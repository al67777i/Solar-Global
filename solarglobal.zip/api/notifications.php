<?php
/**
 * Notifications API
 * AJAX endpoint for notification management.
 *
 * GET  — Fetch notifications (with unread count)
 * POST — Mark as read (single or all)
 *
 * Supports: customer, dealer, installer (determined by session)
 */
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/notification_helpers.php';

// Rate limit
if (!rate_limit('api_notifications', 60, 60)) {
    http_response_code(429);
    echo json_encode(['error' => 'Too many requests.']);
    exit;
}

// Determine user type and ID from session
$user_type = null;
$user_id = null;

if (!empty($_SESSION['customer_id'])) {
    $user_type = 'customer';
    $user_id = (int)$_SESSION['customer_id'];
} elseif (!empty($_SESSION['dealer_id'])) {
    $user_type = 'dealer';
    $user_id = (int)$_SESSION['dealer_id'];
} elseif (!empty($_SESSION['installer_id'])) {
    $user_type = 'installer';
    $user_id = (int)$_SESSION['installer_id'];
}

if (!$user_type || !$user_id) {
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated.']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

// ─── GET: Fetch notifications ───
if ($method === 'GET') {
    $limit  = max(1, min(50, (int)($_GET['limit'] ?? 15)));
    $offset = max(0, (int)($_GET['offset'] ?? 0));
    $unread_only = ($_GET['unread'] ?? '') === '1';

    $unread_count = get_unread_notification_count($user_type, $user_id);

    try {
        $db = getDB();

        $where = "user_type = ? AND user_id = ?";
        $params = [$user_type, $user_id];

        if ($unread_only) {
            $where .= " AND is_read = 0";
        }

        $stmt = $db->prepare("
            SELECT id, type, title, message, link, is_read, created_at
            FROM notifications
            WHERE $where
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        ");
        $params[] = $limit;
        $params[] = $offset;
        $stmt->execute($params);
        $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Format timestamps
        foreach ($notifications as &$n) {
            $n['id'] = (int)$n['id'];
            $n['is_read'] = (bool)$n['is_read'];
            $n['time_ago'] = time_ago($n['created_at']);
        }
        unset($n);

        echo json_encode([
            'success'       => true,
            'notifications' => $notifications,
            'unread_count'  => $unread_count,
            'total'         => count($notifications),
        ]);
    } catch (Exception $e) {
        error_log('Notifications API GET error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to fetch notifications.']);
    }
    exit;
}

// ─── POST: Mark as read ───
if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) $input = $_POST;

    $action = $input['action'] ?? '';

    if ($action === 'mark_read') {
        $notification_id = (int)($input['id'] ?? 0);
        if ($notification_id > 0) {
            mark_notification_read($notification_id, $user_type, $user_id);
        }
        $unread_count = get_unread_notification_count($user_type, $user_id);
        echo json_encode(['success' => true, 'unread_count' => $unread_count]);

    } elseif ($action === 'mark_all_read') {
        mark_all_notifications_read($user_type, $user_id);
        echo json_encode(['success' => true, 'unread_count' => 0]);

    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action.']);
    }
    exit;
}

// Unknown method
http_response_code(405);
echo json_encode(['error' => 'Method not allowed.']);

/**
 * Human-friendly time ago string
 */
function time_ago(string $datetime): string {
    $diff = time() - strtotime($datetime);
    if ($diff < 60)    return 'Just now';
    if ($diff < 3600)  return (int)floor($diff / 60) . 'm ago';
    if ($diff < 86400) return (int)floor($diff / 3600) . 'h ago';
    if ($diff < 604800) return (int)floor($diff / 86400) . 'd ago';
    return date('M j', strtotime($datetime));
}
