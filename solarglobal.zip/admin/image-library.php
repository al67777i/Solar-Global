<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

$pageTitle = 'Image Library';
$message = '';
$error = '';

$folders = ['inverters', 'batteries', 'panels', 'dealers', 'appliances', 'general'];
$uploadBaseDir = __DIR__ . '/../uploads/library/';

// Ensure upload directories exist
foreach ($folders as $folder) {
    $dir = $uploadBaseDir . $folder . '/';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid CSRF token.';
    } else {
        $action = $_POST['action'] ?? '';

        // Upload images
        if ($action === 'upload') {
            $targetFolder = $_POST['folder'] ?? 'general';
            if (!in_array($targetFolder, $folders)) {
                $targetFolder = 'general';
            }

            $uploadDir = $uploadBaseDir . $targetFolder . '/';
            $allowedMimes = ['image/jpeg', 'image/png', 'image/webp'];
            $maxSize = 5 * 1024 * 1024; // 5MB
            $successCount = 0;
            $errors = [];

            if (!empty($_FILES['images']['name'][0])) {
                $fileCount = count($_FILES['images']['name']);
                $fileCount = min($fileCount, 2000); // Max 2000 files

                for ($i = 0; $i < $fileCount; $i++) {
                    if ($_FILES['images']['error'][$i] !== UPLOAD_ERR_OK) {
                        $errors[] = $_FILES['images']['name'][$i] . ': Upload error.';
                        continue;
                    }

                    $tmpName = $_FILES['images']['tmp_name'][$i];
                    $originalName = $_FILES['images']['name'][$i];
                    $fileSize = $_FILES['images']['size'][$i];
                    $mimeType = mime_content_type($tmpName);

                    // Validate MIME
                    if (!in_array($mimeType, $allowedMimes)) {
                        $errors[] = sanitize($originalName) . ': Invalid file type.';
                        continue;
                    }

                    // Validate size
                    if ($fileSize > $maxSize) {
                        $errors[] = sanitize($originalName) . ': File too large (max 5MB).';
                        continue;
                    }

                    // Generate unique filename
                    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                        $ext = 'jpg';
                    }
                    $newFilename = $targetFolder . '_' . time() . '_' . bin2hex(random_bytes(2)) . '.' . $ext;
                    $destPath = $uploadDir . $newFilename;

                    // Get dimensions
                    $imgInfo = getimagesize($tmpName);
                    $width = $imgInfo[0] ?? 0;
                    $height = $imgInfo[1] ?? 0;

                    // Move file
                    if (move_uploaded_file($tmpName, $destPath)) {
                        $filePath = 'uploads/library/' . $targetFolder . '/' . $newFilename;

                        // Create thumbnail if GD available
                        $thumbnailPath = null;
                        if (extension_loaded('gd') && $width > 0) {
                            $thumbDir = $uploadBaseDir . $targetFolder . '/thumbs/';
                            if (!is_dir($thumbDir)) {
                                mkdir($thumbDir, 0755, true);
                            }
                            $thumbPath = $thumbDir . $newFilename;
                            $thumbnailPath = 'uploads/library/' . $targetFolder . '/thumbs/' . $newFilename;

                            $thumbSize = 180;
                            $thumb = imagecreatetruecolor($thumbSize, $thumbSize);

                            // Load source
                            switch ($mimeType) {
                                case 'image/jpeg':
                                    $source = imagecreatefromjpeg($tmpName);
                                    break;
                                case 'image/png':
                                    $source = imagecreatefrompng($tmpName);
                                    break;
                                case 'image/webp':
                                    $source = imagecreatefromwebp($tmpName);
                                    break;
                                default:
                                    $source = null;
                            }

                            if ($source) {
                                // Calculate crop dimensions for cover fit
                                $srcSize = min($width, $height);
                                $srcX = ($width - $srcSize) / 2;
                                $srcY = ($height - $srcSize) / 2;
                                imagecopyresampled($thumb, $source, 0, 0, (int)$srcX, (int)$srcY, $thumbSize, $thumbSize, $srcSize, $srcSize);

                                switch ($mimeType) {
                                    case 'image/jpeg':
                                        imagejpeg($thumb, $thumbPath, 80);
                                        break;
                                    case 'image/png':
                                        imagepng($thumb, $thumbPath);
                                        break;
                                    case 'image/webp':
                                        imagewebp($thumb, $thumbPath, 80);
                                        break;
                                }
                                imagedestroy($thumb);
                                imagedestroy($source);
                            } else {
                                $thumbnailPath = null;
                            }
                        }

                        // Insert into database
                        try {
                            $db = getDB();
                            $stmt = $db->prepare("INSERT INTO image_library (filename, original_filename, file_path, thumbnail_path, folder, mime_type, file_size, width, height, uploaded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                            $stmt->execute([
                                $newFilename,
                                $originalName,
                                $filePath,
                                $thumbnailPath,
                                $targetFolder,
                                $mimeType,
                                $fileSize,
                                $width,
                                $height,
                                $_SESSION['admin_username'] ?? 'admin'
                            ]);
                        } catch (Exception $e) {
                            // DB might not be available, file is still saved
                        }

                        $successCount++;
                    } else {
                        $errors[] = sanitize($originalName) . ': Failed to save.';
                    }
                }

                if ($successCount > 0) {
                    $message = $successCount . ' image(s) uploaded successfully.';
                }
                if (!empty($errors)) {
                    $error = implode('<br>', $errors);
                }
            } else {
                $error = 'No files selected.';
            }
        }

        // Delete single image
        if ($action === 'delete') {
            $id = intval($_POST['id'] ?? 0);
            if ($id > 0) {
                try {
                    $db = getDB();
                    $stmt = $db->prepare("SELECT * FROM image_library WHERE id = ?");
                    $stmt->execute([$id]);
                    $img = $stmt->fetch();

                    if ($img) {
                        // Delete files
                        $fullPath = __DIR__ . '/../' . $img['file_path'];
                        if (file_exists($fullPath)) unlink($fullPath);
                        if (!empty($img['thumbnail_path'])) {
                            $thumbFull = __DIR__ . '/../' . $img['thumbnail_path'];
                            if (file_exists($thumbFull)) unlink($thumbFull);
                        }
                        // Delete DB record
                        $stmt = $db->prepare("DELETE FROM image_library WHERE id = ?");
                        $stmt->execute([$id]);
                        $message = 'Image deleted.';
                    }
                } catch (Exception $e) {
                    $error = 'Delete failed: ' . $e->getMessage();
                }
            }
        }

        // Bulk delete
        if ($action === 'bulk_delete') {
            $ids = $_POST['ids'] ?? [];
            if (!empty($ids) && is_array($ids)) {
                $deleted = 0;
                try {
                    $db = getDB();
                    foreach ($ids as $id) {
                        $id = intval($id);
                        $stmt = $db->prepare("SELECT * FROM image_library WHERE id = ?");
                        $stmt->execute([$id]);
                        $img = $stmt->fetch();
                        if ($img) {
                            $fullPath = __DIR__ . '/../' . $img['file_path'];
                            if (file_exists($fullPath)) unlink($fullPath);
                            if (!empty($img['thumbnail_path'])) {
                                $thumbFull = __DIR__ . '/../' . $img['thumbnail_path'];
                                if (file_exists($thumbFull)) unlink($thumbFull);
                            }
                            $stmt = $db->prepare("DELETE FROM image_library WHERE id = ?");
                            $stmt->execute([$id]);
                            $deleted++;
                        }
                    }
                    $message = $deleted . ' image(s) deleted.';
                } catch (Exception $e) {
                    $error = 'Bulk delete failed: ' . $e->getMessage();
                }
            }
        }

        // Update alt_text/tags
        if ($action === 'update_meta') {
            $id = intval($_POST['id'] ?? 0);
            $altText = trim($_POST['alt_text'] ?? '');
            $tags = trim($_POST['tags'] ?? '');
            if ($id > 0) {
                try {
                    $db = getDB();
                    $stmt = $db->prepare("UPDATE image_library SET alt_text = ?, tags = ? WHERE id = ?");
                    $stmt->execute([$altText, $tags, $id]);
                    $message = 'Image metadata updated.';
                } catch (Exception $e) {
                    $error = 'Update failed: ' . $e->getMessage();
                }
            }
        }
    }
}

// Only need folder/search for tab highlighting — images loaded via AJAX
$filterFolder = $_GET['folder'] ?? 'all';
$search = trim($_GET['search'] ?? '');

// Get total count for display (lightweight query)
$totalImages = 0;
try {
    $db = getDB();
    $totalImages = (int) $db->query("SELECT COUNT(*) FROM image_library")->fetchColumn();
} catch (Exception $e) {
    $error = $error ?: 'Database unavailable. Upload still works (files saved to disk).';
}

include __DIR__ . '/includes/header.php';
?>

<style>
.il-upload-zone {
    border: 2px dashed #cbd5e1;
    border-radius: 12px;
    padding: 2rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s;
    background: #f8fafc;
    margin-bottom: 1.5rem;
}
.il-upload-zone:hover,
.il-upload-zone.dragover {
    border-color: #2563eb;
    background: #eff6ff;
}
.il-upload-zone p {
    margin: 0.5rem 0;
    color: #64748b;
}
.il-upload-zone .upload-icon {
    font-size: 2.5rem;
    margin-bottom: 0.5rem;
}
.il-upload-controls {
    display: flex;
    gap: 1rem;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 1rem;
}
.il-upload-controls select,
.il-upload-controls button {
    padding: 0.5rem 1rem;
    border-radius: 6px;
    border: 1px solid #d1d5db;
    font-size: 0.875rem;
}
.il-upload-controls button {
    background: #2563eb;
    color: #fff;
    border: none;
    cursor: pointer;
    font-weight: 500;
}
.il-upload-controls button:hover {
    background: #1d4ed8;
}

.il-tabs {
    display: flex;
    gap: 0.25rem;
    margin-bottom: 1rem;
    flex-wrap: wrap;
    border-bottom: 2px solid #e2e8f0;
    padding-bottom: 0;
}
.il-tabs a {
    padding: 0.5rem 1rem;
    text-decoration: none;
    color: #64748b;
    border-bottom: 2px solid transparent;
    margin-bottom: -2px;
    font-size: 0.875rem;
    font-weight: 500;
    transition: all 0.2s;
}
.il-tabs a:hover {
    color: #2563eb;
}
.il-tabs a.active {
    color: #2563eb;
    border-bottom-color: #2563eb;
}

.il-search-bar {
    display: flex;
    gap: 0.75rem;
    margin-bottom: 1.5rem;
    align-items: center;
}
.il-search-bar input {
    flex: 1;
    max-width: 320px;
    padding: 0.5rem 0.75rem;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    font-size: 0.875rem;
}
.il-search-bar button {
    padding: 0.5rem 1rem;
    background: #2563eb;
    color: #fff;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.875rem;
}

.il-bulk-bar {
    display: flex;
    gap: 0.75rem;
    margin-bottom: 1rem;
    align-items: center;
}
.il-bulk-bar button {
    padding: 0.4rem 0.75rem;
    background: #dc2626;
    color: #fff;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.8rem;
    font-weight: 500;
}
.il-bulk-bar label {
    font-size: 0.85rem;
    color: #475569;
    cursor: pointer;
}

.il-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 1rem;
}
.il-card {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    overflow: hidden;
    position: relative;
    transition: box-shadow 0.2s;
}
.il-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}
.il-card-check {
    position: absolute;
    top: 8px;
    left: 8px;
    z-index: 2;
    width: 18px;
    height: 18px;
    cursor: pointer;
}
.il-card-img {
    width: 100%;
    height: 180px;
    object-fit: cover;
    display: block;
    background: #f1f5f9;
}
.il-card-body {
    padding: 0.6rem 0.75rem;
}
.il-card-body .il-filename {
    font-size: 0.75rem;
    color: #334155;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-weight: 500;
}
.il-card-body .il-meta {
    font-size: 0.7rem;
    color: #94a3b8;
    margin-top: 0.2rem;
}
.il-card-actions {
    display: flex;
    gap: 0.25rem;
    padding: 0.4rem 0.75rem 0.6rem;
    flex-wrap: wrap;
}
.il-card-actions button,
.il-card-actions .il-btn {
    padding: 0.25rem 0.5rem;
    font-size: 0.7rem;
    border: 1px solid #e2e8f0;
    border-radius: 4px;
    background: #f8fafc;
    cursor: pointer;
    color: #475569;
    text-decoration: none;
}
.il-card-actions button:hover,
.il-card-actions .il-btn:hover {
    background: #e2e8f0;
}
.il-card-actions .il-btn-danger {
    color: #dc2626;
    border-color: #fecaca;
}
.il-card-actions .il-btn-danger:hover {
    background: #fef2f2;
}

.il-edit-form {
    display: none;
    padding: 0.5rem 0.75rem;
    border-top: 1px solid #e2e8f0;
}
.il-edit-form.active {
    display: block;
}
.il-edit-form input {
    width: 100%;
    padding: 0.3rem 0.5rem;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    font-size: 0.75rem;
    margin-bottom: 0.3rem;
}
.il-edit-form button {
    padding: 0.25rem 0.5rem;
    background: #2563eb;
    color: #fff;
    border: none;
    border-radius: 4px;
    font-size: 0.7rem;
    cursor: pointer;
}

.il-message {
    padding: 0.75rem 1rem;
    border-radius: 8px;
    margin-bottom: 1rem;
    font-size: 0.875rem;
}
.il-message.success {
    background: #ecfdf5;
    color: #065f46;
    border: 1px solid #a7f3d0;
}
.il-message.error {
    background: #fef2f2;
    color: #991b1b;
    border: 1px solid #fecaca;
}
.il-empty {
    text-align: center;
    padding: 3rem;
    color: #94a3b8;
}
.il-load-more-btn {
    display: block;
    margin: 1.5rem auto 0;
    padding: 0.6rem 2rem;
    background: #2563eb;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
}
.il-load-more-btn:hover { background: #1d4ed8; }
.il-load-more-btn:disabled { background: #94a3b8; cursor: not-allowed; }
.il-count-bar {
    font-size: 0.82rem;
    color: #64748b;
    margin-bottom: 0.75rem;
}
</style>

<?php if ($message): ?>
    <div class="il-message success"><?= $message ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="il-message error"><?= $error ?></div>
<?php endif; ?>

<!-- Upload Section -->
<form method="POST" enctype="multipart/form-data" id="upload-form">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="upload">

    <div class="il-upload-zone" id="drop-zone">
        <div class="upload-icon">📁</div>
        <p><strong>Drag & drop images here</strong></p>
        <p>or click to select files (max 2000, up to 5MB each)</p>
        <p style="font-size:0.75rem; color:#94a3b8;">Accepted: JPG, PNG, WEBP</p>
        <input type="file" name="images[]" id="file-input" multiple accept=".jpg,.jpeg,.png,.webp" style="display:none;">
    </div>

    <div class="il-upload-controls">
        <select name="folder" id="folder-select">
            <?php foreach ($folders as $f): ?>
                <option value="<?= $f ?>"><?= ucfirst($f) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" id="upload-btn">Upload Images</button>
        <span id="file-count" style="font-size:0.8rem; color:#64748b;"></span>
    </div>
</form>

<!-- Filter Tabs -->
<div class="il-tabs">
    <a href="#" class="<?= $filterFolder === 'all' ? 'active' : '' ?>" onclick="ilFilterFolder('all',this);return false;">All</a>
    <?php foreach ($folders as $f): ?>
        <a href="#" class="<?= $filterFolder === $f ? 'active' : '' ?>" onclick="ilFilterFolder('<?= $f ?>',this);return false;"><?= ucfirst($f) ?></a>
    <?php endforeach; ?>
</div>

<!-- Search Bar -->
<div class="il-search-bar">
    <div style="display:flex; gap:0.5rem; align-items:center; flex:1; max-width:400px;">
        <input type="text" id="il-search-input" value="<?= sanitize($search) ?>" placeholder="Search filename, alt text, tags..." onkeydown="if(event.key==='Enter'){ilSearch();}">
        <button type="button" onclick="ilSearch()">Search</button>
        <button type="button" onclick="document.getElementById('il-search-input').value='';ilSearch();" style="background:#f1f5f9;color:#475569;border:1px solid #d1d5db;">✕</button>
    </div>
</div>

<!-- Bulk Actions -->
<form method="POST" id="bulk-form">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="bulk_delete">

    <div class="il-bulk-bar">
        <label><input type="checkbox" id="select-all"> Select All Visible</label>
        <button type="button" onclick="bulkDeleteSelected()">Delete Selected</button>
        <span id="il-selected-count" style="font-size:0.8rem;color:#475569;"></span>
    </div>

    <!-- Count bar -->
    <div class="il-count-bar" id="il-count-bar">Loading images…</div>

    <!-- Image Grid (populated via AJAX) -->
    <div class="il-grid" id="il-grid"></div>

    <!-- Empty state (hidden initially) -->
    <div class="il-empty" id="il-empty" style="display:none;">
        <p>No images found. Upload some images to get started.</p>
    </div>

    <!-- Loading spinner -->
    <div id="il-loading" style="text-align:center;padding:2rem;color:#64748b;display:none;">Loading…</div>

    <!-- Load More -->
    <button type="button" class="il-load-more-btn" id="il-load-more" style="display:none;" onclick="ilLoadMore()">Load More</button>
</form>

<!-- Hidden form for single delete -->
<form method="POST" id="delete-form" style="display:none;">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="delete-id" value="">
</form>

<!-- Hidden form for meta update -->
<form method="POST" id="meta-form" style="display:none;">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="update_meta">
    <input type="hidden" name="id" id="meta-id" value="">
    <input type="hidden" name="alt_text" id="meta-alt" value="">
    <input type="hidden" name="tags" id="meta-tags" value="">
</form>

<script>
// ── Drag & drop upload ──────────────────────────────────────────────
const dropZone  = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const fileCount = document.getElementById('file-count');

dropZone.addEventListener('click', () => fileInput.click());
dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    fileInput.files = e.dataTransfer.files;
    updateFileCount();
});
fileInput.addEventListener('change', updateFileCount);
function updateFileCount() {
    const count = fileInput.files.length;
    fileCount.textContent = count > 0 ? count + ' file(s) selected' : '';
}

// ── Load More AJAX engine ───────────────────────────────────────────
var _il = {
    page       : 1,
    totalPages : 1,
    total      : 0,
    loaded     : 0,
    folder     : '<?= addslashes($filterFolder) ?>',
    search     : '<?= addslashes($search) ?>',
    loading    : false
};

function ilBuildCard(img) {
    var card = document.createElement('div');
    card.className = 'il-card';
    card.setAttribute('data-id', img.id);

    var sizeKB = img.file_size ? (img.file_size / 1024).toFixed(1) + 'KB' : '';
    var dim    = (img.width && img.height) ? img.width + 'x' + img.height + ' &bull; ' : '';
    var date   = img.created_at ? img.created_at.substring(0, 10) : '';
    var thumb  = img.thumb_url || img.display_url || img.file_path;

    card.innerHTML =
        '<input type="checkbox" name="ids[]" value="' + img.id + '" class="il-card-check bulk-check">' +
        '<img src="' + escHtml(thumb) + '" alt="' + escHtml(img.alt_text || img.original_filename) + '" class="il-card-img" loading="lazy">' +
        '<div class="il-card-body">' +
            '<div class="il-filename" title="' + escHtml(img.original_filename) + '">' + escHtml(img.original_filename) + '</div>' +
            '<div class="il-meta">' + dim + sizeKB + (sizeKB ? ' &bull; ' : '') + date + '</div>' +
        '</div>' +
        '<div class="il-card-actions">' +
            '<button type="button" class="il-btn" onclick="copyPath(\'' + escHtml(img.file_path) + '\')">Copy Path</button>' +
            '<button type="button" class="il-btn" onclick="toggleEdit(' + img.id + ')">Edit</button>' +
            '<button type="button" class="il-btn il-btn-danger" onclick="deleteSingle(' + img.id + ')">Delete</button>' +
        '</div>' +
        '<div class="il-edit-form" id="edit-form-' + img.id + '">' +
            '<input type="text" id="alt-' + img.id + '" value="' + escHtml(img.alt_text || '') + '" placeholder="Alt text...">' +
            '<input type="text" id="tags-' + img.id + '" value="' + escHtml(img.tags || '') + '" placeholder="Tags (comma separated)...">' +
            '<button type="button" onclick="saveMeta(' + img.id + ')">Save</button>' +
        '</div>';
    return card;
}

function ilFetch(append) {
    if (_il.loading) return;
    _il.loading = true;

    var grid    = document.getElementById('il-grid');
    var empty   = document.getElementById('il-empty');
    var loading = document.getElementById('il-loading');
    var loadBtn = document.getElementById('il-load-more');
    var countBar = document.getElementById('il-count-bar');

    if (!append) {
        grid.innerHTML = '';
        _il.page   = 1;
        _il.loaded = 0;
        empty.style.display   = 'none';
        loadBtn.style.display = 'none';
        countBar.textContent  = 'Loading…';
    }

    loading.style.display = 'block';

    var url = 'ajax/image_library_browse.php?page=' + _il.page +
              '&folder=' + encodeURIComponent(_il.folder) +
              '&search=' + encodeURIComponent(_il.search);

    fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(data) {
            loading.style.display = 'none';
            _il.loading = false;

            if (!data.success) {
                countBar.textContent = 'Error loading images.';
                return;
            }

            _il.totalPages = data.total_pages;
            _il.total      = data.total;

            data.images.forEach(function(img) {
                grid.appendChild(ilBuildCard(img));
            });

            _il.loaded += data.images.length;

            if (_il.loaded === 0) {
                empty.style.display = 'block';
                countBar.textContent = '0 images';
            } else {
                countBar.textContent = 'Showing ' + _il.loaded + ' of ' + _il.total + ' images';
            }

            loadBtn.style.display = (_il.page < _il.totalPages) ? 'block' : 'none';
        })
        .catch(function() {
            loading.style.display = 'none';
            _il.loading = false;
            countBar.textContent = 'Failed to load images.';
        });
}

function ilLoadMore() {
    _il.page++;
    ilFetch(true);
}

function ilFilterFolder(folder, btn) {
    _il.folder = folder;
    _il.page   = 1;
    document.querySelectorAll('.il-tabs a').forEach(function(a) { a.classList.remove('active'); });
    btn.classList.add('active');
    ilFetch(false);
    // Update URL without reload for bookmarking
    history.replaceState(null, '', '?folder=' + encodeURIComponent(folder) + '&search=' + encodeURIComponent(_il.search));
}

function ilSearch() {
    _il.search = document.getElementById('il-search-input').value;
    _il.page   = 1;
    ilFetch(false);
    history.replaceState(null, '', '?folder=' + encodeURIComponent(_il.folder) + '&search=' + encodeURIComponent(_il.search));
}

// Load on page open
window.addEventListener('DOMContentLoaded', function() { ilFetch(false); });

// ── Select All visible ───────────────────────────────────────────────
document.getElementById('select-all').addEventListener('change', function() {
    document.querySelectorAll('.bulk-check').forEach(function(cb) { cb.checked = this.checked; }, this);
    updateSelectedCount();
});
document.addEventListener('change', function(e) {
    if (e.target.classList.contains('bulk-check')) updateSelectedCount();
});
function updateSelectedCount() {
    var n = document.querySelectorAll('.bulk-check:checked').length;
    document.getElementById('il-selected-count').textContent = n > 0 ? n + ' selected' : '';
}

// ── Copy path ────────────────────────────────────────────────────────
function copyPath(path) {
    var fullPath = '<?= rtrim(BASE_URL, '/') ?>/' + path;
    navigator.clipboard.writeText(fullPath).then(function() {
        showToast('Path copied!', 'success');
    }).catch(function() {
        prompt('Copy this path:', fullPath);
    });
}

// ── Toggle edit form ─────────────────────────────────────────────────
function toggleEdit(id) {
    var form = document.getElementById('edit-form-' + id);
    form.classList.toggle('active');
}

// ── Save meta via hidden form ─────────────────────────────────────────
function saveMeta(id) {
    document.getElementById('meta-id').value  = id;
    document.getElementById('meta-alt').value  = document.getElementById('alt-' + id).value;
    document.getElementById('meta-tags').value = document.getElementById('tags-' + id).value;
    document.getElementById('meta-form').submit();
}

// ── AJAX single delete ──────────────────────────────────────────────
function deleteSingle(id) {
    if (!confirm('Delete this image permanently? This cannot be undone.')) return;
    var csrfInput = document.querySelector('#delete-form input[name="csrf_token"]');
    var fd = new FormData();
    fd.append('action', 'delete');
    fd.append('id', id);
    fd.append('csrf_token', csrfInput ? csrfInput.value : '');
    fetch('image-library.php', { method: 'POST', body: fd })
        .then(function(r) { return r.text(); })
        .then(function() {
            var card = document.querySelector('.il-card[data-id="' + id + '"]');
            if (card) { card.remove(); _il.loaded--; _il.total--; }
            document.getElementById('il-count-bar').textContent =
                'Showing ' + _il.loaded + ' of ' + _il.total + ' images';
            if (_il.loaded === 0) document.getElementById('il-empty').style.display = 'block';
            showToast('Image deleted.', 'success');
        })
        .catch(function() { showToast('Delete failed.', 'error'); });
}

// ── AJAX bulk delete ─────────────────────────────────────────────────
function bulkDeleteSelected() {
    var checked = Array.from(document.querySelectorAll('.bulk-check:checked'));
    if (checked.length === 0) { showToast('No images selected.', 'error'); return; }
    if (!confirm('Delete ' + checked.length + ' selected image(s) permanently?')) return;
    var csrfInput = document.querySelector('#bulk-form input[name="csrf_token"]');
    var fd = new FormData();
    fd.append('action', 'bulk_delete');
    fd.append('csrf_token', csrfInput ? csrfInput.value : '');
    checked.forEach(function(cb) { fd.append('ids[]', cb.value); });
    fetch('image-library.php', { method: 'POST', body: fd })
        .then(function(r) { return r.text(); })
        .then(function() {
            checked.forEach(function(cb) {
                var card = cb.closest('.il-card');
                if (card) { card.remove(); _il.loaded--; _il.total--; }
            });
            document.getElementById('il-selected-count').textContent = '';
            document.getElementById('select-all').checked = false;
            document.getElementById('il-count-bar').textContent =
                'Showing ' + _il.loaded + ' of ' + _il.total + ' images';
            if (_il.loaded === 0) document.getElementById('il-empty').style.display = 'block';
            showToast(checked.length + ' image(s) deleted.', 'success');
        })
        .catch(function() { showToast('Bulk delete failed.', 'error'); });
}

// ── Toast notification ───────────────────────────────────────────────
function showToast(msg, type) {
    var toast = document.getElementById('il-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'il-toast';
        toast.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:99999;padding:12px 22px;border-radius:10px;font-size:0.9rem;font-weight:600;box-shadow:0 4px 20px rgba(0,0,0,0.18);transition:all 0.3s;opacity:0;transform:translateY(10px);';
        document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.background = type === 'success' ? '#065f46' : '#991b1b';
    toast.style.color = '#fff';
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
    clearTimeout(toast._t);
    toast._t = setTimeout(function() { toast.style.opacity='0'; toast.style.transform='translateY(10px)'; }, 3000);
}

function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
