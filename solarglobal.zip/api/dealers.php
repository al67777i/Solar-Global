<?php
/**
 * Dealers API - Public
 * Returns dealers within radius with inventory + prices
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');

// Rate limiting: 30 requests per minute
if (!rate_limit('api_dealers', 30, 60)) {
    respond_rate_limited();
}

$db = getDB();

$action = $_GET['action'] ?? 'search';

switch ($action) {

    case 'search':
        $lat = floatval($_GET['lat'] ?? 0);
        $lng = floatval($_GET['lng'] ?? 0);
        $radius = min(500, max(5, (int)($_GET['radius'] ?? 50)));

        if (!$lat && !$lng) {
            respond_json(['error' => 'Location required.'], 400);
        }

        $sql = "SELECT d.id, d.business_name, d.city, d.country_code, d.latitude, d.longitude,
                       d.logo_path, d.avg_rating, d.total_reviews, d.phone,
                       (6371 * ACOS(
                           COS(RADIANS(:lat1)) * COS(RADIANS(d.latitude)) * COS(RADIANS(d.longitude) - RADIANS(:lng1)) +
                           SIN(RADIANS(:lat2)) * SIN(RADIANS(d.latitude))
                       )) AS distance_km
                FROM dealers d
                WHERE d.status = 'active'
                AND d.latitude IS NOT NULL AND d.longitude IS NOT NULL
                HAVING distance_km <= :radius
                ORDER BY d.avg_rating DESC, distance_km ASC
                LIMIT 50";
        $stmt = $db->prepare($sql);
        $stmt->execute([':lat1' => $lat, ':lng1' => $lng, ':lat2' => $lat, ':radius' => $radius]);
        $dealers = $stmt->fetchAll();

        // Product counts
        if (!empty($dealers)) {
            $ids = array_column($dealers, 'id');
            $ph = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $db->prepare("SELECT dealer_id, product_type, COUNT(*) cnt FROM dealer_products WHERE dealer_id IN ($ph) AND is_active = 1 GROUP BY dealer_id, product_type");
            $stmt->execute($ids);
            $prods = [];
            foreach ($stmt->fetchAll() as $r) $prods[$r['dealer_id']][$r['product_type']] = (int)$r['cnt'];
            foreach ($dealers as &$d) $d['products'] = $prods[$d['id']] ?? [];
            unset($d);
        }

        respond_json(['dealers' => $dealers, 'count' => count($dealers)]);
        break;

    case 'inventory':
        $dealer_id = (int)($_GET['dealer_id'] ?? 0);
        $type = $_GET['type'] ?? '';
        if ($dealer_id <= 0) respond_json(['error' => 'Invalid dealer.'], 400);

        // Verify dealer is active
        $stmt = $db->prepare("SELECT id, business_name FROM dealers WHERE id = ? AND status = 'active'");
        $stmt->execute([$dealer_id]);
        if (!$stmt->fetch()) respond_json(['error' => 'Dealer not found.'], 404);

        $typeFilter = '';
        $params = [$dealer_id];
        if (in_array($type, ['inverter', 'battery', 'panel', 'installation_appliance'])) {
            $typeFilter = 'AND dp.product_type = ?';
            $params[] = $type;
        }

        $sql = "SELECT dp.id as dp_id, dp.product_type, dp.product_id, dp.dealer_price, dp.currency,
                       dp.stock_quantity, dp.stock_status,
                       CASE dp.product_type
                           WHEN 'inverter' THEN (SELECT name FROM inverters WHERE id = dp.product_id)
                           WHEN 'battery' THEN (SELECT name FROM batteries WHERE id = dp.product_id)
                           WHEN 'panel' THEN (SELECT name FROM panels WHERE id = dp.product_id)
                           WHEN 'installation_appliance' THEN (SELECT name FROM installation_appliances WHERE id = dp.product_id)
                       END as product_name,
                       CASE dp.product_type
                           WHEN 'inverter' THEN (SELECT company FROM inverters WHERE id = dp.product_id)
                           WHEN 'battery' THEN (SELECT brand FROM batteries WHERE id = dp.product_id)
                           WHEN 'panel' THEN (SELECT brand FROM panels WHERE id = dp.product_id)
                           WHEN 'installation_appliance' THEN (SELECT brand FROM installation_appliances WHERE id = dp.product_id)
                       END as brand
                FROM dealer_products dp
                WHERE dp.dealer_id = ? AND dp.is_active = 1 $typeFilter
                ORDER BY dp.product_type, dp.dealer_price ASC";

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        respond_json(['products' => $stmt->fetchAll()]);
        break;

    case 'reviews':
        $dealer_id = (int)($_GET['dealer_id'] ?? 0);
        if ($dealer_id <= 0) respond_json(['error' => 'Invalid dealer.'], 400);

        $stmt = $db->prepare("SELECT r.rating, r.review_text, r.created_at, c.name as customer_name
                              FROM dealer_reviews r
                              JOIN customers c ON r.customer_id = c.id
                              WHERE r.dealer_id = ? AND r.status = 'approved'
                              ORDER BY r.created_at DESC LIMIT 20");
        $stmt->execute([$dealer_id]);
        respond_json(['reviews' => $stmt->fetchAll()]);
        break;

    default:
        respond_json(['error' => 'Invalid action.'], 400);
}
