<?php
/**
 * Email Verification Page
 * Shared page for verifying 6-digit codes (registration, password reset)
 */
session_start();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/customer_auth.php';
require_once __DIR__ . '/includes/email_verification.php';

set_security_headers();

$db = getDB();
$error = '';
$success = '';
$site_name = get_system_setting('site_name', 'SolarGlobal');

// Get email from GET param or session
$email = trim($_GET['email'] ?? $_SESSION['verify_email'] ?? '');
$type = trim($_GET['type'] ?? 'registration');

// Store email in session for subsequent requests
if (!empty($email)) {
    $_SESSION['verify_email'] = $email;
}

// Redirect if no email provided
if (empty($email)) {
    header('Location: /solarglobal/customer/login.php');
    exit();
}

// Mask email: b***@gmail.com
function mask_email(string $email): string {
    $parts = explode('@', $email);
    if (count($parts) !== 2) return '***';
    $local = $parts[0];
    $domain = $parts[1];
    $masked_local = substr($local, 0, 1) . str_repeat('*', max(3, strlen($local) - 1));
    return $masked_local . '@' . $domain;
}

$masked_email = mask_email($email);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';

    if ($action === 'verify') {
        $code = trim($_POST['verification_code'] ?? '');

        if (empty($code) || strlen($code) !== 6 || !ctype_digit($code)) {
            $error = 'Please enter a valid 6-digit code.';
        } else {
            if (verify_code($email, $code, $type)) {
                if ($type === 'registration') {
                    $role = trim($_GET['role'] ?? $_POST['role'] ?? 'customer');

                    if ($role === 'dealer' && !empty($_SESSION['verify_dealer_id'])) {
                        // Mark dealer email as verified
                        $stmt = $db->prepare("UPDATE dealers SET email_verified = 1, email_verified_at = NOW() WHERE id = ?");
                        $stmt->execute([$_SESSION['verify_dealer_id']]);
                        unset($_SESSION['verify_email'], $_SESSION['verify_dealer_id']);
                        header('Location: /solarglobal/dealer/login.php?verified=1');
                        exit();
                    } elseif ($role === 'installer' && !empty($_SESSION['verify_installer_id'])) {
                        // Mark installer email as verified, then login
                        $installer_id = $_SESSION['verify_installer_id'];
                        $stmt = $db->prepare("UPDATE installers SET email_verified = 1 WHERE id = ?");
                        $stmt->execute([$installer_id]);
                        unset($_SESSION['verify_email'], $_SESSION['verify_installer_id']);

                        // Auto-login installer
                        require_once __DIR__ . '/includes/installer_auth.php';
                        $stmt = $db->prepare("SELECT * FROM installers WHERE id = ?");
                        $stmt->execute([$installer_id]);
                        $installer_data = $stmt->fetch();
                        if ($installer_data) installer_login($installer_data);

                        header('Location: /solarglobal/installer/subscription.php?new_account=1');
                        exit();
                    } else {
                        // Customer registration
                        $stmt = $db->prepare("UPDATE customers SET email_verified = 1 WHERE email = ?");
                        $stmt->execute([$email]);

                        // Fetch customer and auto-login
                        $stmt = $db->prepare("SELECT * FROM customers WHERE email = ? LIMIT 1");
                        $stmt->execute([$email]);
                        $customer = $stmt->fetch();

                        if ($customer) {
                            customer_login($customer);
                        }

                        unset($_SESSION['verify_email']);
                        header('Location: /solarglobal/customer/orders.php');
                        exit();
                    }
                } elseif ($type === 'password_reset') {
                    // Set session flag for reset-password page
                    $_SESSION['password_reset_verified'] = true;
                    $_SESSION['password_reset_email'] = $email;
                    unset($_SESSION['verify_email']);

                    header('Location: /solarglobal/reset-password.php');
                    exit();
                }
            } else {
                $error = 'Invalid or expired code. Please try again or request a new one.';
            }
        }
    } elseif ($action === 'resend') {
        // Rate limit: 60 seconds between resends
        $last_resend = $_SESSION['last_resend_time'] ?? 0;
        $time_since_last = time() - $last_resend;

        if ($time_since_last < 60) {
            $remaining = 60 - $time_since_last;
            $error = "Please wait {$remaining} seconds before requesting a new code.";
        } else {
            // Generate and send new code
            $code = generate_verification_code();
            store_verification_code($email, $code, $type);

            // Get name for email based on role
            $role_check = trim($_GET['role'] ?? $_POST['role'] ?? 'customer');
            $name = '';
            if ($role_check === 'dealer') {
                $stmt = $db->prepare("SELECT owner_name FROM dealers WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $row = $stmt->fetch();
                $name = $row['owner_name'] ?? '';
            } elseif ($role_check === 'installer') {
                $stmt = $db->prepare("SELECT owner_name FROM installers WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $row = $stmt->fetch();
                $name = $row['owner_name'] ?? '';
            } else {
                $stmt = $db->prepare("SELECT name FROM customers WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $row = $stmt->fetch();
                $name = $row['name'] ?? '';
            }

            send_verification_email($email, $code, $name);

            $_SESSION['last_resend_time'] = time();
            $success = 'A new verification code has been sent to your email.';
        }
    }
}

// Calculate resend cooldown for JS timer
$last_resend = $_SESSION['last_resend_time'] ?? 0;
$cooldown_remaining = max(0, 60 - (time() - $last_resend));

$page_title = 'Verify Email';
$page_description = 'Enter your verification code to activate your account.';
$page_robots = 'noindex, nofollow';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="<?= $page_robots ?>">
    <meta name="description" content="<?= htmlspecialchars($page_description) ?>">
    <title><?= htmlspecialchars($page_title) ?> - <?= sanitize($site_name) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0F172A 0%, #1E3A5F 50%, #0F172A 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .verify-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
        }

        .logo { text-align: center; margin-bottom: 32px; }
        .logo h1 { font-size: 1.75rem; font-weight: 800; color: #0F172A; }
        .logo h1 span { color: #F59E0B; }
        .logo p { color: #64748B; font-size: 0.875rem; margin-top: 4px; }

        .icon-wrapper {
            text-align: center;
            margin-bottom: 20px;
        }
        .icon-wrapper svg {
            width: 56px;
            height: 56px;
            color: #F59E0B;
        }

        .description {
            text-align: center;
            color: #475569;
            font-size: 0.875rem;
            margin-bottom: 24px;
            line-height: 1.5;
        }
        .description strong {
            color: #1E293B;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 10px;
            font-size: 0.875rem;
            margin-bottom: 20px;
        }
        .alert-error { background: #FEF2F2; color: #991B1B; border: 1px solid #FECACA; }
        .alert-success { background: #F0FDF4; color: #166534; border: 1px solid #BBF7D0; }

        .otp-inputs {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin-bottom: 24px;
        }
        .otp-inputs input {
            width: 48px;
            height: 56px;
            text-align: center;
            font-size: 1.5rem;
            font-weight: 700;
            border: 2px solid #E2E8F0;
            border-radius: 12px;
            font-family: inherit;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .otp-inputs input:focus {
            outline: none;
            border-color: #F59E0B;
            box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.15);
        }
        .otp-inputs input.filled {
            border-color: #F59E0B;
            background: #FFFBEB;
        }

        .btn {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 10px;
            font-size: 0.9375rem;
            font-weight: 700;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.2s;
        }
        .btn-primary {
            background: #F59E0B;
            color: #1E293B;
        }
        .btn-primary:hover {
            background: #D97706;
            transform: translateY(-1px);
        }
        .btn-primary:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .resend-section {
            text-align: center;
            margin-top: 20px;
            font-size: 0.8125rem;
            color: #64748B;
        }
        .resend-section button {
            background: none;
            border: none;
            color: #F59E0B;
            font-weight: 600;
            cursor: pointer;
            font-family: inherit;
            font-size: 0.8125rem;
            text-decoration: underline;
        }
        .resend-section button:hover {
            color: #D97706;
        }
        .resend-section button:disabled {
            color: #94A3B8;
            cursor: not-allowed;
            text-decoration: none;
        }
        .resend-timer {
            color: #94A3B8;
            font-size: 0.8125rem;
            margin-top: 4px;
        }

        .back-link {
            text-align: center;
            margin-top: 24px;
        }
        .back-link a {
            color: #64748B;
            text-decoration: none;
            font-size: 0.8125rem;
            transition: color 0.2s;
        }
        .back-link a:hover {
            color: #F59E0B;
        }
    </style>
</head>
<body>
    <div class="verify-card">
        <div class="logo">
            <h1><?= sanitize($site_name) ?></h1>
            <p>Email Verification</p>
        </div>

        <div class="icon-wrapper">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
            </svg>
        </div>

        <p class="description">
            We sent a 6-digit verification code to<br>
            <strong><?= sanitize($masked_email) ?></strong>
        </p>

        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>

        <?php $role = sanitize(trim($_GET['role'] ?? 'customer')); ?>
        <form method="POST" id="verify-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="verify">
            <input type="hidden" name="role" value="<?= $role ?>">
            <input type="hidden" name="verification_code" id="verification-code">

            <div class="otp-inputs" id="otp-container">
                <input type="text" inputmode="numeric" maxlength="1" class="otp-digit" autofocus autocomplete="one-time-code">
                <input type="text" inputmode="numeric" maxlength="1" class="otp-digit">
                <input type="text" inputmode="numeric" maxlength="1" class="otp-digit">
                <input type="text" inputmode="numeric" maxlength="1" class="otp-digit">
                <input type="text" inputmode="numeric" maxlength="1" class="otp-digit">
                <input type="text" inputmode="numeric" maxlength="1" class="otp-digit">
            </div>

            <button type="submit" class="btn btn-primary" id="verify-btn">Verify Code</button>
        </form>

        <div class="resend-section">
            <span>Didn't receive the code?</span>
            <form method="POST" style="display:inline;" id="resend-form">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="resend">
                <button type="submit" id="resend-btn" <?= $cooldown_remaining > 0 ? 'disabled' : '' ?>>Resend Code</button>
            </form>
            <div class="resend-timer" id="resend-timer" <?= $cooldown_remaining <= 0 ? 'style="display:none;"' : '' ?>>
                Resend in <span id="countdown"><?= $cooldown_remaining ?></span>s
            </div>
        </div>

        <div class="back-link">
            <a href="/solarglobal/customer/login.php">&larr; Back to Login</a>
        </div>
    </div>

    <script>
    // OTP digit inputs behavior
    const digits = document.querySelectorAll('.otp-digit');
    const hiddenInput = document.getElementById('verification-code');
    const verifyForm = document.getElementById('verify-form');

    function updateHiddenCode() {
        const code = Array.from(digits).map(d => d.value).join('');
        hiddenInput.value = code;
        // Toggle filled class
        digits.forEach(d => {
            d.classList.toggle('filled', d.value !== '');
        });
        return code;
    }

    digits.forEach((input, idx) => {
        input.addEventListener('input', e => {
            const val = e.target.value.replace(/\D/g, '');
            e.target.value = val.slice(0, 1);
            if (val && idx < digits.length - 1) {
                digits[idx + 1].focus();
            }
            const code = updateHiddenCode();
            // Auto-submit when all 6 digits filled
            if (code.length === 6) {
                verifyForm.submit();
            }
        });

        input.addEventListener('keydown', e => {
            if (e.key === 'Backspace' && !e.target.value && idx > 0) {
                digits[idx - 1].focus();
                digits[idx - 1].value = '';
                updateHiddenCode();
            }
        });

        input.addEventListener('paste', e => {
            e.preventDefault();
            const pasted = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6);
            pasted.split('').forEach((ch, i) => {
                if (digits[i]) digits[i].value = ch;
            });
            const focusIdx = Math.min(pasted.length, digits.length - 1);
            digits[focusIdx].focus();
            const code = updateHiddenCode();
            if (code.length === 6) {
                verifyForm.submit();
            }
        });

        // Select content on focus for easy overwrite
        input.addEventListener('focus', () => {
            input.select();
        });
    });

    // Resend countdown timer
    let cooldown = <?= (int)$cooldown_remaining ?>;
    const resendBtn = document.getElementById('resend-btn');
    const timerEl = document.getElementById('resend-timer');
    const countdownEl = document.getElementById('countdown');

    function updateTimer() {
        if (cooldown > 0) {
            cooldown--;
            countdownEl.textContent = cooldown;
            resendBtn.disabled = true;
            timerEl.style.display = '';
            if (cooldown <= 0) {
                resendBtn.disabled = false;
                timerEl.style.display = 'none';
            } else {
                setTimeout(updateTimer, 1000);
            }
        }
    }

    if (cooldown > 0) {
        setTimeout(updateTimer, 1000);
    }

    // After resend, start a fresh 60s timer
    document.getElementById('resend-form').addEventListener('submit', function() {
        cooldown = 60;
        countdownEl.textContent = cooldown;
        resendBtn.disabled = true;
        timerEl.style.display = '';
        setTimeout(updateTimer, 1000);
    });
    </script>
</body>
</html>
