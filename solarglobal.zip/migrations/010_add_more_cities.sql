-- Phase 10b: Add missing Pakistani cities (~50 more)

INSERT IGNORE INTO cities (name_en, name_ur, province, latitude, longitude, elevation_m) VALUES
-- Punjab (missing)
('Attock', 'اٹک', 'Punjab', 33.7660, 72.3609, 384),
('Bhakkar', 'بھکر', 'Punjab', 31.6082, 71.0854, 156),
('Chakwal', 'چکوال', 'Punjab', 32.9328, 72.8630, 520),
('Daska', 'ڈسکہ', 'Punjab', 32.3245, 74.3507, 232),
('Hafizabad', 'حافظ آباد', 'Punjab', 32.0709, 73.6880, 210),
('Kamoke', 'کموکی', 'Punjab', 31.9756, 74.2239, 217),
('Khanewal', 'خانیوال', 'Punjab', 30.3017, 71.9321, 128),
('Kharian', 'کھاریاں', 'Punjab', 32.8110, 73.8810, 270),
('Layyah', 'لیہ', 'Punjab', 30.9693, 70.9428, 140),
('Lodhran', 'لودھراں', 'Punjab', 29.5383, 71.6338, 111),
('Mandi Bahauddin', 'منڈی بہاؤالدین', 'Punjab', 32.5840, 73.4910, 225),
('Muzaffargarh', 'مظفر گڑھ', 'Punjab', 30.0753, 71.1936, 122),
('Narowal', 'نارووال', 'Punjab', 32.1024, 74.8730, 227),
('Pakpattan', 'پاکپتن', 'Punjab', 30.3437, 73.3864, 139),
('Rajanpur', 'راجن پور', 'Punjab', 29.1044, 70.3296, 90),
('Toba Tek Singh', 'ٹوبہ ٹیک سنگھ', 'Punjab', 30.9709, 72.4826, 161),
('Vehari', 'وہاڑی', 'Punjab', 30.0452, 72.3489, 140),
('Wazirabad', 'وزیرآباد', 'Punjab', 32.4427, 74.1197, 225),
('Nankana Sahib', 'ننکانہ صاحب', 'Punjab', 31.4500, 73.7000, 191),
('Burewala', 'بوریوالا', 'Punjab', 30.1667, 72.6500, 148),
('Taxila', 'ٹیکسلا', 'Punjab', 33.7400, 72.7900, 500),
('Muridke', 'مریدکے', 'Punjab', 31.8000, 74.2600, 218),

-- Sindh (missing)
('Badin', 'بدین', 'Sindh', 24.6560, 68.8376, 10),
('Dadu', 'دادو', 'Sindh', 26.7319, 67.7762, 37),
('Ghotki', 'گھوٹکی', 'Sindh', 28.0000, 69.3200, 60),
('Khairpur', 'خیرپور', 'Sindh', 27.5295, 68.7592, 46),
('Matiari', 'مٹیاری', 'Sindh', 25.7720, 68.4456, 22),
('Sanghar', 'سانگھڑ', 'Sindh', 26.0467, 68.9489, 29),
('Shikarpur', 'شکار پور', 'Sindh', 27.9556, 68.6382, 53),
('Tando Adam', 'ٹنڈو آدم', 'Sindh', 25.7617, 68.6606, 18),
('Umerkot', 'عمرکوٹ', 'Sindh', 25.3614, 69.7362, 26),

-- KPK (missing)
('Bannu', 'بنوں', 'KPK', 32.9889, 70.6042, 371),
('Charsadda', 'چارسدہ', 'KPK', 34.1478, 71.7421, 330),
('Haripur', 'ہری پور', 'KPK', 33.9940, 72.9330, 520),
('Karak', 'کرک', 'KPK', 33.1167, 71.0833, 600),
('Lakki Marwat', 'لکی مروت', 'KPK', 32.6072, 70.9122, 320),
('Mingora', 'منگورہ', 'KPK', 34.7717, 72.3600, 984),
('Nowshera', 'نوشہرہ', 'KPK', 34.0153, 71.9747, 288),
('Tank', 'ٹانک', 'KPK', 32.2167, 70.3833, 250),
('Timergara', 'تیمرگرہ', 'KPK', 34.8272, 71.8406, 815),

-- Balochistan (missing)
('Chaman', 'چمن', 'Balochistan', 30.9210, 66.4510, 1338),
('Dalbandin', 'دالبندین', 'Balochistan', 28.8884, 64.3979, 848),
('Loralai', 'لورالائی', 'Balochistan', 30.3705, 68.5970, 1400),
('Mastung', 'مستونگ', 'Balochistan', 29.7943, 66.8455, 1580),
('Nushki', 'نوشکی', 'Balochistan', 29.5520, 66.0230, 1000),
('Sibi', 'سبی', 'Balochistan', 29.5430, 67.8770, 133),
('Ziarat', 'زیارت', 'Balochistan', 30.3810, 67.7264, 2453),

-- AJK/GB (missing)
('Bagh', 'باغ', 'AJK', 33.9800, 73.7800, 1067),
('Rawalakot', 'راولاکوٹ', 'AJK', 33.8577, 73.7607, 1638),
('Chilas', 'چلاس', 'Gilgit-Baltistan', 35.4147, 74.0967, 1250);
