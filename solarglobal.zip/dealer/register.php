<?php
/**
 * Dealer Registration Page
 * Solar dealers can register their store on SolarGlobal
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';
require_once __DIR__ . '/../includes/email_verification.php';

set_security_headers();

// If already logged in, go to dashboard
if (is_dealer_logged_in()) {
    header('Location: /solarglobal/dealer/dashboard.php');
    exit();
}

$errors = [];
$success = false;
$form_data = [
    'business_name' => '',
    'owner_name' => '',
    'email' => '',
    'phone' => '',
    'address' => '',
    'city' => '',
    'country_code' => '',
    'store_description' => '',
    'business_reg_number' => '',
    'latitude' => '',
    'longitude' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please try again.';
    } elseif (!validate_honeypot('website_url')) {
        $errors[] = 'Submission rejected.';
    } else {
        // Collect form data
        $form_data['business_name'] = trim($_POST['business_name'] ?? '');
        $form_data['owner_name'] = trim($_POST['owner_name'] ?? '');
        $form_data['email'] = strtolower(trim($_POST['email'] ?? ''));
        $form_data['phone'] = trim($_POST['phone'] ?? '');
        $form_data['address'] = trim($_POST['address'] ?? '');
        $form_data['city'] = trim($_POST['city'] ?? '');
        $form_data['country_code'] = trim($_POST['country_code'] ?? '');
        $form_data['store_description'] = trim($_POST['store_description'] ?? '');
        $form_data['business_reg_number'] = trim($_POST['business_reg_number'] ?? '');
        $form_data['latitude'] = trim($_POST['latitude'] ?? '');
        $form_data['longitude'] = trim($_POST['longitude'] ?? '');
        $password = $_POST['password'] ?? '';
        $password_confirm = $_POST['password_confirm'] ?? '';

        // Validation
        if (empty($form_data['business_name'])) $errors[] = 'Business name is required.';
        if (strlen($form_data['business_name']) > 200) $errors[] = 'Business name too long (max 200 chars).';

        if (empty($form_data['owner_name'])) $errors[] = 'Owner name is required.';
        if (strlen($form_data['owner_name']) > 150) $errors[] = 'Owner name too long (max 150 chars).';

        if (empty($form_data['email'])) {
            $errors[] = 'Email is required.';
        } elseif (!filter_var($form_data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if (empty($password)) {
            $errors[] = 'Password is required.';
        } elseif (strlen($password) < 8) {
            $errors[] = 'Password must be at least 8 characters.';
        } elseif (!preg_match('/[A-Z]/', $password)) {
            $errors[] = 'Password must contain at least one uppercase letter.';
        } elseif (!preg_match('/[0-9]/', $password)) {
            $errors[] = 'Password must contain at least one number.';
        }

        if ($password !== $password_confirm) {
            $errors[] = 'Passwords do not match.';
        }

        if (empty($form_data['address'])) $errors[] = 'Store address is required.';

        if (empty($form_data['latitude']) || empty($form_data['longitude'])) {
            $errors[] = 'Please select your store location on the map.';
        }

        // Check duplicate email
        if (empty($errors)) {
            $db = getDB();
            $stmt = $db->prepare("SELECT id FROM dealers WHERE email = ?");
            $stmt->execute([$form_data['email']]);
            if ($stmt->fetch()) {
                $errors[] = 'An account with this email already exists. <a href="login.php">Login instead?</a>';
            }
        }

        // Handle logo upload
        $logo_path = null;
        if (isset($_FILES['store_logo']) && $_FILES['store_logo']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['store_logo'];
            $allowed_types = ['image/jpeg', 'image/png', 'image/webp'];
            $max_size = 2 * 1024 * 1024; // 2MB

            if (!in_array($file['type'], $allowed_types)) {
                $errors[] = 'Logo must be JPG, PNG, or WebP format.';
            } elseif ($file['size'] > $max_size) {
                $errors[] = 'Logo file must be under 2MB.';
            } else {
                $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                $filename = 'dealer_logo_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                $upload_dir = __DIR__ . '/../uploads/dealers/logos/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

                if (move_uploaded_file($file['tmp_name'], $upload_dir . $filename)) {
                    $logo_path = 'uploads/dealers/logos/' . $filename;
                } else {
                    $errors[] = 'Failed to upload logo. Please try again.';
                }
            }
        }

        // Create account if no errors
        if (empty($errors)) {
            try {
                $db = getDB();
                $password_hash = password_hash($password, PASSWORD_BCRYPT);

                $stmt = $db->prepare("
                    INSERT INTO dealers (email, password_hash, business_name, owner_name, phone,
                        store_description, address, latitude, longitude, country_code, city,
                        business_reg_number, logo_path, status, email_verified, subscription_plan, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'inactive', 0, 'basic', NOW())
                ");
                $stmt->execute([
                    $form_data['email'],
                    $password_hash,
                    $form_data['business_name'],
                    $form_data['owner_name'],
                    $form_data['phone'],
                    $form_data['store_description'],
                    $form_data['address'],
                    $form_data['latitude'],
                    $form_data['longitude'],
                    $form_data['country_code'],
                    $form_data['city'],
                    $form_data['business_reg_number'],
                    $logo_path,
                ]);

                $dealer_id = $db->lastInsertId();

                // Email verification
                if (is_email_verification_required()) {
                    $code = generate_verification_code();
                    store_verification_code($form_data['email'], $code, 'registration');
                    send_verification_email($form_data['email'], $code, $form_data['owner_name']);
                    $_SESSION['verify_email'] = $form_data['email'];
                    $_SESSION['verify_dealer_id'] = $dealer_id;
                    header('Location: /solarglobal/verify-email.php?email=' . urlencode($form_data['email']) . '&type=registration&role=dealer');
                    exit();
                } else {
                    // Auto-verify when email verification is disabled
                    $stmt = $db->prepare("UPDATE dealers SET email_verified = 1, email_verified_at = NOW() WHERE id = ?");
                    $stmt->execute([$dealer_id]);
                }

                // Account stays inactive until payment is made
                $success = true;
            } catch (Exception $e) {
                error_log("Dealer registration error: " . $e->getMessage());
                $errors[] = 'Registration failed. Please try again.';
            }
        }
    }
}

$current_page = 'register';
$page_title = 'Open Your Solar Store';
require_once __DIR__ . '/../includes/header.php';
?>

<?php
$maps_key = get_system_setting('google_maps_api_key', '');
// No hardcoded fallback — key must be set in Admin → Settings
?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
<script>
var useGoogleMaps = false;
function regGmapsReady() { useGoogleMaps = true; }
function gm_authFailure() { useGoogleMaps = false; }
</script>
<script async src="https://maps.googleapis.com/maps/api/js?key=<?= sanitize($maps_key) ?>&libraries=places&callback=regGmapsReady"></script>

<style>
    .page-header {
        background: linear-gradient(135deg, #0D3B6E 0%, #1565C0 50%, #F59E0B 100%);
        padding: 40px 20px;
        text-align: center;
        color: white;
    }
    .page-header h1 { font-size: 2rem; font-weight: 800; margin-bottom: 8px; }
    .page-header p { font-size: 1rem; opacity: 0.9; max-width: 600px; margin: 0 auto; }
    .page-header .back-link {
        display: inline-block; margin-bottom: 16px; color: rgba(255,255,255,0.8);
        text-decoration: none; font-size: 0.875rem;
    }
    .page-header .back-link:hover { color: white; }

    .register-container {
        max-width: 800px; margin: -30px auto 40px; padding: 0 20px;
    }

    /* Wizard Step Indicator */
    .wizard-steps {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0;
        margin-bottom: 32px;
        padding: 0 10px;
    }
    .wizard-step-item {
        display: flex;
        align-items: center;
        gap: 0;
    }
    .wizard-step-circle {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 6px;
        cursor: default;
        min-width: 80px;
    }
    .wizard-step-num {
        width: 40px; height: 40px;
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 0.9375rem; font-weight: 700;
        background: #E2E8F0; color: #94A3B8;
        transition: all 0.3s;
        border: 3px solid transparent;
    }
    .wizard-step-num.active {
        background: #F59E0B; color: white;
        border-color: #FDE68A;
        box-shadow: 0 0 0 4px rgba(245,158,11,0.15);
    }
    .wizard-step-num.completed {
        background: #16A34A; color: white;
        border-color: #BBF7D0;
    }
    .wizard-step-label {
        font-size: 0.7rem; font-weight: 600;
        color: #94A3B8; text-align: center;
        white-space: nowrap;
        transition: color 0.3s;
    }
    .wizard-step-label.active { color: #F59E0B; }
    .wizard-step-label.completed { color: #16A34A; }
    .wizard-step-line {
        width: 40px; height: 3px;
        background: #E2E8F0;
        margin: 0 4px;
        margin-bottom: 22px;
        border-radius: 2px;
        transition: background 0.3s;
    }
    .wizard-step-line.completed { background: #16A34A; }
    @media (max-width: 500px) {
        .wizard-step-circle { min-width: 56px; }
        .wizard-step-label { font-size: 0.6rem; }
        .wizard-step-line { width: 20px; }
        .wizard-step-num { width: 34px; height: 34px; font-size: 0.8125rem; }
    }

    /* Form Card */
    .form-card {
        background: white; border-radius: 16px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        padding: 40px; margin-bottom: 24px;
    }
    .form-card h2 {
        font-size: 1.25rem; font-weight: 700; color: #0D3B6E;
        margin-bottom: 24px; padding-bottom: 12px;
        border-bottom: 2px solid #E2E8F0;
        display: flex; align-items: center; gap: 10px;
    }
    .form-card h2 .step-num {
        background: #F59E0B; color: white; width: 32px; height: 32px;
        border-radius: 50%; display: flex; align-items: center; justify-content: center;
        font-size: 0.875rem; font-weight: 700; flex-shrink: 0;
    }

    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    @media (max-width: 600px) { .form-row { grid-template-columns: 1fr; } }

    .form-group { margin-bottom: 20px; }
    .form-group label {
        display: block; font-size: 0.875rem; font-weight: 600;
        color: #334155; margin-bottom: 6px;
    }
    .form-group label .required { color: #DC2626; }
    .form-group input, .form-group textarea, .form-group select {
        width: 100%; padding: 12px 16px; border: 2px solid #E2E8F0;
        border-radius: 10px; font-size: 0.9375rem; font-family: inherit;
        transition: all 0.2s; background: #F8FAFC;
    }
    .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
        outline: none; border-color: #F59E0B;
        box-shadow: 0 0 0 3px rgba(245,158,11,0.15); background: white;
    }
    .form-group textarea { resize: vertical; min-height: 100px; }
    .form-group .help-text { font-size: 0.8125rem; color: #64748B; margin-top: 4px; }

    .map-container {
        width: 100%; height: 300px; border-radius: 12px;
        border: 2px solid #E2E8F0; overflow: hidden; margin-bottom: 8px;
    }
    .location-coords {
        display: flex; gap: 16px; font-size: 0.8125rem; color: #64748B;
        flex-wrap: wrap;
    }
    .location-coords span { background: #F1F5F9; padding: 4px 10px; border-radius: 6px; }

    .logo-upload {
        border: 2px dashed #CBD5E1; border-radius: 12px;
        padding: 30px; text-align: center; cursor: pointer;
        transition: all 0.2s; background: #F8FAFC;
    }
    .logo-upload:hover { border-color: #F59E0B; background: #FFFBEB; }
    .logo-upload input { display: none; }
    .logo-upload .upload-icon { font-size: 2rem; margin-bottom: 8px; }
    .logo-upload .upload-text { font-size: 0.875rem; color: #64748B; }
    .logo-upload .upload-text strong { color: #F59E0B; }
    .logo-preview { max-width: 120px; max-height: 120px; border-radius: 8px; margin-top: 12px; display: none; }

    .password-strength {
        height: 4px; border-radius: 2px; margin-top: 6px;
        background: #E2E8F0; overflow: hidden;
    }
    .password-strength .bar { height: 100%; border-radius: 2px; transition: all 0.3s; width: 0; }
    .password-strength .bar.weak { width: 33%; background: #DC2626; }
    .password-strength .bar.medium { width: 66%; background: #F59E0B; }
    .password-strength .bar.strong { width: 100%; background: #16A34A; }

    /* Wizard buttons */
    .wizard-buttons {
        display: flex; gap: 12px; margin-top: 8px;
    }
    .btn-next, .btn-submit {
        flex: 1; padding: 16px; border: none; border-radius: 12px;
        font-size: 1.0625rem; font-weight: 700; cursor: pointer;
        background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
        color: white; transition: all 0.3s;
        display: flex; align-items: center; justify-content: center; gap: 8px;
    }
    .btn-next:hover, .btn-submit:hover {
        transform: translateY(-2px); box-shadow: 0 8px 25px rgba(245,158,11,0.4);
    }
    .btn-next:disabled, .btn-submit:disabled {
        opacity: 0.6; cursor: not-allowed; transform: none; box-shadow: none;
    }
    .btn-back {
        padding: 16px 28px; border: 2px solid #CBD5E1; border-radius: 12px;
        font-size: 1.0625rem; font-weight: 600; cursor: pointer;
        background: white; color: #64748B; transition: all 0.3s;
        display: flex; align-items: center; justify-content: center; gap: 8px;
    }
    .btn-back:hover {
        border-color: #94A3B8; color: #334155; background: #F8FAFC;
    }

    /* Review step */
    .review-section {
        background: #F8FAFC; border-radius: 12px;
        padding: 20px 24px; margin-bottom: 16px;
        border: 1px solid #E2E8F0;
    }
    .review-section-header {
        display: flex; align-items: center; justify-content: space-between;
        margin-bottom: 14px;
    }
    .review-section-header h3 {
        font-size: 0.9375rem; font-weight: 700; color: #0D3B6E; margin: 0;
        display: flex; align-items: center; gap: 8px;
    }
    .review-section-header h3 .rs-icon {
        width: 26px; height: 26px; border-radius: 6px;
        background: #F59E0B; color: white;
        display: flex; align-items: center; justify-content: center;
        font-size: 0.75rem; font-weight: 700;
    }
    .review-edit-btn {
        font-size: 0.8125rem; font-weight: 600; color: #F59E0B;
        cursor: pointer; background: none; border: none;
        text-decoration: underline; padding: 0;
        transition: color 0.2s;
    }
    .review-edit-btn:hover { color: #D97706; }
    .review-row {
        display: grid; grid-template-columns: 140px 1fr; gap: 8px;
        margin-bottom: 8px; font-size: 0.875rem;
    }
    .review-row .review-label { color: #64748B; font-weight: 500; }
    .review-row .review-value { color: #1E293B; font-weight: 600; word-break: break-word; }
    .review-logo-preview {
        max-width: 80px; max-height: 80px; border-radius: 8px; margin-top: 4px;
        border: 1px solid #E2E8F0;
    }
    @media (max-width: 500px) {
        .review-row { grid-template-columns: 1fr; gap: 2px; }
    }

    /* Error list */
    .error-list {
        background: #FEF2F2; border: 1px solid #FECACA; border-radius: 12px;
        padding: 16px 20px; margin-bottom: 24px; border-left: 4px solid #DC2626;
    }
    .error-list h3 { font-size: 0.9375rem; color: #991B1B; margin-bottom: 8px; }
    .error-list ul { margin: 0; padding-left: 20px; }
    .error-list li { font-size: 0.875rem; color: #7F1D1D; margin-bottom: 4px; }

    /* Success card */
    .success-card {
        background: white; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        padding: 60px 40px; text-align: center;
    }
    .success-card .success-icon { font-size: 4rem; margin-bottom: 20px; }
    .success-card h2 { font-size: 1.5rem; color: #16A34A; margin-bottom: 12px; }
    .success-card p { color: #64748B; margin-bottom: 24px; max-width: 500px; margin-left: auto; margin-right: auto; }
    .btn-login-link {
        display: inline-block; padding: 14px 40px; background: linear-gradient(135deg, #1565C0, #0D3B6E);
        color: white; text-decoration: none; border-radius: 10px; font-weight: 600;
        transition: all 0.3s;
    }
    .btn-login-link:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(21,101,192,0.3); }

    .login-link-bar {
        text-align: center; margin-top: 24px; font-size: 0.9375rem; color: #64748B;
    }
    .login-link-bar a { color: #1565C0; font-weight: 600; text-decoration: none; }
    .login-link-bar a:hover { text-decoration: underline; }

    .benefits-bar {
        display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px; margin-bottom: 32px;
    }
    .benefit-item {
        background: white; border-radius: 12px; padding: 20px; text-align: center;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    }
    .benefit-item .b-icon { font-size: 1.5rem; margin-bottom: 8px; }
    .benefit-item .b-title { font-weight: 700; font-size: 0.875rem; color: #0D3B6E; }
    .benefit-item .b-desc { font-size: 0.8125rem; color: #64748B; margin-top: 4px; }

    /* Step transition */
    .wizard-step-content {
        display: none;
        animation: fadeInStep 0.3s ease;
    }
    .wizard-step-content.active {
        display: block;
    }
    @keyframes fadeInStep {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Validation error highlight */
    .field-error {
        border-color: #DC2626 !important;
        box-shadow: 0 0 0 3px rgba(220,38,38,0.1) !important;
    }
    .field-error-msg {
        color: #DC2626; font-size: 0.8125rem; margin-top: 4px; font-weight: 500;
    }
</style>

<div class="page-header">
    <a href="/solarglobal/index.php" class="back-link">&larr; Back to <?= htmlspecialchars(get_system_setting('site_name', 'SolarGlobal')) ?></a>
    <h1>Open Your Solar Store</h1>
    <p>Join the world's growing solar marketplace. List your products, reach more customers, and grow your solar business.</p>
</div>

<div class="register-container">
    <?php if ($success): ?>
        <div class="success-card">
            <div class="success-icon">&#10003;</div>
            <h2>Registration Successful!</h2>
            <p>Your account has been created! <strong>Subscribe now</strong> to activate your store and start appearing in customer recommendations.</p>
            <p style="font-size: 0.875rem; color: #DC2626; font-weight: 500;">&#9888; Your store will NOT be visible to customers until you subscribe.</p>
            <a href="login.php" class="btn-login-link" style="margin-bottom: 12px;">Login to Your Dashboard</a>
            <p style="font-size: 0.8125rem; color: #64748B; margin-top: 12px;">After login, go to <strong>Subscription</strong> to activate your store.</p>
        </div>
    <?php else: ?>
        <div class="benefits-bar">
            <div class="benefit-item">
                <div class="b-icon">&#127760;</div>
                <div class="b-title">Global Reach</div>
                <div class="b-desc">Reach solar customers worldwide</div>
            </div>
            <div class="benefit-item">
                <div class="b-icon">&#128176;</div>
                <div class="b-title">Only $<?= get_system_setting('dealer_monthly_fee', '1.00') ?>/month</div>
                <div class="b-desc">Affordable store subscription</div>
            </div>
            <div class="benefit-item">
                <div class="b-icon">&#128200;</div>
                <div class="b-title">Smart Matching</div>
                <div class="b-desc">AI matches your products to buyers</div>
            </div>
            <div class="benefit-item">
                <div class="b-icon">&#128205;</div>
                <div class="b-title">Local Discovery</div>
                <div class="b-desc">Customers find you by location</div>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="error-list">
                <h3>Please fix the following errors:</h3>
                <ul>
                    <?php foreach ($errors as $err): ?>
                        <li><?= $err ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Wizard Step Indicator -->
        <div class="wizard-steps" id="wizardSteps">
            <div class="wizard-step-circle">
                <div class="wizard-step-num active" data-step-num="1">1</div>
                <div class="wizard-step-label active" data-step-label="1">Business</div>
            </div>
            <div class="wizard-step-line" data-step-line="1"></div>
            <div class="wizard-step-circle">
                <div class="wizard-step-num" data-step-num="2">2</div>
                <div class="wizard-step-label" data-step-label="2">Location</div>
            </div>
            <div class="wizard-step-line" data-step-line="2"></div>
            <div class="wizard-step-circle">
                <div class="wizard-step-num" data-step-num="3">3</div>
                <div class="wizard-step-label" data-step-label="3">Account</div>
            </div>
            <div class="wizard-step-line" data-step-line="3"></div>
            <div class="wizard-step-circle">
                <div class="wizard-step-num" data-step-num="4">4</div>
                <div class="wizard-step-label" data-step-label="4">Review</div>
            </div>
        </div>

        <form method="POST" action="" enctype="multipart/form-data" id="registerForm">
            <?= csrf_field() ?>
            <?= render_honeypot_field('website_url') ?>

            <!-- Step 1: Business Information -->
            <div class="wizard-step-content active" data-step="1">
                <div class="form-card">
                    <h2><span class="step-num">1</span> Business Information</h2>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Business / Store Name <span class="required">*</span></label>
                            <input type="text" name="business_name" id="field_business_name" value="<?= sanitize($form_data['business_name']) ?>" maxlength="200" placeholder="e.g., SunPower Solar Store">
                        </div>
                        <div class="form-group">
                            <label>Owner Full Name <span class="required">*</span></label>
                            <input type="text" name="owner_name" id="field_owner_name" value="<?= sanitize($form_data['owner_name']) ?>" maxlength="150" placeholder="e.g., John Smith">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="tel" name="phone" id="field_phone" value="<?= sanitize($form_data['phone']) ?>" maxlength="30" placeholder="e.g., +1 555 123 4567">
                        </div>
                        <div class="form-group">
                            <label>Business Registration Number</label>
                            <input type="text" name="business_reg_number" id="field_business_reg_number" value="<?= sanitize($form_data['business_reg_number']) ?>" maxlength="100" placeholder="Optional">
                            <div class="help-text">Tax ID, business license, or registration number</div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Store Description</label>
                        <textarea name="store_description" id="field_store_description" maxlength="500" placeholder="Tell customers about your solar business, products, and services..."><?= sanitize($form_data['store_description']) ?></textarea>
                        <div class="help-text">Max 500 characters. This appears on your public store page.</div>
                    </div>
                    <div class="form-group">
                        <label>Store Logo</label>
                        <div class="logo-upload" onclick="document.getElementById('logoInput').click()">
                            <input type="file" name="store_logo" id="logoInput" accept="image/jpeg,image/png,image/webp">
                            <div class="upload-icon">&#128247;</div>
                            <div class="upload-text"><strong>Click to upload</strong> your store logo<br>JPG, PNG, WebP - Max 2MB</div>
                            <img id="logoPreview" class="logo-preview" alt="Logo preview">
                        </div>
                    </div>
                </div>
                <div class="wizard-buttons">
                    <button type="button" class="btn-next" onclick="goToStep(2)">Next: Store Location <span>&rarr;</span></button>
                </div>
            </div>

            <!-- Step 2: Store Location -->
            <div class="wizard-step-content" data-step="2">
                <div class="form-card">
                    <h2><span class="step-num">2</span> Store Location</h2>
                    <div class="form-group">
                        <label>Store Address <span class="required">*</span></label>
                        <input type="text" name="address" id="addressInput" value="<?= sanitize($form_data['address']) ?>" placeholder="Search or type your store address...">
                    </div>
                    <div class="form-group">
                        <label>Pin Your Store on the Map <span class="required">*</span></label>
                        <div class="map-container" id="storeMap"></div>
                        <div class="location-coords">
                            <span id="latDisplay">Lat: --</span>
                            <span id="lngDisplay">Lng: --</span>
                            <span id="cityDisplay">City: --</span>
                        </div>
                        <input type="hidden" name="latitude" id="latInput" value="<?= sanitize($form_data['latitude']) ?>">
                        <input type="hidden" name="longitude" id="lngInput" value="<?= sanitize($form_data['longitude']) ?>">
                        <input type="hidden" name="city" id="cityInput" value="<?= sanitize($form_data['city']) ?>">
                        <input type="hidden" name="country_code" id="countryInput" value="<?= sanitize($form_data['country_code']) ?>">
                        <div class="help-text">Click on the map or drag the marker to set your exact store location.</div>
                    </div>
                </div>
                <div class="wizard-buttons">
                    <button type="button" class="btn-back" onclick="goToStep(1)"><span>&larr;</span> Back</button>
                    <button type="button" class="btn-next" onclick="goToStep(3)">Next: Account Details <span>&rarr;</span></button>
                </div>
            </div>

            <!-- Step 3: Account Details -->
            <div class="wizard-step-content" data-step="3">
                <div class="form-card">
                    <h2><span class="step-num">3</span> Account Details</h2>
                    <div class="form-group">
                        <label>Email Address <span class="required">*</span></label>
                        <input type="email" name="email" id="field_email" value="<?= sanitize($form_data['email']) ?>" maxlength="255" placeholder="your@email.com">
                        <div class="help-text">This will be your login email and used for notifications.</div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Password <span class="required">*</span></label>
                            <input type="password" name="password" id="passwordInput" minlength="8" placeholder="Min 8 chars, 1 uppercase, 1 number">
                            <div class="password-strength"><div class="bar" id="pwBar"></div></div>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password <span class="required">*</span></label>
                            <input type="password" name="password_confirm" id="field_password_confirm" minlength="8" placeholder="Re-enter password">
                        </div>
                    </div>
                </div>
                <div class="wizard-buttons">
                    <button type="button" class="btn-back" onclick="goToStep(2)"><span>&larr;</span> Back</button>
                    <button type="button" class="btn-next" onclick="goToStep(4)">Next: Review <span>&rarr;</span></button>
                </div>
            </div>

            <!-- Step 4: Review & Submit -->
            <div class="wizard-step-content" data-step="4">
                <div class="form-card">
                    <h2><span class="step-num">4</span> Review &amp; Submit</h2>
                    <p style="color:#64748B; font-size:0.875rem; margin-bottom:20px;">Please review your information before creating your store.</p>

                    <!-- Business Info Review -->
                    <div class="review-section">
                        <div class="review-section-header">
                            <h3><span class="rs-icon">1</span> Business Information</h3>
                            <button type="button" class="review-edit-btn" onclick="goToStep(1)">Edit</button>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Business Name</span>
                            <span class="review-value" id="rev_business_name">--</span>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Owner Name</span>
                            <span class="review-value" id="rev_owner_name">--</span>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Phone</span>
                            <span class="review-value" id="rev_phone">--</span>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Reg Number</span>
                            <span class="review-value" id="rev_reg_number">--</span>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Description</span>
                            <span class="review-value" id="rev_description">--</span>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Logo</span>
                            <span class="review-value" id="rev_logo_container"><span id="rev_logo_text">No logo uploaded</span><img id="rev_logo_img" class="review-logo-preview" style="display:none" alt="Logo"></span>
                        </div>
                    </div>

                    <!-- Location Review -->
                    <div class="review-section">
                        <div class="review-section-header">
                            <h3><span class="rs-icon">2</span> Store Location</h3>
                            <button type="button" class="review-edit-btn" onclick="goToStep(2)">Edit</button>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Address</span>
                            <span class="review-value" id="rev_address">--</span>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Coordinates</span>
                            <span class="review-value" id="rev_coords">--</span>
                        </div>
                        <div class="review-row">
                            <span class="review-label">City</span>
                            <span class="review-value" id="rev_city">--</span>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Country</span>
                            <span class="review-value" id="rev_country">--</span>
                        </div>
                    </div>

                    <!-- Account Review -->
                    <div class="review-section">
                        <div class="review-section-header">
                            <h3><span class="rs-icon">3</span> Account Details</h3>
                            <button type="button" class="review-edit-btn" onclick="goToStep(3)">Edit</button>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Email</span>
                            <span class="review-value" id="rev_email">--</span>
                        </div>
                        <div class="review-row">
                            <span class="review-label">Password</span>
                            <span class="review-value" id="rev_password">--</span>
                        </div>
                    </div>
                </div>
                <div class="wizard-buttons">
                    <button type="button" class="btn-back" onclick="goToStep(3)"><span>&larr;</span> Back</button>
                    <button type="submit" class="btn-submit" id="submitBtn">
                        <span>&#9889;</span> Create My Solar Store
                    </button>
                </div>
            </div>
        </form>

        <div class="login-link-bar">
            Already have a store? <a href="login.php">Login to your dashboard</a>
        </div>
    <?php endif; ?>
</div>

<script>
(function() {
    // ============ Wizard Logic ============
    var currentStep = 1;
    var totalSteps = 4;
    var mapInitialized = false;

    window.goToStep = function(step) {
        // Validate current step before advancing
        if (step > currentStep) {
            if (!validateStep(currentStep)) return;
        }

        currentStep = step;

        // Show/hide step content
        document.querySelectorAll('.wizard-step-content').forEach(function(el) {
            el.classList.remove('active');
        });
        var target = document.querySelector('.wizard-step-content[data-step="' + step + '"]');
        if (target) target.classList.add('active');

        // Update step indicator
        for (var i = 1; i <= totalSteps; i++) {
            var numEl = document.querySelector('[data-step-num="' + i + '"]');
            var labelEl = document.querySelector('[data-step-label="' + i + '"]');
            if (!numEl || !labelEl) continue;

            numEl.classList.remove('active', 'completed');
            labelEl.classList.remove('active', 'completed');

            if (i < step) {
                numEl.classList.add('completed');
                numEl.innerHTML = '&#10003;';
                labelEl.classList.add('completed');
            } else if (i === step) {
                numEl.classList.add('active');
                numEl.textContent = i;
                labelEl.classList.add('active');
            } else {
                numEl.textContent = i;
            }
        }

        // Update step lines
        for (var j = 1; j < totalSteps; j++) {
            var lineEl = document.querySelector('[data-step-line="' + j + '"]');
            if (lineEl) {
                lineEl.classList.toggle('completed', j < step);
            }
        }

        // Initialize map when entering step 2
        if (step === 2 && !mapInitialized) {
            initMap();
            mapInitialized = true;
        }

        // Trigger map resize when entering step 2
        if (step === 2 && window._storeMap) {
            setTimeout(function() {
                if (window._storeMapType === 'google' && typeof google !== 'undefined') {
                    google.maps.event.trigger(window._storeMap, 'resize');
                } else if (window._storeMapType === 'leaflet') {
                    window._storeMap.invalidateSize();
                }
            }, 100);
        }

        // Populate review when entering step 4
        if (step === 4) {
            populateReview();
        }

        // Scroll to top of wizard
        var header = document.querySelector('.wizard-steps');
        if (header) header.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };

    function validateStep(step) {
        clearFieldErrors();

        if (step === 1) {
            var bName = document.getElementById('field_business_name');
            var oName = document.getElementById('field_owner_name');
            var valid = true;
            if (!bName.value.trim()) {
                showFieldError(bName, 'Business name is required.');
                valid = false;
            }
            if (!oName.value.trim()) {
                showFieldError(oName, 'Owner name is required.');
                valid = false;
            }
            return valid;
        }

        if (step === 2) {
            var addr = document.getElementById('addressInput');
            var lat = document.getElementById('latInput');
            var lng = document.getElementById('lngInput');
            var valid = true;
            if (!addr.value.trim()) {
                showFieldError(addr, 'Store address is required.');
                valid = false;
            }
            if (!lat.value || !lng.value) {
                showFieldError(addr, 'Please select your store location on the map.');
                valid = false;
            }
            return valid;
        }

        if (step === 3) {
            var email = document.getElementById('field_email');
            var pw = document.getElementById('passwordInput');
            var pwc = document.getElementById('field_password_confirm');
            var valid = true;

            if (!email.value.trim()) {
                showFieldError(email, 'Email is required.');
                valid = false;
            } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
                showFieldError(email, 'Please enter a valid email address.');
                valid = false;
            }

            if (!pw.value) {
                showFieldError(pw, 'Password is required.');
                valid = false;
            } else if (pw.value.length < 8) {
                showFieldError(pw, 'Password must be at least 8 characters.');
                valid = false;
            } else if (!/[A-Z]/.test(pw.value)) {
                showFieldError(pw, 'Password must contain at least one uppercase letter.');
                valid = false;
            } else if (!/[0-9]/.test(pw.value)) {
                showFieldError(pw, 'Password must contain at least one number.');
                valid = false;
            }

            if (pw.value && pw.value !== pwc.value) {
                showFieldError(pwc, 'Passwords do not match.');
                valid = false;
            }

            return valid;
        }

        return true;
    }

    function showFieldError(input, msg) {
        input.classList.add('field-error');
        var errDiv = document.createElement('div');
        errDiv.className = 'field-error-msg';
        errDiv.textContent = msg;
        input.parentNode.appendChild(errDiv);
    }

    function clearFieldErrors() {
        document.querySelectorAll('.field-error').forEach(function(el) {
            el.classList.remove('field-error');
        });
        document.querySelectorAll('.field-error-msg').forEach(function(el) {
            el.remove();
        });
    }

    function populateReview() {
        var val = function(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; };
        var setText = function(id, text) { var el = document.getElementById(id); if (el) el.textContent = text || '--'; };

        setText('rev_business_name', val('field_business_name'));
        setText('rev_owner_name', val('field_owner_name'));
        setText('rev_phone', val('field_phone') || 'Not provided');
        setText('rev_reg_number', val('field_business_reg_number') || 'Not provided');
        setText('rev_description', val('field_store_description') || 'Not provided');
        setText('rev_address', val('addressInput'));

        var lat = val('latInput');
        var lng = val('lngInput');
        setText('rev_coords', (lat && lng) ? lat + ', ' + lng : 'Not set');
        setText('rev_city', val('cityInput') || 'Not detected');
        setText('rev_country', val('countryInput') || 'Not detected');
        setText('rev_email', val('field_email'));

        var pw = val('passwordInput');
        setText('rev_password', pw ? '•'.repeat(Math.min(pw.length, 12)) : '--');

        // Logo preview
        var logoPreview = document.getElementById('logoPreview');
        var revImg = document.getElementById('rev_logo_img');
        var revText = document.getElementById('rev_logo_text');
        if (logoPreview && logoPreview.src && logoPreview.style.display !== 'none') {
            revImg.src = logoPreview.src;
            revImg.style.display = 'block';
            revText.style.display = 'none';
        } else {
            revImg.style.display = 'none';
            revText.style.display = 'inline';
            revText.textContent = 'No logo uploaded';
        }
    }

    // ============ Logo Preview ============
    var logoInput = document.getElementById('logoInput');
    if (logoInput) {
        logoInput.addEventListener('change', function(e) {
            var file = e.target.files[0];
            if (file) {
                var reader = new FileReader();
                reader.onload = function(ev) {
                    var preview = document.getElementById('logoPreview');
                    preview.src = ev.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // ============ Password Strength ============
    var pwInput = document.getElementById('passwordInput');
    if (pwInput) {
        pwInput.addEventListener('input', function(e) {
            var pw = e.target.value;
            var bar = document.getElementById('pwBar');
            var score = 0;
            if (pw.length >= 8) score++;
            if (/[A-Z]/.test(pw)) score++;
            if (/[0-9]/.test(pw)) score++;
            if (/[^A-Za-z0-9]/.test(pw)) score++;

            bar.className = 'bar';
            if (score <= 1) bar.classList.add('weak');
            else if (score <= 2) bar.classList.add('medium');
            else bar.classList.add('strong');
        });
    }

    // ============ Map (Google Maps with Leaflet fallback) ============
    function initMap() {
        var mapEl = document.getElementById('storeMap');
        if (!mapEl) return;

        var defaultLat = parseFloat(document.getElementById('latInput').value) || 25.0;
        var defaultLng = parseFloat(document.getElementById('lngInput').value) || 67.0;
        var hasExistingCoords = !!document.getElementById('latInput').value;

        function updateDisplays(lat, lng, city) {
            document.getElementById('latInput').value = lat.toFixed(7);
            document.getElementById('lngInput').value = lng.toFixed(7);
            document.getElementById('latDisplay').textContent = 'Lat: ' + lat.toFixed(5);
            document.getElementById('lngDisplay').textContent = 'Lng: ' + lng.toFixed(5);
            if (city !== undefined) {
                document.getElementById('cityInput').value = city;
                document.getElementById('cityDisplay').textContent = 'City: ' + (city || 'Unknown');
            }
        }

        if (useGoogleMaps && typeof google !== 'undefined') {
            // ─── Google Maps Path ───
            var map = new google.maps.Map(mapEl, {
                center: { lat: defaultLat, lng: defaultLng },
                zoom: hasExistingCoords ? 14 : 3,
                mapTypeControl: false, streetViewControl: false, fullscreenControl: false,
            });
            window._storeMap = map;
            window._storeMapType = 'google';

            var marker = new google.maps.Marker({
                position: { lat: defaultLat, lng: defaultLng },
                map: map, draggable: true, title: 'Your Store Location',
            });
            if (!hasExistingCoords) marker.setVisible(false);

            var geocoder = new google.maps.Geocoder();

            function updateLocation(lat, lng) {
                marker.setPosition({ lat: lat, lng: lng }); marker.setVisible(true);
                updateDisplays(lat, lng);
                geocoder.geocode({ location: { lat: lat, lng: lng } }, function(results, status) {
                    if (status === 'OK' && results[0]) {
                        var city = '', country = '';
                        results[0].address_components.forEach(function(c) {
                            if (c.types.includes('locality')) city = c.long_name;
                            if (c.types.includes('country')) country = c.short_name;
                        });
                        document.getElementById('cityInput').value = city;
                        document.getElementById('countryInput').value = country;
                        document.getElementById('cityDisplay').textContent = 'City: ' + (city || 'Unknown');
                    }
                });
            }

            map.addListener('click', function(e) { updateLocation(e.latLng.lat(), e.latLng.lng()); });
            marker.addListener('dragend', function(e) { updateLocation(e.latLng.lat(), e.latLng.lng()); });

            var addressInput = document.getElementById('addressInput');
            var autocomplete = new google.maps.places.Autocomplete(addressInput, { types: ['establishment', 'geocode'] });
            autocomplete.bindTo('bounds', map);
            autocomplete.addListener('place_changed', function() {
                var place = autocomplete.getPlace();
                if (place.geometry && place.geometry.location) {
                    var lat = place.geometry.location.lat(), lng = place.geometry.location.lng();
                    map.setCenter({ lat: lat, lng: lng }); map.setZoom(16);
                    updateLocation(lat, lng);
                    if (place.formatted_address) addressInput.value = place.formatted_address;
                }
            });

            if (!hasExistingCoords) {
                fetch('https://ip-api.com/json/?fields=status,country,countryCode,city,lat,lon')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.status === 'success') {
                            map.setCenter({ lat: data.lat, lng: data.lon }); map.setZoom(6);
                            if (!document.getElementById('countryInput').value) document.getElementById('countryInput').value = data.countryCode || '';
                            if (!document.getElementById('cityInput').value) {
                                document.getElementById('cityInput').value = data.city || '';
                                document.getElementById('cityDisplay').textContent = 'City: ' + (data.city || '--');
                            }
                        }
                    }).catch(function() {});
            }
        } else if (typeof L !== 'undefined') {
            // ─── Leaflet Fallback Path ───
            var map = L.map(mapEl, {
                center: [defaultLat, defaultLng],
                zoom: hasExistingCoords ? 14 : 3
            });
            window._storeMap = map;
            window._storeMapType = 'leaflet';

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors', maxZoom: 19
            }).addTo(map);

            var marker = L.marker([defaultLat, defaultLng], { draggable: true });
            if (hasExistingCoords) marker.addTo(map);

            function reverseGeocode(lat, lng) {
                fetch('https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lat + '&lon=' + lng + '&zoom=10&addressdetails=1')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        var city = '', country = '';
                        if (data.address) {
                            city = data.address.city || data.address.town || data.address.village || '';
                            country = (data.address.country_code || '').toUpperCase();
                        }
                        document.getElementById('cityInput').value = city;
                        document.getElementById('countryInput').value = country;
                        document.getElementById('cityDisplay').textContent = 'City: ' + (city || 'Unknown');
                    }).catch(function() {});
            }

            function updateLocation(lat, lng) {
                marker.setLatLng([lat, lng]);
                if (!map.hasLayer(marker)) marker.addTo(map);
                updateDisplays(lat, lng);
                reverseGeocode(lat, lng);
            }

            map.on('click', function(e) { updateLocation(e.latlng.lat, e.latlng.lng); });
            marker.on('dragend', function(e) { var pos = e.target.getLatLng(); updateLocation(pos.lat, pos.lng); });

            // Address search via Nominatim
            var addressInput = document.getElementById('addressInput');
            addressInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    var query = addressInput.value.trim();
                    if (!query) return;
                    fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(query) + '&limit=1')
                        .then(function(r) { return r.json(); })
                        .then(function(results) {
                            if (results.length > 0) {
                                var lt = parseFloat(results[0].lat), ln = parseFloat(results[0].lon);
                                map.setView([lt, ln], 16);
                                updateLocation(lt, ln);
                                if (results[0].display_name) addressInput.value = results[0].display_name;
                            }
                        });
                }
            });

            // IP-based country detection
            if (!hasExistingCoords) {
                fetch('https://ip-api.com/json/?fields=status,country,countryCode,city,lat,lon')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.status === 'success') {
                            map.setView([data.lat, data.lon], 6);
                            if (!document.getElementById('countryInput').value) document.getElementById('countryInput').value = data.countryCode || '';
                            if (!document.getElementById('cityInput').value) {
                                document.getElementById('cityInput').value = data.city || '';
                                document.getElementById('cityDisplay').textContent = 'City: ' + (data.city || '--');
                            }
                        }
                    }).catch(function() {});
            }

            setTimeout(function() { map.invalidateSize(); }, 200);
        }
    }

    // ============ Form Submit Protection ============
    var form = document.getElementById('registerForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            var btn = document.getElementById('submitBtn');
            btn.disabled = true;
            btn.innerHTML = '<span>&#8987;</span> Creating your store...';
        });
    }
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
