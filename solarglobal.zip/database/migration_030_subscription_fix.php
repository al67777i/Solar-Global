<?php
/**
 * Migration 030 — Subscription Schema Fixes
 *
 * Fixes:
 * 1. ENUM mismatch: migration had ('trial','active','expired'), code uses ('none','canceled','past_due')
 * 2. Missing columns referenced by registration forms
 * 3. Add grace_period_ends_at for subscription grace period
 * 4. Add store_description (dealer register writes to it)
 * 5. Add missing installer columns (license_number, team_size, price_per_kw, specializations, region)
 */

require_once __DIR__ . '/../includes/db.php';
$db = getDB();

$results = [];

function run($db, $label, $sql, &$results) {
    try {
        $db->exec($sql);
        $results[] = "✅ $label";
    } catch (PDOException $e) {
        $msg = $e->getMessage();
        // Ignore "duplicate column" and "already exists" errors
        if (strpos($msg, 'Duplicate column') !== false || strpos($msg, 'already exists') !== false) {
            $results[] = "⏭️ $label (already done)";
        } else {
            $results[] = "❌ $label: $msg";
        }
    }
}

// ════════════════════════════════════════════════════════════════
// 1. FIX DEALERS TABLE
// ════════════════════════════════════════════════════════════════

// Fix subscription_status ENUM to cover all values used by code
run($db, 'dealers: fix subscription_status ENUM',
    "ALTER TABLE dealers MODIFY COLUMN subscription_status
     ENUM('none','trial','active','past_due','canceled','expired') DEFAULT 'none'",
    $results);

// Add grace_period_ends_at
run($db, 'dealers: add grace_period_ends_at',
    "ALTER TABLE dealers ADD COLUMN grace_period_ends_at TIMESTAMP NULL AFTER subscription_expires_at",
    $results);

// Add store_description (register.php writes this)
run($db, 'dealers: add store_description',
    "ALTER TABLE dealers ADD COLUMN store_description TEXT NULL AFTER description",
    $results);

// Add business_reg_number (register.php writes this)
run($db, 'dealers: add business_reg_number',
    "ALTER TABLE dealers ADD COLUMN business_reg_number VARCHAR(100) NULL AFTER phone",
    $results);

// Add email_verified (register.php writes this)
run($db, 'dealers: add email_verified',
    "ALTER TABLE dealers ADD COLUMN email_verified TINYINT(1) DEFAULT 0 AFTER is_active",
    $results);

// Add approved_by / approved_at (admin uses these)
run($db, 'dealers: add approved_by',
    "ALTER TABLE dealers ADD COLUMN approved_by INT NULL AFTER status",
    $results);
run($db, 'dealers: add approved_at',
    "ALTER TABLE dealers ADD COLUMN approved_at TIMESTAMP NULL AFTER approved_by",
    $results);

// ════════════════════════════════════════════════════════════════
// 2. FIX INSTALLERS TABLE
// ════════════════════════════════════════════════════════════════

// Fix subscription_status ENUM
run($db, 'installers: fix subscription_status ENUM',
    "ALTER TABLE installers MODIFY COLUMN subscription_status
     ENUM('none','trial','active','past_due','canceled','expired') DEFAULT 'none'",
    $results);

// Add grace_period_ends_at
run($db, 'installers: add grace_period_ends_at',
    "ALTER TABLE installers ADD COLUMN grace_period_ends_at TIMESTAMP NULL AFTER subscription_expires_at",
    $results);

// Add license_number (register.php writes this)
run($db, 'installers: add license_number',
    "ALTER TABLE installers ADD COLUMN license_number VARCHAR(100) NULL AFTER phone",
    $results);

// Add team_size (register.php writes this)
run($db, 'installers: add team_size',
    "ALTER TABLE installers ADD COLUMN team_size INT DEFAULT 1 AFTER experience_years",
    $results);

// Add price_per_kw (register.php writes this)
run($db, 'installers: add price_per_kw',
    "ALTER TABLE installers ADD COLUMN price_per_kw DECIMAL(10,2) NULL AFTER team_size",
    $results);

// Add specializations JSON (register.php writes this)
run($db, 'installers: add specializations',
    "ALTER TABLE installers ADD COLUMN specializations TEXT NULL COMMENT 'JSON array' AFTER price_per_kw",
    $results);

// Add region (register.php writes this)
run($db, 'installers: add region',
    "ALTER TABLE installers ADD COLUMN region VARCHAR(100) NULL AFTER city",
    $results);

// Add about (register.php writes 'about' field, maps to description, but let's add alias)
run($db, 'installers: add about',
    "ALTER TABLE installers ADD COLUMN about TEXT NULL AFTER description",
    $results);

// Add approved_by / approved_at
run($db, 'installers: add approved_by',
    "ALTER TABLE installers ADD COLUMN approved_by INT NULL AFTER status",
    $results);
run($db, 'installers: add approved_at',
    "ALTER TABLE installers ADD COLUMN approved_at TIMESTAMP NULL AFTER approved_by",
    $results);

// Add avg_rating alias (some code uses avg_rating, some uses rating_avg)
run($db, 'installers: add avg_rating alias',
    "ALTER TABLE installers ADD COLUMN avg_rating DECIMAL(3,2) DEFAULT 0 AFTER rating_avg",
    $results);

// Add is_featured
run($db, 'installers: add is_featured',
    "ALTER TABLE installers ADD COLUMN is_featured TINYINT(1) DEFAULT 0 AFTER is_active",
    $results);

// ════════════════════════════════════════════════════════════════
// 3. BACKFILL DEFAULT VALUES
// ════════════════════════════════════════════════════════════════

// Set subscription_status to 'none' where it might be empty or invalid
try {
    $db->exec("UPDATE dealers SET subscription_status = 'none' WHERE subscription_status IS NULL OR subscription_status = ''");
    $results[] = "✅ dealers: backfill subscription_status";
} catch (Exception $e) {
    $results[] = "⏭️ dealers: backfill subscription_status (skipped: {$e->getMessage()})";
}

try {
    $db->exec("UPDATE installers SET subscription_status = 'none' WHERE subscription_status IS NULL OR subscription_status = ''");
    $results[] = "✅ installers: backfill subscription_status";
} catch (Exception $e) {
    $results[] = "⏭️ installers: backfill subscription_status (skipped: {$e->getMessage()})";
}

// Sync avg_rating from rating_avg where avg_rating is 0
try {
    $db->exec("UPDATE dealers SET avg_rating = rating_avg WHERE avg_rating = 0 AND rating_avg > 0");
    $results[] = "✅ dealers: sync avg_rating from rating_avg";
} catch (Exception $e) {
    $results[] = "⏭️ dealers: sync avg_rating (skipped)";
}

try {
    $db->exec("UPDATE installers SET avg_rating = rating_avg WHERE avg_rating = 0 AND rating_avg > 0");
    $results[] = "✅ installers: sync avg_rating from rating_avg";
} catch (Exception $e) {
    $results[] = "⏭️ installers: sync avg_rating (skipped)";
}

// ════════════════════════════════════════════════════════════════
// 4. ADD grace_period_days TO system_settings IF NOT EXISTS
// ════════════════════════════════════════════════════════════════

$settings_defaults = [
    'subscription_grace_period_days' => '5',
    'dealer_free_trial_enabled' => '1',
    'dealer_free_trial_days' => '30',
    'installer_free_trial_enabled' => '1',
    'installer_free_trial_days' => '30',
];

foreach ($settings_defaults as $key => $val) {
    try {
        $chk = $db->prepare("SELECT COUNT(*) FROM system_settings WHERE setting_key = ?");
        $chk->execute([$key]);
        if ($chk->fetchColumn() == 0) {
            $db->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)")->execute([$key, $val]);
            $results[] = "✅ system_settings: added $key = $val";
        } else {
            $results[] = "⏭️ system_settings: $key already exists";
        }
    } catch (Exception $e) {
        $results[] = "❌ system_settings: $key: {$e->getMessage()}";
    }
}

// ════════════════════════════════════════════════════════════════
// OUTPUT
// ════════════════════════════════════════════════════════════════
echo "<!DOCTYPE html><html><head><title>Migration 030</title></head><body>";
echo "<h1>Migration 030 — Subscription Schema Fixes</h1><pre>\n";
foreach ($results as $r) echo "$r\n";

// Verify
echo "\n--- Verification ---\n";
$cols_d = $db->query("SHOW COLUMNS FROM dealers")->fetchAll(PDO::FETCH_COLUMN);
echo "Dealers columns (" . count($cols_d) . "): " . implode(', ', $cols_d) . "\n";

$cols_i = $db->query("SHOW COLUMNS FROM installers")->fetchAll(PDO::FETCH_COLUMN);
echo "Installers columns (" . count($cols_i) . "): " . implode(', ', $cols_i) . "\n";

// Show subscription_status ENUM
$enum_d = $db->query("SHOW COLUMNS FROM dealers WHERE Field = 'subscription_status'")->fetch(PDO::FETCH_ASSOC);
echo "Dealers subscription_status type: " . $enum_d['Type'] . "\n";

$enum_i = $db->query("SHOW COLUMNS FROM installers WHERE Field = 'subscription_status'")->fetch(PDO::FETCH_ASSOC);
echo "Installers subscription_status type: " . $enum_i['Type'] . "\n";

echo "</pre></body></html>";
