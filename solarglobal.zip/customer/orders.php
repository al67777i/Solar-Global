<?php
/**
 * Customer Orders - Track order status timeline
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/notification_helpers.php';
require_once __DIR__ . '/../includes/customer_auth.php';

set_security_headers();
require_customer_login();

$customer = get_customer_profile();
$db = getDB();

// Filters
$status_filter = $_GET['status'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 15;
$offset = ($page - 1) * $per_page;

// Count by status
$counts = ['all' => 0, 'pending' => 0, 'confirmed' => 0, 'ready' => 0, 'picked_up' => 0, 'cancelled' => 0];
$stmt = $db->prepare("SELECT status, COUNT(*) as cnt FROM orders WHERE customer_id = ? GROUP BY status");
$stmt->execute([$customer['id']]);
foreach ($stmt->fetchAll() as $r) {
    $counts[$r['status']] = (int)$r['cnt'];
    $counts['all'] += (int)$r['cnt'];
}

// Fetch orders
$where = "WHERE o.customer_id = ?";
$params = [$customer['id']];
if (in_array($status_filter, ['pending', 'confirmed', 'ready', 'picked_up', 'cancelled'])) {
    $where .= " AND o.status = ?";
    $params[] = $status_filter;
}

$stmt = $db->prepare("SELECT COUNT(*) FROM orders o $where");
$stmt->execute($params);
$total = $stmt->fetchColumn();
$total_pages = max(1, ceil($total / $per_page));

$sql = "SELECT o.*, d.business_name, d.phone as dealer_phone, d.address as dealer_address
        FROM orders o
        JOIN dealers d ON o.dealer_id = d.id
        $where
        ORDER BY o.created_at DESC
        LIMIT $per_page OFFSET $offset";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Load items for each order
$order_items = [];
if (!empty($orders)) {
    $order_ids = array_column($orders, 'id');
    $ph = implode(',', array_fill(0, count($order_ids), '?'));
    $stmt = $db->prepare("SELECT * FROM order_items WHERE order_id IN ($ph) ORDER BY id");
    $stmt->execute($order_ids);
    foreach ($stmt->fetchAll() as $item) {
        $order_items[$item['order_id']][] = $item;
    }
}

// Cart count for badge
$cart_count = 0;
foreach ($_SESSION['cart'] ?? [] as $dc) {
    foreach ($dc['items'] ?? [] as $ci) $cart_count += $ci['quantity'];
}


$page_title = 'My Orders';
$current_page = 'orders';
include __DIR__ . '/../includes/header.php';
?>
<style>
        .container { max-width: 900px; margin: 20px auto; padding: 0 20px; }

        .tabs {
            display: flex; gap: 4px; margin-bottom: 20px; background: white;
            border-radius: 10px; padding: 4px; box-shadow: 0 1px 4px rgba(0,0,0,0.05);
            overflow-x: auto;
        }
        .tab {
            padding: 8px 14px; text-align: center; border-radius: 8px; text-decoration: none;
            font-weight: 600; font-size: 0.75rem; color: #64748B; white-space: nowrap;
        }
        .tab.active { background: #1565C0; color: white; }
        .tab:hover:not(.active) { background: #F1F5F9; }
        .tab .cnt { font-weight: 400; opacity: 0.7; }

        /* Order cards */
        .order-card {
            background: white; border-radius: 12px; padding: 20px; margin-bottom: 14px;
            border: 2px solid #E2E8F0; transition: border-color 0.2s;
        }
        .order-card:hover { border-color: #CBD5E1; }

        .oc-header { display: flex; justify-content: space-between; align-items: start; flex-wrap: wrap; gap: 8px; margin-bottom: 14px; }
        .oc-number { font-size: 0.9375rem; font-weight: 700; color: #1E293B; }
        .oc-date { font-size: 0.75rem; color: #94A3B8; }
        .oc-dealer { font-size: 0.8125rem; color: #64748B; margin-top: 2px; }

        .status-badge {
            padding: 4px 12px; border-radius: 6px; font-size: 0.6875rem;
            font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;
        }
        .status-pending { background: #FEF3C7; color: #92400E; }
        .status-confirmed { background: #DBEAFE; color: #1E40AF; }
        .status-ready { background: #D1FAE5; color: #065F46; }
        .status-picked_up { background: #F3F4F6; color: #374151; }
        .status-cancelled { background: #FEE2E2; color: #991B1B; }

        /* Timeline */
        .timeline { display: flex; gap: 0; margin: 16px 0; overflow-x: auto; }
        .tl-step {
            flex: 1; text-align: center; position: relative; min-width: 80px;
        }
        .tl-dot {
            width: 24px; height: 24px; border-radius: 50%; margin: 0 auto 6px;
            display: flex; align-items: center; justify-content: center;
            font-size: 0.6875rem; font-weight: 700; color: white;
            background: #E2E8F0;
        }
        .tl-step.done .tl-dot { background: #059669; }
        .tl-step.active .tl-dot { background: #F59E0B; animation: pulse 1.5s infinite; }
        .tl-step.cancelled .tl-dot { background: #DC2626; }
        .tl-label { font-size: 0.625rem; color: #94A3B8; font-weight: 600; text-transform: uppercase; }
        .tl-step.done .tl-label, .tl-step.active .tl-label { color: #374151; }
        .tl-time { font-size: 0.5625rem; color: #94A3B8; margin-top: 2px; }

        .tl-step::after {
            content: ''; position: absolute; top: 12px; left: 50%; width: 100%; height: 2px;
            background: #E2E8F0; z-index: -1;
        }
        .tl-step:last-child::after { display: none; }
        .tl-step.done::after { background: #059669; }

        @keyframes pulse { 0%, 100% { box-shadow: 0 0 0 0 rgba(245,158,11,0.4); } 50% { box-shadow: 0 0 0 8px rgba(245,158,11,0); } }

        /* Items */
        .oc-items { border-top: 1px solid #F1F5F9; padding-top: 12px; }
        .oc-item { display: flex; justify-content: space-between; padding: 4px 0; font-size: 0.8125rem; }
        .oc-item-name { color: #374151; }
        .oc-item-qty { color: #94A3B8; }
        .oc-item-price { font-weight: 600; color: #1E293B; }

        .oc-total { display: flex; justify-content: space-between; margin-top: 10px; padding-top: 10px; border-top: 2px solid #E2E8F0; }
        .oc-total-label { font-weight: 600; color: #374151; }
        .oc-total-amount { font-weight: 800; font-size: 1.125rem; color: #059669; }

        .oc-actions { margin-top: 12px; display: flex; gap: 8px; }
        .btn-sm {
            padding: 6px 14px; border-radius: 6px; font-size: 0.75rem; font-weight: 600;
            text-decoration: none; cursor: pointer; border: none; font-family: inherit;
        }
        .btn-review { background: #F59E0B; color: #1E293B; }
        .btn-review:hover { background: #D97706; }
        .btn-contact { background: transparent; border: 1px solid #E2E8F0; color: #475569; }

        .empty-msg { text-align: center; padding: 60px 20px; color: #64748B; }
        .empty-msg a { color: #1565C0; text-decoration: none; font-weight: 600; }

        .pagination { display: flex; justify-content: center; gap: 6px; margin-top: 24px; }
        .pagination a {
            padding: 6px 12px; border-radius: 6px; text-decoration: none;
            font-size: 0.8125rem; color: #64748B; background: white; border: 1px solid #E2E8F0;
        }
        .pagination a.active { background: #1565C0; color: white; border-color: #1565C0; }

        .deadline-info {
            display: flex; align-items: center; gap: 6px;
            font-size: 0.8125rem; font-weight: 600; padding: 6px 12px;
            border-radius: 6px; margin-top: 8px; width: fit-content;
            background: #EFF6FF; color: #1E40AF;
        }
        .deadline-info.urgent { background: #FEF3C7; color: #92400E; }
        .deadline-info.overdue { background: #FEE2E2; color: #991B1B; }
    </style>

    <div class="container">
        <div class="tabs">
            <a href="?status=" class="tab <?= !$status_filter ? 'active' : '' ?>">All <span class="cnt">(<?= $counts['all'] ?>)</span></a>
            <a href="?status=pending" class="tab <?= $status_filter === 'pending' ? 'active' : '' ?>">Pending <span class="cnt">(<?= $counts['pending'] ?>)</span></a>
            <a href="?status=confirmed" class="tab <?= $status_filter === 'confirmed' ? 'active' : '' ?>">Confirmed <span class="cnt">(<?= $counts['confirmed'] ?>)</span></a>
            <a href="?status=ready" class="tab <?= $status_filter === 'ready' ? 'active' : '' ?>">Ready <span class="cnt">(<?= $counts['ready'] ?>)</span></a>
            <a href="?status=picked_up" class="tab <?= $status_filter === 'picked_up' ? 'active' : '' ?>">Picked Up <span class="cnt">(<?= $counts['picked_up'] ?>)</span></a>
            <a href="?status=cancelled" class="tab <?= $status_filter === 'cancelled' ? 'active' : '' ?>">Cancelled <span class="cnt">(<?= $counts['cancelled'] ?>)</span></a>
        </div>

        <?php if (empty($orders)): ?>
            <div class="empty-msg">
                <h3>No orders yet</h3>
                <p><a href="/solarglobal/store.php">Find a dealer</a> and place your first order!</p>
            </div>
        <?php else: ?>
            <?php foreach ($orders as $order):
                $items = $order_items[$order['id']] ?? [];
                $status_steps = ['pending', 'confirmed', 'ready', 'picked_up'];
                $current_idx = array_search($order['status'], $status_steps);
                $is_cancelled = $order['status'] === 'cancelled';
            ?>
                <div class="order-card">
                    <div class="oc-header">
                        <div>
                            <div class="oc-number"><?= sanitize($order['order_number']) ?></div>
                            <div class="oc-dealer">&#127979; <?= sanitize($order['business_name']) ?></div>
                            <div class="oc-date"><?= date('M j, Y g:i A', strtotime($order['created_at'])) ?></div>
                        </div>
                        <span class="status-badge status-<?= $order['status'] ?>"><?= ucfirst(str_replace('_', ' ', $order['status'])) ?></span>
                    </div>
                    <?php if (!$is_cancelled && $order['pickup_deadline'] && in_array($order['status'], ['pending','confirmed','ready'])): ?>
                        <?php
                        $deadline_ts = strtotime($order['pickup_deadline']);
                        $remaining = $deadline_ts - time();
                        $is_overdue = $remaining < 0;
                        ?>
                        <div class="deadline-info <?= $is_overdue ? 'overdue' : ($remaining < 7200 ? 'urgent' : '') ?>">
                            <span class="deadline-icon"><?= $is_overdue ? '⚠️' : '⏰' ?></span>
                            <span class="deadline-text" data-deadline="<?= $deadline_ts ?>">
                                <?php if ($is_overdue): ?>
                                    Pickup overdue
                                <?php else: ?>
                                    Pickup by <?= date('M j, g:i A', $deadline_ts) ?>
                                <?php endif; ?>
                            </span>
                        </div>
                    <?php endif; ?>

                    <!-- Timeline -->
                    <?php if (!$is_cancelled): ?>
                    <div class="timeline">
                        <?php foreach ($status_steps as $si => $step):
                            $cls = '';
                            if ($si < $current_idx) $cls = 'done';
                            elseif ($si === $current_idx) $cls = 'active';
                            $time_field = ['pending' => 'created_at', 'confirmed' => 'confirmed_at', 'ready' => 'ready_at', 'picked_up' => 'picked_up_at'];
                            $ts = $order[$time_field[$step]] ?? null;
                        ?>
                            <div class="tl-step <?= $cls ?>">
                                <div class="tl-dot"><?= $cls === 'done' ? '&#10003;' : ($si + 1) ?></div>
                                <div class="tl-label"><?= ucfirst(str_replace('_', ' ', $step)) ?></div>
                                <?php if ($ts): ?><div class="tl-time"><?= date('M j, g:i A', strtotime($ts)) ?></div><?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                        <p style="font-size:0.8125rem;color:#DC2626;margin:8px 0;">
                            Cancelled <?= $order['cancelled_at'] ? date('M j, Y', strtotime($order['cancelled_at'])) : '' ?>
                            <?= $order['cancel_reason'] ? ' — ' . sanitize($order['cancel_reason']) : '' ?>
                        </p>
                    <?php endif; ?>

                    <!-- Items -->
                    <div class="oc-items">
                        <?php foreach ($items as $item): ?>
                            <div class="oc-item">
                                <span class="oc-item-name"><?= sanitize($item['product_name']) ?></span>
                                <span class="oc-item-qty">&times;<?= $item['quantity'] ?></span>
                                <span class="oc-item-price">$<?= number_format($item['total_price'], 2) ?></span>
                            </div>
                        <?php endforeach; ?>
                        <div class="oc-total">
                            <span class="oc-total-label">Total (<?= $order['item_count'] ?> items)</span>
                            <span class="oc-total-amount">$<?= number_format($order['total_amount'], 2) ?></span>
                        </div>
                    </div>

                    <div class="oc-actions">
                        <?php if ($order['status'] === 'picked_up'): ?>
                            <a href="reviews.php?order_id=<?= $order['id'] ?>" class="btn-sm btn-review">&#9733; Leave Review</a>
                        <?php endif; ?>
                        <?php if ($order['dealer_phone']): ?>
                            <a href="tel:<?= sanitize($order['dealer_phone']) ?>" class="btn-sm btn-contact">&#128222; Contact Dealer</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php for ($p = 1; $p <= $total_pages; $p++): ?>
                        <a href="?status=<?= $status_filter ?>&page=<?= $p ?>" class="<?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<script>
// Countdown timers for pickup deadlines
document.querySelectorAll('.deadline-text[data-deadline]').forEach(function(el) {
    var deadline = parseInt(el.dataset.deadline) * 1000;
    function update() {
        var now = Date.now();
        var diff = deadline - now;
        if (diff <= 0) {
            el.textContent = 'Pickup overdue';
            el.closest('.deadline-info').classList.add('overdue');
            return;
        }
        var hours = Math.floor(diff / 3600000);
        var mins = Math.floor((diff % 3600000) / 60000);
        if (hours > 0) {
            el.textContent = hours + 'h ' + mins + 'm remaining';
        } else {
            el.textContent = mins + 'm remaining';
        }
        if (diff < 7200000) el.closest('.deadline-info').classList.add('urgent');
    }
    update();
    setInterval(update, 60000);
});
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
