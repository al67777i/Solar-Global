<?php
/**
 * Customer Reviews - Submit review only for picked_up orders
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/customer_auth.php';

set_security_headers();
require_customer_login();

$customer = get_customer_profile();
$db = getDB();
$success = '';
$error = '';

$order_id = (int)($_GET['order_id'] ?? $_POST['order_id'] ?? 0);

// Validate the order belongs to customer and is picked_up
$order = null;
$existing_review = null;
if ($order_id > 0) {
    $stmt = $db->prepare("SELECT o.*, d.business_name FROM orders o JOIN dealers d ON o.dealer_id = d.id WHERE o.id = ? AND o.customer_id = ?");
    $stmt->execute([$order_id, $customer['id']]);
    $order = $stmt->fetch();

    if ($order) {
        // Check for existing review
        $stmt = $db->prepare("SELECT * FROM dealer_reviews WHERE order_id = ? AND customer_id = ?");
        $stmt->execute([$order_id, $customer['id']]);
        $existing_review = $stmt->fetch();
    }
}

// Handle review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $order_id = (int)($_POST['order_id'] ?? 0);
    $rating = (int)($_POST['rating'] ?? 0);
    $review_text = trim($_POST['review_text'] ?? '');

    // Re-validate order
    $stmt = $db->prepare("SELECT * FROM orders WHERE id = ? AND customer_id = ? AND status = 'picked_up'");
    $stmt->execute([$order_id, $customer['id']]);
    $order_check = $stmt->fetch();

    if (!$order_check) {
        $error = 'Invalid order or order not yet completed.';
    } elseif ($rating < 1 || $rating > 5) {
        $error = 'Please select a rating (1-5 stars).';
    } elseif (strlen($review_text) < 10) {
        $error = 'Please write at least 10 characters in your review.';
    } else {
        // Check for duplicate
        $stmt = $db->prepare("SELECT id FROM dealer_reviews WHERE order_id = ?");
        $stmt->execute([$order_id]);
        if ($stmt->fetch()) {
            $error = 'You have already reviewed this order.';
        } else {
            $stmt = $db->prepare("INSERT INTO dealer_reviews (dealer_id, customer_id, order_id, rating, review_text, status) VALUES (?, ?, ?, ?, ?, 'approved')");
            $stmt->execute([$order_check['dealer_id'], $customer['id'], $order_id, $rating, $review_text]);

            // Update dealer avg rating (count all approved reviews including this one)
            $stmt = $db->prepare("UPDATE dealers SET
                avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM dealer_reviews WHERE dealer_id = ? AND status = 'approved'),
                total_reviews = (SELECT COUNT(*) FROM dealer_reviews WHERE dealer_id = ? AND status = 'approved')
                WHERE id = ?");
            $stmt->execute([$order_check['dealer_id'], $order_check['dealer_id'], $order_check['dealer_id']]);

            $success = 'Thank you for your review! It is now visible on the dealer\'s profile.';
            $existing_review = ['rating' => $rating, 'review_text' => $review_text, 'status' => 'approved'];
        }
    }
}

// Fetch reviewable orders (picked_up, no review yet)
$stmt = $db->prepare("SELECT o.id, o.order_number, o.total_amount, o.picked_up_at, d.business_name,
                       (SELECT COUNT(*) FROM dealer_reviews dr WHERE dr.order_id = o.id) as has_review
                       FROM orders o JOIN dealers d ON o.dealer_id = d.id
                       WHERE o.customer_id = ? AND o.status = 'picked_up'
                       ORDER BY o.picked_up_at DESC");
$stmt->execute([$customer['id']]);
$reviewable_orders = $stmt->fetchAll();


$page_title = 'My Reviews';
$current_page = 'reviews';
include __DIR__ . '/../includes/header.php';
?>
    <style>
        .container { max-width: 700px; margin: 24px auto; padding: 0 20px; }

        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; }
        .alert-success { background: #DCFCE7; color: #166534; }
        .alert-error { background: #FEF2F2; color: #991B1B; }

        .card { background: white; border-radius: 12px; padding: 24px; margin-bottom: 16px; box-shadow: 0 1px 4px rgba(0,0,0,0.05); }
        .card h2 { font-size: 1.125rem; font-weight: 700; color: #1E293B; margin-bottom: 16px; }

        /* Star rating input */
        .star-rating { display: flex; gap: 4px; margin-bottom: 16px; flex-direction: row-reverse; justify-content: flex-end; }
        .star-rating input { display: none; }
        .star-rating label {
            font-size: 2rem; color: #E2E8F0; cursor: pointer; transition: color 0.15s;
        }
        .star-rating input:checked ~ label,
        .star-rating label:hover,
        .star-rating label:hover ~ label { color: #F59E0B; }

        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; font-size: 0.8125rem; font-weight: 600; color: #374151; margin-bottom: 6px; }
        .form-group textarea {
            width: 100%; padding: 12px; border: 2px solid #E2E8F0; border-radius: 8px;
            font-family: inherit; font-size: 0.9375rem; resize: vertical; min-height: 100px;
        }
        .form-group textarea:focus { outline: none; border-color: #F59E0B; }

        .btn-submit {
            padding: 12px 28px; background: #F59E0B; color: #1E293B; border: none;
            border-radius: 8px; font-weight: 700; font-size: 0.9375rem; cursor: pointer; width: 100%;
        }
        .btn-submit:hover { background: #D97706; }

        /* Order list */
        .order-row {
            display: flex; justify-content: space-between; align-items: center; padding: 12px 0;
            border-bottom: 1px solid #F1F5F9; gap: 12px; flex-wrap: wrap;
        }
        .order-row:last-child { border-bottom: none; }
        .or-info { flex: 1; }
        .or-num { font-weight: 600; font-size: 0.875rem; color: #1E293B; }
        .or-dealer { font-size: 0.75rem; color: #64748B; }
        .or-date { font-size: 0.6875rem; color: #94A3B8; }
        .btn-review-sm {
            padding: 6px 14px; border-radius: 6px; font-size: 0.75rem; font-weight: 700;
            text-decoration: none; cursor: pointer; border: none; font-family: inherit;
        }
        .btn-review-sm.active { background: #F59E0B; color: #1E293B; }
        .btn-review-sm.done { background: #E2E8F0; color: #64748B; cursor: default; }

        .existing-review { background: #F0FDF4; border: 1px solid #BBF7D0; border-radius: 8px; padding: 16px; }
        .er-stars { color: #F59E0B; font-size: 1.25rem; margin-bottom: 6px; }
        .er-text { font-size: 0.875rem; color: #374151; }
        .er-status { font-size: 0.6875rem; color: #64748B; margin-top: 6px; }
    </style>

    <div class="container">
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>

        <?php if ($order && $order['status'] === 'picked_up'): ?>
            <div class="card">
                <h2>Review for <?= sanitize($order['business_name']) ?></h2>
                <p style="font-size:0.8125rem;color:#64748B;margin-bottom:16px;">Order <?= sanitize($order['order_number']) ?> &middot; $<?= number_format($order['total_amount'], 2) ?></p>

                <?php if ($existing_review): ?>
                    <div class="existing-review">
                        <div class="er-stars">
                            <?php for ($i = 1; $i <= 5; $i++) echo $i <= $existing_review['rating'] ? '&#9733;' : '&#9734;'; ?>
                        </div>
                        <div class="er-text"><?= nl2br(sanitize($existing_review['review_text'])) ?></div>
                        <div class="er-status">Status: <?= ucfirst($existing_review['status']) ?></div>
                    </div>
                <?php else: ?>
                    <form method="POST">
                        <?= csrf_field() ?>
                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">

                        <div class="form-group">
                            <label>Rating</label>
                            <div class="star-rating">
                                <?php for ($i = 5; $i >= 1; $i--): ?>
                                    <input type="radio" name="rating" id="star<?= $i ?>" value="<?= $i ?>" required>
                                    <label for="star<?= $i ?>">&#9733;</label>
                                <?php endfor; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Your Review</label>
                            <textarea name="review_text" placeholder="Share your experience with this dealer..." required minlength="10"></textarea>
                        </div>

                        <button type="submit" class="btn-submit">Submit Review</button>
                    </form>
                <?php endif; ?>
            </div>
        <?php elseif ($order): ?>
            <div class="card">
                <p style="color:#64748B;">This order hasn't been picked up yet. You can review after pickup.</p>
            </div>
        <?php endif; ?>

        <!-- Reviewable orders list -->
        <div class="card">
            <h2>Your Completed Orders</h2>
            <?php if (empty($reviewable_orders)): ?>
                <p style="color:#64748B;font-size:0.875rem;">No completed orders to review yet.</p>
            <?php else: ?>
                <?php foreach ($reviewable_orders as $ro): ?>
                    <div class="order-row">
                        <div class="or-info">
                            <div class="or-num"><?= sanitize($ro['order_number']) ?></div>
                            <div class="or-dealer"><?= sanitize($ro['business_name']) ?> &middot; $<?= number_format($ro['total_amount'], 2) ?></div>
                            <div class="or-date"><?= $ro['picked_up_at'] ? date('M j, Y', strtotime($ro['picked_up_at'])) : '' ?></div>
                        </div>
                        <?php if ($ro['has_review'] > 0): ?>
                            <span class="btn-review-sm done">&#10003; Reviewed</span>
                        <?php else: ?>
                            <a href="?order_id=<?= $ro['id'] ?>" class="btn-review-sm active">&#9733; Write Review</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
