﻿// Products.js - Only handles dual-range sliders
// Comparison widget is handled by comparison-widget.js

// Tab switching
function switchTab(tabName) {
    // Hide all tab contents
    var contents = document.querySelectorAll('.tab-content');
    for (var i = 0; i < contents.length; i++) {
        contents[i].classList.remove('active');
    }
    
    // Remove active class from all buttons
    var buttons = document.querySelectorAll('.tab-btn');
    for (var i = 0; i < buttons.length; i++) {
        buttons[i].classList.remove('active');
    }
    
    // Show selected tab
    var selectedContent = document.getElementById(tabName);
    if (selectedContent) {
        selectedContent.classList.add('active');
    }
    
    // Activate button
    var allButtons = document.querySelectorAll('.tab-btn');
    for (var i = 0; i < allButtons.length; i++) {
        if (allButtons[i].getAttribute('onclick') && allButtons[i].getAttribute('onclick').indexOf(tabName) > -1) {
            allButtons[i].classList.add('active');
        }
    }
}

// Dual Range Slider Functionality
function initDualRangeSliders() {
    // Price slider
    var priceMin = document.getElementById('price-min');
    var priceMax = document.getElementById('price-max');
    var priceFill = document.getElementById('price-fill');
    var priceMinValue = document.getElementById('price-min-value');
    var priceMaxValue = document.getElementById('price-max-value');
    
    if (priceMin && priceMax && priceFill) {
        var priceDebounce = null;
        
        function updatePriceSlider() {
            var min = parseInt(priceMin.value);
            var max = parseInt(priceMax.value);
            var rangeMin = parseInt(priceMin.min);
            var rangeMax = parseInt(priceMin.max);
            
            // Prevent crossing
            if (min > max) {
                priceMin.value = max;
                min = max;
            }
            if (max < min) {
                priceMax.value = min;
                max = min;
            }
            
            // Update fill bar
            var percentMin = ((min - rangeMin) / (rangeMax - rangeMin)) * 100;
            var percentMax = ((max - rangeMin) / (rangeMax - rangeMin)) * 100;
            
            priceFill.style.left = percentMin + '%';
            priceFill.style.width = (percentMax - percentMin) + '%';
            
            // Update value displays
            if (priceMinValue) {
                priceMinValue.textContent = 'USD ' + formatNumber(min);
            }
            if (priceMaxValue) {
                priceMaxValue.textContent = 'USD ' + formatNumber(max);
            }
            
            // DON'T auto-submit - let user click "Apply Filters" button
            // clearTimeout(priceDebounce);
            // priceDebounce = setTimeout(function() {
            //     var form = document.getElementById('filterForm');
            //     if (form) {
            //         form.submit();
            //     }
            // }, 1000);
        }
        
        priceMin.addEventListener('input', updatePriceSlider);
        priceMax.addEventListener('input', updatePriceSlider);
        
        // Initialize on load
        updatePriceSlider();
    }
    
    // Wattage slider
    var wattMin = document.getElementById('watt-min');
    var wattMax = document.getElementById('watt-max');
    var wattFill = document.getElementById('watt-fill');
    var wattMinValue = document.getElementById('watt-min-value');
    var wattMaxValue = document.getElementById('watt-max-value');
    
    if (wattMin && wattMax && wattFill) {
        var wattDebounce = null;
        
        function updateWattSlider() {
            var min = parseInt(wattMin.value);
            var max = parseInt(wattMax.value);
            var rangeMin = parseInt(wattMin.min);
            var rangeMax = parseInt(wattMin.max);
            
            // Prevent crossing
            if (min > max) {
                wattMin.value = max;
                min = max;
            }
            if (max < min) {
                wattMax.value = min;
                max = min;
            }
            
            // Update fill bar
            var percentMin = ((min - rangeMin) / (rangeMax - rangeMin)) * 100;
            var percentMax = ((max - rangeMin) / (rangeMax - rangeMin)) * 100;
            
            wattFill.style.left = percentMin + '%';
            wattFill.style.width = (percentMax - percentMin) + '%';
            
            // Update value displays
            if (wattMinValue) {
                wattMinValue.textContent = formatNumber(min) + 'W';
            }
            if (wattMaxValue) {
                wattMaxValue.textContent = formatNumber(max) + 'W';
            }
            
            // DON'T auto-submit - let user click "Apply Filters" button
            // clearTimeout(wattDebounce);
            // wattDebounce = setTimeout(function() {
            //     var form = document.getElementById('filterForm');
            //     if (form) {
            //         form.submit();
            //     }
            // }, 1000);
        }
        
        wattMin.addEventListener('input', updateWattSlider);
        wattMax.addEventListener('input', updateWattSlider);
        
        // Initialize on load
        updateWattSlider();
    }
    
    // Capacity slider (for batteries)
    var capacityMin = document.getElementById('capacity-min');
    var capacityMax = document.getElementById('capacity-max');
    var capacityFill = document.getElementById('capacity-fill');
    var capacityMinValue = document.getElementById('capacity-min-value');
    var capacityMaxValue = document.getElementById('capacity-max-value');
    
    if (capacityMin && capacityMax && capacityFill) {
        var capacityDebounce = null;
        
        function updateCapacitySlider() {
            var min = parseInt(capacityMin.value);
            var max = parseInt(capacityMax.value);
            var rangeMin = parseInt(capacityMin.min);
            var rangeMax = parseInt(capacityMin.max);
            
            // Prevent crossing
            if (min > max) {
                capacityMin.value = max;
                min = max;
            }
            if (max < min) {
                capacityMax.value = min;
                max = min;
            }
            
            // Update fill bar
            var percentMin = ((min - rangeMin) / (rangeMax - rangeMin)) * 100;
            var percentMax = ((max - rangeMin) / (rangeMax - rangeMin)) * 100;
            
            capacityFill.style.left = percentMin + '%';
            capacityFill.style.width = (percentMax - percentMin) + '%';
            
            // Update value displays
            if (capacityMinValue) {
                capacityMinValue.textContent = formatNumber(min) + ' Ah';
            }
            if (capacityMaxValue) {
                capacityMaxValue.textContent = formatNumber(max) + ' Ah';
            }
            
            // DON'T auto-submit - let user click "Apply Filters" button
            // clearTimeout(capacityDebounce);
            // capacityDebounce = setTimeout(function() {
            //     var form = document.getElementById('filterForm');
            //     if (form) {
            //         form.submit();
            //     }
            // }, 1000);
        }
        
        capacityMin.addEventListener('input', updateCapacitySlider);
        capacityMax.addEventListener('input', updateCapacitySlider);
        
        // Initialize on load
        updateCapacitySlider();
    }
}

// Format number with commas
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Initialize all on page load
function initAll() {
    initDualRangeSliders();
    initFilterToggle();
    initViewToggle();
    initCardAnimations();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
} else {
    initAll();
}

// Filter sidebar toggle (mobile)
// Skip if inline script already bound handlers (check for data attribute)
function initFilterToggle() {
    var toggleBtn = document.getElementById('filterToggle');
    var sidebar = document.getElementById('filtersSidebar');
    var overlay = document.getElementById('filterOverlay');

    // Don't double-bind — inline scripts on product pages already handle this
    if (!toggleBtn || !sidebar || toggleBtn.dataset.bound) return;
    toggleBtn.dataset.bound = '1';

    toggleBtn.addEventListener('click', function() {
        sidebar.classList.toggle('open');
        if (overlay) overlay.classList.toggle('open');
        document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : '';
    });

    if (overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('open');
            overlay.classList.remove('open');
            document.body.style.overflow = '';
        });
    }
}

// Sort function
window.applySort = function(value) {
    var url = new URL(window.location.href);
    url.searchParams.set('sort', value);
    url.searchParams.delete('page');
    window.location.href = url.toString();
};

// View toggle (grid/list)
function initViewToggle() {
    var viewBtns = document.querySelectorAll('.view-btn');
    var grid = document.querySelector('.products-grid');

    if (!grid || !viewBtns.length || grid.dataset.viewBound) return;
    grid.dataset.viewBound = '1';

    // Load saved view
    var savedView = localStorage.getItem('products_view') || 'grid';
    if (savedView === 'list') {
        grid.classList.add('list-view');
    }

    for (var i = 0; i < viewBtns.length; i++) {
        var btn = viewBtns[i];
        if (btn.getAttribute('data-view') === savedView) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }

        btn.addEventListener('click', function() {
            var view = this.getAttribute('data-view');
            for (var j = 0; j < viewBtns.length; j++) {
                viewBtns[j].classList.remove('active');
            }
            this.classList.add('active');

            if (view === 'list') {
                grid.classList.add('list-view');
            } else {
                grid.classList.remove('list-view');
            }
            localStorage.setItem('products_view', view);
        });
    }
}

// Card entrance animation
function initCardAnimations() {
    var cards = document.querySelectorAll('.product-card');
    if (!cards.length || !('IntersectionObserver' in window)) return;

    var observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('card-visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    for (var i = 0; i < cards.length; i++) {
        cards[i].style.animationDelay = (i * 0.05) + 's';
        observer.observe(cards[i]);
    }
}

// Make functions globally available
window.switchTab = switchTab;
window.initDualRangeSliders = initDualRangeSliders;
window.initFilterToggle = initFilterToggle;
window.initViewToggle = initViewToggle;
window.initCardAnimations = initCardAnimations;
