<?php
/**
 * Installer Profile Management
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/installer_auth.php';

set_security_headers();
require_installer_login();

$installer = get_installer_profile();
$db = getDB();
$errors = [];
$success = '';

// Fetch countries
$countries = [];
try {
    $stmt = $db->query("SELECT code, name FROM countries ORDER BY name ASC");
    $countries = $stmt->fetchAll();
} catch (Exception $e) {}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please try again.';
    } else {
        if ($_POST['action'] === 'update_profile') {
            $business_name = trim($_POST['business_name'] ?? '');
            $owner_name = trim($_POST['owner_name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $about = trim($_POST['about'] ?? '');
            $license_number = trim($_POST['license_number'] ?? '');
            $years_experience = (int)($_POST['years_experience'] ?? 0);
            $team_size = (int)($_POST['team_size'] ?? 1);
            $price_per_kw = trim($_POST['price_per_kw'] ?? '');
            $service_radius = (int)($_POST['service_radius'] ?? 50);
            $latitude = trim($_POST['latitude'] ?? '');
            $longitude = trim($_POST['longitude'] ?? '');
            $city = trim($_POST['city'] ?? '');
            $region = trim($_POST['region'] ?? '');
            $country_code = trim($_POST['country_code'] ?? '');
            $specializations = $_POST['specializations'] ?? [];

            // Validate
            if (empty($business_name)) $errors[] = 'Business name is required.';
            if (empty($owner_name)) $errors[] = 'Owner name is required.';

            $valid_specs = ['Residential', 'Commercial', 'Industrial', 'Off-Grid', 'On-Grid', 'Hybrid'];
            $specializations = array_intersect($specializations, $valid_specs);

            // Handle logo upload
            $logo_path = $installer['logo_path'];
            if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['logo'];
                $allowed_types = ['image/jpeg', 'image/png', 'image/webp'];
                $max_size = 2 * 1024 * 1024;

                if (!in_array($file['type'], $allowed_types)) {
                    $errors[] = 'Logo must be JPG, PNG, or WebP format.';
                } elseif ($file['size'] > $max_size) {
                    $errors[] = 'Logo file must be under 2MB.';
                } else {
                    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $filename = 'installer_logo_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                    $upload_dir = __DIR__ . '/../uploads/installers/logos/';
                    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

                    if (move_uploaded_file($file['tmp_name'], $upload_dir . $filename)) {
                        $logo_path = 'uploads/installers/logos/' . $filename;
                    } else {
                        $errors[] = 'Failed to upload logo.';
                    }
                }
            }

            if (empty($errors)) {
                try {
                    $stmt = $db->prepare("
                        UPDATE installers SET
                            business_name = ?, owner_name = ?, phone = ?, about = ?,
                            license_number = ?, years_experience = ?, team_size = ?,
                            price_per_kw = ?, specializations = ?, service_radius = ?,
                            latitude = ?, longitude = ?, city = ?, region = ?,
                            country_code = ?, logo_path = ?, updated_at = NOW()
                        WHERE id = ?
                    ");
                    $stmt->execute([
                        $business_name, $owner_name, $phone, $about,
                        $license_number, $years_experience, $team_size,
                        $price_per_kw, json_encode($specializations), $service_radius,
                        $latitude, $longitude, $city, $region,
                        $country_code, $logo_path, $installer['id']
                    ]);

                    // Update session
                    $_SESSION['installer_business_name'] = $business_name;
                    $_SESSION['installer_owner_name'] = $owner_name;
                    $_SESSION['installer_logo'] = $logo_path;

                    $success = 'Profile updated successfully!';
                    $installer = get_installer_profile(); // Refresh
                } catch (Exception $e) {
                    error_log("Installer profile update error: " . $e->getMessage());
                    $errors[] = 'Update failed. Please try again.';
                }
            }
        } elseif ($_POST['action'] === 'change_password') {
            $current_password = $_POST['current_password'] ?? '';
            $new_password = $_POST['new_password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';

            // Get current hash
            $stmt = $db->prepare("SELECT password_hash FROM installers WHERE id = ?");
            $stmt->execute([$installer['id']]);
            $row = $stmt->fetch();

            if (!password_verify($current_password, $row['password_hash'])) {
                $errors[] = 'Current password is incorrect.';
            } elseif (strlen($new_password) < 8) {
                $errors[] = 'New password must be at least 8 characters.';
            } elseif (!preg_match('/[A-Z]/', $new_password)) {
                $errors[] = 'New password must contain at least one uppercase letter.';
            } elseif (!preg_match('/[0-9]/', $new_password)) {
                $errors[] = 'New password must contain at least one number.';
            } elseif ($new_password !== $confirm_password) {
                $errors[] = 'New passwords do not match.';
            } else {
                $hash = password_hash($new_password, PASSWORD_BCRYPT);
                $stmt = $db->prepare("UPDATE installers SET password_hash = ? WHERE id = ?");
                $stmt->execute([$hash, $installer['id']]);
                $success = 'Password changed successfully!';
            }
        }
    }
}

$specializations = json_decode($installer['specializations'] ?? '[]', true) ?: [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?= sanitize($installer['business_name']) ?> | <?= get_system_setting('site_name', 'SolarGlobal') ?> Installer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php
    $maps_key = get_system_setting('google_maps_api_key', '');
    // No hardcoded fallback — key must be set in Admin → Settings
    ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
    <script>
    var useGoogleMaps = false;
    function installerProfileGmapsReady() { useGoogleMaps = true; if (window.initProfileMap) window.initProfileMap(); }
    function gm_authFailure() { useGoogleMaps = false; if (window.initProfileMap) window.initProfileMap(); }
    </script>
    <script async src="https://maps.googleapis.com/maps/api/js?key=<?= sanitize($maps_key) ?>&libraries=places&callback=installerProfileGmapsReady"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 260px;
            background: #0F172A; color: white; z-index: 100;
            display: flex; flex-direction: column; transition: transform 0.3s;
        }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid #1E293B; }
        .sidebar-header h2 { font-size: 1.25rem; font-weight: 800; color: #F59E0B; }
        .sidebar-header p { font-size: 0.75rem; color: #94A3B8; margin-top: 2px; }
        .sidebar-nav { flex: 1; padding: 16px 12px; overflow-y: auto; }
        .nav-section { margin-bottom: 24px; }
        .nav-section-title { font-size: 0.6875rem; text-transform: uppercase; letter-spacing: 1px; color: #475569; padding: 0 12px; margin-bottom: 8px; font-weight: 600; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 8px; color: #CBD5E1; text-decoration: none; font-size: 0.875rem; font-weight: 500; transition: all 0.2s; }
        .nav-item:hover { background: #1E293B; color: white; }
        .nav-item.active { background: #D97706; color: white; }
        .nav-item .icon { font-size: 1.125rem; width: 24px; text-align: center; }

        .main-content { margin-left: 260px; padding: 24px 32px; min-height: 100vh; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; }
        .top-bar h1 { font-size: 1.5rem; font-weight: 700; color: #1E293B; }

        .mobile-menu-btn { display: none; background: #0F172A; color: white; border: none; width: 40px; height: 40px; border-radius: 8px; font-size: 1.25rem; cursor: pointer; }

        .form-card {
            background: white; border-radius: 14px; padding: 32px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
            margin-bottom: 24px;
        }
        .form-card h3 { font-size: 1.125rem; font-weight: 700; color: #1E293B; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid #F1F5F9; }

        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-row-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; }
        @media (max-width: 700px) { .form-row, .form-row-3 { grid-template-columns: 1fr; } }

        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 0.875rem; font-weight: 600; color: #334155; margin-bottom: 6px; }
        .form-group label .required { color: #DC2626; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%; padding: 12px 16px; border: 2px solid #E2E8F0;
            border-radius: 10px; font-size: 0.9375rem; font-family: inherit;
            transition: all 0.2s; background: #F8FAFC;
        }
        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            outline: none; border-color: #F59E0B; box-shadow: 0 0 0 3px rgba(245,158,11,0.15); background: white;
        }
        .form-group textarea { resize: vertical; min-height: 100px; }
        .form-group .help-text { font-size: 0.8125rem; color: #64748B; margin-top: 4px; }

        .checkbox-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
        @media (max-width: 600px) { .checkbox-grid { grid-template-columns: 1fr 1fr; } }
        .checkbox-item { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border: 2px solid #E2E8F0; border-radius: 8px; cursor: pointer; transition: all 0.2s; font-size: 0.875rem; }
        .checkbox-item:hover { border-color: #F59E0B; background: #FFFBEB; }
        .checkbox-item:has(input:checked) { border-color: #F59E0B; background: #FFFBEB; }

        .range-container { display: flex; align-items: center; gap: 16px; }
        .range-container input[type="range"] { flex: 1; padding: 0; border: none; background: transparent; -webkit-appearance: none; height: 6px; }
        .range-container input[type="range"]::-webkit-slider-track { background: #E2E8F0; border-radius: 3px; height: 6px; }
        .range-container input[type="range"]::-webkit-slider-thumb { -webkit-appearance: none; width: 20px; height: 20px; background: #F59E0B; border-radius: 50%; cursor: pointer; margin-top: -7px; }
        .range-value { min-width: 60px; text-align: center; font-weight: 700; color: #F59E0B; font-size: 1rem; }

        .map-container { width: 100%; height: 300px; border-radius: 12px; border: 2px solid #E2E8F0; overflow: hidden; margin-bottom: 8px; }
        .location-coords { display: flex; gap: 16px; font-size: 0.8125rem; color: #64748B; }
        .location-coords span { background: #F1F5F9; padding: 4px 10px; border-radius: 6px; }

        .logo-upload { border: 2px dashed #CBD5E1; border-radius: 12px; padding: 30px; text-align: center; cursor: pointer; transition: all 0.2s; background: #F8FAFC; }
        .logo-upload:hover { border-color: #F59E0B; background: #FFFBEB; }
        .logo-upload input { display: none; }
        .logo-upload .upload-text { font-size: 0.875rem; color: #64748B; }
        .logo-upload .upload-text strong { color: #F59E0B; }
        .current-logo { width: 80px; height: 80px; border-radius: 12px; object-fit: cover; margin-bottom: 12px; }

        .btn-save {
            padding: 14px 32px; border: none; border-radius: 10px; font-size: 0.9375rem; font-weight: 700; cursor: pointer;
            background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%); color: white; transition: all 0.3s;
        }
        .btn-save:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(245,158,11,0.3); }

        .success-msg { background: #DCFCE7; border: 1px solid #BBF7D0; color: #166534; padding: 12px 16px; border-radius: 10px; margin-bottom: 20px; font-size: 0.875rem; border-left: 4px solid #16A34A; }
        .error-list { background: #FEF2F2; border: 1px solid #FECACA; border-radius: 10px; padding: 12px 16px; margin-bottom: 20px; border-left: 4px solid #DC2626; }
        .error-list ul { margin: 0; padding-left: 20px; }
        .error-list li { font-size: 0.875rem; color: #991B1B; margin-bottom: 4px; }

        @media (max-width: 900px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .mobile-menu-btn { display: block; }
        }
        .overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 90; }
        .overlay.active { display: block; }
    </style>
</head>
<body>
    <?php $current_installer_page = 'profile'; include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="top-bar">
            <div>
                <button class="mobile-menu-btn" onclick="toggleSidebar()">&#9776;</button>
                <h1>My Profile</h1>
            </div>
        </div>

        <?php if ($success): ?>
            <div class="success-msg"><?= sanitize($success) ?></div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
            <div class="error-list"><ul><?php foreach ($errors as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul></div>
        <?php endif; ?>

        <!-- Profile Form -->
        <form method="POST" action="" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_profile">

            <div class="form-card">
                <h3>&#128188; Business Information</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label>Business Name <span class="required">*</span></label>
                        <input type="text" name="business_name" value="<?= sanitize($installer['business_name']) ?>" required maxlength="200">
                    </div>
                    <div class="form-group">
                        <label>Owner Full Name <span class="required">*</span></label>
                        <input type="text" name="owner_name" value="<?= sanitize($installer['owner_name']) ?>" required maxlength="150">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" name="phone" value="<?= sanitize($installer['phone'] ?? '') ?>" maxlength="30">
                    </div>
                    <div class="form-group">
                        <label>License Number</label>
                        <input type="text" name="license_number" value="<?= sanitize($installer['license_number'] ?? '') ?>" maxlength="100">
                    </div>
                </div>
                <div class="form-group">
                    <label>About Your Business</label>
                    <textarea name="about" maxlength="1000"><?= sanitize($installer['about'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <label>Company Logo</label>
                    <div class="logo-upload" onclick="document.getElementById('logoInput').click()">
                        <?php if (!empty($installer['logo_path'])): ?>
                            <img src="/solarglobal/<?= sanitize($installer['logo_path']) ?>" class="current-logo" alt="Current logo">
                        <?php endif; ?>
                        <input type="file" name="logo" id="logoInput" accept="image/jpeg,image/png,image/webp">
                        <div class="upload-text"><strong>Click to change</strong> logo (JPG, PNG, WebP - Max 2MB)</div>
                    </div>
                </div>
            </div>

            <div class="form-card">
                <h3>&#128296; Experience & Services</h3>
                <div class="form-row-3">
                    <div class="form-group">
                        <label>Years of Experience</label>
                        <input type="number" name="years_experience" value="<?= (int)($installer['years_experience'] ?? 0) ?>" min="0" max="50">
                    </div>
                    <div class="form-group">
                        <label>Team Size</label>
                        <input type="number" name="team_size" value="<?= (int)($installer['team_size'] ?? 1) ?>" min="1" max="500">
                    </div>
                    <div class="form-group">
                        <label>Price per kW (USD)</label>
                        <input type="number" name="price_per_kw" value="<?= sanitize($installer['price_per_kw'] ?? '') ?>" min="0" step="0.01">
                    </div>
                </div>
                <div class="form-group">
                    <label>Specializations</label>
                    <div class="checkbox-grid">
                        <?php
                        $specs = ['Residential', 'Commercial', 'Industrial', 'Off-Grid', 'On-Grid', 'Hybrid'];
                        foreach ($specs as $spec):
                        ?>
                        <label class="checkbox-item">
                            <input type="checkbox" name="specializations[]" value="<?= $spec ?>"
                                <?= in_array($spec, $specializations) ? 'checked' : '' ?>>
                            <span><?= $spec ?></span>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label>Service Radius: <span id="radiusValue"><?= (int)($installer['service_radius'] ?? 50) ?></span> km</label>
                    <div class="range-container">
                        <span style="font-size:0.8125rem;color:#64748B">10km</span>
                        <input type="range" name="service_radius" id="serviceRadius" min="10" max="200" step="5"
                               value="<?= (int)($installer['service_radius'] ?? 50) ?>">
                        <span style="font-size:0.8125rem;color:#64748B">200km</span>
                        <span class="range-value" id="radiusDisplay"><?= (int)($installer['service_radius'] ?? 50) ?> km</span>
                    </div>
                </div>
            </div>

            <div class="form-card">
                <h3>&#128205; Service Location</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label>Country</label>
                        <select name="country_code" id="countrySelect">
                            <option value="">Select Country</option>
                            <?php foreach ($countries as $c): ?>
                                <option value="<?= sanitize($c['code']) ?>" <?= ($installer['country_code'] ?? '') === $c['code'] ? 'selected' : '' ?>>
                                    <?= sanitize($c['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" name="city" id="cityField" value="<?= sanitize($installer['city'] ?? '') ?>" maxlength="100">
                    </div>
                </div>
                <div class="form-group">
                    <label>Region / State</label>
                    <input type="text" name="region" value="<?= sanitize($installer['region'] ?? '') ?>" maxlength="100">
                </div>
                <div class="form-group">
                    <label>Location on Map</label>
                    <input type="text" id="addressInput" placeholder="Search for your address..." style="width:100%;padding:12px 16px;border:2px solid #E2E8F0;border-radius:10px;font-size:0.9375rem;font-family:inherit;margin-bottom:10px;">
                    <div class="map-container" id="profileMap"></div>
                    <div class="location-coords">
                        <span id="latDisplay">Lat: <?= $installer['latitude'] ? number_format((float)$installer['latitude'], 5) : '--' ?></span>
                        <span id="lngDisplay">Lng: <?= $installer['longitude'] ? number_format((float)$installer['longitude'], 5) : '--' ?></span>
                    </div>
                    <input type="hidden" name="latitude" id="latInput" value="<?= sanitize($installer['latitude'] ?? '') ?>">
                    <input type="hidden" name="longitude" id="lngInput" value="<?= sanitize($installer['longitude'] ?? '') ?>">
                </div>

                <button type="submit" class="btn-save">Save Profile Changes</button>
            </div>
        </form>

        <!-- Change Password -->
        <form method="POST" action="">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="change_password">

            <div class="form-card">
                <h3>&#128274; Change Password</h3>
                <div class="form-group">
                    <label>Current Password</label>
                    <input type="password" name="current_password" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" required minlength="8" placeholder="Min 8 chars, 1 uppercase, 1 number">
                    </div>
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" required minlength="8">
                    </div>
                </div>
                <button type="submit" class="btn-save">Change Password</button>
            </div>
        </form>
    </main>

    <script>
    // Service radius slider
    document.getElementById('serviceRadius')?.addEventListener('input', function(e) {
        document.getElementById('radiusValue').textContent = e.target.value;
        document.getElementById('radiusDisplay').textContent = e.target.value + ' km';
    });

    // Map initialization (Google Maps with Leaflet fallback)
    (function() {
        const mapEl = document.getElementById('profileMap');
        if (!mapEl) return;

        const defaultLat = parseFloat(document.getElementById('latInput').value) || 25.0;
        const defaultLng = parseFloat(document.getElementById('lngInput').value) || 67.0;
        const hasCoords = !!document.getElementById('latInput').value;

        function updateCoordDisplays(lat, lng, city, country) {
            document.getElementById('latInput').value = lat.toFixed(7);
            document.getElementById('lngInput').value = lng.toFixed(7);
            document.getElementById('latDisplay').textContent = 'Lat: ' + lat.toFixed(5);
            document.getElementById('lngDisplay').textContent = 'Lng: ' + lng.toFixed(5);
            if (city) document.getElementById('cityField').value = city;
            if (country) {
                var sel = document.getElementById('countrySelect');
                for (var i = 0; i < sel.options.length; i++) {
                    if (sel.options[i].value === country) { sel.selectedIndex = i; break; }
                }
            }
        }

        // ─── Google Maps Path ───
        function initWithGoogle() {
            var map = new google.maps.Map(mapEl, {
                center: { lat: defaultLat, lng: defaultLng },
                zoom: hasCoords ? 14 : 3,
                mapTypeControl: false, streetViewControl: false, fullscreenControl: false,
            });

            var marker = new google.maps.Marker({
                position: { lat: defaultLat, lng: defaultLng },
                map: map, draggable: true, title: 'Your Location',
            });
            marker.setVisible(hasCoords);

            var geocoder = new google.maps.Geocoder();

            function update(lat, lng) {
                marker.setPosition({ lat, lng });
                marker.setVisible(true);
                geocoder.geocode({ location: { lat, lng } }, function(results, status) {
                    if (status === 'OK' && results[0]) {
                        var city = '', country = '';
                        results[0].address_components.forEach(function(c) {
                            if (c.types.includes('locality')) city = c.long_name;
                            if (c.types.includes('country')) country = c.short_name;
                        });
                        updateCoordDisplays(lat, lng, city, country);
                    } else {
                        updateCoordDisplays(lat, lng, '', '');
                    }
                });
            }

            map.addListener('click', function(e) { update(e.latLng.lat(), e.latLng.lng()); });
            marker.addListener('dragend', function(e) { update(e.latLng.lat(), e.latLng.lng()); });

            var autocomplete = new google.maps.places.Autocomplete(document.getElementById('addressInput'), { types: ['establishment', 'geocode'] });
            autocomplete.bindTo('bounds', map);
            autocomplete.addListener('place_changed', function() {
                var place = autocomplete.getPlace();
                if (place.geometry && place.geometry.location) {
                    var lat = place.geometry.location.lat();
                    var lng = place.geometry.location.lng();
                    map.setCenter({ lat, lng }); map.setZoom(16);
                    update(lat, lng);
                }
            });
        }

        // ─── Leaflet Fallback Path ───
        function initWithLeaflet() {
            var map = L.map(mapEl, {
                center: [defaultLat, defaultLng],
                zoom: hasCoords ? 14 : 3
            });

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors',
                maxZoom: 19
            }).addTo(map);

            var marker = L.marker([defaultLat, defaultLng], { draggable: true });
            if (hasCoords) marker.addTo(map);

            function reverseGeocode(lt, ln) {
                fetch('https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lt + '&lon=' + ln + '&zoom=10&addressdetails=1')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        var city = '', country = '';
                        if (data.address) {
                            city = data.address.city || data.address.town || data.address.village || '';
                            country = (data.address.country_code || '').toUpperCase();
                        }
                        updateCoordDisplays(lt, ln, city, country);
                    })
                    .catch(function() {
                        updateCoordDisplays(lt, ln, '', '');
                    });
            }

            function update(lt, ln) {
                marker.setLatLng([lt, ln]);
                if (!map.hasLayer(marker)) marker.addTo(map);
                reverseGeocode(lt, ln);
            }

            map.on('click', function(e) { update(e.latlng.lat, e.latlng.lng); });
            marker.on('dragend', function(e) {
                var pos = e.target.getLatLng();
                update(pos.lat, pos.lng);
            });

            // Address search using Nominatim
            var addressInput = document.getElementById('addressInput');
            addressInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    var query = addressInput.value.trim();
                    if (!query) return;
                    fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(query) + '&limit=1')
                        .then(function(r) { return r.json(); })
                        .then(function(results) {
                            if (results.length > 0) {
                                var lt = parseFloat(results[0].lat);
                                var ln = parseFloat(results[0].lon);
                                map.setView([lt, ln], 16);
                                update(lt, ln);
                                if (results[0].display_name) addressInput.value = results[0].display_name;
                            }
                        });
                }
            });

            setTimeout(function() { map.invalidateSize(); }, 200);
        }

        // ─── Bootstrap ───
        window.initProfileMap = function() {
            if (useGoogleMaps && typeof google !== 'undefined') {
                initWithGoogle();
            } else if (typeof L !== 'undefined') {
                initWithLeaflet();
            }
        };

        // Timeout fallback: if Google Maps hasn't loaded after 4 seconds, use Leaflet
        setTimeout(function() {
            if (!useGoogleMaps && typeof L !== 'undefined' && !mapEl._leaflet_id) {
                initWithLeaflet();
            }
        }, 4000);
    })();
    </script>
</body>
</html>
