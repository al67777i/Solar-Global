<?php
/**
 * SolarGlobal — Database Column Name Constants
 * Single source of truth for all column name mappings.
 * Use these when writing SQL queries to avoid using stale column names.
 */

// ── INVERTERS TABLE ──────────────────────────────────────────────────────────
// Old name → Actual live DB column
// name         → model
// output_watts → output_power_w
// max_load_watts → output_power_w
// max_pv_input → max_pv_input_w
// input_voltage_min → min_pv_voltage
// input_voltage_max → max_pv_voltage
// surge_power_watts → surge_power_w
// price_pkr    → unit_price_usd
// has_bms      → bms (VARCHAR 'Yes'/'No')
// has_l3       → three_phase (VARCHAR 'Yes'/'No')
// parallel_capable → supports_parallel (VARCHAR 'Yes'/'No')
// country_origin → country
// vdc_type     → battery_voltage_range
// efficiency_percent → max_efficiency (may include % sign)

define('INV_ID',           'id');
define('INV_MODEL',        'model');
define('INV_COMPANY',      'company');
define('INV_TYPE',         'type');
define('INV_POWER_W',      'output_power_w');
define('INV_SURGE_W',      'surge_power_w');
define('INV_MAX_PV_W',     'max_pv_input_w');
define('INV_MIN_PV_V',     'min_pv_voltage');
define('INV_MAX_PV_V',     'max_pv_voltage');
define('INV_BAT_VR',       'battery_voltage_range');
define('INV_PRICE',        'unit_price_usd');
define('INV_BMS',          'bms');            // 'Yes'/'No'
define('INV_3PHASE',       'three_phase');    // 'Yes'/'No'
define('INV_PARALLEL',     'supports_parallel'); // 'Yes'/'No'
define('INV_EFFICIENCY',   'max_efficiency'); // may include '%'
define('INV_WARRANTY',     'warranty_years');
define('INV_MPPT',         'mppt_count');
define('INV_COUNTRY',      'country');
define('INV_ACTIVE',       'is_active');

// ── BATTERIES TABLE ──────────────────────────────────────────────────────────
// name         → model
// company      → brand  (NOT company!)
// voltage      → nominal_voltage
// price_pkr    → price_unit_usd
// has_bms      → is_bms (VARCHAR 'Yes'/'No')
// dod          → depth_of_discharge (DECIMAL, stored as 0-100)
// temperature_range → operating_temp
// country_origin → country  (NOT country_origin!)

define('BAT_ID',           'id');
define('BAT_MODEL',        'model');
define('BAT_BRAND',        'brand');           // NOT 'company'!
define('BAT_TYPE',         'type');
define('BAT_VOLTAGE',      'nominal_voltage');
define('BAT_AH',           'capacity_ah');
define('BAT_KWH',          'energy_capacity_kwh');
define('BAT_DOD',          'depth_of_discharge'); // stored as 0-100
define('BAT_BMS',          'is_bms');          // 'Yes'/'No'
define('BAT_PRICE',        'price_unit_usd');
define('BAT_WARRANTY',     'warranty_years');
define('BAT_CYCLES',       'cycle_life');
define('BAT_TEMP',         'operating_temp');
define('BAT_CHARGE_A',     'charging_current_max');
define('BAT_COUNTRY',      'country');         // NOT 'country_origin'!
define('BAT_ACTIVE',       'is_active');

// ── PANELS TABLE ─────────────────────────────────────────────────────────────
// watt_peak    → wattage
// price_pkr    → price_usd
// efficiency_percent → efficiency
// name stays as 'name' for panels (NOT model)
// country_origin stays as 'country_origin' for panels

define('PAN_ID',           'id');
define('PAN_NAME',         'name');            // stays 'name' for panels
define('PAN_WATTAGE',      'wattage');         // NOT watt_peak
define('PAN_VOC',          'voc');
define('PAN_VMP',          'vmp');
define('PAN_ISC',          'isc');
define('PAN_PRICE',        'price_usd');       // NOT price_pkr
define('PAN_TYPE',         'panel_type');
define('PAN_EFFICIENCY',   'efficiency');      // NOT efficiency_percent
define('PAN_TEMP_COEFF',   'temperature_coefficient');
define('PAN_WARRANTY',     'warranty_years');
define('PAN_COUNTRY',      'country_origin'); // panels DO use country_origin
define('PAN_ACTIVE',       'is_active');
