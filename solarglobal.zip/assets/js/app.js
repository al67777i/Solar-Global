/**
 * Main Application Logic
 * Handles step navigation, state management, and CSRF token
 * WITH STATE PERSISTENCE (localStorage)
 */

// Application state
window.appState = {
    currentStep: 0,
    usageType: 'residential',
    selectedCity: null,
    selectedAppliances: [],
    totalWatts: 0,
    dailyKwh: 0,
    recommendations: null,
    selectedInverter: null,
    selectedSystem: null,
    selectedCategory: null,
    manualLoad: null
};

// CSRF Token
window.csrfToken = '';

/**
 * Save state to localStorage
 */
function saveState() {
    try {
        const stateToSave = {
            currentStep: window.appState.currentStep,
            selectedCity: window.appState.selectedCity,
            selectedAppliances: window.appState.selectedAppliances,
            totalWatts: window.appState.totalWatts,
            dailyKwh: window.appState.dailyKwh,
            recommendations: window.appState.recommendations,
            selectedSystem: window.appState.selectedSystem,
            selectedCategory: window.appState.selectedCategory,
            usageType: window.appState.usageType,
            manualLoad: window.appState.manualLoad,
            selectedPhase: window.appState.selectedPhase,
            timestamp: Date.now()
        };
        localStorage.setItem('solarRecommenderState', JSON.stringify(stateToSave));

    } catch (error) {
        console.error('❌ Failed to save state:', error);
    }
}

/**
 * Load state from localStorage
 */
function loadState() {
    try {
        const savedState = localStorage.getItem('solarRecommenderState');
        if (!savedState) {

            return false;
        }
        
        const state = JSON.parse(savedState);
        
        // Check if state is not too old (24 hours)
        const age = Date.now() - (state.timestamp || 0);
        if (age > 24 * 60 * 60 * 1000) {

            clearState();
            return false;
        }
        
        // Restore state
        window.appState.currentStep = state.currentStep ?? 0;
        window.appState.selectedCity = state.selectedCity || null;
        window.appState.selectedAppliances = state.selectedAppliances || [];
        window.appState.totalWatts = state.totalWatts || 0;
        window.appState.dailyKwh = state.dailyKwh || 0;
        window.appState.recommendations = state.recommendations || null;
        window.appState.selectedSystem = state.selectedSystem || null;
        window.appState.selectedCategory = state.selectedCategory || null;
        window.appState.usageType = state.usageType || 'residential';
        window.appState.manualLoad = state.manualLoad || null;
        window.appState.selectedPhase = state.selectedPhase || 1;




        return true;
    } catch (error) {
        console.error('❌ Failed to load state:', error);
        clearState();
        return false;
    }
}

/**
 * Clear saved state
 */
function clearState() {
    try {
        localStorage.removeItem('solarRecommenderState');

    } catch (error) {
        console.error('❌ Failed to clear state:', error);
    }
}

/**
 * Handle Start Over button click
 * - On Step 4 (last page): Start over WITHOUT confirmation
 * - On other steps: Ask for confirmation first
 */
window.handleStartOver = function() {
    const currentStep = window.appState.currentStep;

    // Step 0 (nothing selected yet): just reload
    if (currentStep === 0) {
        performStartOver();
        return;
    }

    // Show custom dialog
    const dialog = document.getElementById('startover-dialog');
    if (dialog) {
        dialog.style.display = 'flex';
    } else {
        performStartOver();
    }
};

window.closeStartOverDialog = function() {
    const dialog = document.getElementById('startover-dialog');
    if (dialog) dialog.style.display = 'none';
};

window.confirmStartOver = function() {
    const dialog = document.getElementById('startover-dialog');
    if (dialog) dialog.style.display = 'none';
    performStartOver();
};

/**
 * Perform the actual start over action
 */
function performStartOver() {
    clearState();
    try {
        localStorage.removeItem('selectedCityId');
        localStorage.removeItem('selectedCityName');
    } catch (e) { /* Ignore localStorage errors (e.g. incognito mode) */ }
    window.appState = {
        currentStep: 0,
        selectedCity: null,
        selectedAppliances: [],
        totalWatts: 0,
        dailyKwh: 0,
        recommendations: null,
        selectedInverter: null,
        selectedSystem: null,
        selectedCategory: null
    };
    location.reload();
}

/**
 * Legacy function for backward compatibility
 */
window.resetApplication = function() {
    window.handleStartOver();
};

/**
 * Initialize CSRF token from server
 */
async function initCSRF() {
    const maxRetries = 3;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const response = await fetch('api/get_csrf_token.php');
            const data = await response.json();

            if (data.success) {
                window.csrfToken = data.csrf_token;

                return; // Success — exit
            } else {
                console.warn(`CSRF attempt ${attempt}/${maxRetries} failed:`, data);
            }
        } catch (error) {
            console.warn(`CSRF attempt ${attempt}/${maxRetries} error:`, error.message);
        }

        // Wait before retry (500ms, 1s, 1.5s)
        if (attempt < maxRetries) {
            await new Promise(r => setTimeout(r, attempt * 500));
        }
    }

    // All retries failed — show error but don't block the app
    console.error('CSRF token failed after all retries');
    showGlobalError('Connection issue detected. Some features may not work. Please refresh if needed.');
}

/**
 * Show global error message
 */
function showGlobalError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: #EF4444;
        color: white;
        padding: 16px 24px;
        border-radius: 8px;
        z-index: 10000;
        font-weight: 600;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;
    errorDiv.innerHTML = `
        ⚠️ ${message}
        <button onclick="this.parentElement.remove()" style="
            background: none;
            border: none;
            color: white;
            margin-left: 12px;
            cursor: pointer;
            font-size: 18px;
        ">×</button>
    `;
    document.body.appendChild(errorDiv);
    
    // Auto-remove after 10 seconds
    setTimeout(() => {
        if (errorDiv.parentElement) {
            errorDiv.remove();
        }
    }, 10000);
}

/**
 * Usage Type Selection (Residential / Commercial / Industrial)
 */
window.selectUsageType = function(type) {
    window.appState.usageType = type;

    // Update active card
    document.querySelectorAll('.usage-type-card').forEach(card => {
        card.classList.toggle('active', card.dataset.type === type);
    });

    const residentialSection = document.getElementById('residential-appliance-section');
    const manualSection = document.getElementById('manual-load-section');

    if (type === 'residential') {
        if (residentialSection) residentialSection.style.display = '';
        if (manualSection) manualSection.style.display = 'none';
    } else {
        if (residentialSection) residentialSection.style.display = 'none';
        if (manualSection) manualSection.style.display = 'block';
        // Industrial defaults to 3-phase
        if (type === 'industrial') {
            selectPhase(3);
        }
        // Initialize interactive load graph
        if (typeof initLoadGraph === 'function') initLoadGraph();
    }

    if (typeof saveState === 'function') saveState();
};

window.selectPhase = function(phase) {
    document.querySelectorAll('.phase-btn').forEach(btn => {
        btn.classList.toggle('active', parseInt(btn.dataset.phase) === phase);
    });
    window.appState.selectedPhase = phase;
};

// ─── Interactive 24-Hour Load Graph (D3) ──────────────────────────────────
window._hourlyLoadKw = new Array(24).fill(0); // kW per hour

window.initLoadGraph = function() {
    const container = document.getElementById('mli-hourly-graph');
    if (!container) return;

    container.innerHTML = '';
    const maxKw = 100; // max Y-axis kW (auto-scales)

    for (let h = 0; h < 24; h++) {
        const isNight = (h >= 18 || h < 6);
        const bar = document.createElement('div');
        bar.className = `mli-bar ${isNight ? 'mli-bar-night' : 'mli-bar-day'}`;
        bar.dataset.hour = h;
        bar.style.height = '0%';

        const label = document.createElement('span');
        label.className = 'mli-bar-label';
        label.textContent = '0';
        bar.appendChild(label);

        const hourLabel = document.createElement('span');
        hourLabel.className = 'mli-bar-hour';
        hourLabel.textContent = h.toString().padStart(2, '0');
        bar.appendChild(hourLabel);

        container.appendChild(bar);

        // Drag interaction
        let isDragging = false;
        const startDrag = (e) => {
            isDragging = true;
            e.preventDefault();
            updateBarFromEvent(e, bar, h, container);
        };
        const moveDrag = (e) => {
            if (!isDragging) return;
            e.preventDefault();
            updateBarFromEvent(e, bar, h, container);
        };
        const endDrag = () => { isDragging = false; };

        bar.addEventListener('mousedown', startDrag);
        bar.addEventListener('touchstart', startDrag, { passive: false });
        document.addEventListener('mousemove', moveDrag);
        document.addEventListener('touchmove', moveDrag, { passive: false });
        document.addEventListener('mouseup', endDrag);
        document.addEventListener('touchend', endDrag);
    }

    // Apply initial values from peak load + operating hours
    updateGraphFromHours();
};

function updateBarFromEvent(e, bar, hour, container) {
    const rect = container.getBoundingClientRect();
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    const relY = Math.max(0, Math.min(1, 1 - (clientY - rect.top) / rect.height));

    // Snap to 0.5 kW increments; max 500 kW
    const maxKw = parseFloat(document.getElementById('mli-peak-load')?.value) || 50;
    const scaledMax = Math.max(maxKw * 1.5, 10); // allow dragging above entered peak
    let kw = Math.round(relY * scaledMax * 2) / 2; // 0.5 increments
    kw = Math.max(0, kw);

    window._hourlyLoadKw[hour] = kw;
    const pct = scaledMax > 0 ? Math.min(100, (kw / scaledMax) * 100) : 0;
    bar.style.height = pct + '%';

    const label = bar.querySelector('.mli-bar-label');
    if (label) label.textContent = kw >= 1 ? kw.toFixed(0) : kw.toFixed(1);

    updateGraphStats();
}

window.updateGraphFromPeak = function() {
    updateGraphFromHours();
};

window.updateGraphFromHours = function() {
    const peakKw = parseFloat(document.getElementById('mli-peak-load')?.value) || 0;
    const opHours = parseInt(document.getElementById('mli-operating-hours')?.value) || 10;

    if (peakKw <= 0) return;

    // Distribute load: start at 7am for opHours, with a bell-curve shape
    const startHour = 7;
    window._hourlyLoadKw = new Array(24).fill(0);

    for (let i = 0; i < opHours && i < 24; i++) {
        const h = (startHour + i) % 24;
        // Bell curve: peak in middle, 60% at edges
        const mid = opHours / 2;
        const dist = Math.abs(i - mid) / mid;
        const factor = 0.6 + 0.4 * (1 - dist * dist); // parabolic
        window._hourlyLoadKw[h] = Math.round(peakKw * factor * 2) / 2;
    }

    refreshGraphBars();
    updateGraphStats();
};

function refreshGraphBars() {
    const container = document.getElementById('mli-hourly-graph');
    if (!container) return;

    const maxVal = Math.max(...window._hourlyLoadKw, 1);
    const scaledMax = maxVal * 1.2;
    const bars = container.querySelectorAll('.mli-bar');

    bars.forEach((bar, h) => {
        const kw = window._hourlyLoadKw[h] || 0;
        const pct = scaledMax > 0 ? Math.min(100, (kw / scaledMax) * 100) : 0;
        bar.style.height = pct + '%';
        const label = bar.querySelector('.mli-bar-label');
        if (label) label.textContent = kw >= 1 ? kw.toFixed(0) : (kw > 0 ? kw.toFixed(1) : '0');
    });
}

function updateGraphStats() {
    const totalKwh = window._hourlyLoadKw.reduce((sum, kw) => sum + kw, 0); // each bar = 1 hour
    const peakKw = Math.max(...window._hourlyLoadKw);

    const totalEl = document.getElementById('mli-total-kwh');
    const peakEl = document.getElementById('mli-peak-display');
    if (totalEl) totalEl.textContent = totalKwh.toFixed(1);
    if (peakEl) peakEl.textContent = peakKw.toFixed(1);
}

window.resetLoadGraph = function() {
    window._hourlyLoadKw = new Array(24).fill(0);
    refreshGraphBars();
    updateGraphStats();
};

window.flattenLoadGraph = function() {
    const total = window._hourlyLoadKw.reduce((s, v) => s + v, 0);
    const active = window._hourlyLoadKw.filter(v => v > 0).length || 1;
    const avg = Math.round((total / active) * 2) / 2;
    window._hourlyLoadKw = window._hourlyLoadKw.map(v => v > 0 ? avg : 0);
    refreshGraphBars();
    updateGraphStats();
};

window.submitManualLoad = function() {
    // Read from the interactive graph
    const hourlyLoad = window._hourlyLoadKw.map(kw => Math.round(kw * 1000)); // convert kW → W
    const totalKwh = window._hourlyLoadKw.reduce((s, v) => s + v, 0);
    const peakKw = Math.max(...window._hourlyLoadKw);
    const opHours = window._hourlyLoadKw.filter(v => v > 0).length;

    // Fallback: if graph wasn't used, try old fields
    const manualPeak = parseFloat(document.getElementById('mli-peak-load')?.value) || 0;

    if (peakKw <= 0 && manualPeak <= 0) {
        alert('Please set your peak load or drag the graph bars to define your hourly load.');
        return;
    }

    const effectivePeakW = Math.max(peakKw, manualPeak) * 1000;
    const effectiveKwh = totalKwh > 0 ? totalKwh : (manualPeak * opHours);
    const isThreePhase = window.appState.selectedPhase === 3;

    // Use graph hourly data (in watts) for hourlyUsage (1 = active, used as multiplier)
    const hourlyUsage = hourlyLoad.map(w => w > 0 ? 1 : 0);

    window.appState.manualLoad = {
        peak_watts: effectivePeakW,
        daily_kwh: effectiveKwh,
        operating_hours: opHours,
        three_phase: isThreePhase,
        hourly_load: hourlyLoad,
        usage_type: window.appState.usageType
    };

    window.appState.totalWatts = effectivePeakW;
    window.appState.dailyKwh = effectiveKwh;

    // Build synthetic appliance for the recommendation API
    window.appState.selectedAppliances = [{
        applianceId: 0,
        name_en: window.appState.usageType === 'industrial' ? 'Industrial Load' : 'Commercial Load',
        icon: window.appState.usageType === 'industrial' ? '🏭' : '🏢',
        watt_typical: effectivePeakW,
        quantity: 1,
        hours: opHours,
        hourlyUsage: hourlyUsage,
        hourlyLoad: hourlyLoad,
        surge_load_watts: Math.round(effectivePeakW * 1.5),
        standby_watts: 0,
        loadFactor: 100,
        isManualLoad: true
    }];

    // Skip to step 2 (load review)
    if (typeof renderLoadReview === 'function') renderLoadReview();
    goToStep(2);
};

/**
 * Navigate to a specific step
 */
function goToStep(stepNumber) {
    // Hide all steps
    document.querySelectorAll('.step-content').forEach(el => {
        el.classList.remove('active');
    });

    // Auto-select smart system defaults on entering step 2
    if (stepNumber === 2) {
        if (typeof window.calculateAndApplySmartDefaults === 'function') {
            window.calculateAndApplySmartDefaults();
        }
    }

    // Show target step
    const targetStep = document.getElementById(`step-${stepNumber}`);
    if (targetStep) {
        targetStep.classList.add('active');
    }

    // Update step indicator (steps are 0-4)
    document.querySelectorAll('.step').forEach((el) => {
        const step = parseInt(el.dataset.step);
        if (step < stepNumber) {
            el.classList.add('completed');
            el.classList.remove('active');
            el.querySelector('.step-circle').innerHTML = '✓';
        } else if (step === stepNumber) {
            el.classList.add('active');
            el.classList.remove('completed');
            el.querySelector('.step-circle').innerHTML = step === 0 ? '📍' : step;
        } else {
            el.classList.remove('active', 'completed');
            el.querySelector('.step-circle').innerHTML = step === 0 ? '📍' : step;
        }
    });
    
    // Animate step transition (wrapped in try-catch for cPanel safety)
    try {
        if (typeof anime !== 'undefined' && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            anime({
                targets: targetStep,
                translateX: [100, 0],
                opacity: [0, 1],
                duration: 500,
                easing: 'easeOutCubic'
            });
            
            // Animate active step circle
            const activeCircle = document.querySelector('.step.active .step-circle');
            if (activeCircle) {
                anime({
                    targets: activeCircle,
                    scale: [1, 1.2, 1],
                    duration: 300,
                    easing: 'easeInOutBack'
                });
            }
        }
    } catch (e) {
        console.warn('Step animation skipped:', e.message);
    }
    
    window.appState.currentStep = stepNumber;

    // CRITICAL FIX: Update backup slider values when going to step 2
    if (stepNumber === 2) {
        setTimeout(() => {
            const slider = document.getElementById('backup-hours-slider');
            if (slider) slider.dispatchEvent(new Event('input'));
        }, 100);
    }

    // Show/hide floating widgets based on step
    if (typeof updateFabVisibility === 'function') updateFabVisibility(stepNumber);
    const catNav = document.getElementById('fab-category-nav');
    if (catNav) catNav.style.display = (stepNumber === 3) ? 'flex' : 'none';

    // CRITICAL: Save state after navigation
    saveState();

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Show loading overlay
 */
function showLoading() {
    document.getElementById('loading-overlay').classList.remove('hidden');
}

/**
 * Hide loading overlay
 */
function hideLoading() {
    document.getElementById('loading-overlay').classList.add('hidden');
}

/**
 * Format number as USD currency
 */
function formatUSD(amount) {
    return 'USD ' + Number(amount).toLocaleString('en-PK', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });
}

/**
 * Initialize app
 */
document.addEventListener('DOMContentLoaded', async () => {
    // Initialize CSRF token first
    await initCSRF();
    
    // CRITICAL: Try to restore saved state
    const stateRestored = loadState();
    
    if (stateRestored) {

        // Restore to saved step
        const savedStep = window.appState.currentStep;

        if (savedStep === 0) {
            goToStep(0);
        } else if (savedStep === 1 && window.appState.selectedCity) {
            goToStep(1);
            setTimeout(() => {
                if (typeof renderSelectedAppliances === 'function') renderSelectedAppliances();
                if (typeof updateLoadTotals === 'function') updateLoadTotals();
            }, 200);
        } else if (savedStep === 2 && window.appState.selectedAppliances.length > 0) {
            renderLoadReview();
            goToStep(2);
        } else if (savedStep === 3 && window.appState.recommendations) {
            if (typeof renderV7Categories === 'function') {
                renderV7Categories(window.appState.recommendations);
            }
            goToStep(3);
        } else if (savedStep === 4 && window.appState.selectedSystem) {
            if (typeof initializeConfigurator === 'function' && window.appState.recommendations) {
                const allOptions = window.appState.recommendations.categories.flatMap(c => c.options);
                initializeConfigurator(
                    window.appState.selectedSystem,
                    window.appState.recommendations.load_analysis,
                    allOptions
                );
                goToStep(4);
            } else {
                goToStep(3);
            }
        } else {
            goToStep(0);
        }

        // Show restoration message
        if (savedStep > 0) showRestorationMessage(savedStep);
    } else {
        // No saved state, start fresh at city selection
        goToStep(0);
    }
    
    // Animate hero on load (wrapped in try-catch for cPanel safety)
    try {
        if (typeof anime !== 'undefined' && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            anime({
                targets: '.hero-title, .hero-subtitle',
                opacity: [0, 1],
                translateY: [20, 0],
                duration: 800,
                delay: anime.stagger(100),
                easing: 'easeOutQuart'
            });
            
            anime({
                targets: '.feature-pill',
                opacity: [0, 1],
                translateY: [20, 0],
                duration: 600,
                delay: anime.stagger(80, {start: 400}),
                easing: 'easeOutQuart'
            });
        }
    } catch (e) {
        console.warn('Hero animation skipped:', e.message);
    }
    
    // Setup button handlers
    document.getElementById('btn-calculate')?.addEventListener('click', () => {
        if (Object.keys(window.appState.selectedAppliances).length === 0) {
            alert(t('error_no_appliances'));
            return;
        }
        renderLoadReview();
        saveState(); // Save before navigation
        goToStep(2);
    });
    
    document.getElementById('btn-back-to-step1')?.addEventListener('click', () => {
        goToStep(1);
    });
    
    document.getElementById('btn-find-system')?.addEventListener('click', () => {
        findSolarSystem(); // Use new V2 function
    });
});

/**
 * Show restoration message
 */
function showRestorationMessage(step) {
    const stepNames = {
        0: 'City Selection',
        1: 'Appliance Selection',
        2: 'Load Review',
        3: 'Recommendations',
        4: 'System Configuration'
    };
    
    const message = document.createElement('div');
    message.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        background: linear-gradient(135deg, #10B981 0%, #059669 100%);
        color: white;
        padding: 16px 24px;
        border-radius: 12px;
        z-index: 10000;
        font-weight: 600;
        box-shadow: 0 4px 16px rgba(16, 185, 129, 0.3);
        animation: slideInRight 0.5s ease-out;
    `;
    message.innerHTML = `
        <div style="display: flex; align-items: center; gap: 12px;">
            <span style="font-size: 24px;">✅</span>
            <div>
                <div style="font-size: 14px; margin-bottom: 4px;">Session Restored</div>
                <div style="font-size: 12px; opacity: 0.9;">Continuing from: ${stepNames[step]}</div>
            </div>
            <button onclick="window.resetApplication()" style="
                background: rgba(255,255,255,0.2);
                border: none;
                color: white;
                padding: 6px 12px;
                border-radius: 6px;
                cursor: pointer;
                font-size: 11px;
                font-weight: 700;
                margin-left: 8px;
            ">Start Over</button>
        </div>
    `;
    document.body.appendChild(message);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        message.style.animation = 'slideOutRight 0.5s ease-out';
        setTimeout(() => message.remove(), 500);
    }, 5000);
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

/**
 * Render Step 2: Load Review
 */
function renderLoadReview() {
    const container = document.getElementById('load-review-content');
    if (!container) return;
    
    const { totalWatts, dailyKwh, selectedAppliances } = window.appState;
    const recommendedWatts = Math.ceil(totalWatts * 1.2);
    const dailyUnits = dailyKwh; // 1 kWh = 1 Unit
    
    let voltageClass = '12V';
    if (recommendedWatts > 1440 && recommendedWatts <= 3600) {
        voltageClass = '24V';
    } else if (recommendedWatts > 3600) {
        voltageClass = '48V';
    }
    
    let gaugeClass = 'green';
    if (totalWatts > 1200 && totalWatts <= 3500) {
        gaugeClass = 'yellow';
    } else if (totalWatts > 3500) {
        gaugeClass = 'red';
    }
    
    const applianceCount = window.appState.selectedAppliances.length;
    
    container.innerHTML = `
        <div class="load-gauge ${gaugeClass}">
            <div class="gauge-bar">
                <div class="gauge-fill" style="width: ${Math.min((totalWatts / 5000) * 100, 100)}%"></div>
            </div>
            <div class="gauge-label">${totalWatts} W</div>
        </div>
        
        <div class="summary-grid">
            <div class="summary-item">
                <div class="summary-label">${t('total_load')}</div>
                <div class="summary-value">${totalWatts} W</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">${t('recommended_voltage')}</div>
                <div class="summary-value">${voltageClass}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">${t('estimated_daily')}</div>
                <div class="summary-value">${dailyKwh.toFixed(2)} kWh</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">${t('daily_units')}</div>
                <div class="summary-value highlight-units">${dailyUnits.toFixed(2)} Units</div>
            </div>
        </div>
        
        <p class="safety-note">${t('safety_buffer')}</p>
        
        <div class="appliance-breakdown">
            <h3>${t('load_breakdown_title') || 'Detailed Load Breakdown'}</h3>
            <div class="table-wrapper">
                <table class="breakdown-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>${t('appliance') || 'Appliance'}</th>
                            <th>${t('hours_per_day') || 'Hours/Day'}</th>
                            <th>${t('power') || 'Power'}</th>
                            <th>${t('daily_usage') || 'Daily kWh'}</th>
                            <th class="units-column">${t('units_per_day') || 'Units/Day'}</th>
                        </tr>
                    </thead>
                    <tbody id="breakdown-tbody"></tbody>
                </table>
            </div>
        </div>
    `;
    
    // Populate breakdown table (will be filled by appliance-selector.js)
    window.populateBreakdownTable?.();
}

/**
 * Find recommendations via API
 */
async function findRecommendations() {
    showLoading();
    
    const appliances = window.appState.selectedAppliances.map(item => ({
        id: item.applianceId,
        quantity: 1,
        hours: item.hours
    }));
    
    try {
        const response = await fetch('api/recommend.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                appliances: appliances,
                csrf_token: window.csrfToken
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            window.appState.recommendations = data;
            renderRecommendations(data);
            goToStep(3);
        } else {
            // Handle different error types
            let errorMessage = data.message || t('error_loading');
            
            if (data.error === 'csrf_invalid') {
                errorMessage = 'Security token expired. Please refresh the page and try again.';
            } else if (data.error === 'no_match') {
                errorMessage = 'No suitable solar systems found for your load. Please contact SolarGlobal for a custom solution.';
            }
            
            alert(errorMessage);
        }
    } catch (error) {
        console.error('Recommendation error:', error);
        alert('Unable to connect to server. Please check your internet connection and try again.');
    } finally {
        hideLoading();
    }
}
