<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/csrf.php';
require_once '../includes/helpers.php';

$db = getDB();
$message = '';
$error = '';
$showForm = false;
$editData = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid token';
    } else {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'add' || $action === 'edit') {
            $id = intval($_POST['id'] ?? 0);
            $name_en = trim($_POST['name_en'] ?? '');
            
            $icon = trim($_POST['icon'] ?? '');
            $watt_typical = intval($_POST['watt_typical'] ?? 0);
            $category = trim($_POST['category'] ?? 'General');
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            if (empty($name_en)) {
                $error = 'English name required';
            } else {
                $image_path = $_POST['existing_image'] ?? null;
                if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                    $upload_result = handle_image_upload($_FILES['image'], '../uploads/appliances/');
                    if ($upload_result['success']) {
                        $image_path = $upload_result['path'];
                    }
                }
                
                // Also get name_ur
                $name_ur = trim($_POST['name_ur'] ?? '');

                if ($action === 'add') {
                    $stmt = $db->prepare("INSERT INTO appliances (name_en, name_ur, icon, image_path, watt_typical, category, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$name_en, $name_ur, $icon, $image_path, $watt_typical, $category, $is_active]);
                    $message = 'Appliance added successfully!';
                } else {
                    $stmt = $db->prepare("UPDATE appliances SET name_en = ?, name_ur = ?, icon = ?, image_path = ?, watt_typical = ?, category = ?, is_active = ? WHERE id = ?");
                    $stmt->execute([$name_en, $name_ur, $icon, $image_path, $watt_typical, $category, $is_active, $id]);
                    $message = 'Appliance updated successfully!';
                }
            }
        } elseif ($action === 'delete') {
            $id = intval($_POST['id'] ?? 0);
            $db->prepare("DELETE FROM appliances WHERE id = ?")->execute([$id]);
            $message = 'Appliance deleted successfully!';
        } elseif ($action === 'show_add') {
            $showForm = true;
        } elseif ($action === 'show_edit') {
            $showForm = true;
            $id = intval($_POST['id'] ?? 0);
            $stmt = $db->prepare("SELECT * FROM appliances WHERE id = ?");
            $stmt->execute([$id]);
            $editData = $stmt->fetch();
        }
    }
}

$appliances = $db->query("SELECT * FROM appliances ORDER BY category ASC, name_en ASC")->fetchAll();

$pageTitle = "Appliances";
include 'includes/header.php';
?>

<style>
.form-container { background: white; padding: 30px; margin-bottom: 20px; border-radius: 8px; border: 2px solid #3b82f6; }
</style>

<?php if ($message): ?>
    <div class="alert alert-success"><?= sanitize($message) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-error"><?= sanitize($error) ?></div>
<?php endif; ?>

<?php if ($showForm): ?>
<div class="form-container">
    <h2><?= $editData ? 'Edit Appliance' : 'Add New Appliance' ?></h2>
    <form method="POST" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $editData ? 'edit' : 'add' ?>">
        <?php if ($editData): ?>
            <input type="hidden" name="id" value="<?= $editData['id'] ?>">
            <input type="hidden" name="existing_image" value="<?= $editData['image_path'] ?? '' ?>">
        <?php endif; ?>
        
        <div class="form-group">
            <label>English Name *</label>
            <input type="text" name="name_en" value="<?= sanitize($editData['name_en'] ?? '') ?>" required>
        </div>
        
        <div class="form-group">
            <label>Urdu Name (اردو نام) *</label>
            <input type="text" name="name_ur" value="<?= sanitize($editData['name_ur'] ?? '') ?>" required style="font-family: 'Noto Nastaliq Urdu', serif; direction: rtl;">
        </div>
        
        <div class="form-group">
            <label>Icon (Emoji) *</label>
            <input type="text" name="icon" value="<?= sanitize($editData['icon'] ?? '') ?>" required placeholder="🌀">
            <small>Use an emoji character (will be shown if no image uploaded)</small>
        </div>
        
        <div class="form-group">
            <label>Appliance Image (Optional)</label>
            <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
            <small>Upload appliance image. If no image, emoji will be shown. Max 2MB. JPG, PNG, or WebP</small>
            <?php if ($editData && $editData['image_path']): ?>
                <div style="margin-top: 10px;">
                    <img src="<?= sanitize($editData['image_path']) ?>" style="width:80px;height:80px;object-fit:contain;border:1px solid #ddd;padding:5px;border-radius:4px;">
                    <p style="font-size:12px;color:#64748b;">Current image</p>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="form-group">
            <label>Typical Wattage *</label>
            <input type="number" name="watt_typical" value="<?= $editData['watt_typical'] ?? '' ?>" required>
        </div>
        
        <div class="form-group">
            <label>Category *</label>
            <select name="category" required>
                <option value="Cooling" <?= ($editData['category'] ?? '') == 'Cooling' ? 'selected' : '' ?>>Cooling</option>
                <option value="Lighting" <?= ($editData['category'] ?? '') == 'Lighting' ? 'selected' : '' ?>>Lighting</option>
                <option value="Kitchen" <?= ($editData['category'] ?? '') == 'Kitchen' ? 'selected' : '' ?>>Kitchen</option>
                <option value="Laundry" <?= ($editData['category'] ?? '') == 'Laundry' ? 'selected' : '' ?>>Laundry</option>
                <option value="Utility" <?= ($editData['category'] ?? '') == 'Utility' ? 'selected' : '' ?>>Utility</option>
                <option value="Electronics" <?= ($editData['category'] ?? '') == 'Electronics' ? 'selected' : '' ?>>Electronics</option>
                <option value="Entertainment" <?= ($editData['category'] ?? '') == 'Entertainment' ? 'selected' : '' ?>>Entertainment</option>
                <option value="Security" <?= ($editData['category'] ?? '') == 'Security' ? 'selected' : '' ?>>Security</option>
                <option value="Water Heating" <?= ($editData['category'] ?? '') == 'Water Heating' ? 'selected' : '' ?>>Water Heating</option>
                <option value="Ventilation" <?= ($editData['category'] ?? '') == 'Ventilation' ? 'selected' : '' ?>>Ventilation</option>
                <option value="Appliances" <?= ($editData['category'] ?? '') == 'Appliances' ? 'selected' : '' ?>>Appliances</option>
                <option value="General" <?= ($editData['category'] ?? 'General') == 'General' ? 'selected' : '' ?>>General</option>
            </select>
        </div>
        
        <div class="form-group">
            <label><input type="checkbox" name="is_active" <?= ($editData['is_active'] ?? 1) ? 'checked' : '' ?>> Active</label>
        </div>
        
        <div class="action-buttons">
            <button type="submit" class="btn btn-primary">Save Appliance</button>
            <a href="appliances.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php else: ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
        <h2>All Appliances (<?= count($appliances) ?>)</h2>
        <form method="POST" style="display: inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="show_add">
            <button type="submit" class="btn btn-primary">+ Add New Appliance</button>
        </form>
    </div>
    
    <table class="data-table">
        <thead>
            <tr>
                <th>Icon</th>
                <th>English Name</th>
                <th>Urdu Name</th>
                <th>Watts</th>
                <th>Category</th>
                <th>Active</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($appliances as $app): ?>
            <tr>
                <td style="font-size: 24px;">
                    <?php if ($app['image_path']): ?>
                        <img src="<?= sanitize($app['image_path']) ?>" style="width:40px;height:40px;object-fit:contain;">
                    <?php else: ?>
                        <?= $app['icon'] ?>
                    <?php endif; ?>
                </td>
                <td><strong><?= sanitize($app['name_en']) ?></strong></td>
                <td style="font-family: 'Noto Nastaliq Urdu', serif; direction: rtl;"><?= sanitize($app['name_ur']) ?></td>
                <td><?= $app['watt_typical'] ?>W</td>
                <td><span class="badge badge-blue"><?= sanitize($app['category']) ?></span></td>
                <td><?= $app['is_active'] ? '✓' : '✗' ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="show_edit">
                        <input type="hidden" name="id" value="<?= $app['id'] ?>">
                        <button type="submit" class="btn btn-secondary btn-sm">Edit</button>
                    </form>
                    <form method="POST" style="display:inline;" onsubmit="return confirm('Delete <?= sanitize($app['name_en']) ?>?');">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= $app['id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
