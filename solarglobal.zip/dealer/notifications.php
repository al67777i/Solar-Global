<?php
/**
 * Dealer Notifications — View and manage notifications
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';
require_once __DIR__ . '/../includes/notification_helpers.php';

set_security_headers();
require_dealer_login();

$dealer = get_dealer_profile();
$db = getDB();
$dealer_id = (int)$dealer['id'];

// Handle mark-all-read POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'mark_all_read') {
    mark_all_notifications_read('dealer', $dealer_id);
    header('Location: notifications.php');
    exit;
}

// Handle mark single read
if (isset($_GET['read'])) {
    $nid = (int)$_GET['read'];
    if ($nid > 0) {
        mark_notification_read($nid, 'dealer', $dealer_id);
        // Redirect to linked page if provided
        $notif = $db->prepare("SELECT link FROM notifications WHERE id = ? AND user_type = 'dealer' AND user_id = ?");
        $notif->execute([$nid, $dealer_id]);
        $link = $notif->fetchColumn();
        if ($link) {
            header('Location: ' . $link);
            exit;
        }
    }
    header('Location: notifications.php');
    exit;
}

// Pagination
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Fetch notifications
$total_stmt = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_type = 'dealer' AND user_id = ?");
$total_stmt->execute([$dealer_id]);
$total = (int)$total_stmt->fetchColumn();
$total_pages = max(1, (int)ceil($total / $per_page));

$notifications = get_notifications('dealer', $dealer_id, $per_page, $offset);
$unread_count = get_unread_notification_count('dealer', $dealer_id);

$pageTitle = 'Notifications';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - <?= sanitize($dealer['business_name']) ?> | <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        .notif-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 20px; flex-wrap: wrap; gap: 12px;
        }
        .notif-header h1 { font-size: 1.5rem; font-weight: 700; color: #1E293B; }
        .notif-header .unread-label {
            font-size: 0.875rem; color: #64748B;
        }
        .notif-header .unread-label strong { color: #EF4444; }

        .btn-mark-all {
            padding: 8px 18px; background: #F1F5F9; color: #475569;
            border: 1.5px solid #E2E8F0; border-radius: 8px; font-size: 0.8125rem;
            font-weight: 600; cursor: pointer; font-family: inherit;
        }
        .btn-mark-all:hover { background: #E2E8F0; }

        .notif-card {
            background: white; border-radius: 12px; overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
        }
        .notif-item {
            display: flex; align-items: flex-start; gap: 14px;
            padding: 16px 20px; border-bottom: 1px solid #F1F5F9;
            text-decoration: none; color: inherit; transition: background 0.15s;
            cursor: pointer;
        }
        .notif-item:last-child { border-bottom: none; }
        .notif-item:hover { background: #F8FAFC; }
        .notif-item.unread { background: #EFF6FF; border-left: 3px solid #3B82F6; }

        .notif-dot {
            width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0;
            margin-top: 5px;
        }
        .notif-dot.unread { background: #3B82F6; }
        .notif-dot.read { background: #CBD5E1; }

        .notif-body { flex: 1; min-width: 0; }
        .notif-title { font-size: 0.9rem; font-weight: 600; color: #1E293B; margin-bottom: 4px; }
        .notif-msg { font-size: 0.8125rem; color: #64748B; line-height: 1.5; }
        .notif-time { font-size: 0.75rem; color: #94A3B8; margin-top: 6px; }

        .notif-type-icon {
            width: 36px; height: 36px; border-radius: 8px; flex-shrink: 0;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.125rem;
        }
        .type-order { background: #DBEAFE; }
        .type-subscription { background: #FEF3C7; }
        .type-system { background: #F1F5F9; }

        .empty-state {
            text-align: center; padding: 60px 20px; color: #94A3B8;
        }
        .empty-state .icon { font-size: 3rem; margin-bottom: 12px; }
        .empty-state h4 { font-size: 1.125rem; color: #475569; margin-bottom: 6px; }

        .pagination {
            display: flex; justify-content: center; gap: 6px; margin-top: 20px;
        }
        .pg-btn {
            padding: 8px 14px; border-radius: 8px; border: 1.5px solid #E2E8F0;
            background: white; color: #475569; font-size: 0.875rem; font-weight: 500;
            text-decoration: none;
        }
        .pg-btn:hover { border-color: #F59E0B; }
        .pg-btn.active { background: #F59E0B; border-color: #F59E0B; color: white; }
    </style>
</head>
<body>
<?php $current_dealer_page = 'notifications'; include __DIR__ . '/includes/sidebar.php'; ?>

<main class="dlr-main-content">
    <div class="dlr-page-header">
        <div class="dlr-page-header-left">
            <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
            <div>
                <h1>&#128276; Notifications</h1>
            </div>
        </div>
    </div>

    <div class="notif-header">
        <div class="unread-label">
            <?php if ($unread_count > 0): ?>
                <strong><?= $unread_count ?></strong> unread notification<?= $unread_count !== 1 ? 's' : '' ?>
            <?php else: ?>
                All caught up!
            <?php endif; ?>
        </div>
        <?php if ($unread_count > 0): ?>
            <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="mark_all_read">
                <button type="submit" class="btn-mark-all">&#10003; Mark all as read</button>
            </form>
        <?php endif; ?>
    </div>

    <?php if (empty($notifications)): ?>
        <div class="empty-state">
            <div class="icon">&#128276;</div>
            <h4>No notifications yet</h4>
            <p>Notifications about orders, subscriptions, and more will appear here.</p>
        </div>
    <?php else: ?>
        <div class="notif-card">
            <?php foreach ($notifications as $n):
                $is_unread = !$n['is_read'];
                $icon_class = 'type-system';
                $icon = '&#128172;';
                if (str_starts_with($n['type'], 'order')) { $icon_class = 'type-order'; $icon = '&#128230;'; }
                elseif (str_starts_with($n['type'], 'subscription')) { $icon_class = 'type-subscription'; $icon = '&#128179;'; }
                $href = 'notifications.php?read=' . $n['id'];
                $time_diff = time() - strtotime($n['created_at']);
                if ($time_diff < 60) $time_str = 'Just now';
                elseif ($time_diff < 3600) $time_str = (int)floor($time_diff/60) . 'm ago';
                elseif ($time_diff < 86400) $time_str = (int)floor($time_diff/3600) . 'h ago';
                elseif ($time_diff < 604800) $time_str = (int)floor($time_diff/86400) . 'd ago';
                else $time_str = date('M j, Y', strtotime($n['created_at']));
            ?>
                <a href="<?= $href ?>" class="notif-item <?= $is_unread ? 'unread' : '' ?>">
                    <div class="notif-type-icon <?= $icon_class ?>"><?= $icon ?></div>
                    <div class="notif-body">
                        <div class="notif-title"><?= sanitize($n['title']) ?></div>
                        <div class="notif-msg"><?= sanitize($n['message']) ?></div>
                        <div class="notif-time"><?= $time_str ?></div>
                    </div>
                    <div class="notif-dot <?= $is_unread ? 'unread' : 'read' ?>"></div>
                </a>
            <?php endforeach; ?>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php for ($p = 1; $p <= $total_pages; $p++): ?>
                    <a href="?page=<?= $p ?>" class="pg-btn <?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</main>
</body>
</html>
