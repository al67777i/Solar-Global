<?php
/**
 * Migration: Create installation_appliances table
 * Run once: http://localhost/solarglobal/database/migration_installation_appliances.php
 */
require_once __DIR__ . '/../includes/db.php';

$db = getDB();

$queries = [
    'Create installation_appliances table' => "
        CREATE TABLE IF NOT EXISTS installation_appliances (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            category ENUM('breaker','wire','frame','mounting','connector',
                          'combiner_box','surge_protector','cable_tray','other') NOT NULL DEFAULT 'other',
            brand VARCHAR(150) NULL,
            specifications TEXT NULL,
            price_usd DECIMAL(10,2) NOT NULL DEFAULT 0,
            image_path VARCHAR(255) NULL,
            icon VARCHAR(50) DEFAULT '🔧',
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_category (category),
            INDEX idx_active (is_active),
            INDEX idx_brand (brand)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    'Create country_price_adjustments table' => "
        CREATE TABLE IF NOT EXISTS country_price_adjustments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            country_code VARCHAR(3) NOT NULL,
            product_type ENUM('inverter','battery','panel','installation') NOT NULL,
            markup_percent DECIMAL(5,2) DEFAULT 0,
            tax_percent DECIMAL(5,2) DEFAULT 0,
            shipping_flat_usd DECIMAL(8,2) DEFAULT 0,
            updated_by INT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uk_country_type (country_code, product_type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    'Add exchange_rate_to_usd to countries' => "
        ALTER TABLE countries ADD COLUMN IF NOT EXISTS exchange_rate_to_usd DECIMAL(12,6) DEFAULT 1.000000
    ",

    'Add sell_rate_kwh to countries' => "
        ALTER TABLE countries ADD COLUMN IF NOT EXISTS sell_rate_kwh DECIMAL(8,4) NULL AFTER electricity_rate_kwh
    ",
];

echo "<h1>SolarGlobal Phase 1 Migration</h1><pre>\n";

foreach ($queries as $label => $sql) {
    try {
        $db->exec($sql);
        echo "&#10004; $label\n";
    } catch (PDOException $e) {
        $msg = $e->getMessage();
        if (strpos($msg, 'Duplicate') !== false || strpos($msg, 'already exists') !== false) {
            echo "&#9197; $label (already exists)\n";
        } else {
            echo "&#10060; $label: $msg\n";
        }
    }
}

// Seed some common installation appliances
$seedData = [
    ['DC Circuit Breaker (32A)', 'breaker', 'Generic', '32A DC, 600V rated, DIN rail mount', 8.50, '&#9889;'],
    ['DC Circuit Breaker (63A)', 'breaker', 'Generic', '63A DC, 1000V rated, DIN rail mount', 12.00, '&#9889;'],
    ['AC Circuit Breaker (32A)', 'breaker', 'Generic', '32A AC, 230V rated, MCB', 5.50, '&#9889;'],
    ['AC Circuit Breaker (63A)', 'breaker', 'Generic', '63A AC, 230V rated, MCB', 8.00, '&#9889;'],
    ['DC Surge Protector (1000V)', 'surge_protector', 'Generic', 'Type II SPD, 1000V DC, 40kA', 25.00, '&#9889;'],
    ['AC Surge Protector (275V)', 'surge_protector', 'Generic', 'Type II SPD, 275V AC, 40kA', 18.00, '&#9889;'],
    ['PV Cable 4mm (per meter)', 'wire', 'Generic', '4mm2 solar cable, UV resistant, TUV certified', 0.45, '&#128268;'],
    ['PV Cable 6mm (per meter)', 'wire', 'Generic', '6mm2 solar cable, UV resistant, TUV certified', 0.65, '&#128268;'],
    ['Battery Cable 16mm (per meter)', 'wire', 'Generic', '16mm2 battery cable, flexible copper', 1.80, '&#128268;'],
    ['Battery Cable 25mm (per meter)', 'wire', 'Generic', '25mm2 battery cable, flexible copper', 2.50, '&#128268;'],
    ['AC Cable 4mm (per meter)', 'wire', 'Generic', '4mm2 3-core AC cable', 0.90, '&#128268;'],
    ['MC4 Connector Pair', 'connector', 'Generic', 'Male + Female MC4 connectors, IP67', 1.20, '&#128268;'],
    ['MC4 Y-Branch Pair', 'connector', 'Generic', '2-to-1 Y-branch MC4, IP67', 3.50, '&#128268;'],
    ['Aluminum Mounting Rail (2.1m)', 'mounting', 'Generic', '2100mm aluminum rail, anodized, 40x40mm', 12.00, '&#128296;'],
    ['Mid Clamp (pair)', 'mounting', 'Generic', 'Adjustable mid clamp 30-40mm, stainless steel', 1.50, '&#128296;'],
    ['End Clamp (pair)', 'mounting', 'Generic', 'Adjustable end clamp 30-40mm, stainless steel', 1.80, '&#128296;'],
    ['L-Bracket Roof Mount', 'mounting', 'Generic', 'Stainless steel L-bracket with rubber gasket', 3.00, '&#128296;'],
    ['Ground Mounting Frame (per panel)', 'frame', 'Generic', 'Galvanized steel ground frame, adjustable tilt 15-45 deg', 18.00, '&#128296;'],
    ['Roof Mounting Frame (per panel)', 'frame', 'Generic', 'Aluminum roof frame kit with flashing', 15.00, '&#128296;'],
    ['DC Combiner Box (4 strings)', 'combiner_box', 'Generic', '4-string input, fused, IP65 rated', 35.00, '&#128230;'],
    ['DC Combiner Box (8 strings)', 'combiner_box', 'Generic', '8-string input, fused, IP65 rated', 55.00, '&#128230;'],
    ['Cable Tray (1m)', 'cable_tray', 'Generic', 'Perforated cable tray 200mm, galvanized', 4.50, '&#128230;'],
    ['Cable Gland PG13.5', 'connector', 'Generic', 'Waterproof cable gland, IP68, 6-12mm', 0.80, '&#128268;'],
    ['Earth Grounding Kit', 'other', 'Generic', 'Copper ground rod + clamp + 10m wire', 15.00, '&#9889;'],
    ['DC Isolator Switch (32A)', 'other', 'Generic', '32A rotary DC isolator, 1000V, IP66', 14.00, '&#9889;'],
    ['AC Isolator Switch (63A)', 'other', 'Generic', '63A rotary AC isolator, 415V, IP66', 10.00, '&#9889;'],
];

$existingCount = $db->query("SELECT COUNT(*) FROM installation_appliances")->fetchColumn();
if ($existingCount == 0) {
    $stmt = $db->prepare("INSERT INTO installation_appliances (name, category, brand, specifications, price_usd, icon) VALUES (?, ?, ?, ?, ?, ?)");
    foreach ($seedData as $item) {
        $stmt->execute($item);
    }
    echo "\n&#10004; Seeded " . count($seedData) . " installation appliances\n";
} else {
    echo "\n&#9197; Skipped seeding ($existingCount items already exist)\n";
}

echo "\nDone! Phase 1 migration complete.\n</pre>";
