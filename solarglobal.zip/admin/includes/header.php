<?php
// Ensure helpers.php is loaded for sanitize(), get_image_url(), etc.
if (!function_exists('sanitize')) {
    require_once __DIR__ . '/../../includes/helpers.php';
}
$_site_name = get_system_setting('site_name', 'SolarGlobal');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Admin' ?> - <?= $_site_name ?> Admin</title>
    <meta name="robots" content="noindex, nofollow">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body">
    <div class="admin-layout">
        <!-- Sidebar -->
        <aside class="admin-sidebar" id="admin-sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <span class="logo-icon">☀️</span>
                    <div>
                        <h1><?= $_site_name ?></h1>
                        <p>Admin Panel</p>
                    </div>
                </div>
                <button class="sidebar-toggle" id="sidebar-toggle" aria-label="Toggle sidebar">✕</button>
            </div>

            <nav class="sidebar-nav">
                <div class="nav-section">
                    <span class="nav-section-title">Overview</span>
                    <a href="dashboard.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
                        <span class="nav-icon">📊</span><span>Dashboard</span>
                    </a>
                    <a href="traffic.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'traffic.php' ? 'active' : '' ?>">
                        <span class="nav-icon">📈</span><span>Traffic Analytics</span>
                    </a>
                </div>

                <div class="nav-section">
                    <span class="nav-section-title">Products</span>
                    <a href="companies.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'companies.php' ? 'active' : '' ?>">
                        <span class="nav-icon">🏢</span><span>Companies</span>
                    </a>
                    <a href="inverters.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'inverters.php' ? 'active' : '' ?>">
                        <span class="nav-icon">⚡</span><span>Inverters</span>
                    </a>
                    <a href="batteries.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'batteries.php' ? 'active' : '' ?>">
                        <span class="nav-icon">🔋</span><span>Batteries</span>
                    </a>
                    <a href="panels.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'panels.php' ? 'active' : '' ?>">
                        <span class="nav-icon">☀️</span><span>Solar Panels</span>
                    </a>
                    <a href="appliances.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'appliances.php' ? 'active' : '' ?>">
                        <span class="nav-icon">🏠</span><span>Appliances</span>
                    </a>
                    <a href="installation-appliances.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'installation-appliances.php' ? 'active' : '' ?>">
                        <span class="nav-icon">🔌</span><span>Installation Items</span>
                    </a>
                </div>

                <div class="nav-section">
                    <span class="nav-section-title">Import & Data</span>
                    <a href="import.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'import.php' ? 'active' : '' ?>">
                        <span class="nav-icon">📥</span><span>Import Products</span>
                    </a>
                    <a href="price-adjustments.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'price-adjustments.php' ? 'active' : '' ?>">
                        <span class="nav-icon">💰</span><span>Price Adjustments</span>
                    </a>
                    <a href="countries.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'countries.php' ? 'active' : '' ?>">
                        <span class="nav-icon">🌍</span><span>Countries</span>
                    </a>
                    <a href="image-library.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'image-library.php' ? 'active' : '' ?>">
                        <span class="nav-icon">🖼️</span><span>Image Library</span>
                    </a>
                </div>

                <div class="nav-section">
                    <span class="nav-section-title">Marketplace</span>
                    <a href="dealers.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'dealers.php' ? 'active' : '' ?>">
                        <span class="nav-icon">🏪</span><span>Dealers</span>
                    </a>
                    <a href="installers.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'installers.php' ? 'active' : '' ?>">
                        <span class="nav-icon">🔧</span><span>Installers</span>
                    </a>
                    <a href="product-requests.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'product-requests.php' ? 'active' : '' ?>">
                        <span class="nav-icon">📋</span><span>Product Requests</span>
                    </a>
                    <a href="reviews.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'reviews.php' ? 'active' : '' ?>">
                        <span class="nav-icon">⭐</span><span>Reviews</span>
                    </a>
                </div>

                <div class="nav-section">
                    <span class="nav-section-title">Marketing</span>
                    <a href="ads.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'ads.php' ? 'active' : '' ?>">
                        <span class="nav-icon">📢</span><span>Advertisements</span>
                    </a>
                    <a href="seo.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'seo.php' ? 'active' : '' ?>">
                        <span class="nav-icon">🔍</span><span>SEO Settings</span>
                    </a>
                </div>

                <div class="nav-section">
                    <span class="nav-section-title">System</span>
                    <a href="settings.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : '' ?>">
                        <span class="nav-icon">⚙️</span><span>Settings</span>
                    </a>
                    <a href="contact_messages.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'contact_messages.php' ? 'active' : '' ?>">
                        <span class="nav-icon">✉️</span><span>Messages</span>
                    </a>
                    <a href="data-management.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'data-management.php' ? 'active' : '' ?>">
                        <span class="nav-icon">🗑️</span><span>Data Management</span>
                    </a>
                </div>
            </nav>

            <div class="sidebar-footer">
                <a href="../index.php" target="_blank" class="btn btn-outline btn-sm">🌐 View Site</a>
                <a href="../logout.php" class="btn btn-danger btn-sm">Logout</a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="admin-main">
            <div class="admin-header">
                <button class="mobile-toggle" id="mobile-toggle" aria-label="Open menu">☰</button>
                <h1><?= $pageTitle ?? 'Admin Panel' ?></h1>
                <div class="admin-user">
                    <span class="user-avatar">👤</span>
                    <span><?= sanitize($_SESSION['admin_username'] ?? 'Admin') ?></span>
                </div>
            </div>

            <div class="admin-content">
