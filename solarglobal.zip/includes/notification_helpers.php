<?php
/**
 * Notification Helpers — Create and manage in-app notifications
 *
 * Tables: notifications (created in migration_031_notifications.php)
 *
 * User types: 'customer', 'dealer', 'installer'
 * Common types: 'order_placed', 'order_confirmed', 'order_ready', 'order_picked_up',
 *               'order_cancelled', 'subscription_expired', 'subscription_expiring',
 *               'subscription_urgent', 'store_hidden'
 */

/**
 * Insert a notification.
 *
 * @param string      $userType  'customer', 'dealer', or 'installer'
 * @param int         $userId    The user's ID
 * @param string      $type      Notification type identifier
 * @param string      $title     Short title
 * @param string      $message   Full message body
 * @param string|null $link      Optional link URL
 * @return bool
 */
function create_notification(string $userType, int $userId, string $type, string $title, string $message, ?string $link = null): bool {
    try {
        $db = getDB();
        $stmt = $db->prepare("
            INSERT INTO notifications (user_type, user_id, type, title, message, link, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        return $stmt->execute([$userType, $userId, $type, $title, $message, $link]);
    } catch (Exception $e) {
        error_log('Notification insert failed: ' . $e->getMessage());
        return false;
    }
}

/**
 * Get unread notification count for a user.
 *
 * @param string $userType
 * @param int    $userId
 * @return int
 */
function get_unread_notification_count(string $userType, int $userId): int {
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_type = ? AND user_id = ? AND is_read = 0");
        $stmt->execute([$userType, $userId]);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

/**
 * Get recent notifications for a user.
 *
 * @param string $userType
 * @param int    $userId
 * @param int    $limit
 * @param int    $offset
 * @return array
 */
function get_notifications(string $userType, int $userId, int $limit = 20, int $offset = 0): array {
    try {
        $db = getDB();
        $stmt = $db->prepare("
            SELECT * FROM notifications
            WHERE user_type = ? AND user_id = ?
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$userType, $userId, $limit, $offset]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Mark a single notification as read.
 *
 * @param int    $notificationId
 * @param string $userType
 * @param int    $userId
 * @return bool
 */
function mark_notification_read(int $notificationId, string $userType, int $userId): bool {
    try {
        $db = getDB();
        $stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_type = ? AND user_id = ?");
        return $stmt->execute([$notificationId, $userType, $userId]);
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Mark all notifications as read for a user.
 *
 * @param string $userType
 * @param int    $userId
 * @return bool
 */
function mark_all_notifications_read(string $userType, int $userId): bool {
    try {
        $db = getDB();
        $stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE user_type = ? AND user_id = ? AND is_read = 0");
        return $stmt->execute([$userType, $userId]);
    } catch (Exception $e) {
        return false;
    }
}
