<?php
/**
 * Installer Registration Page
 * Solar installers can register their services on SolarGlobal
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/installer_auth.php';
require_once __DIR__ . '/../includes/email_verification.php';

set_security_headers();

// If already logged in, go to dashboard
if (is_installer_logged_in()) {
    header('Location: /solarglobal/installer/dashboard.php');
    exit();
}

$errors = [];
$success = false;
$form_data = [
    'business_name' => '',
    'owner_name' => '',
    'email' => '',
    'phone' => '',
    'about' => '',
    'license_number' => '',
    'years_experience' => '',
    'team_size' => '',
    'price_per_kw' => '',
    'service_radius' => '50',
    'latitude' => '',
    'longitude' => '',
    'city' => '',
    'region' => '',
    'country_code' => '',
    'specializations' => [],
];

// Fetch countries for dropdown
$db = getDB();
$countries = [];
try {
    $stmt = $db->query("SELECT code, name FROM countries ORDER BY name ASC");
    $countries = $stmt->fetchAll();
} catch (Exception $e) {
    // countries table might not exist yet
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please try again.';
    } elseif (!validate_honeypot('website_url')) {
        $errors[] = 'Submission rejected.';
    } else {
        // Collect form data
        $form_data['business_name'] = trim($_POST['business_name'] ?? '');
        $form_data['owner_name'] = trim($_POST['owner_name'] ?? '');
        $form_data['email'] = strtolower(trim($_POST['email'] ?? ''));
        $form_data['phone'] = trim($_POST['phone'] ?? '');
        $form_data['about'] = trim($_POST['about'] ?? '');
        $form_data['license_number'] = trim($_POST['license_number'] ?? '');
        $form_data['years_experience'] = (int)($_POST['years_experience'] ?? 0);
        $form_data['team_size'] = (int)($_POST['team_size'] ?? 1);
        $form_data['price_per_kw'] = trim($_POST['price_per_kw'] ?? '');
        $form_data['service_radius'] = (int)($_POST['service_radius'] ?? 50);
        $form_data['latitude'] = trim($_POST['latitude'] ?? '');
        $form_data['longitude'] = trim($_POST['longitude'] ?? '');
        $form_data['city'] = trim($_POST['city'] ?? '');
        $form_data['region'] = trim($_POST['region'] ?? '');
        $form_data['country_code'] = trim($_POST['country_code'] ?? '');
        $form_data['specializations'] = $_POST['specializations'] ?? [];
        $password = $_POST['password'] ?? '';
        $password_confirm = $_POST['password_confirm'] ?? '';

        // Validation
        if (empty($form_data['business_name'])) $errors[] = 'Business name is required.';
        if (strlen($form_data['business_name']) > 200) $errors[] = 'Business name too long (max 200 chars).';

        if (empty($form_data['owner_name'])) $errors[] = 'Owner name is required.';
        if (strlen($form_data['owner_name']) > 150) $errors[] = 'Owner name too long (max 150 chars).';

        if (empty($form_data['email'])) {
            $errors[] = 'Email is required.';
        } elseif (!filter_var($form_data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if (empty($password)) {
            $errors[] = 'Password is required.';
        } elseif (strlen($password) < 8) {
            $errors[] = 'Password must be at least 8 characters.';
        } elseif (!preg_match('/[A-Z]/', $password)) {
            $errors[] = 'Password must contain at least one uppercase letter.';
        } elseif (!preg_match('/[0-9]/', $password)) {
            $errors[] = 'Password must contain at least one number.';
        }

        if ($password !== $password_confirm) {
            $errors[] = 'Passwords do not match.';
        }

        if (empty($form_data['latitude']) || empty($form_data['longitude'])) {
            $errors[] = 'Please select your location on the map.';
        }

        if (empty($form_data['license_number'])) {
            $errors[] = 'License number is required.';
        }

        // Validate specializations
        $valid_specs = ['Residential', 'Commercial', 'Industrial', 'Off-Grid', 'On-Grid', 'Hybrid'];
        $form_data['specializations'] = array_intersect($form_data['specializations'], $valid_specs);

        // Check duplicate email
        if (empty($errors)) {
            $stmt = $db->prepare("SELECT id FROM installers WHERE email = ?");
            $stmt->execute([$form_data['email']]);
            if ($stmt->fetch()) {
                $errors[] = 'An account with this email already exists. <a href="login.php">Login instead?</a>';
            }
        }

        // Handle logo upload
        $logo_path = null;
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['logo'];
            $allowed_types = ['image/jpeg', 'image/png', 'image/webp'];
            $max_size = 2 * 1024 * 1024; // 2MB

            if (!in_array($file['type'], $allowed_types)) {
                $errors[] = 'Logo must be JPG, PNG, or WebP format.';
            } elseif ($file['size'] > $max_size) {
                $errors[] = 'Logo file must be under 2MB.';
            } else {
                $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                $filename = 'installer_logo_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                $upload_dir = __DIR__ . '/../uploads/installers/logos/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

                if (move_uploaded_file($file['tmp_name'], $upload_dir . $filename)) {
                    $logo_path = 'uploads/installers/logos/' . $filename;
                } else {
                    $errors[] = 'Failed to upload logo. Please try again.';
                }
            }
        }

        // Create account if no errors
        if (empty($errors)) {
            try {
                $password_hash = password_hash($password, PASSWORD_BCRYPT);
                $specializations_json = json_encode($form_data['specializations']);

                $stmt = $db->prepare("
                    INSERT INTO installers (email, password_hash, business_name, owner_name, phone,
                        about_text, license_number, years_experience, team_size, price_per_kw,
                        specializations, service_radius_km, latitude, longitude, city, region,
                        country_code, logo_path, status, subscription_plan, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'inactive', 'basic', NOW())
                ");
                $stmt->execute([
                    $form_data['email'],
                    $password_hash,
                    $form_data['business_name'],
                    $form_data['owner_name'],
                    $form_data['phone'],
                    $form_data['about'],
                    $form_data['license_number'],
                    $form_data['years_experience'],
                    $form_data['team_size'],
                    $form_data['price_per_kw'],
                    $specializations_json,
                    $form_data['service_radius'],
                    $form_data['latitude'],
                    $form_data['longitude'],
                    $form_data['city'],
                    $form_data['region'],
                    $form_data['country_code'],
                    $logo_path,
                ]);

                $installer_id = $db->lastInsertId();

                // Email verification check
                if (is_email_verification_required()) {
                    $code = generate_verification_code();
                    store_verification_code($form_data['email'], $code, 'registration');
                    send_verification_email($form_data['email'], $code, $form_data['owner_name']);
                    $_SESSION['verify_email'] = $form_data['email'];
                    $_SESSION['verify_installer_id'] = $installer_id;
                    header('Location: /solarglobal/verify-email.php?email=' . urlencode($form_data['email']) . '&type=registration&role=installer');
                    exit();
                }

                // Auto-login after registration
                $installer = $db->prepare("SELECT * FROM installers WHERE id = ?");
                $installer->execute([$installer_id]);
                $installer_data = $installer->fetch();

                installer_login($installer_data);

                // Redirect to subscription page — account stays inactive until payment
                header('Location: /solarglobal/installer/subscription.php?new_account=1');
                exit();

            } catch (Exception $e) {
                error_log("Installer registration error: " . $e->getMessage());
                $errors[] = 'Registration failed. Please try again.';
            }
        }
    }
}

$current_page = 'register';
$page_title = 'Register as Solar Installer';
require_once __DIR__ . '/../includes/header.php';

$has_post_data = ($_SERVER['REQUEST_METHOD'] === 'POST');
?>

<?php
$maps_key = get_system_setting('google_maps_api_key', '');
// No hardcoded fallback — key must be set in Admin → Settings
?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
<script>
var useGoogleMaps = false;
function installerRegisterGmapsReady() { useGoogleMaps = true; if (window.initInstallerMap) window.initInstallerMap(); }
function gm_authFailure() { useGoogleMaps = false; if (window.initInstallerMap) window.initInstallerMap(); }
</script>
<script async src="https://maps.googleapis.com/maps/api/js?key=<?= sanitize($maps_key) ?>&libraries=places&callback=installerRegisterGmapsReady"></script>

<style>
/* ===== Installer Register Wizard ===== */
.ir-page-header {
    background: linear-gradient(135deg, #0D3B6E 0%, #1565C0 50%, #F59E0B 100%);
    padding: 40px 20px;
    text-align: center;
    color: white;
}
.ir-page-header h1 { font-size: 2rem; font-weight: 800; margin-bottom: 8px; }
.ir-page-header p { font-size: 1rem; opacity: 0.9; max-width: 600px; margin: 0 auto; }
.ir-page-header .back-link {
    display: inline-block; margin-bottom: 16px; color: rgba(255,255,255,0.8);
    text-decoration: none; font-size: 0.875rem;
}
.ir-page-header .back-link:hover { color: white; }

.ir-container {
    max-width: 800px; margin: -30px auto 40px; padding: 0 20px; position: relative; z-index: 1;
}

/* Step Indicator */
.ir-steps {
    display: flex; align-items: center; justify-content: center;
    gap: 0; margin-bottom: 32px; background: white;
    border-radius: 16px; padding: 20px 24px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
}
.ir-step-item {
    display: flex; align-items: center; gap: 10px; cursor: pointer;
    padding: 8px 12px; border-radius: 8px; transition: background 0.2s;
    flex-shrink: 0;
}
.ir-step-item:hover { background: #F8FAFC; }
.ir-step-num {
    width: 36px; height: 36px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 0.875rem; font-weight: 700; transition: all 0.3s;
    background: #E2E8F0; color: #64748B; flex-shrink: 0;
}
.ir-step-item.active .ir-step-num {
    background: #F59E0B; color: #1E293B;
}
.ir-step-item.completed .ir-step-num {
    background: #16A34A; color: white;
}
.ir-step-label {
    font-size: 0.8125rem; font-weight: 600; color: #94A3B8; transition: color 0.3s;
    white-space: nowrap;
}
.ir-step-item.active .ir-step-label { color: #1E293B; }
.ir-step-item.completed .ir-step-label { color: #16A34A; }
.ir-step-connector {
    flex: 1; height: 2px; background: #E2E8F0; min-width: 20px; margin: 0 4px;
    transition: background 0.3s;
}
.ir-step-connector.done { background: #16A34A; }

@media (max-width: 640px) {
    .ir-steps { padding: 16px 12px; gap: 0; }
    .ir-step-label { display: none; }
    .ir-step-item { padding: 6px; }
    .ir-step-connector { min-width: 16px; }
}

/* Form Card */
.ir-form-card {
    background: white; border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    padding: 40px; margin-bottom: 24px;
    display: none;
}
.ir-form-card.active { display: block; }
.ir-form-card h2 {
    font-size: 1.25rem; font-weight: 700; color: #0D3B6E;
    margin-bottom: 24px; padding-bottom: 12px;
    border-bottom: 2px solid #E2E8F0;
    display: flex; align-items: center; gap: 10px;
}
.ir-form-card h2 .step-num {
    background: #F59E0B; color: #1E293B; width: 32px; height: 32px;
    border-radius: 50%; display: flex; align-items: center; justify-content: center;
    font-size: 0.875rem; font-weight: 700; flex-shrink: 0;
}

/* Form layout */
.ir-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.ir-row-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; }
@media (max-width: 600px) {
    .ir-row, .ir-row-3 { grid-template-columns: 1fr; }
}

.ir-group { margin-bottom: 20px; }
.ir-group label {
    display: block; font-size: 0.875rem; font-weight: 600;
    color: #334155; margin-bottom: 6px;
}
.ir-group label .req { color: #DC2626; }
.ir-group input, .ir-group textarea, .ir-group select {
    width: 100%; padding: 12px 16px; border: 2px solid #E2E8F0;
    border-radius: 10px; font-size: 0.9375rem; font-family: inherit;
    transition: all 0.2s; background: #F8FAFC;
}
.ir-group input:focus, .ir-group textarea:focus, .ir-group select:focus {
    outline: none; border-color: #F59E0B;
    box-shadow: 0 0 0 3px rgba(245,158,11,0.15); background: white;
}
.ir-group textarea { resize: vertical; min-height: 100px; }
.ir-group .help-text { font-size: 0.8125rem; color: #64748B; margin-top: 4px; }
.ir-group .field-error { font-size: 0.8125rem; color: #DC2626; margin-top: 4px; display: none; }
.ir-group.has-error input,
.ir-group.has-error textarea,
.ir-group.has-error select { border-color: #DC2626; }
.ir-group.has-error .field-error { display: block; }

/* Checkboxes */
.ir-checkbox-grid {
    display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;
}
@media (max-width: 600px) { .ir-checkbox-grid { grid-template-columns: 1fr 1fr; } }
.ir-checkbox-item {
    display: flex; align-items: center; gap: 8px;
    padding: 10px 14px; border: 2px solid #E2E8F0; border-radius: 8px;
    cursor: pointer; transition: all 0.2s; font-size: 0.875rem;
}
.ir-checkbox-item:hover { border-color: #F59E0B; background: #FFFBEB; }
.ir-checkbox-item input:checked + span { color: #D97706; font-weight: 600; }
.ir-checkbox-item:has(input:checked) { border-color: #F59E0B; background: #FFFBEB; }

/* Range slider */
.ir-range-wrap { display: flex; align-items: center; gap: 16px; }
.ir-range-wrap input[type="range"] {
    flex: 1; padding: 0; border: none; background: transparent;
    -webkit-appearance: none; height: 6px;
}
.ir-range-wrap input[type="range"]::-webkit-slider-track {
    background: #E2E8F0; border-radius: 3px; height: 6px;
}
.ir-range-wrap input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none; width: 20px; height: 20px;
    background: #F59E0B; border-radius: 50%; cursor: pointer; margin-top: -7px;
}
.ir-range-val {
    min-width: 60px; text-align: center; font-weight: 700;
    color: #F59E0B; font-size: 1rem;
}

/* Map */
.ir-map-container {
    width: 100%; height: 300px; border-radius: 12px;
    border: 2px solid #E2E8F0; overflow: hidden; margin-bottom: 8px;
}
.ir-coords {
    display: flex; gap: 16px; font-size: 0.8125rem; color: #64748B;
}
.ir-coords span { background: #F1F5F9; padding: 4px 10px; border-radius: 6px; }

/* Logo upload */
.ir-logo-upload {
    border: 2px dashed #CBD5E1; border-radius: 12px;
    padding: 30px; text-align: center; cursor: pointer;
    transition: all 0.2s; background: #F8FAFC;
}
.ir-logo-upload:hover { border-color: #F59E0B; background: #FFFBEB; }
.ir-logo-upload input { display: none; }
.ir-logo-upload .upload-icon { font-size: 2rem; margin-bottom: 8px; }
.ir-logo-upload .upload-text { font-size: 0.875rem; color: #64748B; }
.ir-logo-upload .upload-text strong { color: #F59E0B; }
.ir-logo-preview { max-width: 120px; max-height: 120px; border-radius: 8px; margin-top: 12px; display: none; }

/* Password strength */
.ir-pw-strength {
    height: 4px; border-radius: 2px; margin-top: 6px;
    background: #E2E8F0; overflow: hidden;
}
.ir-pw-strength .bar { height: 100%; border-radius: 2px; transition: all 0.3s; width: 0; }
.ir-pw-strength .bar.weak { width: 33%; background: #DC2626; }
.ir-pw-strength .bar.medium { width: 66%; background: #F59E0B; }
.ir-pw-strength .bar.strong { width: 100%; background: #16A34A; }

/* Buttons */
.ir-btn-row {
    display: flex; gap: 12px; margin-top: 8px;
}
.ir-btn-next, .ir-btn-submit {
    flex: 1; padding: 14px 24px; border: none; border-radius: 12px;
    font-size: 1rem; font-weight: 700; cursor: pointer;
    background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
    color: white; transition: all 0.3s;
    display: flex; align-items: center; justify-content: center; gap: 8px;
}
.ir-btn-next:hover, .ir-btn-submit:hover {
    transform: translateY(-2px); box-shadow: 0 8px 25px rgba(245,158,11,0.4);
}
.ir-btn-next:disabled, .ir-btn-submit:disabled {
    opacity: 0.6; cursor: not-allowed; transform: none; box-shadow: none;
}
.ir-btn-back {
    padding: 14px 24px; border: 2px solid #CBD5E1; border-radius: 12px;
    font-size: 1rem; font-weight: 600; cursor: pointer;
    background: white; color: #475569; transition: all 0.2s;
    display: flex; align-items: center; justify-content: center; gap: 8px;
}
.ir-btn-back:hover { border-color: #94A3B8; background: #F8FAFC; }

/* Review section */
.ir-review {
    margin-top: 28px; border-top: 2px solid #E2E8F0; padding-top: 24px;
}
.ir-review h3 {
    font-size: 1.1rem; font-weight: 700; color: #0D3B6E; margin-bottom: 20px;
}
.ir-review-section {
    background: #F8FAFC; border-radius: 12px; padding: 16px 20px; margin-bottom: 16px;
}
.ir-review-section-head {
    display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;
}
.ir-review-section-head h4 {
    font-size: 0.9375rem; font-weight: 700; color: #0D3B6E; margin: 0;
}
.ir-review-edit {
    font-size: 0.8125rem; color: #F59E0B; font-weight: 600; cursor: pointer;
    text-decoration: none; border: none; background: none; padding: 4px 8px;
    border-radius: 6px; transition: background 0.2s;
}
.ir-review-edit:hover { background: #FEF3C7; }
.ir-review-row {
    display: flex; gap: 8px; margin-bottom: 6px; font-size: 0.875rem;
}
.ir-review-label { color: #64748B; min-width: 130px; flex-shrink: 0; }
.ir-review-value { color: #1E293B; font-weight: 500; word-break: break-word; }

/* Error list */
.ir-error-list {
    background: #FEF2F2; border: 1px solid #FECACA; border-radius: 12px;
    padding: 16px 20px; margin-bottom: 24px; border-left: 4px solid #DC2626;
}
.ir-error-list h3 { font-size: 0.9375rem; color: #991B1B; margin-bottom: 8px; }
.ir-error-list ul { margin: 0; padding-left: 20px; }
.ir-error-list li { font-size: 0.875rem; color: #7F1D1D; margin-bottom: 4px; }

/* Benefits bar */
.ir-benefits {
    display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
    gap: 16px; margin-bottom: 32px;
}
.ir-benefit {
    background: white; border-radius: 12px; padding: 20px; text-align: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}
.ir-benefit .b-icon { font-size: 1.5rem; margin-bottom: 8px; }
.ir-benefit .b-title { font-weight: 700; font-size: 0.875rem; color: #0F172A; }
.ir-benefit .b-desc { font-size: 0.8125rem; color: #64748B; margin-top: 4px; }

/* Login link */
.ir-login-bar {
    text-align: center; margin-top: 24px; font-size: 0.9375rem; color: #64748B;
}
.ir-login-bar a { color: #F59E0B; font-weight: 600; text-decoration: none; }
.ir-login-bar a:hover { text-decoration: underline; }
</style>

<div class="ir-page-header">
    <a href="/solarglobal/index.php" class="back-link">&larr; Back to <?= get_system_setting('site_name', 'SolarGlobal') ?></a>
    <h1>Register as Solar Installer</h1>
    <p>Join our network of certified solar installers. Get matched with customers in your area and grow your installation business.</p>
</div>

<div class="ir-container">
    <!-- Benefits Bar -->
    <div class="ir-benefits">
        <div class="ir-benefit">
            <div class="b-icon">&#128205;</div>
            <div class="b-title">Local Leads</div>
            <div class="b-desc">Get matched with nearby customers</div>
        </div>
        <div class="ir-benefit">
            <div class="b-icon">&#11088;</div>
            <div class="b-title">Build Reputation</div>
            <div class="b-desc">Collect reviews and ratings</div>
        </div>
        <div class="ir-benefit">
            <div class="b-icon">&#128200;</div>
            <div class="b-title">Grow Business</div>
            <div class="b-desc">Showcase your portfolio</div>
        </div>
        <div class="ir-benefit">
            <div class="b-icon">&#128176;</div>
            <div class="b-title">Free Listing</div>
            <div class="b-desc">No monthly fees to get started</div>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="ir-error-list">
            <h3>Please fix the following errors:</h3>
            <ul>
                <?php foreach ($errors as $err): ?>
                    <li><?= $err ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Step Indicator -->
    <div class="ir-steps">
        <div class="ir-step-item active" data-target="1" onclick="goToStep(1)">
            <div class="ir-step-num">1</div>
            <span class="ir-step-label">Business Info</span>
        </div>
        <div class="ir-step-connector"></div>
        <div class="ir-step-item" data-target="2" onclick="goToStep(2)">
            <div class="ir-step-num">2</div>
            <span class="ir-step-label">Services</span>
        </div>
        <div class="ir-step-connector"></div>
        <div class="ir-step-item" data-target="3" onclick="goToStep(3)">
            <div class="ir-step-num">3</div>
            <span class="ir-step-label">Location</span>
        </div>
        <div class="ir-step-connector"></div>
        <div class="ir-step-item" data-target="4" onclick="goToStep(4)">
            <div class="ir-step-num">4</div>
            <span class="ir-step-label">Account</span>
        </div>
    </div>

    <form method="POST" action="" enctype="multipart/form-data" id="registerForm">
        <?= csrf_field() ?>
        <?= render_honeypot_field('website_url') ?>

        <!-- ===== STEP 1: Business Information ===== -->
        <div class="ir-form-card active" data-step="1">
            <h2><span class="step-num">1</span> Business Information</h2>
            <div class="ir-row">
                <div class="ir-group" id="grp-business_name">
                    <label>Business Name <span class="req">*</span></label>
                    <input type="text" name="business_name" id="business_name" value="<?= sanitize($form_data['business_name']) ?>" maxlength="200" placeholder="e.g., SunTech Installations">
                    <div class="field-error">Business name is required.</div>
                </div>
                <div class="ir-group" id="grp-owner_name">
                    <label>Owner Full Name <span class="req">*</span></label>
                    <input type="text" name="owner_name" id="owner_name" value="<?= sanitize($form_data['owner_name']) ?>" maxlength="150" placeholder="e.g., John Smith">
                    <div class="field-error">Owner name is required.</div>
                </div>
            </div>
            <div class="ir-row">
                <div class="ir-group">
                    <label>Phone Number</label>
                    <input type="tel" name="phone" id="phone" value="<?= sanitize($form_data['phone']) ?>" maxlength="30" placeholder="e.g., +1 555 123 4567">
                </div>
                <div class="ir-group" id="grp-license_number">
                    <label>License Number <span class="req">*</span></label>
                    <input type="text" name="license_number" id="license_number" value="<?= sanitize($form_data['license_number']) ?>" maxlength="100" placeholder="Installation license/certification #">
                    <div class="field-error">License number is required.</div>
                </div>
            </div>
            <div class="ir-group">
                <label>About Your Business</label>
                <textarea name="about" id="about" maxlength="1000" placeholder="Tell customers about your installation services, experience, and what sets you apart..."><?= sanitize($form_data['about']) ?></textarea>
                <div class="help-text">Max 1000 characters. This appears on your public profile.</div>
            </div>
            <div class="ir-group">
                <label>Company Logo</label>
                <div class="ir-logo-upload" onclick="document.getElementById('logoInput').click()">
                    <input type="file" name="logo" id="logoInput" accept="image/jpeg,image/png,image/webp">
                    <div class="upload-icon">&#128247;</div>
                    <div class="upload-text"><strong>Click to upload</strong> your company logo<br>JPG, PNG, WebP - Max 2MB</div>
                    <img id="logoPreview" class="ir-logo-preview" alt="Logo preview">
                </div>
            </div>
            <div class="ir-btn-row">
                <button type="button" class="ir-btn-next" onclick="nextStep(1)">Continue to Services &#8594;</button>
            </div>
        </div>

        <!-- ===== STEP 2: Services & Experience ===== -->
        <div class="ir-form-card" data-step="2">
            <h2><span class="step-num">2</span> Services &amp; Experience</h2>
            <div class="ir-row-3">
                <div class="ir-group">
                    <label>Years of Experience</label>
                    <input type="number" name="years_experience" id="years_experience" value="<?= (int)$form_data['years_experience'] ?>" min="0" max="50" placeholder="e.g., 5">
                </div>
                <div class="ir-group">
                    <label>Team Size</label>
                    <input type="number" name="team_size" id="team_size" value="<?= (int)$form_data['team_size'] ?>" min="1" max="500" placeholder="e.g., 10">
                </div>
                <div class="ir-group">
                    <label>Price per kW (USD)</label>
                    <input type="number" name="price_per_kw" id="price_per_kw" value="<?= sanitize($form_data['price_per_kw']) ?>" min="0" step="0.01" placeholder="e.g., 850">
                    <div class="help-text">Average installation charge</div>
                </div>
            </div>

            <div class="ir-group">
                <label>Specializations</label>
                <div class="ir-checkbox-grid">
                    <?php
                    $specs = ['Residential', 'Commercial', 'Industrial', 'Off-Grid', 'On-Grid', 'Hybrid'];
                    foreach ($specs as $spec):
                    ?>
                    <label class="ir-checkbox-item">
                        <input type="checkbox" name="specializations[]" value="<?= $spec ?>"
                            <?= in_array($spec, $form_data['specializations']) ? 'checked' : '' ?>>
                        <span><?= $spec ?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="ir-group">
                <label>Service Radius: <span id="radiusValue"><?= (int)$form_data['service_radius'] ?></span> km</label>
                <div class="ir-range-wrap">
                    <span style="font-size:0.8125rem;color:#64748B">10km</span>
                    <input type="range" name="service_radius" id="serviceRadius" min="10" max="200" step="5"
                           value="<?= (int)$form_data['service_radius'] ?>">
                    <span style="font-size:0.8125rem;color:#64748B">200km</span>
                    <span class="ir-range-val" id="radiusDisplay"><?= (int)$form_data['service_radius'] ?> km</span>
                </div>
            </div>

            <div class="ir-btn-row">
                <button type="button" class="ir-btn-back" onclick="goToStep(1)">&#8592; Back</button>
                <button type="button" class="ir-btn-next" onclick="nextStep(2)">Continue to Location &#8594;</button>
            </div>
        </div>

        <!-- ===== STEP 3: Service Location ===== -->
        <div class="ir-form-card" data-step="3">
            <h2><span class="step-num">3</span> Service Location</h2>
            <div class="ir-row">
                <div class="ir-group">
                    <label>Country <span class="req">*</span></label>
                    <select name="country_code" id="countrySelect">
                        <option value="">Select Country</option>
                        <?php foreach ($countries as $c): ?>
                            <option value="<?= sanitize($c['code']) ?>" <?= $form_data['country_code'] === $c['code'] ? 'selected' : '' ?>>
                                <?= sanitize($c['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="ir-group">
                    <label>City</label>
                    <input type="text" name="city" id="cityField" value="<?= sanitize($form_data['city']) ?>" maxlength="100" placeholder="Your city">
                </div>
            </div>
            <div class="ir-group">
                <label>Region / State</label>
                <input type="text" name="region" id="regionField" value="<?= sanitize($form_data['region']) ?>" maxlength="100" placeholder="State or province">
            </div>
            <div class="ir-group" id="grp-location">
                <label>Pin Your Location on the Map <span class="req">*</span></label>
                <div style="margin-bottom:10px">
                    <input type="text" id="addressInput" placeholder="Search for your address..." style="width:100%;padding:12px 16px;border:2px solid #E2E8F0;border-radius:10px;font-size:0.9375rem;font-family:inherit;">
                </div>
                <div class="ir-map-container" id="installerMap"></div>
                <div class="ir-coords">
                    <span id="latDisplay">Lat: --</span>
                    <span id="lngDisplay">Lng: --</span>
                </div>
                <input type="hidden" name="latitude" id="latInput" value="<?= sanitize($form_data['latitude']) ?>">
                <input type="hidden" name="longitude" id="lngInput" value="<?= sanitize($form_data['longitude']) ?>">
                <div class="help-text">Click on the map or drag the marker to set your primary service location.</div>
                <div class="field-error">Please select your location on the map.</div>
            </div>

            <div class="ir-btn-row">
                <button type="button" class="ir-btn-back" onclick="goToStep(2)">&#8592; Back</button>
                <button type="button" class="ir-btn-next" onclick="nextStep(3)">Continue to Account &#8594;</button>
            </div>
        </div>

        <!-- ===== STEP 4: Account & Review ===== -->
        <div class="ir-form-card" data-step="4">
            <h2><span class="step-num">4</span> Account &amp; Review</h2>

            <div class="ir-group" id="grp-email">
                <label>Email Address <span class="req">*</span></label>
                <input type="email" name="email" id="email" value="<?= sanitize($form_data['email']) ?>" maxlength="255" placeholder="your@email.com">
                <div class="help-text">This will be your login email and used for notifications.</div>
                <div class="field-error">Please enter a valid email address.</div>
            </div>
            <div class="ir-row">
                <div class="ir-group" id="grp-password">
                    <label>Password <span class="req">*</span></label>
                    <input type="password" name="password" id="passwordInput" minlength="8" placeholder="Min 8 chars, 1 uppercase, 1 number">
                    <div class="ir-pw-strength"><div class="bar" id="pwBar"></div></div>
                    <div class="field-error">Min 8 chars, at least 1 uppercase letter and 1 number.</div>
                </div>
                <div class="ir-group" id="grp-password_confirm">
                    <label>Confirm Password <span class="req">*</span></label>
                    <input type="password" name="password_confirm" id="passwordConfirm" minlength="8" placeholder="Re-enter password">
                    <div class="field-error">Passwords do not match.</div>
                </div>
            </div>

            <!-- Review Summary -->
            <div class="ir-review">
                <h3>Review Your Details</h3>

                <!-- Business Info Review -->
                <div class="ir-review-section">
                    <div class="ir-review-section-head">
                        <h4>Business Information</h4>
                        <button type="button" class="ir-review-edit" onclick="goToStep(1)">Edit</button>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Business Name:</span>
                        <span class="ir-review-value" id="rev-business_name">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Owner:</span>
                        <span class="ir-review-value" id="rev-owner_name">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Phone:</span>
                        <span class="ir-review-value" id="rev-phone">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">License #:</span>
                        <span class="ir-review-value" id="rev-license_number">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">About:</span>
                        <span class="ir-review-value" id="rev-about">--</span>
                    </div>
                </div>

                <!-- Services Review -->
                <div class="ir-review-section">
                    <div class="ir-review-section-head">
                        <h4>Services &amp; Experience</h4>
                        <button type="button" class="ir-review-edit" onclick="goToStep(2)">Edit</button>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Years Experience:</span>
                        <span class="ir-review-value" id="rev-years_experience">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Team Size:</span>
                        <span class="ir-review-value" id="rev-team_size">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Price/kW:</span>
                        <span class="ir-review-value" id="rev-price_per_kw">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Specializations:</span>
                        <span class="ir-review-value" id="rev-specializations">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Service Radius:</span>
                        <span class="ir-review-value" id="rev-service_radius">--</span>
                    </div>
                </div>

                <!-- Location Review -->
                <div class="ir-review-section">
                    <div class="ir-review-section-head">
                        <h4>Service Location</h4>
                        <button type="button" class="ir-review-edit" onclick="goToStep(3)">Edit</button>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Country:</span>
                        <span class="ir-review-value" id="rev-country">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">City:</span>
                        <span class="ir-review-value" id="rev-city">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Region:</span>
                        <span class="ir-review-value" id="rev-region">--</span>
                    </div>
                    <div class="ir-review-row">
                        <span class="ir-review-label">Coordinates:</span>
                        <span class="ir-review-value" id="rev-coords">--</span>
                    </div>
                </div>
            </div>

            <div class="ir-btn-row" style="margin-top:24px">
                <button type="button" class="ir-btn-back" onclick="goToStep(3)">&#8592; Back</button>
                <button type="submit" class="ir-btn-submit" id="submitBtn">&#9889; Register as Installer</button>
            </div>
        </div>
    </form>

    <div class="ir-login-bar">
        Already registered? <a href="login.php">Login to your dashboard</a>
    </div>
</div>

<script>
(function() {
    var currentStep = 1;
    var maxVisited = 1;
    var hasPostData = <?= $has_post_data ? 'true' : 'false' ?>;
    var hasErrors = <?= !empty($errors) ? 'true' : 'false' ?>;

    // ===== Step Navigation =====
    window.goToStep = function(n) {
        if (n < 1 || n > 4) return;
        // Only allow going to visited steps or the next one
        if (n > maxVisited + 1) return;

        currentStep = n;
        if (n > maxVisited) maxVisited = n;

        // Show/hide step cards
        document.querySelectorAll('.ir-form-card').forEach(function(card) {
            card.classList.toggle('active', parseInt(card.dataset.step) === n);
        });

        // Update step indicator
        document.querySelectorAll('.ir-step-item').forEach(function(item) {
            var target = parseInt(item.dataset.target);
            item.classList.remove('active', 'completed');
            if (target === n) item.classList.add('active');
            else if (target < n) item.classList.add('completed');
        });

        // Update connectors
        var connectors = document.querySelectorAll('.ir-step-connector');
        connectors.forEach(function(c, i) {
            c.classList.toggle('done', i < n - 1);
        });

        // If going to step 4, populate review
        if (n === 4) populateReview();

        // If going to step 3, trigger map resize
        if (n === 3 && window._installerMap) {
            setTimeout(function() {
                if (window._installerMap.invalidateSize) {
                    // Leaflet map
                    window._installerMap.invalidateSize();
                } else if (typeof google !== 'undefined' && google.maps && google.maps.event) {
                    // Google Map
                    google.maps.event.trigger(window._installerMap, 'resize');
                }
            }, 100);
        }

        // Scroll to top of form area
        document.querySelector('.ir-steps').scrollIntoView({ behavior: 'smooth', block: 'start' });
    };

    window.nextStep = function(fromStep) {
        if (!validateStep(fromStep)) return;
        goToStep(fromStep + 1);
    };

    // ===== Validation per step =====
    function validateStep(step) {
        clearErrors();
        var valid = true;

        if (step === 1) {
            if (!val('business_name')) { showErr('grp-business_name'); valid = false; }
            if (!val('owner_name')) { showErr('grp-owner_name'); valid = false; }
            if (!val('license_number')) { showErr('grp-license_number'); valid = false; }
        } else if (step === 2) {
            // No required fields
        } else if (step === 3) {
            if (!val('latInput') || !val('lngInput')) { showErr('grp-location'); valid = false; }
        } else if (step === 4) {
            var email = document.getElementById('email').value.trim();
            var pw = document.getElementById('passwordInput').value;
            var pc = document.getElementById('passwordConfirm').value;

            if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showErr('grp-email'); valid = false; }
            if (pw.length < 8 || !/[A-Z]/.test(pw) || !/[0-9]/.test(pw)) { showErr('grp-password'); valid = false; }
            if (pw !== pc) { showErr('grp-password_confirm'); valid = false; }
        }

        return valid;
    }

    function val(id) {
        var el = document.getElementById(id);
        return el && el.value.trim() !== '';
    }
    function showErr(grpId) {
        var g = document.getElementById(grpId);
        if (g) g.classList.add('has-error');
    }
    function clearErrors() {
        document.querySelectorAll('.ir-group.has-error').forEach(function(g) {
            g.classList.remove('has-error');
        });
    }

    // ===== Populate Review =====
    function populateReview() {
        setText('rev-business_name', val2('business_name'));
        setText('rev-owner_name', val2('owner_name'));
        setText('rev-phone', val2('phone') || 'Not provided');
        setText('rev-license_number', val2('license_number'));

        var about = val2('about');
        setText('rev-about', about ? (about.length > 120 ? about.substring(0, 120) + '...' : about) : 'Not provided');

        setText('rev-years_experience', val2('years_experience') || 'Not specified');
        setText('rev-team_size', val2('team_size') || 'Not specified');
        var ppk = val2('price_per_kw');
        setText('rev-price_per_kw', ppk ? ('$' + ppk) : 'Not specified');

        var checks = document.querySelectorAll('input[name="specializations[]"]:checked');
        var specList = [];
        checks.forEach(function(c) { specList.push(c.value); });
        setText('rev-specializations', specList.length ? specList.join(', ') : 'None selected');

        setText('rev-service_radius', val2('serviceRadius') + ' km');

        var cs = document.getElementById('countrySelect');
        var countryText = cs && cs.selectedIndex > 0 ? cs.options[cs.selectedIndex].text : 'Not selected';
        setText('rev-country', countryText);
        setText('rev-city', val2('cityField') || 'Not specified');
        setText('rev-region', val2('regionField') || 'Not specified');

        var lat = val2('latInput');
        var lng = val2('lngInput');
        setText('rev-coords', lat && lng ? (parseFloat(lat).toFixed(5) + ', ' + parseFloat(lng).toFixed(5)) : 'Not set');
    }

    function val2(id) {
        var el = document.getElementById(id);
        return el ? el.value.trim() : '';
    }
    function setText(id, text) {
        var el = document.getElementById(id);
        if (el) el.textContent = text;
    }

    // ===== Logo preview =====
    document.getElementById('logoInput').addEventListener('change', function(e) {
        var file = e.target.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(ev) {
                var preview = document.getElementById('logoPreview');
                preview.src = ev.target.result;
                preview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    });

    // ===== Password strength =====
    document.getElementById('passwordInput').addEventListener('input', function(e) {
        var pw = e.target.value;
        var bar = document.getElementById('pwBar');
        var score = 0;
        if (pw.length >= 8) score++;
        if (/[A-Z]/.test(pw)) score++;
        if (/[0-9]/.test(pw)) score++;
        if (/[^A-Za-z0-9]/.test(pw)) score++;

        bar.className = 'bar';
        if (score <= 1) bar.classList.add('weak');
        else if (score <= 2) bar.classList.add('medium');
        else bar.classList.add('strong');
    });

    // ===== Service radius slider =====
    document.getElementById('serviceRadius').addEventListener('input', function(e) {
        document.getElementById('radiusValue').textContent = e.target.value;
        document.getElementById('radiusDisplay').textContent = e.target.value + ' km';
    });

    // ===== Map (Google Maps with Leaflet fallback) =====
    (function() {
        var mapEl = document.getElementById('installerMap');
        if (!mapEl) return;

        var defaultLat = parseFloat(document.getElementById('latInput').value) || 25.0;
        var defaultLng = parseFloat(document.getElementById('lngInput').value) || 67.0;
        var hasExisting = !!document.getElementById('latInput').value;

        function updateCoordDisplays(lat, lng, city, country) {
            document.getElementById('latInput').value = lat.toFixed(7);
            document.getElementById('lngInput').value = lng.toFixed(7);
            document.getElementById('latDisplay').textContent = 'Lat: ' + lat.toFixed(5);
            document.getElementById('lngDisplay').textContent = 'Lng: ' + lng.toFixed(5);
            if (city) document.getElementById('cityField').value = city;
            if (country) {
                var sel = document.getElementById('countrySelect');
                if (sel) {
                    for (var i = 0; i < sel.options.length; i++) {
                        if (sel.options[i].value === country) {
                            sel.selectedIndex = i;
                            break;
                        }
                    }
                }
            }
        }

        // ─── Google Maps Path ───
        function initWithGoogle() {
            var map = new google.maps.Map(mapEl, {
                center: { lat: defaultLat, lng: defaultLng },
                zoom: hasExisting ? 14 : 3,
                mapTypeControl: false, streetViewControl: false, fullscreenControl: false,
            });
            window._installerMap = map;

            var marker = new google.maps.Marker({
                position: { lat: defaultLat, lng: defaultLng },
                map: map, draggable: true, title: 'Your Location',
            });
            marker.setVisible(hasExisting);

            var geocoder = new google.maps.Geocoder();

            function update(lat, lng) {
                marker.setPosition({ lat: lat, lng: lng });
                marker.setVisible(true);
                geocoder.geocode({ location: { lat: lat, lng: lng } }, function(results, status) {
                    if (status === 'OK' && results[0]) {
                        var city = '', country = '';
                        results[0].address_components.forEach(function(c) {
                            if (c.types.includes('locality')) city = c.long_name;
                            if (c.types.includes('country')) country = c.short_name;
                        });
                        updateCoordDisplays(lat, lng, city, country);
                    } else {
                        updateCoordDisplays(lat, lng, '', '');
                    }
                });
            }

            map.addListener('click', function(e) { update(e.latLng.lat(), e.latLng.lng()); });
            marker.addListener('dragend', function(e) { update(e.latLng.lat(), e.latLng.lng()); });

            var addressInput = document.getElementById('addressInput');
            var autocomplete = new google.maps.places.Autocomplete(addressInput, {
                types: ['establishment', 'geocode']
            });
            autocomplete.bindTo('bounds', map);
            autocomplete.addListener('place_changed', function() {
                var place = autocomplete.getPlace();
                if (place.geometry && place.geometry.location) {
                    var lat = place.geometry.location.lat();
                    var lng = place.geometry.location.lng();
                    map.setCenter({ lat: lat, lng: lng }); map.setZoom(16);
                    update(lat, lng);
                }
            });

            // IP-based country detection (only on fresh load, not POST)
            if (!hasPostData && !hasExisting) {
                fetch('https://ip-api.com/json/?fields=status,country,countryCode,city,lat,lon')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.status === 'success') {
                            if (data.countryCode) {
                                var sel = document.getElementById('countrySelect');
                                if (sel) {
                                    for (var i = 0; i < sel.options.length; i++) {
                                        if (sel.options[i].value === data.countryCode) { sel.selectedIndex = i; break; }
                                    }
                                }
                            }
                            if (data.city) document.getElementById('cityField').value = data.city;
                            if (data.lat && data.lon) { map.setCenter({ lat: data.lat, lng: data.lon }); map.setZoom(6); }
                        }
                    }).catch(function() {});
            }

            if (!hasExisting && !hasPostData && navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(pos) {
                    if (!document.getElementById('latInput').value) {
                        map.setCenter({ lat: pos.coords.latitude, lng: pos.coords.longitude }); map.setZoom(12);
                    }
                }, function() {}, { timeout: 5000 });
            }
        }

        // ─── Leaflet Fallback Path ───
        function initWithLeaflet() {
            var map = L.map(mapEl, {
                center: [defaultLat, defaultLng],
                zoom: hasExisting ? 14 : 3
            });
            window._installerMap = map;

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors',
                maxZoom: 19
            }).addTo(map);

            var marker = L.marker([defaultLat, defaultLng], { draggable: true });
            if (hasExisting) marker.addTo(map);

            function reverseGeocode(lt, ln) {
                fetch('https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lt + '&lon=' + ln + '&zoom=10&addressdetails=1')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        var city = '', country = '';
                        if (data.address) {
                            city = data.address.city || data.address.town || data.address.village || '';
                            country = (data.address.country_code || '').toUpperCase();
                        }
                        updateCoordDisplays(lt, ln, city, country);
                    })
                    .catch(function() {
                        updateCoordDisplays(lt, ln, '', '');
                    });
            }

            function update(lt, ln) {
                marker.setLatLng([lt, ln]);
                if (!map.hasLayer(marker)) marker.addTo(map);
                reverseGeocode(lt, ln);
            }

            map.on('click', function(e) { update(e.latlng.lat, e.latlng.lng); });
            marker.on('dragend', function(e) {
                var pos = e.target.getLatLng();
                update(pos.lat, pos.lng);
            });

            // Address search using Nominatim
            var addressInput = document.getElementById('addressInput');
            addressInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    var query = addressInput.value.trim();
                    if (!query) return;
                    fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(query) + '&limit=1')
                        .then(function(r) { return r.json(); })
                        .then(function(results) {
                            if (results.length > 0) {
                                var lt = parseFloat(results[0].lat);
                                var ln = parseFloat(results[0].lon);
                                map.setView([lt, ln], 16);
                                update(lt, ln);
                                if (results[0].display_name) addressInput.value = results[0].display_name;
                            }
                        });
                }
            });

            // IP-based country detection (only on fresh load, not POST)
            if (!hasPostData && !hasExisting) {
                fetch('https://ip-api.com/json/?fields=status,country,countryCode,city,lat,lon')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.status === 'success') {
                            if (data.countryCode) {
                                var sel = document.getElementById('countrySelect');
                                if (sel) {
                                    for (var i = 0; i < sel.options.length; i++) {
                                        if (sel.options[i].value === data.countryCode) { sel.selectedIndex = i; break; }
                                    }
                                }
                            }
                            if (data.city) document.getElementById('cityField').value = data.city;
                            if (data.lat && data.lon) { map.setView([data.lat, data.lon], 6); }
                        }
                    }).catch(function() {});
            }

            if (!hasExisting && !hasPostData && navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(pos) {
                    if (!document.getElementById('latInput').value) {
                        map.setView([pos.coords.latitude, pos.coords.longitude], 12);
                    }
                }, function() {}, { timeout: 5000 });
            }

            setTimeout(function() { map.invalidateSize(); }, 200);
        }

        // ─── Bootstrap ───
        window.initInstallerMap = function() {
            if (useGoogleMaps && typeof google !== 'undefined') {
                initWithGoogle();
            } else if (typeof L !== 'undefined') {
                initWithLeaflet();
            }
        };

        // Timeout fallback: if Google Maps hasn't loaded after 4 seconds, use Leaflet
        setTimeout(function() {
            if (!useGoogleMaps && typeof L !== 'undefined' && !mapEl._leaflet_id) {
                initWithLeaflet();
            }
        }, 4000);
    })();

    // ===== Form submission protection =====
    document.getElementById('registerForm').addEventListener('submit', function(e) {
        if (!validateStep(4)) {
            e.preventDefault();
            return;
        }
        var btn = document.getElementById('submitBtn');
        btn.disabled = true;
        btn.innerHTML = '<span>&#8987;</span> Creating your account...';
    });

    // ===== If POST errors, go to the step with the first error =====
    if (hasErrors && hasPostData) {
        // Unlock all steps so user can navigate
        maxVisited = 4;
        // Try to determine which step has the error
        var errText = document.querySelector('.ir-error-list') ? document.querySelector('.ir-error-list').textContent : '';
        if (errText.indexOf('Business name') > -1 || errText.indexOf('Owner name') > -1 || errText.indexOf('License') > -1) {
            goToStep(1);
        } else if (errText.indexOf('location') > -1 || errText.indexOf('map') > -1) {
            goToStep(3);
        } else if (errText.indexOf('email') > -1 || errText.indexOf('Email') > -1 || errText.indexOf('assword') > -1 || errText.indexOf('account') > -1) {
            goToStep(4);
        } else {
            goToStep(4);
        }
    }
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
