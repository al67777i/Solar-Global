<?php
$page_title = 'Privacy Policy';
$page_description = 'Privacy Policy - Learn how we collect, use, and protect your personal information. Your privacy matters to us.';
$current_page = 'privacy-policy';

require_once 'includes/db.php';
require_once 'includes/helpers.php';
include 'includes/header.php';

$site_name = get_system_setting('site_name', 'SolarGlobal');
$contact_email = get_system_setting('contact_email', 'support@solarglobal.com');
?>

<style>
.privacy-container {
    max-width: 800px;
    margin: 40px auto;
    padding: 30px 20px;
    font-family: inherit;
    line-height: 1.7;
    color: #333;
}

.privacy-container h1 {
    font-size: 2rem;
    margin-bottom: 5px;
    color: #1a1a1a;
}

.privacy-container .last-updated {
    color: #666;
    font-size: 0.9rem;
    margin-bottom: 40px;
    padding-bottom: 20px;
    border-bottom: 1px solid #e0e0e0;
}

.privacy-section {
    margin-bottom: 35px;
    padding-left: 20px;
    border-left: 3px solid #f0a500;
}

.privacy-section h2 {
    font-size: 1.3rem;
    color: #1a1a1a;
    margin-bottom: 12px;
}

.privacy-section p,
.privacy-section ul {
    font-size: 0.95rem;
    color: #444;
    margin-bottom: 12px;
}

.privacy-section ul {
    padding-left: 20px;
}

.privacy-section ul li {
    margin-bottom: 8px;
}

.privacy-section strong {
    color: #333;
}

.privacy-container a {
    color: #f0a500;
    text-decoration: none;
}

.privacy-container a:hover {
    text-decoration: underline;
}
</style>

<div class="privacy-container">
    <h1>Privacy Policy</h1>
    <p class="last-updated">Last updated: May 2026</p>

    <div class="privacy-section">
        <h2>1. Introduction</h2>
        <p><?php echo htmlspecialchars($site_name); ?> is an informative solar product comparison and recommendation platform. Our purpose is to help buyers find suitable solar products and connect them with solar dealers and installers in their area. We do not sell solar products directly. This Privacy Policy explains how we collect, use, and protect your information when you use our website.</p>
    </div>

    <div class="privacy-section">
        <h2>2. Information We Collect</h2>
        <p>We may collect the following types of information:</p>
        <ul>
            <li><strong>Location Data:</strong> Your city or region, used to find nearby solar dealers and provide location-relevant product recommendations.</li>
            <li><strong>Account Information:</strong> Email address, name, and password when you create an account on our platform.</li>
            <li><strong>Cookies:</strong> Small data files stored on your device to remember your preferences and improve your experience.</li>
            <li><strong>Browsing Behavior:</strong> Pages visited, products viewed, search queries, and interactions with the site to improve our recommendation engine.</li>
            <li><strong>Device Information:</strong> Browser type, operating system, and screen resolution for optimizing the display of our content.</li>
        </ul>
    </div>

    <div class="privacy-section">
        <h2>3. How We Use Your Information</h2>
        <p>We use the information we collect to:</p>
        <ul>
            <li>Provide personalized solar product recommendations based on your needs and location.</li>
            <li>Connect you with solar dealers and installers in your area.</li>
            <li>Improve our services, content, and product database.</li>
            <li>Maintain and secure your account.</li>
            <li>Send relevant notifications if you have opted in (e.g., new dealers in your area).</li>
            <li>Analyze usage patterns to enhance the user experience.</li>
        </ul>
    </div>

    <div class="privacy-section">
        <h2>4. Third-Party Services</h2>
        <p>We integrate with the following third-party services:</p>
        <ul>
            <li><strong>Google Maps:</strong> Used to display dealer locations and calculate distances. Subject to <a href="https://policies.google.com/privacy" target="_blank" rel="noopener">Google's Privacy Policy</a>.</li>
            <li><strong>Stripe:</strong> Used to process subscription payments for dealers and installers who list on our platform. Buyer users are not charged through our site. Subject to <a href="https://stripe.com/privacy" target="_blank" rel="noopener">Stripe's Privacy Policy</a>.</li>
            <li><strong>Google Analytics:</strong> Used to understand how visitors use our site so we can improve it. Subject to <a href="https://policies.google.com/privacy" target="_blank" rel="noopener">Google's Privacy Policy</a>.</li>
        </ul>
        <p>We do not sell your personal information to any third party.</p>
    </div>

    <div class="privacy-section">
        <h2>5. Cookies</h2>
        <p>Our site uses the following cookies:</p>
        <ul>
            <li><strong>sg_location:</strong> Stores your selected location to provide relevant nearby dealer results without repeatedly asking for your location.</li>
            <li><strong>sg_consent:</strong> Records whether you have accepted or declined our cookie usage notice.</li>
            <li><strong>Session Cookies:</strong> Temporary cookies that maintain your login state and preferences during your browsing session. These are deleted when you close your browser.</li>
        </ul>
        <p>You can manage or delete cookies through your browser settings at any time. Disabling cookies may limit some functionality of the site.</p>
    </div>

    <div class="privacy-section">
        <h2>6. Data Security</h2>
        <p>We take reasonable measures to protect your information, including:</p>
        <ul>
            <li>All data transmitted between your browser and our servers is encrypted using HTTPS.</li>
            <li>Passwords are stored using secure one-way hashing algorithms and are never stored in plain text.</li>
            <li>Access to user data is restricted to authorized personnel only.</li>
            <li>Regular security reviews and updates to our systems.</li>
        </ul>
        <p>While we strive to protect your information, no method of transmission over the Internet is 100% secure. We cannot guarantee absolute security.</p>
    </div>

    <div class="privacy-section">
        <h2>7. Your Rights</h2>
        <p>You have the following rights regarding your data:</p>
        <ul>
            <li><strong>Delete Account:</strong> You may request the deletion of your account and all associated data at any time.</li>
            <li><strong>Export Data:</strong> You may request a copy of the personal data we hold about you.</li>
            <li><strong>Opt Out of Cookies:</strong> You can withdraw cookie consent and manage cookie preferences through your browser settings.</li>
            <li><strong>Unsubscribe:</strong> You can opt out of any email communications at any time using the unsubscribe link provided in our emails.</li>
        </ul>
        <p>To exercise any of these rights, please contact us at <a href="mailto:<?php echo htmlspecialchars($contact_email); ?>"><?php echo htmlspecialchars($contact_email); ?></a>.</p>
    </div>

    <div class="privacy-section">
        <h2>8. Dealer/Installer Disclaimer</h2>
        <p><?php echo htmlspecialchars($site_name); ?> serves as an informational platform that connects buyers with solar dealers and installers. Please be aware of the following:</p>
        <ul>
            <li>We do <strong>not</strong> verify the products, pricing, availability, or claims made by dealers or installers listed on our platform.</li>
            <li>We are <strong>not</strong> responsible for any transactions, agreements, or disputes between buyers and dealers/installers.</li>
            <li>Any purchase or contract you enter into with a dealer is solely between you and that dealer.</li>
            <li>We recommend that buyers conduct their own due diligence before making purchasing decisions.</li>
        </ul>
    </div>

    <div class="privacy-section">
        <h2>9. Children's Privacy</h2>
        <p>Our services are not directed at children under the age of 13. We do not knowingly collect personal information from children under 13. If you believe we have inadvertently collected such information, please contact us immediately and we will take steps to delete it.</p>
    </div>

    <div class="privacy-section">
        <h2>10. Changes to This Policy</h2>
        <p>We may update this Privacy Policy from time to time to reflect changes in our practices or for legal and regulatory reasons. When we make changes, we will update the "Last updated" date at the top of this page. We encourage you to review this policy periodically to stay informed about how we protect your information.</p>
    </div>

    <div class="privacy-section">
        <h2>11. Contact Us</h2>
        <p>If you have any questions, concerns, or requests regarding this Privacy Policy or your personal data, please contact us at:</p>
        <p><strong>Email:</strong> <a href="mailto:<?php echo htmlspecialchars($contact_email); ?>"><?php echo htmlspecialchars($contact_email); ?></a></p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
