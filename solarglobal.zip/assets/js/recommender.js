﻿/**
 * Recommendation Results Rendering
 * Step 3: Display recommended solar systems
 */

/**
 * Render recommendations
 */
function renderRecommendations(data) {
    const container = document.getElementById('recommendations-container');
    if (!container) return;
    
    const { best_inverter, alternative_inverters, panel_config } = data;
    
    container.innerHTML = `
        ${renderBestMatch(best_inverter, panel_config)}
        ${alternative_inverters.length > 0 ? renderAlternatives(alternative_inverters) : ''}
    `;
    
    // Animate entrance
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        anime({
            targets: '.best-match-card',
            scale: [0.8, 1],
            opacity: [0, 1],
            duration: 700,
            easing: 'easeOutBack'
        });
        
        anime({
            targets: '.alternative-card',
            translateY: [30, 0],
            opacity: [0, 1],
            duration: 500,
            delay: anime.stagger(80, {start: 300}),
            easing: 'easeOutCubic'
        });
    }
    
    // Setup view details buttons
    setupViewDetailsButtons();
}

/**
 * Render best match card
 */
function renderBestMatch(inverter, panelConfig) {
    const batteries = inverter.compatible_batteries || [];
    const bestBattery = batteries[0];
    
    return `
        <div class="best-match-card card">
            <div class="best-match-badge">${t('best_match')}</div>
            
            <div class="inverter-detail">
                <div class="inverter-header">
                    ${inverter.image_path ? `<img src="${inverter.image_path}" alt="${inverter.name}" class="inverter-image">` : ''}
                    <div class="inverter-info">
                        <h2>${inverter.name}</h2>
                        <div class="company-info">
                            ${inverter.company_logo ? `<img src="${inverter.company_logo}" alt="${inverter.company_name}" class="company-logo-sm">` : ''}
                            <span>${inverter.company_name}</span>
                        </div>
                    </div>
                </div>
                
                <div class="specs-grid">
                    <div class="spec-item">
                        <div class="spec-label">${t('voltage_class')}</div>
                        <div class="spec-value">
                            <span class="badge badge-blue">${inverter.voltage_class}</span>
                        </div>
                    </div>
                    <div class="spec-item">
                        <div class="spec-label">${t('max_load')}</div>
                        <div class="spec-value">${inverter.max_load_watts}W</div>
                    </div>
                    <div class="spec-item">
                        <div class="spec-label">${t('price')}</div>
                        <div class="spec-value price">${formatUSD(inverter.price_usd)}</div>
                    </div>
                    <div class="spec-item">
                        <div class="spec-label">BMS</div>
                        <div class="spec-value">
                            <span class="badge ${inverter.has_bms == 1 ? 'badge-green' : 'badge-gray'}">
                                ${inverter.has_bms == 1 ? t('bms_included') : t('no_bms')}
                            </span>
                        </div>
                    </div>
                </div>
                
                ${batteries.length > 0 ? `
                    <div class="compatible-batteries">
                        <h4>${t('compatible_batteries')}</h4>
                        <div class="battery-list">
                            ${batteries.map(b => `
                                <div class="battery-item">
                                    <span class="battery-name">${b.name}</span>
                                    <span class="battery-specs">${b.voltage}V ${b.capacity_ah}Ah</span>
                                    <span class="battery-price">${formatUSD(b.price_usd)}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                
                <button class="btn btn-primary btn-lg btn-view-details" data-inverter-id="${inverter.id}">
                    ${t('btn_view_details')} & ${t('step4')}
                </button>
            </div>
        </div>
    `;
}

/**
 * Render alternative options
 */
function renderAlternatives(inverters) {
    return `
        <div class="alternatives-section">
            <h3>${t('alternative_options')}</h3>
            <div class="alternatives-grid">
                ${inverters.map(inv => renderAlternativeCard(inv)).join('')}
            </div>
        </div>
    `;
}

/**
 * Render single alternative card
 */
function renderAlternativeCard(inverter) {
    const batteries = inverter.compatible_batteries || [];
    
    return `
        <div class="alternative-card card">
            <div class="alt-header">
                <h4>${inverter.name}</h4>
                <span class="alt-company">${inverter.company_name}</span>
            </div>
            
            <div class="alt-specs">
                <div class="alt-spec">
                    <span class="badge badge-blue">${inverter.voltage_class}</span>
                </div>
                <div class="alt-spec">
                    <span>${inverter.max_load_watts}W</span>
                </div>
                <div class="alt-spec">
                    <span class="price">${formatUSD(inverter.price_usd)}</span>
                </div>
            </div>
            
            ${batteries.length > 0 ? `
                <div class="alt-batteries">
                    <small>${batteries.length} ${t('compatible_batteries')}</small>
                </div>
            ` : ''}
            
            <button class="btn btn-secondary btn-sm btn-view-details" data-inverter-id="${inverter.id}">
                ${t('btn_view_details')}
            </button>
        </div>
    `;
}

/**
 * Setup view details buttons
 */
function setupViewDetailsButtons() {
    document.querySelectorAll('.btn-view-details').forEach(btn => {
        btn.addEventListener('click', () => {
            const inverterId = parseInt(btn.dataset.inverterId);
            const recommendations = window.appState.recommendations;
            
            // Find the inverter
            let inverter = null;
            if (recommendations.best_inverter.id === inverterId) {
                inverter = recommendations.best_inverter;
            } else {
                inverter = recommendations.alternative_inverters.find(i => i.id === inverterId);
            }
            
            if (inverter) {
                window.appState.selectedInverter = inverter;
                renderInstallationGuide(inverter, recommendations.panel_config);
                goToStep(4);
            }
        });
    });
}
