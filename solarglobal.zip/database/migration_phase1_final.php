<?php
/**
 * Migration: Phase 1 final fixes
 * - Add 'installation' to country_price_adjustments product_type ENUM
 * - Clean up temp check files
 */
require_once __DIR__ . '/../includes/db.php';
$db = getDB();

$queries = [
    'price_adjustments: add installation type' => "ALTER TABLE country_price_adjustments MODIFY COLUMN product_type ENUM('inverter','battery','panel','installation','all') NOT NULL",
];

echo "<h1>Phase 1 Final Migration</h1><pre>\n";

foreach ($queries as $label => $sql) {
    try {
        $db->exec($sql);
        echo "&#10004; $label\n";
    } catch (PDOException $e) {
        echo "&#10060; $label: " . $e->getMessage() . "\n";
    }
}

// Clean up temp check files
foreach (['_check_columns.php', '_check2.php'] as $f) {
    $path = __DIR__ . '/' . $f;
    if (file_exists($path)) {
        unlink($path);
        echo "&#10004; Removed temp file: $f\n";
    }
}

echo "\nDone!\n</pre>";
