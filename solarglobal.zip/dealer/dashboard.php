<?php
/**
 * Dealer Dashboard - Main dealer control panel
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

set_security_headers();
require_dealer_login();

$dealer = get_dealer_profile();
$db = getDB();

// Stats
$product_count = get_dealer_product_count();

$stmt = $db->prepare("SELECT COUNT(*) FROM dealer_products WHERE dealer_id = ? AND stock_status = 'low_stock'");
$stmt->execute([$dealer['id']]);
$low_stock_count = (int)$stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM dealer_products WHERE dealer_id = ? AND stock_status = 'out_of_stock'");
$stmt->execute([$dealer['id']]);
$out_stock_count = (int)$stmt->fetchColumn();

// Order stats
$pendingOrders = 0;
$todayRevenue = 0;
$monthRevenue = 0;
$totalOrders = 0;
try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM orders WHERE dealer_id = ? AND status = 'pending'");
    $stmt->execute([$dealer['id']]);
    $pendingOrders = (int)$stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COUNT(*) FROM orders WHERE dealer_id = ?");
    $stmt->execute([$dealer['id']]);
    $totalOrders = (int)$stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE dealer_id = ? AND status = 'picked_up' AND DATE(picked_up_at) = CURDATE()");
    $stmt->execute([$dealer['id']]);
    $todayRevenue = (float)$stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE dealer_id = ? AND status = 'picked_up' AND picked_up_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
    $stmt->execute([$dealer['id']]);
    $monthRevenue = (float)$stmt->fetchColumn();
} catch (Exception $e) {}

// Check subscription
$subCheck = check_dealer_subscription();
$subActive = $subCheck['active'];
$subTrial = $subCheck['trial'] ?? false;
$subTrialDays = $subCheck['trial_days_left'] ?? 0;

// Status info - depends on subscription
if ($subActive && $subTrial) {
    $status = ['label' => "Free Trial ($subTrialDays days left)", 'color' => '#8B5CF6', 'bg' => '#F5F3FF', 'icon' => '&#127881;'];
} elseif ($subActive) {
    $status = ['label' => 'Active & Live', 'color' => '#16A34A', 'bg' => '#DCFCE7', 'icon' => '&#9889;'];
} elseif ($dealer['status'] === 'suspended') {
    $status = ['label' => 'Suspended', 'color' => '#DC2626', 'bg' => '#FEE2E2', 'icon' => '&#9888;'];
} elseif ($dealer['status'] === 'active' && !$subActive) {
    $status = ['label' => 'Subscription Expired', 'color' => '#DC2626', 'bg' => '#FEE2E2', 'icon' => '&#128274;'];
} else {
    $status = ['label' => 'Payment Required', 'color' => '#F59E0B', 'bg' => '#FEF3C7', 'icon' => '&#128179;'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?= sanitize($dealer['business_name']) ?> | <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        /* Dashboard-specific */
        .dash-greeting { font-size: 0.875rem; color: #64748B; }

        /* Status banner */
        .status-banner {
            display: flex; align-items: center; gap: 16px;
            padding: 16px 24px; border-radius: 12px; margin-bottom: 28px;
            font-size: 0.9375rem; font-weight: 600;
        }
        .status-banner .s-icon { font-size: 1.5rem; }
        .status-banner .s-text { flex: 1; }
        .status-banner .s-action {
            padding: 8px 20px; border-radius: 8px; border: none;
            font-weight: 600; font-size: 0.8125rem; cursor: pointer;
            text-decoration: none; display: inline-block;
        }

        /* Stat cards */
        .stat-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px; margin-bottom: 32px;
        }
        .stat-card {
            background: white; border-radius: 14px; padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
        }
        .stat-card .sc-label { font-size: 0.8125rem; color: #64748B; font-weight: 500; margin-bottom: 8px; }
        .stat-card .sc-value { font-size: 2rem; font-weight: 800; color: #1E293B; }
        .stat-card .sc-sub { font-size: 0.8125rem; color: #94A3B8; margin-top: 4px; }
        .stat-card .sc-icon { font-size: 2rem; float: right; margin-top: -4px; }

        /* Content cards */
        .content-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        .content-card {
            background: white; border-radius: 14px; padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
        }
        .content-card h3 {
            font-size: 1rem; font-weight: 700; color: #1E293B; margin-bottom: 16px;
            padding-bottom: 12px; border-bottom: 1px solid #F1F5F9;
        }
        .quick-action {
            display: flex; align-items: center; gap: 12px; padding: 12px;
            border-radius: 10px; text-decoration: none; color: #334155;
            transition: all 0.2s; font-size: 0.875rem; font-weight: 500;
        }
        .quick-action:hover { background: #F1F5F9; }
        .quick-action .qa-icon {
            width: 40px; height: 40px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.125rem;
        }
        .qa-inv { background: #DBEAFE; }
        .qa-bat { background: #DCFCE7; }
        .qa-pan { background: #FEF3C7; }
        .qa-set { background: #F1F5F9; }

        .info-row {
            display: flex; justify-content: space-between; align-items: center;
            padding: 10px 0; border-bottom: 1px solid #F1F5F9;
            font-size: 0.875rem;
        }
        .info-row:last-child { border-bottom: none; }
        .info-row .label { color: #64748B; }
        .info-row .value { font-weight: 600; color: #1E293B; }

        /* Responsive */
        @media (max-width: 900px) {
            .content-grid { grid-template-columns: 1fr; }
            .stat-grid { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 500px) {
            .stat-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <?php $current_dealer_page = 'dashboard'; $pending_orders_count = $pendingOrders; include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="dlr-main-content">
        <div class="dlr-page-header">
            <div class="dlr-page-header-left">
                <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
                <div>
                    <h1>Dashboard</h1>
                    <div class="dash-greeting">Welcome back, <?= sanitize($dealer['owner_name']) ?>!</div>
                </div>
            </div>
            <div></div>
        </div>

        <!-- Status Banner -->
        <div class="status-banner" style="background:<?= $status['bg'] ?>; color:<?= $status['color'] ?>">
            <span class="s-icon"><?= $status['icon'] ?></span>
            <span class="s-text">
                Store Status: <strong><?= $status['label'] ?></strong>
                <?php if (!$subActive && $dealer['status'] !== 'suspended'): ?>
                    <br><small style="font-weight:400">Your store is not visible to customers. Subscribe to activate and start getting leads.</small>
                <?php elseif ($subTrial): ?>
                    <br><small style="font-weight:400">Your store is live during free trial. Subscribe before it expires to maintain visibility.</small>
                <?php elseif ($subActive): ?>
                    <br><small style="font-weight:400">Your store is live and appearing in customer recommendations.</small>
                <?php endif; ?>
            </span>
            <?php if (!$subActive && $dealer['status'] !== 'suspended'): ?>
                <a href="subscription.php" class="s-action" style="background:<?= $status['color'] ?>; color:white">
                    Subscribe Now
                </a>
            <?php elseif ($subTrial): ?>
                <a href="subscription.php" class="s-action" style="background:#8B5CF6; color:white">
                    Upgrade to Paid
                </a>
            <?php endif; ?>
        </div>

        <!-- Stats -->
        <div class="stat-grid">
            <div class="stat-card">
                <span class="sc-icon">&#128230;</span>
                <div class="sc-label">Listed Products</div>
                <div class="sc-value"><?= $product_count ?></div>
                <div class="sc-sub">Active listings</div>
            </div>
            <div class="stat-card">
                <span class="sc-icon">&#128203;</span>
                <div class="sc-label">Pending Orders</div>
                <div class="sc-value" style="<?= $pendingOrders > 0 ? 'color:#F59E0B' : '' ?>"><?= $pendingOrders ?></div>
                <div class="sc-sub"><?= $totalOrders ?> total orders</div>
            </div>
            <div class="stat-card">
                <span class="sc-icon">&#128176;</span>
                <div class="sc-label">Today's Revenue</div>
                <div class="sc-value">$<?= number_format($todayRevenue, 0) ?></div>
                <div class="sc-sub">$<?= number_format($monthRevenue, 0) ?> this month</div>
            </div>
            <div class="stat-card">
                <span class="sc-icon">&#11088;</span>
                <div class="sc-label">Store Rating</div>
                <div class="sc-value"><?= $dealer['rating_avg'] > 0 ? number_format($dealer['rating_avg'], 1) : '--' ?></div>
                <div class="sc-sub"><?= $dealer['rating_count'] ?> reviews</div>
            </div>
            <div class="stat-card">
                <span class="sc-icon">&#9888;&#65039;</span>
                <div class="sc-label">Low Stock</div>
                <div class="sc-value"><?= $low_stock_count ?></div>
                <div class="sc-sub"><?= $out_stock_count ?> out of stock</div>
            </div>
        </div>

        <!-- Content -->
        <div class="content-grid">
            <div class="content-card">
                <h3>&#9889; Quick Actions</h3>
                <a href="add-products.php" class="quick-action">
                    <span class="qa-icon qa-inv">&#9889;</span>
                    <span>Add Inverters to Store</span>
                </a>
                <a href="add-products.php?type=battery" class="quick-action">
                    <span class="qa-icon qa-bat">&#128267;</span>
                    <span>Add Batteries to Store</span>
                </a>
                <a href="add-products.php?type=panel" class="quick-action">
                    <span class="qa-icon qa-pan">&#9728;</span>
                    <span>Add Solar Panels to Store</span>
                </a>
                <a href="pos.php" class="quick-action">
                    <span class="qa-icon" style="background:#DBEAFE;color:#1D4ED8;">&#128179;</span>
                    <span>Open Point of Sale</span>
                </a>
                <a href="orders.php" class="quick-action">
                    <span class="qa-icon" style="background:#FEF3C7;color:#B45309;">&#128203;</span>
                    <span>Manage Orders</span>
                </a>
                <a href="store-settings.php" class="quick-action">
                    <span class="qa-icon qa-set">&#9881;</span>
                    <span>Edit Store Settings</span>
                </a>
            </div>

            <div class="content-card">
                <h3>&#128203; Store Information</h3>
                <div class="info-row">
                    <span class="label">Business Name</span>
                    <span class="value"><?= sanitize($dealer['business_name']) ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Owner</span>
                    <span class="value"><?= sanitize($dealer['owner_name']) ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Location</span>
                    <span class="value"><?= sanitize($dealer['city'] ?: ($dealer['country_code'] ?: 'Not set')) ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Phone</span>
                    <span class="value"><?= sanitize($dealer['phone'] ?: 'Not set') ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Member Since</span>
                    <span class="value"><?= date('M d, Y', strtotime($dealer['created_at'])) ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Subscription</span>
                    <span class="value" style="color: <?= $dealer['subscription_status'] === 'active' ? '#16A34A' : '#64748B' ?>">
                        <?= ucfirst($dealer['subscription_status'] ?: 'None') ?>
                    </span>
                </div>
            </div>
        </div>
    </main>

    <script>
    // Sidebar toggle handled by shared sidebar.php include
    </script>
</body>
</html>
