<?php
/**
 * Admin - Data Cleanup & Management
 * Delete old logs, sessions, and garbage data to keep database clean
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';

requireAdmin();

$db = getDB();
$success = '';
$error = '';
$stats = [];

// Get current data statistics
try {
    $stats['visitor_stats'] = $db->query("SELECT COUNT(*), MIN(visit_date), MAX(visit_date) FROM visitor_stats")->fetch(PDO::FETCH_NUM);
    $stats['visitors'] = $db->query("SELECT COUNT(*), MIN(visit_date), MAX(visit_date) FROM visitors")->fetch(PDO::FETCH_NUM);
    $stats['customer_sessions'] = $db->query("SELECT COUNT(*), MIN(created_at), MAX(created_at) FROM customer_sessions")->fetch(PDO::FETCH_NUM);
    $stats['dealer_sessions'] = $db->query("SELECT COUNT(*), MIN(created_at), MAX(created_at) FROM dealer_sessions")->fetch(PDO::FETCH_NUM);
    $stats['import_logs'] = $db->query("SELECT COUNT(*), MIN(created_at), MAX(created_at) FROM import_logs")->fetch(PDO::FETCH_NUM);
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Handle cleanup actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';
    $months = (int)($_POST['months'] ?? 1);
    
    if ($months < 1 || $months > 60) {
        $error = "Invalid time period. Must be between 1 and 60 months.";
    } else {
        $date_threshold = date('Y-m-d', strtotime("-{$months} months"));
        $deleted = 0;
        
        try {
            switch ($action) {
                case 'cleanup_visitor_stats':
                    $stmt = $db->prepare("DELETE FROM visitor_stats WHERE visit_date < ?");
                    $stmt->execute([$date_threshold]);
                    $deleted = $stmt->rowCount();
                    $success = "Deleted {$deleted} visitor stat records older than {$months} months.";
                    break;
                    
                case 'cleanup_visitors':
                    $stmt = $db->prepare("DELETE FROM visitors WHERE visit_date < ?");
                    $stmt->execute([$date_threshold]);
                    $deleted = $stmt->rowCount();
                    $success = "Deleted {$deleted} visitor records older than {$months} months.";
                    break;
                    
                case 'cleanup_sessions':
                    $datetime_threshold = date('Y-m-d H:i:s', strtotime("-{$months} months"));
                    $stmt1 = $db->prepare("DELETE FROM customer_sessions WHERE created_at < ?");
                    $stmt1->execute([$datetime_threshold]);
                    $deleted1 = $stmt1->rowCount();
                    
                    $stmt2 = $db->prepare("DELETE FROM dealer_sessions WHERE created_at < ?");
                    $stmt2->execute([$datetime_threshold]);
                    $deleted2 = $stmt2->rowCount();
                    
                    $deleted = $deleted1 + $deleted2;
                    $success = "Deleted {$deleted} session records ({$deleted1} customer + {$deleted2} dealer) older than {$months} months.";
                    break;
                    
                case 'cleanup_import_logs':
                    $datetime_threshold = date('Y-m-d H:i:s', strtotime("-{$months} months"));
                    $stmt = $db->prepare("DELETE FROM import_logs WHERE created_at < ?");
                    $stmt->execute([$datetime_threshold]);
                    $deleted = $stmt->rowCount();
                    $success = "Deleted {$deleted} import log records older than {$months} months.";
                    break;
                    
                case 'cleanup_all':
                    $datetime_threshold = date('Y-m-d H:i:s', strtotime("-{$months} months"));
                    
                    $total = 0;
                    $stmt = $db->prepare("DELETE FROM visitor_stats WHERE visit_date < ?");
                    $stmt->execute([$date_threshold]);
                    $total += $stmt->rowCount();
                    
                    $stmt = $db->prepare("DELETE FROM visitors WHERE visit_date < ?");
                    $stmt->execute([$date_threshold]);
                    $total += $stmt->rowCount();
                    
                    $stmt = $db->prepare("DELETE FROM customer_sessions WHERE created_at < ?");
                    $stmt->execute([$datetime_threshold]);
                    $total += $stmt->rowCount();
                    
                    $stmt = $db->prepare("DELETE FROM dealer_sessions WHERE created_at < ?");
                    $stmt->execute([$datetime_threshold]);
                    $total += $stmt->rowCount();
                    
                    $stmt = $db->prepare("DELETE FROM import_logs WHERE created_at < ?");
                    $stmt->execute([$datetime_threshold]);
                    $total += $stmt->rowCount();
                    
                    $success = "Deleted {$total} total records across all tables older than {$months} months.";
                    break;
                    
                default:
                    $error = "Invalid action.";
            }
            
            // Refresh stats after cleanup
            if ($deleted > 0) {
                $stats['visitor_stats'] = $db->query("SELECT COUNT(*), MIN(visit_date), MAX(visit_date) FROM visitor_stats")->fetch(PDO::FETCH_NUM);
                $stats['visitors'] = $db->query("SELECT COUNT(*), MIN(visit_date), MAX(visit_date) FROM visitors")->fetch(PDO::FETCH_NUM);
                $stats['customer_sessions'] = $db->query("SELECT COUNT(*), MIN(created_at), MAX(created_at) FROM customer_sessions")->fetch(PDO::FETCH_NUM);
                $stats['dealer_sessions'] = $db->query("SELECT COUNT(*), MIN(created_at), MAX(created_at) FROM dealer_sessions")->fetch(PDO::FETCH_NUM);
                $stats['import_logs'] = $db->query("SELECT COUNT(*), MIN(created_at), MAX(created_at) FROM import_logs")->fetch(PDO::FETCH_NUM);
            }
            
        } catch (PDOException $e) {
            $error = "Cleanup failed: " . $e->getMessage();
        }
    }
}

$pageTitle = 'Data Cleanup';
include __DIR__ . '/includes/header.php';
?>

<div class="content-wrapper" style="padding: 24px;">
    <div style="margin-bottom: 24px;">
        <h2 style="font-size: 1.5rem; color: #1E293B; margin: 0 0 8px;">🗑️ Data Cleanup & Management</h2>
        <p style="color: #64748B; font-size: 0.875rem;">Remove old logs, sessions, and garbage data to optimize database performance</p>
    </div>

    <?php if ($success): ?>
        <div style="background: #DCFCE7; color: #166534; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; border-left: 4px solid #16A34A;">
            ✅ <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div style="background: #FEE2E2; color: #991B1B; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; border-left: 4px solid #DC2626;">
            ❌ <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 32px;">
        <?php
        $cards = [
            ['label' => 'Visitor Stats', 'key' => 'visitor_stats', 'icon' => '📊', 'color' => '#3B82F6'],
            ['label' => 'Visitors', 'key' => 'visitors', 'icon' => '👥', 'color' => '#8B5CF6'],
            ['label' => 'Customer Sessions', 'key' => 'customer_sessions', 'icon' => '🔐', 'color' => '#10B981'],
            ['label' => 'Dealer Sessions', 'key' => 'dealer_sessions', 'icon' => '🏪', 'color' => '#F59E0B'],
            ['label' => 'Import Logs', 'key' => 'import_logs', 'icon' => '📥', 'color' => '#6366F1'],
        ];
        
        foreach ($cards as $card):
            $data = $stats[$card['key']] ?? [0, null, null];
            $count = number_format($data[0]);
            $oldest = $data[1] ? date('M d, Y', strtotime($data[1])) : 'N/A';
            $newest = $data[2] ? date('M d, Y', strtotime($data[2])) : 'N/A';
        ?>
            <div style="background: white; border-radius: 12px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); border-left: 4px solid <?= $card['color'] ?>;">
                <div style="font-size: 1.5rem; margin-bottom: 8px;"><?= $card['icon'] ?></div>
                <div style="font-size: 0.8125rem; color: #64748B; margin-bottom: 4px;"><?= $card['label'] ?></div>
                <div style="font-size: 1.5rem; font-weight: 700; color: #1E293B; margin-bottom: 8px;"><?= $count ?></div>
                <div style="font-size: 0.6875rem; color: #94A3B8;">
                    Oldest: <?= $oldest ?><br>
                    Newest: <?= $newest ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Cleanup Actions -->
    <div style="background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
        <h3 style="font-size: 1.125rem; color: #1E293B; margin: 0 0 20px;">Cleanup Actions</h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px;">
            
            <!-- Visitor Stats -->
            <div style="border: 2px solid #E2E8F0; border-radius: 10px; padding: 20px;">
                <h4 style="color: #1E293B; margin: 0 0 12px; font-size: 1rem; display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 1.5rem;">📊</span> Visitor Statistics
                </h4>
                <p style="font-size: 0.8125rem; color: #64748B; margin-bottom: 16px;">Daily aggregated visitor stats</p>
                <form method="POST" onsubmit="return confirm('Delete old visitor stats?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="cleanup_visitor_stats">
                    <div style="margin-bottom: 12px;">
                        <label style="font-size: 0.8125rem; color: #475569; display: block; margin-bottom: 6px;">Delete records older than:</label>
                        <select name="months" style="width: 100%; padding: 8px 12px; border: 1px solid #CBD5E1; border-radius: 6px; font-size: 0.875rem;">
                            <option value="1">1 month</option>
                            <option value="2">2 months</option>
                            <option value="3" selected>3 months</option>
                            <option value="6">6 months</option>
                            <option value="12">1 year</option>
                            <option value="24">2 years</option>
                        </select>
                    </div>
                    <button type="submit" style="width: 100%; padding: 10px; background: #DC2626; color: white; border: none; border-radius: 6px; font-weight: 600; font-size: 0.875rem; cursor: pointer;">
                        🗑️ Clean Up
                    </button>
                </form>
            </div>

            <!-- Visitors -->
            <div style="border: 2px solid #E2E8F0; border-radius: 10px; padding: 20px;">
                <h4 style="color: #1E293B; margin: 0 0 12px; font-size: 1rem; display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 1.5rem;">👥</span> Visitor Tracking
                </h4>
                <p style="font-size: 0.8125rem; color: #64748B; margin-bottom: 16px;">Individual visitor records</p>
                <form method="POST" onsubmit="return confirm('Delete old visitor records?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="cleanup_visitors">
                    <div style="margin-bottom: 12px;">
                        <label style="font-size: 0.8125rem; color: #475569; display: block; margin-bottom: 6px;">Delete records older than:</label>
                        <select name="months" style="width: 100%; padding: 8px 12px; border: 1px solid #CBD5E1; border-radius: 6px; font-size: 0.875rem;">
                            <option value="1">1 month</option>
                            <option value="2">2 months</option>
                            <option value="3" selected>3 months</option>
                            <option value="6">6 months</option>
                            <option value="12">1 year</option>
                        </select>
                    </div>
                    <button type="submit" style="width: 100%; padding: 10px; background: #DC2626; color: white; border: none; border-radius: 6px; font-weight: 600; font-size: 0.875rem; cursor: pointer;">
                        🗑️ Clean Up
                    </button>
                </form>
            </div>

            <!-- Sessions -->
            <div style="border: 2px solid #E2E8F0; border-radius: 10px; padding: 20px;">
                <h4 style="color: #1E293B; margin: 0 0 12px; font-size: 1rem; display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 1.5rem;">🔐</span> Login Sessions
                </h4>
                <p style="font-size: 0.8125rem; color: #64748B; margin-bottom: 16px;">Customer & dealer sessions</p>
                <form method="POST" onsubmit="return confirm('Delete old session records?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="cleanup_sessions">
                    <div style="margin-bottom: 12px;">
                        <label style="font-size: 0.8125rem; color: #475569; display: block; margin-bottom: 6px;">Delete sessions older than:</label>
                        <select name="months" style="width: 100%; padding: 8px 12px; border: 1px solid #CBD5E1; border-radius: 6px; font-size: 0.875rem;">
                            <option value="1" selected>1 month</option>
                            <option value="2">2 months</option>
                            <option value="3">3 months</option>
                            <option value="6">6 months</option>
                        </select>
                    </div>
                    <button type="submit" style="width: 100%; padding: 10px; background: #DC2626; color: white; border: none; border-radius: 6px; font-weight: 600; font-size: 0.875rem; cursor: pointer;">
                        🗑️ Clean Up
                    </button>
                </form>
            </div>

            <!-- Import Logs -->
            <div style="border: 2px solid #E2E8F0; border-radius: 10px; padding: 20px;">
                <h4 style="color: #1E293B; margin: 0 0 12px; font-size: 1rem; display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 1.5rem;">📥</span> Import Logs
                </h4>
                <p style="font-size: 0.8125rem; color: #64748B; margin-bottom: 16px;">Product import history</p>
                <form method="POST" onsubmit="return confirm('Delete old import logs?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="cleanup_import_logs">
                    <div style="margin-bottom: 12px;">
                        <label style="font-size: 0.8125rem; color: #475569; display: block; margin-bottom: 6px;">Delete logs older than:</label>
                        <select name="months" style="width: 100%; padding: 8px 12px; border: 1px solid #CBD5E1; border-radius: 6px; font-size: 0.875rem;">
                            <option value="3">3 months</option>
                            <option value="6" selected>6 months</option>
                            <option value="12">1 year</option>
                            <option value="24">2 years</option>
                        </select>
                    </div>
                    <button type="submit" style="width: 100%; padding: 10px; background: #DC2626; color: white; border: none; border-radius: 6px; font-weight: 600; font-size: 0.875rem; cursor: pointer;">
                        🗑️ Clean Up
                    </button>
                </form>
            </div>

        </div>

        <!-- Bulk Cleanup -->
        <div style="margin-top: 32px; padding-top: 24px; border-top: 2px solid #E2E8F0;">
            <h3 style="font-size: 1.125rem; color: #1E293B; margin: 0 0 16px;">⚡ Bulk Cleanup (All Tables)</h3>
            <form method="POST" onsubmit="return confirm('⚠️ WARNING: This will delete old data from ALL tables. Are you sure?')" style="display: flex; gap: 12px; align-items: flex-end; flex-wrap: wrap;">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="cleanup_all">
                <div style="flex: 1; min-width: 200px;">
                    <label style="font-size: 0.875rem; color: #475569; display: block; margin-bottom: 6px;">Delete ALL data older than:</label>
                    <select name="months" style="width: 100%; padding: 10px 12px; border: 2px solid #CBD5E1; border-radius: 8px; font-size: 0.875rem;">
                        <option value="3">3 months</option>
                        <option value="6" selected>6 months</option>
                        <option value="12">1 year</option>
                        <option value="24">2 years</option>
                        <option value="36">3 years</option>
                    </select>
                </div>
                <button type="submit" style="padding: 12px 32px; background: linear-gradient(135deg, #DC2626, #991B1B); color: white; border: none; border-radius: 8px; font-weight: 700; font-size: 0.9375rem; cursor: pointer; box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);">
                    🗑️ Clean Up All Tables
                </button>
            </form>
            <p style="font-size: 0.75rem; color: #EF4444; margin-top: 8px;">⚠️ This action cannot be undone! Make sure you have a database backup.</p>
        </div>
    </div>

    <!-- Database Optimization -->
    <div style="background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); margin-top: 24px;">
        <h3 style="font-size: 1.125rem; color: #1E293B; margin: 0 0 16px;">⚙️ Database Optimization Tips</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px;">
            <div style="padding: 16px; background: #F0F9FF; border-left: 4px solid #3B82F6; border-radius: 6px;">
                <h4 style="font-size: 0.875rem; color: #1E40AF; margin: 0 0 8px; font-weight: 600;">📊 Visitor Data</h4>
                <p style="font-size: 0.8125rem; color: #475569; line-height: 1.5; margin: 0;">Keep 3-6 months for analytics. Older data has minimal value.</p>
            </div>
            <div style="padding: 16px; background: #F0FDF4; border-left: 4px solid #10B981; border-radius: 6px;">
                <h4 style="font-size: 0.875rem; color: #065F46; margin: 0 0 8px; font-weight: 600;">🔐 Sessions</h4>
                <p style="font-size: 0.8125rem; color: #475569; line-height: 1.5; margin: 0;">Clean monthly. Sessions expire after 30 days anyway.</p>
            </div>
            <div style="padding: 16px; background: #FEF3C7; border-left: 4px solid #F59E0B; border-radius: 6px;">
                <h4 style="font-size: 0.875rem; color: #92400E; margin: 0 0 8px; font-weight: 600;">📥 Import Logs</h4>
                <p style="font-size: 0.8125rem; color: #475569; line-height: 1.5; margin: 0;">Keep 6-12 months for audit trail. Archive older logs offline.</p>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
