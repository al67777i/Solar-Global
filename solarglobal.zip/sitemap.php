<?php
/**
 * Dynamic XML Sitemap Generator
 * Generates sitemap from database content for solarglobal.com
 */

header('Content-Type: application/xml; charset=UTF-8');
header('X-Robots-Tag: noindex');

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$domain = get_system_setting('site_domain', 'solarglobal.com') ?: 'solarglobal.com';
$baseUrl = 'https://' . ($_SERVER['HTTP_HOST'] ?? $domain);
$today = date('Y-m-d');

// Check which columns exist in tables
function columnExists($pdo, $table, $column) {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE :column");
        $stmt->execute(['column' => $column]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

// Check for slug columns
$inverterHasSlug = columnExists($pdo, 'inverters', 'slug');
$batteryHasSlug = columnExists($pdo, 'batteries', 'slug');
$panelHasSlug = columnExists($pdo, 'panels', 'slug');
$dealerHasSlug = columnExists($pdo, 'dealers', 'slug');

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">

  <!-- === Static Pages === -->

  <!-- Homepage -->
  <url>
    <loc><?= $baseUrl ?>/</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>

  <!-- Product Listing Pages (priority 0.9) -->
  <url>
    <loc><?= $baseUrl ?>/inverters</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc><?= $baseUrl ?>/batteries</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc><?= $baseUrl ?>/panels</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>

  <!-- Feature Pages (priority 0.8) -->
  <url>
    <loc><?= $baseUrl ?>/compare</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc><?= $baseUrl ?>/appliances</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>

  <!-- Service Pages (priority 0.7) -->
  <url>
    <loc><?= $baseUrl ?>/stores</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc><?= $baseUrl ?>/find-installer</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc><?= $baseUrl ?>/become-dealer</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc><?= $baseUrl ?>/become-installer</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>

  <!-- Info Pages (priority 0.6) -->
  <url>
    <loc><?= $baseUrl ?>/about</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc><?= $baseUrl ?>/contact</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc><?= $baseUrl ?>/privacy-policy</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>yearly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc><?= $baseUrl ?>/terms</loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq>yearly</changefreq>
    <priority>0.6</priority>
  </url>

  <!-- === Dynamic Product Pages === -->

<?php
// --- Inverters ---
try {
    $cols = $inverterHasSlug ? 'id, slug, updated_at' : 'id, updated_at';
    $stmt = $pdo->query("SELECT $cols FROM inverters WHERE is_active = 1 ORDER BY id");
    while ($row = $stmt->fetch()) {
        $loc = $baseUrl . '/inverter-detail.php?id=' . $row['id'];
        if ($inverterHasSlug && !empty($row['slug'])) {
            $loc = $baseUrl . '/inverter/' . htmlspecialchars($row['slug']);
        }
        $lastmod = !empty($row['updated_at']) ? date('Y-m-d', strtotime($row['updated_at'])) : $today;
        echo "  <url>\n";
        echo "    <loc>" . htmlspecialchars($loc) . "</loc>\n";
        echo "    <lastmod>$lastmod</lastmod>\n";
        echo "    <changefreq>weekly</changefreq>\n";
        echo "    <priority>0.8</priority>\n";
        echo "  </url>\n";
    }
} catch (PDOException $e) {
    // Silently skip if table doesn't exist
}

// --- Batteries ---
try {
    $cols = $batteryHasSlug ? 'id, slug, updated_at' : 'id, updated_at';
    $stmt = $pdo->query("SELECT $cols FROM batteries WHERE is_active = 1 ORDER BY id");
    while ($row = $stmt->fetch()) {
        $loc = $baseUrl . '/battery-detail.php?id=' . $row['id'];
        if ($batteryHasSlug && !empty($row['slug'])) {
            $loc = $baseUrl . '/battery/' . htmlspecialchars($row['slug']);
        }
        $lastmod = !empty($row['updated_at']) ? date('Y-m-d', strtotime($row['updated_at'])) : $today;
        echo "  <url>\n";
        echo "    <loc>" . htmlspecialchars($loc) . "</loc>\n";
        echo "    <lastmod>$lastmod</lastmod>\n";
        echo "    <changefreq>weekly</changefreq>\n";
        echo "    <priority>0.8</priority>\n";
        echo "  </url>\n";
    }
} catch (PDOException $e) {
    // Silently skip if table doesn't exist
}

// --- Panels ---
try {
    $cols = $panelHasSlug ? 'id, slug, updated_at' : 'id, updated_at';
    $stmt = $pdo->query("SELECT $cols FROM panels WHERE is_active = 1 ORDER BY id");
    while ($row = $stmt->fetch()) {
        $loc = $baseUrl . '/panel-detail.php?id=' . $row['id'];
        if ($panelHasSlug && !empty($row['slug'])) {
            $loc = $baseUrl . '/panel/' . htmlspecialchars($row['slug']);
        }
        $lastmod = !empty($row['updated_at']) ? date('Y-m-d', strtotime($row['updated_at'])) : $today;
        echo "  <url>\n";
        echo "    <loc>" . htmlspecialchars($loc) . "</loc>\n";
        echo "    <lastmod>$lastmod</lastmod>\n";
        echo "    <changefreq>weekly</changefreq>\n";
        echo "    <priority>0.8</priority>\n";
        echo "  </url>\n";
    }
} catch (PDOException $e) {
    // Silently skip if table doesn't exist
}

// --- Dealer Store Pages ---
try {
    $cols = $dealerHasSlug ? 'id, slug' : 'id';
    $stmt = $pdo->query("SELECT $cols FROM dealers WHERE is_active = 1 AND subscription_status = 'active' ORDER BY id");
    while ($row = $stmt->fetch()) {
        $loc = $baseUrl . '/store-detail.php?id=' . $row['id'];
        if ($dealerHasSlug && !empty($row['slug'])) {
            $loc = $baseUrl . '/store/' . htmlspecialchars($row['slug']);
        }
        echo "  <url>\n";
        echo "    <loc>" . htmlspecialchars($loc) . "</loc>\n";
        echo "    <lastmod>$today</lastmod>\n";
        echo "    <changefreq>weekly</changefreq>\n";
        echo "    <priority>0.7</priority>\n";
        echo "  </url>\n";
    }
} catch (PDOException $e) {
    // Silently skip if table doesn't exist
}
?>

</urlset>
