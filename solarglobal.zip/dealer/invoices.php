<?php
/**
 * Dealer Invoices — Invoice management with view, print, and return processing
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

set_security_headers();
require_dealer_login();

$dealer    = get_dealer_profile();
$db        = getDB();
$dealer_id = (int)$dealer['id'];

// Currency info
$dealer_country  = $dealer['country_code'] ?? '';
$dealer_currency = get_country_currency_info($dealer_country);

$CURRENCY_SYMBOL = $dealer_currency['currency_symbol'];
$CURRENCY_CODE   = $dealer_currency['currency_code'];
$EXCHANGE_RATE   = $dealer_currency['exchange_rate'];

$csrf_token = generate_csrf_token();

/* =====================================================================
 * Check if refund columns exist on orders table
 * ===================================================================== */
$has_refund_columns = false;
try {
    $col_check = $db->query("SHOW COLUMNS FROM orders LIKE 'refund_amount'");
    $has_refund_columns = ($col_check->rowCount() > 0);
} catch (Exception $e) {
    $has_refund_columns = false;
}

/* =====================================================================
 * AJAX HANDLERS — respond and exit before any HTML
 * ===================================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['action'];

    /* ---------- view_invoice ---------------------------------------- */
    if ($action === 'view_invoice') {
        $order_id = (int)($_POST['order_id'] ?? 0);
        if (!$order_id) {
            echo json_encode(['error' => 'Invalid order ID']);
            exit;
        }

        $stmt = $db->prepare("
            SELECT o.*, c.name AS customer_name, c.email AS customer_email, c.phone AS customer_phone
            FROM orders o
            LEFT JOIN customers c ON c.id = o.customer_id
            WHERE o.id = ? AND o.dealer_id = ? AND o.order_number LIKE 'POS-%'
        ");
        $stmt->execute([$order_id, $dealer_id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$order) {
            echo json_encode(['error' => 'Invoice not found']);
            exit;
        }

        // Items
        $items_stmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $items_stmt->execute([$order_id]);
        $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

        // Returns
        $returns = [];
        try {
            $ret_stmt = $db->prepare("
                SELECT sr.*,
                       (SELECT GROUP_CONCAT(CONCAT(sri.product_name, ' x', sri.quantity_returned) SEPARATOR ', ')
                        FROM sale_return_items sri WHERE sri.return_id = sr.id) AS items_summary
                FROM sale_returns sr
                WHERE sr.order_id = ? AND sr.dealer_id = ? AND sr.status != 'cancelled'
                ORDER BY sr.created_at DESC
            ");
            $ret_stmt->execute([$order_id, $dealer_id]);
            $returns = $ret_stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            // sale_returns table may not exist yet
        }

        // Already returned quantities per order_item_id
        $returned_qtys = [];
        try {
            $rq_stmt = $db->prepare("
                SELECT sri.order_item_id, SUM(sri.quantity_returned) AS total_returned
                FROM sale_return_items sri
                JOIN sale_returns sr ON sr.id = sri.return_id
                WHERE sr.order_id = ? AND sr.dealer_id = ? AND sr.status != 'cancelled'
                GROUP BY sri.order_item_id
            ");
            $rq_stmt->execute([$order_id, $dealer_id]);
            while ($row = $rq_stmt->fetch(PDO::FETCH_ASSOC)) {
                $returned_qtys[(int)$row['order_item_id']] = (int)$row['total_returned'];
            }
        } catch (Exception $e) {}

        // Refund totals
        $refund_amount = 0;
        $net_amount    = (float)$order['total_amount'];
        if ($has_refund_columns) {
            $refund_amount = (float)($order['refund_amount'] ?? 0);
            $net_amount    = (float)($order['net_amount'] ?? $order['total_amount']);
        } else {
            // Calculate from sale_returns
            foreach ($returns as $r) {
                $refund_amount += (float)($r['total_amount'] ?? 0);
            }
            $net_amount = (float)$order['total_amount'] - $refund_amount;
        }

        echo json_encode([
            'success' => true,
            'order'   => array_merge($order, [
                'refund_amount' => $refund_amount,
                'net_amount'    => $net_amount,
            ]),
            'items'        => $items,
            'returns'      => $returns,
            'returned_qtys' => $returned_qtys,
            'customer'     => [
                'name'  => $order['customer_name'] ?? 'N/A',
                'email' => $order['customer_email'] ?? '',
                'phone' => $order['customer_phone'] ?? '',
            ],
        ]);
        exit;
    }

    /* ---------- process_return --------------------------------------- */
    if ($action === 'process_return') {
        // CSRF
        if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
            http_response_code(403);
            echo json_encode(['error' => 'Security token invalid. Refresh the page.']);
            exit;
        }

        $order_id = (int)($_POST['order_id'] ?? 0);
        $reason   = trim($_POST['reason'] ?? '');
        $notes    = trim($_POST['notes'] ?? '');
        $return_items_raw = $_POST['return_items'] ?? [];

        if (!$order_id || empty($return_items_raw)) {
            echo json_encode(['error' => 'Please select at least one item to return.']);
            exit;
        }
        if (empty($reason)) {
            echo json_encode(['error' => 'Please select a return reason.']);
            exit;
        }

        // Validate order
        $stmt = $db->prepare("SELECT * FROM orders WHERE id = ? AND dealer_id = ? AND status = 'picked_up' AND order_number LIKE 'POS-%'");
        $stmt->execute([$order_id, $dealer_id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$order) {
            echo json_encode(['error' => 'Order not found or not eligible for returns.']);
            exit;
        }

        // Get order items
        $items_stmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $items_stmt->execute([$order_id]);
        $order_items = [];
        while ($row = $items_stmt->fetch(PDO::FETCH_ASSOC)) {
            $order_items[(int)$row['id']] = $row;
        }

        // Already returned quantities
        $already_returned = [];
        try {
            $rq = $db->prepare("
                SELECT sri.order_item_id, SUM(sri.quantity_returned) AS total_returned
                FROM sale_return_items sri
                JOIN sale_returns sr ON sr.id = sri.return_id
                WHERE sr.order_id = ? AND sr.dealer_id = ? AND sr.status != 'cancelled'
                GROUP BY sri.order_item_id
            ");
            $rq->execute([$order_id, $dealer_id]);
            while ($row = $rq->fetch(PDO::FETCH_ASSOC)) {
                $already_returned[(int)$row['order_item_id']] = (int)$row['total_returned'];
            }
        } catch (Exception $e) {}

        // Validate and build return items
        $valid_items = [];
        $subtotal    = 0;
        foreach ($return_items_raw as $item_data) {
            $oi_id = (int)($item_data['order_item_id'] ?? 0);
            $qty   = (int)($item_data['quantity'] ?? 0);

            if ($qty <= 0 || !isset($order_items[$oi_id])) continue;

            $oi = $order_items[$oi_id];
            $max_returnable = (int)$oi['quantity'] - ($already_returned[$oi_id] ?? 0);

            if ($qty > $max_returnable) {
                echo json_encode(['error' => "Cannot return {$qty} of \"{$oi['product_name']}\". Maximum returnable: {$max_returnable}."]);
                exit;
            }

            $line_total   = round((float)$oi['unit_price'] * $qty, 2);
            $subtotal    += $line_total;
            $valid_items[] = [
                'order_item_id' => $oi_id,
                'product_type'  => $oi['product_type'],
                'product_id'    => (int)$oi['product_id'],
                'product_name'  => $oi['product_name'],
                'quantity'      => $qty,
                'unit_price'    => (float)$oi['unit_price'],
                'total_price'   => $line_total,
            ];
        }

        if (empty($valid_items)) {
            echo json_encode(['error' => 'No valid items selected for return.']);
            exit;
        }

        // Tax lookup
        $tax_percent = 0.0;
        if (!empty($dealer['country_code'])) {
            try {
                $tax_stmt = $db->prepare("SELECT AVG(tax_percent) AS avg_tax FROM country_price_adjustments WHERE country_code = ?");
                $tax_stmt->execute([$dealer['country_code']]);
                $tax_row = $tax_stmt->fetch(PDO::FETCH_ASSOC);
                $tax_percent = $tax_row ? (float)($tax_row['avg_tax'] ?? 0) : 0.0;
            } catch (Exception $e) {}
        }

        $tax_amount = round($subtotal * ($tax_percent / 100), 2);
        $total      = round($subtotal + $tax_amount, 2);

        // Generate return number: RET-YYYYMMDD-XXXX
        $today  = date('Ymd');
        $prefix = 'RET-' . $today . '-';
        $cnt_stmt = $db->prepare("SELECT COUNT(*) FROM sale_returns WHERE return_number LIKE ? AND DATE(created_at) = CURDATE()");
        $cnt_stmt->execute([$prefix . '%']);
        $seq = (int)$cnt_stmt->fetchColumn() + 1;
        $return_number = $prefix . str_pad($seq, 4, '0', STR_PAD_LEFT);

        // Ensure uniqueness
        $chk = $db->prepare("SELECT id FROM sale_returns WHERE return_number = ?");
        $chk->execute([$return_number]);
        while ($chk->fetch()) {
            $seq++;
            $return_number = $prefix . str_pad($seq, 4, '0', STR_PAD_LEFT);
            $chk->execute([$return_number]);
        }

        // Begin transaction
        $db->beginTransaction();
        try {
            // Insert sale_return
            $ins_ret = $db->prepare("
                INSERT INTO sale_returns (order_id, dealer_id, return_number, subtotal_amount, tax_amount, total_amount, currency, reason, notes, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', NOW())
            ");
            $ins_ret->execute([
                $order_id, $dealer_id, $return_number,
                $subtotal, $tax_amount, $total,
                $order['currency'] ?? $CURRENCY_CODE,
                $reason, $notes ?: null,
            ]);
            $return_id = (int)$db->lastInsertId();

            // Insert return items
            $ins_item = $db->prepare("
                INSERT INTO sale_return_items (return_id, order_item_id, product_type, product_id, product_name, quantity_returned, unit_price, total_price)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            // Restock query
            $restock = $db->prepare("
                UPDATE dealer_products
                SET stock_quantity = stock_quantity + ?,
                    stock_status = CASE
                        WHEN stock_quantity + ? > 5 THEN 'in_stock'
                        WHEN stock_quantity + ? > 0 THEN 'low_stock'
                        ELSE 'out_of_stock'
                    END,
                    updated_at = NOW()
                WHERE dealer_id = ? AND product_type = ? AND product_id = ?
            ");

            foreach ($valid_items as $vi) {
                $ins_item->execute([
                    $return_id,
                    $vi['order_item_id'],
                    $vi['product_type'],
                    $vi['product_id'],
                    $vi['product_name'],
                    $vi['quantity'],
                    $vi['unit_price'],
                    $vi['total_price'],
                ]);

                // Restock
                $restock->execute([
                    $vi['quantity'], $vi['quantity'], $vi['quantity'],
                    $dealer_id, $vi['product_type'], $vi['product_id'],
                ]);
            }

            // Update order refund/net amounts
            if ($has_refund_columns) {
                $db->prepare("
                    UPDATE orders
                    SET refund_amount = refund_amount + ?,
                        net_amount    = total_amount - (refund_amount + ?),
                        updated_at    = NOW()
                    WHERE id = ?
                ")->execute([$total, $total, $order_id]);
            }

            $db->commit();

            echo json_encode([
                'success'       => true,
                'return_number' => $return_number,
                'subtotal'      => $subtotal,
                'tax_amount'    => $tax_amount,
                'total'         => $total,
                'message'       => "Return {$return_number} processed successfully. Stock has been restored.",
            ]);
            exit;

        } catch (Exception $e) {
            $db->rollBack();
            error_log("Return processing error: " . $e->getMessage());
            echo json_encode(['error' => 'Failed to process return. Please try again.']);
            exit;
        }
    }

    /* ---------- get_return_details ---------------------------------- */
    if ($action === 'get_return_details') {
        $return_id = (int)($_POST['return_id'] ?? 0);
        if (!$return_id) {
            echo json_encode(['error' => 'Invalid return ID']);
            exit;
        }

        try {
            $stmt = $db->prepare("SELECT * FROM sale_returns WHERE id = ? AND dealer_id = ?");
            $stmt->execute([$return_id, $dealer_id]);
            $return_data = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$return_data) {
                echo json_encode(['error' => 'Return not found']);
                exit;
            }

            $items_stmt = $db->prepare("SELECT * FROM sale_return_items WHERE return_id = ?");
            $items_stmt->execute([$return_id]);
            $return_items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode([
                'success' => true,
                'return'  => $return_data,
                'items'   => $return_items,
            ]);
        } catch (Exception $e) {
            echo json_encode(['error' => 'Could not load return details.']);
        }
        exit;
    }

    // Unknown action
    echo json_encode(['error' => 'Unknown action']);
    exit;
}

/* =====================================================================
 * FILTERS & PAGINATION
 * ===================================================================== */
$valid_statuses = ['all', 'pending', 'confirmed', 'ready', 'picked_up', 'cancelled'];
$status_filter  = $_GET['status'] ?? 'all';
if (!in_array($status_filter, $valid_statuses)) $status_filter = 'all';

$search    = trim($_GET['search'] ?? '');
$date_from = trim($_GET['date_from'] ?? '');
$date_to   = trim($_GET['date_to'] ?? '');
$page      = max(1, (int)($_GET['page'] ?? 1));
$per_page  = 20;
$offset    = ($page - 1) * $per_page;

/* =====================================================================
 * BUILD QUERY
 * ===================================================================== */
$where_parts  = ["o.dealer_id = :dealer_id", "o.order_number LIKE 'POS-%'"];
$query_params = [':dealer_id' => $dealer_id];

if ($status_filter !== 'all') {
    $where_parts[]           = "o.status = :status";
    $query_params[':status'] = $status_filter;
}

if ($search !== '') {
    $where_parts[]            = "(o.order_number LIKE :search OR c.name LIKE :search2)";
    $query_params[':search']  = '%' . $search . '%';
    $query_params[':search2'] = '%' . $search . '%';
}

if ($date_from !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from)) {
    $where_parts[]               = "DATE(o.created_at) >= :date_from";
    $query_params[':date_from']  = $date_from;
}

if ($date_to !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to)) {
    $where_parts[]             = "DATE(o.created_at) <= :date_to";
    $query_params[':date_to']  = $date_to;
}

$where_sql = implode(' AND ', $where_parts);

// Total count
$count_q = $db->prepare(
    "SELECT COUNT(*) FROM orders o LEFT JOIN customers c ON c.id = o.customer_id WHERE $where_sql"
);
$count_q->execute($query_params);
$total_rows  = (int)$count_q->fetchColumn();
$total_pages = max(1, (int)ceil($total_rows / $per_page));
if ($page > $total_pages) $page = $total_pages;

// Select columns — handle missing refund columns
$refund_cols = $has_refund_columns
    ? "o.refund_amount, o.net_amount"
    : "0 AS refund_amount, o.total_amount AS net_amount";

$orders_stmt = $db->prepare("
    SELECT o.id, o.order_number, o.customer_id, o.status, o.total_amount,
           {$refund_cols}, o.currency, o.item_count, o.created_at,
           c.name AS customer_name, c.email AS customer_email
    FROM orders o
    LEFT JOIN customers c ON c.id = o.customer_id
    WHERE $where_sql
    ORDER BY o.created_at DESC
    LIMIT :limit OFFSET :offset
");
foreach ($query_params as $k => $v) {
    $orders_stmt->bindValue($k, $v);
}
$orders_stmt->bindValue(':limit',  $per_page, PDO::PARAM_INT);
$orders_stmt->bindValue(':offset', $offset,   PDO::PARAM_INT);
$orders_stmt->execute();
$orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);

// If refund columns don't exist, calculate refunds from sale_returns
if (!$has_refund_columns && !empty($orders)) {
    $order_ids = array_column($orders, 'id');
    try {
        $placeholders = implode(',', array_fill(0, count($order_ids), '?'));
        $ref_stmt = $db->prepare("
            SELECT order_id, SUM(total_amount) AS total_refund
            FROM sale_returns
            WHERE order_id IN ($placeholders) AND dealer_id = ? AND status != 'cancelled'
            GROUP BY order_id
        ");
        $ref_params = array_merge($order_ids, [$dealer_id]);
        $ref_stmt->execute($ref_params);
        $refund_map = [];
        while ($row = $ref_stmt->fetch(PDO::FETCH_ASSOC)) {
            $refund_map[(int)$row['order_id']] = (float)$row['total_refund'];
        }
        foreach ($orders as &$o) {
            $r = $refund_map[(int)$o['id']] ?? 0;
            $o['refund_amount'] = $r;
            $o['net_amount']    = (float)$o['total_amount'] - $r;
        }
        unset($o);
    } catch (Exception $e) {
        // sale_returns table may not exist
    }
}

/* =====================================================================
 * STATUS COUNTS
 * ===================================================================== */
$count_stmt = $db->prepare("SELECT status, COUNT(*) AS cnt FROM orders WHERE dealer_id = ? AND order_number LIKE 'POS-%' GROUP BY status");
$count_stmt->execute([$dealer_id]);
$counts = ['all' => 0, 'pending' => 0, 'confirmed' => 0, 'ready' => 0, 'picked_up' => 0, 'cancelled' => 0];
foreach ($count_stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    if (isset($counts[$row['status']])) $counts[$row['status']] += (int)$row['cnt'];
    $counts['all'] += (int)$row['cnt'];
}

/* =====================================================================
 * HELPER
 * ===================================================================== */
function inv_status_badge(string $status): string {
    $map = [
        'pending'   => ['label' => 'Pending',   'bg' => '#FEF3C7', 'color' => '#92400E', 'dot' => '#F59E0B'],
        'confirmed' => ['label' => 'Confirmed', 'bg' => '#DBEAFE', 'color' => '#1E40AF', 'dot' => '#3B82F6'],
        'ready'     => ['label' => 'Ready',     'bg' => '#DCFCE7', 'color' => '#166534', 'dot' => '#16A34A'],
        'picked_up' => ['label' => 'Picked Up', 'bg' => '#DCFCE7', 'color' => '#166534', 'dot' => '#16A34A'],
        'cancelled' => ['label' => 'Cancelled', 'bg' => '#FEE2E2', 'color' => '#991B1B', 'dot' => '#EF4444'],
    ];
    $s = $map[$status] ?? ['label' => ucfirst($status), 'bg' => '#F1F5F9', 'color' => '#475569', 'dot' => '#94A3B8'];
    return '<span class="inv-badge" style="background:' . $s['bg'] . ';color:' . $s['color'] . '">'
         . '<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:' . $s['dot'] . ';margin-right:5px;vertical-align:middle"></span>'
         . htmlspecialchars($s['label']) . '</span>';
}

$pageTitle = 'Invoices';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - <?= sanitize($dealer['business_name']) ?> | <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        .inv-page-sub { font-size: 0.875rem; color: #64748B; }

        /* Alerts */
        .alert {
            padding: 14px 18px; border-radius: 10px; margin-bottom: 20px;
            font-size: 0.9rem; font-weight: 500; display: flex; align-items: center; gap: 10px;
        }
        .alert-success { background: #DCFCE7; color: #166534; border: 1px solid #BBF7D0; }
        .alert-error   { background: #FEE2E2; color: #991B1B; border: 1px solid #FECACA; }

        /* Controls bar */
        .controls-bar {
            display: flex; gap: 12px; align-items: flex-end; margin-bottom: 20px; flex-wrap: wrap;
        }
        .ctrl-group { display: flex; flex-direction: column; gap: 4px; }
        .ctrl-group label { font-size: 0.75rem; font-weight: 600; color: #64748B; text-transform: uppercase; letter-spacing: 0.3px; }
        .ctrl-input {
            padding: 9px 14px; border: 1.5px solid #E2E8F0; border-radius: 10px;
            font-size: 0.875rem; background: white; font-family: inherit; outline: none;
            transition: border-color 0.2s;
        }
        .ctrl-input:focus { border-color: #F59E0B; }
        .search-group { flex: 1; min-width: 220px; }
        .search-group .ctrl-input { width: 100%; padding-left: 38px; }
        .search-wrap { position: relative; }
        .search-wrap .s-icon {
            position: absolute; left: 13px; top: 50%; transform: translateY(-50%);
            color: #94A3B8; font-size: 1rem; pointer-events: none;
        }
        .ctrl-select { min-width: 140px; cursor: pointer; }

        .btn-search {
            padding: 9px 20px; background: #F59E0B; color: white; border: none;
            border-radius: 10px; font-weight: 600; font-size: 0.875rem;
            cursor: pointer; font-family: inherit; transition: background 0.2s; height: 39px;
        }
        .btn-search:hover { background: #D97706; }
        .btn-clear {
            padding: 9px 16px; background: #F1F5F9; color: #64748B; border: 1.5px solid #E2E8F0;
            border-radius: 10px; font-size: 0.875rem; cursor: pointer; font-family: inherit;
            text-decoration: none; display: inline-flex; align-items: center; height: 39px;
        }
        .btn-clear:hover { background: #E2E8F0; }

        /* Status tabs */
        .status-tabs { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 20px; }
        .tab-btn {
            padding: 8px 16px; border-radius: 8px; border: 1.5px solid #E2E8F0;
            font-size: 0.8125rem; font-weight: 600; cursor: pointer; background: white;
            color: #64748B; text-decoration: none; transition: all 0.2s; display: inline-flex;
            align-items: center; gap: 6px; font-family: inherit;
        }
        .tab-btn:hover  { border-color: #F59E0B; color: #92400E; background: #FFFBEB; }
        .tab-btn.active { border-color: #F59E0B; background: #FEF3C7; color: #92400E; }
        .tab-count {
            background: #E2E8F0; color: #475569; border-radius: 10px;
            padding: 1px 7px; font-size: 0.6875rem; font-weight: 700;
        }
        .tab-btn.active .tab-count { background: #FDE68A; color: #92400E; }

        /* Table card */
        .card {
            background: white; border-radius: 14px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0; overflow: hidden;
        }
        .card-header {
            padding: 18px 24px; border-bottom: 1px solid #F1F5F9;
            display: flex; align-items: center; justify-content: space-between;
        }
        .card-header h3 { font-size: 1rem; font-weight: 700; color: #1E293B; }
        .card-header .total-label { font-size: 0.8125rem; color: #64748B; }

        .inv-table { width: 100%; border-collapse: collapse; }
        .inv-table th {
            padding: 12px 14px; text-align: left; font-size: 0.75rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.5px; color: #64748B;
            background: #F8FAFC; border-bottom: 1px solid #E2E8F0;
        }
        .inv-table td {
            padding: 13px 14px; font-size: 0.875rem; color: #1E293B;
            border-bottom: 1px solid #F1F5F9; vertical-align: middle;
        }
        .inv-table tbody tr:last-child td { border-bottom: none; }
        .inv-table tbody tr:hover { background: #F8FAFC; }

        .inv-number { font-weight: 700; color: #1E293B; }
        .customer-name { font-weight: 500; }
        .customer-email { font-size: 0.8125rem; color: #64748B; }
        .amount { font-weight: 700; color: #1E293B; }
        .refund-amount { font-weight: 600; color: #EF4444; }
        .net-amount { font-weight: 700; color: #166534; }
        .date-cell { font-size: 0.8125rem; color: #64748B; white-space: nowrap; }

        .inv-badge {
            display: inline-flex; align-items: center; padding: 4px 10px;
            border-radius: 20px; font-size: 0.75rem; font-weight: 600; white-space: nowrap;
        }

        /* Action buttons */
        .actions-cell { white-space: nowrap; }
        .btn-action {
            padding: 6px 12px; border-radius: 7px; border: none; font-size: 0.75rem;
            font-weight: 600; cursor: pointer; font-family: inherit; transition: all 0.2s;
            margin-right: 4px; text-decoration: none; display: inline-block;
        }
        .btn-view   { background: #DBEAFE; color: #1E40AF; }
        .btn-view:hover { background: #BFDBFE; }
        .btn-return { background: #FEF3C7; color: #92400E; }
        .btn-return:hover { background: #FDE68A; }

        /* Empty state */
        .empty-state { text-align: center; padding: 60px 20px; }
        .empty-state .es-icon { font-size: 3rem; margin-bottom: 12px; }
        .empty-state h4 { font-size: 1.125rem; font-weight: 700; color: #1E293B; margin-bottom: 6px; }
        .empty-state p { font-size: 0.875rem; color: #64748B; }

        /* Pagination */
        .pagination { display: flex; justify-content: center; align-items: center; gap: 6px; padding: 20px; }
        .pg-btn {
            padding: 8px 14px; border-radius: 8px; border: 1.5px solid #E2E8F0;
            background: white; color: #475569; font-size: 0.875rem; font-weight: 500;
            text-decoration: none; display: inline-block; transition: all 0.2s;
        }
        .pg-btn:hover   { border-color: #F59E0B; color: #92400E; background: #FFFBEB; }
        .pg-btn.active  { background: #F59E0B; border-color: #F59E0B; color: white; }
        .pg-btn.disabled { opacity: 0.4; pointer-events: none; }
        .pg-info { font-size: 0.875rem; color: #64748B; padding: 0 10px; }

        /* Modal */
        .modal-backdrop {
            display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55);
            z-index: 200; justify-content: center; align-items: flex-start;
            padding: 40px 16px; overflow-y: auto;
        }
        .modal-backdrop.open { display: flex; }
        .modal {
            background: white; border-radius: 16px; width: 100%; max-width: 720px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.2); animation: slideUp 0.25s ease;
            flex-shrink: 0;
        }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .modal-header {
            display: flex; justify-content: space-between; align-items: center;
            padding: 20px 24px; border-bottom: 1px solid #E2E8F0;
        }
        .modal-header h3 { font-size: 1.125rem; font-weight: 700; color: #1E293B; }
        .modal-close {
            background: #F1F5F9; border: none; width: 32px; height: 32px; border-radius: 8px;
            cursor: pointer; font-size: 1.125rem; color: #64748B; display: flex;
            align-items: center; justify-content: center; transition: background 0.2s;
        }
        .modal-close:hover { background: #E2E8F0; }
        .modal-body  { padding: 24px; max-height: 70vh; overflow-y: auto; }
        .modal-footer {
            padding: 16px 24px; border-top: 1px solid #E2E8F0;
            display: flex; justify-content: flex-end; gap: 8px;
        }

        .modal-section { margin-bottom: 24px; }
        .modal-section:last-child { margin-bottom: 0; }
        .modal-section h4 {
            font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px;
            color: #94A3B8; font-weight: 600; margin-bottom: 12px;
        }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .info-item .label { font-size: 0.8125rem; color: #64748B; margin-bottom: 2px; }
        .info-item .value { font-size: 0.9375rem; font-weight: 600; color: #1E293B; }

        .items-table { width: 100%; border-collapse: collapse; }
        .items-table th {
            font-size: 0.75rem; font-weight: 600; text-transform: uppercase;
            color: #94A3B8; padding: 8px 12px; text-align: left;
            background: #F8FAFC; border-bottom: 1px solid #E2E8F0;
        }
        .items-table td { padding: 10px 12px; font-size: 0.875rem; border-bottom: 1px solid #F1F5F9; }
        .items-table tr:last-child td { border-bottom: none; }
        .items-table .total-row td { font-weight: 700; color: #1E293B; background: #F8FAFC; }

        .return-list-item {
            display: flex; justify-content: space-between; align-items: center;
            padding: 10px 14px; background: #FEF2F2; border-radius: 8px; margin-bottom: 8px;
            font-size: 0.875rem;
        }
        .return-list-item .ret-num { font-weight: 600; color: #991B1B; }
        .return-list-item .ret-amt { font-weight: 700; color: #991B1B; }
        .return-list-item .ret-detail-btn {
            background: none; border: none; color: #1565C0; font-size: 0.8125rem;
            font-weight: 600; cursor: pointer; text-decoration: underline; font-family: inherit;
        }

        /* Return modal */
        .ret-item-row {
            display: grid; grid-template-columns: auto 1fr auto auto; gap: 12px;
            align-items: center; padding: 10px 0; border-bottom: 1px solid #F1F5F9;
        }
        .ret-item-row:last-child { border-bottom: none; }
        .ret-item-check { width: 18px; height: 18px; cursor: pointer; accent-color: #1565C0; }
        .ret-item-name { font-size: 0.875rem; font-weight: 500; color: #1E293B; }
        .ret-item-name small { display: block; color: #64748B; font-weight: 400; font-size: 0.8125rem; }
        .ret-qty-input {
            width: 70px; padding: 6px 10px; border: 1.5px solid #E2E8F0; border-radius: 8px;
            font-size: 0.875rem; text-align: center; font-family: inherit; outline: none;
        }
        .ret-qty-input:focus { border-color: #F59E0B; }
        .ret-line-total { font-weight: 600; color: #1E293B; min-width: 90px; text-align: right; }

        .ret-reason-select {
            width: 100%; padding: 10px 14px; border: 1.5px solid #E2E8F0; border-radius: 10px;
            font-size: 0.875rem; font-family: inherit; outline: none; background: white; cursor: pointer;
        }
        .ret-reason-select:focus { border-color: #F59E0B; }
        .ret-notes {
            width: 100%; padding: 10px 14px; border: 1.5px solid #E2E8F0; border-radius: 10px;
            font-size: 0.875rem; font-family: inherit; outline: none; resize: vertical;
            min-height: 70px; margin-top: 10px;
        }
        .ret-notes:focus { border-color: #F59E0B; }

        .ret-summary {
            display: flex; justify-content: space-between; align-items: center;
            padding: 14px 18px; background: #FEF3C7; border-radius: 10px; margin-top: 16px;
        }
        .ret-summary .ret-label { font-size: 0.875rem; font-weight: 600; color: #92400E; }
        .ret-summary .ret-total { font-size: 1.125rem; font-weight: 700; color: #92400E; }

        .btn-primary {
            padding: 10px 22px; background: #1565C0; color: white; border: none;
            border-radius: 9px; font-weight: 600; font-size: 0.875rem; cursor: pointer;
            font-family: inherit; transition: background 0.2s;
        }
        .btn-primary:hover { background: #0D47A1; }
        .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-secondary {
            padding: 10px 18px; background: #F1F5F9; color: #475569; border: 1.5px solid #E2E8F0;
            border-radius: 9px; font-weight: 600; font-size: 0.875rem; cursor: pointer;
            font-family: inherit; transition: background 0.2s;
        }
        .btn-secondary:hover { background: #E2E8F0; }
        .btn-amber {
            padding: 10px 22px; background: #F59E0B; color: white; border: none;
            border-radius: 9px; font-weight: 600; font-size: 0.875rem; cursor: pointer;
            font-family: inherit; transition: background 0.2s;
        }
        .btn-amber:hover { background: #D97706; }
        .btn-amber:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-print {
            padding: 10px 18px; background: #0F172A; color: white; border: none;
            border-radius: 9px; font-weight: 600; font-size: 0.875rem; cursor: pointer;
            font-family: inherit; transition: background 0.2s;
        }
        .btn-print:hover { background: #1E293B; }

        /* Print receipt styles */
        @media print {
            body * { visibility: hidden; }
            #printArea, #printArea * { visibility: visible; }
            #printArea {
                position: absolute; left: 0; top: 0; width: 80mm; font-size: 12px;
                font-family: 'Courier New', monospace; padding: 8px;
            }
            #printArea .print-header { text-align: center; margin-bottom: 10px; font-weight: bold; }
            #printArea table { width: 100%; border-collapse: collapse; }
            #printArea td, #printArea th { padding: 3px 0; font-size: 11px; }
            #printArea .print-divider { border-top: 1px dashed #000; margin: 6px 0; }
            #printArea .print-total { font-weight: bold; font-size: 13px; }
        }

        /* Responsive */
        @media (max-width: 960px) {
            th.hide-sm, td.hide-sm { display: none; }
        }
        @media (max-width: 600px) {
            .info-grid { grid-template-columns: 1fr; }
            .controls-bar { flex-direction: column; align-items: stretch; }
            .ctrl-group { width: 100%; }
            .search-group .ctrl-input { width: 100%; }
            .ret-item-row { grid-template-columns: auto 1fr; gap: 8px; }
            .ret-qty-input { width: 60px; }
        }
    </style>
</head>
<body>
<?php $current_dealer_page = 'invoices'; include __DIR__ . '/includes/sidebar.php'; ?>

<main class="dlr-main-content">
    <div class="dlr-page-header">
        <div class="dlr-page-header-left">
            <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
            <div>
                <h1>&#128451; Invoices</h1>
                <div class="inv-page-sub">View POS invoices, print receipts, and process returns</div>
            </div>
        </div>
        <div></div>
    </div>

    <div id="alertBox"></div>

    <!-- Status Tabs -->
    <div class="status-tabs">
        <?php
        $tab_labels = [
            'all'       => 'All Invoices',
            'pending'   => 'Pending',
            'confirmed' => 'Confirmed',
            'ready'     => 'Ready',
            'picked_up' => 'Picked Up',
            'cancelled' => 'Cancelled',
        ];
        foreach ($tab_labels as $st => $lbl):
            $is_active = ($status_filter === $st);
            $url_params = http_build_query(array_filter([
                'status'    => $st === 'all' ? '' : $st,
                'search'    => $search,
                'date_from' => $date_from,
                'date_to'   => $date_to,
            ]));
            $href = 'invoices.php' . ($url_params ? '?' . $url_params : '');
        ?>
        <a href="<?= $href ?>" class="tab-btn <?= $is_active ? 'active' : '' ?>">
            <?= $lbl ?>
            <span class="tab-count"><?= $counts[$st] ?></span>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- Search & Filter bar -->
    <form method="GET" action="invoices.php">
        <?php if ($status_filter !== 'all'): ?>
            <input type="hidden" name="status" value="<?= sanitize($status_filter) ?>">
        <?php endif; ?>
        <div class="controls-bar">
            <div class="ctrl-group search-group">
                <label>Search</label>
                <div class="search-wrap">
                    <span class="s-icon">&#128269;</span>
                    <input type="text" name="search" class="ctrl-input"
                           placeholder="Invoice # or customer name..."
                           value="<?= sanitize($search) ?>">
                </div>
            </div>
            <div class="ctrl-group">
                <label>From Date</label>
                <input type="date" name="date_from" class="ctrl-input" value="<?= sanitize($date_from) ?>">
            </div>
            <div class="ctrl-group">
                <label>To Date</label>
                <input type="date" name="date_to" class="ctrl-input" value="<?= sanitize($date_to) ?>">
            </div>
            <button type="submit" class="btn-search" style="margin-top:auto">Search</button>
            <?php if ($search || $date_from || $date_to): ?>
                <a href="invoices.php<?= $status_filter !== 'all' ? '?status=' . urlencode($status_filter) : '' ?>"
                   class="btn-clear" style="margin-top:auto">&#10005; Clear</a>
            <?php endif; ?>
        </div>
    </form>

    <!-- Invoice Table -->
    <div class="card">
        <div class="card-header">
            <h3>Invoices</h3>
            <span class="total-label"><?= $total_rows ?> invoice<?= $total_rows !== 1 ? 's' : '' ?> found</span>
        </div>

        <?php if (empty($orders)): ?>
            <div class="empty-state">
                <div class="es-icon">&#128451;</div>
                <h4>No invoices found</h4>
                <p><?= ($search || $date_from || $date_to) ? 'Try adjusting your search or filters.' : 'POS sales invoices will appear here.' ?></p>
            </div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="inv-table">
            <thead>
                <tr>
                    <th>Invoice #</th>
                    <th class="hide-sm">Date</th>
                    <th>Customer</th>
                    <th class="hide-sm">Items</th>
                    <th>Total</th>
                    <th>Refund</th>
                    <th>Net</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($orders as $o): ?>
                <tr>
                    <td><span class="inv-number"><?= sanitize($o['order_number']) ?></span></td>
                    <td class="date-cell hide-sm"><?= date('M d, Y', strtotime($o['created_at'])) ?><br><?= date('H:i', strtotime($o['created_at'])) ?></td>
                    <td>
                        <div class="customer-name"><?= sanitize($o['customer_name'] ?? 'Walk-in') ?></div>
                        <?php if (!empty($o['customer_email']) && strpos($o['customer_email'], '@internal.pos') === false): ?>
                            <div class="customer-email"><?= sanitize($o['customer_email']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="hide-sm"><?= (int)$o['item_count'] ?></td>
                    <td><span class="amount"><?= $CURRENCY_SYMBOL ?> <?= number_format((float)$o['total_amount'] * $EXCHANGE_RATE, 2) ?></span></td>
                    <td>
                        <?php if ((float)$o['refund_amount'] > 0): ?>
                            <span class="refund-amount">-<?= $CURRENCY_SYMBOL ?> <?= number_format((float)$o['refund_amount'] * $EXCHANGE_RATE, 2) ?></span>
                        <?php else: ?>
                            <span style="color:#94A3B8">--</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="net-amount"><?= $CURRENCY_SYMBOL ?> <?= number_format((float)$o['net_amount'] * $EXCHANGE_RATE, 2) ?></span></td>
                    <td><?= inv_status_badge($o['status']) ?></td>
                    <td class="actions-cell">
                        <button type="button" class="btn-action btn-view"
                                onclick="viewInvoice(<?= (int)$o['id'] ?>)">View</button>
                        <?php if ($o['status'] === 'picked_up'): ?>
                            <button type="button" class="btn-action btn-return"
                                    onclick="openReturnModal(<?= (int)$o['id'] ?>)">Return</button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php
            $pg_base = 'invoices.php?' . http_build_query(array_filter([
                'status'    => $status_filter !== 'all' ? $status_filter : '',
                'search'    => $search,
                'date_from' => $date_from,
                'date_to'   => $date_to,
            ]));
            ?>
            <a href="<?= $pg_base ?>&page=<?= max(1, $page - 1) ?>"
               class="pg-btn <?= $page <= 1 ? 'disabled' : '' ?>">&#8592; Prev</a>
            <?php
            $range_start = max(1, $page - 2);
            $range_end   = min($total_pages, $page + 2);
            if ($range_start > 1): ?>
                <a href="<?= $pg_base ?>&page=1" class="pg-btn">1</a>
                <?php if ($range_start > 2): ?><span class="pg-info">...</span><?php endif; ?>
            <?php endif; ?>
            <?php for ($i = $range_start; $i <= $range_end; $i++): ?>
                <a href="<?= $pg_base ?>&page=<?= $i ?>" class="pg-btn <?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
            <?php if ($range_end < $total_pages): ?>
                <?php if ($range_end < $total_pages - 1): ?><span class="pg-info">...</span><?php endif; ?>
                <a href="<?= $pg_base ?>&page=<?= $total_pages ?>" class="pg-btn"><?= $total_pages ?></a>
            <?php endif; ?>
            <a href="<?= $pg_base ?>&page=<?= min($total_pages, $page + 1) ?>"
               class="pg-btn <?= $page >= $total_pages ? 'disabled' : '' ?>">Next &#8594;</a>
            <span class="pg-info">Page <?= $page ?> of <?= $total_pages ?></span>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</main>

<!-- ════════════════════════════════════════════
     VIEW INVOICE MODAL
     ════════════════════════════════════════════ -->
<div class="modal-backdrop" id="viewModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="viewTitle">Invoice Details</h3>
            <button class="modal-close" onclick="closeViewModal()">&#10005;</button>
        </div>
        <div class="modal-body" id="viewBody">
            <p style="text-align:center;color:#94A3B8;padding:30px 0">Loading...</p>
        </div>
        <div class="modal-footer">
            <button class="btn-print" onclick="printInvoice()">&#128424; Print</button>
            <button class="btn-secondary" onclick="closeViewModal()">Close</button>
        </div>
    </div>
</div>

<!-- ════════════════════════════════════════════
     PROCESS RETURN MODAL
     ════════════════════════════════════════════ -->
<div class="modal-backdrop" id="returnModal">
    <div class="modal" style="max-width:760px">
        <div class="modal-header">
            <h3 id="returnTitle">Process Return</h3>
            <button class="modal-close" onclick="closeReturnModal()">&#10005;</button>
        </div>
        <div class="modal-body" id="returnBody">
            <p style="text-align:center;color:#94A3B8;padding:30px 0">Loading...</p>
        </div>
        <div class="modal-footer">
            <button class="btn-secondary" onclick="closeReturnModal()">Cancel</button>
            <button class="btn-amber" id="submitReturnBtn" onclick="submitReturn()" disabled>Process Return</button>
        </div>
    </div>
</div>

<!-- Hidden print area -->
<div id="printArea" style="display:none"></div>

<script>
const CSRF_TOKEN      = <?= json_encode($csrf_token) ?>;
const CURRENCY_SYMBOL = <?= json_encode($CURRENCY_SYMBOL) ?>;
const CURRENCY_CODE   = <?= json_encode($CURRENCY_CODE) ?>;
const EXCHANGE_RATE   = <?= json_encode($EXCHANGE_RATE) ?>;
const DEALER_NAME     = <?= json_encode($dealer['business_name'] ?? '') ?>;

let currentInvoiceData = null;
let returnOrderId      = null;

/* ── Helpers ── */
function escHtml(s) {
    if (s === null || s === undefined) return '';
    const d = document.createElement('div');
    d.textContent = String(s);
    return d.innerHTML;
}

function toLocal(usd) {
    return (parseFloat(usd) || 0) * EXCHANGE_RATE;
}

function fmtMoney(usd) {
    return CURRENCY_SYMBOL + ' ' + toLocal(usd).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
}

function fmtDate(d) {
    if (!d) return '--';
    const dt = new Date(d.replace(' ', 'T'));
    return dt.toLocaleDateString('en-GB', {day: '2-digit', month: 'short', year: 'numeric'}) + ' ' +
           dt.toLocaleTimeString('en-GB', {hour: '2-digit', minute: '2-digit'});
}

function statusBadgeHtml(status) {
    const map = {
        pending:   {label:'Pending',   bg:'#FEF3C7', color:'#92400E', dot:'#F59E0B'},
        confirmed: {label:'Confirmed', bg:'#DBEAFE', color:'#1E40AF', dot:'#3B82F6'},
        ready:     {label:'Ready',     bg:'#DCFCE7', color:'#166534', dot:'#16A34A'},
        picked_up: {label:'Picked Up', bg:'#DCFCE7', color:'#166534', dot:'#16A34A'},
        cancelled: {label:'Cancelled', bg:'#FEE2E2', color:'#991B1B', dot:'#EF4444'},
    };
    const s = map[status] || {label: status, bg:'#F1F5F9', color:'#475569', dot:'#94A3B8'};
    return '<span class="inv-badge" style="background:'+s.bg+';color:'+s.color+'"><span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:'+s.dot+';margin-right:5px;vertical-align:middle"></span>'+escHtml(s.label)+'</span>';
}

function showAlert(msg, type) {
    const box = document.getElementById('alertBox');
    const icon = type === 'success' ? '&#10003;' : '&#9888;';
    box.innerHTML = '<div class="alert alert-' + type + '">' + icon + ' ' + escHtml(msg) + '</div>';
    setTimeout(() => { box.innerHTML = ''; }, 6000);
}

function ajaxPost(data) {
    const fd = new FormData();
    for (const k in data) fd.append(k, data[k]);
    return fetch('invoices.php', { method: 'POST', body: fd })
        .then(r => r.json());
}

/* ── View Invoice ── */
function viewInvoice(orderId) {
    document.getElementById('viewModal').classList.add('open');
    document.getElementById('viewTitle').textContent = 'Loading...';
    document.getElementById('viewBody').innerHTML = '<p style="text-align:center;color:#94A3B8;padding:40px 0">Loading invoice details...</p>';

    ajaxPost({ action: 'view_invoice', order_id: orderId }).then(data => {
        if (data.error) {
            document.getElementById('viewBody').innerHTML = '<p style="color:#EF4444;text-align:center;padding:30px">' + escHtml(data.error) + '</p>';
            return;
        }
        currentInvoiceData = data;
        renderInvoice(data);
    }).catch(() => {
        document.getElementById('viewBody').innerHTML = '<p style="color:#EF4444;text-align:center;padding:30px">Failed to load invoice.</p>';
    });
}

function renderInvoice(data) {
    const o = data.order;
    const items = data.items || [];
    const returns = data.returns || [];

    document.getElementById('viewTitle').textContent = 'Invoice ' + o.order_number;

    // Items table
    let itemsHtml = '<table class="items-table"><thead><tr>' +
        '<th>Product</th><th>Type</th><th style="text-align:right">Qty</th>' +
        '<th style="text-align:right">Unit Price</th><th style="text-align:right">Total</th></tr></thead><tbody>';

    let subtotal = 0;
    items.forEach(item => {
        const tp = parseFloat(item.total_price) || 0;
        subtotal += tp;
        itemsHtml += '<tr>' +
            '<td>' + escHtml(item.product_name) + '</td>' +
            '<td style="text-transform:capitalize">' + escHtml(item.product_type) + '</td>' +
            '<td style="text-align:right">' + parseInt(item.quantity) + '</td>' +
            '<td style="text-align:right">' + fmtMoney(item.unit_price) + '</td>' +
            '<td style="text-align:right">' + fmtMoney(item.total_price) + '</td></tr>';
    });

    const totalAmt  = parseFloat(o.total_amount) || 0;
    const refundAmt = parseFloat(o.refund_amount) || 0;
    const netAmt    = parseFloat(o.net_amount) || totalAmt;

    itemsHtml += '<tr class="total-row"><td colspan="4" style="text-align:right;padding-right:16px">Total</td>' +
                 '<td style="text-align:right">' + fmtMoney(totalAmt) + '</td></tr>';

    if (refundAmt > 0) {
        itemsHtml += '<tr class="total-row"><td colspan="4" style="text-align:right;padding-right:16px;color:#EF4444">Refunds</td>' +
                     '<td style="text-align:right;color:#EF4444">-' + fmtMoney(refundAmt) + '</td></tr>';
        itemsHtml += '<tr class="total-row"><td colspan="4" style="text-align:right;padding-right:16px;color:#166534">Net Amount</td>' +
                     '<td style="text-align:right;color:#166534">' + fmtMoney(netAmt) + '</td></tr>';
    }
    itemsHtml += '</tbody></table>';

    // Returns list
    let returnsHtml = '';
    if (returns.length > 0) {
        returnsHtml = '<div class="modal-section"><h4>Returns</h4>';
        returns.forEach(r => {
            returnsHtml += '<div class="return-list-item">' +
                '<div><span class="ret-num">' + escHtml(r.return_number) + '</span>' +
                ' <span style="color:#64748B;font-size:0.8125rem">' + fmtDate(r.created_at) + '</span>' +
                (r.items_summary ? '<br><span style="font-size:0.8125rem;color:#64748B">' + escHtml(r.items_summary) + '</span>' : '') +
                '</div>' +
                '<div style="text-align:right"><span class="ret-amt">-' + fmtMoney(r.total_amount) + '</span>' +
                '</div></div>';
        });
        returnsHtml += '</div>';
    }

    document.getElementById('viewBody').innerHTML =
        '<div class="modal-section"><h4>Invoice Information</h4>' +
        '<div class="info-grid">' +
            '<div class="info-item"><div class="label">Invoice Number</div><div class="value">' + escHtml(o.order_number) + '</div></div>' +
            '<div class="info-item"><div class="label">Status</div><div class="value">' + statusBadgeHtml(o.status) + '</div></div>' +
            '<div class="info-item"><div class="label">Date</div><div class="value">' + fmtDate(o.created_at) + '</div></div>' +
            '<div class="info-item"><div class="label">Currency</div><div class="value">' + escHtml(CURRENCY_CODE) + '</div></div>' +
        '</div></div>' +

        '<div class="modal-section"><h4>Customer</h4>' +
        '<div class="info-grid">' +
            '<div class="info-item"><div class="label">Name</div><div class="value">' + escHtml(data.customer.name || 'Walk-in') + '</div></div>' +
            '<div class="info-item"><div class="label">Phone</div><div class="value">' + escHtml(data.customer.phone || '--') + '</div></div>' +
            (data.customer.email && !data.customer.email.includes('@internal.pos')
                ? '<div class="info-item"><div class="label">Email</div><div class="value">' + escHtml(data.customer.email) + '</div></div>'
                : '') +
        '</div></div>' +

        '<div class="modal-section"><h4>Items (' + items.length + ')</h4>' + itemsHtml + '</div>' +
        returnsHtml;
}

function closeViewModal() {
    document.getElementById('viewModal').classList.remove('open');
    currentInvoiceData = null;
}

/* ── Print Invoice ── */
function printInvoice() {
    if (!currentInvoiceData) return;
    const o = currentInvoiceData.order;
    const items = currentInvoiceData.items || [];

    const totalAmt  = parseFloat(o.total_amount) || 0;
    const refundAmt = parseFloat(o.refund_amount) || 0;
    const netAmt    = parseFloat(o.net_amount) || totalAmt;

    let html = '<div class="print-header">' + escHtml(DEALER_NAME) + '<br>INVOICE</div>';
    html += '<div class="print-divider"></div>';
    html += '<div>Invoice: ' + escHtml(o.order_number) + '</div>';
    html += '<div>Date: ' + fmtDate(o.created_at) + '</div>';
    html += '<div>Customer: ' + escHtml(currentInvoiceData.customer.name || 'Walk-in') + '</div>';
    html += '<div class="print-divider"></div>';

    html += '<table>';
    html += '<tr><th style="text-align:left">Item</th><th style="text-align:right">Qty</th><th style="text-align:right">Total</th></tr>';
    items.forEach(item => {
        html += '<tr><td>' + escHtml(item.product_name) + '</td>' +
                '<td style="text-align:right">' + parseInt(item.quantity) + '</td>' +
                '<td style="text-align:right">' + fmtMoney(item.total_price) + '</td></tr>';
    });
    html += '</table>';

    html += '<div class="print-divider"></div>';
    html += '<div class="print-total">Total: ' + fmtMoney(totalAmt) + '</div>';
    if (refundAmt > 0) {
        html += '<div>Refunds: -' + fmtMoney(refundAmt) + '</div>';
        html += '<div class="print-total">Net: ' + fmtMoney(netAmt) + '</div>';
    }
    html += '<div class="print-divider"></div>';
    html += '<div style="text-align:center;font-size:10px;margin-top:6px">Thank you for your purchase!</div>';

    const printArea = document.getElementById('printArea');
    printArea.innerHTML = html;
    printArea.style.display = 'block';
    window.print();
    setTimeout(() => { printArea.style.display = 'none'; }, 500);
}

/* ── Return Modal ── */
function openReturnModal(orderId) {
    returnOrderId = orderId;
    document.getElementById('returnModal').classList.add('open');
    document.getElementById('returnTitle').textContent = 'Loading...';
    document.getElementById('returnBody').innerHTML = '<p style="text-align:center;color:#94A3B8;padding:40px 0">Loading order items...</p>';
    document.getElementById('submitReturnBtn').disabled = true;

    ajaxPost({ action: 'view_invoice', order_id: orderId }).then(data => {
        if (data.error) {
            document.getElementById('returnBody').innerHTML = '<p style="color:#EF4444;text-align:center;padding:30px">' + escHtml(data.error) + '</p>';
            return;
        }
        renderReturnForm(data);
    }).catch(() => {
        document.getElementById('returnBody').innerHTML = '<p style="color:#EF4444;text-align:center;padding:30px">Failed to load order.</p>';
    });
}

function renderReturnForm(data) {
    const o = data.order;
    const items = data.items || [];
    const returnedQtys = data.returned_qtys || {};

    document.getElementById('returnTitle').textContent = 'Return - ' + o.order_number;

    let html = '<div class="modal-section"><h4>Select Items to Return</h4>';
    let hasReturnableItems = false;

    items.forEach(item => {
        const originalQty   = parseInt(item.quantity);
        const alreadyReturned = parseInt(returnedQtys[item.id] || 0);
        const maxReturn     = originalQty - alreadyReturned;

        if (maxReturn <= 0) {
            html += '<div class="ret-item-row" style="opacity:0.4">' +
                '<input type="checkbox" class="ret-item-check" disabled>' +
                '<div class="ret-item-name">' + escHtml(item.product_name) +
                    '<small>Fully returned (' + originalQty + '/' + originalQty + ')</small></div>' +
                '<div>--</div><div class="ret-line-total">--</div></div>';
            return;
        }

        hasReturnableItems = true;
        html += '<div class="ret-item-row">' +
            '<input type="checkbox" class="ret-item-check" data-item-id="' + item.id + '" ' +
                'data-unit-price="' + item.unit_price + '" data-max="' + maxReturn + '" ' +
                'onchange="toggleReturnItem(this)">' +
            '<div class="ret-item-name">' + escHtml(item.product_name) +
                '<small>' + escHtml(item.product_type) + ' | Unit: ' + fmtMoney(item.unit_price) +
                (alreadyReturned > 0 ? ' | Already returned: ' + alreadyReturned : '') +
                ' | Max: ' + maxReturn + '</small></div>' +
            '<input type="number" class="ret-qty-input" data-item-id="' + item.id + '" ' +
                'min="1" max="' + maxReturn + '" value="1" disabled ' +
                'onchange="clampReturnQty(this); calcReturnTotal()" ' +
                'oninput="clampReturnQty(this); calcReturnTotal()">' +
            '<div class="ret-line-total" data-item-id="' + item.id + '">' + fmtMoney(0) + '</div></div>';
    });

    html += '</div>';

    if (!hasReturnableItems) {
        html += '<div style="text-align:center;padding:20px;color:#64748B">All items have already been returned.</div>';
        document.getElementById('returnBody').innerHTML = html;
        return;
    }

    html += '<div class="modal-section"><h4>Return Reason</h4>' +
        '<select class="ret-reason-select" id="returnReason">' +
            '<option value="">Select reason...</option>' +
            '<option value="Defective">Defective</option>' +
            '<option value="Wrong Item">Wrong Item</option>' +
            '<option value="Customer Changed Mind">Customer Changed Mind</option>' +
            '<option value="Other">Other</option>' +
        '</select>' +
        '<textarea class="ret-notes" id="returnNotes" placeholder="Additional notes (optional)..."></textarea>' +
    '</div>';

    html += '<div class="ret-summary">' +
        '<span class="ret-label">Return Total</span>' +
        '<span class="ret-total" id="returnTotalDisplay">' + fmtMoney(0) + '</span></div>';

    document.getElementById('returnBody').innerHTML = html;
}

function clampReturnQty(input) {
    const max = parseInt(input.max) || 1;
    const min = parseInt(input.min) || 1;
    let val = parseInt(input.value) || min;
    if (val > max) { val = max; input.value = max; }
    if (val < min) { val = min; input.value = min; }
}

function toggleReturnItem(checkbox) {
    const itemId = checkbox.dataset.itemId;
    const qtyInput = document.querySelector('.ret-qty-input[data-item-id="' + itemId + '"]');
    if (qtyInput) {
        qtyInput.disabled = !checkbox.checked;
        if (!checkbox.checked) qtyInput.value = 1;
    }
    calcReturnTotal();
}

function calcReturnTotal() {
    let total = 0;
    const checks = document.querySelectorAll('.ret-item-check:checked:not(:disabled)');

    checks.forEach(cb => {
        const itemId = cb.dataset.itemId;
        const unitPrice = parseFloat(cb.dataset.unitPrice) || 0;
        const maxQty = parseInt(cb.dataset.max) || 1;
        const qtyInput = document.querySelector('.ret-qty-input[data-item-id="' + itemId + '"]');
        let qty = parseInt(qtyInput?.value) || 1;
        if (qty > maxQty) { qty = maxQty; qtyInput.value = maxQty; }
        if (qty < 1) { qty = 1; qtyInput.value = 1; }

        const lineTotal = unitPrice * qty;
        total += lineTotal;

        const ltEl = document.querySelector('.ret-line-total[data-item-id="' + itemId + '"]');
        if (ltEl) ltEl.textContent = fmtMoney(lineTotal);
    });

    // Reset unchecked line totals
    document.querySelectorAll('.ret-item-check:not(:checked)').forEach(cb => {
        if (cb.disabled && !cb.dataset.itemId) return;
        const ltEl = document.querySelector('.ret-line-total[data-item-id="' + cb.dataset.itemId + '"]');
        if (ltEl) ltEl.textContent = fmtMoney(0);
    });

    const display = document.getElementById('returnTotalDisplay');
    if (display) display.textContent = fmtMoney(total);

    const btn = document.getElementById('submitReturnBtn');
    if (btn) btn.disabled = (total <= 0);
}

function closeReturnModal() {
    document.getElementById('returnModal').classList.remove('open');
    returnOrderId = null;
}

function submitReturn() {
    if (!returnOrderId) return;

    const reason = document.getElementById('returnReason')?.value || '';
    const notes  = document.getElementById('returnNotes')?.value || '';

    if (!reason) {
        alert('Please select a return reason.');
        return;
    }

    // Collect checked items
    const checks = document.querySelectorAll('.ret-item-check:checked:not(:disabled)');
    if (checks.length === 0) {
        alert('Please select at least one item.');
        return;
    }

    const btn = document.getElementById('submitReturnBtn');
    btn.disabled = true;
    btn.textContent = 'Processing...';

    const fd = new FormData();
    fd.append('action', 'process_return');
    fd.append('csrf_token', CSRF_TOKEN);
    fd.append('order_id', returnOrderId);
    fd.append('reason', reason);
    fd.append('notes', notes);

    let idx = 0;
    let validationFailed = false;
    checks.forEach(cb => {
        const itemId = cb.dataset.itemId;
        const maxQty = parseInt(cb.dataset.max) || 1;
        const qtyInput = document.querySelector('.ret-qty-input[data-item-id="' + itemId + '"]');
        let qty = parseInt(qtyInput?.value) || 1;
        // Final clamp: never allow more than max returnable
        if (qty > maxQty) { qty = maxQty; qtyInput.value = maxQty; }
        if (qty < 1) { qty = 1; }
        fd.append('return_items[' + idx + '][order_item_id]', itemId);
        fd.append('return_items[' + idx + '][quantity]', qty);
        idx++;
    });

    if (validationFailed) {
        btn.disabled = false;
        btn.textContent = 'Process Return';
        return;
    }

    fetch('invoices.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
                btn.disabled = false;
                btn.textContent = 'Process Return';
                return;
            }
            closeReturnModal();
            showAlert(data.message || 'Return processed successfully.', 'success');
            // Reload after short delay to refresh table
            setTimeout(() => { window.location.reload(); }, 1500);
        })
        .catch(() => {
            alert('Network error. Please try again.');
            btn.disabled = false;
            btn.textContent = 'Process Return';
        });
}

/* ── Close modals on backdrop click / Escape ── */
document.getElementById('viewModal').addEventListener('click', function(e) {
    if (e.target === this) closeViewModal();
});
document.getElementById('returnModal').addEventListener('click', function(e) {
    if (e.target === this) closeReturnModal();
});
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeViewModal();
        closeReturnModal();
    }
});
</script>
</body>
</html>
