-- =============================================================
-- SolarGlobal Comprehensive Product Seed Data
-- Run with: mysql --default-character-set=utf8mb4 -u root solarglobal -e "source D:/xampp/htdocs/solarglobal/database/seed_products.sql"
-- =============================================================

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- =============================================================
-- SOLAR PANELS (~55 panels)
-- =============================================================

INSERT INTO panels (name, brand, wattage, voc, vmp, isc, type, efficiency, dimensions, weight_kg, price_usd, cells_count, max_system_voltage, temperature_coefficient, degradation_percent, certifications, country_origin, frame_color, backsheet_color, available_regions, features) VALUES

-- Tier 1: Premium Mono panels (400W-700W)
('LONGi Hi-MO 6 Explorer 580W', 'LONGi', 580, 51.90, 43.60, 13.85, 'mono', 22.3, '2278x1134x30mm', 28.5, 185.00, 144, 1500, -0.290, 0.40, 'IEC 61215, IEC 61730, UL 1703', 'China', 'Silver', 'White', 'global', 'HPDC cell technology, Anti-LID/PID'),
('LONGi Hi-MO 7 600W', 'LONGi', 600, 52.40, 44.20, 14.10, 'mono', 22.7, '2278x1134x30mm', 29.0, 195.00, 144, 1500, -0.280, 0.38, 'IEC 61215, IEC 61730, UL 1703', 'China', 'Black', 'Black', 'global', 'HPC cell technology, BC technology'),
('JinkoSolar Tiger Neo 580W', 'JinkoSolar', 580, 51.52, 43.38, 13.90, 'mono', 22.5, '2278x1134x30mm', 28.8, 180.00, 144, 1500, -0.290, 0.40, 'IEC 61215, IEC 61730, UL 1703', 'China', 'Silver', 'White', 'global', 'N-type TOPCon, Anti-PID'),
('JinkoSolar Tiger Neo 620W', 'JinkoSolar', 620, 53.10, 44.80, 14.35, 'mono', 22.8, '2382x1134x30mm', 30.2, 210.00, 156, 1500, -0.280, 0.38, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', 'N-type TOPCon, Smarter clamp'),
('Trina Solar Vertex S+ 445W', 'Trina Solar', 445, 41.70, 34.80, 13.35, 'mono', 22.4, '1762x1134x30mm', 21.8, 145.00, 108, 1500, -0.290, 0.40, 'IEC 61215, IEC 61730', 'China', 'Black', 'Black', 'global', 'N-type i-TOPCon, Residential'),
('Trina Solar Vertex N 700W', 'Trina Solar', 700, 55.80, 47.10, 15.40, 'mono', 22.9, '2384x1303x35mm', 37.5, 245.00, 168, 1500, -0.280, 0.35, 'IEC 61215, IEC 61730, UL 1703', 'China', 'Silver', 'White', 'global', 'N-type TOPCon, Commercial/Utility'),
('Canadian Solar HiKu7 CS7N-665W', 'Canadian Solar', 665, 54.80, 46.20, 14.95, 'mono', 22.5, '2384x1303x35mm', 36.8, 230.00, 168, 1500, -0.290, 0.40, 'IEC 61215, IEC 61730', 'Canada', 'Silver', 'White', 'global', 'N-type TOPCon, HJT'),
('Canadian Solar HiKu6 CS6R-425W', 'Canadian Solar', 425, 40.20, 33.60, 13.15, 'mono', 22.0, '1722x1134x30mm', 21.2, 135.00, 108, 1500, -0.300, 0.45, 'IEC 61215, IEC 61730', 'Canada', 'Black', 'Black', 'global', 'Residential optimized'),
('JA Solar DeepBlue 4.0 Pro 580W', 'JA Solar', 580, 51.60, 43.50, 13.88, 'mono', 22.4, '2278x1134x30mm', 28.6, 178.00, 144, 1500, -0.290, 0.40, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', 'N-type Bycium+ cells'),
('JA Solar DeepBlue 4.0 Pro 630W', 'JA Solar', 630, 53.50, 45.10, 14.50, 'mono', 22.6, '2382x1134x30mm', 30.5, 218.00, 156, 1500, -0.280, 0.38, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', 'N-type Bycium+, Utility scale'),

-- Mid-range Mono panels (350W-550W)
('Risen Energy Titan S 440W', 'Risen Energy', 440, 41.30, 34.50, 13.28, 'mono', 22.0, '1762x1134x30mm', 21.5, 128.00, 108, 1500, -0.300, 0.45, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', '210mm cells, Anti-reflective'),
('Risen Energy Titan 580W', 'Risen Energy', 580, 51.40, 43.30, 13.92, 'mono', 22.2, '2278x1134x30mm', 28.7, 170.00, 144, 1500, -0.290, 0.42, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', 'HJT technology'),
('REC Alpha Pure-R 430W', 'REC', 430, 40.80, 34.10, 13.12, 'mono', 22.3, '1730x1118x30mm', 21.0, 195.00, 108, 1500, -0.260, 0.25, 'IEC 61215, IEC 61730', 'Norway', 'Black', 'Black', 'global', 'HJT cells, 25yr product warranty'),
('REC TwinPeak 5 410W', 'REC', 410, 39.80, 33.20, 12.85, 'mono', 21.6, '1730x1118x30mm', 20.8, 175.00, 108, 1000, -0.300, 0.45, 'IEC 61215, IEC 61730', 'Norway', 'Black', 'Black', 'global', 'Split cell, shade tolerant'),
('SunPower Maxeon 6 AC 440W', 'SunPower', 440, 41.50, 34.80, 13.15, 'mono', 22.8, '1812x1046x40mm', 22.5, 320.00, 104, 1000, -0.270, 0.25, 'IEC 61215, UL 1703', 'USA', 'Black', 'Black', 'global', 'IBC cells, Integrated micro-inverter'),
('Q CELLS Q.PEAK DUO ML-G11S 420W', 'Hanwha Q CELLS', 420, 40.10, 33.50, 13.05, 'mono', 21.8, '1722x1134x32mm', 21.5, 155.00, 108, 1500, -0.290, 0.40, 'IEC 61215, IEC 61730', 'South Korea', 'Black', 'White', 'global', 'Q.ANTUM DUO Z, Anti-LID'),
('Q CELLS Q.PEAK DUO XL-G11S 580W', 'Hanwha Q CELLS', 580, 51.60, 43.40, 13.90, 'mono', 22.3, '2278x1134x35mm', 29.0, 185.00, 144, 1500, -0.280, 0.38, 'IEC 61215, IEC 61730', 'South Korea', 'Silver', 'White', 'global', 'N-type TOPCon'),
('Astronergy ASTRO N7s 590W', 'Astronergy', 590, 52.10, 43.90, 13.95, 'mono', 22.5, '2278x1134x30mm', 28.9, 172.00, 144, 1500, -0.290, 0.40, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', 'N-type TOPCon, ASTRO technology'),
('Phono Solar TwinPlus 550W', 'Phono Solar', 550, 49.80, 41.90, 13.65, 'mono', 21.8, '2256x1133x35mm', 27.8, 155.00, 144, 1500, -0.300, 0.45, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', 'Half-cell, Multi-busbar'),
('Hyundai HiE-S485VG 485W', 'Hyundai', 485, 44.20, 37.10, 13.58, 'mono', 22.0, '1903x1134x35mm', 24.5, 168.00, 120, 1500, -0.290, 0.40, 'IEC 61215, IEC 61730', 'South Korea', 'Silver', 'White', 'global', 'N-type HJT, Heavy snow load'),

-- Bifacial panels (Commercial/Utility)
('LONGi Hi-MO 7 Bifacial 600W', 'LONGi', 600, 52.40, 44.20, 14.10, 'bifacial', 22.7, '2278x1134x30mm', 29.5, 205.00, 144, 1500, -0.280, 0.38, 'IEC 61215, IEC 61730', 'China', 'Silver', 'Glass', 'global', 'Bifaciality up to 80%, BC technology'),
('JinkoSolar Tiger Neo Bifacial 580W', 'JinkoSolar', 580, 51.52, 43.38, 13.90, 'bifacial', 22.5, '2278x1134x30mm', 30.2, 192.00, 144, 1500, -0.290, 0.38, 'IEC 61215, IEC 61730', 'China', 'Silver', 'Glass', 'global', 'Bifaciality 70%, N-type TOPCon'),
('Trina Vertex N Bifacial 700W', 'Trina Solar', 700, 55.80, 47.10, 15.40, 'bifacial', 22.9, '2384x1303x35mm', 38.2, 255.00, 168, 1500, -0.280, 0.35, 'IEC 61215, IEC 61730', 'China', 'Silver', 'Glass', 'global', 'Bifaciality 80%, Dual glass'),
('Canadian Solar BiHiKu7 680W', 'Canadian Solar', 680, 55.20, 46.60, 15.15, 'bifacial', 22.4, '2384x1303x35mm', 37.5, 240.00, 168, 1500, -0.290, 0.38, 'IEC 61215, IEC 61730', 'Canada', 'Silver', 'Glass', 'global', 'Bifaciality 70%, High mechanical load'),
('JA Solar DeepBlue 4.0 Bifacial 625W', 'JA Solar', 625, 53.30, 44.90, 14.45, 'bifacial', 22.5, '2382x1134x30mm', 31.0, 215.00, 156, 1500, -0.280, 0.38, 'IEC 61215, IEC 61730', 'China', 'Silver', 'Glass', 'global', 'Bifaciality 75%, Gapless cells'),
('Risen Titan Bifacial 660W', 'Risen Energy', 660, 54.50, 46.00, 14.90, 'bifacial', 22.3, '2384x1303x35mm', 37.0, 225.00, 168, 1500, -0.290, 0.40, 'IEC 61215, IEC 61730', 'China', 'Silver', 'Glass', 'global', 'Bifaciality 70%, HJT cells'),

-- Poly panels (Budget)
('Trina Solar TSM-345PE09H 345W', 'Trina Solar', 345, 40.60, 33.10, 10.85, 'poly', 18.3, '1960x992x35mm', 22.0, 85.00, 72, 1000, -0.370, 0.55, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', 'Half-cell poly, Budget residential'),
('Canadian Solar CS3U-370P 370W', 'Canadian Solar', 370, 41.20, 33.80, 11.40, 'poly', 19.1, '2000x992x35mm', 23.5, 92.00, 72, 1000, -0.360, 0.55, 'IEC 61215, IEC 61730', 'Canada', 'Silver', 'White', 'global', 'KuPower, Split cell'),
('JA Solar JAP72S10 340W', 'JA Solar', 340, 40.20, 32.80, 10.75, 'poly', 17.5, '1960x992x35mm', 22.2, 78.00, 72, 1000, -0.380, 0.60, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'PK,IN,BD,EG,NG,VN,PH,ID', 'Budget poly, Hot climate rated'),
('Risen RSM72-6-370P 370W', 'Risen Energy', 370, 41.10, 33.70, 11.35, 'poly', 19.0, '2000x992x35mm', 23.0, 88.00, 72, 1000, -0.370, 0.55, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'PK,IN,BD,EG,NG,VN,PH,ID', 'Budget commercial poly'),

-- Thin-film panels (Specialized)
('First Solar Series 7 545W', 'First Solar', 545, 232.00, 195.00, 3.20, 'thin-film', 19.8, '2520x1242x40mm', 42.5, 175.00, 0, 1500, -0.280, 0.30, 'IEC 61215, IEC 61730', 'USA', 'Black', 'Black', 'US,CA,AU,SA,AE,EG', 'CdTe, Best in hot/humid climates'),
('First Solar Series 6 Plus 470W', 'First Solar', 470, 219.00, 183.50, 2.95, 'thin-film', 19.2, '2384x1206x40mm', 38.0, 155.00, 0, 1500, -0.280, 0.30, 'IEC 61215, IEC 61730', 'USA', 'Black', 'Black', 'US,CA,AU,SA,AE,EG', 'CdTe, Low carbon footprint'),

-- Budget panels for developing markets
('Jinko Eagle 400W', 'JinkoSolar', 400, 41.50, 34.00, 12.25, 'mono', 20.5, '1755x1038x35mm', 21.0, 110.00, 108, 1000, -0.340, 0.50, 'IEC 61215', 'China', 'Silver', 'White', 'PK,IN,BD,NG,EG,VN,PH,ID,TH', 'P-type PERC, Budget'),
('Longi LR5-54HTH 430W', 'LONGi', 430, 40.90, 34.20, 13.05, 'mono', 21.8, '1722x1134x30mm', 21.5, 130.00, 108, 1500, -0.290, 0.40, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', 'Residential optimized HPDC'),
('Trina Vertex S 420W', 'Trina Solar', 420, 40.00, 33.40, 13.08, 'mono', 21.6, '1762x1134x30mm', 21.3, 125.00, 108, 1500, -0.300, 0.42, 'IEC 61215, IEC 61730', 'China', 'Black', 'Black', 'global', 'Residential aesthetic'),

-- Ultra-high wattage for utility (700W+)
('LONGi Hi-MO X6 Max 630W', 'LONGi', 630, 53.50, 45.10, 14.52, 'mono', 23.0, '2382x1134x30mm', 30.8, 220.00, 156, 1500, -0.270, 0.35, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', 'BC cell, Premium efficiency'),
('Trina Vertex N Max 720W', 'Trina Solar', 720, 56.50, 47.80, 15.65, 'mono', 23.1, '2384x1303x35mm', 38.0, 260.00, 168, 1500, -0.270, 0.33, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'global', 'Utility-scale optimized'),

-- Additional residential popular brands
('Panasonic EverVolt EVPV410H 410W', 'Panasonic', 410, 39.80, 33.30, 12.80, 'mono', 22.2, '1722x1097x35mm', 20.5, 245.00, 108, 1000, -0.260, 0.25, 'IEC 61215, UL 1703', 'Japan', 'Black', 'Black', 'US,CA,JP,AU,GB,DE,FR', 'HIT cells, Premium residential'),
('LG NeON H+ 400W', 'LG', 400, 39.40, 33.00, 12.62, 'mono', 21.7, '1722x1097x35mm', 20.2, 230.00, 108, 1000, -0.280, 0.30, 'IEC 61215, UL 1703', 'South Korea', 'Black', 'Black', 'US,CA,JP,AU,GB,DE,FR,KR', 'N-type Cello, Premium'),
('Silfab SIL-420-BG 420W', 'Silfab', 420, 40.50, 33.90, 12.88, 'mono', 21.4, '1722x1134x30mm', 21.2, 195.00, 108, 1000, -0.300, 0.40, 'UL 1703, CSA C22.2', 'USA', 'Black', 'Black', 'US,CA', 'Made in USA/Canada, N-type'),
('Mission Solar MSE410SR9S 410W', 'Mission Solar', 410, 39.90, 33.40, 12.78, 'mono', 21.0, '1722x1097x35mm', 20.8, 180.00, 108, 1000, -0.300, 0.45, 'UL 1703, IEC 61215', 'USA', 'Silver', 'White', 'US,CA', 'Made in Texas, US supply chain'),

-- Panels for specific markets
('Adani 540W Mono PERC', 'Adani Solar', 540, 49.50, 41.60, 13.50, 'mono', 21.2, '2256x1133x35mm', 27.5, 140.00, 144, 1500, -0.320, 0.50, 'IEC 61215, BIS', 'India', 'Silver', 'White', 'IN,BD,PK', 'BIS certified for India'),
('Tata Solar 400W DCR', 'Tata Power Solar', 400, 41.00, 33.80, 12.30, 'mono', 20.8, '1755x1038x35mm', 21.0, 145.00, 108, 1000, -0.330, 0.50, 'IEC 61215, BIS, DCR compliant', 'India', 'Silver', 'White', 'IN', 'DCR compliant, Govt subsidy eligible'),
('Waaree Energies 545W', 'Waaree', 545, 49.80, 41.80, 13.55, 'mono', 21.3, '2256x1133x35mm', 27.8, 135.00, 144, 1500, -0.320, 0.50, 'IEC 61215, BIS', 'India', 'Silver', 'White', 'IN,BD,PK,AE,SA', 'BIS certified, Value for money'),
('DAH Solar HCM72X9 550W', 'DAH Solar', 550, 49.90, 42.00, 13.60, 'mono', 21.5, '2278x1134x30mm', 28.0, 145.00, 144, 1500, -0.300, 0.45, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'PK,SA,AE,TR,EG,NG,ZA', 'Full-screen design'),
('Yingli Panda 3.0 445W', 'Yingli Solar', 445, 41.50, 34.60, 13.38, 'mono', 21.8, '1762x1134x30mm', 21.6, 118.00, 108, 1500, -0.300, 0.42, 'IEC 61215, IEC 61730', 'China', 'Silver', 'White', 'PK,IN,BD,BR,MX,TR,VN', 'N-type, Budget premium'),
('GCL System M12/120H 420W', 'GCL-SI', 420, 40.20, 33.60, 13.00, 'mono', 21.5, '1722x1134x30mm', 21.3, 108.00, 108, 1500, -0.310, 0.45, 'IEC 61215', 'China', 'Silver', 'White', 'PK,IN,BD,VN,PH,ID,NG,EG', 'Budget residential'),

-- Small panels for off-grid
('Victron 175W 12V Mono', 'Victron Energy', 175, 22.80, 18.90, 9.70, 'mono', 19.5, '1485x668x30mm', 11.2, 135.00, 36, 600, -0.340, 0.50, 'IEC 61215', 'Netherlands', 'Silver', 'White', 'global', 'Off-grid, MC4, Marine rated'),
('Renogy 200W 12V Mono', 'Renogy', 200, 24.30, 20.20, 10.30, 'mono', 20.2, '1580x710x35mm', 12.0, 120.00, 36, 600, -0.340, 0.50, 'IEC 61215', 'USA', 'Silver', 'White', 'global', 'Off-grid, RV, Cabin'),
('Rich Solar 100W 12V Poly', 'Rich Solar', 100, 21.60, 17.80, 5.90, 'poly', 16.5, '1016x670x35mm', 7.5, 65.00, 36, 600, -0.380, 0.60, 'IEC 61215', 'USA', 'Silver', 'White', 'global', 'Off-grid, Camping, Small systems');


-- =============================================================
-- INVERTERS (~60 inverters: Single-phase, 3-phase, residential to industrial)
-- =============================================================

INSERT INTO inverters (name, brand, power_rating, output_watts, type, usage_type, three_phase, vdc_type, max_solar_input, mppt_channels, mppt_count, efficiency, price_usd, output_voltage, output_frequency, surge_power_watts, parallel_capable, max_parallel_units, parallel_phase_config, certifications, country_origin, ip_rating, input_voltage_min, input_voltage_max, available_regions, features, warranty_years) VALUES

-- =============================================================
-- RESIDENTIAL SINGLE-PHASE HYBRID INVERTERS (3kW - 12kW)
-- =============================================================
('Deye SUN-3K-SG04LP1', 'Deye', 3000, 3000, 'hybrid', 'residential', 0, '48V', 4500, 2, 1, 97.6, 650.00, 230, 50, 6000, 1, 6, '1P/3P', 'IEC 62109, VDE 4105', 'China', 'IP65', 90, 450, 'global', 'Low voltage, Single MPPT, Compact', 10),
('Deye SUN-5K-SG03LP1', 'Deye', 5000, 5000, 'hybrid', 'residential', 0, '48V', 6500, 2, 2, 97.6, 950.00, 230, 50, 10000, 1, 6, '1P/3P', 'IEC 62109, VDE 4105', 'China', 'IP65', 120, 500, 'global', 'Dual MPPT, Popular residential', 10),
('Deye SUN-8K-SG01LP1', 'Deye', 8000, 8000, 'hybrid', 'residential', 0, '48V', 10400, 2, 2, 97.8, 1350.00, 230, 50, 16000, 1, 6, '1P/3P', 'IEC 62109, VDE 4105', 'China', 'IP65', 120, 500, 'global', 'High power residential', 10),
('Deye SUN-12K-SG04LP1', 'Deye', 12000, 12000, 'hybrid', 'residential', 0, '48V', 16000, 2, 2, 97.8, 1850.00, 230, 50, 24000, 1, 6, '1P/3P', 'IEC 62109, VDE 4105', 'China', 'IP65', 150, 500, 'global', '12kW single phase residential max', 10),

('Growatt SPF 5000ES', 'Growatt', 5000, 5000, 'hybrid', 'residential', 0, '48V', 6000, 2, 1, 97.0, 820.00, 230, 50, 10000, 1, 6, '1P/3P', 'IEC 62109, VDE 0126', 'China', 'IP65', 90, 450, 'global', 'Budget hybrid, Reliable', 5),
('Growatt MIN 6000TL-XH', 'Growatt', 6000, 6000, 'hybrid', 'residential', 0, 'HV', 9000, 2, 2, 98.2, 1100.00, 230, 50, 12000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP65', 80, 550, 'global', 'High voltage battery compatible', 10),
('Growatt MOD 10KTL3-XH', 'Growatt', 10000, 10000, 'hybrid', 'residential', 0, 'HV', 15000, 2, 2, 98.4, 1650.00, 230, 50, 20000, 1, 4, '1P', 'IEC 62109, VDE 4105', 'China', 'IP65', 80, 550, 'global', 'High voltage, Smart residential', 10),

('Goodwe GW5000-ES-20', 'GoodWe', 5000, 5000, 'hybrid', 'residential', 0, '48V', 6500, 2, 2, 97.6, 980.00, 230, 50, 10000, 0, 1, NULL, 'IEC 62109, VDE 4105, AS4777', 'China', 'IP65', 80, 500, 'global', 'Compact hybrid, ET series', 10),
('Goodwe GW10K-ET', 'GoodWe', 10000, 10000, 'hybrid', 'residential', 0, 'HV', 15500, 2, 2, 98.0, 1750.00, 230, 50, 20000, 0, 1, NULL, 'IEC 62109, VDE 4105, AS4777', 'China', 'IP66', 80, 550, 'global', 'Premium residential, ET series', 10),

('SolarEdge SE5000H', 'SolarEdge', 5000, 5000, 'hybrid', 'residential', 0, 'HV', 7500, 1, 1, 99.2, 1450.00, 230, 50, 7500, 0, 1, NULL, 'IEC 62109, VDE 4105, UL 1741', 'Israel', 'IP65', 380, 480, 'US,CA,GB,DE,FR,AU,JP', 'HD-Wave, Optimizer-based, Premium', 12),
('SolarEdge SE10000H', 'SolarEdge', 10000, 10000, 'hybrid', 'residential', 0, 'HV', 13500, 1, 1, 99.2, 2250.00, 230, 50, 15000, 0, 1, NULL, 'IEC 62109, VDE 4105, UL 1741', 'Israel', 'IP65', 380, 480, 'US,CA,GB,DE,FR,AU,JP', 'HD-Wave, Premium 10kW residential', 12),

('Fronius Primo GEN24 6.0 Plus', 'Fronius', 6000, 6000, 'hybrid', 'residential', 0, 'HV', 9000, 2, 2, 98.3, 2100.00, 230, 50, 9000, 0, 1, NULL, 'IEC 62109, VDE 4105, AS4777', 'Austria', 'IP65', 80, 550, 'GB,DE,FR,AU,US,CA', 'Premium European, PV Point backup', 10),

('Sungrow SH5.0RS', 'Sungrow', 5000, 5000, 'hybrid', 'residential', 0, 'HV', 7500, 2, 2, 97.8, 1050.00, 230, 50, 10000, 0, 1, NULL, 'IEC 62109, VDE 4105, AS4777', 'China', 'IP65', 80, 550, 'global', 'High voltage, Compact', 10),
('Sungrow SH10RS', 'Sungrow', 10000, 10000, 'hybrid', 'residential', 0, 'HV', 15000, 2, 2, 98.0, 1850.00, 230, 50, 20000, 0, 1, NULL, 'IEC 62109, VDE 4105, AS4777', 'China', 'IP65', 80, 550, 'global', 'High power residential', 10),

('Victron MultiPlus-II 48/5000', 'Victron Energy', 5000, 5000, 'hybrid', 'residential', 0, '48V', 7500, 0, 0, 96.0, 1850.00, 230, 50, 9000, 1, 6, '1P/3P', 'IEC 62109', 'Netherlands', 'IP21', 38, 66, 'global', 'Off-grid king, Extremely reliable', 5),

-- =============================================================
-- RESIDENTIAL SINGLE-PHASE ON-GRID (3kW - 10kW)
-- =============================================================
('Huawei SUN2000-5KTL-L1', 'Huawei', 5000, 5000, 'on-grid', 'residential', 0, 'HV', 7500, 2, 2, 98.6, 850.00, 230, 50, 5000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP65', 90, 560, 'global', 'LUNA battery compatible, Smart', 10),
('Huawei SUN2000-10KTL-M1', 'Huawei', 10000, 10000, 'on-grid', 'residential', 0, 'HV', 15000, 2, 2, 98.6, 1200.00, 230, 50, 10000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP65', 160, 950, 'global', 'High power on-grid residential', 10),
('Solis S6-GR1P5K', 'Solis', 5000, 5000, 'on-grid', 'residential', 0, 'HV', 7500, 2, 2, 97.8, 520.00, 230, 50, 5000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP65', 80, 550, 'global', 'Budget on-grid, Reliable', 10),
('Solis S6-GR1P8K', 'Solis', 8000, 8000, 'on-grid', 'residential', 0, 'HV', 12000, 2, 2, 97.8, 680.00, 230, 50, 8000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP65', 80, 550, 'global', 'Value on-grid', 10),

-- =============================================================
-- RESIDENTIAL SINGLE-PHASE OFF-GRID (3kW - 10kW)
-- =============================================================
('Must PV1800 VPM 5KW', 'Must Energy', 5000, 5000, 'off-grid', 'residential', 0, '48V', 5000, 1, 1, 93.0, 380.00, 230, 50, 10000, 1, 9, '1P/3P', 'IEC 62109', 'China', 'IP20', 60, 115, 'PK,IN,BD,NG,EG,ZA,VN,PH', 'Budget off-grid, Popular in developing', 2),
('Axpert VM III 5KW', 'Voltronic Power', 5000, 5000, 'off-grid', 'residential', 0, '48V', 5000, 1, 1, 93.5, 420.00, 230, 50, 10000, 1, 9, '1P/3P', 'IEC 62109', 'China', 'IP20', 60, 115, 'PK,IN,BD,NG,EG,ZA', 'Budget off-grid, Widely available', 2),
('MPP Solar LV6548', 'MPP Solar', 6500, 6500, 'off-grid', 'residential', 0, '48V', 6500, 2, 2, 94.0, 650.00, 230, 50, 13000, 1, 6, '1P/3P', 'IEC 62109', 'Taiwan', 'IP20', 60, 145, 'global', 'High power off-grid, Split phase capable', 3),
('EG4 6000XP', 'EG4', 6000, 6000, 'off-grid', 'residential', 0, '48V', 8000, 2, 2, 94.5, 1150.00, 230, 50, 12000, 1, 10, '1P/3P', 'UL 1741', 'China', 'IP20', 40, 60, 'US,CA', '120/240V split phase, Popular in USA', 5),

-- =============================================================
-- COMMERCIAL 3-PHASE INVERTERS (15kW - 100kW)
-- =============================================================
('Deye SUN-15K-SG01LP3', 'Deye', 15000, 15000, 'hybrid', 'commercial', 1, '48V', 19500, 2, 2, 97.8, 2400.00, 400, 50, 30000, 1, 16, '3P', 'IEC 62109, VDE 4105', 'China', 'IP65', 150, 500, 'global', '3-phase hybrid, Small commercial', 10),
('Deye SUN-25K-SG01LP3', 'Deye', 25000, 25000, 'hybrid', 'commercial', 1, 'HV', 30000, 3, 3, 98.0, 3200.00, 400, 50, 50000, 1, 16, '3P', 'IEC 62109, VDE 4105', 'China', 'IP65', 200, 850, 'global', '3-phase hybrid commercial', 10),
('Deye SUN-50K-SG01HP3', 'Deye', 50000, 50000, 'hybrid', 'commercial', 1, 'HV', 65000, 4, 4, 98.2, 5500.00, 400, 50, 75000, 1, 8, '3P', 'IEC 62109, VDE 4105', 'China', 'IP65', 200, 1000, 'global', '50kW 3-phase commercial hybrid', 10),

('Growatt MID 20KTL3-X', 'Growatt', 20000, 20000, 'on-grid', 'commercial', 1, 'HV', 27000, 2, 2, 98.6, 1800.00, 400, 50, 20000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP65', 160, 1000, 'global', '3-phase string, Small commercial', 10),
('Growatt MAX 50KTL3 LV', 'Growatt', 50000, 50000, 'on-grid', 'commercial', 1, 'HV', 67500, 5, 5, 98.7, 3800.00, 400, 50, 50000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP65', 200, 1000, 'global', '50kW 3-phase string commercial', 10),
('Growatt MAX 75KTL3 LV', 'Growatt', 75000, 75000, 'on-grid', 'commercial', 1, 'HV', 100000, 6, 6, 98.8, 5200.00, 400, 50, 75000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP65', 200, 1100, 'global', '75kW commercial rooftop', 10),
('Growatt MAX 100KTL3-X LV', 'Growatt', 100000, 100000, 'on-grid', 'commercial', 1, 'HV', 135000, 9, 9, 98.8, 6800.00, 400, 50, 100000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP66', 200, 1100, 'global', '100kW large commercial', 10),

('Sungrow SG25CX-P2', 'Sungrow', 25000, 25000, 'on-grid', 'commercial', 1, 'HV', 37500, 3, 3, 98.7, 2200.00, 400, 50, 25000, 0, 1, NULL, 'IEC 62109, VDE 4105, AS4777', 'China', 'IP66', 200, 1000, 'global', '3-phase string commercial', 10),
('Sungrow SG50CX-P2', 'Sungrow', 50000, 50000, 'on-grid', 'commercial', 1, 'HV', 75000, 5, 5, 98.8, 3600.00, 400, 50, 50000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP66', 200, 1100, 'global', '50kW high efficiency commercial', 10),
('Sungrow SG110CX-P2', 'Sungrow', 110000, 110000, 'on-grid', 'commercial', 1, 'HV', 150000, 9, 9, 98.9, 7500.00, 400, 50, 110000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP66', 200, 1100, 'global', '110kW large commercial/small industrial', 10),

('Huawei SUN2000-50KTL-M3', 'Huawei', 50000, 50000, 'on-grid', 'commercial', 1, 'HV', 65000, 6, 6, 98.8, 4200.00, 400, 50, 50000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP66', 200, 1080, 'global', 'Smart PV, FusionSolar', 10),
('Huawei SUN2000-100KTL-M2', 'Huawei', 100000, 100000, 'on-grid', 'commercial', 1, 'HV', 135000, 9, 9, 98.9, 6500.00, 400, 50, 100000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP66', 200, 1100, 'global', '100kW Smart String, AI powered', 10),

('SMA Sunny Tripower X 25', 'SMA', 25000, 25000, 'on-grid', 'commercial', 1, 'HV', 37500, 3, 3, 98.5, 2800.00, 400, 50, 25000, 0, 1, NULL, 'IEC 62109, VDE 4105, UL 1741', 'Germany', 'IP65', 160, 1000, 'US,CA,GB,DE,FR,AU', 'Premium German engineering', 10),
('SMA Sunny Tripower Core2 110', 'SMA', 110000, 110000, 'on-grid', 'commercial', 1, 'HV', 147000, 12, 6, 98.8, 8500.00, 400, 50, 110000, 0, 1, NULL, 'IEC 62109, VDE 4105, UL 1741', 'Germany', 'IP65', 500, 1000, 'US,CA,GB,DE,FR,AU', 'Free-standing, No DC combiner needed', 10),

('Fronius Tauro 50-3', 'Fronius', 50000, 50000, 'on-grid', 'commercial', 1, 'HV', 75000, 6, 6, 98.6, 4500.00, 400, 50, 50000, 0, 1, NULL, 'IEC 62109, VDE 4105, AS4777', 'Austria', 'IP65', 200, 1000, 'GB,DE,FR,AU,US,CA', 'Premium 3-phase, Active cooling', 10),

('GoodWe GW50KN-MT', 'GoodWe', 50000, 50000, 'on-grid', 'commercial', 1, 'HV', 67500, 5, 5, 98.6, 3200.00, 400, 50, 50000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP66', 200, 1000, 'global', '3-phase commercial value', 10),

-- =============================================================
-- INDUSTRIAL 3-PHASE INVERTERS (125kW - 1MW)
-- =============================================================
('Sungrow SG250HX-20', 'Sungrow', 250000, 250000, 'on-grid', 'industrial', 1, 'HV', 330000, 12, 12, 99.0, 18000.00, 690, 50, 250000, 0, 1, NULL, 'IEC 62109, IEC 61727', 'China', 'IP66', 500, 1500, 'global', '1500V string, Utility grade, Smart IV', 10),
('Sungrow SG350HX', 'Sungrow', 350000, 350000, 'on-grid', 'industrial', 1, 'HV', 462000, 12, 12, 99.0, 24000.00, 690, 50, 350000, 0, 1, NULL, 'IEC 62109, IEC 61727', 'China', 'IP66', 500, 1500, 'global', '350kW string inverter, Utility', 10),

('Huawei SUN2000-200KTL-H3', 'Huawei', 200000, 200000, 'on-grid', 'industrial', 1, 'HV', 270000, 12, 12, 99.0, 15000.00, 690, 50, 200000, 0, 1, NULL, 'IEC 62109, IEC 61727', 'China', 'IP66', 500, 1500, 'global', '1500V industrial, Smart PV + AI', 10),
('Huawei SUN2000-330KTL-H1', 'Huawei', 330000, 330000, 'on-grid', 'industrial', 1, 'HV', 440000, 12, 12, 99.0, 22000.00, 690, 50, 330000, 0, 1, NULL, 'IEC 62109, IEC 61727', 'China', 'IP66', 500, 1500, 'global', '330kW Smart String, FusionSolar', 10),

('Growatt MAX 250KTL3-X HV', 'Growatt', 250000, 250000, 'on-grid', 'industrial', 1, 'HV', 330000, 12, 12, 99.0, 16500.00, 690, 50, 250000, 0, 1, NULL, 'IEC 62109, IEC 61727', 'China', 'IP66', 500, 1500, 'global', '250kW industrial string', 10),

('SMA Sunny Highpower PEAK3 150', 'SMA', 150000, 150000, 'on-grid', 'industrial', 1, 'HV', 200000, 6, 6, 98.9, 14000.00, 690, 50, 150000, 0, 1, NULL, 'IEC 62109, VDE 4105, UL 1741', 'Germany', 'IP65', 500, 1500, 'US,CA,GB,DE,FR,AU,SA,AE', '1500V industrial, German quality', 10),

('TMEIC SOLAR WARE SAMURAI 660kW', 'TMEIC', 660000, 660000, 'on-grid', 'industrial', 1, 'HV', 880000, 0, 0, 99.1, 85000.00, 690, 50, 660000, 0, 1, NULL, 'IEC 62109, UL 1741', 'Japan', 'IP55', 850, 1500, 'global', 'Central inverter, Utility scale', 5),
('TMEIC SOLAR WARE SAMURAI 1MW', 'TMEIC', 1000000, 1000000, 'on-grid', 'industrial', 1, 'HV', 1300000, 0, 0, 99.2, 125000.00, 690, 50, 1000000, 0, 1, NULL, 'IEC 62109, UL 1741', 'Japan', 'IP55', 850, 1500, 'global', '1MW Central inverter, Utility mega-scale', 5),

('Sungrow SG3150U-MV', 'Sungrow', 500000, 500000, 'on-grid', 'industrial', 1, 'HV', 660000, 0, 0, 99.0, 65000.00, 690, 50, 500000, 0, 1, NULL, 'IEC 62109, IEC 61727', 'China', 'IP54', 850, 1500, 'global', '500kW turnkey station, MV transformer', 5),
('Sungrow SG5000UD-MV', 'Sungrow', 750000, 750000, 'on-grid', 'industrial', 1, 'HV', 990000, 0, 0, 99.0, 90000.00, 690, 50, 750000, 0, 1, NULL, 'IEC 62109, IEC 61727', 'China', 'IP54', 850, 1500, 'global', '750kW container solution', 5),

('Power Electronics FS1500 1MW', 'Power Electronics', 1000000, 1000000, 'on-grid', 'industrial', 1, 'HV', 1350000, 0, 0, 99.1, 130000.00, 690, 50, 1000000, 0, 1, NULL, 'IEC 62109, UL 1741', 'Spain', 'IP54', 850, 1500, 'global', '1MW central, Liquid cooled', 5),

-- =============================================================
-- MICROINVERTERS
-- =============================================================
('Hoymiles HM-800', 'Hoymiles', 800, 800, 'microinverter', 'residential', 0, 'LV', 960, 2, 2, 96.7, 185.00, 230, 50, 800, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP67', 16, 60, 'global', '2-in-1 microinverter, Module level', 12),
('Hoymiles HM-1500', 'Hoymiles', 1500, 1500, 'microinverter', 'residential', 0, 'LV', 1800, 4, 4, 96.7, 295.00, 230, 50, 1500, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP67', 16, 60, 'global', '4-in-1 microinverter', 12),
('Enphase IQ8M', 'Enphase', 330, 330, 'microinverter', 'residential', 0, 'LV', 440, 1, 1, 97.5, 195.00, 230, 50, 330, 0, 1, NULL, 'IEC 62109, UL 1741, AS4777', 'USA', 'IP67', 22, 58, 'US,CA,AU,GB,DE,FR', 'Premium microinverter, Sunlight backup', 25),
('Enphase IQ8A', 'Enphase', 366, 366, 'microinverter', 'residential', 0, 'LV', 480, 1, 1, 97.5, 215.00, 230, 50, 366, 0, 1, NULL, 'IEC 62109, UL 1741, AS4777', 'USA', 'IP67', 22, 58, 'US,CA,AU,GB,DE,FR', 'High-power micro, Module-level optimization', 25),

-- =============================================================
-- 3-PHASE RESIDENTIAL/SMALL COMMERCIAL (5kW - 15kW)
-- =============================================================
('Fronius Symo GEN24 10.0 Plus', 'Fronius', 10000, 10000, 'hybrid', 'residential', 1, 'HV', 15000, 2, 2, 98.2, 2800.00, 400, 50, 15000, 0, 1, NULL, 'IEC 62109, VDE 4105, AS4777', 'Austria', 'IP65', 80, 550, 'GB,DE,FR,AU', 'Premium 3-phase residential hybrid', 10),
('Sungrow SH10RT', 'Sungrow', 10000, 10000, 'hybrid', 'residential', 1, 'HV', 15000, 2, 2, 97.8, 1950.00, 400, 50, 20000, 0, 1, NULL, 'IEC 62109, VDE 4105, AS4777', 'China', 'IP65', 80, 550, 'global', '3-phase residential hybrid', 10),
('Huawei SUN2000-8KTL-M1', 'Huawei', 8000, 8000, 'on-grid', 'residential', 1, 'HV', 12000, 2, 2, 98.6, 1100.00, 400, 50, 8000, 0, 1, NULL, 'IEC 62109, VDE 4105', 'China', 'IP65', 160, 950, 'global', '3-phase residential on-grid', 10),
('SMA Sunny Tripower 10.0', 'SMA', 10000, 10000, 'on-grid', 'residential', 1, 'HV', 15000, 2, 2, 98.3, 2200.00, 400, 50, 10000, 0, 1, NULL, 'IEC 62109, VDE 4105, AS4777', 'Germany', 'IP65', 160, 1000, 'US,CA,GB,DE,FR,AU', 'Premium 3-phase residential', 10);


-- =============================================================
-- BATTERIES (~50 batteries: Various voltages and types)
-- =============================================================

INSERT INTO batteries (name, brand, capacity_ah, voltage, capacity_kwh, type, is_bms, cycle_life, dod, charging_current_max, weight_kg, dimensions, maintenance_free, temperature_range, communication, certifications, country_origin, price_usd, available_regions, features, warranty_years) VALUES

-- =============================================================
-- 48V LITHIUM/LFP BATTERIES (Most popular for residential)
-- =============================================================
('Pylontech US5000 4.8kWh', 'Pylontech', 100, 48, 4.80, 'lfp', 1, 6000, 0.90, 100, 36.0, '442x420x132mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 1050.00, 'global', 'Stackable, Rack mount, Popular choice', 10),
('Pylontech Force H2 7.1kWh', 'Pylontech', 148, 48, 7.10, 'lfp', 1, 6000, 0.90, 148, 68.0, '580x500x195mm', 1, '-10C to 50C', 'RS485, CAN, WiFi', 'IEC 62619, UN38.3', 'China', 2200.00, 'global', 'High voltage compatible, Expandable to 21.3kWh', 10),
('BYD Battery-Box Premium HVS 5.1', 'BYD', 64, 48, 5.10, 'lfp', 1, 6000, 0.96, 64, 58.0, '585x298x580mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3, VDE', 'China', 2400.00, 'global', 'Premium modular, Expandable to 12.8kWh', 15),
('BYD Battery-Box Premium HVS 10.2', 'BYD', 128, 48, 10.20, 'lfp', 1, 6000, 0.96, 128, 116.0, '585x298x1060mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3, VDE', 'China', 4500.00, 'global', 'Premium 10kWh modular', 15),
('Deye SE-G5.1 Pro', 'Deye', 100, 48, 5.12, 'lfp', 1, 6000, 0.90, 100, 45.0, '600x500x150mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 1100.00, 'global', 'Compatible with Deye inverters', 10),
('Deye RW-M6.1 Wall', 'Deye', 120, 48, 6.14, 'lfp', 1, 6000, 0.90, 100, 52.0, '670x560x160mm', 1, '-10C to 50C', 'RS485, CAN, WiFi', 'IEC 62619, UN38.3', 'China', 1500.00, 'global', 'Wall mounted, Space efficient', 10),
('Growatt ARK 10.2kWh HV', 'Growatt', 200, 48, 10.24, 'lfp', 1, 6000, 0.90, 100, 95.0, '760x580x310mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 3500.00, 'global', 'High voltage stack, Growatt compatible', 10),
('Growatt APX 5.0P', 'Growatt', 100, 48, 5.12, 'lfp', 1, 6000, 0.90, 100, 42.0, '470x600x160mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 1200.00, 'global', 'Modular design, Expandable', 10),
('Felicity Solar 48V 200Ah', 'Felicity Solar', 200, 48, 10.24, 'lfp', 1, 4000, 0.80, 100, 85.0, '650x520x275mm', 1, '-10C to 45C', 'RS485', 'IEC 62619', 'China', 1800.00, 'PK,IN,BD,NG,EG,ZA,VN,PH', 'Budget LFP, Rack mount', 5),
('Narada 48100 5kWh', 'Narada', 100, 48, 5.12, 'lfp', 1, 5000, 0.90, 100, 40.0, '440x420x132mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 980.00, 'PK,IN,BD,NG,EG,ZA,SA,AE', 'Budget premium LFP', 5),
('GoodWe Lynx Home U 5.4', 'GoodWe', 112, 48, 5.40, 'lfp', 1, 6000, 0.90, 100, 48.0, '600x450x155mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 1800.00, 'global', 'GoodWe ecosystem, Smart BMS', 10),
('Hubble AM-5', 'Hubble', 106, 48, 5.12, 'lfp', 1, 6000, 0.90, 100, 38.0, '440x420x132mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'South Africa', 1200.00, 'ZA,NG,EG,AE,SA', 'South African brand, Reliable', 10),

-- =============================================================
-- HIGH VOLTAGE BATTERIES (For HV inverters like Huawei, SolarEdge, Fronius)
-- =============================================================
('Huawei LUNA2000-10-S0 10kWh', 'Huawei', 20, 400, 10.00, 'lfp', 1, 6000, 0.95, 25, 82.0, '670x150x600mm', 1, '-10C to 55C', 'CAN, WiFi', 'IEC 62619, UN38.3, VDE', 'China', 4500.00, 'global', 'HV modular, Expandable to 30kWh, FusionSolar', 10),
('Huawei LUNA2000-15-S0 15kWh', 'Huawei', 30, 400, 15.00, 'lfp', 1, 6000, 0.95, 37, 120.0, '670x150x870mm', 1, '-10C to 55C', 'CAN, WiFi', 'IEC 62619, UN38.3, VDE', 'China', 6200.00, 'global', '15kWh HV stack', 10),
('BYD Battery-Box Premium HVM 11.0', 'BYD', 22, 400, 11.04, 'lfp', 1, 6000, 0.96, 25, 114.0, '585x298x1200mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3, VDE', 'China', 5200.00, 'global', 'HVM series, Modular up to 22kWh', 15),
('BYD Battery-Box Premium HVM 16.6', 'BYD', 33, 400, 16.56, 'lfp', 1, 6000, 0.96, 37, 170.0, '585x298x1720mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3, VDE', 'China', 7500.00, 'global', 'Large HV residential/commercial', 15),
('Tesla Powerwall 3', 'Tesla', 35, 400, 13.50, 'lfp', 1, 5000, 0.95, 33, 99.0, '1098x609x193mm', 1, '-20C to 50C', 'WiFi, Ethernet, CAN', 'UL 9540, IEC 62619', 'USA', 8500.00, 'US,CA,AU,GB,DE,FR,JP', 'Integrated inverter, Storm Watch, Premium', 10),
('Enphase IQ Battery 5P', 'Enphase', 12, 400, 5.00, 'lfp', 1, 4000, 0.95, 12, 55.0, '1122x637x168mm', 1, '-15C to 50C', 'Ethernet, WiFi', 'UL 9540, IEC 62619', 'USA', 5500.00, 'US,CA,AU,GB,DE,FR', 'Enphase ecosystem, Micro-based', 15),
('Enphase IQ Battery 10T', 'Enphase', 24, 400, 10.00, 'lfp', 1, 4000, 0.95, 24, 108.0, '1122x637x328mm', 1, '-15C to 50C', 'Ethernet, WiFi', 'UL 9540, IEC 62619', 'USA', 10500.00, 'US,CA,AU,GB,DE,FR', '10kWh Enphase ecosystem', 15),
('SolarEdge Home Battery 10kWh', 'SolarEdge', 22, 400, 9.70, 'lfp', 1, 5000, 0.94, 20, 110.0, '920x540x205mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'Israel', 5800.00, 'US,CA,GB,DE,FR,AU', 'SolarEdge ecosystem, DC-coupled', 10),
('Sungrow SBR128 12.8kWh', 'Sungrow', 25, 400, 12.80, 'lfp', 1, 6000, 0.90, 30, 95.0, '620x580x350mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 4200.00, 'global', 'HV modular, Sungrow compatible', 10),
('Sungrow SBR256 25.6kWh', 'Sungrow', 50, 400, 25.60, 'lfp', 1, 6000, 0.90, 60, 186.0, '620x580x650mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 8000.00, 'global', 'Large HV, Commercial ready', 10),

-- =============================================================
-- 12V/24V BATTERIES (Off-grid, small systems)
-- =============================================================
('Victron Smart LiFePO4 12.8V 200Ah', 'Victron Energy', 200, 12, 2.56, 'lfp', 1, 5000, 0.90, 200, 22.0, '452x238x220mm', 1, '-20C to 50C', 'Bluetooth', 'UN38.3', 'Netherlands', 1350.00, 'global', 'Off-grid premium, Bluetooth monitoring', 5),
('Victron Smart LiFePO4 25.6V 200Ah', 'Victron Energy', 200, 24, 5.12, 'lfp', 1, 5000, 0.90, 200, 42.0, '452x476x220mm', 1, '-20C to 50C', 'Bluetooth', 'UN38.3', 'Netherlands', 2600.00, 'global', '24V off-grid premium', 5),
('Battle Born 100Ah 12V LiFePO4', 'Battle Born', 100, 12, 1.28, 'lfp', 1, 3000, 0.90, 100, 13.0, '330x173x212mm', 1, '-20C to 50C', 'None', 'UN38.3, UL', 'USA', 850.00, 'US,CA', 'RV/Marine, Drop-in replacement', 10),
('SOK 12V 206Ah LiFePO4', 'SOK Battery', 206, 12, 2.64, 'lfp', 1, 4000, 0.90, 100, 24.5, '483x178x262mm', 1, '-20C to 50C', 'Bluetooth', 'UN38.3', 'China', 680.00, 'US,CA', 'Budget LFP, High capacity', 7),
('EG4 LifePower4 48V 100Ah', 'EG4', 100, 48, 5.12, 'lfp', 1, 7000, 0.90, 100, 41.0, '440x420x132mm', 1, '-10C to 50C', 'RS485, CAN', 'UL 9540A, UN38.3', 'China', 1150.00, 'US,CA', 'USA off-grid popular, High cycle', 10),
('Renogy 12V 200Ah LFP', 'Renogy', 200, 12, 2.56, 'lfp', 1, 4000, 0.90, 100, 22.0, '483x170x240mm', 1, '-20C to 50C', 'Bluetooth', 'UN38.3', 'USA', 750.00, 'US,CA', 'Off-grid/RV, Bluetooth BMS', 5),

-- =============================================================
-- LEAD-ACID / GEL / AGM (Budget markets)
-- =============================================================
('Trojan T-105 6V 225Ah', 'Trojan', 225, 6, 1.35, 'lead-acid', 0, 1200, 0.50, 45, 28.0, '264x181x276mm', 0, '0C to 45C', 'None', 'IEC 60896', 'USA', 195.00, 'global', 'Deep cycle flooded, Golf cart standard', 2),
('Rolls S-550 6V 428Ah', 'Rolls/Surrette', 428, 6, 2.57, 'lead-acid', 0, 2500, 0.50, 85, 55.0, '318x181x425mm', 0, '0C to 45C', 'None', 'IEC 60896', 'Canada', 420.00, 'US,CA,AU', 'Premium deep cycle, Long life', 3),
('Narada 12V 200Ah GEL', 'Narada', 200, 12, 2.40, 'gel', 0, 1500, 0.70, 40, 58.0, '522x240x219mm', 1, '-10C to 45C', 'None', 'IEC 60896, IEC 61427', 'China', 280.00, 'PK,IN,BD,NG,EG,ZA,SA,AE', 'Solar GEL, Maintenance free', 3),
('Vision 6FM200 12V 200Ah AGM', 'Vision', 200, 12, 2.40, 'agm', 0, 1000, 0.60, 60, 55.0, '522x240x219mm', 1, '-15C to 50C', 'None', 'IEC 60896', 'China', 220.00, 'PK,IN,BD,NG,EG,ZA', 'Budget AGM solar', 2),
('Phoenix 12V 200Ah Tubular GEL', 'Phoenix', 200, 12, 2.40, 'gel', 0, 2500, 0.75, 40, 62.0, '522x240x240mm', 1, '-10C to 45C', 'None', 'IEC 60896, IEC 61427', 'China', 320.00, 'PK,IN,BD,SA,AE,EG', 'Tubular GEL, Long life budget', 3),
('Ritar 12V 150Ah GEL', 'Ritar', 150, 12, 1.80, 'gel', 0, 1800, 0.70, 30, 43.0, '483x170x240mm', 1, '-10C to 45C', 'None', 'IEC 60896', 'China', 185.00, 'PK,IN,BD,NG,EG,ZA,VN,PH', 'Budget GEL solar', 2),
('Hoppecke 8 OPzS 800 2V 800Ah', 'Hoppecke', 800, 2, 1.60, 'lead-acid', 0, 3000, 0.60, 160, 45.0, '145x206x580mm', 0, '0C to 45C', 'None', 'IEC 60896, DIN 40736', 'Germany', 380.00, 'global', 'Tubular plate, Industrial grade', 5),

-- =============================================================
-- COMMERCIAL/INDUSTRIAL BATTERIES (Large capacity)
-- =============================================================
('BYD Battery-Box Premium C-Series 40kWh', 'BYD', 80, 400, 40.00, 'lfp', 1, 6000, 0.96, 94, 480.0, '1560x770x400mm', 1, '-10C to 50C', 'RS485, CAN, Ethernet', 'IEC 62619, UN38.3, UL 9540A', 'China', 18000.00, 'global', 'Commercial rack, Modular', 15),
('Pylontech PowerCube-H1 14.2kWh', 'Pylontech', 280, 48, 14.21, 'lfp', 1, 6000, 0.90, 140, 128.0, '700x560x420mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 4800.00, 'global', 'High capacity rack, Commercial', 10),
('Sungrow ST2752UX-US 100kWh', 'Sungrow', 200, 400, 100.00, 'lfp', 1, 6000, 0.90, 125, 1100.0, '2600x1350x860mm', 1, '-10C to 50C', 'CAN, Ethernet', 'IEC 62619, UL 9540A', 'China', 42000.00, 'global', 'Container battery, Liquid cooled', 15),
('Tesla Megapack 2 3.9MWh', 'Tesla', 1000, 400, 3900.00, 'lfp', 1, 5000, 0.95, 500, 38000.0, '7620x1600x2770mm', 1, '-30C to 50C', 'Ethernet, CAN', 'UL 9540A', 'USA', 1200000.00, 'US,CA,AU,GB,DE,FR,JP', 'Utility-scale, AC-coupled', 15),
('Huawei LUNA2000-200KWH-2H1', 'Huawei', 500, 400, 200.00, 'lfp', 1, 6000, 0.95, 250, 2200.0, '2685x900x2100mm', 1, '-10C to 55C', 'CAN, Ethernet, WiFi', 'IEC 62619, UN38.3', 'China', 80000.00, 'global', '200kWh commercial ESS, Smart cooling', 10),

-- =============================================================
-- SERVER RACK BATTERIES (48V, popular for parallel)
-- =============================================================
('Megarevo 48V 100Ah Server Rack', 'Megarevo', 100, 48, 5.12, 'lfp', 1, 6000, 0.90, 100, 42.0, '440x420x132mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 900.00, 'global', 'Budget server rack LFP', 5),
('Sunsynk 5.32kWh', 'Sunsynk', 104, 48, 5.32, 'lfp', 1, 6000, 0.90, 100, 41.0, '440x420x135mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 1100.00, 'ZA,GB,AE,SA,NG', 'Sunsynk ecosystem, Popular in SA', 10),
('FreedomWon eTower 5.3kWh', 'FreedomWon', 110, 48, 5.32, 'lfp', 1, 6000, 0.90, 100, 38.0, '500x600x150mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619', 'South Africa', 1800.00, 'ZA,NG', 'South African made, Premium build', 10),
('Dyness A48100 4.8kWh', 'Dyness', 100, 48, 4.80, 'lfp', 1, 6000, 0.90, 100, 37.0, '440x420x132mm', 1, '-10C to 50C', 'RS485, CAN', 'IEC 62619, UN38.3', 'China', 950.00, 'global', 'Budget rack mount, Stackable to 16', 10);

-- Verify counts
SELECT 'Panels' as product, COUNT(*) as total FROM panels
UNION ALL
SELECT 'Inverters', COUNT(*) FROM inverters
UNION ALL
SELECT 'Batteries', COUNT(*) FROM batteries;
