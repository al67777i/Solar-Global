<?php
/**
 * Find Solar Installers — AJAX-Powered International Installer Search
 *
 * Endpoints:
 *   ?ajax=installers       — Paginated installer listing (JSON)
 *   ?ajax=installer_detail — Full profile with reviews, portfolio, areas (JSON)
 *   ?ajax=submit_review    — Submit a review (POST, JSON)
 *   (default)              — Full HTML page
 */

require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/subscription_helpers.php';
require_once 'includes/location_helper.php';
require_once 'includes/csrf.php';

$db = getDB();

// ════════════════════════════════════════════════════════════════
// AJAX Endpoints — respond with JSON and exit early
// ════════════════════════════════════════════════════════════════

if (isset($_GET['ajax'])) {

    if (session_status() === PHP_SESSION_NONE) session_start();

    header('Content-Type: application/json; charset=utf-8');

    // ── Installers endpoint ─────────────────────────────────
    if ($_GET['ajax'] === 'installers') {

        if (!rate_limit('fi_installers', 60, 60)) { respond_rate_limited(); }

        $lat       = isset($_GET['lat']) ? (float)$_GET['lat'] : null;
        $lng       = isset($_GET['lng']) ? (float)$_GET['lng'] : null;
        $radius    = max(5, min(500, (int)($_GET['radius'] ?? 100)));
        $sort      = $_GET['sort'] ?? 'distance';
        $type      = trim($_GET['type'] ?? '');
        $size      = trim($_GET['size'] ?? '');
        $min_rating = max(0, min(5, (float)($_GET['min_rating'] ?? 0)));
        $offset    = max(0, (int)($_GET['offset'] ?? 0));
        $limit     = max(1, min(50, (int)($_GET['limit'] ?? 10)));

        $valid_sorts = ['distance', 'rating', 'price'];
        if (!in_array($sort, $valid_sorts)) $sort = 'distance';

        $valid_types = ['', 'Residential', 'Commercial', 'Industrial'];
        if (!in_array($type, $valid_types)) $type = '';

        $has_location = ($lat !== null && $lng !== null && ($lat != 0 || $lng != 0));

        // Installer filter: show all active/approved installers
        // The subscription filter is intentionally relaxed here to include
        // free-tier installers (subscription_status='none') who are admin-activated.
        // This ensures newly approved installers appear immediately.
        $installer_filter = "i.status IN ('active','approved')";

        // Country code for currency conversion
        $country_code = 'US';
        if (!empty($_COOKIE['sg_location'])) {
            $loc_cookie = json_decode($_COOKIE['sg_location'], true);
            if (!empty($loc_cookie['country_code'])) {
                $country_code = strtoupper(substr($loc_cookie['country_code'], 0, 3));
            }
        }
        $currency_info = get_country_currency_info($country_code);

        // Distance select
        $distance_select = $has_location
            ? haversine_sql('i.latitude', 'i.longitude') . ' AS distance_km'
            : '9999999 AS distance_km';

        $where_clauses = [
            $installer_filter,
            "i.latitude IS NOT NULL",
            "i.longitude IS NOT NULL",
        ];
        $params = [];

        // Haversine params for SELECT
        $select_params = [];
        if ($has_location) {
            $select_params = [$lat, $lng, $lat];
        }

        // Radius filter
        if ($has_location) {
            $where_clauses[] = haversine_sql('i.latitude', 'i.longitude') . ' <= ?';
            $params[] = $lat;
            $params[] = $lng;
            $params[] = $lat;
            $params[] = $radius;
        }

        // Type filter (search in specializations)
        if ($type !== '') {
            $where_clauses[] = "i.specializations LIKE ?";
            $params[] = '%' . $type . '%';
        }

        // Minimum rating
        if ($min_rating > 0) {
            $where_clauses[] = "i.avg_rating >= ?";
            $params[] = $min_rating;
        }

        $where_sql = implode(' AND ', $where_clauses);

        // Sort
        $order_by = match($sort) {
            'rating'   => 'i.is_featured DESC, i.avg_rating DESC, distance_km ASC',
            'price'    => 'i.is_featured DESC, i.price_per_kw ASC, distance_km ASC',
            default    => 'i.is_featured DESC, distance_km ASC, i.avg_rating DESC',
        };

        $sql = "SELECT i.id, i.business_name, i.city, i.region, i.country_code,
                       i.latitude, i.longitude, i.phone, i.email, i.logo_path,
                       i.avg_rating, i.total_reviews, i.years_experience, i.team_size,
                       i.completed_installations, i.specializations, i.price_per_kw,
                       i.license_number, i.is_featured, i.service_radius_km, i.about_text,
                       {$distance_select}
                FROM installers i
                WHERE {$where_sql}
                ORDER BY {$order_by}
                LIMIT ? OFFSET ?";

        $all_params = array_merge($select_params, $params, [$limit, $offset]);

        // Count query
        $count_where_params = [];
        $count_where_clauses = [
            $installer_filter,
            "i.latitude IS NOT NULL",
            "i.longitude IS NOT NULL",
        ];
        if ($has_location) {
            $count_where_clauses[] = haversine_sql('i.latitude', 'i.longitude') . ' <= ?';
            $count_where_params = [$lat, $lng, $lat, $radius];
        }
        if ($type !== '') {
            $count_where_clauses[] = "i.specializations LIKE ?";
            $count_where_params[] = '%' . $type . '%';
        }
        if ($min_rating > 0) {
            $count_where_clauses[] = "i.avg_rating >= ?";
            $count_where_params[] = $min_rating;
        }
        $count_sql = "SELECT COUNT(*) FROM installers i WHERE " . implode(' AND ', $count_where_clauses);

        try {
            $count_stmt = $db->prepare($count_sql);
            $count_stmt->execute($count_where_params);
            $total = (int)$count_stmt->fetchColumn();

            $stmt = $db->prepare($sql);
            $stmt->execute($all_params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $installers = [];
            foreach ($rows as $row) {
                $local_price = $row['price_per_kw'] > 0
                    ? convert_usd_to_local((float)$row['price_per_kw'], $country_code)
                    : 0;
                $installers[] = [
                    'id'                     => (int)$row['id'],
                    'business_name'          => $row['business_name'] ?? '',
                    'city'                   => $row['city'] ?? '',
                    'region'                 => $row['region'] ?? '',
                    'country_code'           => $row['country_code'] ?? '',
                    'latitude'               => (float)$row['latitude'],
                    'longitude'              => (float)$row['longitude'],
                    'phone'                  => $row['phone'] ?? '',
                    'email'                  => $row['email'] ?? '',
                    'logo_path'              => !empty($row['logo_path']) ? get_image_url($row['logo_path']) : '',
                    'avg_rating'             => round((float)$row['avg_rating'], 1),
                    'total_reviews'          => (int)$row['total_reviews'],
                    'years_experience'       => (int)$row['years_experience'],
                    'team_size'              => (int)$row['team_size'],
                    'completed_installations'=> (int)$row['completed_installations'],
                    'specializations'        => $row['specializations'] ? (json_decode($row['specializations'], true) ?: array_map('trim', explode(',', $row['specializations']))) : [],
                    'price_per_kw'           => round($local_price, 2),
                    'formatted_price'        => $local_price > 0 ? $currency_info['currency_symbol'] . ' ' . number_format($local_price, 0, '.', ',') : '',
                    'license_number'         => $row['license_number'] ?? '',
                    'is_featured'            => (bool)$row['is_featured'],
                    'service_radius_km'      => (int)$row['service_radius_km'],
                    'distance_km'            => $has_location ? round((float)$row['distance_km'], 1) : null,
                    'about_text'             => $row['about_text'] ?? '',
                ];
            }

            echo json_encode([
                'installers' => $installers,
                'total'      => $total,
                'currency'   => $currency_info,
            ]);
        } catch (Exception $e) {
            error_log('Find Installer AJAX error: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'Failed to load installers.']);
        }
        exit;
    }

    // ── Installer detail endpoint ───────────────────────────
    if ($_GET['ajax'] === 'installer_detail') {

        if (!rate_limit('fi_detail', 60, 60)) { respond_rate_limited(); }

        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid installer ID.']);
            exit;
        }

        try {
            // Full installer data
            $stmt = $db->prepare("SELECT * FROM installers WHERE id = ? AND status IN ('active','approved')");
            $stmt->execute([$id]);
            $inst = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$inst) {
                http_response_code(404);
                echo json_encode(['error' => 'Installer not found.']);
                exit;
            }

            // Reviews (approved)
            $rStmt = $db->prepare("SELECT reviewer_name, rating, title, review_text, project_type, system_size_kw, created_at, admin_response FROM installer_reviews WHERE installer_id = ? AND status = 'approved' ORDER BY created_at DESC");
            $rStmt->execute([$id]);
            $reviews = $rStmt->fetchAll(PDO::FETCH_ASSOC);

            // Portfolio
            $pStmt = $db->prepare("SELECT image_path, title, system_size_kw, description FROM installer_portfolio WHERE installer_id = ? ORDER BY created_at DESC");
            $pStmt->execute([$id]);
            $portfolio = $pStmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($portfolio as &$p) {
                $p['image_path'] = !empty($p['image_path']) ? get_image_url($p['image_path']) : '';
            }
            unset($p);

            // Service areas
            $aStmt = $db->prepare("SELECT area_name, radius_km, is_primary FROM installer_service_areas WHERE installer_id = ? ORDER BY is_primary DESC");
            $aStmt->execute([$id]);
            $areas = $aStmt->fetchAll(PDO::FETCH_ASSOC);

            // Rating breakdown
            $bStmt = $db->prepare("SELECT rating, COUNT(*) as cnt FROM installer_reviews WHERE installer_id = ? AND status = 'approved' GROUP BY rating");
            $bStmt->execute([$id]);
            $breakdown = [];
            foreach ($bStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $breakdown[$row['rating']] = (int)$row['cnt'];
            }

            echo json_encode([
                'installer'        => [
                    'id'                      => (int)$inst['id'],
                    'business_name'           => $inst['business_name'] ?? '',
                    'about_text'              => $inst['about_text'] ?? '',
                    'phone'                   => $inst['phone'] ?? '',
                    'email'                   => $inst['email'] ?? '',
                    'address'                 => $inst['address'] ?? '',
                    'city'                    => $inst['city'] ?? '',
                    'region'                  => $inst['region'] ?? '',
                    'country_code'            => $inst['country_code'] ?? '',
                    'years_experience'        => (int)$inst['years_experience'],
                    'team_size'               => (int)$inst['team_size'],
                    'completed_installations' => (int)$inst['completed_installations'],
                    'license_number'          => $inst['license_number'] ?? '',
                    'service_radius_km'       => (int)$inst['service_radius_km'],
                ],
                'reviews'          => $reviews,
                'portfolio'        => $portfolio,
                'service_areas'    => $areas,
                'rating_breakdown' => $breakdown,
            ]);
        } catch (Exception $e) {
            error_log('Installer detail error: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'Failed to load installer details.']);
        }
        exit;
    }

    // ── Submit review endpoint (POST) ───────────────────────
    if ($_GET['ajax'] === 'submit_review' && $_SERVER['REQUEST_METHOD'] === 'POST') {

        if (!rate_limit('fi_review', 5, 300)) { respond_rate_limited(); }

        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) $input = $_POST;

        if (!validate_csrf_token($input['csrf_token'] ?? '')) {
            http_response_code(403);
            echo json_encode(['error' => 'Invalid security token. Please reload and try again.']);
            exit;
        }

        $installer_id    = (int)($input['installer_id'] ?? 0);
        $reviewer_name   = trim($input['reviewer_name'] ?? '');
        $reviewer_email  = trim($input['reviewer_email'] ?? '');
        $reviewer_phone  = trim($input['reviewer_phone'] ?? '');
        $rating          = (int)($input['rating'] ?? 0);
        $title           = trim($input['review_title'] ?? '');
        $review_text     = trim($input['review_text'] ?? '');
        $project_type    = trim($input['project_type'] ?? '');
        $system_size_kw  = (float)($input['system_size_kw'] ?? 0);
        $installation_date = trim($input['installation_date'] ?? '');

        $errors = [];
        if ($installer_id <= 0) $errors[] = 'Invalid installer.';
        if ($reviewer_name === '') $errors[] = 'Name is required.';
        if ($reviewer_email === '' || !filter_var($reviewer_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
        if ($rating < 1 || $rating > 5) $errors[] = 'Rating must be between 1 and 5.';
        if ($review_text === '') $errors[] = 'Review text is required.';

        if (!empty($errors)) {
            http_response_code(422);
            echo json_encode(['error' => implode(' ', $errors)]);
            exit;
        }

        try {
            $chk = $db->prepare("SELECT id FROM installers WHERE id = ? AND status IN ('active','approved')");
            $chk->execute([$installer_id]);
            if (!$chk->fetch()) {
                http_response_code(404);
                echo json_encode(['error' => 'Installer not found.']);
                exit;
            }

            // Order gate: user must have a completed order with this installer
            $orderGate = $db->prepare("
                SELECT COUNT(*) FROM installer_orders
                WHERE installer_id = ? AND status = 'completed'
                  AND (customer_id IN (SELECT id FROM customers WHERE email = ?)
                       OR description LIKE CONCAT('%', ?, '%'))
            ");
            $orderGate->execute([$installer_id, $reviewer_email, $reviewer_email]);
            $hasCompletedOrder = (int)$orderGate->fetchColumn() > 0;

            if (!$hasCompletedOrder) {
                $cid = $_SESSION['customer_id'] ?? 0;
                if ($cid > 0) {
                    $oc = $db->prepare("SELECT COUNT(*) FROM installer_orders WHERE installer_id = ? AND customer_id = ? AND status = 'completed'");
                    $oc->execute([$installer_id, $cid]);
                    $hasCompletedOrder = (int)$oc->fetchColumn() > 0;
                }
            }

            if (!$hasCompletedOrder) {
                http_response_code(403);
                echo json_encode(['error' => 'You can only review an installer after completing an installation order with them.']);
                exit;
            }

            $stmt = $db->prepare("INSERT INTO installer_reviews
                (installer_id, reviewer_name, reviewer_email, reviewer_phone, rating, title, review_text, project_type, system_size_kw, installation_date, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())");
            $stmt->execute([
                $installer_id, $reviewer_name, $reviewer_email, $reviewer_phone,
                $rating, $title, $review_text, $project_type,
                $system_size_kw > 0 ? $system_size_kw : null,
                $installation_date ?: null
            ]);

            echo json_encode(['success' => true, 'message' => 'Thank you! Your review will be published after moderation.']);
        } catch (Exception $e) {
            error_log('Review submit error: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'Failed to submit review. Please try again.']);
        }
        exit;
    }

    // Unknown AJAX action
    http_response_code(400);
    echo json_encode(['error' => 'Invalid AJAX action.']);
    exit;
}

// ════════════════════════════════════════════════════════════════
// HTML Page — Full Find Installer layout
// ════════════════════════════════════════════════════════════════

set_security_headers();
if (session_status() === PHP_SESSION_NONE) session_start();

trackVisitor($db);

$page_title       = "Find Solar Installers Near You";
$page_description = "Search verified solar installers near you. Compare ratings, prices, portfolios and request installation quotes from trusted professionals.";
$page_keywords    = "solar installer, find solar installer, solar installation, solar panel installer near me";
$current_page     = 'find-installer';

$user_location = detect_user_location();
$user_radius   = get_user_radius(100);

$page_country_code = 'US';
if (!empty($_COOKIE['sg_location'])) {
    $loc_data = json_decode($_COOKIE['sg_location'], true);
    if (!empty($loc_data['country_code'])) $page_country_code = strtoupper(substr($loc_data['country_code'], 0, 3));
} elseif (!empty($user_location['country_code'])) {
    $page_country_code = strtoupper($user_location['country_code']);
}
$page_currency = get_country_currency_info($page_country_code);

$maps_key = get_system_setting('google_maps_api_key', '');
// No hardcoded fallback — key must be set in Admin → Settings

$csrf_token = generate_csrf_token();

include 'includes/header.php';
?>

<style>
/* ═══════════════════════════════════════════════════
   Find Installer — Premium Dark Theme (matches store.php)
   ═══════════════════════════════════════════════════ */

/* Hero */
.fi-hero {
    position: relative;
    background: linear-gradient(160deg, #0a0a0a 0%, #111318 30%, #0f1419 60%, #0a0a0a 100%);
    padding: 32px 24px 28px;
    color: #fff;
    font-family: 'Inter', sans-serif;
    overflow: hidden;
    border-bottom: 2px solid rgba(245,158,11,0.15);
}
.fi-hero::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 600px;
    height: 600px;
    background: radial-gradient(circle, rgba(245,158,11,0.08) 0%, transparent 70%);
    pointer-events: none;
}
.fi-hero::after {
    content: '';
    position: absolute;
    inset: 0;
    background-image:
        linear-gradient(rgba(255,255,255,0.015) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,0.015) 1px, transparent 1px);
    background-size: 50px 50px;
    pointer-events: none;
}
/* Floating accent shapes */
.fi-hero-shape {
    position: absolute;
    pointer-events: none;
    z-index: 0;
}
.fi-hero-glow {
    position: absolute;
    border-radius: 50%;
    filter: blur(60px);
    pointer-events: none;
    z-index: 0;
}
.fi-hero-glow--amber {
    width: 300px; height: 300px;
    background: rgba(245,158,11,0.05);
    top: -10%; left: -5%;
}
.fi-hero-glow--teal {
    width: 200px; height: 200px;
    background: rgba(52,211,153,0.04);
    bottom: -10%; right: 20%;
}
.fi-hero-inner {
    position: relative;
    z-index: 2;
    max-width: 1280px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 480px;
    gap: 28px;
    align-items: stretch;
}
.fi-hero-left {
    display: flex;
    flex-direction: column;
    justify-content: center;
}
.fi-hero-title {
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.03em;
    margin: 0 0 6px;
    line-height: 1.15;
    color: #ffffff;
}
.fi-hero-title span {
    background: linear-gradient(135deg, #F59E0B, #FBBF24);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
.fi-hero-sub {
    font-size: 0.9rem;
    color: #a8a8b3;
    margin: 0 0 20px;
    line-height: 1.5;
}

/* Search bar in hero */
.fi-hero-search {
    position: relative;
    margin-bottom: 18px;
}
.fi-hero-search-box {
    display: flex;
    align-items: center;
    background: rgba(255,255,255,0.06);
    border: 2px solid rgba(245,158,11,0.2);
    border-radius: 14px;
    padding: 4px 6px;
    transition: all 0.3s cubic-bezier(.4,0,.2,1);
    backdrop-filter: blur(8px);
}
.fi-hero-search-box:focus-within {
    border-color: #F59E0B;
    background: rgba(255,255,255,0.1);
    box-shadow: 0 0 0 4px rgba(245,158,11,0.12), 0 8px 32px rgba(245,158,11,0.08);
    transform: scale(1.01);
}
.fi-hero-search-box .search-icon-wrap {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 42px;
    height: 42px;
    border-radius: 10px;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    flex-shrink: 0;
}
.fi-hero-search-input {
    flex: 1;
    border: none;
    background: transparent;
    color: #f1f5f9;
    font-size: 1rem;
    font-weight: 500;
    padding: 12px 14px;
    outline: none;
    font-family: inherit;
}
.fi-hero-search-input::placeholder { color: #71717a; font-weight: 400; }

/* Location row */
.fi-loc-row {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 16px;
    flex-wrap: wrap;
}
.fi-loc-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(245,158,11,0.08);
    border: 1px solid rgba(245,158,11,0.2);
    border-radius: 10px;
    padding: 8px 14px;
    font-size: 0.82rem;
    color: #F59E0B;
    font-weight: 600;
}
.fi-loc-badge svg { flex-shrink: 0; }
.fi-loc-change {
    padding: 8px 16px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 8px;
    color: #a1a1aa;
    font-size: 0.8rem;
    font-weight: 500;
    cursor: pointer;
    font-family: inherit;
    transition: all 0.2s;
}
.fi-loc-change:hover { background: rgba(255,255,255,0.1); color: #f1f5f9; }

/* Sliders */
.fi-sliders-row {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
}
.fi-slider-group {
    flex: 1;
    min-width: 140px;
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.06);
    border-radius: 12px;
    padding: 10px 14px;
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.fi-slider-group .slider-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.fi-slider-group label {
    font-size: 0.72rem;
    color: #a1a1aa;
    white-space: nowrap;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.06em;
}
.fi-slider-group input[type="range"] {
    width: 100%;
    height: 6px;
    border-radius: 3px;
    -webkit-appearance: none;
    appearance: none;
    outline: none;
    cursor: pointer;
    background: rgba(255,255,255,0.08);
}
.fi-slider-group input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 3px solid #F59E0B;
    background: #1a1a1a;
    cursor: pointer;
    box-shadow: 0 0 8px rgba(245,158,11,0.3);
    transition: box-shadow .15s;
}
.fi-slider-group input[type="range"]::-webkit-slider-thumb:hover {
    box-shadow: 0 0 14px rgba(245,158,11,0.5);
}
.fi-slider-group input[type="range"]::-moz-range-thumb {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 3px solid #F59E0B;
    background: #1a1a1a;
    cursor: pointer;
}
.slider-val { font-size: 0.9rem; font-weight: 700; min-width: 44px; text-align: right; }
.slider-val.amber { color: #F59E0B; }
.slider-val.green { color: #34D399; }

/* Hero map */
.fi-hero-map {
    border-radius: 16px;
    overflow: hidden;
    border: 2px solid rgba(245,158,11,0.12);
    min-height: 400px;
    background: #111;
    position: relative;
    box-shadow: 0 4px 30px rgba(0,0,0,0.4);
}
#fiMap {
    width: 100%;
    height: 100%;
    min-height: 400px;
}
.fi-hero-map .map-label {
    position: absolute;
    bottom: 10px;
    left: 10px;
    background: rgba(10,10,10,0.85);
    color: #F59E0B;
    font-size: 0.75rem;
    font-weight: 600;
    padding: 5px 10px;
    border-radius: 6px;
    z-index: 500;
    pointer-events: none;
    backdrop-filter: blur(4px);
    border: 1px solid rgba(245,158,11,0.2);
}

/* Filter bar */
.fi-filters {
    background: #fafafa;
    border-bottom: 1px solid #e5e5e5;
    padding: 10px 24px;
    position: sticky;
    top: 68px;
    z-index: 50;
    font-family: 'Inter', sans-serif;
}
.fi-filters-inner {
    max-width: 1280px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}
.fi-pills { display: flex; gap: 4px; flex-wrap: wrap; }
.fi-pill {
    padding: 7px 16px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
    border: 1px solid #e5e5e5;
    background: #fff;
    color: #525252;
    cursor: pointer;
    transition: all 0.2s;
    font-family: inherit;
}
.fi-pill:hover { border-color: #F59E0B; color: #D97706; }
.fi-pill.active { background: #0a0a0a; color: #F59E0B; border-color: #0a0a0a; }
.fi-filter-sep { width: 1px; height: 24px; background: #e5e5e5; margin: 0 4px; }
.fi-filter-select {
    padding: 7px 12px;
    border: 1px solid #e5e5e5;
    border-radius: 8px;
    font-size: 0.8rem;
    font-family: inherit;
    color: #3f3f46;
    background: #fff;
    cursor: pointer;
    min-width: 110px;
}

/* Grid container */
.fi-grid-container {
    max-width: 1280px;
    margin: 0 auto;
    padding: 20px 24px 40px;
}
.fi-results-info {
    font-size: 0.8rem;
    color: #64748B;
    padding: 0 0 12px;
    font-family: 'Inter', sans-serif;
}

/* Installer card grid */
.fi-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

/* Installer card */
.fi-card {
    background: #fff;
    border-radius: 16px;
    border: 1px solid #E2E8F0;
    overflow: hidden;
    transition: box-shadow 0.25s, transform 0.2s;
    display: flex;
    flex-direction: column;
    opacity: 0;
    transform: translateY(20px);
    animation: fiCardIn 0.5s ease-out forwards;
}
.fi-card:hover {
    box-shadow: 0 8px 30px rgba(0,0,0,0.1);
    transform: translateY(-2px);
}
@keyframes fiCardIn {
    to { opacity: 1; transform: translateY(0); }
}
.fi-card.featured {
    border-color: #F59E0B;
    box-shadow: 0 0 0 1px #F59E0B;
    position: relative;
}
.fi-featured-badge {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    color: #0F172A;
    text-align: center;
    padding: 3px;
    font-size: 0.65rem;
    font-weight: 800;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    z-index: 2;
}
.fi-card-body { padding: 20px; }
.fi-card.featured .fi-card-body { padding-top: 30px; }
.fi-card-top {
    display: flex;
    gap: 14px;
    align-items: flex-start;
}
.fi-card-logo {
    width: 64px;
    height: 64px;
    border-radius: 12px;
    background: #F1F5F9;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    overflow: hidden;
    border: 1px solid #E2E8F0;
    font-size: 1.8rem;
    color: #94A3B8;
}
.fi-card-logo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.fi-card-info { flex: 1; min-width: 0; }
.fi-card-name {
    font-size: 1.1rem;
    font-weight: 700;
    color: #0F172A;
    margin: 0 0 4px;
    line-height: 1.3;
}
.fi-card-loc {
    color: #64748B;
    font-size: 0.82rem;
    margin: 0 0 6px;
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
}
.fi-distance-badge {
    display: inline-block;
    font-size: 0.68rem;
    font-weight: 700;
    color: #92400E;
    background: #FEF3C7;
    padding: 2px 8px;
    border-radius: 6px;
    white-space: nowrap;
}
.fi-card-stars {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 6px;
}
.fi-stars {
    color: #F59E0B;
    font-size: 0.9rem;
    letter-spacing: 1px;
    line-height: 1;
}
.fi-stars-count { color: #64748B; font-size: 0.78rem; }
.fi-card-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin: 10px 0;
    font-size: 0.8rem;
    color: #475569;
}
.fi-card-meta-item {
    display: flex;
    align-items: center;
    gap: 4px;
}
.fi-card-meta-item .licensed-badge {
    background: #D1FAE5;
    color: #065F46;
    font-size: 0.68rem;
    font-weight: 600;
    padding: 2px 8px;
    border-radius: 4px;
}
.fi-card-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    margin: 8px 0;
}
.fi-tag {
    background: #EFF6FF;
    color: #1E40AF;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 0.72rem;
    font-weight: 600;
}
.fi-card-contact {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin: 6px 0;
}
.fi-contact-link {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 0.76rem;
    color: #0D3B6E;
    text-decoration: none;
    padding: 4px 10px;
    background: #F0F9FF;
    border-radius: 6px;
    transition: background 0.2s;
}
.fi-contact-link:hover { background: #DBEAFE; }
.fi-card-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 10px;
    padding-top: 12px;
    border-top: 1px solid #F1F5F9;
    gap: 8px;
    flex-wrap: wrap;
}
.fi-price {
    font-size: 1.05rem;
    font-weight: 700;
    color: #059669;
}
.fi-price small { font-weight: 400; color: #64748B; font-size: 0.78rem; }
.fi-card-actions {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}
.fi-btn-profile {
    padding: 8px 18px;
    border-radius: 8px;
    border: none;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    color: #0F172A;
    font-weight: 700;
    font-size: 0.82rem;
    cursor: pointer;
    transition: all 0.2s;
    font-family: inherit;
    text-decoration: none;
    display: inline-block;
}
.fi-btn-profile:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(245,158,11,0.3);
}
.fi-btn-request {
    padding: 8px 18px;
    border-radius: 8px;
    border: none;
    background: #16A34A;
    color: #fff;
    font-weight: 700;
    font-size: 0.82rem;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
    font-family: inherit;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}
.fi-btn-request:hover {
    background: #15803D;
    transform: translateY(-1px);
}

/* Profile expansion */
.fi-profile {
    display: none;
    background: #F8FAFC;
    border-top: 1px solid #E2E8F0;
    padding: 24px;
}
.fi-profile.active {
    display: block;
    animation: fiSlideDown 0.35s ease-out;
}
@keyframes fiSlideDown {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}
.fi-profile-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}
.fi-profile-section {
    background: #fff;
    border-radius: 12px;
    padding: 18px;
    border: 1px solid #E2E8F0;
}
.fi-profile-section.full { grid-column: 1 / -1; }
.fi-profile-section h3 {
    font-size: 0.95rem;
    color: #0F172A;
    margin: 0 0 12px;
    padding-bottom: 8px;
    border-bottom: 2px solid #F59E0B;
}
.fi-about-text { color: #475569; line-height: 1.65; font-size: 0.9rem; }
.fi-detail-list { list-style: none; padding: 0; margin: 0; }
.fi-detail-list li {
    display: flex;
    justify-content: space-between;
    padding: 7px 0;
    border-bottom: 1px solid #F1F5F9;
    color: #475569;
    font-size: 0.85rem;
}
.fi-detail-list li:last-child { border-bottom: none; }
.fi-detail-list li strong { color: #0F172A; }

/* Service area tags */
.fi-area-tags { display: flex; flex-wrap: wrap; gap: 6px; }
.fi-area-tag {
    background: #FEF3C7;
    color: #92400E;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.78rem;
    font-weight: 500;
}
.fi-area-tag.primary {
    background: #F59E0B;
    color: #0F172A;
    font-weight: 700;
}

/* Portfolio gallery */
.fi-portfolio-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 10px;
}
.fi-portfolio-item {
    border-radius: 10px;
    overflow: hidden;
    position: relative;
    aspect-ratio: 4/3;
    background: #E2E8F0;
    cursor: pointer;
}
.fi-portfolio-item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
}
.fi-portfolio-item:hover img { transform: scale(1.05); }
.fi-portfolio-caption {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 8px;
    background: linear-gradient(transparent, rgba(0,0,0,0.7));
    color: #fff;
    font-size: 0.72rem;
    font-weight: 600;
}

/* Rating breakdown */
.fi-rating-breakdown { margin-bottom: 14px; }
.fi-rb-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 5px;
    font-size: 0.82rem;
}
.fi-rb-label { width: 24px; text-align: right; color: #64748B; font-weight: 600; }
.fi-rb-bar {
    flex: 1;
    height: 8px;
    background: #E2E8F0;
    border-radius: 4px;
    overflow: hidden;
}
.fi-rb-fill {
    height: 100%;
    background: linear-gradient(90deg, #F59E0B, #D97706);
    border-radius: 4px;
    transition: width 0.6s ease-out;
}
.fi-rb-pct { width: 36px; text-align: right; color: #64748B; font-size: 0.78rem; }

/* Review cards */
.fi-review-card {
    background: #fff;
    border-radius: 10px;
    padding: 14px;
    border: 1px solid #E2E8F0;
    margin-bottom: 10px;
}
.fi-review-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 6px;
}
.fi-review-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    color: #0F172A;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 0.85rem;
    flex-shrink: 0;
}
.fi-review-author { font-weight: 700; color: #0F172A; font-size: 0.88rem; }
.fi-review-date { color: #94A3B8; font-size: 0.78rem; }
.fi-review-title { font-weight: 600; color: #334155; margin: 4px 0 6px; font-size: 0.88rem; }
.fi-review-text { color: #475569; font-size: 0.88rem; line-height: 1.6; }
.fi-review-meta { margin-top: 8px; font-size: 0.78rem; color: #94A3B8; }
.fi-review-meta .project-badge {
    display: inline-block;
    background: #EFF6FF;
    color: #1E40AF;
    padding: 2px 8px;
    border-radius: 4px;
    font-weight: 600;
    font-size: 0.72rem;
}
.fi-admin-response {
    background: #F8FAFC;
    border-left: 3px solid #F59E0B;
    padding: 10px 14px;
    margin-top: 10px;
    border-radius: 0 8px 8px 0;
}
.fi-admin-response strong { color: #0F172A; font-size: 0.78rem; }
.fi-admin-response p { margin: 4px 0 0; color: #475569; font-size: 0.82rem; }

/* Review form */
.fi-review-form { margin-top: 16px; }
.fi-review-form h4 { margin: 0 0 14px; color: #0F172A; font-size: 0.95rem; }
.fi-review-form-toggle {
    padding: 8px 16px;
    border-radius: 8px;
    border: 1px solid #E2E8F0;
    background: #fff;
    color: #475569;
    font-size: 0.82rem;
    font-weight: 600;
    cursor: pointer;
    font-family: inherit;
    transition: all 0.2s;
    margin-bottom: 14px;
}
.fi-review-form-toggle:hover { border-color: #F59E0B; color: #D97706; }
.fi-form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}
.fi-form-field { display: flex; flex-direction: column; gap: 4px; }
.fi-form-field.full { grid-column: 1 / -1; }
.fi-form-field label { font-size: 0.78rem; color: #475569; font-weight: 600; }
.fi-form-field input,
.fi-form-field select,
.fi-form-field textarea {
    padding: 10px 14px;
    border: 1px solid #CBD5E1;
    border-radius: 8px;
    font-size: 0.88rem;
    font-family: inherit;
    transition: border-color 0.2s;
    background: #fff;
    color: #0F172A;
}
.fi-form-field input:focus,
.fi-form-field select:focus,
.fi-form-field textarea:focus {
    outline: none;
    border-color: #F59E0B;
    box-shadow: 0 0 0 3px rgba(245,158,11,0.15);
}
.fi-form-field textarea { resize: vertical; min-height: 80px; }
.fi-star-input { display: flex; gap: 4px; flex-direction: row-reverse; justify-content: flex-end; }
.fi-star-input input { display: none; }
.fi-star-input label {
    font-size: 1.5rem;
    color: #CBD5E1;
    cursor: pointer;
    transition: color 0.15s;
    line-height: 1;
}
.fi-star-input label:hover,
.fi-star-input label:hover ~ label,
.fi-star-input input:checked ~ label { color: #F59E0B; }
.fi-btn-submit {
    grid-column: 1 / -1;
    padding: 12px;
    border-radius: 8px;
    border: none;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    color: #0F172A;
    font-size: 0.95rem;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s;
    font-family: inherit;
}
.fi-btn-submit:hover { box-shadow: 0 4px 14px rgba(245,158,11,0.35); }
.fi-btn-submit:disabled { background: #CBD5E1; cursor: not-allowed; }

/* Empty state */
.fi-empty-state {
    text-align: center;
    padding: 48px 24px;
    color: #64748B;
    font-family: 'Inter', sans-serif;
}
.fi-empty-state svg { margin-bottom: 12px; }
.fi-empty-state h3 { font-size: 1.1rem; color: #334155; margin: 0 0 6px; }
.fi-empty-state p { font-size: 0.9rem; margin: 0; color: #94A3B8; }

/* Load more */
.fi-load-more { text-align: center; padding: 20px; }
.fi-load-more-btn {
    display: inline-block;
    padding: 12px 32px;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    color: #fff;
    border: none;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
    transition: all 0.25s;
    box-shadow: 0 4px 12px rgba(245,158,11,0.3);
}
.fi-load-more-btn:hover {
    background: linear-gradient(135deg, #D97706, #B45309);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(245,158,11,0.4);
}
.fi-loading {
    text-align: center;
    padding: 20px;
    color: #94A3B8;
    font-size: 0.85rem;
}
.fi-loading .spinner {
    display: inline-block;
    width: 22px;
    height: 22px;
    border: 3px solid #E2E8F0;
    border-top-color: #F59E0B;
    border-radius: 50%;
    animation: fi-spin 0.7s linear infinite;
    margin-bottom: 6px;
}
@keyframes fi-spin { to { transform: rotate(360deg); } }

/* Toast */
.fi-toast {
    position: fixed;
    bottom: 24px;
    right: 24px;
    background: #065F46;
    color: #fff;
    padding: 10px 18px;
    border-radius: 8px;
    font-size: 0.85rem;
    font-family: 'Inter', sans-serif;
    font-weight: 500;
    box-shadow: 0 4px 16px rgba(0,0,0,0.15);
    z-index: 9999;
    transform: translateY(100px);
    opacity: 0;
    transition: all 0.3s ease;
}
.fi-toast.show { transform: translateY(0); opacity: 1; }
.fi-toast.error { background: #991B1B; }

/* Leaflet marker fix */
.fi-leaflet-marker { background: none !important; border: none !important; }

/* Responsive */
@media (max-width: 1024px) {
    .fi-hero-inner { grid-template-columns: 1fr; }
    .fi-hero-map { min-height: 300px; }
    #fiMap { min-height: 300px; }
}
@media (max-width: 900px) {
    .fi-grid { grid-template-columns: 1fr; }
    .fi-profile-grid { grid-template-columns: 1fr; }
    .fi-hero { padding: 20px 16px; }
    .fi-hero-title { font-size: 1.5rem; }
    .fi-hero-map { min-height: 250px; }
    #fiMap { min-height: 250px; }
    .fi-filters-inner { gap: 6px; }
}
@media (max-width: 600px) {
    .fi-card-top { flex-direction: column; align-items: center; text-align: center; }
    .fi-card-loc { justify-content: center; }
    .fi-card-meta { justify-content: center; }
    .fi-card-tags { justify-content: center; }
    .fi-card-contact { justify-content: center; }
    .fi-card-footer { flex-direction: column; align-items: stretch; }
    .fi-card-actions { justify-content: center; }
    .fi-form-grid { grid-template-columns: 1fr; }
    .fi-sliders-row { flex-direction: column; gap: 10px; }
    .fi-grid-container { padding: 16px 12px 30px; }
}
</style>

<!-- ═══════════════ Hero Section — Solar Black Theme ═══════════════ -->
<div class="fi-hero">
    <!-- Background accent glows -->
    <div class="fi-hero-glow fi-hero-glow--amber"></div>
    <div class="fi-hero-glow fi-hero-glow--teal"></div>

    <!-- Floating geometric shapes (animated via anime.js) -->
    <svg class="fi-hero-shape" id="fi-shape-1" style="top:8%;left:5%;opacity:0;" width="40" height="40" viewBox="0 0 40 40" fill="none">
        <rect x="4" y="4" width="32" height="32" rx="6" stroke="rgba(245,158,11,0.15)" stroke-width="1.5"/>
    </svg>
    <svg class="fi-hero-shape" id="fi-shape-2" style="top:65%;left:3%;opacity:0;" width="32" height="32" viewBox="0 0 32 32" fill="none">
        <circle cx="16" cy="16" r="12" stroke="rgba(52,211,153,0.12)" stroke-width="1.5"/>
    </svg>
    <svg class="fi-hero-shape" id="fi-shape-3" style="top:80%;left:45%;opacity:0;" width="36" height="36" viewBox="0 0 36 36" fill="none">
        <path d="M18 3L33 18L18 33L3 18Z" stroke="rgba(245,158,11,0.1)" stroke-width="1.5"/>
    </svg>

    <div class="fi-hero-inner">
        <div class="fi-hero-left" id="fi-hero-left">
            <h1 class="fi-hero-title">Find Solar <span>Installers</span></h1>
            <p class="fi-hero-sub">Compare ratings, prices and portfolios from verified solar professionals near you.</p>

            <!-- Search bar -->
            <div class="fi-hero-search">
                <div class="fi-hero-search-box">
                    <div class="search-icon-wrap">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    </div>
                    <input type="text" id="fiLocationInput" class="fi-hero-search-input" placeholder="Enter your city or address..." autocomplete="off">
                </div>
            </div>

            <!-- Location badge -->
            <div class="fi-loc-row">
                <div class="fi-loc-badge">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <span id="fiLocationLabel">
                        <?php if ($user_location['detected']): ?>
                            <?= sanitize($user_location['city'] ?: 'Your Location') ?>
                        <?php else: ?>
                            Detecting location...
                        <?php endif; ?>
                    </span>
                </div>
                <button class="fi-loc-change" id="fiChangeLocation" type="button">Change Location</button>
            </div>

            <!-- Sliders -->
            <div class="fi-sliders-row">
                <div class="fi-slider-group">
                    <div class="slider-header">
                        <label>Radius</label>
                        <span class="slider-val amber" id="fiRadiusValue"><?= (int)$user_radius ?> km</span>
                    </div>
                    <input type="range" id="fiRadius" min="10" max="500" step="10" value="<?= (int)$user_radius ?>">
                </div>
                <div class="fi-slider-group">
                    <div class="slider-header">
                        <label>Min Rating</label>
                        <span class="slider-val green" id="fiRatingValue">Any</span>
                    </div>
                    <input type="range" id="fiRating" min="0" max="5" step="0.5" value="0">
                </div>
            </div>
        </div>

        <!-- Map -->
        <div class="fi-hero-map">
            <div id="fiMap"></div>
            <div class="map-label" id="fiMapLabel">Your area</div>
        </div>
    </div>
</div>

<!-- Filters Bar -->
<div class="fi-filters">
    <div class="fi-filters-inner">
        <div class="fi-pills">
            <button class="fi-pill active" data-type="all">All</button>
            <button class="fi-pill" data-type="Residential">Residential</button>
            <button class="fi-pill" data-type="Commercial">Commercial</button>
            <button class="fi-pill" data-type="Industrial">Industrial</button>
        </div>
        <div class="fi-filter-sep"></div>
        <select class="fi-filter-select" id="fiSort">
            <option value="distance">Nearest First</option>
            <option value="rating">Highest Rated</option>
            <option value="price">Lowest Price</option>
        </select>
        <div class="fi-filter-sep"></div>
        <select class="fi-filter-select" id="fiSize">
            <option value="">Any Size</option>
            <option value="1-5">1 - 5 kW</option>
            <option value="5-10">5 - 10 kW</option>
            <option value="10-20">10 - 20 kW</option>
            <option value="20-50">20 - 50 kW</option>
            <option value="50+">50+ kW</option>
        </select>
    </div>
</div>

<!-- Results Grid -->
<div class="fi-grid-container">
    <div class="fi-results-info" id="fiResultsInfo"></div>
    <div class="fi-grid" id="fiGrid"></div>
    <div id="fiLoadMore" style="display:none;"></div>
</div>

<!-- Toast -->
<div class="fi-toast" id="fiToast"></div>

<!-- Google Maps -->
<script>
var fiUseGoogleMaps = false;
function fiGmapsReady() { fiUseGoogleMaps = true; fiInitApp(); }
function gm_authFailure() {
    fiUseGoogleMaps = false;
    var lk = document.createElement('link');
    lk.rel = 'stylesheet';
    lk.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    document.head.appendChild(lk);
    var sc = document.createElement('script');
    sc.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    sc.onload = function() { fiInitApp(); };
    document.head.appendChild(sc);
}
</script>
<script async src="https://maps.googleapis.com/maps/api/js?key=<?= htmlspecialchars($maps_key) ?>&libraries=places&callback=fiGmapsReady"></script>

<script>
// ═══════════════════════════════════════════
// Hero Entrance Animations (anime.js)
// Waits for window load so anime.js is guaranteed available
// Elements are fully visible by default; animation is enhancement only
// ═══════════════════════════════════════════
window.addEventListener('load', function() {
    if (typeof anime === 'undefined') return;

    // Set initial hidden state via JS (not CSS) so elements are visible if anime fails
    var heroTargets = ['.fi-hero-title', '.fi-hero-sub', '.fi-hero-search', '.fi-loc-row', '.fi-sliders-row', '.fi-hero-map'];
    heroTargets.forEach(function(sel) {
        var el = document.querySelector(sel);
        if (el) { el.style.opacity = '0'; el.style.transform = 'translateY(20px)'; }
    });

    // Hero content entrance
    anime.timeline({ easing: 'easeOutExpo' })
        .add({
            targets: '.fi-hero-title',
            opacity: [0, 1],
            translateY: [30, 0],
            duration: 800
        })
        .add({
            targets: '.fi-hero-sub',
            opacity: [0, 1],
            translateY: [20, 0],
            duration: 700
        }, '-=500')
        .add({
            targets: '.fi-hero-search',
            opacity: [0, 1],
            translateY: [20, 0],
            scale: [0.98, 1],
            duration: 700
        }, '-=400')
        .add({
            targets: '.fi-loc-row',
            opacity: [0, 1],
            translateX: [-20, 0],
            duration: 600
        }, '-=300')
        .add({
            targets: '.fi-sliders-row',
            opacity: [0, 1],
            translateY: [15, 0],
            duration: 600
        }, '-=300')
        .add({
            targets: '.fi-hero-map',
            opacity: [0, 1],
            scale: [0.95, 1],
            duration: 900,
            easing: 'easeOutCubic'
        }, '-=700');

    // Floating shapes — continuous loop
    anime({ targets: '#fi-shape-1', opacity: [0, 0.6], translateY: [0, -14], rotate: [0, 12], duration: 4500, direction: 'alternate', loop: true, easing: 'easeInOutSine', delay: 300 });
    anime({ targets: '#fi-shape-2', opacity: [0, 0.5], translateY: [0, 16], rotate: [0, -20], duration: 5500, direction: 'alternate', loop: true, easing: 'easeInOutSine', delay: 600 });
    anime({ targets: '#fi-shape-3', opacity: [0, 0.5], translateX: [0, 12], translateY: [0, -10], rotate: [0, 45], duration: 6000, direction: 'alternate', loop: true, easing: 'easeInOutSine', delay: 200 });

    // Glowing orbs pulse
    anime({ targets: '.fi-hero-glow', scale: [0.9, 1.1], opacity: [0.4, 0.8], duration: 4000, direction: 'alternate', loop: true, easing: 'easeInOutSine', delay: anime.stagger(1200) });
});
</script>

<script>
(function() {
    'use strict';

    // ═══════════════ State ═══════════════
    var state = {
        lat: <?= json_encode($user_location['lat']) ?>,
        lng: <?= json_encode($user_location['lng']) ?>,
        city: <?= json_encode($user_location['city']) ?>,
        country_code: <?= json_encode($user_location['country_code']) ?>,
        detected: <?= $user_location['detected'] ? 'true' : 'false' ?>,
        radius: <?= (int)$user_radius ?>,
        type: 'all',
        sort: 'distance',
        size: '',
        min_rating: 0,
        offset: 0,
        limit: 10,
        total: 0,
        loading: false,
        allLoaded: false,
        csrfToken: <?= json_encode($csrf_token) ?>,
        currency: <?= json_encode($page_currency) ?>,
        expandedProfile: null
    };

    var map = null;
    var markers = [];
    var userMarker = null;
    var radiusCircle = null;
    var infoWindow = null;
    var leafletMap = null;
    var leafletMarkers = null;
    var leafletUserMarker = null;
    var leafletRadiusCircle = null;

    var debounceTimer = null;

    // ═══════════════ DOM refs ═══════════════
    var grid = document.getElementById('fiGrid');
    var resultsInfo = document.getElementById('fiResultsInfo');
    var loadMoreWrap = document.getElementById('fiLoadMore');
    var locationInput = document.getElementById('fiLocationInput');
    var locationLabel = document.getElementById('fiLocationLabel');
    var radiusSlider = document.getElementById('fiRadius');
    var radiusValue = document.getElementById('fiRadiusValue');
    var ratingSlider = document.getElementById('fiRating');
    var ratingValue = document.getElementById('fiRatingValue');
    var mapLabel = document.getElementById('fiMapLabel');

    // ═══════════════ Init ═══════════════
    window.fiInitApp = function() {
        initMap();
        bindEvents();

        // Auto-detect location if not already detected
        if (!state.detected) {
            detectLocation();
        } else {
            loadInstallers(false);
        }
    };

    // If Google Maps never loads and no auth failure fires, init after timeout
    setTimeout(function() {
        if (!map && !leafletMap) {
            gm_authFailure();
        }
    }, 5000);

    // ═══════════════ Location Detection ═══════════════
    function detectLocation() {
        locationLabel.textContent = 'Detecting location...';

        // Try IP-based first (fast)
        fetch('http://ip-api.com/json/?fields=lat,lon,city,countryCode', { mode: 'cors' })
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d && d.lat && d.lon) {
                    setLocation(d.lat, d.lon, d.city || '', d.countryCode || '');
                } else {
                    tryBrowserGeolocation();
                }
            })
            .catch(function() {
                tryBrowserGeolocation();
            });
    }

    function tryBrowserGeolocation() {
        if (!navigator.geolocation) {
            locationLabel.textContent = 'Set location';
            loadInstallers(false);
            return;
        }
        navigator.geolocation.getCurrentPosition(function(pos) {
            reverseGeocode(pos.coords.latitude, pos.coords.longitude, function(city, cc) {
                setLocation(pos.coords.latitude, pos.coords.longitude, city, cc);
            });
        }, function() {
            locationLabel.textContent = 'Set location';
            loadInstallers(false);
        }, { enableHighAccuracy: false, timeout: 8000 });
    }

    function setLocation(lat, lng, city, cc) {
        state.lat = lat;
        state.lng = lng;
        state.city = city || '';
        state.country_code = cc || '';
        state.detected = true;

        // Save cookie
        var cookieData = JSON.stringify({ lat: lat, lng: lng, city: city, country_code: cc });
        document.cookie = 'sg_location=' + encodeURIComponent(cookieData) + ';path=/solarglobal/;max-age=' + (30*86400);

        locationLabel.textContent = city || 'Your Location';
        locationInput.value = city || '';
        mapLabel.textContent = city ? city + ' area' : 'Your area';

        updateMapCenter();
        resetAndLoad();
    }

    function reverseGeocode(lat, lng, cb) {
        if (fiUseGoogleMaps && typeof google !== 'undefined' && google.maps && google.maps.Geocoder) {
            var geocoder = new google.maps.Geocoder();
            geocoder.geocode({ location: { lat: lat, lng: lng } }, function(results, status) {
                if (status === 'OK' && results[0]) {
                    var city = '', cc = '';
                    results[0].address_components.forEach(function(c) {
                        if (c.types.indexOf('locality') !== -1) city = c.long_name;
                        if (c.types.indexOf('country') !== -1) cc = c.short_name;
                    });
                    cb(city || results[0].formatted_address.split(',')[0], cc);
                } else {
                    cb('', '');
                }
            });
        } else {
            fetch('https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lat + '&lon=' + lng + '&zoom=10', { headers: { 'Accept-Language': 'en' } })
                .then(function(r) { return r.json(); })
                .then(function(d) {
                    var city = (d.address && (d.address.city || d.address.town || d.address.village)) || '';
                    var cc = (d.address && d.address.country_code) ? d.address.country_code.toUpperCase() : '';
                    cb(city, cc);
                })
                .catch(function() { cb('', ''); });
        }
    }

    // Forward geocode: city/address name → lat/lng
    function geocodeSearch(query) {
        if (!query || query.length < 2) return;
        // Try Google Geocoder first
        if (fiUseGoogleMaps && typeof google !== 'undefined' && google.maps && google.maps.Geocoder) {
            var geocoder = new google.maps.Geocoder();
            geocoder.geocode({ address: query }, function(results, status) {
                if (status === 'OK' && results[0]) {
                    var loc = results[0].geometry.location;
                    var city = '', cc = '';
                    results[0].address_components.forEach(function(c) {
                        if (c.types.indexOf('locality') !== -1) city = c.long_name;
                        if (c.types.indexOf('country') !== -1) cc = c.short_name;
                    });
                    setLocation(loc.lat(), loc.lng(), city || query, cc);
                } else {
                    // Fallback to Nominatim
                    geocodeNominatim(query);
                }
            });
        } else {
            geocodeNominatim(query);
        }
    }

    function geocodeNominatim(query) {
        fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(query) + '&limit=1&addressdetails=1', {
            headers: { 'Accept-Language': 'en' }
        })
        .then(function(r) { return r.json(); })
        .then(function(results) {
            if (results && results.length > 0) {
                var r = results[0];
                var lat = parseFloat(r.lat);
                var lng = parseFloat(r.lon);
                var city = (r.address && (r.address.city || r.address.town || r.address.village || r.address.state)) || query;
                var cc = (r.address && r.address.country_code) ? r.address.country_code.toUpperCase() : '';
                setLocation(lat, lng, city, cc);
            } else {
                showToast('Location not found. Try a different city name.', 'warning');
            }
        })
        .catch(function() {
            showToast('Could not geocode location. Please try again.', 'error');
        });
    }

    // ═══════════════ Map Init ═══════════════
    function initMap() {
        var mapEl = document.getElementById('fiMap');
        if (!mapEl) return;

        var center = { lat: state.lat || 20, lng: state.lng || 0 };
        var zoom = state.detected ? 10 : 2;

        if (fiUseGoogleMaps) {
            map = new google.maps.Map(mapEl, {
                zoom: zoom,
                center: center,
                styles: [
                    { featureType: 'poi', stylers: [{ visibility: 'off' }] },
                    { featureType: 'transit', stylers: [{ visibility: 'off' }] }
                ],
                mapTypeControl: false,
                streetViewControl: false,
                fullscreenControl: true
            });

            infoWindow = new google.maps.InfoWindow();

            // Click on map to set location
            map.addListener('click', function(e) {
                reverseGeocode(e.latLng.lat(), e.latLng.lng(), function(city, cc) {
                    setLocation(e.latLng.lat(), e.latLng.lng(), city, cc);
                });
            });

            // Places autocomplete on search input
            if (google.maps.places) {
                var autocomplete = new google.maps.places.Autocomplete(locationInput, { types: ['(cities)'] });
                autocomplete.addListener('place_changed', function() {
                    var place = autocomplete.getPlace();
                    if (place.geometry) {
                        var cc = '';
                        (place.address_components || []).forEach(function(c) {
                            if (c.types.indexOf('country') !== -1) cc = c.short_name;
                        });
                        setLocation(
                            place.geometry.location.lat(),
                            place.geometry.location.lng(),
                            place.name || '',
                            cc
                        );
                    }
                });
            }

            addUserMarker();
        } else {
            // Leaflet
            leafletMap = L.map(mapEl, { zoomControl: true }).setView([center.lat, center.lng], zoom);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap'
            }).addTo(leafletMap);

            leafletMarkers = L.featureGroup().addTo(leafletMap);

            // Click to set location
            leafletMap.on('click', function(e) {
                reverseGeocode(e.latlng.lat, e.latlng.lng, function(city, cc) {
                    setLocation(e.latlng.lat, e.latlng.lng, city, cc);
                });
            });

            addUserMarkerLeaflet();
        }
    }

    function addUserMarker() {
        if (!map || !state.lat) return;

        if (userMarker) userMarker.setMap(null);
        if (radiusCircle) radiusCircle.setMap(null);

        userMarker = new google.maps.Marker({
            position: { lat: state.lat, lng: state.lng },
            map: map,
            icon: {
                path: google.maps.SymbolPath.CIRCLE,
                scale: 10,
                fillColor: '#3B82F6',
                fillOpacity: 0.9,
                strokeColor: '#fff',
                strokeWeight: 3
            },
            title: 'Your Location',
            zIndex: 999
        });

        radiusCircle = new google.maps.Circle({
            map: map,
            center: { lat: state.lat, lng: state.lng },
            radius: state.radius * 1000,
            strokeColor: '#F59E0B',
            strokeOpacity: 0.3,
            strokeWeight: 1,
            fillColor: '#F59E0B',
            fillOpacity: 0.05
        });
    }

    function addUserMarkerLeaflet() {
        if (!leafletMap || !state.lat) return;

        if (leafletUserMarker) leafletMap.removeLayer(leafletUserMarker);
        if (leafletRadiusCircle) leafletMap.removeLayer(leafletRadiusCircle);

        leafletUserMarker = L.circleMarker([state.lat, state.lng], {
            radius: 8, color: '#3B82F6', fillColor: '#3B82F6', fillOpacity: 0.9, weight: 3
        }).addTo(leafletMap).bindPopup('Your Location');

        leafletRadiusCircle = L.circle([state.lat, state.lng], {
            radius: state.radius * 1000,
            color: '#F59E0B',
            fillColor: '#F59E0B',
            fillOpacity: 0.05,
            weight: 1
        }).addTo(leafletMap);
    }

    function updateMapCenter() {
        if (map && state.lat) {
            map.setCenter({ lat: state.lat, lng: state.lng });
            map.setZoom(10);
            addUserMarker();
        } else if (leafletMap && state.lat) {
            leafletMap.setView([state.lat, state.lng], 10);
            addUserMarkerLeaflet();
        }
    }

    // ═══════════════ Map Markers ═══════════════
    function clearMapMarkers() {
        if (fiUseGoogleMaps) {
            markers.forEach(function(m) { m.setMap(null); });
            markers = [];
        } else if (leafletMarkers) {
            leafletMarkers.clearLayers();
        }
    }

    function addInstallerMarker(inst) {
        if (!inst.latitude || !inst.longitude) return;

        if (fiUseGoogleMaps && map) {
            var marker = new google.maps.Marker({
                position: { lat: inst.latitude, lng: inst.longitude },
                map: map,
                title: inst.business_name,
                icon: {
                    path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z',
                    fillColor: inst.is_featured ? '#F59E0B' : '#EF4444',
                    fillOpacity: 0.9,
                    strokeColor: '#fff',
                    strokeWeight: 1.5,
                    scale: 1.5,
                    anchor: new google.maps.Point(12, 22)
                }
            });

            marker.addListener('click', function() {
                var stars = '';
                for (var s = 0; s < 5; s++) stars += s < Math.round(inst.avg_rating) ? '★' : '☆';
                infoWindow.setContent(
                    '<div style="font-family:Inter,sans-serif;padding:4px;max-width:220px;">' +
                    '<strong style="font-size:0.92rem;">' + escHtml(inst.business_name) + '</strong><br>' +
                    '<span style="color:#F59E0B;">' + stars + '</span> ' +
                    '<span style="color:#64748B;font-size:0.78rem;">' + inst.avg_rating + '</span><br>' +
                    '<span style="color:#64748B;font-size:0.82rem;">' + escHtml(inst.city) + '</span>' +
                    (inst.distance_km !== null ? '<br><span style="font-size:0.78rem;color:#92400E;font-weight:600;">' + inst.distance_km + ' km</span>' : '') +
                    (inst.phone ? '<br><a href="tel:' + escHtml(inst.phone) + '" style="font-size:0.78rem;color:#0D3B6E;">' + escHtml(inst.phone) + '</a>' : '') +
                    '<br><a href="<?= BASE_URL ?>installer-detail.php?id=' + inst.id + '" style="color:#D97706;font-weight:600;font-size:0.82rem;text-decoration:none;">View Details</a>' +
                    '</div>'
                );
                infoWindow.open(map, marker);
            });

            markers.push(marker);
        } else if (leafletMap) {
            var color = inst.is_featured ? '#F59E0B' : '#EF4444';
            var icon = L.divIcon({
                className: 'fi-leaflet-marker',
                html: '<div style="width:24px;height:30px;"><svg viewBox="0 0 24 30" width="24" height="30"><path d="M12 0C8.13 0 5 3.13 5 7c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" fill="' + color + '" stroke="#fff" stroke-width="1.5"/><circle cx="12" cy="7" r="3" fill="#fff"/></svg></div>',
                iconSize: [24, 30], iconAnchor: [12, 30], popupAnchor: [0, -30]
            });
            var stars = '';
            for (var s = 0; s < 5; s++) stars += s < Math.round(inst.avg_rating) ? '★' : '☆';
            var lm = L.marker([inst.latitude, inst.longitude], { icon: icon });
            lm.bindPopup(
                '<div style="font-family:Inter,sans-serif;">' +
                '<strong>' + escHtml(inst.business_name) + '</strong><br>' +
                '<span style="color:#F59E0B;">' + stars + '</span> ' + inst.avg_rating + '<br>' +
                escHtml(inst.city) +
                (inst.phone ? '<br>' + escHtml(inst.phone) : '') +
                '<br><a href="<?= BASE_URL ?>installer-detail.php?id=' + inst.id + '" style="color:#D97706;font-weight:600;font-size:0.82rem;">View Details</a>' +
                '</div>'
            );
            leafletMarkers.addLayer(lm);
        }
    }

    function fitMapToMarkers() {
        if (fiUseGoogleMaps && map && markers.length > 0) {
            var bounds = new google.maps.LatLngBounds();
            if (state.lat) bounds.extend({ lat: state.lat, lng: state.lng });
            markers.forEach(function(m) { bounds.extend(m.getPosition()); });
            map.fitBounds(bounds, 50);
        } else if (leafletMap && leafletMarkers && leafletMarkers.getLayers().length > 0) {
            var group = L.featureGroup(leafletMarkers.getLayers());
            if (leafletUserMarker) group.addLayer(leafletUserMarker);
            leafletMap.fitBounds(group.getBounds().pad(0.1));
        }
    }

    // ═══════════════ Load Installers ═══════════════
    function loadInstallers(append) {
        if (state.loading) return;
        state.loading = true;

        if (!append) {
            grid.innerHTML = '<div class="fi-loading"><div class="spinner"></div><br>Searching for installers...</div>';
            loadMoreWrap.style.display = 'none';
        } else {
            loadMoreWrap.innerHTML = '<div class="fi-loading"><div class="spinner"></div><br>Loading more...</div>';
        }

        var params = new URLSearchParams({
            ajax: 'installers',
            lat: state.lat || 0,
            lng: state.lng || 0,
            radius: state.radius,
            sort: state.sort,
            type: state.type === 'all' ? '' : state.type,
            size: state.size,
            min_rating: state.min_rating,
            offset: state.offset,
            limit: state.limit
        });

        fetch('find-installer.php?' + params.toString())
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.error) {
                    showToast(data.error, true);
                    state.loading = false;
                    return;
                }

                state.total = data.total || 0;
                state.currency = data.currency || state.currency;

                var installers = data.installers || [];
                if (installers.length < state.limit) state.allLoaded = true;

                if (!append) {
                    grid.innerHTML = '';
                    clearMapMarkers();
                }

                if (installers.length === 0 && !append) {
                    grid.innerHTML =
                        '<div class="fi-empty-state" style="grid-column:1/-1;">' +
                        '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>' +
                        '<h3>No installers found</h3>' +
                        '<p>Try expanding your search radius or changing your location.</p>' +
                        '</div>';
                    loadMoreWrap.style.display = 'none';
                } else {
                    installers.forEach(function(inst, i) {
                        var card = renderCard(inst, state.offset + i);
                        grid.appendChild(card);
                        addInstallerMarker(inst);
                    });

                    if (!append) fitMapToMarkers();

                    // Load more button
                    var shown = state.offset + installers.length;
                    if (!state.allLoaded && shown < state.total) {
                        loadMoreWrap.style.display = 'block';
                        loadMoreWrap.innerHTML =
                            '<div class="fi-load-more">' +
                            '<div style="font-size:0.82rem;color:#64748B;margin-bottom:8px;">Showing ' + shown + ' of ' + state.total + '</div>' +
                            '<button class="fi-load-more-btn" id="fiLoadMoreBtn">Load More Installers</button>' +
                            '</div>';
                        document.getElementById('fiLoadMoreBtn').addEventListener('click', function() {
                            state.offset += state.limit;
                            loadInstallers(true);
                        });
                    } else {
                        loadMoreWrap.style.display = 'none';
                    }
                }

                // Results info
                resultsInfo.textContent = state.total > 0
                    ? state.total + ' installer' + (state.total !== 1 ? 's' : '') + ' found' + (state.city ? ' near ' + state.city : '')
                    : '';

                state.loading = false;
            })
            .catch(function(err) {
                console.error('Load error:', err);
                showToast('Failed to load installers.', true);
                state.loading = false;
                if (!append) grid.innerHTML = '';
            });
    }

    function resetAndLoad() {
        state.offset = 0;
        state.allLoaded = false;
        state.expandedProfile = null;
        loadInstallers(false);
    }

    // ═══════════════ Render Card ═══════════════
    function renderCard(inst, index) {
        var card = document.createElement('div');
        card.className = 'fi-card' + (inst.is_featured ? ' featured' : '');
        card.id = 'fi-card-' + inst.id;
        card.style.animationDelay = (index % 10) * 0.06 + 's';

        var starsHtml = '';
        for (var s = 1; s <= 5; s++) {
            starsHtml += s <= Math.floor(inst.avg_rating) ? '★' : (s - 0.5 <= inst.avg_rating ? '★' : '☆');
        }

        var specs = (inst.specializations || []).slice(0, 4);
        var tagsHtml = specs.map(function(sp) { return '<span class="fi-tag">' + escHtml(sp) + '</span>'; }).join('');
        if ((inst.specializations || []).length > 4) {
            tagsHtml += '<span class="fi-tag">+' + (inst.specializations.length - 4) + ' more</span>';
        }

        var locationText = [inst.city, inst.region].filter(Boolean).join(', ');
        var distBadge = inst.distance_km !== null ? '<span class="fi-distance-badge">' + inst.distance_km + ' km</span>' : '';

        var metaItems = '';
        if (inst.years_experience) metaItems += '<span class="fi-card-meta-item">📅 ' + inst.years_experience + ' yrs exp</span>';
        if (inst.team_size) metaItems += '<span class="fi-card-meta-item">👥 ' + inst.team_size + ' team</span>';
        if (inst.completed_installations > 0) metaItems += '<span class="fi-card-meta-item">✅ ' + inst.completed_installations + ' installs</span>';
        if (inst.license_number) metaItems += '<span class="fi-card-meta-item"><span class="licensed-badge">📋 Licensed</span></span>';

        var contactHtml = '';
        if (inst.phone) {
            contactHtml += '<a href="tel:' + escHtml(inst.phone) + '" class="fi-contact-link">' +
                '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>' +
                escHtml(inst.phone) + '</a>';
        }
        if (inst.email) {
            contactHtml += '<a href="mailto:' + escHtml(inst.email) + '" class="fi-contact-link">' +
                '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>' +
                escHtml(inst.email) + '</a>';
        }

        var priceHtml = inst.formatted_price
            ? '<span class="fi-price">' + escHtml(inst.formatted_price) + ' <small>/kW</small></span>'
            : '<span class="fi-price"><small style="color:#64748B">Contact for pricing</small></span>';

        var logoHtml = inst.logo_path
            ? '<img src="' + escHtml(inst.logo_path) + '" alt="' + escHtml(inst.business_name) + '">'
            : '☀';

        var html =
            (inst.is_featured ? '<div class="fi-featured-badge">FEATURED</div>' : '') +
            '<div class="fi-card-body">' +
                '<div class="fi-card-top">' +
                    '<div class="fi-card-logo">' + logoHtml + '</div>' +
                    '<div class="fi-card-info">' +
                        '<h3 class="fi-card-name">' + escHtml(inst.business_name) + '</h3>' +
                        '<p class="fi-card-loc">' + escHtml(locationText) + ' ' + distBadge + '</p>' +
                        '<div class="fi-card-stars">' +
                            '<span class="fi-stars">' + starsHtml + '</span>' +
                            '<span class="fi-stars-count">' + inst.avg_rating + ' (' + inst.total_reviews + ' reviews)</span>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
                '<div class="fi-card-meta">' + metaItems + '</div>' +
                (tagsHtml ? '<div class="fi-card-tags">' + tagsHtml + '</div>' : '') +
                (contactHtml ? '<div class="fi-card-contact">' + contactHtml + '</div>' : '') +
                '<div class="fi-card-footer">' +
                    priceHtml +
                    '<div class="fi-card-actions">' +
                        '<a href="<?= BASE_URL ?>installer-detail.php?id=' + inst.id + '" class="fi-btn-profile">View Details</a>' +
                        '<a href="<?= BASE_URL ?>installer-detail.php?id=' + inst.id + '#request-section" class="fi-btn-request">Request Quote</a>' +
                    '</div>' +
                '</div>' +
            '</div>';

        card.innerHTML = html;

        return card;
    }

    // ═══════════════ Profile Detail ═══════════════
    window.fiViewProfile = function(id) {
        var profileEl = document.getElementById('fi-profile-' + id);
        if (!profileEl) return;

        // If already open, close it
        if (profileEl.classList.contains('active')) {
            profileEl.classList.remove('active');
            state.expandedProfile = null;
            return;
        }

        // Close any other open profiles
        document.querySelectorAll('.fi-profile.active').forEach(function(p) { p.classList.remove('active'); });

        profileEl.innerHTML = '<div class="fi-loading" style="padding:20px;"><div class="spinner"></div><br>Loading profile...</div>';
        profileEl.classList.add('active');
        state.expandedProfile = id;

        fetch('find-installer.php?ajax=installer_detail&id=' + id)
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.error) {
                    profileEl.innerHTML = '<div style="padding:20px;color:#991B1B;text-align:center;">' + escHtml(data.error) + '</div>';
                    return;
                }
                renderProfile(profileEl, data, id);
                setTimeout(function() {
                    document.getElementById('fi-card-' + id).scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 100);
            })
            .catch(function() {
                profileEl.innerHTML = '<div style="padding:20px;color:#991B1B;text-align:center;">Failed to load profile.</div>';
            });
    };

    function renderProfile(el, data, installerId) {
        var inst = data.installer;
        var reviews = data.reviews || [];
        var portfolio = data.portfolio || [];
        var areas = data.service_areas || [];
        var breakdown = data.rating_breakdown || {};

        var totalReviews = 0;
        for (var r = 1; r <= 5; r++) totalReviews += (breakdown[r] || 0);

        // About
        var aboutHtml = '<div class="fi-profile-section"><h3>About</h3><p class="fi-about-text">' +
            (inst.about_text ? escHtml(inst.about_text).replace(/\n/g, '<br>') : 'No description provided.') +
            '</p></div>';

        // Details
        var detailsHtml = '<div class="fi-profile-section"><h3>Details</h3><ul class="fi-detail-list">';
        if (inst.phone) detailsHtml += '<li><span>Phone</span><strong><a href="tel:' + escHtml(inst.phone) + '" style="color:#0D3B6E;text-decoration:none;">' + escHtml(inst.phone) + '</a></strong></li>';
        if (inst.address) detailsHtml += '<li><span>Address</span><strong>' + escHtml(inst.address) + '</strong></li>';
        detailsHtml += '<li><span>Experience</span><strong>' + inst.years_experience + ' years</strong></li>';
        detailsHtml += '<li><span>Team Size</span><strong>' + inst.team_size + ' members</strong></li>';
        detailsHtml += '<li><span>Installations</span><strong>' + inst.completed_installations + ' completed</strong></li>';
        if (inst.license_number) detailsHtml += '<li><span>License</span><strong>' + escHtml(inst.license_number) + '</strong></li>';
        if (inst.service_radius_km) detailsHtml += '<li><span>Service Radius</span><strong>' + inst.service_radius_km + ' km</strong></li>';
        detailsHtml += '</ul></div>';

        // Service Areas
        var areasHtml = '';
        if (areas.length > 0) {
            areasHtml = '<div class="fi-profile-section full"><h3>Service Areas</h3><div class="fi-area-tags">';
            areas.forEach(function(a) {
                areasHtml += '<span class="fi-area-tag ' + (a.is_primary ? 'primary' : '') + '">' +
                    escHtml(a.area_name) +
                    (a.radius_km ? ' (' + a.radius_km + ' km)' : '') +
                    '</span>';
            });
            areasHtml += '</div></div>';
        }

        // Portfolio
        var portfolioHtml = '';
        if (portfolio.length > 0) {
            portfolioHtml = '<div class="fi-profile-section full"><h3>Portfolio</h3><div class="fi-portfolio-grid">';
            portfolio.forEach(function(p) {
                portfolioHtml += '<div class="fi-portfolio-item">' +
                    (p.image_path ? '<img src="' + escHtml(p.image_path) + '" alt="' + escHtml(p.title || '') + '" loading="lazy">' : '') +
                    '<div class="fi-portfolio-caption">' + escHtml(p.title || '') +
                    (p.system_size_kw ? ' &bull; ' + p.system_size_kw + ' kW' : '') +
                    '</div></div>';
            });
            portfolioHtml += '</div></div>';
        }

        // Rating breakdown
        var breakdownHtml = '';
        if (totalReviews > 0) {
            breakdownHtml = '<div class="fi-rating-breakdown">';
            for (var rb = 5; rb >= 1; rb--) {
                var cnt = breakdown[rb] || 0;
                var pct = totalReviews > 0 ? Math.round((cnt / totalReviews) * 100) : 0;
                breakdownHtml += '<div class="fi-rb-row">' +
                    '<span class="fi-rb-label">' + rb + '★</span>' +
                    '<div class="fi-rb-bar"><div class="fi-rb-fill" style="width:' + pct + '%"></div></div>' +
                    '<span class="fi-rb-pct">' + pct + '%</span></div>';
            }
            breakdownHtml += '</div>';
        }

        // Reviews
        var reviewsListHtml = '';
        if (reviews.length > 0) {
            reviews.forEach(function(rev) {
                var revStars = '';
                for (var rs = 1; rs <= 5; rs++) revStars += rs <= rev.rating ? '★' : '☆';
                var initial = (rev.reviewer_name || '?').charAt(0).toUpperCase();
                var dateStr = rev.created_at ? new Date(rev.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : '';

                reviewsListHtml += '<div class="fi-review-card">' +
                    '<div class="fi-review-header">' +
                        '<div style="display:flex;gap:10px;align-items:center;">' +
                            '<div class="fi-review-avatar">' + initial + '</div>' +
                            '<div>' +
                                '<div class="fi-review-author">' + escHtml(rev.reviewer_name) + '</div>' +
                                '<div class="fi-stars" style="font-size:0.82rem;">' + revStars + '</div>' +
                            '</div>' +
                        '</div>' +
                        '<span class="fi-review-date">' + dateStr + '</span>' +
                    '</div>';
                if (rev.title) reviewsListHtml += '<div class="fi-review-title">' + escHtml(rev.title) + '</div>';
                reviewsListHtml += '<div class="fi-review-text">' + escHtml(rev.review_text).replace(/\n/g, '<br>') + '</div>';
                if (rev.project_type || rev.system_size_kw) {
                    reviewsListHtml += '<div class="fi-review-meta">';
                    if (rev.project_type) reviewsListHtml += '<span class="project-badge">' + escHtml(rev.project_type) + '</span> ';
                    if (rev.system_size_kw) reviewsListHtml += rev.system_size_kw + ' kW';
                    reviewsListHtml += '</div>';
                }
                if (rev.admin_response) {
                    reviewsListHtml += '<div class="fi-admin-response"><strong>Installer Response:</strong><p>' +
                        escHtml(rev.admin_response).replace(/\n/g, '<br>') + '</p></div>';
                }
                reviewsListHtml += '</div>';
            });
        } else {
            reviewsListHtml = '<p style="color:#94A3B8;text-align:center;padding:16px 0;">No reviews yet. Be the first to leave a review!</p>';
        }

        // Review form
        var formHtml =
            '<div class="fi-review-form">' +
            '<button type="button" class="fi-review-form-toggle" id="fiToggleForm-' + installerId + '">Write a Review</button>' +
            '<div id="fiFormWrap-' + installerId + '" style="display:none;">' +
            '<form class="fi-form-grid" id="fiReviewForm-' + installerId + '">' +
                '<input type="hidden" name="installer_id" value="' + installerId + '">' +
                '<input type="hidden" name="csrf_token" value="' + escHtml(state.csrfToken) + '">' +
                '<div class="fi-form-field"><label>Your Name *</label><input type="text" name="reviewer_name" required placeholder="John Doe"></div>' +
                '<div class="fi-form-field"><label>Email *</label><input type="email" name="reviewer_email" required placeholder="email@example.com"></div>' +
                '<div class="fi-form-field"><label>Phone (optional)</label><input type="tel" name="reviewer_phone" placeholder="+1 234 567 8900"></div>' +
                '<div class="fi-form-field"><label>Rating *</label>' +
                    '<div class="fi-star-input">' +
                    '<input type="radio" name="rating" id="star-' + installerId + '-5" value="5" required><label for="star-' + installerId + '-5">★</label>' +
                    '<input type="radio" name="rating" id="star-' + installerId + '-4" value="4"><label for="star-' + installerId + '-4">★</label>' +
                    '<input type="radio" name="rating" id="star-' + installerId + '-3" value="3"><label for="star-' + installerId + '-3">★</label>' +
                    '<input type="radio" name="rating" id="star-' + installerId + '-2" value="2"><label for="star-' + installerId + '-2">★</label>' +
                    '<input type="radio" name="rating" id="star-' + installerId + '-1" value="1"><label for="star-' + installerId + '-1">★</label>' +
                    '</div></div>' +
                '<div class="fi-form-field full"><label>Review Title</label><input type="text" name="review_title" placeholder="Sum up your experience"></div>' +
                '<div class="fi-form-field full"><label>Your Review *</label><textarea name="review_text" required placeholder="Tell others about your experience with this installer..."></textarea></div>' +
                '<div class="fi-form-field"><label>Project Type</label><select name="project_type"><option value="">Select...</option><option value="Residential">Residential</option><option value="Commercial">Commercial</option><option value="Industrial">Industrial</option></select></div>' +
                '<div class="fi-form-field"><label>System Size (kW)</label><input type="number" name="system_size_kw" step="0.1" min="0" placeholder="e.g. 10"></div>' +
                '<div class="fi-form-field"><label>Installation Date</label><input type="date" name="installation_date"></div>' +
                '<div class="fi-form-field" style="justify-content:flex-end;"><button type="submit" class="fi-btn-submit">Submit Review</button></div>' +
            '</form></div></div>';

        // Assemble
        el.innerHTML =
            '<div class="fi-profile-grid">' +
                aboutHtml + detailsHtml + areasHtml + portfolioHtml +
                '<div class="fi-profile-section full">' +
                    '<h3>Reviews (' + totalReviews + ')</h3>' +
                    breakdownHtml + reviewsListHtml + formHtml +
                '</div>' +
            '</div>';

        // Toggle form
        document.getElementById('fiToggleForm-' + installerId).addEventListener('click', function() {
            var wrap = document.getElementById('fiFormWrap-' + installerId);
            wrap.style.display = wrap.style.display === 'none' ? 'block' : 'none';
        });

        // Form submit
        document.getElementById('fiReviewForm-' + installerId).addEventListener('submit', function(e) {
            e.preventDefault();
            submitReview(this, installerId);
        });
    }

    // ═══════════════ Submit Review ═══════════════
    function submitReview(form, installerId) {
        var btn = form.querySelector('.fi-btn-submit');
        btn.disabled = true;
        btn.textContent = 'Submitting...';

        var formData = new FormData(form);
        var body = {};
        formData.forEach(function(v, k) { body[k] = v; });

        fetch('find-installer.php?ajax=submit_review', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.error) {
                showToast(data.error, true);
            } else {
                showToast(data.message || 'Review submitted successfully!', false);
                form.reset();
                document.getElementById('fiFormWrap-' + installerId).style.display = 'none';
            }
        })
        .catch(function() {
            showToast('Failed to submit review.', true);
        })
        .finally(function() {
            btn.disabled = false;
            btn.textContent = 'Submit Review';
        });
    }

    // ═══════════════ Events ═══════════════
    function bindEvents() {
        // Radius slider
        radiusSlider.addEventListener('input', function() {
            state.radius = parseInt(this.value);
            radiusValue.textContent = state.radius + ' km';
            // Save cookie
            document.cookie = 'sg_radius=' + state.radius + ';path=/solarglobal/;max-age=' + (30*86400);
            // Update radius circle
            if (radiusCircle) radiusCircle.setRadius(state.radius * 1000);
            if (leafletRadiusCircle) leafletRadiusCircle.setRadius(state.radius * 1000);
            debouncedReload();
        });

        // Rating slider
        ratingSlider.addEventListener('input', function() {
            state.min_rating = parseFloat(this.value);
            ratingValue.textContent = state.min_rating > 0 ? state.min_rating + '★+' : 'Any';
            debouncedReload();
        });

        // Type pills
        document.querySelectorAll('.fi-pill').forEach(function(pill) {
            pill.addEventListener('click', function() {
                document.querySelectorAll('.fi-pill').forEach(function(p) { p.classList.remove('active'); });
                this.classList.add('active');
                state.type = this.getAttribute('data-type');
                resetAndLoad();
            });
        });

        // Sort select
        document.getElementById('fiSort').addEventListener('change', function() {
            state.sort = this.value;
            resetAndLoad();
        });

        // Size select
        document.getElementById('fiSize').addEventListener('change', function() {
            state.size = this.value;
            resetAndLoad();
        });

        // Change location button — focus the search bar so user can type
        document.getElementById('fiChangeLocation').addEventListener('click', function() {
            locationInput.value = '';
            locationInput.focus();
            locationInput.placeholder = 'Type a city name and press Enter...';
        });

        // Location input — Enter key triggers geocoding (Nominatim fallback if no Google Places)
        locationInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                var q = this.value.trim();
                if (q.length < 2) return;
                geocodeSearch(q);
            }
        });

        // "Use My GPS" — use browser geolocation
        locationInput.addEventListener('focus', function() {
            // Show hint
            this.setAttribute('data-old-placeholder', this.placeholder);
            this.placeholder = 'Type a city or press Enter to search...';
        });
        locationInput.addEventListener('blur', function() {
            var old = this.getAttribute('data-old-placeholder');
            if (old) this.placeholder = old;
        });
    }

    function debouncedReload() {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(function() { resetAndLoad(); }, 400);
    }

    // ═══════════════ Helpers ═══════════════
    function escHtml(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function showToast(msg, isError) {
        var toast = document.getElementById('fiToast');
        toast.textContent = msg;
        toast.className = 'fi-toast' + (isError ? ' error' : '');
        toast.classList.add('show');
        setTimeout(function() { toast.classList.remove('show'); }, 4000);
    }

})();
</script>

<?php include 'includes/footer.php'; ?>
