<?php
/**
 * Dealer Subscription Page
 * Stripe Checkout integration for dealer subscriptions
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';
require_once __DIR__ . '/../includes/stripe_config.php';
require_once __DIR__ . '/../includes/data_retention.php';

set_security_headers();
require_dealer_login();

$dealer = get_dealer_profile();
$db = getDB();

// Ensure Stripe columns exist on the dealers table
try { $db->exec("ALTER TABLE dealers ADD COLUMN stripe_customer_id VARCHAR(255) NULL"); } catch (Exception $e) {}
try { $db->exec("ALTER TABLE dealers ADD COLUMN stripe_subscription_id VARCHAR(255) NULL"); } catch (Exception $e) {}

$success = '';
$error = '';

// Get payment settings
$stripeKeys = getStripeKeys();
$dealerFee = (float)getPaymentSetting('dealer_monthly_fee', '1.00');
$currency = getPaymentSetting('payment_currency', 'usd');
$isTestMode = ($stripeKeys['mode'] === 'test');
$stripeConfigured = !empty($stripeKeys['secret_key']) && !empty($stripeKeys['publishable_key']);

// Handle successful return from Stripe Checkout
if (isset($_GET['session_id']) && !empty($_GET['session_id'])) {
    $sessionId = $_GET['session_id'];
    $result = getStripeCheckoutSession($sessionId);

    if ($result['success'] && $result['data']['payment_status'] === 'paid') {
        $session = $result['data'];
        $stripeCustomerId = $session['customer'] ?? '';
        $stripeSubscriptionId = $session['subscription'] ?? '';

        // Update dealer with Stripe info
        $stmt = $db->prepare("
            UPDATE dealers SET
                stripe_customer_id = ?,
                stripe_subscription_id = ?,
                subscription_status = 'active',
                subscription_started_at = NOW(),
                subscription_expires_at = DATE_ADD(NOW(), INTERVAL 1 MONTH),
                status = CASE WHEN status IN ('approved','pending','inactive') THEN 'active' ELSE status END
            WHERE id = ?
        ");
        $stmt->execute([$stripeCustomerId, $stripeSubscriptionId, $dealer['id']]);

        $_SESSION['dealer_status'] = 'active';
        $success = 'Subscription activated! Your store is now live.';
        $dealer = get_dealer_profile();
    } else {
        $error = 'Could not verify payment session. Please contact support if you were charged.';
    }
}

// Handle canceled return from Stripe
if (isset($_GET['canceled'])) {
    $error = 'Payment was canceled. You can try again when ready.';
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_checkout') {
        if (!$stripeConfigured) {
            $error = 'Payment system is not configured. Please contact the administrator.';
        } elseif ($dealerFee <= 0) {
            $error = 'Invalid subscription fee configured.';
        } else {
            // Create Stripe Checkout Session
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $baseUrl = $protocol . '://' . $_SERVER['HTTP_HOST'] . '/solarglobal/dealer/subscription.php';

            $checkoutParams = [
                'customer_email' => $dealer['email'],
                'price_amount' => (int)round($dealerFee * 100), // Convert to cents
                'currency' => $currency,
                'product_name' => get_system_setting('site_name', 'SolarGlobal') . ' Dealer Store - Monthly Subscription',
                'success_url' => $baseUrl . '?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => $baseUrl . '?canceled=1',
                'metadata' => [
                    'dealer_id' => (string)$dealer['id'],
                    'type' => 'dealer',
                ],
            ];

            // Use existing Stripe customer if available
            if (!empty($dealer['stripe_customer_id'])) {
                $checkoutParams['customer_id'] = $dealer['stripe_customer_id'];
                unset($checkoutParams['customer_email']);
            }

            $result = createStripeCheckoutSession($checkoutParams);

            if ($result['success'] && !empty($result['data']['url'])) {
                header('Location: ' . $result['data']['url']);
                exit();
            } else {
                $error = 'Could not create checkout session: ' . ($result['error'] ?? 'Unknown error');
            }
        }
    }

    if ($action === 'change_retention_plan') {
        $new_plan = strtolower(trim($_POST['retention_plan'] ?? ''));
        if (update_retention_plan($db, 'dealers', $dealer['id'], $new_plan)) {
            $info = get_retention_info($new_plan);
            $success = "Data retention plan updated to {$info['label']}. Your order history and records will be kept for {$info['months']} months.";
            $dealer = get_dealer_profile();
        } else {
            $error = 'Invalid retention plan selected.';
        }
    }

    if ($action === 'cancel_subscription') {
        if (!empty($dealer['stripe_subscription_id'])) {
            $result = cancelStripeSubscription($dealer['stripe_subscription_id']);

            if ($result['success']) {
                $stmt = $db->prepare("
                    UPDATE dealers SET
                        subscription_status = 'canceled'
                    WHERE id = ?
                ");
                $stmt->execute([$dealer['id']]);

                $success = 'Subscription has been canceled. You will retain access until the end of your billing period.';
                $dealer = get_dealer_profile();
            } else {
                $error = 'Could not cancel subscription: ' . ($result['error'] ?? 'Unknown error');
            }
        } else {
            // No Stripe subscription, just mark canceled locally
            $stmt = $db->prepare("UPDATE dealers SET subscription_status = 'canceled' WHERE id = ?");
            $stmt->execute([$dealer['id']]);
            $success = 'Subscription canceled.';
            $dealer = get_dealer_profile();
        }
    }
}

// Check subscription status (includes free trial logic)
$subCheck = check_dealer_subscription();
$is_active = $subCheck['active'];
$is_trial = $subCheck['trial'] ?? false;
$trial_days_left = $subCheck['trial_days_left'] ?? 0;

$is_canceled = ($dealer['subscription_status'] ?? '') === 'canceled';
$is_past_due = ($dealer['subscription_status'] ?? '') === 'past_due';
$expires = $dealer['subscription_expires_at'] ? date('M d, Y', strtotime($dealer['subscription_expires_at'])) : null;
$formattedFee = number_format($dealerFee, 2);

// Free trial settings
$freeTrialEnabled = get_system_setting('dealer_free_trial_enabled', '0') === '1';
$freeTrialDays = (int)get_system_setting('dealer_free_trial_days', '30');

// Data retention plan info
$current_retention = get_retention_info($dealer['subscription_plan'] ?? null);
$all_retention_plans = get_all_retention_plans();

// Redirect message (from require_dealer_subscription)
$redirectMsg = $_SESSION['dealer_sub_message'] ?? '';
unset($_SESSION['dealer_sub_message']);
if ($redirectMsg && !$error) {
    $error = $redirectMsg;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscription - <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }
        .container { max-width: 700px; margin: 0 auto; padding: 0; }

        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 0.875rem; }
        .alert-success { background: #DCFCE7; color: #166534; }
        .alert-error { background: #FEE2E2; color: #991B1B; }

        .plan-card {
            background: white; border-radius: 16px; padding: 40px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08); text-align: center;
            border: 2px solid #E2E8F0; margin-bottom: 24px; position: relative; overflow: hidden;
        }
        .plan-card.active { border-color: #16A34A; }
        .plan-card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px;
            background: linear-gradient(90deg, #F59E0B, #1565C0);
        }

        .plan-icon { font-size: 3rem; margin-bottom: 16px; }
        .plan-name { font-size: 1.5rem; font-weight: 800; color: #0D3B6E; margin-bottom: 8px; }
        .plan-price { font-size: 2.5rem; font-weight: 800; color: #1E293B; }
        .plan-price small { font-size: 1rem; font-weight: 400; color: #64748B; }
        .plan-desc { color: #64748B; margin: 16px 0 24px; font-size: 0.9375rem; }

        .features-list { text-align: left; max-width: 400px; margin: 0 auto 32px; }
        .feature-item {
            display: flex; align-items: center; gap: 10px; padding: 8px 0;
            font-size: 0.9375rem; color: #334155;
        }
        .feature-item .check { color: #16A34A; font-weight: 700; font-size: 1.125rem; }

        .btn-activate {
            padding: 16px 48px; border: none; border-radius: 12px;
            font-size: 1.0625rem; font-weight: 700; cursor: pointer;
            transition: all 0.3s;
        }
        .btn-activate.primary {
            background: linear-gradient(135deg, #F59E0B, #D97706);
            color: white;
        }
        .btn-activate.primary:hover {
            transform: translateY(-2px); box-shadow: 0 8px 25px rgba(245,158,11,0.4);
        }
        .btn-activate.disabled {
            background: #E2E8F0; color: #94A3B8; cursor: default;
        }
        .btn-cancel {
            display: inline-block; margin-top: 16px; padding: 10px 24px;
            border: 2px solid #EF4444; border-radius: 8px; background: white;
            color: #EF4444; font-size: 0.875rem; font-weight: 600; cursor: pointer;
            transition: all 0.3s;
        }
        .btn-cancel:hover {
            background: #FEE2E2;
        }

        .status-card {
            background: white; border-radius: 12px; padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); margin-bottom: 16px;
        }
        .status-row {
            display: flex; justify-content: space-between; padding: 10px 0;
            border-bottom: 1px solid #F1F5F9; font-size: 0.9375rem;
        }
        .status-row:last-child { border-bottom: none; }
        .status-row .label { color: #64748B; }
        .status-row .value { font-weight: 600; }
        .status-row .value.active { color: #16A34A; }
        .status-row .value.inactive { color: #94A3B8; }
        .status-row .value.past-due { color: #F59E0B; }
        .status-row .value.canceled { color: #EF4444; }

        .dev-notice {
            background: #FEF3C7; border: 1px solid #FDE68A; padding: 16px;
            border-radius: 8px; margin-top: 24px; font-size: 0.8125rem; color: #92400E;
        }
    </style>
</head>
<body>
    <?php $current_dealer_page = 'subscription'; include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="dlr-main-content">
        <div class="dlr-page-header">
            <div class="dlr-page-header-left">
                <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
                <h1>&#128179; Subscription</h1>
            </div>
            <div></div>
        </div>

        <div class="container">
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>

        <!-- Trial Banner -->
        <?php if ($is_trial): ?>
        <div style="background:#DBEAFE;border:1px solid #93C5FD;padding:16px 20px;border-radius:10px;margin-bottom:20px;display:flex;align-items:center;gap:12px;">
            <span style="font-size:2rem;">&#127881;</span>
            <div>
                <strong style="color:#1D4ED8;font-size:0.9375rem;">Free Trial Active</strong>
                <p style="color:#1E40AF;font-size:0.8125rem;margin-top:2px;">
                    You have <strong><?= $trial_days_left ?> day<?= $trial_days_left !== 1 ? 's' : '' ?></strong> remaining.
                    Subscribe before your trial ends to keep your store active.
                </p>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!$is_active && !$is_trial): ?>
        <div style="background:#FEF2F2;border:1px solid #FECACA;padding:16px 20px;border-radius:10px;margin-bottom:20px;display:flex;align-items:center;gap:12px;">
            <span style="font-size:2rem;">&#128274;</span>
            <div>
                <strong style="color:#991B1B;font-size:0.9375rem;">Store Inactive</strong>
                <p style="color:#B91C1C;font-size:0.8125rem;margin-top:2px;">
                    Your store is not visible to customers. Subscribe to activate your store and start appearing in recommendations.
                </p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Current Status -->
        <div class="status-card">
            <div class="status-row">
                <span class="label">Subscription Status</span>
                <span class="value <?= $is_active ? 'active' : ($is_past_due ? 'past-due' : ($is_canceled ? 'canceled' : 'inactive')) ?>">
                    <?php if ($is_active && $is_trial): ?>&#127881; Free Trial (<?= $trial_days_left ?> days left)
                    <?php elseif ($is_active): ?>&#10004; Active
                    <?php elseif ($is_past_due): ?>&#9888; Past Due
                    <?php elseif ($is_canceled): ?>&#10060; Canceled
                    <?php else: ?>&#10060; Inactive<?php endif; ?>
                </span>
            </div>
            <?php if ($dealer['subscription_started_at'] ?? null): ?>
            <div class="status-row">
                <span class="label">Started</span>
                <span class="value"><?= date('M d, Y', strtotime($dealer['subscription_started_at'])) ?></span>
            </div>
            <?php endif; ?>
            <?php if ($expires): ?>
            <div class="status-row">
                <span class="label">Renews On</span>
                <span class="value"><?= $expires ?></span>
            </div>
            <?php endif; ?>
            <div class="status-row">
                <span class="label">Store Status</span>
                <span class="value"><?= ucfirst($dealer['status']) ?></span>
            </div>
            <div class="status-row">
                <span class="label">Payment Method</span>
                <span class="value">Stripe</span>
            </div>
        </div>

        <!-- Plan -->
        <div class="plan-card <?= $is_active ? 'active' : '' ?>">
            <div class="plan-icon">&#9889;</div>
            <div class="plan-name"><?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer Store</div>
            <div class="plan-price">$<?= $formattedFee ?> <small>/month</small></div>
            <div class="plan-desc">Everything you need to sell solar products online</div>

            <div class="features-list">
                <div class="feature-item"><span class="check">&#10003;</span> List unlimited products</div>
                <div class="feature-item"><span class="check">&#10003;</span> Custom pricing and stock management</div>
                <div class="feature-item"><span class="check">&#10003;</span> Appear in customer recommendations</div>
                <div class="feature-item"><span class="check">&#10003;</span> Location-based customer matching</div>
                <div class="feature-item"><span class="check">&#10003;</span> Public store page</div>
                <div class="feature-item"><span class="check">&#10003;</span> Customer leads and inquiries</div>
                <div class="feature-item"><span class="check">&#10003;</span> Dashboard analytics</div>
            </div>

            <?php if ($is_active): ?>
                <button class="btn-activate disabled">&#10004; Currently Active</button>
                <br>
                <form method="POST" style="display:inline" onsubmit="return confirm('Are you sure you want to cancel your subscription?');">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="cancel_subscription">
                    <button type="submit" class="btn-cancel">Cancel Subscription</button>
                </form>
            <?php elseif (!$stripeConfigured): ?>
                <button class="btn-activate disabled" title="Payment system not configured">&#9889; Payment System Unavailable</button>
            <?php else: ?>
                <form method="POST" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="create_checkout">
                    <button type="submit" class="btn-activate primary">
                        &#9889; Activate Subscription - $<?= $formattedFee ?>/month
                    </button>
                </form>
            <?php endif; ?>
        </div>

        <?php if ($isTestMode): ?>
        <div class="dev-notice">
            <strong>Stripe TEST Mode:</strong> Payments are processed using Stripe's test environment.
            No real charges will be made. Use test card <strong>4242 4242 4242 4242</strong> with any future expiry and any CVC.
        </div>
        <?php endif; ?>

        <!-- ═══ Data Retention Plan Section ═══ -->
        <div class="plan-card" style="margin-top: 32px;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                <span style="font-size: 1.5rem;">&#128451;</span>
                <h3 style="font-weight: 700; color: #0F172A;">Data Retention Plan</h3>
            </div>
            <p style="color: #64748B; font-size: 0.875rem; margin-bottom: 20px;">
                Choose how long your order history, invoices, reviews, and records are kept.
                When data passes your plan's retention period, it is <strong>automatically and permanently deleted</strong>.
            </p>

            <div style="background: #F0FDF4; border: 1px solid #BBF7D0; border-radius: 10px; padding: 14px 18px; margin-bottom: 20px;">
                <div style="font-weight: 600; color: #166534; font-size: 0.9rem;">
                    Current Plan: <span style="color: #15803D;"><?= sanitize($current_retention['label']) ?></span>
                </div>
                <div style="color: #166534; font-size: 0.82rem; margin-top: 4px;">
                    Your data is kept for <strong><?= $current_retention['months'] ?> months (~<?= $current_retention['days'] ?> days)</strong>.
                    <?php if ($current_retention['fee'] > 0): ?>
                        Add-on fee: <strong>$<?= number_format($current_retention['fee'], 2) ?>/month</strong>
                    <?php else: ?>
                        <strong>Free — included with your subscription.</strong>
                    <?php endif; ?>
                </div>
            </div>

            <form method="POST" id="retentionForm">
                <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                <input type="hidden" name="action" value="change_retention_plan">

                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 12px; margin-bottom: 20px;">
                    <?php
                    $plan_colors = [
                        'basic'      => ['border' => '#E2E8F0', 'bg' => '#F8FAFC', 'text' => '#334155', 'badge' => '#94A3B8'],
                        'standard'   => ['border' => '#BFDBFE', 'bg' => '#EFF6FF', 'text' => '#1D4ED8', 'badge' => '#3B82F6'],
                        'premium'    => ['border' => '#FDE68A', 'bg' => '#FFFBEB', 'text' => '#92400E', 'badge' => '#F59E0B'],
                        'enterprise' => ['border' => '#C4B5FD', 'bg' => '#F5F3FF', 'text' => '#5B21B6', 'badge' => '#8B5CF6'],
                    ];
                    foreach ($all_retention_plans as $rp):
                        $c = $plan_colors[$rp['plan']] ?? $plan_colors['basic'];
                        $is_current = ($rp['plan'] === $current_retention['plan']);
                    ?>
                    <label style="cursor: pointer; display: block;">
                        <input type="radio" name="retention_plan" value="<?= $rp['plan'] ?>"
                               <?= $is_current ? 'checked' : '' ?>
                               style="display: none;" onchange="document.getElementById('retentionSubmit').style.display='inline-flex'">
                        <div class="retention-plan-option <?= $is_current ? 'active' : '' ?>" data-plan="<?= $rp['plan'] ?>"
                             style="padding: 16px; border-radius: 10px; border: 2px solid <?= $is_current ? $c['badge'] : $c['border'] ?>; background: <?= $c['bg'] ?>; transition: all 0.2s;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                                <span style="font-weight: 700; color: <?= $c['text'] ?>; font-size: 0.95rem;"><?= ucfirst($rp['plan']) ?></span>
                                <?php if ($is_current): ?>
                                    <span style="font-size: 0.7rem; background: <?= $c['badge'] ?>; color: white; padding: 2px 8px; border-radius: 20px; font-weight: 600;">CURRENT</span>
                                <?php endif; ?>
                            </div>
                            <div style="font-size: 1.4rem; font-weight: 800; color: <?= $c['text'] ?>;"><?= $rp['months'] ?> <span style="font-size: 0.75rem; font-weight: 500;">months</span></div>
                            <div style="font-size: 0.8rem; color: #64748B; margin-top: 4px;">
                                ~<?= $rp['days'] ?> days
                            </div>
                            <div style="font-size: 0.82rem; font-weight: 600; color: <?= $c['text'] ?>; margin-top: 8px;">
                                <?php if ($rp['fee'] <= 0): ?>
                                    Free (Included)
                                <?php else: ?>
                                    +$<?= number_format($rp['fee'], 2) ?>/month
                                <?php endif; ?>
                            </div>
                        </div>
                    </label>
                    <?php endforeach; ?>
                </div>

                <button type="submit" id="retentionSubmit" class="btn-activate"
                        style="display: none; background: #7C3AED; color: white; border: none; padding: 12px 28px; border-radius: 10px; font-weight: 600; font-size: 0.9rem; cursor: pointer; align-items: center; gap: 6px;"
                        onmouseover="this.style.background='#6D28D9'" onmouseout="this.style.background='#7C3AED'">
                    &#128451; Update Retention Plan
                </button>
            </form>

            <div style="margin-top: 16px; padding: 12px 16px; background: #FEF3C7; border: 1px solid #FDE68A; border-radius: 8px; font-size: 0.8rem; color: #92400E;">
                <strong>&#9888;&#65039; Important:</strong> Downgrading your plan will cause data older than the new retention period to be
                <strong>permanently deleted</strong> on the next cleanup cycle (runs daily). This cannot be undone.
                Upgrading keeps all existing data and extends future retention.
            </div>
        </div>

        <style>
            .retention-plan-option:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
            input[type="radio"]:checked + .retention-plan-option { box-shadow: 0 0 0 2px currentColor, 0 4px 12px rgba(0,0,0,0.1); }
        </style>

        </div>
    </main>
</body>
</html>
