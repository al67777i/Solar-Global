<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/csrf.php';
require_once '../includes/helpers.php';

$db = getDB();
$message = '';
$error = '';
$showForm = false;
$editData = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid token';
    } else {
        $action = $_POST['action'] ?? '';

        // AJAX: Update inverter image_path
        if ($action === 'update_image') {
            header('Content-Type: application/json');
            $id = intval($_POST['id'] ?? 0);
            $image_path = trim($_POST['image_path'] ?? '');
            if ($id > 0 && !empty($image_path)) {
                $db->prepare("UPDATE inverters SET image_path = ? WHERE id = ?")->execute([$image_path, $id]);
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Invalid parameters']);
            }
            exit;
        }

        if ($action === 'add' || $action === 'edit') {
            $id = intval($_POST['id'] ?? 0);

            // Basic Info
            $company_id = intval($_POST['company_id'] ?? 0);
            $model = trim($_POST['model'] ?? '');  // CHANGED: name → model
            $battery_voltage_range = $_POST['battery_voltage_range'] ?? '12V';  // CHANGED: vdc_type → battery_voltage_range
            $output_power_w = intval($_POST['output_power_w'] ?? 0);  // CHANGED: power_rating → output_power_w
            $max_pv_input_w = intval($_POST['max_pv_input_w'] ?? 0) ?: null;  // CHANGED: max_pv_input → max_pv_input_w
            $unit_price_usd = floatval($_POST['unit_price_usd'] ?? 0);  // CHANGED: price_usd → unit_price_usd
            $type = $_POST['type'] ?? 'hybrid';
            $max_efficiency = floatval($_POST['max_efficiency'] ?? 90);  // CHANGED: efficiency → max_efficiency
            $series_name = trim($_POST['series_name'] ?? '');

            // Electrical Specs
            $min_pv_voltage = intval($_POST['min_pv_voltage'] ?? 0) ?: null;  // CHANGED: input_voltage_min → min_pv_voltage
            $max_pv_voltage = intval($_POST['max_pv_voltage'] ?? 0) ?: null;  // CHANGED: input_voltage_max → max_pv_voltage
            $mppt_count = intval($_POST['mppt_count'] ?? 1);
            $output_ac_voltage_range = trim($_POST['output_ac_voltage_range'] ?? '');
            $power_factor = trim($_POST['power_factor'] ?? '');

            // Power
            $surge_power_w = intval($_POST['surge_power_w'] ?? 0) ?: null;  // CHANGED: surge_power_watts → surge_power_w

            // Features
            $three_phase = isset($_POST['three_phase']) ? 'Yes' : 'No';  // CHANGED: has_l3 → three_phase
            $bms = isset($_POST['bms']) ? 'Yes' : 'No';  // CHANGED: has_bms (0/1) → bms ('Yes'/'No')
            $supports_parallel = isset($_POST['supports_parallel']) ? 'Yes' : 'No';  // CHANGED: parallel_capable → supports_parallel
            $max_parallel_units = intval($_POST['max_parallel_units'] ?? 1);
            $display_type = trim($_POST['display_type'] ?? '');
            $cooling_method = trim($_POST['cooling_method'] ?? 'Natural');
            $communication = trim($_POST['communication'] ?? '');

            // Physical
            $weight_kg = floatval($_POST['weight_kg'] ?? 0) ?: null;
            $dimensions = trim($_POST['dimensions'] ?? '');
            $ip_rating = trim($_POST['ip_rating'] ?? '');
            $operating_temperature = trim($_POST['operating_temperature'] ?? '');
            $noise_level = trim($_POST['noise_level'] ?? '');

            // Certification
            $warranty_years = intval($_POST['warranty_years'] ?? 5);
            $country = trim($_POST['country'] ?? '');  // CHANGED: country_origin → country
            $primary_application = $_POST['primary_application'] ?? 'residential';
            $hybrid_offgrid_charging_power_watt = intval($_POST['hybrid_offgrid_charging_power_watt'] ?? 0);

            // Other
            $notes = trim($_POST['notes'] ?? '');
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            $availability_status = trim($_POST['availability_status'] ?? 'available');

            if (empty($model) || $company_id == 0) {
                $error = 'Model name and company required';
            } else {
                $image_path = $_POST['existing_image'] ?? null;
                if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                    $upload_result = handle_image_upload($_FILES['image'], '../uploads/inverters/');
                    if ($upload_result['success']) {
                        $image_path = $upload_result['path'];
                    }
                }

                if (empty($error)) {
                    if ($action === 'add') {
                        $stmt = $db->prepare("INSERT INTO inverters (
                            company_id, model, series_name, image_path, battery_voltage_range, output_power_w, max_pv_input_w, unit_price_usd, type, max_efficiency,
                            min_pv_voltage, max_pv_voltage, mppt_count, output_ac_voltage_range, power_factor,
                            surge_power_w, three_phase, bms, supports_parallel, max_parallel_units,
                            display_type, cooling_method, communication,
                            weight_kg, dimensions, ip_rating, operating_temperature, noise_level,
                            warranty_years, country, primary_application, hybrid_offgrid_charging_power_watt,
                            is_active, availability_status
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $company_id, $model, $series_name, $image_path, $battery_voltage_range, $output_power_w, $max_pv_input_w, $unit_price_usd, $type, $max_efficiency,
                            $min_pv_voltage, $max_pv_voltage, $mppt_count, $output_ac_voltage_range, $power_factor,
                            $surge_power_w, $three_phase, $bms, $supports_parallel, $max_parallel_units,
                            $display_type, $cooling_method, $communication,
                            $weight_kg, $dimensions, $ip_rating, $operating_temperature, $noise_level,
                            $warranty_years, $country, $primary_application, $hybrid_offgrid_charging_power_watt,
                            $is_active, $availability_status
                        ]);
                        $message = 'Inverter added successfully!';
                    } else {
                        $stmt = $db->prepare("UPDATE inverters SET
                            company_id = ?, model = ?, series_name = ?, image_path = ?, battery_voltage_range = ?, output_power_w = ?, max_pv_input_w = ?, unit_price_usd = ?, type = ?, max_efficiency = ?,
                            min_pv_voltage = ?, max_pv_voltage = ?, mppt_count = ?, output_ac_voltage_range = ?, power_factor = ?,
                            surge_power_w = ?, three_phase = ?, bms = ?, supports_parallel = ?, max_parallel_units = ?,
                            display_type = ?, cooling_method = ?, communication = ?,
                            weight_kg = ?, dimensions = ?, ip_rating = ?, operating_temperature = ?, noise_level = ?,
                            warranty_years = ?, country = ?, primary_application = ?, hybrid_offgrid_charging_power_watt = ?,
                            is_active = ?, availability_status = ?
                        WHERE id = ?");
                        $stmt->execute([
                            $company_id, $model, $series_name, $image_path, $battery_voltage_range, $output_power_w, $max_pv_input_w, $unit_price_usd, $type, $max_efficiency,
                            $min_pv_voltage, $max_pv_voltage, $mppt_count, $output_ac_voltage_range, $power_factor,
                            $surge_power_w, $three_phase, $bms, $supports_parallel, $max_parallel_units,
                            $display_type, $cooling_method, $communication,
                            $weight_kg, $dimensions, $ip_rating, $operating_temperature, $noise_level,
                            $warranty_years, $country, $primary_application, $hybrid_offgrid_charging_power_watt,
                            $is_active, $availability_status,
                            $id
                        ]);
                        $message = 'Inverter updated successfully!';
                    }
                }
            }
        } elseif ($action === 'delete') {
            $id = intval($_POST['id'] ?? 0);
            $db->prepare("DELETE FROM inverters WHERE id = ?")->execute([$id]);
            $message = 'Inverter deleted successfully!';
        } elseif ($action === 'show_add') {
            $showForm = true;
        } elseif ($action === 'show_edit') {
            $showForm = true;
            $id = intval($_POST['id'] ?? 0);
            $stmt = $db->prepare("SELECT * FROM inverters WHERE id = ?");
            $stmt->execute([$id]);
            $editData = $stmt->fetch();
        }
    }
}

// ── Pagination + Filters ──────────────────────────────────────────
$search_q   = trim($_GET['search'] ?? '');
$filter_co  = trim($_GET['company_id'] ?? '');
$filter_ty  = trim($_GET['type'] ?? '');
$per_page   = max(10, min(200, (int)($_GET['per_page'] ?? 25)));
$page_num   = max(1, (int)($_GET['page'] ?? 1));
$offset     = ($page_num - 1) * $per_page;

$where  = [];
$params = [];
if ($search_q)  { $where[] = "(i.model LIKE ? OR c.name LIKE ?)"; $params[] = "%$search_q%"; $params[] = "%$search_q%"; }
if ($filter_co) { $where[] = "i.company_id = ?"; $params[] = (int)$filter_co; }
if ($filter_ty) { $where[] = "i.type = ?"; $params[] = $filter_ty; }
$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$cnt = $db->prepare("SELECT COUNT(*) FROM inverters i LEFT JOIN companies c ON i.company_id=c.id $where_sql");
$cnt->execute($params);
$total_inv  = (int)$cnt->fetchColumn();
$total_pages = max(1, ceil($total_inv / $per_page));
$page_num = min($page_num, $total_pages);

$invStmt = $db->prepare("SELECT i.*, c.name as company_name FROM inverters i LEFT JOIN companies c ON i.company_id = c.id $where_sql ORDER BY i.created_at DESC LIMIT $per_page OFFSET $offset");
$invStmt->execute($params);
$inverters = $invStmt->fetchAll();

$companies = $db->query("SELECT id, name FROM companies ORDER BY name ASC")->fetchAll();

$pageTitle = "Inverters";
include 'includes/header.php';
?>

<style>
.form-container { background: white; padding: 30px; margin-bottom: 20px; border-radius: 8px; border: 2px solid #3b82f6; max-height: 80vh; overflow-y: auto; }
.form-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; }
.form-grid-2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
@media (max-width: 1024px) { .form-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 768px) { .form-grid, .form-grid-2 { grid-template-columns: 1fr; } }
.form-section { background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #3b82f6; }
.form-section h3 { margin: 0 0 15px 0; color: #1e40af; font-size: 16px; }
.checkbox-row { display: flex; flex-wrap: wrap; gap: 20px; margin-top: 10px; }
.checkbox-row label { display: flex; align-items: center; gap: 6px; cursor: pointer; }
</style>

<?php if ($message): ?>
    <div class="alert alert-success"><?= sanitize($message) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-error"><?= sanitize($error) ?></div>
<?php endif; ?>

<?php if ($showForm): ?>
<div class="form-container">
    <h2><?= $editData ? 'Edit Inverter' : 'Add New Inverter' ?></h2>
    <form method="POST" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $editData ? 'edit' : 'add' ?>">
        <?php if ($editData): ?>
            <input type="hidden" name="id" value="<?= $editData['id'] ?>">
            <input type="hidden" name="existing_image" id="existing_image" value="<?= $editData['image_path'] ?? '' ?>">
        <?php else: ?>
            <input type="hidden" name="existing_image" id="existing_image" value="">
        <?php endif; ?>

        <!-- Basic Info -->
        <div class="form-section">
            <h3>Basic Info</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label>Company *</label>
                    <select name="company_id" required>
                        <option value="">Select Company</option>
                        <?php foreach ($companies as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= ($editData['company_id'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= sanitize($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Inverter Model *</label>
                    <input type="text" name="model" value="<?= sanitize($editData['model'] ?? '') ?>" required placeholder="e.g., Nitrox 5KW">
                    <small>Product model name</small>
                </div>

                <div class="form-group">
                    <label>Series Name</label>
                    <input type="text" name="series_name" value="<?= sanitize($editData['series_name'] ?? '') ?>" placeholder="e.g., PowerMax Series">
                    <small>Product series/family</small>
                </div>

                <div class="form-group">
                    <label>Inverter Type *</label>
                    <select name="type" required>
                        <option value="off-grid" <?= ($editData['type'] ?? '') == 'off-grid' ? 'selected' : '' ?>>Off-Grid (Battery Only)</option>
                        <option value="on-grid" <?= ($editData['type'] ?? '') == 'on-grid' ? 'selected' : '' ?>>On-Grid (Grid Tie)</option>
                        <option value="hybrid" <?= ($editData['type'] ?? 'hybrid') == 'hybrid' ? 'selected' : '' ?>>Hybrid (Battery + Grid)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Battery Voltage Range *</label>
                    <select name="battery_voltage_range" required>
                        <option value="12V" <?= ($editData['battery_voltage_range'] ?? '12V') == '12V' ? 'selected' : '' ?>>12V</option>
                        <option value="24V" <?= ($editData['battery_voltage_range'] ?? '') == '24V' ? 'selected' : '' ?>>24V</option>
                        <option value="48V" <?= ($editData['battery_voltage_range'] ?? '') == '48V' ? 'selected' : '' ?>>48V</option>
                        <option value="HV" <?= ($editData['battery_voltage_range'] ?? '') == 'HV' ? 'selected' : '' ?>>HV (High Voltage)</option>
                    </select>
                    <small>Supported battery voltage</small>
                </div>

                <div class="form-group">
                    <label>Output Power (Watts) *</label>
                    <input type="number" name="output_power_w" value="<?= $editData['output_power_w'] ?? '' ?>" required placeholder="5000">
                    <small>Continuous output power</small>
                </div>

                <div class="form-group">
                    <label>Max PV Input (Watts)</label>
                    <input type="number" name="max_pv_input_w" value="<?= $editData['max_pv_input_w'] ?? '' ?>" placeholder="6500">
                    <small>Maximum solar panel wattage</small>
                </div>

                <div class="form-group">
                    <label>Unit Price (USD) *</label>
                    <input type="number" name="unit_price_usd" value="<?= $editData['unit_price_usd'] ?? '' ?>" step="0.01" required placeholder="850.00">
                    <small>Price in USD</small>
                </div>

                <div class="form-group">
                    <label>Max Efficiency (%)</label>
                    <input type="number" name="max_efficiency" value="<?= $editData['max_efficiency'] ?? 90 ?>" step="0.01" min="0" max="100" placeholder="95.5">
                    <small>Maximum conversion efficiency</small>
                </div>

                <div class="form-group">
                    <label>Product Image</label>
                    <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
                    <small>Max 2MB. JPG, PNG, or WebP</small>
                    <div style="margin-top:8px;">
                        <button type="button" class="btn btn-secondary btn-sm" onclick="openImagePicker('existing_image','inverter-image-preview','inverters')" style="font-size:13px;">&#128247; Select from Library</button>
                    </div>
                    <div id="inverter-image-preview" style="margin-top:8px;">
                        <?php if ($editData && !empty($editData['image_path'])): ?>
                            <img src="<?= sanitize($editData['image_path']) ?>" style="width:80px;height:80px;object-fit:contain;border:1px solid #ddd;border-radius:4px;">
                            <small style="display:block;color:#666;">Current: <?= sanitize(basename($editData['image_path'])) ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Electrical Specs -->
        <div class="form-section">
            <h3>Electrical Specs</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label>Min PV Voltage (VDC)</label>
                    <input type="number" name="min_pv_voltage" value="<?= $editData['min_pv_voltage'] ?? '' ?>" placeholder="30">
                    <small>Minimum solar panel voltage</small>
                </div>

                <div class="form-group">
                    <label>Max PV Voltage (VDC)</label>
                    <input type="number" name="max_pv_voltage" value="<?= $editData['max_pv_voltage'] ?? '' ?>" placeholder="500">
                    <small>Maximum solar panel voltage</small>
                </div>

                <div class="form-group">
                    <label>Output AC Voltage Range</label>
                    <input type="text" name="output_ac_voltage_range" value="<?= sanitize($editData['output_ac_voltage_range'] ?? '') ?>" placeholder="220-240V / 110-120V">
                    <small>AC output voltage range</small>
                </div>

                <div class="form-group">
                    <label>Power Factor</label>
                    <input type="text" name="power_factor" value="<?= sanitize($editData['power_factor'] ?? '') ?>" placeholder="1.0 / 0.8-1.0">
                    <small>Power factor rating</small>
                </div>

                <div class="form-group">
                    <label>MPPT Count</label>
                    <input type="number" name="mppt_count" value="<?= $editData['mppt_count'] ?? 1 ?>" min="0" max="10" placeholder="2">
                    <small>Number of MPPT trackers</small>
                </div>

                <div class="form-group">
                    <label>Max Input Current (Amps)</label>
                    <input type="number" name="max_input_current" value="<?= $editData['max_input_current'] ?? '' ?>" placeholder="25">
                    <small>Per MPPT tracker</small>
                </div>

                <div class="form-group">
                    <label>Output Voltage (VAC)</label>
                    <input type="number" name="output_voltage" value="<?= $editData['output_voltage'] ?? 230 ?>" placeholder="230">
                </div>

                <div class="form-group">
                    <label>Output Frequency (Hz)</label>
                    <input type="number" name="output_frequency" value="<?= $editData['output_frequency'] ?? 50 ?>" placeholder="50">
                </div>
            </div>
        </div>

        <!-- Power -->
        <div class="form-section">
            <h3>Power</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label>Surge Power (Watts)</label>
                    <input type="number" name="surge_power_w" value="<?= $editData['surge_power_w'] ?? '' ?>" placeholder="10000">
                    <small>Peak power capacity</small>
                </div>
            </div>
        </div>

        <!-- Features -->
        <div class="form-section">
            <h3>Features</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label>Display Type</label>
                    <input type="text" name="display_type" value="<?= sanitize($editData['display_type'] ?? '') ?>" placeholder="LCD, LED, OLED, None">
                </div>

                <div class="form-group">
                    <label>Cooling Method</label>
                    <select name="cooling_method">
                        <option value="Natural" <?= ($editData['cooling_method'] ?? 'Natural') == 'Natural' ? 'selected' : '' ?>>Natural</option>
                        <option value="Fan" <?= ($editData['cooling_method'] ?? '') == 'Fan' ? 'selected' : '' ?>>Fan</option>
                        <option value="Liquid" <?= ($editData['cooling_method'] ?? '') == 'Liquid' ? 'selected' : '' ?>>Liquid</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Communication</label>
                    <input type="text" name="communication" value="<?= sanitize($editData['communication'] ?? '') ?>" placeholder="WiFi/RS485/USB/Ethernet">
                </div>
            </div>

            <div class="checkbox-row">
                <label><input type="checkbox" name="three_phase" <?= ($editData['three_phase'] ?? 'No') === 'Yes' ? 'checked' : '' ?>> Three Phase Support</label>
                <label><input type="checkbox" name="bms" <?= ($editData['bms'] ?? 'No') === 'Yes' ? 'checked' : '' ?>> Built-in BMS</label>
            </div>
        </div>

        <!-- Parallel Configuration -->
        <div class="form-section">
            <h3>Parallel Configuration</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label><input type="checkbox" name="supports_parallel" id="parallel_capable_cb" <?= ($editData['supports_parallel'] ?? 'No') === 'Yes' ? 'checked' : '' ?> onchange="toggleParallelFields()"> Supports Parallel Operation</label>
                    <small>Can multiple units be connected in parallel?</small>
                </div>

                <div class="form-group parallel-field" id="parallel_units_group" style="<?= ($editData['parallel_capable'] ?? 0) ? '' : 'opacity:0.4;' ?>">
                    <label>Max Parallel Units</label>
                    <input type="number" name="max_parallel_units" value="<?= $editData['max_parallel_units'] ?? 1 ?>" min="1" max="99" placeholder="12">
                    <small>Maximum number of units that can be connected in parallel</small>
                </div>

                <div class="form-group parallel-field" id="parallel_phase_group" style="<?= ($editData['parallel_capable'] ?? 0) ? '' : 'opacity:0.4;' ?>">
                    <label>Parallel Phase Config</label>
                    <select name="parallel_phase_config">
                        <option value="">Select Configuration</option>
                        <?php
                        $phase_configs = [
                            'single-phase' => 'Single Phase Parallel',
                            'split-phase' => 'Split Phase (120/240V)',
                            'three-phase' => 'Three Phase (L1+L2+L3)',
                            'single-and-three' => 'Single Phase + Three Phase',
                        ];
                        foreach ($phase_configs as $val => $label): ?>
                            <option value="<?= $val ?>" <?= ($editData['parallel_phase_config'] ?? '') === $val ? 'selected' : '' ?>><?= $label ?></option>
                        <?php endforeach; ?>
                    </select>
                    <small>How units can be configured when paralleled</small>
                </div>
            </div>
        </div>
        <script>
        function toggleParallelFields() {
            var checked = document.getElementById('parallel_capable_cb').checked;
            document.getElementById('parallel_units_group').style.opacity = checked ? '1' : '0.4';
            document.getElementById('parallel_phase_group').style.opacity = checked ? '1' : '0.4';
        }
        </script>

        <!-- Physical -->
        <div class="form-section">
            <h3>Physical</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label>Weight (kg)</label>
                    <input type="number" name="weight_kg" value="<?= $editData['weight_kg'] ?? '' ?>" step="0.01" placeholder="25.5">
                </div>

                <div class="form-group">
                    <label>Dimensions (L x W x H mm)</label>
                    <input type="text" name="dimensions" value="<?= sanitize($editData['dimensions'] ?? '') ?>" placeholder="450x350x150">
                </div>

                <div class="form-group">
                    <label>IP Rating</label>
                    <select name="ip_rating">
                        <option value="">Select IP Rating</option>
                        <option value="IP21" <?= ($editData['ip_rating'] ?? '') == 'IP21' ? 'selected' : '' ?>>IP21</option>
                        <option value="IP54" <?= ($editData['ip_rating'] ?? '') == 'IP54' ? 'selected' : '' ?>>IP54</option>
                        <option value="IP65" <?= ($editData['ip_rating'] ?? '') == 'IP65' ? 'selected' : '' ?>>IP65</option>
                        <option value="IP66" <?= ($editData['ip_rating'] ?? '') == 'IP66' ? 'selected' : '' ?>>IP66</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Certification -->
        <div class="form-section">
            <h3>Certification</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label>Warranty (Years)</label>
                    <input type="number" name="warranty_years" value="<?= $editData['warranty_years'] ?? 5 ?>" min="0" max="30" placeholder="5">
                </div>

                <div class="form-group">
                    <label>Certifications</label>
                    <input type="text" name="certifications" value="<?= sanitize($editData['certifications'] ?? '') ?>" placeholder="CE/IEC/VDE/UL">
                </div>

                <div class="form-group">
                    <label>Country of Origin</label>
                    <input type="text" name="country" value="<?= sanitize($editData['country'] ?? '') ?>" placeholder="China, Pakistan, etc.">
                    <small>Manufacturing country</small>
                </div>

                <div class="form-group">
                    <label>Primary Application</label>
                    <select name="primary_application">
                        <option value="residential" <?= ($editData['primary_application'] ?? 'residential') === 'residential' ? 'selected' : '' ?>>Residential</option>
                        <option value="commercial" <?= ($editData['primary_application'] ?? '') === 'commercial' ? 'selected' : '' ?>>Commercial</option>
                        <option value="industrial" <?= ($editData['primary_application'] ?? '') === 'industrial' ? 'selected' : '' ?>>Industrial</option>
                        <option value="utility" <?= ($editData['primary_application'] ?? '') === 'utility' ? 'selected' : '' ?>>Utility Scale</option>
                    </select>
                    <small>Primary use case</small>
                </div>

                <div class="form-group">
                    <label>Charging Power (Watts)</label>
                    <input type="number" name="hybrid_offgrid_charging_power_watt" value="<?= $editData['hybrid_offgrid_charging_power_watt'] ?? '' ?>" placeholder="5000">
                    <small>Hybrid/off-grid charging power</small>
                </div>
            </div>
        </div>

        <!-- Status & Notes -->
        <div class="form-section">
            <h3>Status & Notes</h3>
            
            <div class="form-grid-2">
                <div class="form-group">
                    <label>Availability Status *</label>
                    <select name="availability_status" required>
                        <option value="available" <?= ($editData['availability_status'] ?? 'available') === 'available' ? 'selected' : '' ?>>✅ Available</option>
                        <option value="upcoming" <?= ($editData['availability_status'] ?? '') === 'upcoming' ? 'selected' : '' ?>>🔜 Upcoming</option>
                        <option value="discontinued" <?= ($editData['availability_status'] ?? '') === 'discontinued' ? 'selected' : '' ?>>❌ Discontinued</option>
                    </select>
                    <small>Product availability in market</small>
                </div>
            </div>

            <div class="form-group">
                <label>Notes</label>
                <textarea name="notes" rows="3" placeholder="Additional information about this inverter..."><?= sanitize($editData['notes'] ?? '') ?></textarea>
            </div>

            <div class="checkbox-row">
                <label><input type="checkbox" name="is_active" <?= ($editData['is_active'] ?? 1) ? 'checked' : '' ?>> Active</label>
            </div>
        </div>

        <div class="action-buttons" style="position: sticky; bottom: 0; background: white; padding: 20px 0; border-top: 2px solid #e5e7eb;">
            <button type="submit" class="btn btn-primary">Save Inverter</button>
            <a href="inverters" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php else: ?>
<div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
        <h2 style="margin:0;">All Inverters <span style="font-size:0.85rem;color:#64748b;font-weight:400;">(<?= $total_inv ?> total)</span></h2>
        <form method="POST" style="display:inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="show_add">
            <button type="submit" class="btn btn-primary">+ Add New Inverter</button>
        </form>
    </div>

    <!-- Search & Filters -->
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:18px;padding:14px 16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;">
        <input type="text" name="search" value="<?= htmlspecialchars($search_q) ?>" placeholder="Search name or company..." style="flex:1;min-width:180px;padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
        <select name="company_id" style="padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
            <option value="">All Companies</option>
            <?php foreach ($companies as $co): ?>
                <option value="<?= $co['id'] ?>" <?= (string)$filter_co === (string)$co['id'] ? 'selected' : '' ?>><?= sanitize($co['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="type" style="padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
            <option value="">All Types</option>
            <option value="hybrid"   <?= $filter_ty === 'hybrid'   ? 'selected' : '' ?>>Hybrid</option>
            <option value="on-grid"  <?= $filter_ty === 'on-grid'  ? 'selected' : '' ?>>On-Grid</option>
            <option value="off-grid" <?= $filter_ty === 'off-grid' ? 'selected' : '' ?>>Off-Grid</option>
        </select>
        <select name="per_page" style="padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
            <?php foreach ([10,25,50,100] as $opt): ?>
                <option value="<?= $opt ?>" <?= $per_page == $opt ? 'selected' : '' ?>><?= $opt ?> per page</option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary btn-sm">Filter</button>
        <?php if ($search_q || $filter_co || $filter_ty): ?>
            <a href="inverters.php" class="btn btn-secondary btn-sm">✕ Clear</a>
        <?php endif; ?>
    </form>

    <div style="overflow-x:auto;">
        <table class="data-table" id="inv-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Company</th>
                    <th>Max Load</th>
                    <th>Price</th>
                    <th>Type</th>
                    <th>Voltage</th>
                    <th>Parallel</th>
                    <th>Active</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="inv-tbody">
                <!-- rows loaded via AJAX -->
            </tbody>
        </table>
    </div>

    <!-- count + load more -->
    <div style="margin-top:14px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
        <div id="inv-count" style="font-size:0.85rem;color:#64748b;">Loading&hellip;</div>
        <button type="button" id="inv-load-more" style="display:none;padding:8px 22px;background:#3b82f6;color:#fff;border:none;border-radius:7px;font-size:0.85rem;font-weight:600;cursor:pointer;" onclick="invLoadMore()">Load More</button>
    </div>
</div>
<?php endif; ?>

<?php include 'includes/image_picker_modal.php'; ?>

<input type="hidden" id="_inline_image_hidden" value="">
<div id="_inline_image_preview" style="display:none;"></div>

<script>
/* ── Inverters AJAX Load More ────────────────────────────────────── */
var _inv = {
    page       : 1,
    totalPages : 1,
    total      : 0,
    loaded     : 0,
    loading    : false,
    search     : <?= json_encode($search_q) ?>,
    company_id : <?= json_encode($filter_co) ?>,
    filter     : <?= json_encode($filter_ty) ?>,
    per_page   : <?= (int)$per_page ?>
};

function escH(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function invRowHtml(r) {
    var img = r.img_url
        ? '<img src="' + r.img_url + '" style="width:60px;height:60px;object-fit:contain;border-radius:4px;border:1px solid #e2e8f0;">'
        : '<span style="color:#cbd5e1;font-size:1.5rem;">\uD83D\uDDBC</span>';

    var parallel = r.parallel_capable
        ? '<span class="badge badge-green" title="Max ' + r.max_parallel_units + ' units">&times;' + r.max_parallel_units + '</span>'
        : '<span style="color:#aaa">&mdash;</span>';

    var activeIcon = r.is_active ? '&#10003;' : '&#10007;';
    var pinBtn = r.image_path ? '<a href="inverter_pinpoints.php?id=' + r.id + '" class="btn btn-primary btn-sm">Pinpoints</a> ' : '';
    var csrf = document.querySelector('input[name="csrf_token"]') ? document.querySelector('input[name="csrf_token"]').value : '';

    return '<tr>' +
        '<td>' + r.id + '</td>' +
        '<td>' + img + '</td>' +
        '<td><strong>' + escH(r.name) + '</strong></td>' +
        '<td>' + escH(r.company_name) + '</td>' +
        '<td>' + Number(r.power_rating).toLocaleString() + 'W</td>' +
        '<td>' + Number(r.price_usd).toLocaleString(undefined,{maximumFractionDigits:0}) + '</td>' +
        '<td><span class="badge badge-green">' + escH(r.type || 'hybrid') + '</span></td>' +
        '<td><span class="badge badge-blue">' + escH(r.vdc_type) + '</span></td>' +
        '<td>' + parallel + '</td>' +
        '<td>' + activeIcon + '</td>' +
        '<td>' +
            '<form method="POST" style="display:inline;"><input type="hidden" name="csrf_token" value="' + csrf + '"><input type="hidden" name="action" value="show_edit"><input type="hidden" name="id" value="' + r.id + '"><button type="submit" class="btn btn-secondary btn-sm">Edit</button></form> ' +
            '<button type="button" class="btn btn-secondary btn-sm" onclick="openInlineImagePicker(' + r.id + ')" title="Assign Image">&#128247;</button> ' +
            pinBtn +
            '<form method="POST" style="display:inline;" onsubmit="return confirm(\'Delete?\');"><input type="hidden" name="csrf_token" value="' + csrf + '"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="' + r.id + '"><button type="submit" class="btn btn-danger btn-sm">Delete</button></form>' +
        '</td>' +
    '</tr>';
}

function invFetch(append) {
    if (_inv.loading) return;
    _inv.loading = true;
    var tbody   = document.getElementById('inv-tbody');
    var countEl = document.getElementById('inv-count');
    var loadBtn = document.getElementById('inv-load-more');

    if (!append) {
        tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;padding:20px;color:#64748b;">Loading&hellip;</td></tr>';
        _inv.page   = 1;
        _inv.loaded = 0;
        loadBtn.style.display = 'none';
    }

    var url = 'ajax/products_browse.php?type=inverters' +
        '&page=' + _inv.page +
        '&per_page=' + _inv.per_page +
        '&search=' + encodeURIComponent(_inv.search) +
        '&company_id=' + encodeURIComponent(_inv.company_id) +
        '&filter=' + encodeURIComponent(_inv.filter);

    fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(data) {
            _inv.loading = false;
            if (!data.success) { tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;color:#dc2626;">Error loading data</td></tr>'; return; }

            _inv.totalPages = data.total_pages;
            _inv.total      = data.total;

            if (!append) tbody.innerHTML = '';

            if (data.rows.length === 0 && !append) {
                tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;padding:30px;color:#94a3b8;">No inverters found.</td></tr>';
                countEl.textContent = '0 inverters';
                loadBtn.style.display = 'none';
                return;
            }

            data.rows.forEach(function(r) {
                tbody.insertAdjacentHTML('beforeend', invRowHtml(r));
            });

            _inv.loaded += data.rows.length;
            countEl.textContent = 'Showing ' + _inv.loaded + ' of ' + _inv.total + ' inverters';
            loadBtn.style.display = (_inv.page < _inv.totalPages) ? 'inline-block' : 'none';
        })
        .catch(function() { _inv.loading = false; });
}

function invLoadMore() {
    _inv.page++;
    invFetch(true);
}

window.addEventListener('DOMContentLoaded', function() { invFetch(false); });

document.addEventListener('DOMContentLoaded', function() {
    var filterForm = document.querySelector('form[method="GET"]');
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var fd = new FormData(filterForm);
            _inv.search     = fd.get('search') || '';
            _inv.company_id = fd.get('company_id') || '';
            _inv.filter     = fd.get('type') || '';
            _inv.per_page   = parseInt(fd.get('per_page')) || 25;
            invFetch(false);
            history.replaceState(null, '', '?' + new URLSearchParams(Object.fromEntries(fd.entries())).toString());
        });
    }
});

/* ── Inline image picker for inverters ────────────────────────────── */
var _inlineImageInverterId = null;

function openInlineImagePicker(inverterId) {
    _inlineImageInverterId = inverterId;
    openImagePicker('_inline_image_hidden', '_inline_image_preview', 'inverters');
}

(function() {
    var interval = setInterval(function() {
        if (window.imgPickerUseSelected) {
            clearInterval(interval);
            var origUseSelected = window.imgPickerUseSelected;
            window.imgPickerUseSelected = function() {
                origUseSelected();
                if (_inlineImageInverterId) {
                    var imagePath = document.getElementById('_inline_image_hidden').value;
                    if (imagePath) {
                        var csrfInput = document.querySelector('input[name="csrf_token"]');
                        var formData = new FormData();
                        formData.append('action', 'update_image');
                        formData.append('csrf_token', csrfInput ? csrfInput.value : '');
                        formData.append('id', _inlineImageInverterId);
                        formData.append('image_path', imagePath);
                        fetch('inverters.php', { method: 'POST', body: formData })
                            .then(function(r) { return r.json(); })
                            .then(function(data) {
                                if (data.success) { location.reload(); }
                                else { alert('Failed to update image: ' + (data.error || 'Unknown error')); }
                            })
                            .catch(function() { alert('Error updating image'); });
                    }
                    _inlineImageInverterId = null;
                }
            };
        }
    }, 100);
})();
</script>
<?php include 'includes/footer.php'; ?>

