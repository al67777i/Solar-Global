<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/csrf.php';
require_once '../includes/helpers.php';

$db = getDB();
$message = '';
$error = '';
$showForm = false;
$editData = null;

// AJAX: inline image assign from table row
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_image') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'error' => 'Invalid token']);
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $image_path = trim($_POST['image_path'] ?? '');
    if ($id > 0 && $image_path) {
        $db->prepare("UPDATE panels SET image_path = ? WHERE id = ?")->execute([$image_path, $id]);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid data']);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid token';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'add' || $action === 'edit') {
            $id = intval($_POST['id'] ?? 0);
            $company_id = intval($_POST['company_id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $wattage = intval($_POST['wattage'] ?? 0);
            $voc = floatval($_POST['voc'] ?? 0);
            $vmp = floatval($_POST['vmp'] ?? 0);
            $isc = floatval($_POST['isc'] ?? 0);
            $price_usd = floatval($_POST['price_usd'] ?? 0);
            $is_active = isset($_POST['is_active']) ? 1 : 0;

            // New fields
            $panel_type = trim($_POST['panel_type'] ?? '');
            $efficiency = ($_POST['efficiency'] ?? '') !== '' ? floatval($_POST['efficiency']) : null;
            $warranty_years = ($_POST['warranty_years'] ?? '') !== '' ? intval($_POST['warranty_years']) : null;
            $degradation_percent = ($_POST['degradation_percent'] ?? '') !== '' ? floatval($_POST['degradation_percent']) : null;
            $temperature_coefficient = ($_POST['temperature_coefficient'] ?? '') !== '' ? floatval($_POST['temperature_coefficient']) : null;
            $dimensions = trim($_POST['dimensions'] ?? '') ?: null;
            $weight_kg = ($_POST['weight_kg'] ?? '') !== '' ? floatval($_POST['weight_kg']) : null;
            $cells_count = ($_POST['cells_count'] ?? '') !== '' ? intval($_POST['cells_count']) : null;
            $max_system_voltage = ($_POST['max_system_voltage'] ?? '') !== '' ? intval($_POST['max_system_voltage']) : null;
            $operating_temp = trim($_POST['operating_temp'] ?? '') ?: null;
            $certifications = trim($_POST['certifications'] ?? '') ?: null;
            $country_origin = trim($_POST['country_origin'] ?? '') ?: null;
            $frame_color = trim($_POST['frame_color'] ?? '') ?: null;
            $backsheet_color = trim($_POST['backsheet_color'] ?? '') ?: null;

            // Sanitize panel_type against allowed values
            $allowed_panel_types = ['Monocrystalline', 'Polycrystalline', 'Bifacial', 'Thin-Film', 'HJT', 'TOPCon'];
            if ($panel_type !== '' && !in_array($panel_type, $allowed_panel_types)) {
                $panel_type = null;
            }
            $panel_type = $panel_type ?: null;

            // Sanitize frame_color against allowed values
            $allowed_frame_colors = ['Black', 'Silver', 'Anodized'];
            if ($frame_color !== null && !in_array($frame_color, $allowed_frame_colors)) {
                $frame_color = null;
            }

            // Sanitize backsheet_color against allowed values
            $allowed_backsheet_colors = ['White', 'Black', 'Transparent'];
            if ($backsheet_color !== null && !in_array($backsheet_color, $allowed_backsheet_colors)) {
                $backsheet_color = null;
            }

            if (empty($name) || $company_id == 0) {
                $error = 'Name and company required';
            } else {
                $image_path = $_POST['existing_image'] ?? null;
                if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                    $upload_result = handle_image_upload($_FILES['image'], '../uploads/panels/');
                    if ($upload_result['success']) {
                        $image_path = $upload_result['path'];
                    }
                }

                if (empty($error)) {
                    if ($action === 'add') {
                        $stmt = $db->prepare("INSERT INTO panels (company_id, name, image_path, wattage, voc, vmp, isc, price_usd, is_active, panel_type, efficiency, warranty_years, degradation_percent, temperature_coefficient, dimensions, weight_kg, cells_count, max_system_voltage, operating_temp, certifications, country_origin, frame_color, backsheet_color) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$company_id, $name, $image_path, $wattage, $voc, $vmp, $isc, $price_usd, $is_active, $panel_type, $efficiency, $warranty_years, $degradation_percent, $temperature_coefficient, $dimensions, $weight_kg, $cells_count, $max_system_voltage, $operating_temp, $certifications, $country_origin, $frame_color, $backsheet_color]);
                        $message = 'Panel added successfully!';
                    } else {
                        $stmt = $db->prepare("UPDATE panels SET company_id = ?, name = ?, image_path = ?, wattage = ?, voc = ?, vmp = ?, isc = ?, price_usd = ?, is_active = ?, panel_type = ?, efficiency = ?, warranty_years = ?, degradation_percent = ?, temperature_coefficient = ?, dimensions = ?, weight_kg = ?, cells_count = ?, max_system_voltage = ?, operating_temp = ?, certifications = ?, country_origin = ?, frame_color = ?, backsheet_color = ? WHERE id = ?");
                        $stmt->execute([$company_id, $name, $image_path, $wattage, $voc, $vmp, $isc, $price_usd, $is_active, $panel_type, $efficiency, $warranty_years, $degradation_percent, $temperature_coefficient, $dimensions, $weight_kg, $cells_count, $max_system_voltage, $operating_temp, $certifications, $country_origin, $frame_color, $backsheet_color, $id]);
                        $message = 'Panel updated successfully!';
                    }
                }
            }
        } elseif ($action === 'delete') {
            $id = intval($_POST['id'] ?? 0);
            $db->prepare("DELETE FROM panels WHERE id = ?")->execute([$id]);
            $message = 'Panel deleted successfully!';
        } elseif ($action === 'show_add') {
            $showForm = true;
        } elseif ($action === 'show_edit') {
            $showForm = true;
            $id = intval($_POST['id'] ?? 0);
            $stmt = $db->prepare("SELECT * FROM panels WHERE id = ?");
            $stmt->execute([$id]);
            $editData = $stmt->fetch();
        }
    }
}

// ── Pagination + Filters ──
$search_q   = trim($_GET['search'] ?? '');
$filter_co  = trim($_GET['company_id'] ?? '');
$filter_ty  = trim($_GET['type'] ?? '');
$per_page   = max(10, min(200, (int)($_GET['per_page'] ?? 25)));
$page_num   = max(1, (int)($_GET['page'] ?? 1));
$offset     = ($page_num - 1) * $per_page;

$where  = [];
$params = [];
if ($search_q)  { $where[] = "(p.name LIKE ? OR c.name LIKE ?)"; $params[] = "%$search_q%"; $params[] = "%$search_q%"; }
if ($filter_co) { $where[] = "p.company_id = ?"; $params[] = (int)$filter_co; }
if ($filter_ty) { $where[] = "p.panel_type = ?"; $params[] = $filter_ty; }
$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$cnt = $db->prepare("SELECT COUNT(*) FROM panels p LEFT JOIN companies c ON p.company_id=c.id $where_sql");
$cnt->execute($params);
$total_pan   = (int)$cnt->fetchColumn();
$total_pages = max(1, ceil($total_pan / $per_page));
$page_num    = min($page_num, $total_pages);

$panStmt = $db->prepare("SELECT p.*, c.name as company_name FROM panels p LEFT JOIN companies c ON p.company_id = c.id $where_sql ORDER BY p.wattage DESC LIMIT $per_page OFFSET $offset");
$panStmt->execute($params);
$panels = $panStmt->fetchAll();

$companies = $db->query("SELECT id, name FROM companies ORDER BY name ASC")->fetchAll();

$pageTitle = "Solar Panels";
include 'includes/header.php';
?>

<style>
.form-container { background: white; padding: 30px; margin-bottom: 20px; border-radius: 8px; border: 2px solid #3b82f6; }
.form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
@media (max-width: 768px) { .form-grid { grid-template-columns: 1fr; } }
.form-section { margin-top: 24px; margin-bottom: 8px; padding-bottom: 6px; border-bottom: 2px solid #e5e7eb; }
.form-section h3 { margin: 0; font-size: 15px; font-weight: 600; color: #374151; text-transform: uppercase; letter-spacing: 0.05em; }
</style>

<?php if ($message): ?>
    <div class="alert alert-success"><?= sanitize($message) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-error"><?= sanitize($error) ?></div>
<?php endif; ?>

<?php if ($showForm): ?>
<div class="form-container">
    <h2><?= $editData ? 'Edit Solar Panel' : 'Add New Solar Panel' ?></h2>
    <form method="POST" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $editData ? 'edit' : 'add' ?>">
        <?php if ($editData): ?>
            <input type="hidden" name="id" value="<?= $editData['id'] ?>">
            <input type="hidden" name="existing_image" id="existing_image" value="<?= $editData['image_path'] ?? '' ?>">
        <?php else: ?>
            <input type="hidden" name="existing_image" id="existing_image" value="">
        <?php endif; ?>

        <!-- Basic Info -->
        <div class="form-section"><h3>Basic Info</h3></div>
        <div class="form-grid">
            <div class="form-group">
                <label>Company *</label>
                <select name="company_id" required>
                    <option value="">Select Company</option>
                    <?php foreach ($companies as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($editData['company_id'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= sanitize($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Panel Name *</label>
                <input type="text" name="name" value="<?= sanitize($editData['name'] ?? '') ?>" required>
            </div>

            <div class="form-group">
                <label>Watt Peak *</label>
                <input type="number" name="wattage" value="<?= $editData['wattage'] ?? '' ?>" required>
            </div>

            <div class="form-group">
                <label>Price *</label>
                <input type="number" name="price_usd" value="<?= $editData['price_usd'] ?? '' ?>" step="0.01" required>
                <small>Currency based on product's country</small>
            </div>

            <div class="form-group">
                <label>Panel Type</label>
                <select name="panel_type">
                    <option value="">Select Type</option>
                    <?php
                    $panel_types = ['Monocrystalline', 'Polycrystalline', 'Bifacial', 'Thin-Film', 'HJT', 'TOPCon'];
                    foreach ($panel_types as $pt): ?>
                        <option value="<?= $pt ?>" <?= ($editData['panel_type'] ?? '') === $pt ? 'selected' : '' ?>><?= $pt ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Product Image</label>
                <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
                <small>Max 2MB. JPG, PNG, or WebP</small>
                <div style="margin-top:8px;">
                    <button type="button" class="btn btn-secondary btn-sm" onclick="openImagePicker('existing_image','panel-image-preview','panels')" style="font-size:13px;">&#128247; Select from Library</button>
                </div>
                <div id="panel-image-preview" style="margin-top:8px;">
                    <?php if (!empty($editData['image_path'])): ?>
                        <img src="<?= htmlspecialchars(get_image_url($editData['image_path'])) ?>" style="width:80px;height:80px;object-fit:contain;border:1px solid #ddd;border-radius:4px;">
                        <small style="display:block;color:#666;">Current image</small>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Electrical -->
        <div class="form-section"><h3>Electrical</h3></div>
        <div class="form-grid">
            <div class="form-group">
                <label>Voc (Open Circuit Voltage) *</label>
                <input type="number" name="voc" value="<?= $editData['voc'] ?? '' ?>" step="0.01" required>
            </div>

            <div class="form-group">
                <label>Vmp (Max Power Voltage) *</label>
                <input type="number" name="vmp" value="<?= $editData['vmp'] ?? '' ?>" step="0.01" required>
            </div>

            <div class="form-group">
                <label>Isc (Short Circuit Current) *</label>
                <input type="number" name="isc" value="<?= $editData['isc'] ?? '' ?>" step="0.01" required>
            </div>

            <div class="form-group">
                <label>Efficiency (%)</label>
                <input type="number" name="efficiency" value="<?= $editData['efficiency'] ?? '' ?>" step="0.01" min="0" max="100">
            </div>

            <div class="form-group">
                <label>Temperature Coefficient (%/C)</label>
                <input type="number" name="temperature_coefficient" value="<?= $editData['temperature_coefficient'] ?? '' ?>" step="0.001">
                <small>e.g. -0.350</small>
            </div>

            <div class="form-group">
                <label>Max System Voltage (V)</label>
                <input type="number" name="max_system_voltage" value="<?= $editData['max_system_voltage'] ?? '' ?>">
            </div>

            <div class="form-group">
                <label>Number of Cells</label>
                <input type="number" name="cells_count" value="<?= $editData['cells_count'] ?? '' ?>">
            </div>
        </div>

        <!-- Physical -->
        <div class="form-section"><h3>Physical</h3></div>
        <div class="form-grid">
            <div class="form-group">
                <label>Weight (kg)</label>
                <input type="number" name="weight_kg" value="<?= $editData['weight_kg'] ?? '' ?>" step="0.1" min="0">
            </div>

            <div class="form-group">
                <label>Dimensions (L x W x H mm)</label>
                <input type="text" name="dimensions" value="<?= sanitize($editData['dimensions'] ?? '') ?>" placeholder="e.g. 2278 x 1134 x 30">
            </div>

            <div class="form-group">
                <label>Frame Color</label>
                <select name="frame_color">
                    <option value="">Select Color</option>
                    <?php
                    $frame_colors = ['Black', 'Silver', 'Anodized'];
                    foreach ($frame_colors as $fc): ?>
                        <option value="<?= $fc ?>" <?= ($editData['frame_color'] ?? '') === $fc ? 'selected' : '' ?>><?= $fc ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Backsheet Color</label>
                <select name="backsheet_color">
                    <option value="">Select Color</option>
                    <?php
                    $backsheet_colors = ['White', 'Black', 'Transparent'];
                    foreach ($backsheet_colors as $bc): ?>
                        <option value="<?= $bc ?>" <?= ($editData['backsheet_color'] ?? '') === $bc ? 'selected' : '' ?>><?= $bc ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <!-- Performance -->
        <div class="form-section"><h3>Performance</h3></div>
        <div class="form-grid">
            <div class="form-group">
                <label>Annual Degradation (%)</label>
                <input type="number" name="degradation_percent" value="<?= $editData['degradation_percent'] ?? '' ?>" step="0.01" min="0" max="100">
                <small>e.g. 0.55</small>
            </div>

            <div class="form-group">
                <label>Operating Temperature Range</label>
                <input type="text" name="operating_temp" value="<?= sanitize($editData['operating_temp'] ?? '') ?>" placeholder="e.g. -40 to +85 C">
            </div>
        </div>

        <!-- Certification -->
        <div class="form-section"><h3>Certification</h3></div>
        <div class="form-grid">
            <div class="form-group">
                <label>Warranty (years)</label>
                <input type="number" name="warranty_years" value="<?= $editData['warranty_years'] ?? '' ?>" min="0">
            </div>

            <div class="form-group">
                <label>Certifications</label>
                <input type="text" name="certifications" value="<?= sanitize($editData['certifications'] ?? '') ?>" placeholder="e.g. IEC 61215, IEC 61730, UL 1703">
            </div>

            <div class="form-group">
                <label>Country of Origin</label>
                <input type="text" name="country_origin" value="<?= sanitize($editData['country_origin'] ?? '') ?>" placeholder="e.g. China, Germany">
            </div>
        </div>

        <div class="form-group" style="margin-top: 16px;">
            <label><input type="checkbox" name="is_active" <?= ($editData['is_active'] ?? 1) ? 'checked' : '' ?>> Active</label>
        </div>

        <div class="action-buttons">
            <button type="submit" class="btn btn-primary">Save Panel</button>
            <a href="panels.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php else: ?>
<div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
        <h2 style="margin:0;">All Solar Panels <span style="font-size:0.85rem;color:#64748b;font-weight:400;">(<?= $total_pan ?> total)</span></h2>
        <form method="POST" style="display:inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="show_add">
            <button type="submit" class="btn btn-primary">+ Add New Panel</button>
        </form>
    </div>

    <!-- Search & Filters -->
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:18px;padding:14px 16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;">
        <input type="text" name="search" value="<?= htmlspecialchars($search_q) ?>" placeholder="Search name or company..." style="flex:1;min-width:180px;padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
        <select name="company_id" style="padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
            <option value="">All Companies</option>
            <?php foreach ($companies as $co): ?>
                <option value="<?= $co['id'] ?>" <?= (string)$filter_co === (string)$co['id'] ? 'selected' : '' ?>><?= sanitize($co['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="type" style="padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
            <option value="">All Types</option>
            <?php foreach (['Monocrystalline','Polycrystalline','Bifacial','Thin-Film','HJT','TOPCon'] as $t): ?>
                <option value="<?= $t ?>" <?= $filter_ty === $t ? 'selected' : '' ?>><?= $t ?></option>
            <?php endforeach; ?>
        </select>
        <select name="per_page" style="padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
            <?php foreach ([10,25,50,100] as $opt): ?>
                <option value="<?= $opt ?>" <?= $per_page == $opt ? 'selected' : '' ?>><?= $opt ?> per page</option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary btn-sm">Filter</button>
        <?php if ($search_q || $filter_co || $filter_ty): ?>
            <a href="panels.php" class="btn btn-secondary btn-sm">✕ Clear</a>
        <?php endif; ?>
    </form>

    <div style="overflow-x:auto;">
    <table class="data-table" id="panels-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Company</th>
                <th>Watt Peak</th>
                <th>Price</th>
                <th>Type</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="panels-tbody">
            <!-- rows loaded via AJAX -->
        </tbody>
    </table>
    </div>

    <!-- count + load more -->
    <div style="margin-top:14px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
        <div id="panels-count" style="font-size:0.85rem;color:#64748b;">Loading&hellip;</div>
        <button type="button" id="panels-load-more" style="display:none;padding:8px 22px;background:#3b82f6;color:#fff;border:none;border-radius:7px;font-size:0.85rem;font-weight:600;cursor:pointer;" onclick="panelsLoadMore()">Load More</button>
    </div>
</div>
<?php endif; ?>

<?php include 'includes/image_picker_modal.php'; ?>

<script>
/* ── Panels AJAX Load More ──────────────────────────────────────── */
var _pan = {
    page       : 1,
    totalPages : 1,
    total      : 0,
    loaded     : 0,
    loading    : false,
    search     : <?= json_encode($search_q) ?>,
    company_id : <?= json_encode($filter_co) ?>,
    filter     : <?= json_encode($filter_ty) ?>,
    per_page   : <?= (int)$per_page ?>
};

function panelRowHtml(p) {
    var img = p.img_url
        ? '<img src="' + p.img_url + '" style="width:60px;height:60px;object-fit:contain;border-radius:4px;border:1px solid #e2e8f0;">'
        : '<span style="color:#cbd5e1;font-size:1.5rem;">\uD83D\uDDBC</span>';

    var pinBtn = p.image_path
        ? '<a href="panel_pinpoints.php?id=' + p.id + '" class="btn btn-primary btn-sm">Pinpoints</a>'
        : '';

    var csrf = document.querySelector('input[name="csrf_token"]') ? document.querySelector('input[name="csrf_token"]').value : '';

    return '<tr>' +
        '<td>' + p.id + '</td>' +
        '<td id="panel-img-' + p.id + '">' + img + '</td>' +
        '<td><strong>' + escHtml(p.name) + '</strong></td>' +
        '<td>' + escHtml(p.company_name) + '</td>' +
        '<td>' + Number(p.wattage).toLocaleString() + 'W</td>' +
        '<td>' + Number(p.price_usd).toLocaleString(undefined,{maximumFractionDigits:0}) + '</td>' +
        '<td>' + escHtml(p.panel_type || '-') + '</td>' +
        '<td>' +
            '<button type="button" class="btn btn-secondary btn-sm" onclick="openInlineImagePicker(' + p.id + ')" title="Assign Image">&#128247;</button> ' +
            '<form method="POST" style="display:inline;"><input type="hidden" name="csrf_token" value="' + csrf + '"><input type="hidden" name="action" value="show_edit"><input type="hidden" name="id" value="' + p.id + '"><button type="submit" class="btn btn-secondary btn-sm">Edit</button></form> ' +
            pinBtn +
            ' <form method="POST" style="display:inline;" onsubmit="return confirm(' + "'Delete?'" + ');"><input type="hidden" name="csrf_token" value="' + csrf + '"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="' + p.id + '"><button type="submit" class="btn btn-danger btn-sm">Delete</button></form>' +
        '</td>' +
    '</tr>';
}

function panelsFetch(append) {
    if (_pan.loading) return;
    _pan.loading = true;
    var tbody   = document.getElementById('panels-tbody');
    var countEl = document.getElementById('panels-count');
    var loadBtn = document.getElementById('panels-load-more');

    if (!append) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:20px;color:#64748b;">Loading&hellip;</td></tr>';
        _pan.page   = 1;
        _pan.loaded = 0;
        loadBtn.style.display = 'none';
    }

    var url = 'ajax/products_browse.php?type=panels' +
        '&page=' + _pan.page +
        '&per_page=' + _pan.per_page +
        '&search=' + encodeURIComponent(_pan.search) +
        '&company_id=' + encodeURIComponent(_pan.company_id) +
        '&filter=' + encodeURIComponent(_pan.filter);

    fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(data) {
            _pan.loading = false;
            if (!data.success) { tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#dc2626;">Error loading data</td></tr>'; return; }

            _pan.totalPages = data.total_pages;
            _pan.total      = data.total;

            if (!append) tbody.innerHTML = '';

            if (data.rows.length === 0 && !append) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:30px;color:#94a3b8;">No panels found.</td></tr>';
                countEl.textContent = '0 panels';
                loadBtn.style.display = 'none';
                return;
            }

            data.rows.forEach(function(p) {
                tbody.insertAdjacentHTML('beforeend', panelRowHtml(p));
            });

            _pan.loaded += data.rows.length;
            countEl.textContent = 'Showing ' + _pan.loaded + ' of ' + _pan.total + ' panels';
            loadBtn.style.display = (_pan.page < _pan.totalPages) ? 'inline-block' : 'none';
        })
        .catch(function() { _pan.loading = false; });
}

function panelsLoadMore() {
    _pan.page++;
    panelsFetch(true);
}

function escHtml(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Initial load + re-load on filter form submit
window.addEventListener('DOMContentLoaded', function() { panelsFetch(false); });

// Hijack the GET filter form to update _pan state and re-fetch instead of reloading
document.addEventListener('DOMContentLoaded', function() {
    var filterForm = document.querySelector('form[method="GET"]');
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var fd = new FormData(filterForm);
            _pan.search     = fd.get('search') || '';
            _pan.company_id = fd.get('company_id') || '';
            _pan.filter     = fd.get('type') || '';
            _pan.per_page   = parseInt(fd.get('per_page')) || 25;
            panelsFetch(false);
            // Update URL
            history.replaceState(null, '', '?' + new URLSearchParams(Object.fromEntries(fd.entries())).toString());
        });
    }
});
</script>

<?php include 'includes/image_picker_modal.php'; ?>

<script>
var _inlinePickerId = null;

function openInlineImagePicker(id) {
    _inlinePickerId = id;
    // Point the picker at our hidden staging input so it stores file_path there
    openImagePicker('_inline_tmp_img', '_inline_tmp_prev', 'panels');
}

(function () {
    var _interval = setInterval(function () {
        if (window.imgPickerUseSelected) {
            clearInterval(_interval);
            var _origUse = window.imgPickerUseSelected;

            window.imgPickerUseSelected = function () {
                // 1. Call original — this writes file_path → #_inline_tmp_img and closes modal
                _origUse();

                // 2. If we opened the picker inline (not from edit form), do AJAX update
                if (_inlinePickerId) {
                    var rowId = _inlinePickerId;
                    _inlinePickerId = null;

                    var imgPath = document.getElementById('_inline_tmp_img').value;
                    if (!imgPath) { alert('No image selected.'); return; }

                    var fd = new FormData();
                    fd.append('action',     'update_image');
                    fd.append('id',         rowId);
                    fd.append('image_path', imgPath);
                    fd.append('csrf_token', '<?= generate_csrf_token() ?>');

                    fetch('panels.php', { method: 'POST', body: fd })
                        .then(function (r) { return r.json(); })
                        .then(function (d) {
                            if (d.success) {
                                location.reload();
                            } else {
                                alert(d.error || 'Failed to update image.');
                            }
                        })
                        .catch(function () { alert('Network error. Please try again.'); });
                }
            };
        }
    }, 100);
})();
</script>
<input type="hidden" id="_inline_tmp_img" value="">
<div id="_inline_tmp_prev" style="display:none;"></div>

<?php include 'includes/footer.php'; ?>
