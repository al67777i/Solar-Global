<?php
/**
 * Customer Watchlist API
 * Actions: add, remove, list
 */
session_start();
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/customer_auth.php';

header('Content-Type: application/json; charset=utf-8');

// Rate limiting: 30 requests per minute
if (!rate_limit('api_watchlist', 30, 60)) {
    respond_rate_limited();
}

if (!is_customer_logged_in()) {
    respond_json(['error' => 'Not authenticated.'], 401);
}

$db = getDB();
$customer_id = get_customer_id();
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    case 'add':
        $product_type = $_POST['product_type'] ?? '';
        $product_id = (int)($_POST['product_id'] ?? 0);

        if (!in_array($product_type, ['inverter', 'battery', 'panel', 'installation_appliance'])) {
            respond_json(['error' => 'Invalid product type.'], 400);
        }
        if ($product_id <= 0) {
            respond_json(['error' => 'Invalid product.'], 400);
        }

        // Verify product exists
        $tables = ['inverter' => 'inverters', 'battery' => 'batteries', 'panel' => 'panels', 'installation_appliance' => 'installation_appliances'];
        $stmt = $db->prepare("SELECT id FROM {$tables[$product_type]} WHERE id = ? AND is_active = 1");
        $stmt->execute([$product_id]);
        if (!$stmt->fetch()) {
            respond_json(['error' => 'Product not found.'], 404);
        }

        try {
            $stmt = $db->prepare("INSERT IGNORE INTO watchlist (customer_id, product_type, product_id) VALUES (?, ?, ?)");
            $stmt->execute([$customer_id, $product_type, $product_id]);
            respond_json(['success' => true, 'message' => 'Added to watchlist.']);
        } catch (Exception $e) {
            respond_json(['error' => 'Already in watchlist.'], 409);
        }
        break;

    case 'remove':
        $product_type = $_POST['product_type'] ?? '';
        $product_id = (int)($_POST['product_id'] ?? 0);

        $stmt = $db->prepare("DELETE FROM watchlist WHERE customer_id = ? AND product_type = ? AND product_id = ?");
        $stmt->execute([$customer_id, $product_type, $product_id]);
        respond_json(['success' => true, 'removed' => $stmt->rowCount()]);
        break;

    case 'list':
        $type_filter = $_GET['type'] ?? '';
        $sql = "SELECT w.*,
                CASE w.product_type
                    WHEN 'inverter' THEN (SELECT model FROM inverters WHERE id = w.product_id)
                    WHEN 'battery' THEN (SELECT model FROM batteries WHERE id = w.product_id)
                    WHEN 'panel' THEN (SELECT name FROM panels WHERE id = w.product_id)
                    WHEN 'installation_appliance' THEN (SELECT name FROM installation_appliances WHERE id = w.product_id)
                END as product_name,
                CASE w.product_type
                    WHEN 'inverter' THEN (SELECT company FROM inverters WHERE id = w.product_id)
                    WHEN 'battery' THEN (SELECT brand FROM batteries WHERE id = w.product_id)
                    WHEN 'panel' THEN (SELECT brand FROM panels WHERE id = w.product_id)
                    WHEN 'installation_appliance' THEN (SELECT brand FROM installation_appliances WHERE id = w.product_id)
                END as brand,
                CASE w.product_type
                    WHEN 'inverter' THEN (SELECT unit_price_usd FROM inverters WHERE id = w.product_id)
                    WHEN 'battery' THEN (SELECT price_unit_usd FROM batteries WHERE id = w.product_id)
                    WHEN 'panel' THEN (SELECT price_usd FROM panels WHERE id = w.product_id)
                    WHEN 'installation_appliance' THEN (SELECT price_usd FROM installation_appliances WHERE id = w.product_id)
                END as base_price
                FROM watchlist w WHERE w.customer_id = ?";
        $params = [$customer_id];
        if (in_array($type_filter, ['inverter', 'battery', 'panel', 'installation_appliance'])) {
            $sql .= " AND w.product_type = ?";
            $params[] = $type_filter;
        }
        $sql .= " ORDER BY w.created_at DESC";

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        respond_json(['watchlist' => $stmt->fetchAll()]);
        break;

    case 'check':
        $product_type = $_GET['product_type'] ?? '';
        $product_id = (int)($_GET['product_id'] ?? 0);

        $stmt = $db->prepare("SELECT id FROM watchlist WHERE customer_id = ? AND product_type = ? AND product_id = ?");
        $stmt->execute([$customer_id, $product_type, $product_id]);
        respond_json(['in_watchlist' => (bool)$stmt->fetch()]);
        break;

    default:
        respond_json(['error' => 'Invalid action.'], 400);
}
