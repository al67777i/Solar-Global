/**
 * Comparison Widget - Floating Action Button (FAB)
 * Pure vanilla JS, ES5 compatible, self-contained with inline CSS
 */

(function() {
    'use strict';

    // Prevent multiple initializations
    if (window.comparisonWidgetLoaded) {
        return;
    }
    window.comparisonWidgetLoaded = true;

    // ── Config ──────────────────────────────────────────────────────────
    var MAX_ITEMS = 4;
    var TOAST_DURATION = 3000;

    // ── Storage ─────────────────────────────────────────────────────────
    var storage = {
        inverter: [],
        battery: [],
        panel: []
    };

    var panelOpen = false;
    var toastStack = [];
    var toastCounter = 0;

    // ── Inject Styles ───────────────────────────────────────────────────
    function injectStyles() {
        var isMobile = window.innerWidth <= 768;
        var fabBottom = isMobile ? '80px' : '30px';
        var fabRight = isMobile ? '16px' : '30px';
        var panelBottom = isMobile ? '150px' : '100px';
        var panelRight = isMobile ? '12px' : '30px';
        var panelExtra = isMobile ? 'left: 12px; width: auto;' : 'width: 360px;';
        var css = '' +
        /* FAB */
        '#compare-fab {' +
            'position: fixed; bottom: ' + fabBottom + '; right: ' + fabRight + '; z-index: 99999;' +
            'width: 60px; height: 60px; border-radius: 50%;' +
            'background: linear-gradient(135deg, #0D3B6E, #1565C0);' +
            'border: none; cursor: pointer; box-shadow: 0 6px 20px rgba(13,59,110,0.4);' +
            'display: flex; align-items: center; justify-content: center;' +
            'transition: transform 0.2s ease, box-shadow 0.2s ease;' +
            'outline: none;' +
        '}' +
        '#compare-fab:hover {' +
            'transform: scale(1.08);' +
            'box-shadow: 0 8px 28px rgba(13,59,110,0.55);' +
        '}' +
        '#compare-fab svg {' +
            'width: 28px; height: 28px; fill: white; pointer-events: none;' +
        '}' +
        /* Badge */
        '#compare-fab-badge {' +
            'position: absolute; top: -4px; right: -4px;' +
            'background: #EF4444; color: white; font-size: 13px; font-weight: 700;' +
            'width: 24px; height: 24px; border-radius: 50%;' +
            'display: none; align-items: center; justify-content: center;' +
            'border: 2px solid white; line-height: 1; font-family: Arial, sans-serif;' +
        '}' +
        '#compare-fab-badge.visible { display: flex; }' +
        /* Pulse */
        '@keyframes compare-pulse {' +
            '0% { box-shadow: 0 6px 20px rgba(13,59,110,0.4); }' +
            '50% { box-shadow: 0 0 0 12px rgba(21,101,192,0.25); }' +
            '100% { box-shadow: 0 6px 20px rgba(13,59,110,0.4); }' +
        '}' +
        '#compare-fab.pulse { animation: compare-pulse 0.6s ease; }' +
        /* Panel */
        '#compare-panel {' +
            'position: fixed; bottom: ' + panelBottom + '; right: ' + panelRight + '; z-index: 99998;' +
            panelExtra + ' background: white; border-radius: 14px;' +
            'box-shadow: 0 12px 40px rgba(0,0,0,0.18);' +
            'transform: translateY(20px); opacity: 0; pointer-events: none;' +
            'transition: transform 0.3s cubic-bezier(0.4,0,0.2,1), opacity 0.3s cubic-bezier(0.4,0,0.2,1);' +
            'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;' +
            'overflow: hidden;' +
        '}' +
        '#compare-panel.open {' +
            'transform: translateY(0); opacity: 1; pointer-events: auto;' +
        '}' +
        /* Panel header */
        '#compare-panel-header {' +
            'background: linear-gradient(135deg, #0D3B6E, #1565C0);' +
            'color: white; padding: 16px 18px; font-size: 15px; font-weight: 700;' +
        '}' +
        /* Panel body */
        '#compare-panel-body { padding: 14px 18px; max-height: 320px; overflow-y: auto; }' +
        /* Item row */
        '.compare-item {' +
            'background: #F8FAFC; padding: 10px 12px; margin-bottom: 8px;' +
            'border-radius: 8px; display: flex; align-items: center;' +
            'justify-content: space-between; font-size: 14px;' +
        '}' +
        '.compare-item-name { font-weight: 600; color: #1E293B; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; margin-right: 8px; }' +
        '.compare-item-remove {' +
            'background: none; border: none; color: #94A3B8; cursor: pointer;' +
            'font-size: 20px; line-height: 1; padding: 0 4px; transition: color 0.15s;' +
        '}' +
        '.compare-item-remove:hover { color: #EF4444; }' +
        /* Panel footer */
        '#compare-panel-footer {' +
            'padding: 0 18px 16px; display: flex; align-items: center; gap: 12px;' +
        '}' +
        '#compare-now-btn {' +
            'flex: 1; padding: 10px 0; border: none; border-radius: 8px;' +
            'background: #10B981; color: white; font-size: 14px; font-weight: 700;' +
            'cursor: pointer; transition: background 0.15s;' +
        '}' +
        '#compare-now-btn:hover { background: #059669; }' +
        '#compare-now-btn:disabled {' +
            'background: #E2E8F0; color: #94A3B8; cursor: not-allowed;' +
        '}' +
        '#compare-clear-btn {' +
            'background: none; border: none; color: #EF4444; font-size: 13px;' +
            'font-weight: 600; cursor: pointer; padding: 4px 0; white-space: nowrap;' +
        '}' +
        '#compare-clear-btn:hover { text-decoration: underline; }' +
        /* Empty state */
        '.compare-empty {' +
            'text-align: center; padding: 18px 0; color: #94A3B8; font-size: 14px;' +
        '}' +
        /* Toasts */
        '#compare-toast-container {' +
            'position: fixed; top: 20px; right: 20px; z-index: 100000;' +
            'display: flex; flex-direction: column; gap: 10px;' +
            'pointer-events: none;' +
        '}' +
        '.compare-toast {' +
            'background: #1E293B; color: white; padding: 14px 20px 14px 16px;' +
            'border-radius: 10px; font-size: 14px; font-weight: 500;' +
            'box-shadow: 0 8px 24px rgba(0,0,0,0.2);' +
            'transform: translateX(120%); opacity: 0;' +
            'transition: transform 0.35s cubic-bezier(0.4,0,0.2,1), opacity 0.35s;' +
            'pointer-events: auto; max-width: 320px;' +
            'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;' +
            'border-left: 4px solid #10B981;' +
        '}' +
        '.compare-toast.visible { transform: translateX(0); opacity: 1; }' +
        '.compare-toast.warning { border-left-color: #F59E0B; }' +
        '';

        var styleEl = document.createElement('style');
        styleEl.type = 'text/css';
        styleEl.id = 'compare-widget-styles';
        if (styleEl.styleSheet) {
            styleEl.styleSheet.cssText = css;
        } else {
            styleEl.appendChild(document.createTextNode(css));
        }
        document.head.appendChild(styleEl);
    }

    // Re-inject styles on resize (mobile ↔ desktop) — attached once
    var _resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(_resizeTimer);
        _resizeTimer = setTimeout(function() {
            var oldStyle = document.getElementById('compare-widget-styles');
            if (oldStyle) oldStyle.remove();
            injectStyles();
        }, 250);
    });

    // ── LocalStorage ────────────────────────────────────────────────────
    function loadStorage() {
        try {
            var data = localStorage.getItem('solar_comparison');
            if (data) {
                var parsed = JSON.parse(data);
                if (parsed.inverter) {
                    storage.inverter = parsed.inverter.filter(function(item) {
                        return item && item.id && item.name && item.name !== 'undefined';
                    });
                }
                if (parsed.battery) {
                    storage.battery = parsed.battery.filter(function(item) {
                        return item && item.id && item.name && item.name !== 'undefined';
                    });
                }
                if (parsed.panel) {
                    storage.panel = parsed.panel.filter(function(item) {
                        return item && item.id && item.name && item.name !== 'undefined';
                    });
                }
            }
        } catch (e) {
            localStorage.removeItem('solar_comparison');
            localStorage.removeItem('comparisonItems');
        }
    }

    function saveStorage() {
        try {
            localStorage.setItem('solar_comparison', JSON.stringify(storage));
        } catch (e) { /* silent */ }
    }

    // ── Page Type Detection ─────────────────────────────────────────────
    function getPageType() {
        var path = window.location.pathname.toLowerCase();
        if (path.indexOf('battery') > -1 || path.indexOf('batteries') > -1) return 'battery';
        if (path.indexOf('panel') > -1) return 'panel';
        return 'inverter';
    }

    // ── Toast System ────────────────────────────────────────────────────
    function getToastContainer() {
        var c = document.getElementById('compare-toast-container');
        if (!c) {
            c = document.createElement('div');
            c.id = 'compare-toast-container';
            document.body.appendChild(c);
        }
        return c;
    }

    function showToast(message, type) {
        var container = getToastContainer();
        var toast = document.createElement('div');
        toast.className = 'compare-toast' + (type === 'warning' ? ' warning' : '');
        toast.textContent = message;
        container.appendChild(toast);

        // Trigger reflow then show
        toast.offsetHeight; // eslint-disable-line no-unused-expressions
        toast.className += ' visible';

        var id = ++toastCounter;
        toastStack.push(id);

        setTimeout(function() {
            toast.className = toast.className.replace(' visible', '');
            setTimeout(function() {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 400);
        }, TOAST_DURATION);
    }

    // ── Build DOM ───────────────────────────────────────────────────────
    var fabEl, badgeEl, panelEl;

    function buildDOM() {
        // Toast container
        getToastContainer();

        // FAB
        fabEl = document.createElement('button');
        fabEl.id = 'compare-fab';
        fabEl.type = 'button';
        fabEl.setAttribute('aria-label', 'Compare items');
        fabEl.innerHTML = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">' +
            '<path d="M12 2L9 7H3l5 4.5L6 17l6-4 6 4-2-5.5L21 7h-6L12 2z' +
            'M4 20h7v2H4v-2zm9 0h7v2h-7v-2z"/>' +
            '</svg>' +
            '<span id="compare-fab-badge"></span>';
        fabEl.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            togglePanel();
        });
        document.body.appendChild(fabEl);

        badgeEl = document.getElementById('compare-fab-badge');

        // Panel
        panelEl = document.createElement('div');
        panelEl.id = 'compare-panel';
        panelEl.addEventListener('click', function(e) {
            e.stopPropagation();
        });
        document.body.appendChild(panelEl);

        // Click outside to close
        document.addEventListener('click', function(e) {
            if (panelOpen && !panelEl.contains(e.target) && !fabEl.contains(e.target)) {
                closePanel();
            }
        });
    }

    // ── Panel Toggle ────────────────────────────────────────────────────
    function togglePanel() {
        if (panelOpen) {
            closePanel();
        } else {
            openPanel();
        }
    }

    function openPanel() {
        panelOpen = true;
        renderPanel();
        panelEl.className = 'open';
    }

    function closePanel() {
        panelOpen = false;
        panelEl.className = '';
    }

    // ── Pulse FAB ───────────────────────────────────────────────────────
    function pulseFab() {
        fabEl.className = 'pulse';
        setTimeout(function() {
            fabEl.className = '';
        }, 600);
    }

    // ── Render ──────────────────────────────────────────────────────────
    function updateBadge() {
        var type = getPageType();
        var count = storage[type].length;
        if (count > 0) {
            badgeEl.textContent = count;
            badgeEl.className = 'visible';
        } else {
            badgeEl.className = '';
        }

        // Update external sidebar count if present
        var countEl = document.getElementById('compare-count');
        if (countEl) {
            countEl.textContent = count;
        }
    }

    function renderPanel() {
        var type = getPageType();
        var items = storage[type];
        var count = items.length;
        var label = type.charAt(0).toUpperCase() + type.slice(1);
        var icon = type === 'inverter' ? '⚡' : (type === 'battery' ? '🔋' : '☀️');

        var html = '';

        // Header
        html += '<div id="compare-panel-header">' +
                    icon + ' Compare ' + label + 's (' + count + '/' + MAX_ITEMS + ')' +
                '</div>';

        // Body
        html += '<div id="compare-panel-body">';
        if (count === 0) {
            html += '<div class="compare-empty">No items selected.<br>Add items from the listing page.</div>';
        } else {
            for (var i = 0; i < items.length; i++) {
                html += '<div class="compare-item">' +
                            '<span class="compare-item-name">' + (i + 1) + '. ' + escapeHtml(items[i].name) + '</span>' +
                            '<button type="button" class="compare-item-remove" data-id="' + items[i].id + '" data-type="' + type + '" aria-label="Remove">&times;</button>' +
                        '</div>';
            }
        }
        html += '</div>';

        // Footer
        if (count > 0) {
            html += '<div id="compare-panel-footer">' +
                        '<button type="button" id="compare-now-btn"' + (count < 2 ? ' disabled' : '') + '>Compare Now</button>' +
                        '<button type="button" id="compare-clear-btn">Clear All</button>' +
                    '</div>';
        }

        panelEl.innerHTML = html;

        // Bind remove buttons
        var removeBtns = panelEl.querySelectorAll('.compare-item-remove');
        for (var j = 0; j < removeBtns.length; j++) {
            (function(btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var rid = parseInt(btn.getAttribute('data-id'));
                    var rtype = btn.getAttribute('data-type');
                    window.removeFromCompare(rid, rtype);
                });
            })(removeBtns[j]);
        }

        // Compare Now
        var compareBtn = document.getElementById('compare-now-btn');
        if (compareBtn) {
            compareBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                window.viewComparison(type);
            });
        }

        // Clear All
        var clearBtn = document.getElementById('compare-clear-btn');
        if (clearBtn) {
            clearBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                window.clearComparison(type);
            });
        }
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    function updateWidget() {
        if (document.readyState === 'unloading') return;
        updateBadge();
        if (panelOpen) {
            renderPanel();
        }
    }

    // ── Public API ──────────────────────────────────────────────────────

    window.addToCompare = function(id, type, name) {
        if (typeof event !== 'undefined' && event) {
            event.preventDefault();
            event.stopPropagation();
        }

        id = parseInt(id);
        if (!type) type = getPageType();

        if (!name || name === 'undefined' || name === 'null') {
            name = type.charAt(0).toUpperCase() + type.slice(1) + ' #' + id;
        }

        // Check duplicate
        for (var i = 0; i < storage[type].length; i++) {
            if (storage[type][i].id === id) {
                showToast('Already in comparison!', 'warning');
                return false;
            }
        }

        // Check max
        if (storage[type].length >= MAX_ITEMS) {
            showToast('Maximum ' + MAX_ITEMS + ' items. Remove one first.', 'warning');
            return false;
        }

        storage[type].push({ id: id, name: name });
        saveStorage();
        updateWidget();
        pulseFab();

        showToast('Added to compare! (' + storage[type].length + '/' + MAX_ITEMS + ')');

        return false;
    };

    window.removeFromCompare = function(id, type) {
        if (typeof event !== 'undefined' && event) {
            event.preventDefault();
            event.stopPropagation();
        }

        id = parseInt(id);
        if (!type) type = getPageType();

        storage[type] = storage[type].filter(function(item) {
            return item.id !== id;
        });
        saveStorage();
        updateWidget();

        return false;
    };

    window.clearComparison = function(type) {
        if (typeof event !== 'undefined' && event) {
            event.preventDefault();
            event.stopPropagation();
        }

        if (type) {
            storage[type] = [];
        } else {
            storage = { inverter: [], battery: [], panel: [] };
        }
        saveStorage();
        updateWidget();

        return false;
    };

    window.viewComparison = function(type) {
        if (typeof event !== 'undefined' && event) {
            event.preventDefault();
            event.stopPropagation();
        }

        if (!type) type = getPageType();
        var items = storage[type];

        if (items.length < 2) {
            showToast('Add at least 2 items to compare', 'warning');
            return false;
        }

        var ids = items.map(function(item) { return item.id; }).join(',');
        window.location.href = 'compare.php?type=' + type + '&ids=' + ids;
        return false;
    };

    window.isInCompare = function(id, type) {
        id = parseInt(id);
        if (!type) type = getPageType();
        for (var i = 0; i < storage[type].length; i++) {
            if (storage[type][i].id === id) return true;
        }
        return false;
    };

    window.toggleCompare = function(id, type, name) {
        id = parseInt(id);
        if (!type) type = getPageType();
        if (window.isInCompare(id, type)) {
            window.removeFromCompare(id, type);
        } else {
            window.addToCompare(id, type, name);
        }
    };

    // ── Init ────────────────────────────────────────────────────────────
    function init() {
        injectStyles();
        loadStorage();
        buildDOM();
        updateWidget();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
