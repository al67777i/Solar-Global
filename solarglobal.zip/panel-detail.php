<?php
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/location_helper.php';
require_once 'includes/subscription_helpers.php';
set_security_headers();

// Track visitor
trackVisitor($pdo);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: panels.php');
    exit;
}

// ─── Get panel details ─────────────────────────────────────────────────────
$stmt = $pdo->prepare("
    SELECT p.*, c.name as company_name, c.country, c.description as company_description,
           c.logo_path as company_logo, c.website as company_website, c.slug as company_slug
    FROM panels p
    JOIN companies c ON p.company_id = c.id
    WHERE p.id = ? AND p.is_active = 1
");
$stmt->execute([$id]);
$panel = $stmt->fetch();

if (!$panel) {
    header('Location: panels.php');
    exit;
}

// ─── Country flag (prefer country_origin, fallback to company country) ─────
$origin_or_company = !empty($panel['country_origin']) ? $panel['country_origin'] : $panel['country'];
$flag_emoji = '';
if ($origin_or_company) {
    $fStmt = $pdo->prepare("
        SELECT flag_emoji, flag_icon, code FROM countries
        WHERE LOWER(name COLLATE utf8mb4_general_ci) = LOWER(?)
           OR LOWER(code COLLATE utf8mb4_general_ci) = LOWER(?)
        LIMIT 1
    ");
    $fStmt->execute([$origin_or_company, $origin_or_company]);
    $fRow = $fStmt->fetch();
    if ($fRow) $flag_emoji = $fRow['flag_emoji'];
}

// ─── User currency (cookie → detect_user_country → get_country_currency_info) ─
$user_cc = '';
$loc = json_decode($_COOKIE['sg_location'] ?? '{}', true);
if (!empty($loc['country_code'])) {
    $user_cc = $loc['country_code'];
} else {
    $detected = detect_user_country();
    if ($detected) $user_cc = $detected;
}
$currency_info   = get_country_currency_info($user_cc);
$currency_symbol = $currency_info['currency_symbol'];
$currency_code   = $currency_info['currency_code'];
$exchange_rate   = max(0.001, $currency_info['exchange_rate']);

$local_price = round($panel['price_usd'] * $exchange_rate);

// ─── Price per watt ───────────────────────────────────────────────────────
$price_per_watt = ($panel['wattage'] > 0 && $panel['price_usd'] > 0)
    ? round($panel['price_usd'] / $panel['wattage'], 3)
    : 0;

// ─── Similar panels ────────────────────────────────────────────────────────
$wattage_min = $panel['wattage'] * 0.70;
$wattage_max = $panel['wattage'] * 1.30;
$simStmt = $pdo->prepare("
    SELECT p.*, c.name as company_name
    FROM panels p
    JOIN companies c ON p.company_id = c.id
    WHERE p.id != ?
      AND p.panel_type = ?
      AND p.wattage BETWEEN ? AND ?
      AND p.is_active = 1
    ORDER BY ABS(p.price_usd - ?) ASC
    LIMIT 4
");
$simStmt->execute([$id, $panel['panel_type'], $wattage_min, $wattage_max, $panel['price_usd']]);
$similar = $simStmt->fetchAll();

// ─── Where to Buy: nearby dealers ─────────────────────────────────────────
$dealers      = [];
$user_lat     = null;
$user_lng     = null;
$location_set = false;

if (!empty($loc['lat']) && !empty($loc['lng'])) {
    $user_lat     = (float)$loc['lat'];
    $user_lng     = (float)$loc['lng'];
    $location_set = true;
}

$sub_filter = get_dealer_subscription_filter('d');

if ($location_set) {
    $haversine  = haversine_sql('d.latitude', 'd.longitude');

    $dStmt = $pdo->prepare("
        SELECT d.id, d.business_name, d.city, d.country_code, dp.dealer_price,
               {$haversine} AS distance_km
        FROM dealer_products dp
        JOIN dealers d ON dp.dealer_id = d.id
        WHERE dp.product_type = 'panel' AND dp.product_id = ? AND dp.is_active = 1
          AND d.latitude IS NOT NULL AND d.longitude IS NOT NULL
          AND {$sub_filter}
        ORDER BY distance_km ASC
        LIMIT 10
    ");
    $dStmt->execute([$user_lat, $user_lng, $user_lat, $id]);
    $dealers = $dStmt->fetchAll();
}

// Country-based fallback when no coordinates available
if (empty($dealers) && !empty($user_cc)) {
    $dStmt = $pdo->prepare("
        SELECT d.id, d.business_name, d.city, d.country_code, dp.dealer_price,
               NULL AS distance_km
        FROM dealer_products dp
        JOIN dealers d ON dp.dealer_id = d.id
        WHERE dp.product_type = 'panel' AND dp.product_id = ? AND dp.is_active = 1
          AND d.country_code = ?
          AND {$sub_filter}
        ORDER BY dp.dealer_price ASC
        LIMIT 10
    ");
    $dStmt->execute([$id, $user_cc]);
    $dealers = $dStmt->fetchAll();
}

// ─── SEO ──────────────────────────────────────────────────────────────────
$panel_type_label = !empty($panel['panel_type']) ? ucfirst($panel['panel_type']) : 'Solar';
$site_name = get_system_setting('site_name', 'SolarGlobal');
$page_title       = $panel['name'] . " - " . $panel['company_name'] . " | " . $site_name;
$page_description = $panel['name'] . " — " . $panel['wattage'] . "W " . $panel_type_label . " solar panel. Efficiency: " . $panel['efficiency'] . "%. Warranty: " . ($panel['warranty_years'] ?? 25) . " years. Price: $" . number_format($panel['price_usd']) . " USD.";
$page_keywords    = $panel['name'] . ", " . $panel['company_name'] . " panel, " . $panel_type_label . " solar panel, solar panel";
$current_page     = 'panels';
$page_og_type     = 'product';

// ─── Badge CSS class by panel type ────────────────────────────────────────
$panel_type_lower = strtolower(str_replace(['-', ' '], '', $panel['panel_type'] ?? 'monocrystalline'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0D3B6E">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="mobile-web-app-capable" content="yes">
    <title><?php echo htmlspecialchars($page_title); ?></title>

    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo htmlspecialchars($page_description); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($page_keywords); ?>">
    <meta name="author" content="<?= htmlspecialchars($site_name) ?>">
    <meta name="robots" content="index, follow">

    <!-- Open Graph -->
    <meta property="og:title" content="<?php echo htmlspecialchars($page_title); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($page_description); ?>">
    <meta property="og:url" content="<?php echo htmlspecialchars(getCurrentUrl()); ?>">
    <meta property="og:type" content="product">
    <?php if (!empty($panel['image_path'])): ?>
    <meta property="og:image" content="<?php echo htmlspecialchars(get_image_url($panel['image_path'])); ?>">
    <?php endif; ?>

    <!-- Canonical URL -->
    <link rel="canonical" href="<?php echo htmlspecialchars(getCurrentUrl()); ?>">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/frontend.css">
    <link rel="stylesheet" href="assets/css/products.css">
    <link rel="stylesheet" href="assets/css/mobile-app.css">

    <!-- JSON-LD Product Schema -->
    <?php $baseUrl = 'https://' . ($_SERVER['HTTP_HOST'] ?? (get_system_setting('site_domain', 'solarglobal.com') ?: 'solarglobal.com')) . BASE_URL; ?>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": <?php echo json_encode($panel['name']); ?>,
        "url": <?php echo json_encode($baseUrl . 'panel-detail.php?id=' . (int)$panel['id']); ?>,
        "description": <?php echo json_encode(strip_tags($page_description)); ?>,
        "brand": {
            "@type": "Brand",
            "name": <?php echo json_encode($panel['company_name']); ?>
        },
        <?php if (!empty($panel['image_path'])): ?>
        "image": <?php echo json_encode('https://' . ($_SERVER['HTTP_HOST'] ?? '') . get_image_url($panel['image_path'])); ?>,
        <?php endif; ?>
        "offers": {
            "@type": "Offer",
            "price": "<?php echo (float)$panel['price_usd']; ?>",
            "priceCurrency": "USD",
            "availability": "https://schema.org/InStock"
        },
        "additionalProperty": [
            {"@type":"PropertyValue","name":"Wattage","value":"<?php echo (int)$panel['wattage']; ?>W"},
            {"@type":"PropertyValue","name":"Panel Type","value":"<?php echo htmlspecialchars($panel['panel_type'] ?? 'Monocrystalline'); ?>"},
            {"@type":"PropertyValue","name":"Efficiency","value":"<?php echo htmlspecialchars($panel['efficiency'] ?? ''); ?>%"},
            {"@type":"PropertyValue","name":"Warranty","value":"<?php echo (int)($panel['warranty_years'] ?? 25); ?> years"}
        ]
    }
    </script>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "Home", "item": "<?= $baseUrl ?>"},
            {"@type": "ListItem", "position": 2, "name": "Solar Panels", "item": "<?= $baseUrl ?>panels.php"},
            {"@type": "ListItem", "position": 3, "name": "<?= sanitize($panel['name']) ?>"}
        ]
    }
    </script>

    <style>
    /* ── Page Layout ─────────────────────────────────────── */
    body { background: #F8FAFC; }

    .pd-wrap {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px 80px;
    }

    /* ── Breadcrumb ──────────────────────────────────────── */
    .pd-breadcrumb {
        background: #F8FAFC;
        border-bottom: 1px solid #E2E8F0;
        padding: 14px 0;
        font-size: 0.875rem;
    }
    .pd-breadcrumb .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }
    .pd-breadcrumb a { color: #1565C0; text-decoration: none; }
    .pd-breadcrumb a:hover { text-decoration: underline; }
    .pd-breadcrumb span { color: #64748B; }

    /* ── Hero Section ────────────────────────────────────── */
    .pd-hero {
        background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%);
        padding: 40px 0 44px;
    }
    .pd-hero-inner {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
        display: grid;
        grid-template-columns: 280px 1fr;
        gap: 40px;
        align-items: start;
    }

    /* Image panel */
    .pd-hero-image {
        background: rgba(255,255,255,0.06);
        border: 1px solid rgba(255,255,255,0.10);
        border-radius: 16px;
        aspect-ratio: 4/3;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }
    .pd-hero-image img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        padding: 16px;
    }
    .pd-hero-image .panel-icon-fallback {
        font-size: 5rem;
        opacity: 0.5;
    }

    /* Info panel */
    .pd-hero-info {}

    .pd-company-line {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
    }
    .pd-company-name {
        color: #94A3B8;
        font-size: 0.9rem;
        font-weight: 500;
    }
    .pd-flag { font-size: 1.2rem; }

    .pd-hero-info h1 {
        font-size: 2rem;
        font-weight: 800;
        color: #fff;
        margin: 0 0 16px;
        line-height: 1.2;
    }

    /* Price display */
    .pd-price-block { margin-bottom: 20px; }
    .pd-price-main {
        font-size: 2.2rem;
        font-weight: 800;
        color: #F59E0B;
        display: flex;
        align-items: baseline;
        gap: 10px;
        flex-wrap: wrap;
    }
    .pd-price-usd {
        font-size: 0.95rem;
        font-weight: 500;
        color: #64748B;
    }
    .pd-price-pw {
        font-size: 0.85rem;
        color: #94A3B8;
        margin-top: 4px;
    }

    /* Key spec pills */
    .pd-spec-pills {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-bottom: 18px;
    }
    .pd-spec-pill {
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.12);
        border-radius: 50px;
        padding: 6px 16px;
        display: flex;
        flex-direction: column;
        align-items: center;
        min-width: 80px;
    }
    .pd-spec-pill-label {
        font-size: 0.68rem;
        color: #64748B;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        margin-bottom: 2px;
    }
    .pd-spec-pill-value {
        font-size: 0.95rem;
        font-weight: 700;
        color: #F1F5F9;
    }

    /* Feature tags */
    .pd-feature-tags {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 24px;
    }
    .pd-feature-tag {
        background: rgba(255,255,255,0.06);
        border: 1px solid rgba(255,255,255,0.10);
        color: #CBD5E1;
        font-size: 0.78rem;
        padding: 4px 12px;
        border-radius: 6px;
        font-weight: 500;
    }
    .pd-feature-tag.high-eff {
        background: rgba(5,150,105,0.20);
        border-color: rgba(5,150,105,0.40);
        color: #34D399;
        font-weight: 700;
    }

    /* Panel type badge */
    .pd-type-badge {
        display: inline-block;
        font-size: 0.75rem;
        font-weight: 700;
        padding: 4px 14px;
        border-radius: 20px;
        margin-bottom: 10px;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        background: #475569;
        color: #fff;
    }
    .pd-type-badge.monocrystalline { background: #1D4ED8; color: #fff; }
    .pd-type-badge.polycrystalline { background: #059669; color: #fff; }
    .pd-type-badge.thinfilm        { background: #7C3AED; color: #fff; }
    .pd-type-badge.bifacial        { background: #0EA5E9; color: #fff; }

    /* Hero CTA buttons */
    .pd-hero-actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }
    .pd-btn-primary {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 24px;
        background: linear-gradient(135deg, #F59E0B, #D97706);
        color: #fff;
        border-radius: 10px;
        font-weight: 700;
        font-size: 0.9rem;
        text-decoration: none;
        border: none;
        cursor: pointer;
        transition: opacity 0.2s, transform 0.15s;
        box-shadow: 0 4px 15px rgba(245,158,11,0.35);
    }
    .pd-btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
    .pd-btn-secondary {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 24px;
        background: rgba(255,255,255,0.08);
        color: #F1F5F9;
        border-radius: 10px;
        font-weight: 600;
        font-size: 0.9rem;
        text-decoration: none;
        border: 1px solid rgba(255,255,255,0.15);
        cursor: pointer;
        transition: background 0.2s;
    }
    .pd-btn-secondary:hover { background: rgba(255,255,255,0.14); }

    /* ── Tabs ─────────────────────────────────────────────── */
    .pd-tabs-section {
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.06);
        margin-top: 28px;
        overflow: hidden;
    }
    .pd-tab-buttons {
        display: flex;
        border-bottom: 2px solid #E2E8F0;
        overflow-x: auto;
        scrollbar-width: none;
    }
    .pd-tab-buttons::-webkit-scrollbar { display: none; }
    .pd-tab-btn {
        flex-shrink: 0;
        padding: 16px 24px;
        font-size: 0.9rem;
        font-weight: 600;
        color: #64748B;
        background: none;
        border: none;
        border-bottom: 3px solid transparent;
        cursor: pointer;
        transition: color 0.2s, border-color 0.2s;
        margin-bottom: -2px;
    }
    .pd-tab-btn:hover { color: #1E293B; }
    .pd-tab-btn.active { color: #F59E0B; border-bottom-color: #F59E0B; }

    .pd-tab-content { display: none; padding: 32px; }
    .pd-tab-content.active { display: block; }

    /* ── Specs Table ─────────────────────────────────────── */
    .pd-specs-table { width: 100%; border-collapse: collapse; }
    .pd-specs-table tr { border-bottom: 1px solid #F1F5F9; }
    .pd-specs-table tr:last-child { border-bottom: none; }
    .pd-specs-table td {
        padding: 12px 16px;
        font-size: 0.925rem;
        vertical-align: top;
    }
    .pd-specs-table td:first-child {
        width: 40%;
        color: #64748B;
        font-weight: 500;
    }
    .pd-specs-table td:last-child {
        color: #1E293B;
        font-weight: 600;
    }
    .pd-specs-table tr:hover { background: #FAFBFC; }

    /* ── Features List ───────────────────────────────────── */
    .pd-features-list {
        list-style: none;
        padding: 0;
        margin: 0;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
    }
    .pd-features-list li {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 14px 16px;
        background: #F8FAFC;
        border-radius: 10px;
        border: 1px solid #E2E8F0;
        font-size: 0.9rem;
        color: #374151;
        line-height: 1.5;
    }
    .pd-features-list li .feat-icon {
        color: #10B981;
        font-size: 1rem;
        flex-shrink: 0;
        margin-top: 1px;
    }

    /* ── Where to Buy ────────────────────────────────────── */
    .pd-dealers-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 16px;
    }
    .pd-dealer-card {
        background: #F8FAFC;
        border: 1.5px solid #E2E8F0;
        border-radius: 12px;
        padding: 18px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        transition: border-color 0.2s, box-shadow 0.2s;
    }
    .pd-dealer-card:hover {
        border-color: #F59E0B;
        box-shadow: 0 4px 16px rgba(245,158,11,0.10);
    }
    .pd-dealer-card-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 10px;
    }
    .pd-dealer-name {
        font-size: 1rem;
        font-weight: 700;
        color: #1E293B;
    }
    .pd-dealer-city {
        font-size: 0.8rem;
        color: #64748B;
        margin-top: 2px;
    }
    .pd-distance-badge {
        background: #FEF3C7;
        color: #92400E;
        border: 1px solid #FDE68A;
        font-size: 0.75rem;
        font-weight: 700;
        padding: 3px 10px;
        border-radius: 20px;
        white-space: nowrap;
        flex-shrink: 0;
    }
    .pd-dealer-price {
        font-size: 1.15rem;
        font-weight: 800;
        color: #F59E0B;
    }
    .pd-dealer-price-usd {
        font-size: 0.75rem;
        color: #94A3B8;
        margin-top: 2px;
    }
    .pd-visit-store-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 10px 18px;
        background: linear-gradient(135deg, #F59E0B, #D97706);
        color: #fff;
        border-radius: 8px;
        font-weight: 700;
        font-size: 0.85rem;
        text-decoration: none;
        transition: opacity 0.2s;
    }
    .pd-visit-store-btn:hover { opacity: 0.88; }

    .pd-no-dealers {
        text-align: center;
        padding: 40px 20px;
        color: #64748B;
    }
    .pd-no-dealers-icon { font-size: 2.5rem; margin-bottom: 10px; }
    .pd-no-dealers h4 { color: #1E293B; margin: 0 0 8px; font-size: 1rem; }
    .pd-no-dealers p { font-size: 0.875rem; margin: 0; }

    /* ── About Brand ─────────────────────────────────────── */
    .pd-brand-section { display: flex; gap: 28px; align-items: flex-start; }
    .pd-brand-logo {
        width: 80px;
        height: 80px;
        border-radius: 14px;
        background: #F1F5F9;
        border: 1px solid #E2E8F0;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    .pd-brand-logo img { width: 100%; height: 100%; object-fit: contain; padding: 8px; }
    .pd-brand-logo .brand-icon { font-size: 2.5rem; }
    .pd-brand-info h3 { font-size: 1.3rem; font-weight: 800; color: #1E293B; margin: 0 0 6px; }
    .pd-brand-info .brand-country { font-size: 0.875rem; color: #64748B; margin-bottom: 14px; display: flex; align-items: center; gap: 6px; }
    .pd-brand-info p { font-size: 0.925rem; color: #475569; line-height: 1.75; margin: 0 0 16px; }

    /* ── Similar Panels ──────────────────────────────────── */
    .pd-similar-section { margin-top: 48px; }
    .pd-similar-section h2 {
        font-size: 1.6rem;
        font-weight: 800;
        color: #1E293B;
        margin: 0 0 20px;
    }
    .pd-similar-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
        gap: 18px;
    }
    .pd-similar-card {
        background: #fff;
        border: 1.5px solid #E2E8F0;
        border-radius: 14px;
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        transition: border-color 0.2s, box-shadow 0.2s, transform 0.15s;
    }
    .pd-similar-card:hover {
        border-color: #F59E0B;
        box-shadow: 0 6px 20px rgba(245,158,11,0.10);
        transform: translateY(-2px);
    }
    .pd-similar-badge {
        font-size: 0.72rem;
        font-weight: 700;
        padding: 3px 10px;
        border-radius: 20px;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.03em;
        align-self: flex-start;
        background: #F1F5F9;
        color: #475569;
    }
    .pd-similar-badge.monocrystalline { background: #DBEAFE; color: #1D4ED8; }
    .pd-similar-badge.polycrystalline { background: #D1FAE5; color: #065F46; }
    .pd-similar-badge.thinfilm        { background: #EDE9FE; color: #6D28D9; }
    .pd-similar-badge.bifacial        { background: #E0F2FE; color: #0369A1; }
    .pd-similar-company { font-size: 0.8rem; color: #64748B; font-weight: 500; }
    .pd-similar-name { font-size: 0.975rem; font-weight: 700; color: #1E293B; }
    .pd-similar-specs { display: flex; gap: 10px; flex-wrap: wrap; }
    .pd-similar-spec { font-size: 0.78rem; color: #64748B; background: #F1F5F9; padding: 3px 10px; border-radius: 6px; }
    .pd-similar-price { font-size: 1.15rem; font-weight: 800; color: #F59E0B; }
    .pd-similar-view {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 9px 16px;
        background: #F8FAFC;
        border: 1.5px solid #E2E8F0;
        color: #1E293B;
        border-radius: 8px;
        font-size: 0.85rem;
        font-weight: 600;
        text-decoration: none;
        transition: background 0.2s, border-color 0.2s;
    }
    .pd-similar-view:hover { background: #FEF3C7; border-color: #F59E0B; color: #D97706; }

    /* ── Currency Bar ────────────────────────────────────── */
    .pd-currency-bar {
        background: #FFFBEB;
        border-bottom: 1px solid #FDE68A;
        padding: 8px 0;
        font-size: 0.82rem;
    }
    .pd-currency-bar-inner {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
    }
    .pd-currency-badge {
        background: #F59E0B;
        color: #fff;
        padding: 3px 10px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 0.78rem;
    }

    /* ── Responsive ──────────────────────────────────────── */
    @media (max-width: 900px) {
        .pd-hero-inner { grid-template-columns: 1fr; }
        .pd-hero-image { max-width: 260px; margin: 0 auto; }
        .pd-hero-info h1 { font-size: 1.5rem; }
        .pd-price-main { font-size: 1.7rem; }
        .pd-tab-content { padding: 20px; }
        .pd-features-list { grid-template-columns: 1fr; }
        .pd-brand-section { flex-direction: column; }
    }
    @media (max-width: 600px) {
        .pd-spec-pills { gap: 8px; }
        .pd-spec-pill { min-width: 70px; padding: 5px 12px; }
        .pd-similar-grid { grid-template-columns: 1fr; }
    }
    </style>
</head>
<body>
    <?php include 'includes/header-nav.php'; ?>
    <?php include_once 'includes/ad_display.php'; ?>

    <?php renderAds('header'); ?>

    <!-- Currency Bar -->
    <div class="pd-currency-bar">
        <div class="pd-currency-bar-inner">
            <span style="color:#92400E;font-weight:500;">Prices shown in:</span>
            <span class="pd-currency-badge"><?php echo htmlspecialchars($currency_code); ?> (<?php echo htmlspecialchars($currency_symbol); ?>)</span>
        </div>
    </div>

    <!-- Breadcrumb -->
    <div class="pd-breadcrumb">
        <div class="container">
            <a href="<?php echo BASE_URL; ?>">Home</a> /&nbsp;
            <a href="<?php echo BASE_URL; ?>panels.php">Solar Panels</a> /&nbsp;
            <span><?php echo htmlspecialchars($panel['name']); ?></span>
        </div>
    </div>

    <!-- ══════════════════════════════════════════════════════
         HERO
    ══════════════════════════════════════════════════════ -->
    <div class="pd-hero">
        <div class="pd-hero-inner">

            <!-- Product Image -->
            <div class="pd-hero-image">
                <?php if (!empty($panel['image_path'])): ?>
                    <img src="<?php echo htmlspecialchars(get_image_url($panel['image_path'])); ?>"
                         alt="<?php echo htmlspecialchars($panel['name']); ?>" loading="eager">
                <?php else: ?>
                    <span class="panel-icon-fallback">&#9728;&#65039;</span>
                <?php endif; ?>
            </div>

            <!-- Product Info -->
            <div class="pd-hero-info">

                <!-- Panel type badge -->
                <?php
                    $badge_label = !empty($panel['panel_type']) ? ucfirst($panel['panel_type']) : 'Solar Panel';
                ?>
                <span class="pd-type-badge <?php echo htmlspecialchars($panel_type_lower); ?>">
                    <?php echo htmlspecialchars($badge_label); ?>
                </span>

                <!-- Company + Flag -->
                <div class="pd-company-line">
                    <?php if ($fRow || $flag_emoji): ?>
                        <span class="pd-flag"><?= get_country_flag($fRow ?? $origin_or_company, 20) ?></span>
                    <?php endif; ?>
                    <span class="pd-company-name"><?php echo htmlspecialchars($panel['company_name']); ?></span>
                    <?php if (!empty($panel['country'])): ?>
                        <span class="pd-company-name" style="color:#475569;">&bull; <?php echo htmlspecialchars($panel['country']); ?></span>
                    <?php endif; ?>
                </div>

                <!-- Panel Name -->
                <h1><?php echo htmlspecialchars($panel['name']); ?></h1>

                <!-- Price -->
                <div class="pd-price-block">
                    <div class="pd-price-main">
                        <span><?php echo htmlspecialchars($currency_symbol); ?><?php echo number_format($local_price); ?></span>
                        <?php if ($currency_code !== 'USD'): ?>
                            <span class="pd-price-usd">$<?php echo number_format($panel['price_usd']); ?> USD</span>
                        <?php endif; ?>
                    </div>
                    <?php if ($price_per_watt > 0): ?>
                        <div class="pd-price-pw">
                            $<?php echo number_format($price_per_watt, 3); ?>/W &nbsp;&bull;&nbsp;
                            <?php echo htmlspecialchars($currency_symbol); ?><?php echo number_format(round($price_per_watt * $exchange_rate, 3), 3); ?>/W local
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Key Spec Pills: Wattage | Panel Type | Efficiency | Voc | Warranty -->
                <div class="pd-spec-pills">
                    <div class="pd-spec-pill">
                        <span class="pd-spec-pill-label">Wattage</span>
                        <span class="pd-spec-pill-value"><?php echo number_format($panel['wattage']); ?>W</span>
                    </div>
                    <?php if (!empty($panel['panel_type'])): ?>
                    <div class="pd-spec-pill">
                        <span class="pd-spec-pill-label">Type</span>
                        <span class="pd-spec-pill-value"><?php echo htmlspecialchars(ucfirst($panel['panel_type'])); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($panel['efficiency'])): ?>
                    <div class="pd-spec-pill">
                        <span class="pd-spec-pill-label">Efficiency</span>
                        <span class="pd-spec-pill-value"><?php echo htmlspecialchars($panel['efficiency']); ?>%</span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($panel['voc'])): ?>
                    <div class="pd-spec-pill">
                        <span class="pd-spec-pill-label">Voc</span>
                        <span class="pd-spec-pill-value"><?php echo htmlspecialchars($panel['voc']); ?>V</span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($panel['warranty_years'])): ?>
                    <div class="pd-spec-pill">
                        <span class="pd-spec-pill-label">Warranty</span>
                        <span class="pd-spec-pill-value"><?php echo (int)$panel['warranty_years']; ?> yr</span>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Feature Tags -->
                <div class="pd-feature-tags">
                    <?php if (!empty($panel['efficiency']) && (float)$panel['efficiency'] > 21): ?>
                        <span class="pd-feature-tag high-eff">&#9889; High Efficiency (<?php echo htmlspecialchars($panel['efficiency']); ?>%)</span>
                    <?php endif; ?>
                    <?php if (!empty($panel['frame_color'])): ?>
                        <span class="pd-feature-tag"><?php echo htmlspecialchars($panel['frame_color']); ?> Frame</span>
                    <?php endif; ?>
                    <?php if (!empty($panel['cells_count'])): ?>
                        <span class="pd-feature-tag"><?php echo (int)$panel['cells_count']; ?> Cells</span>
                    <?php endif; ?>
                    <?php if (!empty($panel['max_system_voltage'])): ?>
                        <span class="pd-feature-tag"><?php echo htmlspecialchars($panel['max_system_voltage']); ?>V Max System</span>
                    <?php endif; ?>
                    <?php if (!empty($panel['backsheet_color'])): ?>
                        <span class="pd-feature-tag"><?php echo htmlspecialchars($panel['backsheet_color']); ?> Backsheet</span>
                    <?php endif; ?>
                    <?php if (!empty($panel['certifications'])): ?>
                        <span class="pd-feature-tag">&#10003; <?php echo htmlspecialchars($panel['certifications']); ?></span>
                    <?php endif; ?>
                </div>

                <!-- Action Buttons -->
                <div class="pd-hero-actions">
                    <a href="<?php echo BASE_URL; ?>contact.php" class="pd-btn-primary">
                        &#128222; Contact for Quote
                    </a>
                    <button type="button" class="pd-btn-secondary"
                        onclick="addToCompare(<?php echo (int)$panel['id']; ?>, 'panel', '<?php echo htmlspecialchars(addslashes($panel['name']), ENT_QUOTES); ?>'); return false;">
                        &#128202; Add to Compare
                    </button>
                </div>

            </div><!-- /.pd-hero-info -->
        </div><!-- /.pd-hero-inner -->
    </div><!-- /.pd-hero -->

    <!-- ══════════════════════════════════════════════════════
         TABS
    ══════════════════════════════════════════════════════ -->
    <div class="pd-wrap">
        <div class="pd-tabs-section">
            <div class="pd-tab-buttons">
                <button type="button" class="pd-tab-btn active" onclick="pdSwitchTab(this,'specifications')">Specifications</button>
                <button type="button" class="pd-tab-btn" onclick="pdSwitchTab(this,'features')">Features</button>
                <button type="button" class="pd-tab-btn" onclick="pdSwitchTab(this,'where-to-buy')">Where to Buy</button>
                <button type="button" class="pd-tab-btn" onclick="pdSwitchTab(this,'about-brand')">About Brand</button>
            </div>

            <!-- ── Specifications Tab ──────────────────────────────── -->
            <div id="tab-specifications" class="pd-tab-content active">
                <table class="pd-specs-table">
                    <tbody>
                        <tr><td>Model Name</td><td><?php echo htmlspecialchars($panel['name']); ?></td></tr>
                        <tr><td>Brand</td><td><?php echo htmlspecialchars($panel['company_name']); ?></td></tr>
                        <tr><td>Panel Type</td>
                            <td><span class="pd-similar-badge <?php echo htmlspecialchars($panel_type_lower); ?>"><?php echo htmlspecialchars(ucfirst($panel['panel_type'] ?? 'Monocrystalline')); ?></span></td>
                        </tr>
                        <tr><td>Wattage (Wp)</td><td><?php echo number_format($panel['wattage']); ?> W</td></tr>
                        <?php if (!empty($panel['voc'])): ?>
                        <tr><td>Voc (Open Circuit Voltage)</td><td><?php echo htmlspecialchars($panel['voc']); ?> V</td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['vmp'])): ?>
                        <tr><td>Vmp (Max Power Voltage)</td><td><?php echo htmlspecialchars($panel['vmp']); ?> V</td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['isc'])): ?>
                        <tr><td>Isc (Short Circuit Current)</td><td><?php echo htmlspecialchars($panel['isc']); ?> A</td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['efficiency'])): ?>
                        <tr><td>Efficiency</td><td><?php echo htmlspecialchars($panel['efficiency']); ?>%</td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['warranty_years'])): ?>
                        <tr><td>Warranty</td><td><?php echo (int)$panel['warranty_years']; ?> Years</td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['degradation_percent'])): ?>
                        <tr><td>Annual Degradation</td><td><?php echo htmlspecialchars($panel['degradation_percent']); ?>% per year</td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['temperature_coefficient'])): ?>
                        <tr><td>Temperature Coefficient (Pmax)</td><td><?php echo htmlspecialchars($panel['temperature_coefficient']); ?>%/&deg;C</td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['dimensions'])): ?>
                        <tr><td>Dimensions</td><td><?php echo htmlspecialchars($panel['dimensions']); ?> mm</td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['weight_kg'])): ?>
                        <tr><td>Weight</td><td><?php echo htmlspecialchars($panel['weight_kg']); ?> kg</td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['cells_count'])): ?>
                        <tr><td>Cells Count</td><td><?php echo (int)$panel['cells_count']; ?></td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['max_system_voltage'])): ?>
                        <tr><td>Max System Voltage</td><td><?php echo htmlspecialchars($panel['max_system_voltage']); ?> V</td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['operating_temp'])): ?>
                        <tr><td>Operating Temperature</td><td><?php echo htmlspecialchars($panel['operating_temp']); ?></td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['frame_color'])): ?>
                        <tr><td>Frame Color</td><td><?php echo htmlspecialchars($panel['frame_color']); ?></td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['backsheet_color'])): ?>
                        <tr><td>Backsheet Color</td><td><?php echo htmlspecialchars($panel['backsheet_color']); ?></td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['certifications'])): ?>
                        <tr><td>Certifications</td><td><?php echo htmlspecialchars($panel['certifications']); ?></td></tr>
                        <?php endif; ?>
                        <?php if (!empty($panel['country_origin'])): ?>
                        <tr><td>Country of Origin</td>
                            <td><?= ($fRow || $flag_emoji) ? get_country_flag($fRow ?? $origin_or_company, 20) . ' ' : '' ?><?php echo htmlspecialchars($panel['country_origin']); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if ($price_per_watt > 0): ?>
                        <tr><td>Price per Watt</td><td>$<?php echo number_format($price_per_watt, 3); ?> USD/W</td></tr>
                        <?php endif; ?>
                        <tr>
                            <td>Price</td>
                            <td>
                                <strong style="color:#F59E0B;font-size:1.2rem;">
                                    <?php echo htmlspecialchars($currency_symbol); ?><?php echo number_format($local_price); ?>
                                    <?php echo htmlspecialchars($currency_code); ?>
                                </strong>
                                <?php if ($currency_code !== 'USD'): ?>
                                    <br><span style="color:#94A3B8;font-size:0.8rem;">$<?php echo number_format($panel['price_usd']); ?> USD</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- ── Features Tab ────────────────────────────────────── -->
            <div id="tab-features" class="pd-tab-content">
                <h3 style="color:#1E293B;margin:0 0 20px;font-size:1.2rem;">Key Features</h3>
                <ul class="pd-features-list">
                    <li><span class="feat-icon">&#10003;</span>
                        <?php echo htmlspecialchars(ucfirst($panel['panel_type'] ?? 'Monocrystalline')); ?> solar panel technology
                    </li>
                    <li><span class="feat-icon">&#10003;</span>
                        <?php echo number_format($panel['wattage']); ?>W peak power output (Wp)
                    </li>
                    <?php if (!empty($panel['efficiency'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        <?php echo htmlspecialchars($panel['efficiency']); ?>% module conversion efficiency
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['warranty_years'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        <?php echo (int)$panel['warranty_years']; ?>-year product &amp; power output warranty
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['degradation_percent'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        Low degradation: only <?php echo htmlspecialchars($panel['degradation_percent']); ?>% per year
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['temperature_coefficient'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        Temperature coefficient: <?php echo htmlspecialchars($panel['temperature_coefficient']); ?>%/&deg;C (Pmax)
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['voc'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        Open circuit voltage (Voc): <?php echo htmlspecialchars($panel['voc']); ?>V
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['vmp'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        Maximum power voltage (Vmp): <?php echo htmlspecialchars($panel['vmp']); ?>V
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['cells_count'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        <?php echo (int)$panel['cells_count']; ?> high-grade solar cells
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['max_system_voltage'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        Max system voltage: <?php echo htmlspecialchars($panel['max_system_voltage']); ?>V
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['frame_color'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        <?php echo htmlspecialchars($panel['frame_color']); ?> anodized aluminium alloy frame
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['dimensions'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        Dimensions: <?php echo htmlspecialchars($panel['dimensions']); ?> mm
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['weight_kg'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        Lightweight: <?php echo htmlspecialchars($panel['weight_kg']); ?> kg
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['certifications'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        International certifications: <?php echo htmlspecialchars($panel['certifications']); ?>
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($panel['operating_temp'])): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        Operating temperature range: <?php echo htmlspecialchars($panel['operating_temp']); ?>
                    </li>
                    <?php endif; ?>
                    <?php if ($price_per_watt > 0): ?>
                    <li><span class="feat-icon">&#10003;</span>
                        Excellent value at $<?php echo number_format($price_per_watt, 3); ?> per watt
                    </li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- ── Where to Buy Tab ────────────────────────────────── -->
            <div id="tab-where-to-buy" class="pd-tab-content">
                <h3 style="color:#1E293B;margin:0 0 6px;font-size:1.2rem;">Nearby Dealers</h3>
                <p style="color:#64748B;font-size:0.875rem;margin:0 0 24px;">
                    Dealers closest to your location stocking this panel. Prices may vary by dealer.
                </p>

                <?php if (!$location_set): ?>
                    <div class="pd-no-dealers">
                        <div class="pd-no-dealers-icon">&#128205;</div>
                        <h4>Location not detected</h4>
                        <p>Allow location access on this site to see nearby dealers.</p>
                    </div>
                <?php elseif (empty($dealers)): ?>
                    <div class="pd-no-dealers">
                        <div class="pd-no-dealers-icon">&#127978;</div>
                        <h4>No nearby dealers found</h4>
                        <p>No dealers in your area currently stock this panel. Try <a href="<?php echo BASE_URL; ?>contact.php" style="color:#F59E0B;">contacting us</a> for a referral.</p>
                    </div>
                <?php else: ?>
                    <div class="pd-dealers-grid">
                        <?php foreach ($dealers as $dealer): ?>
                            <?php
                                $dealer_local = ($dealer['dealer_price'] > 0)
                                    ? round($dealer['dealer_price'] * $exchange_rate)
                                    : null;
                                $dist_km = isset($dealer['distance_km'])
                                    ? round((float)$dealer['distance_km'], 1)
                                    : null;
                            ?>
                            <div class="pd-dealer-card">
                                <div class="pd-dealer-card-header">
                                    <div>
                                        <div class="pd-dealer-name"><?php echo htmlspecialchars($dealer['business_name']); ?></div>
                                        <div class="pd-dealer-city">
                                            <?php echo htmlspecialchars($dealer['city'] ?? ''); ?>
                                            <?php if (!empty($dealer['country_code'])): ?>
                                                &bull; <?php echo htmlspecialchars(strtoupper($dealer['country_code'])); ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php if ($dist_km !== null): ?>
                                        <span class="pd-distance-badge">
                                            <?php echo number_format($dist_km, 1); ?> km
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <?php if ($dealer_local !== null): ?>
                                    <div>
                                        <div class="pd-dealer-price">
                                            <?php echo htmlspecialchars($currency_symbol); ?><?php echo number_format($dealer_local); ?>
                                            <span style="font-size:0.78rem;font-weight:500;color:#94A3B8;"><?php echo htmlspecialchars($currency_code); ?></span>
                                        </div>
                                        <?php if ($currency_code !== 'USD' && $dealer['dealer_price'] > 0): ?>
                                            <div class="pd-dealer-price-usd">$<?php echo number_format($dealer['dealer_price']); ?> USD</div>
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <div style="font-size:0.85rem;color:#94A3B8;">Price on request</div>
                                <?php endif; ?>

                                <a href="<?php echo BASE_URL; ?>store-detail.php?id=<?php echo (int)$dealer['id']; ?>"
                                   class="pd-visit-store-btn">
                                    &#127978; Visit Store &rarr;
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- ── About Brand Tab ─────────────────────────────────── -->
            <div id="tab-about-brand" class="pd-tab-content">
                <div class="pd-brand-section">
                    <div class="pd-brand-logo">
                        <?php if (!empty($panel['company_logo'])): ?>
                            <img src="<?php echo htmlspecialchars(get_image_url($panel['company_logo'])); ?>"
                                 alt="<?php echo htmlspecialchars($panel['company_name']); ?> logo" loading="lazy">
                        <?php else: ?>
                            <span class="brand-icon">&#9728;&#65039;</span>
                        <?php endif; ?>
                    </div>
                    <div class="pd-brand-info">
                        <h3><?php echo htmlspecialchars($panel['company_name']); ?></h3>
                        <div class="brand-country">
                            <?php if ($fRow || $flag_emoji): ?>
                                <span><?= get_country_flag($fRow ?? $origin_or_company, 20) ?></span>
                            <?php endif; ?>
                            <span><?php echo htmlspecialchars($panel['country'] ?? ''); ?></span>
                        </div>
                        <?php if (!empty($panel['company_description'])): ?>
                            <p><?php echo htmlspecialchars($panel['company_description']); ?></p>
                        <?php else: ?>
                            <p style="color:#94A3B8;font-style:italic;">No company description available.</p>
                        <?php endif; ?>
                        <?php if (!empty($panel['company_website'])): ?>
                            <a href="<?php echo htmlspecialchars($panel['company_website']); ?>"
                               target="_blank" rel="noopener noreferrer"
                               style="display:inline-flex;align-items:center;gap:6px;color:#F59E0B;font-weight:600;font-size:0.9rem;text-decoration:none;">
                                &#127760; Visit Official Website &rarr;
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div><!-- /.pd-tabs-section -->

        <!-- ══════════════════════════════════════════════════════
             SIMILAR PANELS
        ══════════════════════════════════════════════════════ -->
        <?php if (!empty($similar)): ?>
        <div class="pd-similar-section">
            <h2>Similar Panels</h2>
            <div class="pd-similar-grid">
                <?php foreach ($similar as $sim):
                    $sim_local     = round($sim['price_usd'] * $exchange_rate);
                    $sim_type_low  = strtolower(str_replace(['-', ' '], '', $sim['panel_type'] ?? ''));
                    $sim_ppw       = ($sim['wattage'] > 0 && $sim['price_usd'] > 0)
                                        ? round($sim['price_usd'] / $sim['wattage'], 2)
                                        : 0;
                ?>
                <div class="pd-similar-card">
                    <span class="pd-similar-badge <?php echo htmlspecialchars($sim_type_low); ?>">
                        <?php echo htmlspecialchars(ucfirst($sim['panel_type'] ?? 'Solar')); ?>
                    </span>
                    <div class="pd-similar-company"><?php echo htmlspecialchars($sim['company_name']); ?></div>
                    <div class="pd-similar-name"><?php echo htmlspecialchars($sim['name']); ?></div>
                    <div class="pd-similar-specs">
                        <span class="pd-similar-spec"><?php echo number_format($sim['wattage']); ?>W</span>
                        <?php if (!empty($sim['efficiency'])): ?>
                            <span class="pd-similar-spec"><?php echo htmlspecialchars($sim['efficiency']); ?>% eff</span>
                        <?php endif; ?>
                        <?php if ($sim_ppw > 0): ?>
                            <span class="pd-similar-spec">$<?php echo number_format($sim_ppw, 2); ?>/W</span>
                        <?php endif; ?>
                    </div>
                    <div class="pd-similar-price">
                        <?php echo htmlspecialchars($currency_symbol); ?><?php echo number_format($sim_local); ?>
                        <?php if ($currency_code !== 'USD'): ?>
                            <span style="font-size:0.75rem;font-weight:500;color:#94A3B8;"> ($<?php echo number_format($sim['price_usd']); ?> USD)</span>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo BASE_URL; ?>panel-detail.php?id=<?php echo (int)$sim['id']; ?>"
                       class="pd-similar-view">View Details &rarr;</a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </div><!-- /.pd-wrap -->

    <?php renderAds('footer'); ?>

    <?php include 'includes/footer.php'; ?>

    <script src="assets/js/products.js"></script>
    <script>
    // ── Tab switcher ──────────────────────────────────────────────────────
    function pdSwitchTab(btn, tabId) {
        document.querySelectorAll('.pd-tab-content').forEach(function(el) {
            el.classList.remove('active');
        });
        document.querySelectorAll('.pd-tab-btn').forEach(function(b) {
            b.classList.remove('active');
        });
        var target = document.getElementById('tab-' + tabId);
        if (target) target.classList.add('active');
        btn.classList.add('active');
    }
    </script>
</body>
</html>
