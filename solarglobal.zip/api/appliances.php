<?php
/**
 * API: Get Active Appliances (Country + Season aware)
 * Returns JSON with smart seasonal intelligence
 *
 * Params:
 *   city_id   - optional city ID for temperature-based recommendations
 *   country   - optional ISO 2-letter code (PK, US, IN, etc.)
 *   seasonal  - flag to include seasonal recommendations
 */
header('Content-Type: application/json; charset=utf-8');
require_once '../includes/db.php';
require_once '../includes/helpers.php';
require_once '../includes/city_helper.php';

set_security_headers();

if (!rate_limit('api_appliances', 30, 60)) { respond_rate_limited(); }

try {
    $db = getDB();
    $cityId = (int)($_GET['city_id'] ?? 0);
    $countryCode = strtoupper(trim($_GET['country'] ?? ''));
    $withSeasonal = isset($_GET['seasonal']);

    // Build query — select all active appliances
    $stmt = $db->prepare("
        SELECT id, name_en, icon, image_path, watt_typical, category,
               season_tags, usage_hours_summer, usage_hours_winter,
               surge_load_watts, standby_watts, country_codes,
               voltage_system, is_inverter_type, min_watt, priority_order
        FROM appliances
        WHERE is_active = 1
        ORDER BY priority_order ASC, category ASC, name_en ASC
    ");
    $stmt->execute();
    $allAppliances = $stmt->fetchAll();

    // Filter by country if provided
    $appliances = [];
    foreach ($allAppliances as $row) {
        $codes = strtoupper(trim($row['country_codes'] ?? 'global'));

        if ($countryCode && $codes !== 'GLOBAL') {
            // Check if this appliance is for the user's country
            $codeList = array_map('trim', explode(',', $codes));
            if (!in_array($countryCode, $codeList)) {
                continue; // Skip — not for this country
            }
        }
        $appliances[] = $row;
    }

    // Determine current season
    $season = getCurrentSeason();
    $temperature = null;

    // If city provided, get temperature for smarter recommendations
    if ($cityId) {
        $sunData = getSunDataForCity($cityId, (int)date('n'));
        if ($sunData) {
            $temperature = (float)$sunData['avg_temperature_c'];
        }
    }

    foreach ($appliances as &$appliance) {
        $appliance['id'] = (int)$appliance['id'];
        $appliance['watt_typical'] = (int)$appliance['watt_typical'];
        $appliance['surge_load_watts'] = (int)($appliance['surge_load_watts'] ?? 0);
        $appliance['standby_watts'] = (int)($appliance['standby_watts'] ?? 0);
        $appliance['usage_hours_summer'] = (float)($appliance['usage_hours_summer'] ?? 4);
        $appliance['usage_hours_winter'] = (float)($appliance['usage_hours_winter'] ?? 4);
        $appliance['is_inverter_type'] = (int)($appliance['is_inverter_type'] ?? 0);
        $appliance['min_watt'] = (int)($appliance['min_watt'] ?? 0);
        $appliance['voltage_system'] = (int)($appliance['voltage_system'] ?? 220);
        $appliance['priority_order'] = (int)($appliance['priority_order'] ?? 50);

        // Fix image paths
        if (!empty($appliance['image_path'])) {
            if (strpos($appliance['image_path'], 'uploads/') !== 0) {
                $appliance['image_path'] = str_replace('../', '', $appliance['image_path']);
                if (strpos($appliance['image_path'], 'uploads/') !== 0) {
                    $appliance['image_path'] = 'uploads/' . $appliance['image_path'];
                }
            }
        }

        // Calculate seasonal relevance
        $seasonTags = explode(',', $appliance['season_tags'] ?? 'all_year');
        $isSeasonRelevant = in_array('all_year', $seasonTags) || in_array($season, $seasonTags);

        // Smart recommendation logic
        $recommendation = 'normal';
        $reasonEn = '';

        if ($temperature !== null) {
            if ($temperature >= 35 && in_array('summer', $seasonTags)) {
                $recommendation = 'highly_recommended';
                $reasonEn = 'Essential in current hot weather';
            } elseif ($temperature >= 30 && in_array('summer', $seasonTags)) {
                $recommendation = 'recommended';
                $reasonEn = 'Good for warm weather';
            } elseif ($temperature <= 10 && in_array('winter', $seasonTags)) {
                $recommendation = 'highly_recommended';
                $reasonEn = 'Essential in current cold weather';
            } elseif ($temperature <= 18 && in_array('winter', $seasonTags)) {
                $recommendation = 'recommended';
                $reasonEn = 'Recommended for cool weather';
            } elseif (!$isSeasonRelevant) {
                $recommendation = 'not_recommended';
                $reasonEn = 'Not typically used this season';
            } elseif (in_array('all_year', $seasonTags)) {
                $recommendation = 'essential';
                $reasonEn = 'Used year-round';
            }
        } else {
            if (in_array('all_year', $seasonTags)) {
                $recommendation = 'essential';
            } elseif ($isSeasonRelevant) {
                $recommendation = 'recommended';
            } else {
                $recommendation = 'not_recommended';
            }
        }

        // Calculate recommended usage hours based on season
        $usageHours = $season === 'winter'
            ? $appliance['usage_hours_winter']
            : $appliance['usage_hours_summer'];

        $appliance['seasonal'] = [
            'season' => $season,
            'is_relevant' => $isSeasonRelevant,
            'recommendation' => $recommendation,
            'reason_en' => $reasonEn,
            'usage_hours' => $usageHours,
            'daily_kwh' => round(($appliance['watt_typical'] * $usageHours) / 1000, 2)
        ];
    }

    // Sort: highly_recommended first, then essential, recommended, normal, not_recommended last
    // Within same recommendation, sort by priority_order
    $priority = ['highly_recommended' => 0, 'essential' => 1, 'recommended' => 2, 'normal' => 3, 'not_recommended' => 4];
    usort($appliances, function($a, $b) use ($priority) {
        $pa = $priority[$a['seasonal']['recommendation']] ?? 3;
        $pb = $priority[$b['seasonal']['recommendation']] ?? 3;
        if ($pa !== $pb) return $pa - $pb;
        // Same recommendation — sort by priority_order
        if ($a['priority_order'] !== $b['priority_order']) return $a['priority_order'] - $b['priority_order'];
        return strcmp($a['category'], $b['category']);
    });

    respond_json([
        'success' => true,
        'season' => $season,
        'city_id' => $cityId ?: null,
        'country' => $countryCode ?: null,
        'temperature' => $temperature,
        'total' => count($appliances),
        'appliances' => $appliances
    ]);

} catch (Exception $e) {
    error_log("Appliances API error: " . $e->getMessage());
    respond_json([
        'success' => false,
        'message' => 'Error loading appliances'
    ], 500);
}
