<?php
/**
 * Dealer Products - Manage listed products
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

set_security_headers();
require_dealer_login();
require_dealer_subscription(); // Must have active subscription to manage products

$dealer = get_dealer_profile();
$db = getDB();
$success = '';
$error = '';

// Dealer's currency info
$dealer_country = $dealer['country_code'] ?? '';
$dealer_currency = get_country_currency_info($dealer_country);

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';
    $dp_id = (int)($_POST['dp_id'] ?? 0);

    if ($action === 'update_price' && $dp_id) {
        $local_price = floatval($_POST['dealer_price'] ?? 0);
        $price = convert_local_to_usd($local_price, $dealer_country);
        if ($price > 0) {
            $db->prepare("UPDATE dealer_products SET dealer_price = ?, updated_at = NOW() WHERE id = ? AND dealer_id = ?")
               ->execute([$price, $dp_id, $dealer['id']]);
            $success = 'Price updated!';
        }
    } elseif ($action === 'update_stock' && $dp_id) {
        $qty = max(0, (int)($_POST['stock_quantity'] ?? 0));
        $status = $qty > 5 ? 'in_stock' : ($qty > 0 ? 'low_stock' : 'out_of_stock');
        $db->prepare("UPDATE dealer_products SET stock_quantity = ?, stock_status = ?, updated_at = NOW() WHERE id = ? AND dealer_id = ?")
           ->execute([$qty, $status, $dp_id, $dealer['id']]);
        $success = 'Stock updated!';
    } elseif ($action === 'toggle_active' && $dp_id) {
        $db->prepare("UPDATE dealer_products SET is_active = NOT is_active, updated_at = NOW() WHERE id = ? AND dealer_id = ?")
           ->execute([$dp_id, $dealer['id']]);
        $success = 'Product visibility toggled!';
    } elseif ($action === 'remove' && $dp_id) {
        $db->prepare("DELETE FROM dealer_products WHERE id = ? AND dealer_id = ?")->execute([$dp_id, $dealer['id']]);
        $success = 'Product removed from your store.';
    }
}

// Filter
$type_filter = $_GET['type'] ?? 'all';
$valid_types = ['all', 'inverter', 'battery', 'panel', 'installation_appliance'];
if (!in_array($type_filter, $valid_types)) $type_filter = 'all';

// Fetch dealer products with product details
$where_type = $type_filter !== 'all' ? "AND dp.product_type = " . $db->quote($type_filter) : '';
$products = $db->prepare("
    SELECT dp.*,
        CASE dp.product_type
            WHEN 'inverter' THEN (SELECT CONCAT(i.company, ' ', i.model) FROM inverters i WHERE i.id = dp.product_id)
            WHEN 'battery'  THEN (SELECT CONCAT(b.brand, ' ', b.model) FROM batteries b WHERE b.id = dp.product_id)
            WHEN 'panel'    THEN (SELECT CONCAT(p.brand, ' ', p.name) FROM panels p WHERE p.id = dp.product_id)
            WHEN 'installation_appliance' THEN (SELECT CONCAT(ia.brand, ' ', ia.name) FROM installation_appliances ia WHERE ia.id = dp.product_id)
        END AS product_name,
        CASE dp.product_type
            WHEN 'inverter' THEN (SELECT i.unit_price_usd FROM inverters i WHERE i.id = dp.product_id)
            WHEN 'battery'  THEN (SELECT b.price_unit_usd FROM batteries b WHERE b.id = dp.product_id)
            WHEN 'panel'    THEN (SELECT p.price_usd FROM panels p WHERE p.id = dp.product_id)
            WHEN 'installation_appliance' THEN (SELECT ia.price_usd FROM installation_appliances ia WHERE ia.id = dp.product_id)
        END AS base_price,
        CASE dp.product_type
            WHEN 'inverter' THEN (SELECT CONCAT(i.output_power_w, 'W') FROM inverters i WHERE i.id = dp.product_id)
            WHEN 'battery'  THEN (SELECT CONCAT(b.capacity_ah, 'Ah/', b.nominal_voltage, 'V') FROM batteries b WHERE b.id = dp.product_id)
            WHEN 'panel'    THEN (SELECT CONCAT(p.wattage, 'W') FROM panels p WHERE p.id = dp.product_id)
            WHEN 'installation_appliance' THEN (SELECT ia.category FROM installation_appliances ia WHERE ia.id = dp.product_id)
        END AS spec_summary,
        CASE dp.product_type
            WHEN 'inverter' THEN (SELECT COUNT(*) FROM inverters i WHERE i.id = dp.product_id)
            WHEN 'battery'  THEN (SELECT COUNT(*) FROM batteries b WHERE b.id = dp.product_id)
            WHEN 'panel'    THEN (SELECT COUNT(*) FROM panels p WHERE p.id = dp.product_id)
            WHEN 'installation_appliance' THEN (SELECT COUNT(*) FROM installation_appliances ia WHERE ia.id = dp.product_id)
        END AS product_exists
    FROM dealer_products dp
    WHERE dp.dealer_id = ? $where_type
    ORDER BY dp.product_type, dp.updated_at DESC
");
$products->execute([$dealer['id']]);
$products = $products->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Products - <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        .container { max-width: 100%; padding: 0; }
        .btn-add { display: inline-block; padding: 8px 16px; background: #F59E0B; color: #1E293B; font-weight: 600; border-radius: 8px; text-decoration: none; font-size: 0.875rem; }
        .btn-add:hover { background: #D97706; }

        .filter-bar {
            display: flex; gap: 8px; margin-bottom: 20px; flex-wrap: wrap;
        }
        .filter-btn {
            padding: 8px 18px; border: 2px solid #E2E8F0; border-radius: 8px;
            background: white; font-size: 0.875rem; font-weight: 500;
            cursor: pointer; text-decoration: none; color: #475569;
        }
        .filter-btn.active, .filter-btn:hover {
            border-color: #1565C0; background: #EFF6FF; color: #1565C0;
        }

        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; }
        .alert-success { background: #DCFCE7; color: #166534; }
        .alert-error { background: #FEF2F2; color: #991B1B; }

        .product-table {
            width: 100%; border-collapse: collapse; background: white;
            border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }
        .product-table th {
            background: #F8FAFC; padding: 12px 16px; text-align: left;
            font-size: 0.8125rem; font-weight: 600; color: #64748B;
            text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #E2E8F0;
        }
        .product-table td {
            padding: 14px 16px; border-bottom: 1px solid #F1F5F9;
            font-size: 0.875rem; vertical-align: middle;
        }
        .product-table tr:hover { background: #F8FAFC; }

        .type-badge {
            display: inline-block; padding: 3px 10px; border-radius: 6px;
            font-size: 0.75rem; font-weight: 600; text-transform: uppercase;
        }
        .type-inverter { background: #DBEAFE; color: #1E40AF; }
        .type-battery { background: #DCFCE7; color: #166534; }
        .type-panel { background: #FEF3C7; color: #92400E; }
        .type-installation_appliance { background: #F3E8FF; color: #6B21A8; }

        .stock-badge {
            display: inline-block; padding: 3px 10px; border-radius: 6px;
            font-size: 0.75rem; font-weight: 600;
        }
        .stock-in_stock { background: #DCFCE7; color: #166534; }
        .stock-low_stock { background: #FEF3C7; color: #92400E; }
        .stock-out_of_stock { background: #FEE2E2; color: #991B1B; }

        .price-cell { font-weight: 700; color: #1E293B; }
        .base-price { font-size: 0.75rem; color: #94A3B8; text-decoration: line-through; }

        .action-btns { display: flex; gap: 4px; }
        .action-btn {
            padding: 6px 10px; border: 1px solid #E2E8F0; border-radius: 6px;
            background: white; cursor: pointer; font-size: 0.75rem; font-weight: 500;
            color: #475569; transition: all 0.2s;
        }
        .action-btn:hover { background: #F1F5F9; }
        .action-btn.danger:hover { background: #FEF2F2; color: #DC2626; border-color: #FECACA; }

        .empty-state {
            text-align: center; padding: 60px 20px; background: white;
            border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }
        .empty-state .e-icon { font-size: 3rem; margin-bottom: 16px; }
        .empty-state h3 { font-size: 1.25rem; color: #1E293B; margin-bottom: 8px; }
        .empty-state p { color: #64748B; margin-bottom: 20px; }
        .empty-state a {
            display: inline-block; padding: 12px 28px; background: #F59E0B;
            color: #1E293B; text-decoration: none; border-radius: 8px; font-weight: 600;
        }

        .inline-form { display: inline-flex; align-items: center; gap: 4px; }
        .inline-form input {
            width: 90px; padding: 5px 8px; border: 1px solid #E2E8F0;
            border-radius: 4px; font-size: 0.8125rem; text-align: right;
        }

        @media (max-width: 768px) {
            .product-table, .product-table thead, .product-table tbody,
            .product-table th, .product-table td, .product-table tr {
                display: block;
            }
            .product-table thead { display: none; }
            .product-table td {
                padding: 8px 16px; text-align: right;
                position: relative; padding-left: 40%;
            }
            .product-table td::before {
                content: attr(data-label); position: absolute; left: 16px;
                font-weight: 600; color: #64748B; font-size: 0.8125rem;
            }
            .product-table tr { margin-bottom: 12px; border: 1px solid #E2E8F0; border-radius: 8px; }
        }
    </style>
</head>
<body>
    <?php $current_dealer_page = 'products'; include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="dlr-main-content">
        <div class="dlr-page-header">
            <div class="dlr-page-header-left">
                <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
                <h1>&#128230; My Products</h1>
            </div>
            <div>
                <a href="add-products.php" class="btn-add">+ Add Products</a>
            </div>
        </div>

        <div class="container">
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>

        <?php
        $orphaned_count = count(array_filter($products, fn($p) => !($p['product_exists'] ?? 1)));
        if ($orphaned_count > 0):
        ?>
        <div class="alert" style="background:#FEF3C7; color:#92400E; border-left:4px solid #F59E0B;">
            ⚠️ <strong><?= $orphaned_count ?> product(s) removed from catalog</strong> —
            These products were deleted by the admin and are no longer available. They are hidden from your store but still listed here.
            Please remove them from your inventory to keep your store clean.
        </div>
        <?php endif; ?>

        <div class="filter-bar">
            <a href="?type=all" class="filter-btn <?= $type_filter === 'all' ? 'active' : '' ?>">All (<?= count($products) ?>)</a>
            <a href="?type=inverter" class="filter-btn <?= $type_filter === 'inverter' ? 'active' : '' ?>">Inverters</a>
            <a href="?type=battery" class="filter-btn <?= $type_filter === 'battery' ? 'active' : '' ?>">Batteries</a>
            <a href="?type=panel" class="filter-btn <?= $type_filter === 'panel' ? 'active' : '' ?>">Panels</a>
            <a href="?type=installation_appliance" class="filter-btn <?= $type_filter === 'installation_appliance' ? 'active' : '' ?>">Installation</a>
        </div>

        <?php if (empty($products)): ?>
            <div class="empty-state">
                <div class="e-icon">&#128230;</div>
                <h3>No products listed yet</h3>
                <p>Start adding solar products to your store inventory.</p>
                <a href="add-products.php">+ Add Your First Product</a>
            </div>
        <?php else: ?>
            <table class="product-table">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Product</th>
                        <th>Specs</th>
                        <th>Your Price</th>
                        <th>Stock</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $p): ?>
                        <tr style="border-bottom:1px solid #F1F5F9;<?= !($p['product_exists'] ?? 1) ? ' background:#FFF7ED; opacity:0.8;' : '' ?>">
                            <td data-label="Type">
                                <span class="type-badge type-<?= $p['product_type'] ?>">
                                    <?= ucfirst($p['product_type']) ?>
                                </span>
                            </td>
                            <td data-label="Product">
                                <?php if (!($p['product_exists'] ?? 1)): ?>
                                    <strong style="color:#92400E;">⚠️ Product Deleted</strong>
                                    <div style="font-size:0.75rem; color:#B45309;">This product was removed from the catalog by admin</div>
                                <?php else: ?>
                                    <strong><?= sanitize($p['product_name'] ?? 'Unknown') ?></strong>
                                <?php endif; ?>
                            </td>
                            <td data-label="Specs"><?= sanitize($p['spec_summary'] ?? '') ?></td>
                            <td data-label="Price" class="price-cell">
                                <form method="POST" class="inline-form">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="update_price">
                                    <input type="hidden" name="dp_id" value="<?= $p['id'] ?>">
                                    <?= sanitize($dealer_currency['currency_symbol']) ?><input type="number" name="dealer_price" value="<?= number_format(convert_usd_to_local((float)$p['dealer_price'], $dealer_country), 2, '.', '') ?>" step="0.01" min="0">
                                    <button type="submit" class="action-btn" title="Save price">&#10004;</button>
                                </form>
                                <?php if ($p['base_price']): ?>
                                    <div class="base-price">Base: <?= format_local_price((float)$p['base_price'], $dealer_country) ?></div>
                                <?php endif; ?>
                            </td>
                            <td data-label="Stock">
                                <form method="POST" class="inline-form">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="update_stock">
                                    <input type="hidden" name="dp_id" value="<?= $p['id'] ?>">
                                    <input type="number" name="stock_quantity" value="<?= $p['stock_quantity'] ?>" min="0" style="width:60px">
                                    <button type="submit" class="action-btn" title="Save stock">&#10004;</button>
                                </form>
                            </td>
                            <td data-label="Status">
                                <span class="stock-badge stock-<?= $p['stock_status'] ?>">
                                    <?= str_replace('_', ' ', ucfirst($p['stock_status'])) ?>
                                </span>
                                <?php if (!$p['is_active']): ?>
                                    <br><small style="color:#DC2626">Hidden</small>
                                <?php endif; ?>
                            </td>
                            <td data-label="Actions">
                                <div class="action-btns">
                                    <form method="POST" style="display:inline">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="toggle_active">
                                        <input type="hidden" name="dp_id" value="<?= $p['id'] ?>">
                                        <button type="submit" class="action-btn" title="<?= $p['is_active'] ? 'Hide' : 'Show' ?>">
                                            <?= $p['is_active'] ? '&#128065;' : '&#128064;' ?>
                                        </button>
                                    </form>
                                    <form method="POST" style="display:inline" onsubmit="return confirm('Remove this product from your store?')">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="remove">
                                        <input type="hidden" name="dp_id" value="<?= $p['id'] ?>">
                                        <button type="submit" class="action-btn danger" title="Remove">&#128465;</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    </main>
</body>
</html>
