<?php
/**
 * Solar Recommendation Engine  v10.1
 * ====================================
 * Fix: All helper functions moved outside try{} block (required by PHP).
 *      Granular error logging at each major step.
 *      Graceful column-missing fallbacks (uses COALESCE/defaults for new cols).
 */

// ── Configuration ─────────────────────────────────────────────────────────────
define('MAX_BACKUP_HOURS',       10);
define('DEFAULT_PEAK_SUN_HOURS', 5.0);
define('SAFETY_FACTOR',          1.25);
define('MIN_INVERTER_WATTS',     300);
define('BATTERY_LIMIT_SMALL',    16);
define('BATTERY_LIMIT_MEDIUM',   24);
define('BATTERY_LIMIT_LARGE',    32);
define('MAX_PARALLEL_STRINGS',   12);
define('TIER_DB_LIMIT',          5);
define('COO_YEARS',              10);

// ── Init ──────────────────────────────────────────────────────────────────────
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors',     1);
header('Content-Type: application/json; charset=utf-8');
session_start();

try {
    require_once '../includes/db.php';
    require_once '../includes/csrf.php';
    require_once '../includes/helpers.php';
    require_once '../includes/RecommendationEnhancer.php';
    set_security_headers();

    if (!rate_limit('api_recommend_v7', 15, 60)) { respond_rate_limited(); }
} catch (Exception $e) {
    http_response_code(500);
    respond_json(['success' => false, 'error' => 'init_failed', 'message' => $e->getMessage()]);
    exit;
}

// ── Rate Limiting ─────────────────────────────────────────────────────────────
$rate_key = 'rl_' . md5(($_SERVER['REMOTE_ADDR'] ?? '') . session_id());
if (!isset($_SESSION[$rate_key])) $_SESSION[$rate_key] = [];
$_SESSION[$rate_key] = array_filter($_SESSION[$rate_key], fn($t) => (time() - $t) < 60);
if (count($_SESSION[$rate_key]) >= 30) {
    respond_json(['success' => false, 'message' => 'Too many requests. Please wait a minute.'], 429);
    exit;
}
$_SESSION[$rate_key][] = time();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond_json(['success' => false, 'message' => 'Method not allowed'], 405);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!validate_csrf_token($input['csrf_token'] ?? '')) {
    respond_json(['success' => false, 'error' => 'csrf_invalid'], 403);
    exit;
}
if (empty($input['appliances'])) {
    respond_json(['success' => false, 'message' => 'No appliances selected'], 400);
    exit;
}

// ══════════════════════════════════════════════════════════════════════════════
// ALL HELPER FUNCTIONS  (must be at file scope, NOT inside try{})
// ══════════════════════════════════════════════════════════════════════════════

function parseVoltage(string $s): int {
    $upper = strtoupper(trim($s));
    // Handle named voltage classes
    if ($upper === 'HV')  return 400;  // High-voltage (200-400V batteries)
    if ($upper === 'LV')  return 48;   // Low-voltage (48V typical)
    $v = intval(preg_replace('/[^0-9]/', '', $s));
    return $v > 0 ? $v : 48;
}

function panelVoltageClass(float $vmp): int {
    if ($vmp < 28)  return 12;
    if ($vmp <= 42) return 24;
    return 48;
}

/**
 * Battery capacity derating for high ambient temperature.
 * Lead-Acid / Tubular / Gel : -2 %/°C above 25°C, max 30 %
 * Lithium / LiFePO4         : -1 %/°C above 25°C, max 15 %
 */
function batteryTempDerate(float $ah, array $bat, int $temp_c): float {
    if ($temp_c <= 25) return $ah;
    $type  = strtolower($bat['type'] ?? '');
    $is_li = str_contains($type, 'lithium') || str_contains($type, 'lfp');
    $pct   = $is_li ? min(15, ($temp_c - 25)) : min(30, ($temp_c - 25) * 2);
    return $ah * (1 - $pct / 100);
}

/**
 * Panel output derating for high cell temperature.
 * Cell temp ≈ ambient + 25 °C (NOCT approximation).
 */
function panelTempDerate(float $wp, array $panel, int $ambient_c): float {
    $coeff  = -0.35; // default temperature coefficient (column not in new schema)
    $cell_c = $ambient_c + 25;
    $delta  = $cell_c - 25;
    if ($delta <= 0) return $wp;
    $derate = max(0.65, 1.0 + ($coeff / 100) * $delta);
    return $wp * $derate;
}

/**
 * Parse temperature range string like "-20°C ~ +60°C" → [min, max].
 */
function parseTempRange(string $s): array {
    preg_match_all('/-?\d+/', $s, $m);
    $nums = array_map('intval', $m[0]);
    if (count($nums) >= 2) return [$nums[0], $nums[1]];
    if (count($nums) === 1) return [$nums[0], $nums[0]];
    return [-20, 60];
}

/**
 * Panel type quality score.
 * TopCon / N-Type > HJT > Mono PERC > Poly > Thin-Film
 */
function panelTypeScore(string $type): float {
    $t = strtolower($type);
    if (str_contains($t, 'topcon') || str_contains($t, 'n-type')) return 1.00;
    if (str_contains($t, 'hjt') || str_contains($t, 'heterojunction'))   return 0.95;
    if (str_contains($t, 'perc') || str_contains($t, 'mono'))             return 0.85;
    if (str_contains($t, 'poly') || str_contains($t, 'multicrystal'))     return 0.65;
    return 0.55;
}

/**
 * IP rating quality score. IP66 → 1.0 … IP21 → 0.40.
 */
function ipRatingScore(string $ip): float {
    $ip = strtoupper($ip);
    if (str_contains($ip, 'IP66')) return 1.00;
    if (str_contains($ip, 'IP65')) return 0.90;
    if (str_contains($ip, 'IP55')) return 0.80;
    if (str_contains($ip, 'IP54')) return 0.75;
    if (str_contains($ip, 'IP44')) return 0.60;
    if (str_contains($ip, 'IP21')) return 0.40;
    return 0.50;
}

/**
 * Warranty score 0–1 (linear up to max_years).
 */
function warrantyScore(int $years, int $max_years = 10): float {
    return min(1.0, $years / max(1, $max_years));
}

/**
 * 10-year cost-of-ownership: cost spread over effective life.
 */
function costOfOwnership(float $cost, int $warranty_years): float {
    $life = max(1, min(COO_YEARS, $warranty_years + 2));
    return $cost / $life;
}

/**
 * Fetch ALL suitable inverters across ALL voltage classes (12V, 24V, 48V).
 * Pre-filters for panel compatibility — only returns inverters where at least
 * one available panel's Voc fits within the inverter's VDC input range.
 *
 * This replaces the old tier-based system that always found 12V inverters
 * first (smallest wattage), which often had no compatible panels.
 */
function fetchCompatibleInverters(
    PDO   $db,
    int   $min_watts,
    int   $has_bms,
    int   $peak_surge,
    bool  $three_phase,
    array $available_panels,
    int   $limit = 15
): array {
    $floor = max($min_watts, MIN_INVERTER_WATTS);
    $cap   = max($floor * 4, 10000);

    // Simplified query for new schema: no has_bms, no input_voltage_max/min,
    // no surge_power_watts, no has_l3, no ip_rating, no cooling_method,
    // no communication, no certifications, no max_input_current
    $stmt = $db->prepare("
        SELECT
            i.*,
            COALESCE(i.efficiency, 90)  AS efficiency,
            COALESCE(i.mppt_count,        1)  AS mppt_channels,
            COALESCE(i.warranty_years,    1)  AS warranty_years,
            COALESCE(c.name,    'Unknown')    AS company_name,
            COALESCE(c.logo_path, '')         AS company_logo
        FROM inverters i
        LEFT JOIN companies c ON i.company_id = c.id
        WHERE i.output_power_w  >= ?
          AND i.output_power_w  <= ?
          AND i.is_active        = 1
        ORDER BY
            i.output_power_w ASC,
            i.unit_price_usd      ASC
        LIMIT 80
    ");
    $stmt->execute([$floor, $cap]);
    $all_inverters = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($all_inverters)) return [];

    error_log("v10.2 fetchCompatibleInverters: min={$floor}W, "
        . "total_found=" . count($all_inverters));

    // Pick best from each voltage class (max 5 per class)
    $by_class = [];
    foreach ($all_inverters as $inv) {
        $vc = $inv['vdc_type'] ?? '48V';
        if (!isset($by_class[$vc])) $by_class[$vc] = [];
        if (count($by_class[$vc]) < 5) {
            $by_class[$vc][] = $inv;
        }
    }

    // Merge all voltage classes
    $result = [];
    $seen   = [];
    foreach ($by_class as $invs) {
        foreach ($invs as $inv) {
            if (!in_array($inv['id'], $seen)) {
                $result[] = $inv;
                $seen[]   = $inv['id'];
            }
        }
    }

    // Sort by best match: closest to 1.3x required watts, then cheapest
    usort($result, function($a, $b) use ($floor) {
        $a_fit = abs(($a['output_power_w'] / $floor) - 1.3);
        $b_fit = abs(($b['output_power_w'] / $floor) - 1.3);
        $d = $a_fit <=> $b_fit;
        return $d !== 0 ? $d : ($a['unit_price_usd'] <=> $b['unit_price_usd']);
    });

    // Assign tier labels by position
    $labels = ['Recommended', '+2KW Upgrade', '+3KW Upgrade', 'Premium Tier', 'Extended'];
    $descs  = ['Best Match',  'More Headroom', 'Future Expansion', 'High Capacity', 'Max Power'];
    foreach ($result as $i => &$inv) {
        $ti = min($i, count($labels) - 1);
        $inv['tier_name']  = $labels[$ti];
        $inv['tier_label'] = $descs[$ti];
        $inv['surge_ok']   = true; // no surge_power_watts column in new schema
    }
    unset($inv);

    return array_slice($result, 0, $limit);
}

function buildTiersFromCapacities(array $caps): array {
    $tiers  = [];
    $labels = ['Recommended', 'Next Tier', 'Higher Tier'];
    $descs  = ['Best Match',  'More Headroom', 'Future Expansion'];
    foreach (array_values($caps) as $i => $cap) {
        $next  = $caps[$i + 1] ?? null;
        $max_w = $next ? ($next - 1) : (int)($cap * 1.30);
        $tiers[] = [
            'name'  => $labels[$i] ?? 'Option ' . ($i + 1),
            'label' => $descs[$i]  ?? '',
            'min'   => (int)$cap,
            'max'   => (int)$max_w,
        ];
        if (count($tiers) >= 3) break;
    }
    return $tiers;
}

/**
 * Fetch inverters for one tier with full attribute columns.
 * Uses COALESCE for optional columns so missing columns don't crash.
 *
 * Soft preferences via ORDER BY:
 *  1. Three-phase capable (if three_phase=true)
 *  2. Surge power covers peak
 *  3. Smallest adequate size first
 *  4. Cheapest
 */
function fetchInverterTier(
    PDO   $db,
    array $tier,
    int   $has_bms,
    int   $peak_surge,
    bool  $three_phase,
    int   $limit = 3
): array {
    $stmt = $db->prepare("
        SELECT
            i.*,
            COALESCE(i.efficiency, 90)  AS efficiency,
            COALESCE(i.mppt_count,        1)  AS mppt_channels,
            COALESCE(i.warranty_years,    1)  AS warranty_years,
            COALESCE(c.name,    'Unknown')    AS company_name,
            COALESCE(c.logo_path, '')         AS company_logo
        FROM inverters i
        LEFT JOIN companies c ON i.company_id = c.id
        WHERE i.output_power_w  >= ?
          AND i.output_power_w  <= ?
          AND i.is_active        = 1
        ORDER BY
            i.output_power_w ASC,
            i.unit_price_usd      ASC
        LIMIT ?
    ");
    $stmt->execute([$tier['min'], $tier['max'], $limit]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fallback: nearest above min, capped at 3x tier-min
    if (empty($rows)) {
        $cap  = $tier['min'] * 3;
        $stmt = $db->prepare("
            SELECT
                i.*,
                COALESCE(i.max_efficiency, '90%')  AS efficiency,
                COALESCE(i.mppt_count,        1)  AS mppt_channels,
                COALESCE(i.warranty_years,    1)  AS warranty_years,
                COALESCE(c.name,    'Unknown')    AS company_name,
                COALESCE(c.logo_path, '')         AS company_logo
            FROM inverters i
            LEFT JOIN companies c ON i.company_id = c.id
            WHERE i.output_power_w >= ?
              AND i.output_power_w <= ?
              AND i.is_active       = 1
            ORDER BY i.output_power_w ASC, i.unit_price_usd ASC
            LIMIT ?
        ");
        $stmt->execute([$tier['min'], $cap, $limit]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    foreach ($rows as &$r) {
        $r['tier_name']  = $tier['name'];
        $r['tier_label'] = $tier['label'];
        $r['surge_ok']   = true; // no surge_power_w in calculations for now
        $r['power_rating'] = $r['output_power_w']; // Add alias for backward compatibility
    }
    return $rows;
}

function buildInverterList(PDO $db, array $tiers, int $has_bms, int $peak_surge, bool $three_phase): array {
    $list = [];
    $seen = [];
    foreach ($tiers as $tier) {
        foreach (fetchInverterTier($db, $tier, $has_bms, $peak_surge, $three_phase, 3) as $inv) {
            if (!in_array($inv['id'], $seen)) {
                $list[] = $inv;
                $seen[] = $inv['id'];
            }
        }
    }
    return $list;
}

/**
 * Select the best panel for a given inverter using simplified scoring.
 * New schema has no voc/vmp/isc columns — matching is by wattage and quality.
 *
 * SCORING: cost_eff × size_match × eff_bonus × type_bonus × warr_bonus
 */
function selectBestPanel(array $panels, array $inverter, int $ambient_temp_c): ?array {
    $inv_watts  = intval($inverter['output_power_w']   ?? $inverter['power_rating'] ?? 0);
    $max_pv_w   = intval($inverter['max_pv_input_w']   ?? $inverter['max_solar_input'] ?? 0);
    $mppt_count = max(1, intval($inverter['mppt_channels'] ?? 1));

    // Target PV wattage: 100-130% of inverter capacity (or max_pv_input_w)
    $target_pv_w = ($max_pv_w > 0) ? $max_pv_w : ($inv_watts * 1.3);

    // Ideal single-panel wattage for this inverter size
    $ideal_panel_wp = ($inv_watts < 1000) ? 200
                    : (($inv_watts < 3000) ? 330
                    : (($inv_watts < 5000) ? 450 : 550));

    $best_panel = null;
    $best_score = -1.0;

    foreach ($panels as $p) {
        $wp  = intval($p['wattage'] ?? 0);
        if ($wp <= 0) continue;

        $price = floatval($p['price_usd'] ?? 0);
        if ($price <= 0) continue;

        // How many panels needed to reach target PV wattage
        $panels_needed = max(1, (int)ceil($target_pv_w / $wp));
        $total_wp      = $panels_needed * $wp;
        $total_cost    = $panels_needed * $price;

        // Factor 1: Panel wattage match to inverter size (0.5 - 1.0)
        $wp_diff_ratio = abs($wp - $ideal_panel_wp) / max(1, $ideal_panel_wp);
        $size_match = max(0.5, 1.0 - $wp_diff_ratio * 0.6);

        // Factor 2: Practical panel count (0.6 - 1.0) — fewer is better
        $ideal_count = max(2, (int)ceil($target_pv_w / max(1, $wp)));
        $count_ratio = $panels_needed / max(1, $ideal_count);
        $count_score = ($count_ratio >= 0.8 && $count_ratio <= 1.5) ? 1.0
                     : max(0.6, 1.0 - abs($count_ratio - 1.0) * 0.3);

        // Factor 3: Cost efficiency (watts per dollar)
        $cost_eff = $total_wp / $total_cost;

        // Factor 4: Technical quality bonuses
        $eff    = floatval($p['efficiency'] ?? 15);
        $eff_b  = max(0.85, 1.0 + ($eff - 18) / 50);
        $type_b = panelTypeScore($p['type'] ?? '');
        $warr_b = 1.0 + warrantyScore(intval($p['warranty_years'] ?? 10), 25) * 0.05;

        // Combined score
        $score = $cost_eff
               * $size_match
               * $count_score
               * $eff_b * $type_b * $warr_b;

        if ($score > $best_score) {
            $best_score = $score;
            $best_panel = $p;
        }
    }

    return $best_panel;
}

/**
 * Calculate panel array configuration for a specific inverter + daily energy need.
 */
function calcPanelConfig(
    array $panel,
    array $inverter,
    float $daily_energy_kwh,
    float $battery_recharge_kwh,
    float $peak_sun_hours,
    int   $ambient_temp_c
): ?array {
    $wp         = intval($panel['wattage']             ?? 0);
    $max_pv_w   = intval($inverter['max_solar_input']  ?? 0);
    $mppt_count = max(1, intval($inverter['mppt_channels'] ?? 1));

    if ($wp <= 0) return null;

    $wp_derated = panelTempDerate($wp, $panel, $ambient_temp_c);

    $total_daily_kwh = $daily_energy_kwh + $battery_recharge_kwh;
    $req_kwp = ($total_daily_kwh / max(0.1, $peak_sun_hours)) * SAFETY_FACTOR;
    if ($req_kwp < 0.2) $req_kwp = 0.2;
    if ($max_pv_w > 0)  $req_kwp = min($req_kwp, $max_pv_w / 1000);

    // Calculate total panels needed
    $total = max(1, (int)ceil(($req_kwp * 1000) / max(1, $wp_derated)));

    // Clamp to max_solar_input
    if ($max_pv_w > 0 && ($total * $wp) > $max_pv_w) {
        $total = max(1, (int)floor($max_pv_w / $wp));
    }

    $total = min($total, MAX_PARALLEL_STRINGS * $mppt_count);

    $total_wp         = $total * $wp;
    $total_wp_derated = $total * $wp_derated;
    $daily_gen_kwh    = round(($total_wp_derated / 1000) * $peak_sun_hours, 2);

    return [
        'panel'               => $panel,
        'quantity'            => $total,
        'series'              => 1,
        'parallel'            => $total,
        'wiring'              => "{$total} panels",
        'total_wattage_stc'   => $total_wp,
        'total_wattage_real'  => (int)$total_wp_derated,
        'total_kwp'           => round($total_wp / 1000, 2),
        'daily_gen_kwh'       => $daily_gen_kwh,
        'daily_need_kwh'      => round($total_daily_kwh, 2),
        'total_cost'          => round($total * floatval($panel['price_usd'] ?? 0)),
        'vdc_used'            => 0,
        'vdc_limit'           => 0,
        'within_vdc'          => true,
        'panel_warranty_yrs'  => intval($panel['warranty_years'] ?? 10),
        'panel_efficiency'    => floatval($panel['efficiency']   ?? 0),
        'panel_degradation'   => 0,
        'panel_type'          => $panel['type'] ?? '',
        'temp_derate_applied' => ($ambient_temp_c > 25),
        'certifications'      => '',
    ];
}

/**
 * Find top batteries for a given inverter + battery category.
 *
 * SCORING DIMENSIONS (100 pts total):
 *  accuracy     38 pts — backup time meets/exceeds requested hours
 *  cost_eff     18 pts — cost per usable kWh vs benchmark
 *  coo_score     8 pts — 10-year cost-of-ownership efficiency
 *  warranty_sc  14 pts — warranty years / 10
 *  cycle_sc     12 pts — cycle life / 3000
 *  fewer_sc      6 pts — fewer batteries = simpler bank
 *  maint_sc      4 pts — maintenance-free bonus
 *
 * Temperature range validated; out-of-range → 0.6× score penalty.
 * Charging current per string validated (hard limit ×1.10 tolerance).
 */
function findTopBatteries(
    PDO    $db,
    array  $inverter,
    array  $battery_types,
    float  $backup_hours,
    float  $avg_night_load_w,
    int    $ambient_temp_c,
    bool   $bms_required,
    int    $max_results = 3
): array {
    $sys_v     = parseVoltage($inverter['battery_voltage_range'] ?? $inverter['vdc_type'] ?? '48V');
    $inv_watts = intval($inverter['output_power_w'] ?? $inverter['power_rating'] ?? 0);
    $eff_str   = $inverter['max_efficiency'] ?? $inverter['efficiency'] ?? '90%';
    $inv_eff   = max(50, min(99, intval($eff_str))) / 100;
    $max_bats  = $inv_watts < 5000   ? BATTERY_LIMIT_SMALL
               : (($inv_watts <= 15000) ? BATTERY_LIMIT_MEDIUM : BATTERY_LIMIT_LARGE);

    // Build compatible voltage list
    // HV systems (400V) use HV batteries (200V+) in series, or 48V batteries stacked
    // LV/48V systems use 12V, 24V, or 48V batteries in series
    $compat_v = [];
    if ($sys_v >= 200) {
        // HV system — match HV batteries (200V+) and 48V batteries
        $possible_v = [48, 200, 400];
        foreach ($possible_v as $pv) {
            if ($sys_v >= $pv) $compat_v[] = $pv;
        }
    } else {
        // LV system — standard voltage matching
        $possible_v = [2, 6, 8, 12, 24, 48];
        foreach ($possible_v as $pv) {
            if ($sys_v >= $pv && $sys_v % $pv === 0) {
                $compat_v[] = $pv;
            }
        }
    }
    if (empty($compat_v)) $compat_v = [12]; // fallback

    if (empty($battery_types)) return [];
    $type_ph = implode(',', array_fill(0, count($battery_types), '?'));
    $bms_sql = $bms_required ? 'AND b.is_bms = 1' : 'AND b.is_bms = 0';

    $all_candidates = [];

    foreach ($compat_v as $batt_v) {
        $series = (int)round($sys_v / $batt_v);
        if ($series < 1) continue; // skip if voltage doesn't work

        $stmt = $db->prepare("
            SELECT
                b.*,
                COALESCE(b.dod,              0.50) AS dod_decimal,
                COALESCE(b.cycle_life,        500) AS cycle_life,
                COALESCE(b.warranty_years,      1) AS warranty_years,
                COALESCE(c.name, 'Unknown')        AS company_name,
                COALESCE(c.logo_path, '')          AS company_logo
            FROM batteries b
            LEFT JOIN companies c ON b.company_id = c.id
            WHERE b.voltage       = ?
              AND b.type IN ($type_ph)
              $bms_sql
              AND b.is_active     = 1
            ORDER BY b.price_usd ASC
            LIMIT 60
        ");
        $stmt->execute(array_merge([$batt_v], $battery_types));
        $batteries = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($batteries as $bat) {
            $dod_ratio = max(0.10, floatval($bat['dod_decimal'] ?? 0.50));
            $raw_ah    = floatval($bat['capacity_ah'] ?? 0);
            if ($raw_ah <= 0) continue;

            $derated_ah = batteryTempDerate($raw_ah, $bat, $ambient_temp_c);
            $usable_ah  = $derated_ah * $dod_ratio;
            if ($usable_ah <= 0.1) continue;

            // Temperature penalty (no temperature_range column in new schema)
            $temp_penalty = 1.0;
            $temp_ok      = true;

            $required_wh = $avg_night_load_w * $backup_hours;
            $req_ah_sys  = ($sys_v > 0) ? ($required_wh / $sys_v) : $required_wh;
            $parallel    = max(1, (int)ceil($req_ah_sys / $usable_ah));
            $total_bats  = $series * $parallel;
            if ($total_bats > $max_bats || $total_bats <= 0) continue;

            $total_ah     = $parallel * $raw_ah;
            $usable_total = ($parallel * $derated_ah) * $dod_ratio;
            $total_cost   = $total_bats * floatval($bat['price_usd'] ?? 0);
            $batt_kwh     = ($usable_total * $batt_v * $series) / 1000;
            $raw_kwh      = ($total_ah * $batt_v * $series) / 1000; // Total raw capacity (not derated)

            $backup_time = ($avg_night_load_w > 0 && $batt_kwh > 0)
                ? ($batt_kwh * 1000 * $inv_eff) / $avg_night_load_w
                : 0;

            $warranty = intval($bat['warranty_years']);
            $cycles   = intval($bat['cycle_life']);
            $maint    = 0; // no maintenance_free column in new schema

            $accuracy    = ($backup_time >= $backup_hours)
                ? 1.0 : max(0.0, $backup_time / max(1, $backup_hours));
            $cost_per_kwh = ($batt_kwh > 0) ? ($total_cost / $batt_kwh) : 999999;
            $cost_eff     = max(0, 1 - ($cost_per_kwh / 120000));
            $coo_per_yr   = costOfOwnership($total_cost, $warranty);
            $coo_sc       = max(0, 1 - ($coo_per_yr / 60000));
            $warranty_sc  = warrantyScore($warranty, 10);
            $cycle_sc     = min(1.0, $cycles / 3000);
            $fewer_sc     = max(0.0, 1 - ($total_bats / max(1, $max_bats)));
            $maint_sc     = $maint ? 0.04 : 0.0;

            $score = (($accuracy   * 38)
                    + ($cost_eff   * 18)
                    + ($coo_sc     *  8)
                    + ($warranty_sc * 14)
                    + ($cycle_sc    * 12)
                    + ($fewer_sc    *  6)
                    + ($maint_sc    *  4))
                   * $temp_penalty;

            // Wiring description
            if ($series > 1 && $parallel > 1) {
                $wiring = "{$series}S{$parallel}P — {$series}×{$batt_v}V in series = "
                        . ($batt_v * $series) . "V, {$parallel} strings parallel";
            } elseif ($series > 1) {
                $wiring = "{$series} in series ({$batt_v}V×{$series}=" . ($batt_v * $series) . "V)";
            } elseif ($parallel > 1) {
                $wiring = "{$parallel} in parallel = " . ($parallel * $raw_ah) . "Ah @ {$batt_v}V";
            } else {
                $wiring = "Single — {$batt_v}V {$raw_ah}Ah";
            }

            $all_candidates[] = [
                'score'      => $score,
                'company_id' => intval($bat['company_id'] ?? 0),
                'config'     => [
                    'battery'          => $bat,
                    'quantity'         => $total_bats,
                    'series'           => $series,
                    'parallel'         => $parallel,
                    'total_ah'         => round($total_ah),
                    'usable_kwh'       => round($batt_kwh, 2),
                    'total_kwh'        => round($raw_kwh, 2),
                    'total_cost'       => round($total_cost),
                    'backup_hours'     => round($backup_time, 1),
                    'wiring'           => $wiring,
                    'dod_percent'      => intval(round($dod_ratio * 100)),
                    'warranty_years'   => $warranty,
                    'cycle_life'       => $cycles,
                    'maintenance_free' => (bool)$maint,
                    'temp_ok'          => $temp_ok,
                    'communication'    => 'N/A',
                    'certifications'   => '',
                    'weight_total_kg'  => 0,
                    'temp_derated'     => ($ambient_temp_c > 25),
                    'score_debug'      => round($score, 2),
                ],
            ];
        }
    }

    if (empty($all_candidates)) return [];

    usort($all_candidates, fn($a, $b) => $b['score'] <=> $a['score']);
    $best_score = $all_candidates[0]['score'];

    $results        = [];
    $used_companies = [];

    foreach ($all_candidates as $cand) {
        $cid   = $cand['company_id'];
        $close = ($best_score > 0 && ($cand['score'] / $best_score) >= 0.90);
        if ($close && in_array($cid, $used_companies) && count($results) > 0) continue;
        $results[]        = $cand['config'];
        $used_companies[] = $cid;
        if (count($results) >= $max_results) break;
    }

    // Back-fill if diversity left us short
    if (count($results) < $max_results) {
        foreach ($all_candidates as $cand) {
            $dup = false;
            foreach ($results as $r) {
                if (($r['battery']['id'] ?? null) === ($cand['config']['battery']['id'] ?? null)) {
                    $dup = true; break;
                }
            }
            if (!$dup) {
                $results[] = $cand['config'];
                if (count($results) >= $max_results) break;
            }
        }
    }

    return $results;
}

/**
 * Composite inverter quality score (0–100).
 */
function scoreInverter(array $inv, int $peak_surge, float $min_price, float $max_price): float {
    $eff_sc   = min(1.0, intval($inv['efficiency'] ?? 90) / 98.0);
    $warr_sc  = warrantyScore(intval($inv['warranty_years'] ?? 1), 10);

    $mppt    = intval($inv['mppt_channels'] ?? 1);
    $mppt_sc = min(1.0, $mppt / 4.0);

    $price       = floatval($inv['price_usd'] ?? 0);
    $price_range = max(1.0, $max_price - $min_price);
    $price_sc    = 1.0 - (($price - $min_price) / $price_range) * 0.7;

    // Parallel bonus: inverters that support parallel get a small bonus
    $parallel_sc = (!empty($inv['parallel_capable'])) ? 1.0 : 0.0;

    return ($eff_sc      * 28)
         + ($warr_sc     * 28)
         + ($mppt_sc     * 18)
         + ($price_sc    * 18)
         + ($parallel_sc * 8);
}

/**
 * Build option list for one category.
 * Each inverter × best_panel × top_batteries → option entries.
 * Sorted: inverter_score DESC, total_cost ASC.
 */
function buildCategoryOptions(
    PDO    $db,
    array  $inverters,
    array  $battery_types,
    bool   $bms_required,
    float  $backup_hours,
    float  $avg_night_load_w,
    float  $daily_energy_kwh,
    float  $battery_recharge_kwh,
    float  $peak_sun_hours,
    int    $ambient_temp_c,
    array  $available_panels,
    int    $peak_surge
): array {
    if (empty($inverters)) return [];

    $prices = array_column($inverters, 'price_usd');
    $min_p  = !empty($prices) ? (float)min($prices) : 0.0;
    $max_p  = !empty($prices) ? (float)max($prices) : 1.0;

    $options = [];

    foreach ($inverters as $inverter) {
        $best_panel = selectBestPanel($available_panels, $inverter, $ambient_temp_c);
        if (!$best_panel) continue;

        $panel_cfg = calcPanelConfig(
            $best_panel, $inverter,
            $daily_energy_kwh, $battery_recharge_kwh,
            $peak_sun_hours, $ambient_temp_c
        );
        if (!$panel_cfg) continue;

        $top_batteries = findTopBatteries(
            $db, $inverter, $battery_types,
            $backup_hours, $avg_night_load_w,
            $ambient_temp_c, $bms_required, 3
        );
        if (empty($top_batteries)) continue;

        $inv_score = scoreInverter($inverter, $peak_surge, $min_p, $max_p);

        foreach ($top_batteries as $bat_cfg) {
            $total_cost = floatval($inverter['price_usd'] ?? 0)
                        + floatval($bat_cfg['total_cost']  ?? 0)
                        + floatval($panel_cfg['total_cost'] ?? 0);

            $avg_warranty = (
                intval($inverter['warranty_years']       ?? 2) +
                intval($bat_cfg['warranty_years']        ?? 1) +
                intval($panel_cfg['panel_warranty_yrs']  ?? 10)
            ) / 3;

            $coo = costOfOwnership($total_cost, (int)round($avg_warranty));

            // Parallel info
            $parallel_capable = !empty($inverter['parallel_capable']);
            $max_parallel     = max(1, intval($inverter['max_parallel_units'] ?? 1));
            $parallel_units   = 1; // default single unit

            $options[] = [
                'inverter'            => $inverter,
                'battery_config'      => $bat_cfg,
                'panel_config'        => $panel_cfg,
                'total_cost'          => round($total_cost),
                'cost_of_ownership'   => round($coo),
                'avg_warranty_yrs'    => round($avg_warranty, 1),
                'inverter_score'      => round($inv_score, 1),
                'tier_name'           => $inverter['tier_name']       ?? '',
                'tier_label'          => $inverter['tier_label']      ?? '',
                'surge_warning'       => '',
                'system_voltage'      => parseVoltage($inverter['vdc_type'] ?? '48V'),
                'covers_surge'        => true,
                'inverter_efficiency' => intval($inverter['efficiency'] ?? 90),
                'inverter_warranty'   => intval($inverter['warranty_years'] ?? 1),
                'inverter_ip'         => '',
                'inverter_mppt'       => intval($inverter['mppt_channels'] ?? 1),
                'parallel_capable'    => $parallel_capable,
                'max_parallel_units'  => $max_parallel,
                'parallel_units_used' => $parallel_units,
                'parallel_phase_config' => $inverter['parallel_phase_config'] ?? null,
                'inverter_cooling'    => '',
                'inverter_comm'       => '',
                'inverter_certs'      => '',
            ];
        }
    }

    usort($options, function($a, $b) {
        $d = $b['inverter_score'] <=> $a['inverter_score'];
        return $d !== 0 ? $d : ($a['total_cost'] <=> $b['total_cost']);
    });

    return $options;
}

// ══════════════════════════════════════════════════════════════════════════════
// MAIN EXECUTION
// ══════════════════════════════════════════════════════════════════════════════
try {
    $db = getDB();

    // ── Request Parameters ────────────────────────────────────────────────────
    $city_id_input    = intval($input['city_id'] ?? 0);
    $backup_hours     = max(1,   min(MAX_BACKUP_HOURS, floatval($input['backup_hours']   ?? 4)));
    $grid_voltage_vac = intval($input['grid_voltage']  ?? 230);
    $grid_frequency   = intval($input['grid_frequency']?? 50);
    $three_phase      = (bool)($input['three_phase']   ?? false);

    // Use city-specific solar data when available (Phase 7 enhancement)
    $enhancer = new RecommendationEnhancer($city_id_input ?: null);
    $enhanced_params = $enhancer->getEnhancedParams();

    // City data overrides user-guessed values, but user can still override
    $ambient_temp_c = intval($input['ambient_temp_c'] ?? $enhanced_params['ambient_temp_c']);
    $ambient_temp_c = max(15, min(55, $ambient_temp_c));
    $peak_sun_hours = floatval($input['peak_sun_hours'] ?? $enhanced_params['peak_sun_hours']);
    $peak_sun_hours = max(3.0, min(8.0, $peak_sun_hours));

    // ── STEP 1: Build Load Profile ────────────────────────────────────────────
    error_log("v10.1 STEP1: Building load profile, appliances=" . count($input['appliances']));

    $total_load_watts  = 0;
    $appliance_details = [];
    $total_daily_wh    = 0;
    $hourly_load       = array_fill(0, 24, 0);
    $peak_surge_load   = 0;

    foreach ($input['appliances'] as $item) {
        $id       = intval($item['id']);
        $quantity = max(1, intval($item['quantity']));
        $load_factor_pct = floatval($item['loadFactor'] ?? 100);
        $load_factor     = max(10, min(100, $load_factor_pct)) / 100;

        $hourlyUsage = (isset($item['hourlyUsage']) && is_array($item['hourlyUsage']))
            ? $item['hourlyUsage'] : null;

        if (!$hourlyUsage) {
            $st          = intval($item['startTime'] ?? 0);
            $et          = intval($item['endTime']   ?? 24);
            $hourlyUsage = array_fill(0, 24, 0);
            for ($h = $st; $h < $et; $h++) $hourlyUsage[$h] = 1;
        }

        $hours = max(0.25, array_sum($hourlyUsage));

        $stmt = $db->prepare("SELECT id, name_en, watt_typical, surge_load_watts, icon, image_path
                               FROM appliances WHERE id = ? AND is_active = 1");
        $stmt->execute([$id]);
        $app = $stmt->fetch();
        if (!$app) continue;

        $watts_per_unit = (int)round($app['watt_typical'] * $load_factor);
        $watts          = $watts_per_unit * $quantity;
        $surge_watts    = intval($app['surge_load_watts'] ?? 0) * $quantity;

        $total_load_watts += $watts;
        $total_daily_wh  += $watts * $hours;
        // Surge: sum concurrent surge loads (worst case all start at same time)
        $peak_surge_load  += $surge_watts;

        for ($h = 0; $h < 24; $h++) {
            if (!empty($hourlyUsage[$h])) $hourly_load[$h] += $watts;
        }

        $startTime = 0; $endTime = 24;
        for ($h = 0;  $h < 24; $h++)  { if (!empty($hourlyUsage[$h])) { $startTime = $h; break; } }
        for ($h = 23; $h >= 0; $h--)  { if (!empty($hourlyUsage[$h])) { $endTime   = $h + 1; break; } }

        $image_path = $app['image_path'] ?? '';
        if (!empty($image_path)) {
            $image_path = str_replace('../', '', $image_path);
            if (strpos($image_path, 'uploads/') !== 0) $image_path = 'uploads/' . $image_path;
        }

        $appliance_details[] = [
            'name_en'              => $app['name_en'],
            'name_ur'              => $app['name_en'],  // No Urdu for international
            'icon'                 => $app['icon'],
            'image_path'           => $image_path,
            'quantity'             => $quantity,
            'load_factor'          => $load_factor_pct,
            'hours'                => $hours,
            'startTime'            => $startTime,
            'endTime'              => $endTime,
            'hourlyUsage'          => $hourlyUsage,
            'watt_per_unit_raw'    => $app['watt_typical'],
            'watt_per_unit'        => $watts_per_unit,
            'total_watts'          => $watts,
            'surge_watts_per_unit' => intval($app['surge_load_watts'] ?? 0),
            'total_surge_watts'    => $surge_watts,
            'daily_wh'             => $watts * $hours,
        ];
    }

    if ($total_load_watts <= 0) {
        respond_json(['success' => false, 'message' => 'No valid appliances found.'], 400);
        exit;
    }

    $peak_load_watts  = max($hourly_load) ?: $total_load_watts;
    $daily_energy_kwh = $total_daily_wh / 1000;

    // ── STEP 2: Load Shape ────────────────────────────────────────────────────
    $peak_window_avg   = 0;
    $peak_window_start = 0;
    for ($h = 0; $h < 22; $h++) {
        $avg = ($hourly_load[$h] + $hourly_load[$h+1] + $hourly_load[$h+2]) / 3;
        if ($avg > $peak_window_avg) { $peak_window_avg = $avg; $peak_window_start = $h; }
    }

    $active_hours = 0; $solar_hours_active = 0;
    for ($h = 0; $h < 24; $h++) {
        if ($hourly_load[$h] > $peak_load_watts * 0.5) {
            $active_hours++;
            if ($h >= 7 && $h <= 17) $solar_hours_active++;
        }
    }

    $required_continuous_watts = (int)ceil($peak_load_watts * 1.05);
    $required_inverter_watts   = max(MIN_INVERTER_WATTS, $required_continuous_watts);

    // ── STEP 3: Night Load ────────────────────────────────────────────────────
    $night_wh = 0; $night_active_count = 0;
    $night_hours = array_merge(range(18, 23), range(0, 5));
    foreach ($night_hours as $h) {
        if ($hourly_load[$h] > 0) { $night_wh += $hourly_load[$h]; $night_active_count++; }
    }

    if ($night_wh > 0 && $night_active_count > 0) {
        $avg_night_load_w   = $night_wh / $night_active_count;
        $night_load_profile = 'measured';
    } else {
        $avg_night_load_w   = $peak_load_watts * 0.30;
        $night_load_profile = 'estimated_daytime_only';
    }

    $battery_recharge_kwh = ($avg_night_load_w * $backup_hours) / 1000;

    error_log("v10.1 STEP3: peak={$peak_load_watts}W, req_inv={$required_inverter_watts}W, surge={$peak_surge_load}W");

    // ── STEP 4: Fetch Panels ──────────────────────────────────────────────────
    error_log("v10.1 STEP4: Fetching panels");
    $stmt = $db->prepare("
        SELECT p.*, COALESCE(c.name, 'Unknown') AS company_name
        FROM panels p
        LEFT JOIN companies c ON p.company_id = c.id
        WHERE p.is_active = 1
          AND p.wattage > 0
        ORDER BY p.wattage ASC, p.price_usd ASC
        LIMIT 80
    ");
    $stmt->execute();
    $available_panels = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($available_panels)) {
        respond_json(['success' => false, 'error' => 'no_panels', 'message' => 'No solar panels in database.']);
        exit;
    }
    error_log("v10.1 STEP4: Found " . count($available_panels) . " panels");

    // ── STEP 5: Build Inverter Lists (all voltage classes, panel-compatible) ─
    error_log("v10.2 STEP5: Building inverter lists (all voltage classes)");
    $non_bms_inverters = fetchCompatibleInverters(
        $db, $required_inverter_watts, 0, $peak_surge_load, $three_phase, $available_panels, 15
    );
    $bms_inverters = fetchCompatibleInverters(
        $db, $required_inverter_watts, 1, $peak_surge_load, $three_phase, $available_panels, 15
    );
    error_log("v10.2 STEP5: non_bms_inv=" . count($non_bms_inverters) . " bms_inv=" . count($bms_inverters));

    if (empty($non_bms_inverters) && empty($bms_inverters)) {
        respond_json(['success' => false, 'error' => 'no_inverters',
            'message' => "No inverters found for {$required_inverter_watts}W. non_bms=" . count($non_bms_inverters) . " bms=" . count($bms_inverters)]);
        exit;
    }

    // ── STEP 6: Build All Three Categories ───────────────────────────────────
    error_log("v10.1 STEP6: Building category 1 (Traditional)");
    $cat1_options = buildCategoryOptions(
        $db, $non_bms_inverters, ['lead-acid'], false,
        $backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
        $peak_sun_hours, $ambient_temp_c, $available_panels, $peak_surge_load
    );
    error_log("v10.1 STEP6: cat1=" . count($cat1_options));

    error_log("v10.1 STEP6: Building category 2 (Maintenance Free)");
    $cat2_options = buildCategoryOptions(
        $db, $non_bms_inverters, ['gel', 'agm'], false,
        $backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
        $peak_sun_hours, $ambient_temp_c, $available_panels, $peak_surge_load
    );
    error_log("v10.1 STEP6: cat2=" . count($cat2_options));

    error_log("v10.1 STEP6: Building category 3 (Premium BMS)");
    $cat3_options = buildCategoryOptions(
        $db, $bms_inverters, ['lithium', 'lfp'], true,
        $backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
        $peak_sun_hours, $ambient_temp_c, $available_panels, $peak_surge_load
    );
    error_log("v10.1 STEP6: cat3=" . count($cat3_options));

    // ── STEP 7: Respond ───────────────────────────────────────────────────────
    $categories = [
        [
            'category_id'          => 'traditional',
            'category_name'        => '🔧 Traditional',
            'category_description' => 'Non-BMS Inverter + Lead-Acid / Tubular Battery',
            'type'        => 'Non-BMS',
            'battery_types'        => 'Lead-Acid or Tubular',
            'best_for'             => 'Lowest upfront cost, proven technology, widely available, easiest to service',
            'trade_offs'           => 'Requires periodic water topping, shorter cycle life (~500 cycles), heavier',
            'options'              => $cat1_options,
            'has_options'          => !empty($cat1_options),
            'empty_message'        => 'No Lead-Acid/Tubular options. Ensure non-BMS inverters + Lead-Acid batteries exist in DB.',
        ],
        [
            'category_id'          => 'maintenance_free',
            'category_name'        => '💧 Maintenance Free',
            'category_description' => 'Non-BMS Inverter + Sealed Dry / Gel / AGM Battery',
            'type'        => 'Non-BMS',
            'battery_types'        => 'Dry, Gel, AGM, or VRLA (sealed)',
            'best_for'             => 'Zero maintenance, sealed for indoor safety, no acid fumes',
            'trade_offs'           => 'Slightly higher cost than tubular; similar ~600 cycle life',
            'options'              => $cat2_options,
            'has_options'          => !empty($cat2_options),
            'empty_message'        => 'No Dry/Gel/AGM options. Ensure non-BMS inverters + sealed batteries exist in DB.',
        ],
        [
            'category_id'          => 'premium_bms',
            'category_name'        => '⚡ Premium Smart (BMS)',
            'category_description' => 'BMS Hybrid Inverter + Lithium / LiFePO4 Battery',
            'type'        => 'BMS Hybrid',
            'battery_types'        => 'Lithium LiFePO4 with BMS',
            'best_for'             => 'Longest life (3000–6000 cycles), smart monitoring, best 10-year ROI',
            'trade_offs'           => 'Highest upfront cost; requires BMS-compatible inverter',
            'options'              => $cat3_options,
            'has_options'          => !empty($cat3_options),
            'empty_message'        => 'No BMS/Lithium options. Ensure BMS inverters + LiFePO4 batteries exist in DB.',
        ],
    ];

    // Determine the dominant system voltage from available options for the load_analysis
    $dominant_voltage = 48; // default
    $dominant_vdc_type = '48V';
    // Pick from the first available category that has options
    foreach ([$cat1_options, $cat2_options, $cat3_options] as $opts) {
        if (!empty($opts)) {
            $dominant_voltage = $opts[0]['system_voltage'] ?? 48;
            $dominant_vdc_type = ($dominant_voltage <= 12 ? '12V' : ($dominant_voltage <= 24 ? '24V' : '48V'));
            break;
        }
    }

    $response = [
        'success' => true,
        'version' => 'v10.3',
        'load_analysis' => [
            'total_load_watts'        => $total_load_watts,
            'peak_load_watts'         => $peak_load_watts,
            'peak_surge_load_watts'   => $peak_surge_load,
            'daily_energy_kwh'        => round($daily_energy_kwh, 2),
            'required_inverter_watts' => $required_inverter_watts,
            'backup_hours_requested'  => $backup_hours,
            'avg_night_load_w'        => round($avg_night_load_w, 1),
            'night_load_profile'      => $night_load_profile,
            'battery_recharge_kwh'    => round($battery_recharge_kwh, 2),
            'peak_sun_hours_used'     => $peak_sun_hours,
            'ambient_temp_c'          => $ambient_temp_c,
            'grid_voltage_vac'        => $grid_voltage_vac,
            'grid_frequency_hz'       => $grid_frequency,
            'three_phase'             => $three_phase,
            'peak_window_start_hour'  => $peak_window_start,
            'peak_window_avg_watts'   => round($peak_window_avg),
            'active_hours_count'      => $active_hours,
            'solar_overlap_hours'     => $solar_hours_active,
            'system_voltage'          => $dominant_voltage,
            'vdc_type'           => $dominant_vdc_type,
            'hourly_load'             => $hourly_load,
            'appliance_details'       => $appliance_details,
        ],
        'categories'    => $categories,
        'total_options' => count($cat1_options) + count($cat2_options) + count($cat3_options),
        'debug' => [
            'non_bms_inverters'  => count($non_bms_inverters),
            'bms_inverters'      => count($bms_inverters),
            'panels_evaluated'   => count($available_panels),
            'cat1_options'       => count($cat1_options),
            'cat2_options'       => count($cat2_options),
            'cat3_options'       => count($cat3_options),
            'city_enhanced'      => ($city_id_input > 0),
            'params_source'      => $enhanced_params['source'] ?? 'defaults',
        ],
    ];

    // Phase 7: Enhance with city-specific solar intelligence
    if ($city_id_input > 0) {
        $response = $enhancer->enhanceRecommendation($response);
    }

    respond_json($response);

} catch (PDOException $e) {
    error_log("v10.1 PDOException: " . $e->getMessage() . "\n" . $e->getTraceAsString());
    respond_json([
        'success' => false,
        'error'   => 'db_error',
        'message' => 'Database error: ' . $e->getMessage(),
    ], 500);
} catch (Exception $e) {
    error_log("v10.1 Exception: " . $e->getMessage() . "\n" . $e->getTraceAsString());
    respond_json([
        'success' => false,
        'error'   => 'server_error',
        'message' => 'Server error: ' . $e->getMessage(),
    ], 500);
}