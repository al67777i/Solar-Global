<?php
/**
 * Cron: Check Subscriptions
 * Run daily — checks for expired subscriptions, sets grace periods, inserts notifications.
 *
 * Schedule: 0 0 * * * php /path/to/solarglobal/cron/check_subscriptions.php
 *
 * Logic:
 * 1. Active subscriptions past expiry → set to 'expired', start grace period
 * 2. Grace period expired → notify store hidden
 * 3. Subscriptions expiring in 7 days or 3 days → warning notification
 */

require_once __DIR__ . '/../includes/db.php';

$db = getDB();
$now = date('Y-m-d H:i:s');
$processed = [];

// Load grace period setting
$graceDays = 5;
try {
    $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'subscription_grace_period_days'");
    $stmt->execute();
    $val = $stmt->fetchColumn();
    if ($val !== false) $graceDays = (int)$val;
} catch (Exception $e) {}

/**
 * Insert a notification
 */
function notify($db, string $userType, int $userId, string $type, string $title, string $message, ?string $link = null): void {
    try {
        $stmt = $db->prepare("
            INSERT INTO notifications (user_type, user_id, type, title, message, link, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$userType, $userId, $type, $title, $message, $link]);
    } catch (Exception $e) {
        // Silently fail — notifications are non-critical
    }
}

// ════════════════════════════════════════════════════════════════
// Process both dealers and installers
// ════════════════════════════════════════════════════════════════

$entities = [
    ['table' => 'dealers', 'type' => 'dealer', 'sub_page' => '/solarglobal/dealer/subscription.php'],
    ['table' => 'installers', 'type' => 'installer', 'sub_page' => '/solarglobal/installer/subscription.php'],
];

foreach ($entities as $entity) {
    $table = $entity['table'];
    $userType = $entity['type'];
    $subPage = $entity['sub_page'];

    // ─── 1. Expire active subscriptions that are past their expiry date ───
    try {
        $stmt = $db->prepare("
            SELECT id, business_name, subscription_expires_at
            FROM {$table}
            WHERE subscription_status = 'active'
              AND subscription_expires_at IS NOT NULL
              AND subscription_expires_at < NOW()
        ");
        $stmt->execute();
        $expired = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($expired as $e) {
            $graceEnd = date('Y-m-d H:i:s', strtotime($e['subscription_expires_at']) + ($graceDays * 86400));

            $db->prepare("
                UPDATE {$table}
                SET subscription_status = 'expired',
                    grace_period_ends_at = ?
                WHERE id = ? AND subscription_status = 'active'
            ")->execute([$graceEnd, $e['id']]);

            notify($db, $userType, $e['id'], 'subscription_expired',
                'Subscription Expired',
                "Your subscription has expired. You have {$graceDays} days to renew before your store is hidden from customers.",
                $subPage);

            $processed[] = "EXPIRED: {$table} #{$e['id']} ({$e['business_name']}) — grace until {$graceEnd}";
        }
    } catch (Exception $ex) {
        $processed[] = "ERROR expiring {$table}: " . $ex->getMessage();
    }

    // ─── 2. Grace period ended — notify store is now hidden ───
    try {
        $stmt = $db->prepare("
            SELECT id, business_name
            FROM {$table}
            WHERE subscription_status = 'expired'
              AND grace_period_ends_at IS NOT NULL
              AND grace_period_ends_at < NOW()
              AND grace_period_ends_at > DATE_SUB(NOW(), INTERVAL 1 DAY)
        ");
        $stmt->execute();
        $graceEnded = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($graceEnded as $g) {
            notify($db, $userType, $g['id'], 'store_hidden',
                'Store Hidden from Customers',
                'Your grace period has ended. Your store is no longer visible to customers. Subscribe now to restore visibility.',
                $subPage);

            $processed[] = "GRACE ENDED: {$table} #{$g['id']} ({$g['business_name']})";
        }
    } catch (Exception $ex) {
        $processed[] = "ERROR grace check {$table}: " . $ex->getMessage();
    }

    // ─── 3. Subscriptions expiring in 7 days — warning ───
    try {
        $stmt = $db->prepare("
            SELECT id, business_name, subscription_expires_at
            FROM {$table}
            WHERE subscription_status = 'active'
              AND subscription_expires_at IS NOT NULL
              AND subscription_expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)
              AND subscription_expires_at > DATE_ADD(NOW(), INTERVAL 3 DAY)
        ");
        $stmt->execute();
        $expiring7 = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($expiring7 as $w) {
            $daysLeft = max(1, (int)ceil((strtotime($w['subscription_expires_at']) - time()) / 86400));

            // Avoid duplicate notifications: check if we already sent one today
            $chk = $db->prepare("
                SELECT COUNT(*) FROM notifications
                WHERE user_type = ? AND user_id = ? AND type = 'subscription_expiring'
                  AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)
            ");
            $chk->execute([$userType, $w['id']]);
            if ($chk->fetchColumn() > 0) continue;

            notify($db, $userType, $w['id'], 'subscription_expiring',
                'Subscription Expiring Soon',
                "Your subscription expires in {$daysLeft} days. Renew now to keep your store visible.",
                $subPage);

            $processed[] = "WARNING 7d: {$table} #{$w['id']} ({$w['business_name']}) — {$daysLeft} days left";
        }
    } catch (Exception $ex) {
        $processed[] = "ERROR 7d warning {$table}: " . $ex->getMessage();
    }

    // ─── 4. Subscriptions expiring in 3 days — urgent warning ───
    try {
        $stmt = $db->prepare("
            SELECT id, business_name, subscription_expires_at
            FROM {$table}
            WHERE subscription_status = 'active'
              AND subscription_expires_at IS NOT NULL
              AND subscription_expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 3 DAY)
        ");
        $stmt->execute();
        $expiring3 = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($expiring3 as $u) {
            $daysLeft = max(1, (int)ceil((strtotime($u['subscription_expires_at']) - time()) / 86400));

            $chk = $db->prepare("
                SELECT COUNT(*) FROM notifications
                WHERE user_type = ? AND user_id = ? AND type = 'subscription_urgent'
                  AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)
            ");
            $chk->execute([$userType, $u['id']]);
            if ($chk->fetchColumn() > 0) continue;

            notify($db, $userType, $u['id'], 'subscription_urgent',
                'Subscription Expiring in ' . $daysLeft . ' Day(s)!',
                "Your subscription expires very soon. Renew immediately to avoid losing visibility.",
                $subPage);

            $processed[] = "URGENT 3d: {$table} #{$u['id']} ({$u['business_name']}) — {$daysLeft} days left";
        }
    } catch (Exception $ex) {
        $processed[] = "ERROR 3d warning {$table}: " . $ex->getMessage();
    }
}

// ════════════════════════════════════════════════════════════════
// OUTPUT (for manual runs / debugging)
// ════════════════════════════════════════════════════════════════

if (php_sapi_name() === 'cli') {
    echo "=== Subscription Check (" . date('Y-m-d H:i:s') . ") ===\n";
    foreach ($processed as $p) echo "  $p\n";
    echo "Done. Processed " . count($processed) . " items.\n";
} else {
    echo "<!DOCTYPE html><html><head><title>Subscription Check</title></head><body>";
    echo "<h1>Subscription Check Cron</h1><pre>\n";
    echo "Run at: " . date('Y-m-d H:i:s') . "\n\n";
    foreach ($processed as $p) echo "$p\n";
    echo "\nProcessed " . count($processed) . " items.\n";
    echo "</pre></body></html>";
}
