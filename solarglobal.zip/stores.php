<?php
/**
 * Browse Solar Stores (Dealers) by Location
 * Public page with map + store cards, AJAX-powered location search
 */
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';

$db = getDB();
$page_title = 'Solar Stores & Dealers';
$page_description = 'Find authorized solar product dealers and stores near you. Compare prices on inverters, batteries, and solar panels from verified sellers.';
$current_page = 'stores';

// Google Maps API key — try system_settings first, then hardcoded fallback
$maps_key = get_system_setting('google_maps_api_key', '');
// No hardcoded fallback — key must be set in Admin → Settings

// Track visitor
trackVisitor($db);

// ─── AJAX endpoint: search stores ───
if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json; charset=utf-8');

    if (!rate_limit('stores_ajax', 30, 60)) {
        respond_rate_limited();
    }

    $lat     = isset($_GET['lat']) ? floatval($_GET['lat']) : null;
    $lng     = isset($_GET['lng']) ? floatval($_GET['lng']) : null;
    $radius  = max(10, min(100, (int)($_GET['radius'] ?? 50)));
    $country = preg_match('/^[A-Z]{2}$/', $_GET['country'] ?? '') ? $_GET['country'] : '';

    // If no country provided, try IP detection
    if (empty($country)) {
        $country = get_user_country_code();
        if ($country === 'US' && empty($_COOKIE['sg_location'])) $country = ''; // Don't assume US
    }

    if (!$country) {
        echo json_encode(['stores' => [], 'count' => 0]);
        exit;
    }

    // Haversine query with country + subscription filter
    require_once __DIR__ . '/includes/subscription_helpers.php';
    $subFilter = get_dealer_subscription_filter('d');

    if ($lat && $lng) {
        // Location available: sort by distance within radius
        $sql = "SELECT d.id, d.business_name, d.owner_name, d.phone, d.email, d.address,
                       d.city, d.country_code, d.latitude, d.longitude, d.logo_path,
                       d.avg_rating, d.total_reviews, d.subscription_status,
                       (6371 * ACOS(
                           COS(RADIANS(:lat1)) * COS(RADIANS(d.latitude)) * COS(RADIANS(d.longitude) - RADIANS(:lng1)) +
                           SIN(RADIANS(:lat2)) * SIN(RADIANS(d.latitude))
                       )) AS distance_km
                FROM dealers d
                WHERE {$subFilter}
                  AND d.is_live = 1
                  AND d.country_code = :country
                  AND d.latitude IS NOT NULL AND d.longitude IS NOT NULL
                HAVING distance_km <= :radius
                ORDER BY d.avg_rating DESC, distance_km ASC
                LIMIT 60";

        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':lat1' => $lat, ':lng1' => $lng, ':lat2' => $lat,
            ':country' => $country, ':radius' => $radius
        ]);
    } else {
        // No location: show all stores in country sorted by rating
        $sql = "SELECT d.id, d.business_name, d.owner_name, d.phone, d.email, d.address,
                       d.city, d.country_code, d.latitude, d.longitude, d.logo_path,
                       d.avg_rating, d.total_reviews, d.subscription_status,
                       NULL AS distance_km
                FROM dealers d
                WHERE {$subFilter}
                  AND d.is_live = 1
                  AND d.country_code = :country
                ORDER BY d.avg_rating DESC, d.business_name ASC
                LIMIT 60";

        $stmt = $db->prepare($sql);
        $stmt->execute([':country' => $country]);
    }
    $dealers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Product summaries per dealer
    if (!empty($dealers)) {
        $ids = array_column($dealers, 'id');
        $ph  = implode(',', array_fill(0, count($ids), '?'));
        $ps  = $db->prepare("SELECT dp.dealer_id, dp.product_type, COUNT(*) as cnt
                              FROM dealer_products dp
                              WHERE dp.dealer_id IN ($ph) AND dp.is_active = 1
                              AND (
                                  (dp.product_type = 'inverter' AND EXISTS (SELECT 1 FROM inverters WHERE id = dp.product_id)) OR
                                  (dp.product_type = 'battery' AND EXISTS (SELECT 1 FROM batteries WHERE id = dp.product_id)) OR
                                  (dp.product_type = 'panel' AND EXISTS (SELECT 1 FROM panels WHERE id = dp.product_id)) OR
                                  (dp.product_type = 'installation_appliance' AND EXISTS (SELECT 1 FROM installation_appliances WHERE id = dp.product_id))
                              )
                              GROUP BY dp.dealer_id, dp.product_type");
        $ps->execute($ids);
        $summaries = [];
        foreach ($ps->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $summaries[$r['dealer_id']][$r['product_type']] = (int)$r['cnt'];
        }

        foreach ($dealers as &$d) {
            $d['product_summary'] = $summaries[$d['id']] ?? [];
            $d['logo_url'] = !empty($d['logo_path']) ? get_image_url($d['logo_path']) : '';
        }
        unset($d);
    }

    // Build clean output
    $output = [];
    $type_labels = [
        'inverter' => 'Inverters',
        'battery'  => 'Batteries',
        'panel'    => 'Panels',
        'installation_appliance' => 'Appliances'
    ];

    foreach ($dealers as $d) {
        $products = [];
        $total_products = 0;
        foreach ($type_labels as $tk => $tl) {
            $cnt = $d['product_summary'][$tk] ?? 0;
            if ($cnt > 0) {
                $products[] = ['type' => $tk, 'label' => $tl, 'count' => $cnt];
                $total_products += $cnt;
            }
        }

        $output[] = [
            'id'             => (int)$d['id'],
            'name'           => $d['business_name'],
            'city'           => $d['city'] ?? '',
            'address'        => $d['address'] ?? '',
            'country'        => $d['country_code'] ?? '',
            'lat'            => (float)$d['latitude'],
            'lng'            => (float)$d['longitude'],
            'logo'           => $d['logo_url'] ?? '',
            'rating'         => round(floatval($d['avg_rating'] ?? 0), 1),
            'reviews'        => (int)($d['total_reviews'] ?? 0),
            'distance'       => round((float)$d['distance_km'], 1),
            'products'       => $products,
            'total_products' => $total_products,
        ];
    }

    echo json_encode(['stores' => $output, 'count' => count($output)]);
    exit;
}

// ─── GET params for shareable URLs ───
$init_lat     = isset($_GET['lat']) ? floatval($_GET['lat']) : '';
$init_lng     = isset($_GET['lng']) ? floatval($_GET['lng']) : '';
$init_radius  = isset($_GET['radius']) ? max(10, min(100, (int)$_GET['radius'])) : 50;
$init_loc     = sanitize($_GET['location'] ?? '');
$init_country = sanitize($_GET['country'] ?? '');

require_once 'includes/header.php';
?>

<style>
/* ═══════════════════════════════════════════════
   Stores Page — Complete Styles
   ═══════════════════════════════════════════════ */

/* Hero */
.st-hero {
    position: relative;
    background: linear-gradient(160deg, #0a0a0a 0%, #0f1520 30%, #111827 60%, #0a0a0a 100%);
    padding: 36px 24px 28px;
    text-align: center;
    color: #fff;
    font-family: 'Inter', sans-serif;
    overflow: hidden;
    border-bottom: 2px solid rgba(245,158,11,0.15);
}
.st-hero::before {
    content: '';
    position: absolute;
    top: -40%;
    right: -15%;
    width: 500px;
    height: 500px;
    background: radial-gradient(circle, rgba(245,158,11,0.07) 0%, transparent 70%);
    pointer-events: none;
}
.st-hero::after {
    content: '';
    position: absolute;
    inset: 0;
    background-image:
        linear-gradient(rgba(255,255,255,0.015) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,0.015) 1px, transparent 1px);
    background-size: 50px 50px;
    pointer-events: none;
}
/* Floating accent shapes */
.st-hero-shape {
    position: absolute;
    pointer-events: none;
    z-index: 0;
}
.st-hero-glow {
    position: absolute;
    border-radius: 50%;
    filter: blur(60px);
    pointer-events: none;
    z-index: 0;
}
.st-hero-glow--amber {
    width: 280px; height: 280px;
    background: rgba(245,158,11,0.05);
    top: -15%; left: -5%;
}
.st-hero-glow--teal {
    width: 180px; height: 180px;
    background: rgba(52,211,153,0.04);
    bottom: -15%; right: 15%;
}
.st-hero-inner {
    position: relative;
    z-index: 2;
    max-width: 720px;
    margin: 0 auto;
}
.st-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 14px;
    background: rgba(245,158,11,0.1);
    border: 1px solid rgba(245,158,11,0.25);
    border-radius: 20px;
    font-size: 0.72rem;
    font-weight: 600;
    color: #F59E0B;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 14px;
}
.st-hero h1 {
    font-size: 2rem;
    font-weight: 800;
    color: #ffffff;
    margin: 0 0 8px;
    letter-spacing: -0.03em;
    line-height: 1.15;
}
.st-hero h1 span {
    background: linear-gradient(135deg, #F59E0B, #FBBF24);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
.st-hero p {
    color: #a8a8b3;
    font-size: 0.92rem;
    margin: 0 auto 22px;
    max-width: 520px;
    line-height: 1.6;
}

/* Search bar in hero */
.st-search-bar {
    max-width: 680px;
    margin: 0 auto;
    display: flex;
    gap: 12px;
    align-items: stretch;
}
.st-search-input-wrap {
    flex: 1;
    position: relative;
}
.st-search-input-wrap > svg {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #F59E0B;
    pointer-events: none;
    z-index: 2;
}
/* Autocomplete dropdown */
.st-autocomplete {
    position: absolute;
    top: calc(100% + 6px);
    left: 0;
    right: 0;
    background: #1a1d27;
    border: 2px solid rgba(245,158,11,0.25);
    border-radius: 14px;
    box-shadow: 0 12px 40px rgba(0,0,0,0.5);
    z-index: 100;
    overflow: hidden;
    display: none;
    backdrop-filter: blur(12px);
}
.st-autocomplete.open { display: block; }
.st-ac-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    cursor: pointer;
    transition: background 0.15s;
    border-bottom: 1px solid rgba(255,255,255,0.04);
}
.st-ac-item:last-child { border-bottom: none; }
.st-ac-item:hover, .st-ac-item.active {
    background: rgba(245,158,11,0.1);
}
.st-ac-icon {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    background: rgba(245,158,11,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    color: #F59E0B;
}
.st-ac-text {
    flex: 1;
    min-width: 0;
}
.st-ac-name {
    font-size: 0.85rem;
    font-weight: 600;
    color: #f1f5f9;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.st-ac-detail {
    font-size: 0.72rem;
    color: #71717a;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-top: 1px;
}
.st-ac-loading {
    padding: 16px;
    text-align: center;
    color: #71717a;
    font-size: 0.8rem;
}
.st-ac-loading .spinner {
    display: inline-block;
    width: 16px;
    height: 16px;
    border: 2px solid rgba(245,158,11,0.2);
    border-top-color: #F59E0B;
    border-radius: 50%;
    animation: st-spin 0.6s linear infinite;
    vertical-align: middle;
    margin-right: 8px;
}
#st-location-input {
    width: 100%;
    padding: 14px 46px 14px 42px;
    border: 2px solid rgba(245,158,11,0.2);
    border-radius: 14px;
    font-size: 0.95rem;
    font-family: inherit;
    font-weight: 500;
    color: #f1f5f9;
    background: rgba(255,255,255,0.06);
    transition: all 0.3s cubic-bezier(.4,0,.2,1);
    box-sizing: border-box;
    backdrop-filter: blur(8px);
}
#st-location-input::placeholder {
    color: #71717a;
    font-weight: 400;
}
#st-location-input:focus {
    outline: none;
    border-color: #F59E0B;
    background: rgba(255,255,255,0.1);
    box-shadow: 0 0 0 4px rgba(245,158,11,0.12), 0 8px 32px rgba(245,158,11,0.08);
    transform: scale(1.01);
}
.st-geolocate-btn {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(245,158,11,0.08);
    border: 1px solid rgba(245,158,11,0.2);
    cursor: pointer;
    color: #F59E0B;
    padding: 8px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    transition: all 0.2s;
}
.st-geolocate-btn:hover {
    color: #FBBF24;
    background: rgba(245,158,11,0.2);
    border-color: rgba(245,158,11,0.4);
    box-shadow: 0 0 12px rgba(245,158,11,0.15);
}

/* Radius control in hero */
.st-radius-wrap {
    display: flex;
    align-items: center;
    gap: 10px;
    background: rgba(255,255,255,0.06);
    border: 2px solid rgba(245,158,11,0.2);
    border-radius: 14px;
    padding: 0 18px;
    min-width: 180px;
    backdrop-filter: blur(8px);
    transition: border-color 0.3s;
}
.st-radius-wrap:hover {
    border-color: rgba(245,158,11,0.4);
}
.st-radius-label {
    font-size: 0.7rem;
    font-weight: 600;
    color: #a1a1aa;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    white-space: nowrap;
}
.st-radius-slider {
    -webkit-appearance: none;
    appearance: none;
    width: 90px;
    height: 6px;
    border-radius: 3px;
    background: linear-gradient(90deg, rgba(245,158,11,0.3), rgba(255,255,255,0.08));
    outline: none;
    cursor: pointer;
    transition: background 0.2s;
}
.st-radius-slider:hover {
    background: linear-gradient(90deg, rgba(245,158,11,0.5), rgba(255,255,255,0.15));
}
.st-radius-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    border: 3px solid #ffffff;
    box-shadow: 0 2px 10px rgba(245,158,11,0.4);
    cursor: pointer;
    transition: transform 0.15s, box-shadow 0.15s;
}
.st-radius-slider::-webkit-slider-thumb:hover {
    transform: scale(1.15);
    box-shadow: 0 2px 14px rgba(245,158,11,0.6);
}
.st-radius-slider::-moz-range-thumb {
    width: 22px;
    height: 22px;
    border-radius: 50%;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    border: 3px solid #ffffff;
    box-shadow: 0 2px 10px rgba(245,158,11,0.4);
    cursor: pointer;
}
.st-radius-value {
    font-size: 0.85rem;
    font-weight: 700;
    color: #F59E0B;
    min-width: 50px;
    text-align: center;
    background: rgba(245,158,11,0.08);
    padding: 3px 8px;
    border-radius: 6px;
    letter-spacing: 0.02em;
}

/* Country tag */
.st-country-tag {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 12px;
    padding: 5px 14px;
    background: rgba(245, 158, 11, 0.15);
    border: 1px solid rgba(245, 158, 11, 0.3);
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    color: #FCD34D;
    transition: opacity 0.3s;
}
.st-country-tag.hidden { display: none; }

/* Main layout */
.st-main {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 20px 60px;
}

/* Split layout: map + list */
.st-workspace {
    display: grid;
    grid-template-columns: 60% 40%;
    gap: 0;
    margin-top: 20px;
    min-height: 600px;
    border: 2px solid #E2E8F0;
    border-radius: 16px;
    overflow: hidden;
    background: #ffffff;
    box-shadow: 0 4px 24px rgba(0,0,0,0.06);
}

/* Map panel */
.st-map-panel {
    position: relative;
    background: #F1F5F9;
}
#stores-map {
    width: 100%;
    height: 100%;
    min-height: 600px;
}

/* Store list panel */
.st-list-panel {
    display: flex;
    flex-direction: column;
    border-left: 2px solid #E2E8F0;
    max-height: 700px;
}
.st-list-header {
    padding: 16px 20px;
    border-bottom: 1px solid #E2E8F0;
    background: #F8FAFC;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-shrink: 0;
}
.st-list-header h2 {
    font-size: 1rem;
    font-weight: 700;
    color: #1E293B;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}
.st-list-count {
    font-size: 0.75rem;
    font-weight: 600;
    color: #64748B;
    background: #F1F5F9;
    padding: 3px 10px;
    border-radius: 12px;
}
.st-list-scroll {
    flex: 1;
    overflow-y: auto;
    padding: 12px;
    display: flex;
    flex-direction: column;
    gap: 10px;
}
.st-list-scroll::-webkit-scrollbar {
    width: 6px;
}
.st-list-scroll::-webkit-scrollbar-track {
    background: #F1F5F9;
}
.st-list-scroll::-webkit-scrollbar-thumb {
    background: #CBD5E1;
    border-radius: 3px;
}

/* Store card */
.sc {
    background: #ffffff;
    border: 2px solid #E2E8F0;
    border-radius: 12px;
    padding: 16px;
    cursor: pointer;
    transition: border-color 0.2s, box-shadow 0.25s, transform 0.15s;
}
.sc:hover {
    border-color: #F59E0B;
    box-shadow: 0 4px 16px rgba(245, 158, 11, 0.1);
    transform: translateY(-1px);
}
.sc.highlighted {
    border-color: #F59E0B;
    box-shadow: 0 4px 20px rgba(245, 158, 11, 0.18);
    background: #FFFBEB;
}

.sc-top {
    display: flex;
    gap: 12px;
    margin-bottom: 10px;
}
.sc-logo {
    width: 48px;
    height: 48px;
    border-radius: 10px;
    background: #F1F5F9;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    flex-shrink: 0;
    border: 1px solid #E2E8F0;
}
.sc-logo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.sc-logo-placeholder {
    color: #94A3B8;
}
.sc-info {
    flex: 1;
    min-width: 0;
}
.sc-info h3 {
    font-size: 0.875rem;
    font-weight: 700;
    color: #1E293B;
    margin: 0 0 3px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.sc-meta {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.7rem;
    color: #64748B;
}
.sc-distance {
    font-weight: 700;
    color: #D97706;
    background: #FEF3C7;
    padding: 1px 7px;
    border-radius: 4px;
    font-size: 0.65rem;
}

/* Rating */
.sc-rating {
    display: flex;
    align-items: center;
    gap: 5px;
    margin-bottom: 10px;
}
.sc-stars {
    display: flex;
    gap: 1px;
}
.sc-star-filled { color: #F59E0B; }
.sc-star-empty { color: #E2E8F0; }
.sc-rating-text {
    font-size: 0.7rem;
    color: #64748B;
    font-weight: 500;
}

/* Product tags */
.sc-products {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
    margin-bottom: 12px;
}
.sc-prod-tag {
    padding: 2px 8px;
    background: #F1F5F9;
    border-radius: 5px;
    font-size: 0.65rem;
    color: #475569;
    font-weight: 600;
}
.sc-prod-tag.empty {
    color: #94A3B8;
    font-style: italic;
    font-weight: 400;
}

/* View Store button */
.sc-view-btn {
    display: block;
    width: 100%;
    padding: 9px 14px;
    border-radius: 8px;
    font-size: 0.8rem;
    font-weight: 600;
    text-align: center;
    text-decoration: none;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    color: #ffffff;
    border: none;
    cursor: pointer;
    font-family: inherit;
    transition: opacity 0.15s, transform 0.15s;
}
.sc-view-btn:hover {
    opacity: 0.92;
    transform: translateY(-1px);
}

/* Empty / loading states */
.st-empty {
    text-align: center;
    padding: 60px 20px;
    color: #64748B;
}
.st-empty-icon {
    width: 56px;
    height: 56px;
    margin: 0 auto 14px;
    background: #F1F5F9;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #94A3B8;
}
.st-empty h3 {
    font-size: 1rem;
    color: #1E293B;
    margin: 0 0 6px;
    font-weight: 700;
}
.st-empty p {
    margin: 0 auto;
    font-size: 0.8rem;
    max-width: 300px;
    line-height: 1.6;
}

/* Skeleton loader */
.st-skel-card {
    border: 2px solid #E2E8F0;
    border-radius: 12px;
    padding: 16px;
}
.st-skel-line {
    background: linear-gradient(90deg, #E2E8F0 25%, #F1F5F9 50%, #E2E8F0 75%);
    background-size: 200% 100%;
    animation: st-shimmer 1.5s infinite;
    border-radius: 6px;
    margin-bottom: 8px;
}
@keyframes st-shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }
@keyframes st-spin { to { transform: rotate(360deg); } }

/* Loading spinner overlay on map */
.st-map-loading {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    z-index: 5;
}
.st-map-loading.hidden { display: none; }
.st-map-spinner {
    width: 36px;
    height: 36px;
    border: 3px solid #E2E8F0;
    border-top-color: #F59E0B;
    border-radius: 50%;
    animation: st-spin 0.7s linear infinite;
}
.st-map-loading-text {
    font-size: 0.8rem;
    color: #64748B;
    font-weight: 500;
    background: rgba(255,255,255,0.9);
    padding: 4px 14px;
    border-radius: 8px;
}

/* ─── Responsive ─── */
@media (max-width: 900px) {
    .st-workspace {
        grid-template-columns: 1fr;
        min-height: auto;
        border-radius: 14px;
        margin-top: 16px;
    }
    .st-list-panel {
        border-left: none;
        border-top: 2px solid #E2E8F0;
        max-height: none;
    }
    #stores-map {
        min-height: 350px;
    }
    .st-list-scroll {
        max-height: 500px;
    }
    .st-search-bar {
        flex-direction: column;
    }
    .st-radius-wrap {
        justify-content: center;
    }
}
@media (max-width: 640px) {
    .st-hero { padding: 24px 16px 20px; }
    .st-hero h1 { font-size: 1.4rem; }
    .st-hero p { font-size: 0.82rem; }
    .st-main { padding: 0 12px 40px; }
    #stores-map { min-height: 280px; }
    .st-list-scroll { padding: 8px; }
    .sc { padding: 12px; }
    .st-hero-badge { font-size: 0.65rem; }
}

/* Bottom nav spacer on mobile */
@media (max-width: 1024px) {
    .st-main { padding-bottom: 100px; }
}
</style>

<!-- Hero -->
<div class="st-hero">
    <!-- Ambient glows -->
    <div class="st-hero-glow st-hero-glow--amber"></div>
    <div class="st-hero-glow st-hero-glow--teal"></div>

    <!-- Floating SVG shapes -->
    <svg class="st-hero-shape" id="st-shape-1" style="top:12%;left:8%;opacity:0" width="40" height="40" viewBox="0 0 40 40" fill="none">
        <rect x="5" y="5" width="30" height="30" rx="8" stroke="rgba(245,158,11,0.15)" stroke-width="1.5"/>
    </svg>
    <svg class="st-hero-shape" id="st-shape-2" style="top:20%;right:10%;opacity:0" width="36" height="36" viewBox="0 0 36 36" fill="none">
        <circle cx="18" cy="18" r="14" stroke="rgba(52,211,153,0.12)" stroke-width="1.5"/>
    </svg>
    <svg class="st-hero-shape" id="st-shape-3" style="bottom:15%;left:15%;opacity:0" width="32" height="32" viewBox="0 0 32 32" fill="none">
        <polygon points="16,2 30,28 2,28" stroke="rgba(245,158,11,0.1)" stroke-width="1.5" fill="none"/>
    </svg>

    <div class="st-hero-inner">
        <div class="st-hero-badge">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            Verified Dealers
        </div>
        <h1>Find <span>Solar Stores</span> Near You</h1>
        <p>Browse verified solar equipment dealers in your area. View products, compare ratings, and visit stores.</p>

        <!-- Search bar -->
        <div class="st-search-bar">
            <div class="st-search-input-wrap">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                <input type="text" id="st-location-input" placeholder="Search city or address..." value="<?= $init_loc ?>" autocomplete="off">
                <button type="button" class="st-geolocate-btn" id="st-geolocate" title="Use my location">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 2v4m0 12v4M2 12h4m12 0h4"/></svg>
                </button>
                <div class="st-autocomplete" id="st-autocomplete"></div>
            </div>
            <div class="st-radius-wrap">
                <span class="st-radius-label">Radius</span>
                <input type="range" class="st-radius-slider" id="st-radius" min="10" max="100" step="5" value="<?= $init_radius ?>">
                <span class="st-radius-value" id="st-radius-value"><?= $init_radius ?> km</span>
            </div>
        </div>

        <!-- Country tag -->
        <div class="st-country-tag hidden" id="st-country-tag">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
            <span id="st-country-name"></span>
        </div>
    </div>
</div>

<div class="st-main">
    <!-- Split layout: Map + Store List -->
    <div class="st-workspace">
        <!-- Map -->
        <div class="st-map-panel">
            <div id="stores-map"></div>
            <div class="st-map-loading" id="st-map-loading">
                <div class="st-map-spinner"></div>
                <span class="st-map-loading-text">Detecting your location...</span>
            </div>
        </div>

        <!-- Store List -->
        <div class="st-list-panel">
            <div class="st-list-header">
                <h2>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                    Stores
                </h2>
                <span class="st-list-count" id="st-count">0 found</span>
            </div>
            <div class="st-list-scroll" id="st-list">
                <div class="st-empty" id="st-empty-state">
                    <div class="st-empty-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    </div>
                    <h3>Searching for nearby stores...</h3>
                    <p>Allow location access or search for a city to find solar stores near you.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Leaflet styles for dual-path fallback */
.st-map-panel .leaflet-container { font-family: inherit; }
.st-map-panel .leaflet-popup-content { font-family: Inter, system-ui, sans-serif; }
</style>

<script>
// Dual-path: Google Maps first, Leaflet fallback on auth failure
var stUseGoogleMaps = false;
function stGmapsReady() { stUseGoogleMaps = true; stBootMap(); }
function gm_authFailure() {
    stUseGoogleMaps = false;
    var lk = document.createElement('link');
    lk.rel = 'stylesheet';
    lk.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    document.head.appendChild(lk);
    var sc = document.createElement('script');
    sc.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    sc.onload = function() { stBootMap(); };
    document.head.appendChild(sc);
}
</script>
<?php if ($maps_key): ?>
<script async src="https://maps.googleapis.com/maps/api/js?key=<?= sanitize($maps_key) ?>&libraries=places&callback=stGmapsReady"></script>
<?php else: ?>
<!-- No Google Maps key — load Leaflet directly -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
<script>stUseGoogleMaps = false;</script>
<?php endif; ?>

<script>
(function() {
    'use strict';

    // useLeaflet is set dynamically based on which map loaded successfully
    var useLeaflet = true; // default; overridden by stBootMap()

    // ─── State ───
    var map, searchCircle, userMarker, storeMarkers = [], infoWindow;
    var searchLat = <?= $init_lat !== '' ? $init_lat : 'null' ?>;
    var searchLng = <?= $init_lng !== '' ? $init_lng : 'null' ?>;
    var searchCountry = '<?= $init_country ?>';
    var searchCountryName = '';
    var searchDebounce = null;
    var highlightedCardId = null;

    // ─── Elements ───
    var elMap         = document.getElementById('stores-map');
    var elInput       = document.getElementById('st-location-input');
    var elRadius      = document.getElementById('st-radius');
    var elRadiusVal   = document.getElementById('st-radius-value');
    var elCountryTag  = document.getElementById('st-country-tag');
    var elCountryName = document.getElementById('st-country-name');
    var elList        = document.getElementById('st-list');
    var elCount       = document.getElementById('st-count');
    var elMapLoading  = document.getElementById('st-map-loading');
    var elGeolocate   = document.getElementById('st-geolocate');

    // ─── Radius slider ───
    elRadius.addEventListener('input', function() {
        elRadiusVal.textContent = this.value + ' km';
        saveSgRadius(this.value);
        if (map && searchCircle) {
            if (useLeaflet) {
                searchCircle.setRadius(parseInt(this.value) * 1000);
                map.fitBounds(searchCircle.getBounds());
            } else {
                searchCircle.setRadius(parseInt(this.value) * 1000);
                fitMapToCircle();
            }
        }
        scheduleSearch();
    });

    // ─── Debounced search ───
    function scheduleSearch() {
        clearTimeout(searchDebounce);
        searchDebounce = setTimeout(doSearch, 600);
    }

    // ─── Geolocate button ───
    elGeolocate.addEventListener('click', function() {
        if (!navigator.geolocation) return;
        this.style.color = '#F59E0B';
        elMapLoading.classList.remove('hidden');
        navigator.geolocation.getCurrentPosition(function(pos) {
            setLocation(pos.coords.latitude, pos.coords.longitude, true);
            elGeolocate.style.color = '';
            elMapLoading.classList.add('hidden');
        }, function() {
            elGeolocate.style.color = '';
            elMapLoading.classList.add('hidden');
        });
    });

    // ─── Cookie helpers for location persistence ───
    function getSgLocation() {
        try {
            var m = document.cookie.match(/(?:^|;\s*)sg_location=([^;]*)/);
            return m ? JSON.parse(decodeURIComponent(m[1])) : null;
        } catch(e) { return null; }
    }
    function saveSgLocation(lat, lng, city, cc) {
        var d = JSON.stringify({lat:lat,lng:lng,city:city||'',country_code:cc||''});
        document.cookie = 'sg_location=' + encodeURIComponent(d) + ';path=/solarglobal/;max-age=2592000;SameSite=Lax';
    }
    function getSgRadius() {
        var m = document.cookie.match(/(?:^|;\s*)sg_radius=(\d+)/);
        return m ? parseInt(m[1]) : null;
    }
    function saveSgRadius(r) {
        document.cookie = 'sg_radius=' + r + ';path=/solarglobal/;max-age=2592000;SameSite=Lax';
    }

    // Init from cookies if no server-side location
    (function() {
        if (!searchLat && !searchLng) {
            var loc = getSgLocation();
            if (loc && loc.lat && loc.lng) {
                searchLat = loc.lat;
                searchLng = loc.lng;
                searchCountry = loc.country_code || '';
            }
        }
        var savedR = getSgRadius();
        if (savedR && elRadius) {
            elRadius.value = savedR;
            elRadiusVal.textContent = savedR + ' km';
        }
    })();

    // ─── Reverse geocode using Nominatim (for Leaflet mode) ───
    function reverseGeocodeNominatim(lat, lng, callback) {
        fetch('https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lat + '&lon=' + lng + '&zoom=10&addressdetails=1', {
            headers: { 'Accept-Language': 'en' }
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            var country = '', countryName = '', displayName = '';
            if (data && data.address) {
                country = (data.address.country_code || '').toUpperCase();
                countryName = data.address.country || '';
            }
            displayName = data.display_name || '';
            callback(country, countryName, displayName);
        })
        .catch(function() {
            callback('', '', '');
        });
    }

    // ─── Geocode search text using Nominatim (for Leaflet mode) ───
    function geocodeNominatim(query, callback) {
        fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(query) + '&limit=1&addressdetails=1', {
            headers: { 'Accept-Language': 'en' }
        })
        .then(function(r) { return r.json(); })
        .then(function(results) {
            if (results && results.length > 0) {
                var r = results[0];
                var country = (r.address && r.address.country_code) ? r.address.country_code.toUpperCase() : '';
                var countryName = (r.address && r.address.country) ? r.address.country : '';
                callback(parseFloat(r.lat), parseFloat(r.lon), country, countryName, r.display_name || '');
            } else {
                callback(null, null, '', '', '');
            }
        })
        .catch(function() {
            callback(null, null, '', '', '');
        });
    }

    // ─── Set location + reverse geocode ───
    function setLocation(lat, lng, reverseGeocode) {
        searchLat = lat;
        searchLng = lng;

        if (useLeaflet && map) {
            // Leaflet marker + circle
            if (userMarker) {
                userMarker.setLatLng([lat, lng]);
            } else {
                userMarker = L.circleMarker([lat, lng], {
                    radius: 12,
                    fillColor: '#F59E0B',
                    fillOpacity: 1,
                    color: '#ffffff',
                    weight: 3
                }).addTo(map).bindTooltip('Your Location');
            }

            if (searchCircle) {
                searchCircle.setLatLng([lat, lng]);
                searchCircle.setRadius(parseInt(elRadius.value) * 1000);
            } else {
                searchCircle = L.circle([lat, lng], {
                    radius: parseInt(elRadius.value) * 1000,
                    fillColor: '#F59E0B',
                    fillOpacity: 0.06,
                    color: '#F59E0B',
                    opacity: 0.3,
                    weight: 2
                }).addTo(map);
            }

            map.fitBounds(searchCircle.getBounds());

        } else if (!useLeaflet && map) {
            var pos = { lat: lat, lng: lng };

            if (userMarker) {
                userMarker.setPosition(pos);
            } else {
                userMarker = new google.maps.Marker({
                    position: pos,
                    map: map,
                    icon: {
                        path: google.maps.SymbolPath.CIRCLE,
                        scale: 12,
                        fillColor: '#F59E0B',
                        fillOpacity: 1,
                        strokeWeight: 3,
                        strokeColor: '#ffffff'
                    },
                    title: 'Your Location',
                    zIndex: 999
                });
            }

            if (searchCircle) {
                searchCircle.setCenter(pos);
            } else {
                searchCircle = new google.maps.Circle({
                    center: pos,
                    radius: parseInt(elRadius.value) * 1000,
                    map: map,
                    fillColor: '#F59E0B',
                    fillOpacity: 0.06,
                    strokeColor: '#F59E0B',
                    strokeOpacity: 0.3,
                    strokeWeight: 2
                });
            }

            fitMapToCircle();
        }

        if (reverseGeocode) {
            if (useLeaflet) {
                reverseGeocodeNominatim(lat, lng, function(country, countryName, displayName) {
                    searchCountry = country;
                    searchCountryName = countryName;
                    updateCountryTag(country, countryName);
                    if (displayName) elInput.value = displayName;
                    saveSgLocation(lat, lng, '', country);
                    doSearch();
                });
            } else if (typeof google !== 'undefined') {
                var geocoder = new google.maps.Geocoder();
                geocoder.geocode({ location: { lat: lat, lng: lng } }, function(results, status) {
                    if (status === 'OK' && results[0]) {
                        var country = '', countryName = '';
                        for (var i = 0; i < results[0].address_components.length; i++) {
                            var c = results[0].address_components[i];
                            if (c.types.indexOf('country') !== -1) {
                                country = c.short_name;
                                countryName = c.long_name;
                                break;
                            }
                        }
                        searchCountry = country;
                        searchCountryName = countryName;
                        updateCountryTag(country, countryName);
                        elInput.value = results[0].formatted_address || '';
                        saveSgLocation(lat, lng, '', country);
                        doSearch();
                    }
                });
            }
        } else if (searchCountry) {
            doSearch();
        }
    }

    function updateCountryTag(code, name) {
        if (code) {
            elCountryTag.classList.remove('hidden');
            elCountryName.textContent = 'Showing stores in ' + (name || code);
        } else {
            elCountryTag.classList.add('hidden');
        }
    }

    function fitMapToCircle() {
        if (map && searchCircle) {
            if (useLeaflet) {
                map.fitBounds(searchCircle.getBounds());
            } else {
                map.fitBounds(searchCircle.getBounds());
            }
        }
    }

    // ─── AJAX Search ───
    function doSearch() {
        if (!searchLat || !searchLng || !searchCountry) return;

        var radius = parseInt(elRadius.value);

        // Update URL for shareability
        var url = new URL(window.location.href);
        url.searchParams.set('lat', searchLat);
        url.searchParams.set('lng', searchLng);
        url.searchParams.set('radius', radius);
        url.searchParams.set('country', searchCountry);
        url.searchParams.set('location', elInput.value);
        window.history.replaceState({}, '', url);

        // Show skeleton
        elList.innerHTML = skeletonCards(4);

        var qs = 'ajax=1&lat=' + searchLat + '&lng=' + searchLng
               + '&radius=' + radius
               + '&country=' + encodeURIComponent(searchCountry);

        fetch('stores.php?' + qs)
            .then(function(r) { return r.json(); })
            .then(function(data) {
                renderStoreList(data.stores || [], data.count || 0, radius);
                plotStoreMarkers(data.stores || []);
            })
            .catch(function() {
                elList.innerHTML = '<div class="st-empty"><h3>Something went wrong</h3><p>Please try again.</p></div>';
                elCount.textContent = '0 found';
            });
    }

    function skeletonCards(n) {
        var h = '';
        for (var i = 0; i < n; i++) {
            h += '<div class="st-skel-card">'
               + '<div class="st-skel-line" style="width:45%;height:13px"></div>'
               + '<div class="st-skel-line" style="width:65%;height:11px"></div>'
               + '<div class="st-skel-line" style="width:50%;height:11px"></div>'
               + '<div class="st-skel-line" style="width:100%;height:34px;margin-top:12px"></div>'
               + '</div>';
        }
        return h;
    }

    // ─── Render store cards ───
    function renderStoreList(stores, count, radius) {
        elCount.textContent = count + ' found';

        if (!stores.length) {
            elList.innerHTML = '<div class="st-empty">'
                + '<div class="st-empty-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg></div>'
                + '<h3>No stores found</h3>'
                + '<p>Try increasing the search radius or searching a different location.</p></div>';
            return;
        }

        var html = '';
        stores.forEach(function(s) {
            html += storeCardHTML(s);
        });
        elList.innerHTML = html;

        // Card click -> scroll to and highlight on map
        document.querySelectorAll('.sc[data-id]').forEach(function(card) {
            card.addEventListener('mouseenter', function() {
                var id = parseInt(this.dataset.id);
                highlightMarker(id);
            });
            card.addEventListener('mouseleave', function() {
                unhighlightAll();
            });
        });
    }

    function storeCardHTML(s) {
        // Stars
        var stars = '';
        for (var i = 1; i <= 5; i++) {
            if (i <= Math.round(s.rating)) {
                stars += '<svg class="sc-star-filled" width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
            } else {
                stars += '<svg class="sc-star-empty" width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
            }
        }

        // Product tags
        var tags = '';
        if (s.products && s.products.length) {
            s.products.forEach(function(p) {
                tags += '<span class="sc-prod-tag">' + p.count + ' ' + escapeHtml(p.label) + '</span>';
            });
        } else {
            tags = '<span class="sc-prod-tag empty">No products listed</span>';
        }

        // Logo
        var logo = '';
        if (s.logo) {
            logo = '<img src="' + escapeHtml(s.logo) + '" alt="' + escapeHtml(s.name) + '">';
        } else {
            logo = '<span class="sc-logo-placeholder"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></span>';
        }

        return '<div class="sc" data-id="' + s.id + '">'
            + '<div class="sc-top">'
            +   '<div class="sc-logo">' + logo + '</div>'
            +   '<div class="sc-info">'
            +     '<h3>' + escapeHtml(s.name) + '</h3>'
            +     '<div class="sc-meta">'
            +       '<span>' + escapeHtml(s.city) + '</span>'
            +       '<span class="sc-distance">' + s.distance + ' km</span>'
            +     '</div>'
            +   '</div>'
            + '</div>'
            + '<div class="sc-rating">'
            +   '<div class="sc-stars">' + stars + '</div>'
            +   '<span class="sc-rating-text">' + s.rating + ' (' + s.reviews + ' review' + (s.reviews !== 1 ? 's' : '') + ')</span>'
            + '</div>'
            + '<div class="sc-products">' + tags + '</div>'
            + '<a href="<?= BASE_URL ?>store-detail.php?id=' + s.id + '" class="sc-view-btn">View Store</a>'
            + '</div>';
    }

    // ─── Map markers ───
    function plotStoreMarkers(stores) {
        if (useLeaflet) {
            // Clear old Leaflet markers
            storeMarkers.forEach(function(m) { map.removeLayer(m); });
            storeMarkers = [];

            if (!map) return;

            stores.forEach(function(s) {
                var icon = L.divIcon({
                    className: 'st-leaflet-marker',
                    html: '<div style="width:28px;height:36px;position:relative;">'
                        + '<svg viewBox="0 0 24 30" width="28" height="36"><path d="M12 0C7.03 0 3 4.03 3 9c0 6.75 9 15 9 15s9-8.25 9-15c0-4.97-4.03-9-9-9z" fill="#1E293B" stroke="#fff" stroke-width="1.5"/><circle cx="12" cy="9" r="3.75" fill="#fff"/></svg>'
                        + '</div>',
                    iconSize: [28, 36],
                    iconAnchor: [14, 36],
                    popupAnchor: [0, -36]
                });

                var marker = L.marker([s.lat, s.lng], { icon: icon })
                    .addTo(map)
                    .bindPopup(
                        '<div style="font-family:Inter,sans-serif;padding:2px;min-width:180px;">'
                        + '<strong style="font-size:0.875rem;color:#1E293B;">' + escapeHtml(s.name) + '</strong>'
                        + '<div style="font-size:0.75rem;color:#64748B;margin:4px 0;">' + escapeHtml(s.city) + ' &middot; ' + s.distance + ' km</div>'
                        + '<div style="font-size:0.7rem;color:#475569;margin-bottom:6px;">' + s.total_products + ' products &middot; ' + s.rating + ' stars</div>'
                        + '<a href="<?= BASE_URL ?>store-detail.php?id=' + s.id + '" style="font-size:0.75rem;color:#D97706;font-weight:600;text-decoration:none;">View Store &rarr;</a>'
                        + '</div>'
                    );
                marker._storeId = s.id;

                marker.on('click', function() {
                    highlightCard(s.id);
                });

                storeMarkers.push(marker);
            });

            // Fit map to show all markers + user location
            if (storeMarkers.length > 0 && searchLat && searchLng) {
                var group = L.featureGroup(storeMarkers);
                group.addLayer(L.marker([searchLat, searchLng]));
                map.fitBounds(group.getBounds().pad(0.1));
            }

        } else {
            // Google Maps markers
            storeMarkers.forEach(function(m) { m.setMap(null); });
            storeMarkers = [];
            if (infoWindow) infoWindow.close();

            if (!map) return;

            infoWindow = new google.maps.InfoWindow();

            stores.forEach(function(s) {
                var marker = new google.maps.Marker({
                    position: { lat: s.lat, lng: s.lng },
                    map: map,
                    title: s.name,
                    icon: {
                        path: 'M12 0C7.03 0 3 4.03 3 9c0 6.75 9 15 9 15s9-8.25 9-15c0-4.97-4.03-9-9-9zm0 12.75c-2.07 0-3.75-1.68-3.75-3.75S9.93 5.25 12 5.25 15.75 6.93 15.75 9 14.07 12.75 12 12.75z',
                        fillColor: '#1E293B',
                        fillOpacity: 0.9,
                        strokeColor: '#ffffff',
                        strokeWeight: 1.5,
                        scale: 1.4,
                        anchor: new google.maps.Point(12, 24)
                    },
                    zIndex: 100
                });
                marker._storeId = s.id;

                marker.addListener('click', function() {
                    infoWindow.setContent(
                        '<div style="font-family:Inter,sans-serif;padding:4px;min-width:180px;">'
                        + '<strong style="font-size:0.875rem;color:#1E293B;">' + escapeHtml(s.name) + '</strong>'
                        + '<div style="font-size:0.75rem;color:#64748B;margin:4px 0;">' + escapeHtml(s.city) + ' &middot; ' + s.distance + ' km</div>'
                        + '<div style="font-size:0.7rem;color:#475569;margin-bottom:6px;">' + s.total_products + ' products &middot; ' + s.rating + ' stars</div>'
                        + '<a href="<?= BASE_URL ?>store-detail.php?id=' + s.id + '" style="font-size:0.75rem;color:#D97706;font-weight:600;text-decoration:none;">View Store &rarr;</a>'
                        + '</div>'
                    );
                    infoWindow.open(map, marker);
                    highlightCard(s.id);
                });

                storeMarkers.push(marker);
            });

            if (storeMarkers.length > 0 && searchLat && searchLng) {
                var bounds = new google.maps.LatLngBounds();
                bounds.extend({ lat: searchLat, lng: searchLng });
                storeMarkers.forEach(function(m) { bounds.extend(m.getPosition()); });
                map.fitBounds(bounds, { top: 40, right: 40, bottom: 40, left: 40 });
            }
        }
    }

    function highlightMarker(id) {
        if (useLeaflet) {
            storeMarkers.forEach(function(m) {
                if (m._storeId === id) {
                    m.openPopup();
                }
            });
        } else {
            storeMarkers.forEach(function(m) {
                if (m._storeId === id) {
                    m.setAnimation(google.maps.Animation.BOUNCE);
                    setTimeout(function() { m.setAnimation(null); }, 700);
                }
            });
        }
    }

    function highlightCard(id) {
        document.querySelectorAll('.sc.highlighted').forEach(function(el) {
            el.classList.remove('highlighted');
        });
        var card = document.querySelector('.sc[data-id="' + id + '"]');
        if (card) {
            card.classList.add('highlighted');
            card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    function unhighlightAll() {
        document.querySelectorAll('.sc.highlighted').forEach(function(el) {
            el.classList.remove('highlighted');
        });
    }

    // ─── Helpers ───
    function escapeHtml(s) {
        if (!s) return '';
        var d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
    }

    // ═══════════════════════════════════════════════
    // Location Autocomplete (works in both modes)
    // Uses Nominatim for suggestions, Google Places as bonus if available
    // ═══════════════════════════════════════════════
    var elAutocomplete = document.getElementById('st-autocomplete');
    var acDebounce = null;
    var acResults = [];
    var acActiveIdx = -1;
    var acOpen = false;
    var googleAutocomplete = null; // will be set if Google is available

    function acShow() { elAutocomplete.classList.add('open'); acOpen = true; }
    function acHide() { elAutocomplete.classList.remove('open'); acOpen = false; acActiveIdx = -1; }

    function acRender(results) {
        acResults = results;
        acActiveIdx = -1;
        if (!results.length) {
            elAutocomplete.innerHTML = '<div class="st-ac-loading">No locations found</div>';
            acShow();
            return;
        }
        var html = '';
        results.forEach(function(r, i) {
            var typeIcon = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>';
            html += '<div class="st-ac-item" data-idx="' + i + '">'
                + '<div class="st-ac-icon">' + typeIcon + '</div>'
                + '<div class="st-ac-text">'
                + '<div class="st-ac-name">' + escapeHtml(r.name) + '</div>'
                + '<div class="st-ac-detail">' + escapeHtml(r.detail) + '</div>'
                + '</div></div>';
        });
        elAutocomplete.innerHTML = html;
        acShow();

        // Click handlers
        elAutocomplete.querySelectorAll('.st-ac-item').forEach(function(el) {
            el.addEventListener('mousedown', function(e) {
                e.preventDefault(); // don't blur input
                var idx = parseInt(this.dataset.idx);
                acSelect(idx);
            });
        });
    }

    function acSelect(idx) {
        var r = acResults[idx];
        if (!r) return;
        acHide();
        elInput.value = r.name;
        searchCountry = r.country;
        searchCountryName = r.countryName;
        updateCountryTag(r.country, r.countryName);
        setLocation(r.lat, r.lng, false);
        saveSgLocation(r.lat, r.lng, '', r.country);
        doSearch();
    }

    function acFetchNominatim(query) {
        elAutocomplete.innerHTML = '<div class="st-ac-loading"><span class="spinner"></span>Searching...</div>';
        acShow();

        fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(query) + '&limit=6&addressdetails=1', {
            headers: { 'Accept-Language': 'en' }
        })
        .then(function(r) { return r.json(); })
        .then(function(results) {
            if (!results || !results.length) {
                acRender([]);
                return;
            }
            var parsed = results.map(function(r) {
                var cc = (r.address && r.address.country_code) ? r.address.country_code.toUpperCase() : '';
                var cn = (r.address && r.address.country) ? r.address.country : '';
                // Build a nice name: city + state/region + country
                var parts = [];
                if (r.address) {
                    if (r.address.city || r.address.town || r.address.village) parts.push(r.address.city || r.address.town || r.address.village);
                    if (r.address.state) parts.push(r.address.state);
                    if (r.address.country) parts.push(r.address.country);
                }
                var name = parts.length ? parts.join(', ') : (r.display_name || query);
                return {
                    name: name,
                    detail: r.display_name || '',
                    lat: parseFloat(r.lat),
                    lng: parseFloat(r.lon),
                    country: cc,
                    countryName: cn
                };
            });
            acRender(parsed);
        })
        .catch(function() {
            acRender([]);
        });
    }

    // Input event — debounced autocomplete
    elInput.addEventListener('input', function() {
        var query = this.value.trim();
        clearTimeout(acDebounce);
        if (query.length < 2) { acHide(); return; }

        // If Google Places autocomplete is active, let it handle it
        if (googleAutocomplete && !useLeaflet) return;

        acDebounce = setTimeout(function() {
            acFetchNominatim(query);
        }, 350);
    });

    // Keyboard navigation
    elInput.addEventListener('keydown', function(e) {
        if (!acOpen) {
            if (e.key === 'Enter') {
                e.preventDefault();
                var query = elInput.value.trim();
                if (!query) return;
                // Direct geocode search
                acFetchNominatim(query);
            }
            return;
        }
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            acActiveIdx = Math.min(acActiveIdx + 1, acResults.length - 1);
            acHighlight();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            acActiveIdx = Math.max(acActiveIdx - 1, 0);
            acHighlight();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (acActiveIdx >= 0) {
                acSelect(acActiveIdx);
            } else if (acResults.length > 0) {
                acSelect(0);
            }
        } else if (e.key === 'Escape') {
            acHide();
        }
    });

    function acHighlight() {
        elAutocomplete.querySelectorAll('.st-ac-item').forEach(function(el, i) {
            el.classList.toggle('active', i === acActiveIdx);
            if (i === acActiveIdx) el.scrollIntoView({ block: 'nearest' });
        });
    }

    // Hide on blur
    elInput.addEventListener('blur', function() {
        setTimeout(function() { acHide(); }, 200);
    });

    // Show on focus if there are results
    elInput.addEventListener('focus', function() {
        if (acResults.length > 0 && this.value.trim().length >= 2) acShow();
    });

    // ─── Map initialization ───
    function initLeafletMap() {
        var center = [25, 45];
        var zoom = 3;
        if (searchLat && searchLng) {
            center = [searchLat, searchLng];
            zoom = 10;
        }

        map = L.map(elMap, {
            center: center,
            zoom: zoom,
            zoomControl: true
        });

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(map);

        // Click map to set location
        map.on('click', function(e) {
            setLocation(e.latlng.lat, e.latlng.lng, true);
        });

        elMapLoading.classList.add('hidden');

        // If initial coords exist, search immediately
        if (searchLat && searchLng && searchCountry) {
            setLocation(searchLat, searchLng, false);
            updateCountryTag(searchCountry, '');
            doSearch();
        } else {
            // Auto-detect user location on page load
            elMapLoading.classList.remove('hidden');
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(pos) {
                    setLocation(pos.coords.latitude, pos.coords.longitude, true);
                    elMapLoading.classList.add('hidden');
                }, function() {
                    elMapLoading.classList.add('hidden');
                    elList.innerHTML = '<div class="st-empty">'
                        + '<div class="st-empty-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>'
                        + '<h3>Location access denied</h3>'
                        + '<p>Search for a city or click on the map to find stores near you.</p></div>';
                }, { timeout: 8000, maximumAge: 300000 });
            } else {
                elMapLoading.classList.add('hidden');
            }
        }
    }

    // ─── Google Maps init ───
    function stInitMap() {
        var center = { lat: 25, lng: 45 };
        var zoom = 3;
        if (searchLat && searchLng) {
            center = { lat: searchLat, lng: searchLng };
            zoom = 10;
        }

        map = new google.maps.Map(elMap, {
            center: center,
            zoom: zoom,
            mapTypeControl: false,
            streetViewControl: false,
            fullscreenControl: true,
            zoomControl: true,
            styles: [
                { featureType: 'poi', stylers: [{ visibility: 'off' }] },
                { featureType: 'transit', stylers: [{ visibility: 'off' }] }
            ]
        });

        // Click map to set location
        map.addListener('click', function(e) {
            setLocation(e.latLng.lat(), e.latLng.lng(), true);
        });

        // Places autocomplete (Google's native dropdown)
        googleAutocomplete = new google.maps.places.Autocomplete(elInput, {
            types: ['(regions)']
        });
        googleAutocomplete.bindTo('bounds', map);
        var autocomplete = googleAutocomplete;

        autocomplete.addListener('place_changed', function() {
            var place = autocomplete.getPlace();
            if (!place.geometry) return;

            var lat = place.geometry.location.lat();
            var lng = place.geometry.location.lng();

            var country = '', countryName = '';
            if (place.address_components) {
                for (var i = 0; i < place.address_components.length; i++) {
                    var c = place.address_components[i];
                    if (c.types.indexOf('country') !== -1) {
                        country = c.short_name;
                        countryName = c.long_name;
                        break;
                    }
                }
            }

            searchCountry = country;
            searchCountryName = countryName;
            updateCountryTag(country, countryName);

            searchLat = lat;
            searchLng = lng;

            var pos = { lat: lat, lng: lng };
            if (userMarker) {
                userMarker.setPosition(pos);
            } else {
                userMarker = new google.maps.Marker({
                    position: pos,
                    map: map,
                    icon: {
                        path: google.maps.SymbolPath.CIRCLE,
                        scale: 12,
                        fillColor: '#F59E0B',
                        fillOpacity: 1,
                        strokeWeight: 3,
                        strokeColor: '#ffffff'
                    },
                    title: 'Your Location',
                    zIndex: 999
                });
            }

            if (searchCircle) {
                searchCircle.setCenter(pos);
            } else {
                searchCircle = new google.maps.Circle({
                    center: pos,
                    radius: parseInt(elRadius.value) * 1000,
                    map: map,
                    fillColor: '#F59E0B',
                    fillOpacity: 0.06,
                    strokeColor: '#F59E0B',
                    strokeOpacity: 0.3,
                    strokeWeight: 2
                });
            }

            fitMapToCircle();
            doSearch();
        });

        // If initial coords exist, search immediately
        if (searchLat && searchLng && searchCountry) {
            setLocation(searchLat, searchLng, false);
            updateCountryTag(searchCountry, '');
            doSearch();
        } else {
            // Auto-detect user location on page load
            elMapLoading.classList.remove('hidden');
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(pos) {
                    setLocation(pos.coords.latitude, pos.coords.longitude, true);
                    elMapLoading.classList.add('hidden');
                }, function() {
                    elMapLoading.classList.add('hidden');
                    elList.innerHTML = '<div class="st-empty">'
                        + '<div class="st-empty-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>'
                        + '<h3>Location access denied</h3>'
                        + '<p>Search for a city or click on the map to find stores near you.</p></div>';
                }, { timeout: 8000, maximumAge: 300000 });
            } else {
                elMapLoading.classList.add('hidden');
            }
        }
    }

    // ─── Bootstrap: called by stGmapsReady() or gm_authFailure→Leaflet.onload ───
    window.stBootMap = function() {
        if (typeof stUseGoogleMaps !== 'undefined' && stUseGoogleMaps) {
            useLeaflet = false;
            stInitMap();
        } else if (typeof L !== 'undefined') {
            useLeaflet = true;
            initLeafletMap();
        } else {
            elMap.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#64748B;font-size:0.875rem;padding:20px;text-align:center;">'
                + 'Map could not be loaded. Please check your internet connection or try again later.</div>';
            elMapLoading.classList.add('hidden');
        }
    };

    // If no Google Maps key, Leaflet loaded synchronously — boot now
    <?php if (!$maps_key): ?>
    if (typeof L !== 'undefined') { stBootMap(); }
    <?php endif; ?>

    // Fallback timeout if neither callback fires
    setTimeout(function() {
        if (!map) {
            if (typeof L !== 'undefined') { useLeaflet = true; initLeafletMap(); }
            else {
                elMap.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#64748B;font-size:0.875rem;padding:20px;text-align:center;">'
                    + 'Map could not be loaded. Please check your internet connection.</div>';
                elMapLoading.classList.add('hidden');
            }
        }
    }, 12000);

})();
</script>

<script>
// ═══════════════════════════════════════════
// Hero Entrance Animations (anime.js)
// Elements visible by default; animation is enhancement only
// ═══════════════════════════════════════════
window.addEventListener('load', function() {
    if (typeof anime === 'undefined') return;

    // Set initial hidden state via JS so elements are visible if anime fails
    var heroTargets = ['.st-hero-badge', '.st-hero h1', '.st-hero p', '.st-search-bar', '.st-country-tag'];
    heroTargets.forEach(function(sel) {
        var el = document.querySelector(sel);
        if (el) { el.style.opacity = '0'; el.style.transform = 'translateY(18px)'; }
    });

    anime.timeline({ easing: 'easeOutExpo' })
        .add({ targets: '.st-hero-badge', opacity: [0, 1], translateY: [18, 0], duration: 600 })
        .add({ targets: '.st-hero h1', opacity: [0, 1], translateY: [25, 0], duration: 800 }, '-=400')
        .add({ targets: '.st-hero p', opacity: [0, 1], translateY: [18, 0], duration: 700 }, '-=500')
        .add({ targets: '.st-search-bar', opacity: [0, 1], translateY: [18, 0], scale: [0.98, 1], duration: 700 }, '-=400');

    // Floating shapes
    anime({ targets: '#st-shape-1', opacity: [0, 0.6], translateY: [0, -12], rotate: [0, 10], duration: 4500, direction: 'alternate', loop: true, easing: 'easeInOutSine', delay: 200 });
    anime({ targets: '#st-shape-2', opacity: [0, 0.5], translateY: [0, 14], rotate: [0, -18], duration: 5500, direction: 'alternate', loop: true, easing: 'easeInOutSine', delay: 500 });
    anime({ targets: '#st-shape-3', opacity: [0, 0.5], translateX: [0, 10], translateY: [0, -8], rotate: [0, 40], duration: 6000, direction: 'alternate', loop: true, easing: 'easeInOutSine', delay: 300 });

    // Glowing orbs
    anime({ targets: '.st-hero-glow', scale: [0.9, 1.1], opacity: [0.4, 0.8], duration: 4000, direction: 'alternate', loop: true, easing: 'easeInOutSine', delay: anime.stagger(1000) });
});
</script>

<?php require_once 'includes/footer.php'; ?>
