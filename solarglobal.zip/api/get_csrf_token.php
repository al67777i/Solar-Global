<?php
/**
 * API: Get CSRF Token
 * Returns a CSRF token for frontend use
 */
header('Content-Type: application/json; charset=utf-8');
session_start();

require_once '../includes/csrf.php';
require_once '../includes/helpers.php';

set_security_headers();

if (!rate_limit('api_csrf', 60, 60)) { respond_rate_limited(); }

try {
    $token = generate_csrf_token();
    
    respond_json([
        'success' => true,
        'csrf_token' => $token
    ]);
    
} catch (Exception $e) {
    error_log("CSRF Token API error: " . $e->getMessage());
    respond_json([
        'success' => false,
        'message' => 'Error generating token'
    ], 500);
}
