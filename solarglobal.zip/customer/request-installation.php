<?php
/**
 * Request Installation Service from an Installer
 * Customer submits a request → creates installer_orders record
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/customer_auth.php';

set_security_headers();
require_customer_login();

$customer = get_customer_profile();
$db = getDB();
$success = '';
$error = '';

$installer_id = (int)($_GET['installer'] ?? $_POST['installer_id'] ?? 0);

// Fetch installer info
$installer = null;
if ($installer_id > 0) {
    $stmt = $db->prepare("SELECT id, business_name, owner_name, phone, email, city, country_code, logo_path, avg_rating, total_reviews FROM installers WHERE id = ? AND status = 'active'");
    $stmt->execute([$installer_id]);
    $installer = $stmt->fetch();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $installer_id = (int)($_POST['installer_id'] ?? 0);
    $property_type = $_POST['property_type'] ?? '';
    $system_type = $_POST['system_type'] ?? 'hybrid';
    $system_size_kw = floatval($_POST['system_size_kw'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $latitude = floatval($_POST['latitude'] ?? 0);
    $longitude = floatval($_POST['longitude'] ?? 0);
    $scheduled_date = $_POST['scheduled_date'] ?? '';
    $preferred_time = $_POST['preferred_time'] ?? '';
    $customer_notes = trim($_POST['customer_notes'] ?? '');
    $budget_per_kw = floatval($_POST['budget_per_kw'] ?? 0);
    $budget_total = ($budget_per_kw > 0 && $system_size_kw > 0) ? $budget_per_kw * $system_size_kw : 0;

    // Validate
    if (!$installer) {
        $error = 'Invalid installer selected.';
    } elseif (!in_array($property_type, ['residential', 'commercial', 'industrial'])) {
        $error = 'Please select a valid property type.';
    } elseif (!in_array($system_type, ['on-grid', 'off-grid', 'hybrid'])) {
        $error = 'Invalid system type.';
    } elseif ($system_size_kw <= 0) {
        $error = 'Please enter a valid system size.';
    } elseif (empty($scheduled_date)) {
        $error = 'Please select a preferred date.';
    } elseif (strtotime($scheduled_date) <= strtotime('today')) {
        $error = 'Preferred date must be a future date.';
    } elseif (!in_array($preferred_time, ['morning', 'afternoon', 'evening', 'flexible'])) {
        $error = 'Please select a preferred time.';
    } elseif (empty($description)) {
        $error = 'Please describe the installation work needed.';
    } elseif (empty($address)) {
        $error = 'Please provide the installation address.';
    } else {
        // Check for duplicate pending request
        $stmt = $db->prepare("SELECT id FROM installer_orders WHERE customer_id = ? AND installer_id = ? AND status IN ('requested','accepted','in_progress')");
        $stmt->execute([$customer['id'], $installer_id]);
        if ($stmt->fetch()) {
            $error = 'You already have an active request with this installer.';
        } else {
            $stmt = $db->prepare("INSERT INTO installer_orders
                (customer_id, installer_id, status, system_size_kw, system_type, property_type, preferred_time, description, address, latitude, longitude, scheduled_date, customer_notes, customer_budget_per_kw, customer_budget_total)
                VALUES (?, ?, 'requested', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $customer['id'], $installer_id, $system_size_kw, $system_type,
                $property_type, $preferred_time,
                $description, $address,
                $latitude ?: null, $longitude ?: null,
                $scheduled_date, $customer_notes ?: null,
                $budget_per_kw ?: null, $budget_total ?: null
            ]);
            $success = 'Installation request submitted! The installer will review and respond to your request.';
        }
    }
}

// Get customer's existing installation requests
$stmt = $db->prepare("SELECT io.*, i.business_name, i.phone as installer_phone
                       FROM installer_orders io
                       JOIN installers i ON io.installer_id = i.id
                       WHERE io.customer_id = ?
                       ORDER BY io.created_at DESC LIMIT 20");
$stmt->execute([$customer['id']]);
$my_requests = $stmt->fetchAll();

// Maps key
$maps_key = '';
try { $maps_key = get_system_setting('google_maps_api_key', ''); } catch (Exception $e) {}

$page_title = 'Request Installation';
$current_page = 'request-installation';
include __DIR__ . '/../includes/header.php';
?>
<style>
    .container { max-width: 800px; margin: 24px auto; padding: 0 20px; }

    .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; }
    .alert-success { background: #DCFCE7; color: #166534; }
    .alert-error { background: #FEF2F2; color: #991B1B; }

    .card { background: white; border-radius: 12px; padding: 24px; margin-bottom: 16px; box-shadow: 0 1px 4px rgba(0,0,0,0.05); }
    .card h2 { font-size: 1.125rem; font-weight: 700; color: #1E293B; margin-bottom: 16px; }

    /* Installer info card */
    .installer-info { display: flex; gap: 14px; align-items: center; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid #F1F5F9; }
    .ii-logo { width: 50px; height: 50px; border-radius: 10px; background: #F1F5F9; display: flex; align-items: center; justify-content: center; overflow: hidden; flex-shrink: 0; }
    .ii-logo img { width: 100%; height: 100%; object-fit: cover; }
    .ii-name { font-weight: 700; font-size: 1rem; color: #1E293B; }
    .ii-location { font-size: 0.8125rem; color: #64748B; }
    .ii-rating { font-size: 0.75rem; color: #F59E0B; }

    .customer-info-bar { background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 8px; padding: 10px 16px; margin-bottom: 20px; font-size: 0.875rem; color: #1E40AF; }

    .form-group { margin-bottom: 16px; }
    .form-group label { display: block; font-size: 0.8125rem; font-weight: 600; color: #374151; margin-bottom: 6px; }
    .form-group input, .form-group select, .form-group textarea {
        width: 100%; padding: 10px 14px; border: 2px solid #E2E8F0; border-radius: 8px;
        font-size: 0.9375rem; font-family: inherit;
    }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: #F59E0B; }
    .form-group textarea { resize: vertical; min-height: 80px; }
    .form-group small { display: block; margin-top: 4px; color: #94A3B8; font-size: 0.75rem; }
    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }

    .btn-submit {
        width: 100%; padding: 14px; background: #F59E0B; color: #1E293B; border: none;
        border-radius: 8px; font-weight: 700; font-size: 0.9375rem; cursor: pointer; font-family: inherit;
    }
    .btn-submit:hover { background: #D97706; }

    /* Requests list */
    .request-card {
        background: white; border-radius: 10px; padding: 16px; margin-bottom: 10px;
        border: 2px solid #E2E8F0;
    }
    .rc-header { display: flex; justify-content: space-between; align-items: start; flex-wrap: wrap; gap: 8px; margin-bottom: 8px; }
    .rc-installer { font-weight: 700; font-size: 0.9375rem; color: #1E293B; }
    .rc-date { font-size: 0.6875rem; color: #94A3B8; }
    .rc-desc { font-size: 0.8125rem; color: #475569; margin-bottom: 8px; line-height: 1.5; }
    .rc-meta { display: flex; gap: 10px; flex-wrap: wrap; }
    .rc-badge { padding: 3px 10px; border-radius: 6px; font-size: 0.6875rem; font-weight: 700; text-transform: uppercase; }
    .status-requested { background: #FEF3C7; color: #92400E; }
    .status-accepted { background: #DBEAFE; color: #1E40AF; }
    .status-in_progress { background: #FEF9C3; color: #854D0E; }
    .status-completed { background: #DCFCE7; color: #166534; }
    .status-cancelled { background: #FEE2E2; color: #991B1B; }
    .rc-spec { padding: 3px 10px; background: #F1F5F9; border-radius: 6px; font-size: 0.6875rem; color: #475569; font-weight: 500; }

    .empty-msg { text-align: center; padding: 40px; color: #64748B; }
    .empty-msg a { color: #1565C0; text-decoration: none; font-weight: 600; }

    @media (max-width: 640px) { .form-row { grid-template-columns: 1fr; } }
</style>

    <div class="container">
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>

        <?php if ($installer): ?>
            <!-- Request Form -->
            <div class="card">
                <h2>&#128296; Request Installation Service</h2>
                <div class="installer-info">
                    <div class="ii-logo">
                        <?php if (!empty($installer['logo_path'])): ?>
                            <img src="/solarglobal/<?= sanitize($installer['logo_path']) ?>" alt="">
                        <?php else: ?>
                            <span style="font-size:1.25rem;color:#94A3B8;">&#128296;</span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="ii-name"><?= sanitize($installer['business_name']) ?></div>
                        <div class="ii-location"><?= sanitize($installer['city'] ?? '') ?>, <?= sanitize($installer['country_code'] ?? '') ?></div>
                        <div class="ii-rating">
                            <?php $r = floatval($installer['avg_rating'] ?? 0); for ($i = 1; $i <= 5; $i++) echo $i <= round($r) ? '&#9733;' : '&#9734;'; ?>
                            (<?= $installer['total_reviews'] ?? 0 ?> reviews)
                        </div>
                    </div>
                </div>

                <div class="customer-info-bar">Booking as: <strong><?= sanitize($customer['name'] ?? $customer['full_name'] ?? '') ?></strong> (<?= sanitize($customer['email'] ?? '') ?>)</div>

                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="installer_id" value="<?= $installer['id'] ?>">

                    <div class="form-row">
                        <div class="form-group">
                            <label>Property Type</label>
                            <select name="property_type" required>
                                <option value="" disabled selected>Select property type</option>
                                <option value="residential">Residential</option>
                                <option value="commercial">Commercial</option>
                                <option value="industrial">Industrial</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>System Type</label>
                            <select name="system_type" required>
                                <option value="hybrid">Hybrid (Grid + Battery)</option>
                                <option value="off-grid">Off-Grid (Battery Only)</option>
                                <option value="on-grid">On-Grid (Grid-Tied)</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>System Size (kW)</label>
                            <input type="number" name="system_size_kw" step="0.1" min="0.5" max="500" placeholder="e.g. 5.0" required>
                        </div>
                        <div class="form-group">
                            <label>Your Budget per kW ($)</label>
                            <input type="number" name="budget_per_kw" step="0.01" min="0" placeholder="e.g. 5.00">
                            <small>Optional — helps installer understand your budget expectations</small>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Preferred Date</label>
                            <input type="date" name="scheduled_date" min="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Preferred Time</label>
                            <select name="preferred_time" required>
                                <option value="" disabled selected>Select preferred time</option>
                                <option value="morning">Morning (8am-12pm)</option>
                                <option value="afternoon">Afternoon (12pm-5pm)</option>
                                <option value="evening">Evening (5pm-8pm)</option>
                                <option value="flexible">Flexible</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Installation Address</label>
                            <input type="text" name="address" id="address-input" placeholder="Full address where installation will happen" required>
                            <input type="hidden" name="latitude" id="lat-input">
                            <input type="hidden" name="longitude" id="lng-input">
                            <small>Start typing and select from suggestions for accurate location.</small>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Describe the Installation Work Needed</label>
                        <textarea name="description" rows="4" placeholder="e.g. New rooftop solar installation for a 3-bedroom house. Need panels, inverter, and battery setup. Roof is concrete, south-facing." required></textarea>
                    </div>

                    <div class="form-group">
                        <label>Additional Notes <span style="color:#94A3B8;font-weight:400;">(optional)</span></label>
                        <textarea name="customer_notes" rows="2" placeholder="e.g. Available weekends only, gate code is 1234"></textarea>
                    </div>

                    <button type="submit" class="btn-submit">&#128296; Book Installation</button>
                </form>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="empty-msg">
                    <h3>Select an installer first</h3>
                    <p><a href="/solarglobal/find-installer.php">Find installers near you</a> and click "Request Installation".</p>
                </div>
            </div>
        <?php endif; ?>

        <!-- My Requests -->
        <div class="card">
            <h2>&#128203; My Installation Requests</h2>
            <?php if (empty($my_requests)): ?>
                <div class="empty-msg"><p>No installation requests yet.</p></div>
            <?php else: ?>
                <?php foreach ($my_requests as $req): ?>
                    <div class="request-card">
                        <div class="rc-header">
                            <div>
                                <div class="rc-installer"><?= sanitize($req['business_name']) ?></div>
                                <div class="rc-date"><?= date('M j, Y', strtotime($req['created_at'])) ?></div>
                            </div>
                            <span class="rc-badge status-<?= $req['status'] ?>"><?= ucfirst(str_replace('_', ' ', $req['status'])) ?></span>
                        </div>
                        <div class="rc-desc"><?= sanitize(substr($req['description'], 0, 200)) ?><?= strlen($req['description']) > 200 ? '...' : '' ?></div>
                        <div class="rc-meta">
                            <?php if (!empty($req['property_type'])): ?>
                                <span class="rc-spec"><?= ucfirst(sanitize($req['property_type'])) ?></span>
                            <?php endif; ?>
                            <span class="rc-spec"><?= sanitize($req['system_type']) ?></span>
                            <span class="rc-spec"><?= $req['system_size_kw'] ?> kW</span>
                            <?php if ($req['customer_budget_per_kw']): ?>
                                <span class="rc-spec" style="color:#1565C0;font-weight:700;">Budget: $<?= number_format($req['customer_budget_per_kw'], 2) ?>/kW</span>
                            <?php endif; ?>
                            <?php if (!empty($req['preferred_time'])): ?>
                                <?php
                                    $time_labels = ['morning' => 'Morning (8am-12pm)', 'afternoon' => 'Afternoon (12pm-5pm)', 'evening' => 'Evening (5pm-8pm)', 'flexible' => 'Flexible'];
                                    $time_display = $time_labels[$req['preferred_time']] ?? ucfirst($req['preferred_time']);
                                ?>
                                <span class="rc-spec"><?= sanitize($time_display) ?></span>
                            <?php endif; ?>
                            <?php if ($req['estimated_cost']): ?>
                                <span class="rc-spec" style="color:#059669;font-weight:700;">Quote: $<?= number_format($req['estimated_cost'], 0) ?></span>
                            <?php endif; ?>
                            <?php if ($req['scheduled_date']): ?>
                                <span class="rc-spec"><?= date('M j, Y', strtotime($req['scheduled_date'])) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                <div style="text-align:right;margin-top:12px;">
                    <a href="installations.php" style="color:#1565C0;font-size:0.8125rem;font-weight:600;text-decoration:none;">View all installations &rarr;</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($maps_key): ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?= sanitize($maps_key) ?>&libraries=places" async defer></script>
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const waitForGoogle = setInterval(() => {
            if (typeof google !== 'undefined' && google.maps && google.maps.places) {
                clearInterval(waitForGoogle);
                const input = document.getElementById('address-input');
                if (!input) return;
                const autocomplete = new google.maps.places.Autocomplete(input, { types: ['address'] });
                autocomplete.addListener('place_changed', () => {
                    const place = autocomplete.getPlace();
                    if (place.geometry) {
                        document.getElementById('lat-input').value = place.geometry.location.lat();
                        document.getElementById('lng-input').value = place.geometry.location.lng();
                    }
                });
            }
        }, 200);
    });
    </script>
    <?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
