<?php
/**
 * Migration: Configure Stripe test keys + data retention plan settings
 * Run once: php migration_stripe_setup.php
 */
require_once __DIR__ . '/../includes/db.php';
$db = getDB();

echo "=== Stripe & Data Retention Setup ===\n\n";

// Upsert helper
$stmt = $db->prepare("
    INSERT INTO system_settings (setting_key, setting_value, updated_at)
    VALUES (?, ?, NOW())
    ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
");

$settings = [
    // Stripe test keys
    'stripe_mode'                   => 'test',
    'stripe_test_publishable_key'   => 'pk_test_51TZReMPf9v8FUV342CAKv3bvDY2Fupwm44O8wifxyI3JBBliR8IZWAgUuhEBdNHQhltoZZLZVz7u9eqdpXK7ei6T00PyVVKgkd',
    'stripe_test_secret_key'        => 'sk_test_51TZReMPf9v8FUV34ODJrkg73XGKhaIXw9sbIdSKIQifh9mjGPH886AWcWKIInSLpB0fGN9yJozW2AfMweUmVbNfM00IFVqsWff',

    // Subscription fees
    'dealer_monthly_fee'            => '1.00',
    'installer_monthly_fee'         => '1.00',
    'payment_currency'              => 'usd',

    // Trial settings
    'dealer_free_trial_enabled'     => '1',
    'dealer_free_trial_days'        => '7',
    'installer_free_trial_enabled'  => '1',
    'installer_free_trial_days'     => '7',
    'subscription_grace_period_days'=> '3',

    // Data retention plans (admin-configurable)
    'retention_plan_basic_months'   => '6',
    'retention_plan_basic_fee'      => '0.00',
    'retention_plan_standard_months'=> '24',
    'retention_plan_standard_fee'   => '2.00',
    'retention_plan_premium_months' => '60',
    'retention_plan_premium_fee'    => '5.00',
    'retention_plan_enterprise_months' => '120',
    'retention_plan_enterprise_fee'    => '10.00',
    'retention_order_history_months'=> '120',
];

foreach ($settings as $key => $value) {
    $stmt->execute([$key, $value]);
    echo "  [OK] $key = $value\n";
}

echo "\nDone! Stripe keys configured, subscription fees set, retention plans created.\n";
echo "Admin can modify all values at: /admin/settings.php\n";
