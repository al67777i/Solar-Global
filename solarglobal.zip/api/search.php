<?php
/**
 * Global Search API
 * Searches across dealer products, stores (dealers), and installers.
 * Returns JSON grouped by category. Only active-subscription entities.
 *
 * GET /api/search.php?q=huawei&limit=5
 */
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/subscription_helpers.php';

// Rate limit
if (!rate_limit('global_search', 40, 60)) {
    http_response_code(429);
    echo json_encode(['error' => 'Too many requests.']);
    exit;
}

$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 2) {
    echo json_encode(['products' => [], 'stores' => [], 'installers' => []]);
    exit;
}

$limit = max(1, min(10, (int)($_GET['limit'] ?? 5)));
$like = "%{$q}%";
$db = getDB();

$dealer_filter = get_dealer_subscription_filter('d');
$installer_filter = get_installer_subscription_filter('i');

$products = [];
$stores = [];
$installers = [];

// ─── 1. Products (from dealer_products joined with product tables) ───
try {
    // Search across all product types via UNION ALL
    $sql = "
        (SELECT dp.id AS dp_id, inv.name, inv.image_path, dp.dealer_price, 'inverter' AS product_type,
                inv.id AS product_id, c.name AS brand, d.business_name AS dealer_name, d.id AS dealer_id, d.city
         FROM dealer_products dp
         JOIN dealers d ON dp.dealer_id = d.id AND {$dealer_filter}
         JOIN inverters inv ON dp.product_id = inv.id AND dp.product_type = 'inverter'
         LEFT JOIN companies c ON inv.company_id = c.id
         WHERE dp.is_active = 1 AND dp.stock_quantity > 0
           AND (inv.name LIKE ? OR c.name LIKE ?)
         LIMIT ?)
        UNION ALL
        (SELECT dp.id AS dp_id, bat.name, bat.image_path, dp.dealer_price, 'battery' AS product_type,
                bat.id AS product_id, c.name AS brand, d.business_name AS dealer_name, d.id AS dealer_id, d.city
         FROM dealer_products dp
         JOIN dealers d ON dp.dealer_id = d.id AND {$dealer_filter}
         JOIN batteries bat ON dp.product_id = bat.id AND dp.product_type = 'battery'
         LEFT JOIN companies c ON bat.company_id = c.id
         WHERE dp.is_active = 1 AND dp.stock_quantity > 0
           AND (bat.name LIKE ? OR c.name LIKE ?)
         LIMIT ?)
        UNION ALL
        (SELECT dp.id AS dp_id, pan.name, pan.image_path, dp.dealer_price, 'panel' AS product_type,
                pan.id AS product_id, c.name AS brand, d.business_name AS dealer_name, d.id AS dealer_id, d.city
         FROM dealer_products dp
         JOIN dealers d ON dp.dealer_id = d.id AND {$dealer_filter}
         JOIN panels pan ON dp.product_id = pan.id AND dp.product_type = 'panel'
         LEFT JOIN companies c ON pan.company_id = c.id
         WHERE dp.is_active = 1 AND dp.stock_quantity > 0
           AND (pan.name LIKE ? OR c.name LIKE ?)
         LIMIT ?)
        ORDER BY name ASC
        LIMIT ?
    ";

    $stmt = $db->prepare($sql);
    $stmt->execute([
        $like, $like, $limit,
        $like, $like, $limit,
        $like, $like, $limit,
        $limit
    ]);

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $products[] = [
            'id'           => (int)$row['dp_id'],
            'name'         => $row['name'],
            'brand'        => $row['brand'] ?? '',
            'product_type' => $row['product_type'],
            'price'        => (float)$row['dealer_price'],
            'image'        => !empty($row['image_path']) ? '/solarglobal/' . $row['image_path'] : '',
            'dealer_name'  => $row['dealer_name'],
            'dealer_id'    => (int)$row['dealer_id'],
            'city'         => $row['city'] ?? '',
        ];
    }
} catch (Exception $e) {
    error_log('Global search products error: ' . $e->getMessage());
}

// ─── 2. Stores (dealers with active subscriptions) ───
try {
    $sql = "
        SELECT d.id, d.business_name, d.city, d.country_code, d.logo_path, d.avg_rating, d.total_reviews
        FROM dealers d
        WHERE {$dealer_filter}
          AND (d.business_name LIKE ? OR d.city LIKE ? OR d.address LIKE ?)
        ORDER BY d.avg_rating DESC, d.business_name ASC
        LIMIT ?
    ";
    $stmt = $db->prepare($sql);
    $stmt->execute([$like, $like, $like, $limit]);

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $stores[] = [
            'id'            => (int)$row['id'],
            'business_name' => $row['business_name'],
            'city'          => $row['city'] ?? '',
            'country_code'  => $row['country_code'] ?? '',
            'logo'          => !empty($row['logo_path']) ? '/solarglobal/' . $row['logo_path'] : '',
            'rating'        => (float)$row['avg_rating'],
            'reviews'       => (int)$row['total_reviews'],
        ];
    }
} catch (Exception $e) {
    error_log('Global search stores error: ' . $e->getMessage());
}

// ─── 3. Installers (with active subscriptions) ───
try {
    $sql = "
        SELECT i.id, i.business_name, i.city, i.country_code, i.logo_path,
               i.avg_rating, i.total_reviews, i.years_experience, i.specializations
        FROM installers i
        WHERE {$installer_filter}
          AND (i.business_name LIKE ? OR i.city LIKE ? OR i.specializations LIKE ?)
        ORDER BY i.avg_rating DESC, i.business_name ASC
        LIMIT ?
    ";
    $stmt = $db->prepare($sql);
    $stmt->execute([$like, $like, $like, $limit]);

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $installers[] = [
            'id'            => (int)$row['id'],
            'business_name' => $row['business_name'],
            'city'          => $row['city'] ?? '',
            'country_code'  => $row['country_code'] ?? '',
            'logo'          => !empty($row['logo_path']) ? '/solarglobal/' . $row['logo_path'] : '',
            'rating'        => (float)$row['avg_rating'],
            'reviews'       => (int)$row['total_reviews'],
            'experience'    => (int)$row['years_experience'],
            'specializations' => $row['specializations'] ?? '',
        ];
    }
} catch (Exception $e) {
    error_log('Global search installers error: ' . $e->getMessage());
}

echo json_encode([
    'products'   => $products,
    'stores'     => $stores,
    'installers' => $installers,
    'query'      => $q,
]);
