-- =====================================================
-- PHASE 1: Database Renovation Migration
-- Solar Recommender v2.0
-- Adds: cities, sun_data, weather_cache, seasonal_appliance_mapping,
--       energy_forecasts, contact_messages, system_settings
-- Modifies: appliances (add seasonal columns)
--
-- STATUS: EXECUTED SUCCESSFULLY (2026-05-10)
-- Run 001b_fix_remaining.sql after this if image_path already exists
-- Run 001c_generate_sun_data.php to populate remaining cities
-- =====================================================

USE solar_recommender;

-- =====================================================
-- TABLE: cities
-- All major Pakistani cities with geographic data
-- =====================================================
CREATE TABLE IF NOT EXISTS cities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_en VARCHAR(100) NOT NULL,
    name_ur VARCHAR(100) NOT NULL,
    province VARCHAR(100) NOT NULL,
    latitude DECIMAL(8,5) NOT NULL,
    longitude DECIMAL(8,5) NOT NULL,
    elevation_m INT DEFAULT 0,
    timezone VARCHAR(50) DEFAULT 'Asia/Karachi',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (name_en),
    INDEX idx_province (province),
    INDEX idx_active (is_active),
    INDEX idx_coords (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- SEED: Pakistani Cities (50+ major cities)
-- =====================================================
INSERT INTO cities (name_en, name_ur, province, latitude, longitude, elevation_m) VALUES
-- Punjab
('Lahore', 'لاہور', 'Punjab', 31.55960, 74.35250, 217),
('Faisalabad', 'فیصل آباد', 'Punjab', 31.41870, 73.07900, 186),
('Rawalpindi', 'راولپنڈی', 'Punjab', 33.59510, 73.04800, 508),
('Multan', 'ملتان', 'Punjab', 30.19840, 71.47230, 123),
('Gujranwala', 'گوجرانوالہ', 'Punjab', 32.16170, 74.18820, 226),
('Sialkot', 'سیالکوٹ', 'Punjab', 32.49700, 74.53180, 255),
('Bahawalpur', 'بہاولپور', 'Punjab', 29.39540, 71.68330, 110),
('Sargodha', 'سرگودھا', 'Punjab', 32.08360, 72.67110, 187),
('Sahiwal', 'ساہیوال', 'Punjab', 30.66820, 73.10650, 150),
('Jhang', 'جھنگ', 'Punjab', 31.27810, 72.31170, 160),
('Rahim Yar Khan', 'رحیم یار خان', 'Punjab', 28.42120, 70.29560, 84),
('Kasur', 'قصور', 'Punjab', 31.11680, 74.45010, 201),
('Sheikhupura', 'شیخوپورہ', 'Punjab', 31.71300, 73.97630, 218),
('Okara', 'اوکاڑہ', 'Punjab', 30.80840, 73.44760, 168),
('Jhelum', 'جہلم', 'Punjab', 32.94250, 73.73190, 287),
('Gujrat', 'گجرات', 'Punjab', 32.57440, 74.07550, 232),
('Dera Ghazi Khan', 'ڈیرہ غازی خان', 'Punjab', 30.04890, 70.64090, 130),
('Chiniot', 'چنیوٹ', 'Punjab', 31.72050, 72.97860, 178),
('Mianwali', 'میانوالی', 'Punjab', 32.58520, 71.54710, 210),
-- Sindh
('Karachi', 'کراچی', 'Sindh', 24.86070, 67.01040, 14),
('Hyderabad', 'حیدرآباد', 'Sindh', 25.39600, 68.37380, 28),
('Sukkur', 'سکھر', 'Sindh', 27.70520, 68.85780, 66),
('Larkana', 'لاڑکانہ', 'Sindh', 27.55700, 68.21440, 45),
('Nawabshah', 'نوابشاہ', 'Sindh', 26.24420, 68.41000, 37),
('Mirpur Khas', 'میرپور خاص', 'Sindh', 25.52770, 69.01370, 20),
('Jacobabad', 'جیکب آباد', 'Sindh', 28.28160, 68.43660, 55),
('Thatta', 'ٹھٹہ', 'Sindh', 24.74570, 67.92320, 10),
-- KPK
('Peshawar', 'پشاور', 'KPK', 34.01500, 71.57850, 331),
('Mardan', 'مردان', 'KPK', 34.19790, 72.04000, 283),
('Abbottabad', 'ایبٹ آباد', 'KPK', 34.14680, 73.21110, 1256),
('Swat', 'سوات', 'KPK', 35.22270, 72.42720, 980),
('Mansehra', 'مانسہرہ', 'KPK', 34.33000, 73.20000, 1080),
('Kohat', 'کوہاٹ', 'KPK', 33.58690, 71.44280, 489),
('Dera Ismail Khan', 'ڈیرہ اسماعیل خان', 'KPK', 31.83200, 70.90150, 173),
('Chitral', 'چترال', 'KPK', 35.85180, 71.78540, 1500),
('Swabi', 'صوابی', 'KPK', 34.12030, 72.46980, 321),
-- Balochistan
('Quetta', 'کوئٹہ', 'Balochistan', 30.18310, 66.99500, 1680),
('Gwadar', 'گوادر', 'Balochistan', 25.12160, 62.32540, 12),
('Turbat', 'تربت', 'Balochistan', 26.00420, 63.04720, 150),
('Khuzdar', 'خضدار', 'Balochistan', 27.81190, 66.61330, 1235),
('Hub', 'حب', 'Balochistan', 25.05000, 66.90000, 49),
('Zhob', 'ژوب', 'Balochistan', 31.34130, 69.44900, 1405),
-- Islamabad / AJK / Gilgit-Baltistan
('Islamabad', 'اسلام آباد', 'Islamabad', 33.72940, 73.09310, 507),
('Muzaffarabad', 'مظفرآباد', 'AJK', 34.37000, 73.47100, 738),
('Mirpur', 'میرپور', 'AJK', 33.14840, 73.74160, 459),
('Gilgit', 'گلگت', 'Gilgit-Baltistan', 35.92080, 74.30840, 1500),
('Skardu', 'سکردو', 'Gilgit-Baltistan', 35.29400, 75.63970, 2228),
('Hunza', 'ہنزہ', 'Gilgit-Baltistan', 36.31640, 74.64860, 2438);

-- =====================================================
-- TABLE: sun_data
-- Monthly solar data for each city
-- =====================================================
CREATE TABLE IF NOT EXISTS sun_data (
    id INT PRIMARY KEY AUTO_INCREMENT,
    city_id INT NOT NULL,
    month TINYINT NOT NULL COMMENT '1=Jan, 12=Dec',
    avg_sunrise TIME NOT NULL,
    avg_sunset TIME NOT NULL,
    avg_daylight_hours DECIMAL(4,2) NOT NULL,
    peak_sun_hours DECIMAL(4,2) NOT NULL COMMENT 'Effective solar hours (PSH)',
    avg_irradiance_kwh_m2 DECIMAL(5,2) NOT NULL COMMENT 'Daily solar irradiance kWh/m²',
    avg_temperature_c DECIMAL(4,1) NOT NULL,
    avg_cloud_cover_percent DECIMAL(4,1) DEFAULT 20.0,
    avg_humidity_percent DECIMAL(4,1) DEFAULT 50.0,
    panel_efficiency_factor DECIMAL(4,3) DEFAULT 0.800 COMMENT 'Weather-adjusted efficiency 0-1',
    FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE CASCADE,
    UNIQUE KEY unique_city_month (city_id, month),
    INDEX idx_city (city_id),
    INDEX idx_month (month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- SEED: Sun Data for Major Cities (all 12 months)
-- Based on historical averages for Pakistan
-- =====================================================

-- Lahore (31.56°N) - Hot summers, mild winters
INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor) VALUES
(1, 1, '07:15', '17:25', 10.17, 4.2, 3.8, 12.5, 30, 65, 0.75),
(1, 2, '06:55', '17:55', 11.00, 4.8, 4.5, 15.0, 25, 58, 0.78),
(1, 3, '06:25', '18:20', 11.92, 5.5, 5.3, 21.0, 20, 48, 0.82),
(1, 4, '05:50', '18:45', 12.92, 6.2, 6.2, 28.0, 15, 38, 0.80),
(1, 5, '05:25', '19:10', 13.75, 6.8, 7.0, 34.0, 12, 32, 0.77),
(1, 6, '05:15', '19:25', 14.17, 6.5, 6.8, 38.0, 18, 42, 0.73),
(1, 7, '05:25', '19:20', 13.92, 5.5, 5.8, 35.5, 40, 65, 0.68),
(1, 8, '05:40', '19:00', 13.33, 5.2, 5.5, 34.0, 42, 70, 0.67),
(1, 9, '06:00', '18:25', 12.42, 5.8, 5.6, 31.0, 25, 58, 0.75),
(1, 10, '06:20', '17:45', 11.42, 5.5, 5.0, 26.0, 15, 50, 0.80),
(1, 11, '06:50', '17:15', 10.42, 4.8, 4.2, 19.0, 18, 55, 0.79),
(1, 12, '07:10', '17:10', 10.00, 4.0, 3.5, 13.5, 28, 63, 0.76);

-- Karachi (24.86°N) - Coastal, hot & humid
INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor) VALUES
(20, 1, '07:05', '17:50', 10.75, 5.0, 4.5, 19.0, 10, 55, 0.82),
(20, 2, '06:55', '18:10', 11.25, 5.5, 5.2, 20.5, 8, 52, 0.84),
(20, 3, '06:30', '18:25', 11.92, 6.0, 5.9, 25.0, 8, 50, 0.83),
(20, 4, '06:05', '18:40', 12.58, 6.5, 6.5, 29.0, 5, 55, 0.80),
(20, 5, '05:50', '19:00', 13.17, 7.0, 7.2, 32.0, 8, 60, 0.77),
(20, 6, '05:45', '19:15', 13.50, 6.0, 6.0, 33.5, 30, 72, 0.70),
(20, 7, '05:55', '19:15', 13.33, 4.5, 4.8, 31.0, 55, 78, 0.62),
(20, 8, '06:05', '19:00', 12.92, 4.8, 5.0, 30.0, 50, 76, 0.64),
(20, 9, '06:10', '18:30', 12.33, 5.8, 5.6, 30.5, 25, 68, 0.73),
(20, 10, '06:15', '17:55', 11.67, 6.0, 5.5, 28.0, 10, 55, 0.80),
(20, 11, '06:35', '17:30', 10.92, 5.5, 4.8, 24.0, 5, 50, 0.83),
(20, 12, '07:00', '17:30', 10.50, 5.0, 4.3, 20.0, 8, 52, 0.82);

-- Islamabad (33.73°N) - Continental, 4 distinct seasons
INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor) VALUES
(43, 1, '07:10', '17:20', 10.17, 4.0, 3.5, 10.0, 32, 62, 0.74),
(43, 2, '06:50', '17:50', 11.00, 4.5, 4.2, 12.5, 30, 60, 0.76),
(43, 3, '06:20', '18:15', 11.92, 5.2, 5.0, 17.5, 25, 52, 0.80),
(43, 4, '05:45', '18:40', 12.92, 6.0, 5.9, 23.5, 20, 42, 0.82),
(43, 5, '05:20', '19:05', 13.75, 6.8, 6.8, 30.0, 15, 35, 0.78),
(43, 6, '05:10', '19:20', 14.17, 6.5, 6.5, 35.0, 20, 45, 0.74),
(43, 7, '05:20', '19:15', 13.92, 5.0, 5.2, 33.0, 45, 72, 0.65),
(43, 8, '05:35', '18:55', 13.33, 5.0, 5.0, 31.5, 45, 74, 0.65),
(43, 9, '05:55', '18:20', 12.42, 5.5, 5.3, 28.0, 25, 58, 0.76),
(43, 10, '06:15', '17:40', 11.42, 5.5, 5.0, 23.0, 15, 48, 0.81),
(43, 11, '06:45', '17:10', 10.42, 4.5, 4.0, 16.5, 20, 55, 0.78),
(43, 12, '07:05', '17:05', 10.00, 3.8, 3.3, 11.0, 30, 60, 0.75);

-- Multan (30.20°N) - Extremely hot summers
INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor) VALUES
(4, 1, '07:10', '17:30', 10.33, 4.5, 4.0, 13.0, 22, 58, 0.78),
(4, 2, '06:50', '18:00', 11.17, 5.2, 4.8, 16.0, 18, 50, 0.80),
(4, 3, '06:20', '18:25', 12.08, 5.8, 5.6, 22.5, 15, 40, 0.82),
(4, 4, '05:50', '18:50', 13.00, 6.5, 6.5, 30.0, 10, 30, 0.79),
(4, 5, '05:25', '19:15', 13.83, 7.2, 7.5, 37.0, 8, 25, 0.74),
(4, 6, '05:15', '19:25', 14.17, 7.0, 7.2, 40.5, 12, 32, 0.70),
(4, 7, '05:25', '19:20', 13.92, 5.8, 6.0, 37.0, 35, 55, 0.66),
(4, 8, '05:40', '19:00', 13.33, 5.5, 5.8, 36.0, 38, 60, 0.65),
(4, 9, '06:00', '18:25', 12.42, 6.0, 5.9, 33.0, 18, 48, 0.76),
(4, 10, '06:20', '17:50', 11.50, 5.8, 5.3, 27.0, 10, 42, 0.81),
(4, 11, '06:50', '17:20', 10.50, 5.0, 4.5, 20.0, 15, 50, 0.80),
(4, 12, '07:10', '17:15', 10.08, 4.2, 3.7, 14.0, 22, 56, 0.77);

-- Peshawar (34.02°N) - Hot summers, cold winters
INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor) VALUES
(28, 1, '07:10', '17:15', 10.08, 3.8, 3.3, 8.5, 35, 65, 0.72),
(28, 2, '06:50', '17:45', 10.92, 4.3, 4.0, 11.0, 32, 60, 0.75),
(28, 3, '06:15', '18:15', 12.00, 5.0, 4.8, 16.5, 28, 52, 0.78),
(28, 4, '05:40', '18:40', 13.00, 5.8, 5.7, 23.0, 22, 42, 0.80),
(28, 5, '05:15', '19:05', 13.83, 6.5, 6.5, 30.0, 15, 35, 0.77),
(28, 6, '05:05', '19:20', 14.25, 6.8, 6.8, 35.5, 12, 38, 0.73),
(28, 7, '05:15', '19:15', 14.00, 5.5, 5.5, 33.5, 38, 62, 0.67),
(28, 8, '05:30', '18:55', 13.42, 5.2, 5.2, 32.0, 40, 65, 0.66),
(28, 9, '05:50', '18:20', 12.50, 5.5, 5.3, 28.5, 22, 52, 0.76),
(28, 10, '06:10', '17:40', 11.50, 5.2, 4.8, 22.5, 15, 45, 0.80),
(28, 11, '06:40', '17:10', 10.50, 4.3, 3.8, 15.0, 22, 55, 0.77),
(28, 12, '07:05', '17:05', 10.00, 3.5, 3.1, 9.5, 32, 62, 0.73);

-- Quetta (30.18°N, 1680m elevation) - High altitude, dry
INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor) VALUES
(38, 1, '07:05', '17:25', 10.33, 4.8, 4.5, 5.0, 20, 42, 0.82),
(38, 2, '06:45', '17:55', 11.17, 5.3, 5.0, 7.5, 22, 40, 0.82),
(38, 3, '06:15', '18:20', 12.08, 6.0, 5.8, 12.5, 20, 35, 0.84),
(38, 4, '05:40', '18:45', 13.08, 6.5, 6.5, 18.0, 15, 28, 0.85),
(38, 5, '05:15', '19:10', 13.92, 7.2, 7.5, 24.0, 10, 22, 0.83),
(38, 6, '05:05', '19:25', 14.33, 7.5, 7.8, 29.0, 8, 20, 0.80),
(38, 7, '05:15', '19:20', 14.08, 6.5, 6.8, 31.0, 25, 35, 0.74),
(38, 8, '05:30', '19:00', 13.50, 6.5, 6.8, 29.0, 22, 32, 0.76),
(38, 9, '05:50', '18:25', 12.58, 6.5, 6.3, 24.0, 12, 28, 0.82),
(38, 10, '06:10', '17:45', 11.58, 6.0, 5.5, 17.5, 10, 30, 0.84),
(38, 11, '06:40', '17:15', 10.58, 5.2, 4.8, 10.5, 15, 35, 0.83),
(38, 12, '07:00', '17:10', 10.17, 4.5, 4.2, 6.0, 18, 40, 0.82);

-- Faisalabad (31.42°N) - Industrial city, hot plains
INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor) VALUES
(2, 1, '07:12', '17:28', 10.27, 4.3, 3.9, 12.0, 28, 63, 0.76),
(2, 2, '06:52', '17:58', 11.10, 4.9, 4.6, 14.5, 24, 56, 0.79),
(2, 3, '06:22', '18:22', 12.00, 5.5, 5.3, 20.5, 20, 46, 0.82),
(2, 4, '05:48', '18:47', 12.98, 6.2, 6.2, 27.5, 15, 36, 0.80),
(2, 5, '05:23', '19:12', 13.82, 6.9, 7.1, 34.0, 12, 30, 0.77),
(2, 6, '05:13', '19:27', 14.23, 6.6, 6.9, 38.0, 16, 40, 0.73),
(2, 7, '05:23', '19:22', 13.98, 5.5, 5.8, 35.0, 38, 63, 0.68),
(2, 8, '05:38', '19:02', 13.40, 5.3, 5.5, 34.0, 40, 68, 0.67),
(2, 9, '05:58', '18:27', 12.48, 5.8, 5.7, 31.0, 22, 56, 0.76),
(2, 10, '06:18', '17:47', 11.48, 5.5, 5.1, 26.0, 14, 48, 0.80),
(2, 11, '06:48', '17:17', 10.48, 4.8, 4.3, 19.0, 18, 54, 0.79),
(2, 12, '07:08', '17:12', 10.07, 4.1, 3.6, 13.0, 26, 61, 0.76);

-- Rawalpindi (33.60°N) - Similar to Islamabad
INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor) VALUES
(3, 1, '07:08', '17:22', 10.23, 4.0, 3.5, 10.5, 32, 62, 0.74),
(3, 2, '06:48', '17:52', 11.07, 4.5, 4.2, 13.0, 30, 58, 0.76),
(3, 3, '06:18', '18:17', 11.98, 5.2, 5.0, 18.0, 25, 50, 0.80),
(3, 4, '05:43', '18:42', 12.98, 6.0, 5.9, 24.0, 20, 40, 0.82),
(3, 5, '05:18', '19:07', 13.82, 6.8, 6.8, 30.5, 15, 34, 0.78),
(3, 6, '05:08', '19:22', 14.23, 6.5, 6.5, 35.5, 20, 44, 0.74),
(3, 7, '05:18', '19:17', 13.98, 5.0, 5.2, 33.0, 45, 70, 0.65),
(3, 8, '05:33', '18:57', 13.40, 5.0, 5.0, 32.0, 45, 72, 0.65),
(3, 9, '05:53', '18:22', 12.48, 5.5, 5.3, 28.5, 25, 56, 0.76),
(3, 10, '06:13', '17:42', 11.48, 5.5, 5.0, 23.5, 15, 47, 0.81),
(3, 11, '06:43', '17:12', 10.48, 4.5, 4.0, 17.0, 20, 54, 0.78),
(3, 12, '07:03', '17:07', 10.07, 3.8, 3.3, 11.5, 30, 60, 0.75);

-- Hyderabad Sindh (25.40°N) - Hot, semi-arid
INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor) VALUES
(21, 1, '07:08', '17:48', 10.67, 5.2, 4.6, 18.0, 8, 48, 0.83),
(21, 2, '06:55', '18:08', 11.22, 5.6, 5.3, 20.0, 6, 44, 0.84),
(21, 3, '06:28', '18:25', 11.95, 6.2, 6.0, 26.0, 6, 40, 0.83),
(21, 4, '06:03', '18:42', 12.65, 6.8, 6.8, 31.0, 5, 42, 0.79),
(21, 5, '05:48', '18:58', 13.17, 7.2, 7.4, 35.0, 8, 48, 0.76),
(21, 6, '05:43', '19:12', 13.48, 6.2, 6.2, 36.0, 28, 62, 0.70),
(21, 7, '05:53', '19:12', 13.32, 4.8, 5.0, 33.5, 50, 72, 0.63),
(21, 8, '06:03', '18:58', 12.92, 5.0, 5.2, 32.0, 45, 70, 0.65),
(21, 9, '06:10', '18:28', 12.30, 6.0, 5.8, 31.5, 20, 58, 0.74),
(21, 10, '06:18', '17:55', 11.62, 6.2, 5.7, 28.5, 8, 48, 0.81),
(21, 11, '06:38', '17:32', 10.90, 5.6, 4.9, 23.5, 5, 44, 0.83),
(21, 12, '07:02', '17:28', 10.43, 5.0, 4.3, 19.0, 6, 46, 0.83);

-- Gwadar (25.12°N) - Coastal, high solar potential
INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor) VALUES
(39, 1, '07:15', '17:55', 10.67, 5.5, 5.0, 20.0, 5, 60, 0.82),
(39, 2, '07:00', '18:12', 11.20, 6.0, 5.5, 21.0, 4, 58, 0.83),
(39, 3, '06:35', '18:28', 11.88, 6.5, 6.2, 24.5, 4, 55, 0.83),
(39, 4, '06:08', '18:42', 12.57, 7.0, 7.0, 27.5, 3, 58, 0.81),
(39, 5, '05:52', '18:58', 13.10, 7.5, 7.6, 30.0, 5, 62, 0.79),
(39, 6, '05:48', '19:12', 13.40, 6.5, 6.5, 31.5, 20, 72, 0.72),
(39, 7, '05:58', '19:12', 13.23, 5.0, 5.2, 30.0, 45, 78, 0.64),
(39, 8, '06:08', '18:58', 12.83, 5.2, 5.3, 29.0, 40, 76, 0.66),
(39, 9, '06:12', '18:28', 12.27, 6.2, 6.0, 28.5, 15, 65, 0.76),
(39, 10, '06:22', '17:55', 11.55, 6.5, 6.0, 27.0, 5, 58, 0.81),
(39, 11, '06:42', '17:35', 10.88, 5.8, 5.2, 24.0, 3, 55, 0.83),
(39, 12, '07:08', '17:35', 10.45, 5.3, 4.8, 21.0, 4, 58, 0.83);

-- =====================================================
-- TABLE: weather_cache
-- Stores fetched weather forecast data (30-day)
-- =====================================================
CREATE TABLE IF NOT EXISTS weather_cache (
    id INT PRIMARY KEY AUTO_INCREMENT,
    city_id INT NOT NULL,
    forecast_date DATE NOT NULL,
    temperature_max DECIMAL(4,1) NOT NULL,
    temperature_min DECIMAL(4,1) NOT NULL,
    temperature_avg DECIMAL(4,1) NOT NULL,
    cloud_cover_percent DECIMAL(4,1) DEFAULT 0,
    precipitation_mm DECIMAL(5,1) DEFAULT 0,
    humidity_percent DECIMAL(4,1) DEFAULT 50,
    wind_speed_kmh DECIMAL(5,1) DEFAULT 0,
    uv_index DECIMAL(3,1) DEFAULT 5.0,
    sunshine_hours DECIMAL(4,2) DEFAULT 0,
    solar_irradiance_kwh_m2 DECIMAL(5,2) DEFAULT 0 COMMENT 'Calculated daily irradiance',
    weather_condition VARCHAR(50) DEFAULT 'Clear' COMMENT 'Clear, Cloudy, Rainy, Foggy, etc.',
    fetched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE CASCADE,
    UNIQUE KEY unique_city_date (city_id, forecast_date),
    INDEX idx_city (city_id),
    INDEX idx_date (forecast_date),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: seasonal_appliance_mapping
-- Maps appliances to seasons with usage probability
-- =====================================================
CREATE TABLE IF NOT EXISTS seasonal_appliance_mapping (
    id INT PRIMARY KEY AUTO_INCREMENT,
    appliance_id INT NOT NULL,
    season ENUM('summer', 'winter', 'monsoon', 'spring', 'all_year') NOT NULL,
    usage_probability DECIMAL(3,2) NOT NULL DEFAULT 0.50 COMMENT '0.00-1.00 likelihood of use',
    priority_rank TINYINT DEFAULT 5 COMMENT '1=essential, 10=optional',
    recommended_hours DECIMAL(4,1) DEFAULT 4.0 COMMENT 'Daily recommended usage hours',
    notes VARCHAR(255) DEFAULT NULL,
    FOREIGN KEY (appliance_id) REFERENCES appliances(id) ON DELETE CASCADE,
    UNIQUE KEY unique_appliance_season (appliance_id, season),
    INDEX idx_season (season),
    INDEX idx_priority (priority_rank)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- ALTER: appliances table - Add seasonal columns
-- =====================================================
ALTER TABLE appliances
    ADD COLUMN season_tags VARCHAR(255) DEFAULT 'all_year' COMMENT 'Comma-separated: summer,winter,monsoon,spring,all_year' AFTER category,
    ADD COLUMN usage_hours_summer DECIMAL(4,1) DEFAULT 4.0 AFTER season_tags,
    ADD COLUMN usage_hours_winter DECIMAL(4,1) DEFAULT 4.0 AFTER usage_hours_summer,
    ADD COLUMN surge_watts INT DEFAULT 0 COMMENT 'Starting surge wattage for motors' AFTER usage_hours_winter,
    ADD COLUMN standby_watts INT DEFAULT 0 COMMENT 'Standby power consumption' AFTER surge_watts,
    ADD COLUMN image_path VARCHAR(255) DEFAULT NULL AFTER standby_watts;

-- =====================================================
-- UPDATE: Existing appliances with seasonal data
-- =====================================================
UPDATE appliances SET season_tags = 'summer', usage_hours_summer = 16.0, usage_hours_winter = 0.0, surge_watts = 150 WHERE name_en = 'Ceiling Fan';
UPDATE appliances SET season_tags = 'summer', usage_hours_summer = 12.0, usage_hours_winter = 0.0, surge_watts = 180 WHERE name_en = 'Pedestal Fan';
UPDATE appliances SET season_tags = 'summer,winter', usage_hours_summer = 10.0, usage_hours_winter = 6.0, surge_watts = 2700 WHERE name_en = '1-Ton AC Inverter';
UPDATE appliances SET season_tags = 'summer,winter', usage_hours_summer = 10.0, usage_hours_winter = 6.0, surge_watts = 3900 WHERE name_en = '1.5-Ton AC Inverter';
UPDATE appliances SET season_tags = 'summer,winter', usage_hours_summer = 10.0, usage_hours_winter = 6.0, surge_watts = 5400 WHERE name_en = '2-Ton AC Inverter';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 8.0, usage_hours_winter = 6.0, surge_watts = 0, standby_watts = 2 WHERE name_en = 'LED Bulb 12W';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 8.0, usage_hours_winter = 6.0, surge_watts = 0, standby_watts = 3 WHERE name_en = 'LED Tube Light';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 6.0, usage_hours_winter = 6.0, surge_watts = 0, standby_watts = 2 WHERE name_en = 'CFL Bulb';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 5.0, usage_hours_winter = 5.0, surge_watts = 0, standby_watts = 1 WHERE name_en = 'LED Strip Light';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 24.0, usage_hours_winter = 24.0, surge_watts = 450, standby_watts = 5 WHERE name_en = 'Refrigerator (Small)';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 24.0, usage_hours_winter = 24.0, surge_watts = 750, standby_watts = 8 WHERE name_en = 'Refrigerator (Large)';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 24.0, usage_hours_winter = 24.0, surge_watts = 900, standby_watts = 10 WHERE name_en = 'Deep Freezer';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.5, usage_hours_winter = 0.5, surge_watts = 1800 WHERE name_en = 'Microwave Oven';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.3, usage_hours_winter = 0.5, surge_watts = 0 WHERE name_en = 'Electric Kettle';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.5, usage_hours_winter = 0.5, surge_watts = 1000 WHERE name_en = 'Rice Cooker';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.3, usage_hours_winter = 0.3, surge_watts = 800 WHERE name_en = 'Blender/Juicer';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.2, usage_hours_winter = 0.3, surge_watts = 0 WHERE name_en = 'Toaster';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 1.0, usage_hours_winter = 1.0, surge_watts = 1500 WHERE name_en = 'Washing Machine';
UPDATE appliances SET season_tags = 'winter', usage_hours_summer = 0.0, usage_hours_winter = 1.5, surge_watts = 3000 WHERE name_en = 'Dryer';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.5, usage_hours_winter = 1.0, surge_watts = 0 WHERE name_en = 'Iron';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 2.0, usage_hours_winter = 2.0, surge_watts = 2250 WHERE name_en = 'Submersible Water Pump';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 2.0, usage_hours_winter = 2.0, surge_watts = 1650 WHERE name_en = 'Surface Water Pump';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 8.0, usage_hours_winter = 8.0, surge_watts = 0, standby_watts = 5 WHERE name_en = 'Water Dispenser (Hot+Cold)';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 5.0, usage_hours_winter = 4.0, surge_watts = 0, standby_watts = 1 WHERE name_en = 'LED TV 32 inch';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 5.0, usage_hours_winter = 4.0, surge_watts = 0, standby_watts = 2 WHERE name_en = 'LED TV 55 inch';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 6.0, usage_hours_winter = 6.0, surge_watts = 0, standby_watts = 2 WHERE name_en = 'Laptop';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 6.0, usage_hours_winter = 6.0, surge_watts = 0, standby_watts = 5 WHERE name_en = 'Desktop Computer';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 3.0, usage_hours_winter = 3.0, surge_watts = 0, standby_watts = 1 WHERE name_en = 'Phone Charger';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 24.0, usage_hours_winter = 24.0, surge_watts = 0, standby_watts = 10 WHERE name_en = 'WiFi Router';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 24.0, usage_hours_winter = 24.0, surge_watts = 0, standby_watts = 15 WHERE name_en = 'Security Camera System';
UPDATE appliances SET season_tags = 'winter', usage_hours_summer = 0.0, usage_hours_winter = 2.0, surge_watts = 0 WHERE name_en = 'Electric Geyser';
UPDATE appliances SET season_tags = 'summer', usage_hours_summer = 10.0, usage_hours_winter = 2.0, surge_watts = 80 WHERE name_en = 'Exhaust Fan';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.5, usage_hours_winter = 0.5, surge_watts = 600 WHERE name_en = 'Laser Printer';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 3.0, usage_hours_winter = 3.0, surge_watts = 200 WHERE name_en = 'Sewing Machine (Electric)';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.5, usage_hours_winter = 0.5, surge_watts = 3000 WHERE name_en = 'Flour Mill (Small)';

-- =====================================================
-- SEED: Seasonal Appliance Mapping
-- =====================================================
INSERT INTO seasonal_appliance_mapping (appliance_id, season, usage_probability, priority_rank, recommended_hours, notes) VALUES
-- Ceiling Fan
(1, 'summer', 1.00, 1, 16.0, 'Essential in Pakistani summers'),
(1, 'spring', 0.70, 3, 8.0, 'Used on warm days'),
(1, 'monsoon', 0.90, 2, 12.0, 'Humidity makes fans essential'),
(1, 'winter', 0.05, 10, 0.0, 'Rarely used in winter'),
-- Pedestal Fan
(2, 'summer', 0.85, 2, 10.0, 'Supplementary cooling'),
(2, 'monsoon', 0.75, 3, 8.0, 'Used with humidity'),
(2, 'winter', 0.02, 10, 0.0, 'Not used'),
-- 1-Ton AC
(3, 'summer', 0.95, 1, 10.0, 'Essential cooling'),
(3, 'winter', 0.40, 5, 4.0, 'Used for heating in some homes'),
(3, 'spring', 0.30, 6, 3.0, 'Occasional use'),
-- 1.5-Ton AC
(4, 'summer', 0.95, 1, 10.0, 'Essential cooling'),
(4, 'winter', 0.35, 5, 4.0, 'Heating mode'),
(4, 'spring', 0.25, 6, 3.0, 'Occasional'),
-- 2-Ton AC
(5, 'summer', 0.90, 1, 10.0, 'Large room cooling'),
(5, 'winter', 0.30, 5, 4.0, 'Heating mode'),
-- Lighting (all year)
(6, 'all_year', 1.00, 1, 8.0, 'Always needed'),
(7, 'all_year', 1.00, 1, 8.0, 'Always needed'),
(8, 'all_year', 0.80, 2, 6.0, 'Common backup'),
(9, 'all_year', 0.60, 4, 5.0, 'Decorative/ambient'),
-- Refrigerator
(10, 'all_year', 1.00, 1, 24.0, 'Essential - runs 24/7'),
(11, 'all_year', 1.00, 1, 24.0, 'Essential - runs 24/7'),
-- Deep Freezer
(12, 'all_year', 0.70, 3, 24.0, 'Common in larger homes'),
-- Kitchen appliances
(13, 'all_year', 0.75, 4, 0.5, 'Used briefly'),
(14, 'all_year', 0.85, 3, 0.5, 'Tea/chai essential'),
(15, 'all_year', 0.60, 5, 0.5, 'Depends on family'),
(16, 'all_year', 0.80, 4, 0.3, 'Quick use'),
(17, 'all_year', 0.70, 5, 0.2, 'Breakfast item'),
-- Washing Machine
(18, 'all_year', 0.90, 2, 1.0, 'Regular laundry'),
-- Dryer
(19, 'winter', 0.40, 6, 1.5, 'Winter drying'),
(19, 'monsoon', 0.60, 4, 2.0, 'Wet season drying'),
-- Iron
(20, 'all_year', 0.85, 3, 0.5, 'Regular ironing'),
-- Water Pumps
(21, 'all_year', 0.70, 2, 2.0, 'Water supply'),
(22, 'all_year', 0.65, 2, 2.0, 'Water supply'),
-- Water Dispenser
(23, 'all_year', 0.50, 5, 8.0, 'Modern homes'),
-- TV
(24, 'all_year', 0.90, 3, 5.0, 'Entertainment'),
(25, 'all_year', 0.70, 4, 5.0, 'Entertainment'),
-- Electronics
(26, 'all_year', 0.80, 3, 6.0, 'Work/study'),
(27, 'all_year', 0.40, 5, 6.0, 'Work'),
(28, 'all_year', 0.95, 2, 3.0, 'Essential'),
(29, 'all_year', 1.00, 1, 24.0, 'Always on'),
-- Security Camera
(30, 'all_year', 0.50, 3, 24.0, 'Security essential when installed'),
-- Geyser
(31, 'winter', 1.00, 1, 2.0, 'Essential for hot water in winter'),
(31, 'spring', 0.30, 7, 0.5, 'Occasional use'),
(31, 'summer', 0.05, 10, 0.0, 'Not needed'),
-- Exhaust Fan
(32, 'summer', 0.80, 3, 8.0, 'Kitchen ventilation'),
(32, 'all_year', 0.60, 4, 4.0, 'Bathroom use'),
-- Printer
(33, 'all_year', 0.30, 7, 0.5, 'Occasional use'),
-- Sewing Machine
(34, 'all_year', 0.35, 6, 3.0, 'Household tailoring'),
-- Flour Mill
(35, 'all_year', 0.40, 5, 0.5, 'Weekly grinding');

-- =====================================================
-- TABLE: energy_forecasts
-- Stores calculated energy production forecasts
-- =====================================================
CREATE TABLE IF NOT EXISTS energy_forecasts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    city_id INT NOT NULL,
    forecast_date DATE NOT NULL,
    panel_watt_peak INT NOT NULL,
    num_panels INT NOT NULL DEFAULT 1,
    expected_generation_kwh DECIMAL(6,2) NOT NULL COMMENT 'Expected daily generation',
    weather_factor DECIMAL(4,3) DEFAULT 0.800 COMMENT 'Weather impact 0-1',
    temperature_loss_percent DECIMAL(4,1) DEFAULT 0.0,
    system_losses_percent DECIMAL(4,1) DEFAULT 20.0 COMMENT 'Wiring + inverter + dust losses',
    net_generation_kwh DECIMAL(6,2) NOT NULL COMMENT 'After all losses',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE CASCADE,
    INDEX idx_city_date (city_id, forecast_date),
    INDEX idx_date (forecast_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: system_settings (if not exists)
-- Application-wide configuration
-- =====================================================
CREATE TABLE IF NOT EXISTS system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('weather_api_provider', 'open-meteo', 'Weather API provider (open-meteo is free, no key needed)'),
('weather_cache_hours', '6', 'Hours to cache weather data before refresh'),
('default_city_id', '1', 'Default city (Lahore) if none selected'),
('system_loss_percent', '20', 'Total system losses (wiring + inverter + dust)'),
('panel_degradation_year1', '2', 'First year panel degradation percent'),
('panel_degradation_annual', '0.55', 'Annual panel degradation after year 1'),
('electricity_rate_pkr', '45', 'Average electricity rate per kWh in PKR'),
('net_metering_rate_pkr', '20', 'Net metering sell-back rate per kWh'),
('default_backup_hours', '4', 'Default backup hours for calculation'),
('installation_cost_percent', '15', 'Installation cost as percent of hardware')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- =====================================================
-- TABLE: contact_messages (if not exists)
-- =====================================================
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(200) NOT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    subject VARCHAR(255) DEFAULT NULL,
    message TEXT NOT NULL,
    city_id INT DEFAULT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE SET NULL,
    INDEX idx_read (is_read),
    INDEX idx_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- MIGRATION COMPLETE
-- =====================================================
