@echo off
REM ═══════════════════════════════════════════════
REM  SolarGlobal — Data Retention & Subscription Cron
REM  Schedule this in Windows Task Scheduler to run daily
REM  Recommended: Once per day at 3:00 AM
REM ═══════════════════════════════════════════════

REM Path to PHP executable (adjust if different)
set PHP_PATH=D:\xampp\php\php.exe

REM Path to cron script
set SCRIPT_PATH=D:\xampp\htdocs\solarglobal\api\cron_subscription_check.php

echo [%date% %time%] Running SolarGlobal subscription and retention cron...
"%PHP_PATH%" "%SCRIPT_PATH%"
echo [%date% %time%] Done.
