<?php
require_once 'includes/db.php';
require_once 'includes/helpers.php';
set_security_headers();
trackVisitor($pdo);

// ── Anti-scraping: bot + rate limit ──────────────────────────────────
if (is_bot_request() && !rate_limit('bot_batteries_' . ($_SERVER['REMOTE_ADDR'] ?? ''), 10, 60)) {
    http_response_code(429);
    echo '<h1>429 Too Many Requests</h1>';
    exit;
}
if (!rate_limit('page_batteries_' . ($_SERVER['REMOTE_ADDR'] ?? ''), 60, 60)) {
    http_response_code(429);
    echo '<h1>429 Too Many Requests</h1><p>Please slow down.</p>';
    exit;
}

$current_page = 'batteries';
if (session_status() === PHP_SESSION_NONE) session_start();

// ── Anti-scraping: per-session price obfuscation key ─────────────────
if (empty($_SESSION['_sgpk'])) {
    $_SESSION['_sgpk'] = rand(41, 97);
}
$_pk = $_SESSION['_sgpk'];

// ── USER CURRENCY ─────────────────────────────────────────────────────
$user_cc = 'US';
$loc = json_decode($_COOKIE['sg_location'] ?? '{}', true);
if (!empty($loc['country_code'])) {
    $user_cc = $loc['country_code'];
} else {
    $detected = detect_user_country();
    if ($detected) $user_cc = $detected;
}
$currency_info   = get_country_currency_info($user_cc);
$currency_symbol = $currency_info['currency_symbol'];
$currency_code   = $currency_info['currency_code'];
$exchange_rate   = max(0.001, $currency_info['exchange_rate']);

// ── PARAMS ────────────────────────────────────────────────────────────
$origin_country = trim($_GET['country'] ?? '');
$company_id     = max(0, (int)($_GET['company'] ?? 0));
$brand_name     = '';

// ── ORIGIN COUNTRIES (always loaded) ─────────────────────────────────
$origin_countries = $pdo->query("
    SELECT DISTINCT c.country as name,
           ct.flag_emoji, ct.flag_icon, ct.code,
           COUNT(b.id) as product_count
    FROM companies c
    INNER JOIN batteries b ON b.company_id = c.id AND b.is_active = 1
    LEFT JOIN countries ct ON (
        LOWER(ct.name COLLATE utf8mb4_general_ci) = LOWER(c.country COLLATE utf8mb4_general_ci)
        OR ct.code COLLATE utf8mb4_general_ci = c.country COLLATE utf8mb4_general_ci
    )
    WHERE c.is_active = 1 AND c.country IS NOT NULL AND c.country != ''
    GROUP BY c.country
    ORDER BY product_count DESC, c.country ASC
")->fetchAll(PDO::FETCH_ASSOC);

// ── COMPANY LIST (when country selected) ──────────────────────────────
$company_cards = [];
if ($origin_country) {
    $stmt = $pdo->prepare("
        SELECT c.id, c.name, c.slug, c.logo_path, c.country, c.website,
               COUNT(b.id) as battery_count,
               MIN(b.price_unit_usd) as min_price,
               MAX(b.price_unit_usd) as max_price
        FROM companies c
        INNER JOIN batteries b ON b.company_id = c.id AND b.is_active = 1
        WHERE c.is_active = 1 AND LOWER(c.country) = LOWER(?)
        GROUP BY c.id
        HAVING battery_count > 0
        ORDER BY battery_count DESC, c.name ASC
    ");
    $stmt->execute([$origin_country]);
    $company_cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// ── PRODUCTS (when company selected) ─────────────────────────────────
$batteries      = [];
$total          = 0;
$total_pages    = 0;
$page_num       = 1;
$per_page       = 12;
$price_range    = ['min' => 0, 'max' => 100000];
$capacity_range = ['min' => 0, 'max' => 1000];
$search = $type = $voltage = $min_price = $max_price = $min_capacity = $max_capacity = '';
$sort = 'price_asc';

if ($company_id) {
    $search       = trim($_GET['search']       ?? '');
    $type         = trim($_GET['type']         ?? '');
    $voltage      = trim($_GET['voltage']      ?? '');
    $min_price    = trim($_GET['min_price']    ?? '');
    $max_price    = trim($_GET['max_price']    ?? '');
    $min_capacity = trim($_GET['min_capacity'] ?? '');
    $max_capacity = trim($_GET['max_capacity'] ?? '');
    $sort         = trim($_GET['sort']         ?? 'price_asc');
    $page_num     = max(1, (int)($_GET['page'] ?? 1));
    $offset       = ($page_num - 1) * $per_page;

    $where  = ["b.is_active = 1", "b.company_id = ?"];
    $params = [$company_id];

    if ($search)       { $where[] = "(b.model LIKE ? OR c.name LIKE ?)";  $params[] = "%$search%"; $params[] = "%$search%"; }
    if ($type)         { $where[] = "b.type = ?";                          $params[] = $type; }
    if ($voltage)      { $where[] = "b.nominal_voltage = ?";               $params[] = $voltage; }
    if ($min_price)    { $where[] = "b.price_unit_usd >= ?";               $params[] = (float)$min_price; }
    if ($max_price)    { $where[] = "b.price_unit_usd <= ?";               $params[] = (float)$max_price; }
    if ($min_capacity) { $where[] = "b.capacity_ah >= ?";                  $params[] = (float)$min_capacity; }
    if ($max_capacity) { $where[] = "b.capacity_ah <= ?";                  $params[] = (float)$max_capacity; }

    $where_sql = implode(' AND ', $where);

    $cntStmt = $pdo->prepare("SELECT COUNT(*) FROM batteries b LEFT JOIN companies c ON b.company_id = c.id WHERE $where_sql");
    $cntStmt->execute($params);
    $total       = (int)$cntStmt->fetchColumn();
    $total_pages = max(1, ceil($total / $per_page));

    $allowed_sorts = [
        'price_asc'      => 'b.price_unit_usd ASC',
        'price_desc'     => 'b.price_unit_usd DESC',
        'capacity_asc'   => 'b.capacity_ah ASC',
        'capacity_desc'  => 'b.capacity_ah DESC',
        'name'           => 'b.model ASC',
    ];
    $order_by = $allowed_sorts[$sort] ?? 'b.price_unit_usd ASC';

    $sql = "SELECT b.*, c.name as company_name, c.country as company_country, c.logo_path as company_logo,
                   ct.flag_emoji as origin_flag, ct.flag_icon as origin_flag_icon, ct.code as origin_code
            FROM batteries b
            LEFT JOIN companies c ON b.company_id = c.id
            LEFT JOIN countries ct ON (
                LOWER(ct.name COLLATE utf8mb4_general_ci) = LOWER(COALESCE(b.country, c.country) COLLATE utf8mb4_general_ci)
                OR ct.code COLLATE utf8mb4_general_ci = COALESCE(b.country, c.country) COLLATE utf8mb4_general_ci
            )
            WHERE $where_sql ORDER BY $order_by LIMIT $per_page OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $batteries = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $pr = $pdo->query("SELECT MIN(price_usd) as min, MAX(price_usd) as max FROM batteries WHERE is_active = 1")->fetch();
    if ($pr) $price_range = $pr;
    $cr = $pdo->query("SELECT MIN(capacity_ah) as min, MAX(capacity_ah) as max FROM batteries WHERE is_active = 1")->fetch();
    if ($cr) $capacity_range = $cr;

    if (!$brand_name) {
        $s2 = $pdo->prepare("SELECT name, country FROM companies WHERE id = ? LIMIT 1");
        $s2->execute([$company_id]);
        $cn = $s2->fetch();
        if ($cn) {
            $brand_name = $cn['name'];
            if (!$origin_country) $origin_country = $cn['country'];
        }
    }
}

// ── STATS ─────────────────────────────────────────────────────────────
$total_batteries_all = (int)$pdo->query("SELECT COUNT(*) FROM batteries WHERE is_active = 1")->fetchColumn();
$total_brands_all    = (int)$pdo->query("SELECT COUNT(DISTINCT company_id) FROM batteries WHERE is_active = 1")->fetchColumn();

function toLocal($usd, $rate)         { return round($usd * $rate, 0); }
function formatLocal($usd, $rate, $s) { return $s . number_format(toLocal($usd, $rate)); }
function encP($usd, $k) {
    if (!is_numeric($usd) || floatval($usd) <= 0) return '';
    return rtrim(base64_encode((string)(int)round(floatval($usd) * $k * 100)), '=');
}

// ── SEO ───────────────────────────────────────────────────────────────
$site_name        = get_system_setting('site_name', 'SolarGlobal');
$page_title       = "Solar Batteries – Browse by Country & Brand | $site_name";
$page_description = "Browse $total_batteries_all solar batteries from $total_brands_all+ brands across " . count($origin_countries) . " countries. Filter by type, voltage, and capacity.";
$page_keywords    = "solar batteries, battery prices, lithium battery, LFP, lead acid, compare batteries";
if ($origin_country && !$brand_name) {
    $page_title       = "$origin_country Solar Battery Brands & Prices | $site_name";
    $page_description = "Browse solar battery brands from $origin_country. Compare models and prices in $currency_code.";
}
if ($brand_name) {
    $page_title       = "$brand_name Solar Batteries – Full Catalog & Specs | $site_name";
    $page_description = "All $brand_name solar batteries. Compare $total battery models, capacity and prices in $currency_code.";
}

// ── NAVIGATION STATE ──────────────────────────────────────────────────
$state = 'countries';
if ($origin_country && !$company_id) $state = 'brands';
if ($company_id)                     $state = 'products';

// ── ACTIVE FILTERS COUNT ──────────────────────────────────────────────
$active_filters = array_filter([$search, $type, $voltage, $min_price, $max_price, $min_capacity, $max_capacity]);
$has_filters    = count($active_filters) > 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($page_description) ?>">
    <meta name="keywords"    content="<?= htmlspecialchars($page_keywords) ?>">
    <meta name="robots"      content="index, follow">
    <meta property="og:title"       content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($page_description) ?>">
    <link rel="canonical" href="<?= htmlspecialchars(getBaseUrl() . '/batteries') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <meta name="theme-color" content="#059669">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/frontend.css">
    <link rel="stylesheet" href="assets/css/products.css">
    <link rel="stylesheet" href="assets/css/mobile-app.css">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      "name": <?= json_encode($page_title) ?>,
      "description": <?= json_encode($page_description) ?>,
      "url": <?= json_encode(getCurrentUrl()) ?>,
      "numberOfItems": <?= $company_id ? (int)$total : $total_batteries_all ?>
    }
    </script>

    <style>
    body { background: #F1F5F9; }
    .currency-bar { background:#F0FDF4; border-bottom:1px solid #BBF7D0; padding:7px 0; font-size:.82rem; }
    .currency-bar-inner { max-width:1440px; margin:0 auto; padding:0 20px; display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
    .currency-badge { background:#059669; color:#fff; padding:3px 10px; border-radius:20px; font-weight:700; font-size:.75rem; }
    .cat-hero { background:linear-gradient(135deg,#064E3B 0%,#059669 60%,#10B981 100%); padding:36px 20px 32px; color:#fff; position:relative; overflow:hidden; }
    .cat-hero::before { content:""; position:absolute; inset:0; background-image:radial-gradient(circle at 20% 50%,rgba(255,255,255,.04) 0%,transparent 50%),repeating-linear-gradient(135deg,transparent,transparent 40px,rgba(255,255,255,.015) 40px,rgba(255,255,255,.015) 80px); pointer-events:none; }
    .cat-hero-inner { max-width:1440px; margin:0 auto; position:relative; z-index:1; }
    .cat-hero-row { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:20px; }
    .cat-hero-left h1 { font-size:1.8rem; font-weight:800; margin:0 0 6px; }
    .cat-hero-left p  { font-size:.95rem; color:rgba(255,255,255,.8); margin:0; }
    .cat-hero-stats { display:flex; gap:28px; flex-wrap:wrap; }
    .cat-stat-val { display:block; font-size:1.4rem; font-weight:800; color:#A7F3D0; }
    .cat-stat-lbl { display:block; font-size:.72rem; color:rgba(255,255,255,.7); margin-top:1px; }
    .cat-breadcrumb { background:#fff; border-bottom:1px solid #E2E8F0; padding:10px 20px; font-size:.82rem; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
    .cat-breadcrumb a { color:#64748B; text-decoration:none; transition:color .15s; }
    .cat-breadcrumb a:hover { color:#059669; }
    .cat-breadcrumb .sep { color:#CBD5E1; }
    .cat-breadcrumb .cur { color:#1E293B; font-weight:600; }
    .cat-breadcrumb-inner { max-width:1440px; margin:0 auto; width:100%; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
    .cat-layout { max-width:1440px; margin:0 auto; padding:24px 20px 60px; display:grid; grid-template-columns:280px 1fr; gap:24px; align-items:start; }
    .cat-sidebar { background:#fff; border-radius:14px; border:1px solid #E2E8F0; box-shadow:0 1px 4px rgba(0,0,0,.06); position:sticky; top:20px; max-height:calc(100vh - 40px); overflow-y:auto; scrollbar-width:thin; scrollbar-color:#CBD5E1 transparent; }
    .cat-sidebar::-webkit-scrollbar { width:4px; }
    .cat-sidebar::-webkit-scrollbar-thumb { background:#CBD5E1; border-radius:2px; }
    .sb-search { padding:16px 16px 12px; border-bottom:1px solid #F1F5F9; }
    .sb-search-wrap { display:flex; align-items:center; gap:8px; background:#F8FAFC; border:1.5px solid #E2E8F0; border-radius:10px; padding:9px 12px; transition:border-color .2s; }
    .sb-search-wrap:focus-within { border-color:#059669; background:#fff; }
    .sb-search-wrap input { flex:1; border:none; background:none; font-size:.88rem; color:#1E293B; font-family:inherit; outline:none; }
    .sb-search-wrap input::placeholder { color:#94A3B8; }
    .sb-search-icon { color:#94A3B8; font-size:1rem; flex-shrink:0; }
    .sb-section { border-bottom:1px solid #F1F5F9; }
    .sb-section-head { display:flex; align-items:center; justify-content:space-between; padding:14px 16px 10px; cursor:pointer; user-select:none; }
    .sb-section-title { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:#94A3B8; }
    .sb-section-badge { background:#F1F5F9; color:#64748B; font-size:.68rem; font-weight:700; padding:2px 8px; border-radius:20px; }
    .sb-section-badge.active { background:#D1FAE5; color:#065F46; }
    .sb-section-body { padding:0 8px 10px; }
    .sb-country-item { display:flex; align-items:center; gap:10px; padding:8px 8px; border-radius:8px; text-decoration:none; color:#334155; font-size:.875rem; transition:all .15s; cursor:pointer; }
    .sb-country-item:hover { background:#F8FAFC; color:#1E293B; }
    .sb-country-item.active { background:#ECFDF5; color:#065F46; font-weight:700; }
    .sb-country-item .sb-flag { font-size:1.15rem; flex-shrink:0; }
    .sb-country-item .sb-name { flex:1; min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .sb-country-item .sb-cnt { font-size:.72rem; color:#94A3B8; flex-shrink:0; background:#F1F5F9; padding:2px 7px; border-radius:10px; }
    .sb-country-item.active .sb-cnt { background:#D1FAE5; color:#065F46; }
    .sb-company-item { display:flex; align-items:center; gap:10px; padding:7px 8px; border-radius:8px; text-decoration:none; color:#334155; font-size:.85rem; transition:all .15s; cursor:pointer; }
    .sb-company-item:hover { background:#F8FAFC; color:#1E293B; }
    .sb-company-item.active { background:#ECFDF5; color:#065F46; font-weight:700; }
    .sb-company-logo { width:32px; height:32px; border-radius:6px; background:#F8FAFC; border:1px solid #E2E8F0; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0; }
    .sb-company-logo img { width:100%; height:100%; object-fit:contain; padding:3px; }
    .sb-company-logo .sb-logo-icon { font-size:1rem; color:#94A3B8; }
    .sb-company-item .sb-name { flex:1; min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .sb-company-item .sb-cnt { font-size:.72rem; color:#94A3B8; flex-shrink:0; }
    .sb-company-item.active .sb-cnt { color:#065F46; }
    .sb-show-more { display:block; text-align:center; font-size:.78rem; color:#059669; font-weight:600; padding:6px 0; cursor:pointer; text-decoration:none; transition:color .15s; }
    .sb-show-more:hover { color:#064E3B; }
    .sb-filter-row { padding:0 8px; margin-bottom:10px; }
    .sb-filter-label { font-size:.78rem; font-weight:600; color:#475569; margin-bottom:5px; display:block; }
    .sb-filter-input, .sb-filter-select { width:100%; padding:8px 10px; border:1.5px solid #E2E8F0; border-radius:8px; font-size:.84rem; font-family:inherit; color:#1E293B; background:#fff; transition:border-color .2s; box-sizing:border-box; }
    .sb-filter-select { background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%2364748B' stroke-width='1.5' fill='none'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 10px center; padding-right:30px; cursor:pointer; -webkit-appearance:none; appearance:none; }
    .sb-filter-input:focus, .sb-filter-select:focus { outline:none; border-color:#059669; box-shadow:0 0 0 3px rgba(5,150,105,.1); }
    .sb-filter-apply { display:block; width:100%; padding:11px; margin-top:4px; background:linear-gradient(135deg,#064E3B,#059669); color:#fff; border:none; border-radius:8px; font-weight:700; font-size:.9rem; cursor:pointer; transition:all .2s; font-family:inherit; }
    .sb-filter-apply:hover { background:linear-gradient(135deg,#059669,#10B981); transform:translateY(-1px); }
    .sb-filter-clear { display:block; text-align:center; font-size:.78rem; color:#EF4444; font-weight:600; padding:6px 0; cursor:pointer; text-decoration:none; transition:color .15s; margin-top:2px; }
    .sb-filter-clear:hover { color:#DC2626; }
    .sb-bottom-pad { height:16px; }
    .cat-main { min-height:600px; }
    .cat-guide { background:#fff; border-radius:14px; border:1px solid #E2E8F0; padding:32px; text-align:center; margin-bottom:24px; }
    .cat-guide h2 { font-size:1.25rem; font-weight:700; color:#1E293B; margin:0 0 8px; }
    .cat-guide p  { color:#64748B; font-size:.9rem; margin:0 0 24px; }
    .cat-steps { display:flex; align-items:center; justify-content:center; gap:0; flex-wrap:wrap; }
    .cat-step { display:flex; align-items:center; gap:10px; }
    .cat-step-num { width:36px; height:36px; border-radius:50%; font-weight:800; font-size:.9rem; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
    .cat-step-num.done  { background:#059669; color:#fff; }
    .cat-step-num.cur   { background:#FBBF24; color:#1E293B; box-shadow:0 0 0 3px rgba(251,191,36,.25); }
    .cat-step-num.todo  { background:#F1F5F9; color:#94A3B8; }
    .cat-step-text { font-size:.85rem; font-weight:600; color:#334155; }
    .cat-step-arrow { color:#CBD5E1; margin:0 8px; font-size:1.2rem; }
    .cat-overview-title { font-size:1.1rem; font-weight:700; color:#1E293B; margin:0 0 14px; }
    .country-overview-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(200px, 1fr)); gap:12px; }
    .country-ov-card { background:#fff; border:1.5px solid #E2E8F0; border-radius:12px; padding:16px; text-decoration:none; color:inherit; transition:all .2s; display:flex; align-items:center; gap:12px; }
    .country-ov-card:hover { border-color:#059669; box-shadow:0 4px 16px rgba(5,150,105,.12); transform:translateY(-2px); }
    .country-ov-flag { font-size:1.8rem; flex-shrink:0; }
    .country-ov-info .ov-name { font-weight:700; font-size:.9rem; color:#1E293B; }
    .country-ov-info .ov-cnt  { font-size:.75rem; color:#059669; font-weight:600; margin-top:3px; }
    .brands-grid-title { display:flex; align-items:center; gap:10px; margin-bottom:16px; }
    .brands-grid-title h2 { font-size:1.2rem; font-weight:700; color:#1E293B; margin:0; }
    .brands-grid-title .badge { background:#D1FAE5; color:#065F46; font-size:.72rem; font-weight:700; padding:3px 10px; border-radius:20px; }
    .brands-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(240px, 1fr)); gap:14px; }
    .brand-card { background:#fff; border:1.5px solid #E2E8F0; border-radius:12px; padding:18px; display:flex; align-items:center; gap:14px; text-decoration:none; color:inherit; transition:all .2s; cursor:pointer; }
    .brand-card:hover { border-color:#059669; box-shadow:0 6px 20px rgba(5,150,105,.12); transform:translateY(-2px); }
    .brand-card-logo { width:48px; height:48px; border-radius:10px; background:#F8FAFC; border:1px solid #E2E8F0; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0; }
    .brand-card-logo img { width:100%; height:100%; object-fit:contain; padding:4px; }
    .brand-card-info { flex:1; min-width:0; }
    .brand-card-name { font-size:.95rem; font-weight:700; color:#1E293B; }
    .brand-card-meta { font-size:.75rem; color:#64748B; margin-top:2px; }
    .brand-card-price { font-size:.75rem; color:#059669; font-weight:600; margin-top:3px; }
    .brand-card-arrow { color:#CBD5E1; font-size:1.1rem; flex-shrink:0; transition:color .2s; }
    .brand-card:hover .brand-card-arrow { color:#059669; }
    .products-header { background:#fff; border:1px solid #E2E8F0; border-radius:12px; padding:16px 20px; display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:18px; }
    .products-header h2 { font-size:1.1rem; font-weight:700; color:#1E293B; margin:0; }
    .products-header .ph-meta { font-size:.8rem; color:#64748B; margin-top:2px; }
    .sort-select { padding:8px 32px 8px 12px; border:1.5px solid #E2E8F0; border-radius:8px; font-size:.84rem; font-family:inherit; color:#1E293B; cursor:pointer; background:#fff; -webkit-appearance:none; appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%2364748B' stroke-width='1.5' fill='none'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 10px center; }
    .sort-select:focus { outline:none; border-color:#059669; }
    .products-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(290px, 1fr)); gap:18px; }
    .product-card { background:#fff; border:1.5px solid #E2E8F0; border-radius:14px; display:flex; flex-direction:column; overflow:hidden; transition:all .25s; position:relative; box-shadow:0 1px 4px rgba(0,0,0,.06); }
    .product-card:hover { border-color:#059669; box-shadow:0 8px 28px rgba(5,150,105,.14); transform:translateY(-4px); }
    .product-card::before { content:""; position:absolute; top:0; left:0; right:0; height:3px; background:transparent; transition:background .2s; border-radius:14px 14px 0 0; z-index:2; }
    .product-card:hover::before { background:linear-gradient(90deg,#064E3B,#059669); }
    .product-card-top { position:absolute; top:12px; left:12px; right:12px; display:flex; justify-content:space-between; align-items:flex-start; z-index:3; }
    .product-badge { padding:4px 10px; border-radius:20px; font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.5px; backdrop-filter:blur(4px); }
    .product-badge.lithium   { background:#D1FAE5; color:#065F46; }
    .product-badge.lfp       { background:#DBEAFE; color:#1E40AF; }
    .product-badge.leadacid  { background:#FEF3C7; color:#92400E; }
    .product-badge.gel       { background:#F3E8FF; color:#6B21A8; }
    .product-badge.agm       { background:#FFE4E6; color:#9F1239; }
    .product-badge.standard  { background:#F1F5F9; color:#475569; }
    .compare-toggle { cursor:pointer; display:flex; align-items:center; }
    .compare-toggle input[type=checkbox] { display:none; }
    .compare-toggle-icon { width:28px; height:28px; border-radius:6px; background:rgba(255,255,255,.9); border:1.5px solid #E2E8F0; display:flex; align-items:center; justify-content:center; color:#94A3B8; transition:all .2s; }
    .compare-toggle input:checked ~ .compare-toggle-icon { background:#059669; border-color:#059669; color:#fff; }
    .product-image { width:100%; height:180px; background:#F8FAFC; display:flex; align-items:center; justify-content:center; border-bottom:1px solid #F1F5F9; overflow:hidden; }
    .product-image img { width:100%; height:100%; object-fit:contain; padding:16px; transition:transform .3s; pointer-events:none; user-select:none; -webkit-user-drag:none; }
    .product-card:hover .product-image img { transform:scale(1.05); }
    .product-image-placeholder { display:flex; align-items:center; justify-content:center; width:100%; height:100%; }
    .product-image-placeholder span { font-size:3.5rem; opacity:.35; }
    .product-info { padding:14px 16px 10px; flex:1; }
    .product-brand { font-size:.72rem; font-weight:700; color:#64748B; text-transform:uppercase; letter-spacing:.7px; display:flex; align-items:center; gap:5px; margin-bottom:5px; }
    .product-name { font-size:.95rem; font-weight:700; color:#1E293B; margin:0 0 12px; line-height:1.35; }
    .product-name a { color:inherit; text-decoration:none; }
    .product-name a:hover { color:#059669; }
    .product-specs-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:8px; margin-bottom:10px; }
    .spec-pill { background:#F8FAFC; border-radius:8px; padding:8px; display:flex; align-items:center; gap:7px; border:1px solid #F1F5F9; }
    .spec-pill-icon { font-size:1rem; flex-shrink:0; }
    .spec-pill-label { display:block; font-size:.64rem; color:#94A3B8; font-weight:500; text-transform:uppercase; letter-spacing:.4px; }
    .spec-pill-value { display:block; font-size:.8rem; font-weight:700; color:#1E293B; user-select:none; -webkit-user-select:none; }
    .product-features { display:flex; flex-wrap:wrap; gap:5px; padding-bottom:4px; }
    .feature-tag { font-size:.68rem; font-weight:600; padding:3px 8px; border-radius:4px; background:#F1F5F9; color:#475569; }
    .product-footer { padding:12px 16px 16px; border-top:1px solid #F1F5F9; display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .product-price .price-local { font-size:1.2rem; font-weight:800; color:#059669; display:block; user-select:none; -webkit-user-select:none; }
    .product-price .price-usd { font-size:.72rem; color:#94A3B8; display:block; margin-top:1px; }
    .btn-view-details { padding:9px 16px; background:linear-gradient(135deg,#064E3B,#059669); color:#fff; border-radius:8px; text-decoration:none; font-size:.82rem; font-weight:700; white-space:nowrap; transition:all .2s; flex-shrink:0; }
    .btn-view-details:hover { background:linear-gradient(135deg,#059669,#10B981); transform:translateY(-1px); }
    .pagination-wrap { text-align:center; margin-top:28px; }
    .pagination-info { font-size:.82rem; color:#64748B; margin-bottom:12px; }
    .btn-load-more { display:inline-flex; align-items:center; gap:8px; padding:12px 32px; background:linear-gradient(135deg,#064E3B,#059669); color:#fff; border-radius:10px; font-weight:700; font-size:.9rem; text-decoration:none; box-shadow:0 4px 15px rgba(5,150,105,.3); transition:all .2s; }
    .btn-load-more:hover { box-shadow:0 6px 24px rgba(5,150,105,.45); transform:translateY(-1px); }
    .cat-empty { background:#fff; border-radius:14px; border:1px solid #E2E8F0; padding:48px 24px; text-align:center; }
    .cat-empty .em-icon { font-size:3rem; margin-bottom:12px; }
    .cat-empty h3 { font-size:1.1rem; font-weight:700; color:#1E293B; margin:0 0 8px; }
    .cat-empty p  { color:#64748B; font-size:.88rem; margin:0; }
    .cat-filter-toggle { display:none; position:fixed; bottom:80px; left:16px; width:52px; height:52px; border-radius:50%; background:linear-gradient(135deg,#064E3B,#059669); color:#fff; border:none; cursor:pointer; z-index:9990; box-shadow:0 4px 20px rgba(5,150,105,.4); font-size:1.3rem; align-items:center; justify-content:center; transition:transform .2s; }
    .cat-filter-toggle:active { transform:scale(.92); }
    .cat-filter-overlay { display:none; position:fixed; inset:0; background:rgba(15,23,42,.55); z-index:9991; }
    .cat-filter-overlay.open { display:block; }
    .hp-field { display:none !important; visibility:hidden; }
    @media (max-width:1024px) {
        .cat-layout { grid-template-columns:1fr; }
        .cat-sidebar { display:none; position:fixed; bottom:70px; left:0; right:0; top:auto; width:100% !important; max-height:72vh; border-radius:20px 20px 0 0; z-index:9992; border:none; box-shadow:0 -6px 30px rgba(0,0,0,.18); }
        .cat-sidebar.open { display:block; }
        .cat-filter-toggle { display:flex; }
    }
    @media (max-width:640px) {
        .cat-hero-left h1 { font-size:1.4rem; }
        .brands-grid, .country-overview-grid { grid-template-columns:1fr; }
        .products-grid { grid-template-columns:1fr; }
        .cat-layout { padding:16px 12px 60px; }
    }
    </style>
</head>
<body>
    <?php include 'includes/header-nav.php'; ?>
    <?php include_once 'includes/ad_display.php'; ?>
    <?php renderAds('header'); ?>

    <div class="currency-bar">
        <div class="currency-bar-inner">
            <span style="color:#065F46;font-weight:500;">Prices shown in:</span>
            <span class="currency-badge"><?= htmlspecialchars($currency_code) ?> (<?= htmlspecialchars($currency_symbol) ?>)</span>
            <span style="color:#047857;font-size:.78rem;">· Exchange rate: 1 USD = <?= number_format($exchange_rate, 2) ?> <?= htmlspecialchars($currency_code) ?></span>
        </div>
    </div>

    <div class="cat-hero">
        <div class="cat-hero-inner">
            <div class="cat-hero-row">
                <div class="cat-hero-left">
                    <h1>🔋 Solar Batteries</h1>
                    <p>Browse <?= number_format($total_batteries_all) ?> batteries from <?= $total_brands_all ?>+ brands across <?= count($origin_countries) ?> countries</p>
                </div>
                <div class="cat-hero-stats">
                    <div><span class="cat-stat-val"><?= number_format($total_batteries_all) ?></span><span class="cat-stat-lbl">Batteries</span></div>
                    <div><span class="cat-stat-val"><?= $total_brands_all ?>+</span><span class="cat-stat-lbl">Brands</span></div>
                    <div><span class="cat-stat-val"><?= count($origin_countries) ?></span><span class="cat-stat-lbl">Countries</span></div>
                </div>
            </div>
        </div>
    </div>

    <div class="cat-breadcrumb">
        <div class="cat-breadcrumb-inner">
            <a href="<?= BASE_URL ?>">Home</a>
            <span class="sep">/</span>
            <a href="<?= BASE_URL ?>batteries.php">Batteries</a>
            <?php if ($origin_country): ?>
                <span class="sep">/</span>
                <a href="<?= BASE_URL ?>batteries.php?country=<?= urlencode($origin_country) ?>"><?= htmlspecialchars($origin_country) ?></a>
            <?php endif; ?>
            <?php if ($brand_name): ?>
                <span class="sep">/</span>
                <span class="cur"><?= htmlspecialchars($brand_name) ?></span>
            <?php endif; ?>
        </div>
    </div>

    <button class="cat-filter-toggle" id="catFilterToggle" aria-label="Open filters">&#9776;</button>
    <div class="cat-filter-overlay" id="catFilterOverlay"></div>

    <div class="cat-layout">

        <!-- SIDEBAR -->
        <aside class="cat-sidebar" id="catSidebar">
            <div class="sb-search">
                <form method="GET" action="<?= BASE_URL ?>batteries.php">
                    <?php if ($origin_country): ?><input type="hidden" name="country" value="<?= htmlspecialchars($origin_country) ?>"><?php endif; ?>
                    <?php if ($company_id): ?><input type="hidden" name="company" value="<?= $company_id ?>"><?php endif; ?>
                    <input type="text" name="website_url" class="hp-field" tabindex="-1" autocomplete="off">
                    <div class="sb-search-wrap">
                        <span class="sb-search-icon">&#128269;</span>
                        <input type="text" name="search" placeholder="Search batteries..." value="<?= htmlspecialchars($search) ?>" autocomplete="off">
                    </div>
                </form>
            </div>

            <div style="padding:14px 16px;background:#F8FAFC;border-bottom:1px solid #F1F5F9;">
                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                    <div style="display:flex;align-items:center;gap:5px;">
                        <span style="width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:800;flex-shrink:0;<?= $state==='countries'?'background:#FBBF24;color:#1E293B;':($origin_country?'background:#059669;color:#fff;':'background:#F1F5F9;color:#94A3B8;') ?>">1</span>
                        <span style="font-size:.75rem;font-weight:600;color:<?= $origin_country?'#059669':'#1E293B' ?>;">Country</span>
                    </div>
                    <span style="color:#CBD5E1;font-size:.9rem;">›</span>
                    <div style="display:flex;align-items:center;gap:5px;">
                        <span style="width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:800;flex-shrink:0;<?= $state==='brands'?'background:#FBBF24;color:#1E293B;':($brand_name?'background:#059669;color:#fff;':'background:#F1F5F9;color:#94A3B8;') ?>">2</span>
                        <span style="font-size:.75rem;font-weight:600;color:<?= $brand_name?'#059669':($origin_country?'#1E293B':'#94A3B8') ?>;">Brand</span>
                    </div>
                    <span style="color:#CBD5E1;font-size:.9rem;">›</span>
                    <div style="display:flex;align-items:center;gap:5px;">
                        <span style="width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:800;flex-shrink:0;<?= $state==='products'?'background:#FBBF24;color:#1E293B;':'background:#F1F5F9;color:#94A3B8;' ?>">3</span>
                        <span style="font-size:.75rem;font-weight:600;color:<?= $state==='products'?'#1E293B':'#94A3B8' ?>;">Products</span>
                    </div>
                </div>
            </div>

            <!-- Countries -->
            <div class="sb-section">
                <div class="sb-section-head" onclick="toggleSection(this)">
                    <span class="sb-section-title">&#127760; Manufacturing Country</span>
                    <span class="sb-section-badge <?= $origin_country ? 'active' : '' ?>"><?= count($origin_countries) ?></span>
                </div>
                <div class="sb-section-body">
                    <a class="sb-country-item <?= !$origin_country ? 'active' : '' ?>" href="<?= BASE_URL ?>batteries.php">
                        <span class="sb-flag">&#127758;</span>
                        <span class="sb-name">All Countries</span>
                        <span class="sb-cnt"><?= number_format($total_batteries_all) ?></span>
                    </a>
                    <?php
                    $show_countries = array_slice($origin_countries, 0, 15);
                    $more_countries = array_slice($origin_countries, 15);
                    foreach ($show_countries as $oc):
                        $is_active = (strtolower($origin_country) === strtolower($oc['name']));
                    ?>
                    <a class="sb-country-item <?= $is_active ? 'active' : '' ?>" href="<?= BASE_URL ?>batteries.php?country=<?= urlencode($oc['name']) ?>">
                        <span class="sb-flag"><?= get_country_flag($oc, 18) ?></span>
                        <span class="sb-name"><?= htmlspecialchars($oc['name']) ?></span>
                        <span class="sb-cnt"><?= (int)$oc['product_count'] ?></span>
                    </a>
                    <?php endforeach; ?>
                    <?php if (!empty($more_countries)): ?>
                    <div id="moreCountries" style="display:none;">
                        <?php foreach ($more_countries as $oc): $is_active = (strtolower($origin_country) === strtolower($oc['name'])); ?>
                        <a class="sb-country-item <?= $is_active ? 'active' : '' ?>" href="<?= BASE_URL ?>batteries.php?country=<?= urlencode($oc['name']) ?>">
                            <span class="sb-flag"><?= get_country_flag($oc, 18) ?></span>
                            <span class="sb-name"><?= htmlspecialchars($oc['name']) ?></span>
                            <span class="sb-cnt"><?= (int)$oc['product_count'] ?></span>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <a class="sb-show-more" id="showMoreCountries" onclick="showMoreCountries(event)">+ <?= count($more_countries) ?> more</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Companies (when country selected) -->
            <?php if ($origin_country && !empty($company_cards)): ?>
            <div class="sb-section">
                <div class="sb-section-head" onclick="toggleSection(this)">
                    <span class="sb-section-title">&#127970; Brands in <?= htmlspecialchars($origin_country) ?></span>
                    <span class="sb-section-badge active"><?= count($company_cards) ?></span>
                </div>
                <div class="sb-section-body">
                    <?php
                    $show_companies = array_slice($company_cards, 0, 12);
                    $more_companies = array_slice($company_cards, 12);
                    foreach ($show_companies as $cc): $is_active_co = ($company_id === (int)$cc['id']);
                    ?>
                    <a class="sb-company-item <?= $is_active_co ? 'active' : '' ?>" href="<?= BASE_URL ?>batteries.php?country=<?= urlencode($origin_country) ?>&company=<?= (int)$cc['id'] ?>#products">
                        <div class="sb-company-logo">
                            <?php if (!empty($cc['logo_path'])): ?>
                                <img src="<?= htmlspecialchars(get_image_url($cc['logo_path'])) ?>" alt="<?= htmlspecialchars($cc['name']) ?>" loading="lazy">
                            <?php else: ?>
                                <span class="sb-logo-icon">&#128267;</span>
                            <?php endif; ?>
                        </div>
                        <span class="sb-name"><?= htmlspecialchars($cc['name']) ?></span>
                        <span class="sb-cnt"><?= (int)$cc['battery_count'] ?></span>
                    </a>
                    <?php endforeach; ?>
                    <?php if (!empty($more_companies)): ?>
                    <div id="moreCompanies" style="display:none;">
                        <?php foreach ($more_companies as $cc): $is_active_co = ($company_id === (int)$cc['id']); ?>
                        <a class="sb-company-item <?= $is_active_co ? 'active' : '' ?>" href="<?= BASE_URL ?>batteries.php?country=<?= urlencode($origin_country) ?>&company=<?= (int)$cc['id'] ?>#products">
                            <div class="sb-company-logo">
                                <?php if (!empty($cc['logo_path'])): ?><img src="<?= htmlspecialchars(get_image_url($cc['logo_path'])) ?>" alt="" loading="lazy">
                                <?php else: ?><span class="sb-logo-icon">&#128267;</span><?php endif; ?>
                            </div>
                            <span class="sb-name"><?= htmlspecialchars($cc['name']) ?></span>
                            <span class="sb-cnt"><?= (int)$cc['battery_count'] ?></span>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <a class="sb-show-more" id="showMoreCompanies" onclick="showMoreCompanies(event)">+ <?= count($more_companies) ?> more brands</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Filters (when company selected) -->
            <?php if ($company_id): ?>
            <div class="sb-section">
                <div class="sb-section-head" onclick="toggleSection(this)">
                    <span class="sb-section-title">&#127775; Filter Batteries</span>
                    <?php if ($has_filters): ?><span class="sb-section-badge active"><?= count($active_filters) ?> active</span><?php endif; ?>
                </div>
                <div class="sb-section-body">
                    <form method="GET" action="<?= BASE_URL ?>batteries.php" id="sidebarFilterForm">
                        <input type="hidden" name="country" value="<?= htmlspecialchars($origin_country) ?>">
                        <input type="hidden" name="company" value="<?= $company_id ?>">
                        <input type="text" name="website_url" class="hp-field" tabindex="-1" autocomplete="off">
                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#128269; Search</label>
                            <input type="text" name="search" class="sb-filter-input" placeholder="Search models..." value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#128267; Battery Type</label>
                            <select name="type" class="sb-filter-select">
                                <option value="">All Types</option>
                                <option value="lithium"   <?= $type==='lithium'   ? 'selected':'' ?>>Lithium</option>
                                <option value="lfp"       <?= $type==='lfp'       ? 'selected':'' ?>>LFP</option>
                                <option value="lead-acid" <?= $type==='lead-acid' ? 'selected':'' ?>>Lead Acid</option>
                                <option value="gel"       <?= $type==='gel'       ? 'selected':'' ?>>Gel</option>
                                <option value="agm"       <?= $type==='agm'       ? 'selected':'' ?>>AGM</option>
                            </select>
                        </div>
                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#9889; Voltage</label>
                            <select name="voltage" class="sb-filter-select">
                                <option value="">All Voltages</option>
                                <option value="12"   <?= $voltage==='12'   ? 'selected':'' ?>>12V</option>
                                <option value="24"   <?= $voltage==='24'   ? 'selected':'' ?>>24V</option>
                                <option value="48"   <?= $voltage==='48'   ? 'selected':'' ?>>48V</option>
                                <option value="51.2" <?= $voltage==='51.2' ? 'selected':'' ?>>51.2V</option>
                            </select>
                        </div>
                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#128176; Price Range (USD)</label>
                            <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:6px;align-items:center;">
                                <input type="number" name="min_price" class="sb-filter-input" placeholder="Min" value="<?= htmlspecialchars($min_price) ?>" min="0" step="10">
                                <span style="color:#94A3B8;font-size:.8rem;text-align:center;">–</span>
                                <input type="number" name="max_price" class="sb-filter-input" placeholder="Max" value="<?= htmlspecialchars($max_price) ?>" min="0" step="10">
                            </div>
                        </div>
                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#128161; Capacity (Ah)</label>
                            <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:6px;align-items:center;">
                                <input type="number" name="min_capacity" class="sb-filter-input" placeholder="Min" value="<?= htmlspecialchars($min_capacity) ?>" min="0">
                                <span style="color:#94A3B8;font-size:.8rem;text-align:center;">–</span>
                                <input type="number" name="max_capacity" class="sb-filter-input" placeholder="Max" value="<?= htmlspecialchars($max_capacity) ?>" min="0">
                            </div>
                        </div>
                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#128196; Sort By</label>
                            <select name="sort" class="sb-filter-select">
                                <option value="price_asc"     <?= $sort==='price_asc'     ? 'selected':'' ?>>Price: Low → High</option>
                                <option value="price_desc"    <?= $sort==='price_desc'    ? 'selected':'' ?>>Price: High → Low</option>
                                <option value="capacity_asc"  <?= $sort==='capacity_asc'  ? 'selected':'' ?>>Capacity: Low → High</option>
                                <option value="capacity_desc" <?= $sort==='capacity_desc' ? 'selected':'' ?>>Capacity: High → Low</option>
                                <option value="name"          <?= $sort==='name'          ? 'selected':'' ?>>Name: A → Z</option>
                            </select>
                        </div>
                        <div class="sb-filter-row">
                            <button type="submit" class="sb-filter-apply">Apply Filters</button>
                            <?php if ($has_filters): ?>
                            <a href="<?= BASE_URL ?>batteries.php?country=<?= urlencode($origin_country) ?>&company=<?= $company_id ?>" class="sb-filter-clear">✕ Clear all filters</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>

            <div class="sb-bottom-pad"></div>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="cat-main" id="products">

            <?php if ($state === 'countries'): ?>
            <div class="cat-guide">
                <h2>Browse Solar Batteries</h2>
                <p>Select a manufacturing country from the sidebar, then choose a brand to view all available batteries.</p>
                <div class="cat-steps">
                    <div class="cat-step"><span class="cat-step-num cur">1</span><span class="cat-step-text">Select Country</span></div>
                    <span class="cat-step-arrow">→</span>
                    <div class="cat-step"><span class="cat-step-num todo">2</span><span class="cat-step-text">Choose Brand</span></div>
                    <span class="cat-step-arrow">→</span>
                    <div class="cat-step"><span class="cat-step-num todo">3</span><span class="cat-step-text">View Products</span></div>
                </div>
            </div>
            <p class="cat-overview-title">&#127760; Top Manufacturing Countries</p>
            <div class="country-overview-grid">
                <?php foreach (array_slice($origin_countries, 0, 18) as $oc): ?>
                <a class="country-ov-card" href="<?= BASE_URL ?>batteries.php?country=<?= urlencode($oc['name']) ?>">
                    <span class="country-ov-flag"><?= get_country_flag($oc, 32) ?></span>
                    <div class="country-ov-info">
                        <div class="ov-name"><?= htmlspecialchars($oc['name']) ?></div>
                        <div class="ov-cnt">🔋 <?= (int)$oc['product_count'] ?> batteries</div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>

            <?php elseif ($state === 'brands'): ?>
            <div class="brands-grid-title">
                <h2>Brands from <?= htmlspecialchars($origin_country) ?></h2>
                <span class="badge"><?= count($company_cards) ?> brands</span>
            </div>
            <?php if (empty($company_cards)): ?>
            <div class="cat-empty"><div class="em-icon">&#128269;</div><h3>No brands found</h3><p>No battery brands from "<?= htmlspecialchars($origin_country) ?>". Try a different country.</p></div>
            <?php else: ?>
            <div class="brands-grid">
                <?php foreach ($company_cards as $cc): ?>
                <a class="brand-card" href="<?= BASE_URL ?>batteries.php?country=<?= urlencode($origin_country) ?>&company=<?= (int)$cc['id'] ?>#products">
                    <div class="brand-card-logo">
                        <?php if (!empty($cc['logo_path'])): ?>
                            <img src="<?= htmlspecialchars(get_image_url($cc['logo_path'])) ?>" alt="<?= htmlspecialchars($cc['name']) ?>" loading="lazy">
                        <?php else: ?><span style="font-size:1.4rem;color:#94A3B8;">&#128267;</span><?php endif; ?>
                    </div>
                    <div class="brand-card-info">
                        <div class="brand-card-name"><?= htmlspecialchars($cc['name']) ?></div>
                        <div class="brand-card-meta"><?= (int)$cc['battery_count'] ?> batteries</div>
                        <div class="brand-card-price">
                            <span class="sg-price" data-v="<?= encP($cc['min_price'], $_pk) ?>" data-r="<?= $exchange_rate ?>" data-s="<?= htmlspecialchars($currency_symbol) ?>">—</span>
                            – <span class="sg-price" data-v="<?= encP($cc['max_price'], $_pk) ?>" data-r="<?= $exchange_rate ?>" data-s="<?= htmlspecialchars($currency_symbol) ?>">—</span>
                        </div>
                    </div>
                    <span class="brand-card-arrow">→</span>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php elseif ($state === 'products'): ?>
            <div class="products-header">
                <div>
                    <h2><?= htmlspecialchars($brand_name) ?> Batteries <span style="color:#64748B;font-weight:400;font-size:.88rem;">(<?= number_format($total) ?>)</span></h2>
                    <?php if ($has_filters): ?>
                    <div class="ph-meta">&#10003; Filters active ·
                        <?php if ($search) echo 'Search: "' . htmlspecialchars($search) . '" · '; ?>
                        <?php if ($type)   echo 'Type: ' . htmlspecialchars($type) . ' · '; ?>
                        <a href="<?= BASE_URL ?>batteries.php?country=<?= urlencode($origin_country) ?>&company=<?= $company_id ?>" style="color:#EF4444;font-weight:600;text-decoration:none;">Clear</a>
                    </div>
                    <?php endif; ?>
                </div>
                <select class="sort-select" onchange="applySort(this.value)">
                    <option value="price_asc"     <?= $sort==='price_asc'     ? 'selected':'' ?>>Price ↑</option>
                    <option value="price_desc"    <?= $sort==='price_desc'    ? 'selected':'' ?>>Price ↓</option>
                    <option value="capacity_asc"  <?= $sort==='capacity_asc'  ? 'selected':'' ?>>Capacity ↑</option>
                    <option value="capacity_desc" <?= $sort==='capacity_desc' ? 'selected':'' ?>>Capacity ↓</option>
                    <option value="name"          <?= $sort==='name'          ? 'selected':'' ?>>Name A→Z</option>
                </select>
            </div>

            <?php if (empty($batteries)): ?>
            <div class="cat-empty"><div class="em-icon">&#128269;</div><h3>No batteries found</h3><p>Try adjusting or clearing your filters.</p></div>
            <?php else: ?>
            <div class="products-grid" id="productsGrid">
                <?php foreach ($batteries as $idx => $battery):
                    if ($idx > 0 && $idx % 6 === 0) echo getInlineAdHtml('sidebar');
                    $kwh         = ($battery['capacity_ah'] * ($battery['nominal_voltage'] ?: 1)) / 1000;
                    $price_per_kwh = $kwh > 0 ? $battery['price_unit_usd'] / $kwh : 0;
                    $local_price = toLocal($battery['price_unit_usd'], $exchange_rate);
                    $badge_label = !empty($battery['type']) ? htmlspecialchars($battery['type']) : 'Standard';
                    $badge_class = strtolower(preg_replace('/[^a-z]/i', '', $battery['type'] ?? 'standard'));
                    $image_url   = !empty($battery['image_path']) ? get_image_url($battery['image_path']) : '';
                ?>
                <div class="product-card" data-id="<?= (int)$battery['id'] ?>">
                    <div class="product-card-top">
                        <span class="product-badge <?= $badge_class ?>"><?= $badge_label ?></span>
                        <label class="compare-toggle" title="Add to Compare">
                            <input type="checkbox" onchange="toggleCompare(<?= (int)$battery['id'] ?>,'battery','<?= htmlspecialchars(addslashes($battery['model']), ENT_QUOTES) ?>')">
                            <span class="compare-toggle-icon"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg></span>
                        </label>
                    </div>
                    <div class="product-image">
                        <?php if ($image_url): ?>
                            <img src="<?= htmlspecialchars($image_url) ?>" alt="<?= htmlspecialchars($battery['model']) ?>" loading="lazy">
                        <?php else: ?>
                            <div class="product-image-placeholder"><span>&#128267;</span></div>
                        <?php endif; ?>
                    </div>
                    <div class="product-info">
                        <div class="product-brand">
                            <?php if (!empty($battery['origin_flag']) || !empty($battery['origin_code'])): ?>
                                <span><?= get_country_flag(['flag_emoji'=>$battery['origin_flag']??'','flag_icon'=>$battery['origin_flag_icon']??'','code'=>$battery['origin_code']??''], 16) ?></span>
                            <?php endif; ?>
                            <?= htmlspecialchars($battery['company_name'] ?? '') ?>
                        </div>
                        <h3 class="product-name">
                            <a href="<?= BASE_URL ?>battery-detail.php?id=<?= (int)$battery['id'] ?>"><?= htmlspecialchars($battery['model']) ?></a>
                        </h3>
                        <div class="product-specs-grid">
                            <div class="spec-pill"><span class="spec-pill-icon">&#128267;</span><div><span class="spec-pill-label">Capacity</span><span class="spec-pill-value"><?= number_format($battery['capacity_ah']) ?> Ah</span></div></div>
                            <div class="spec-pill"><span class="spec-pill-icon">&#9889;</span><div><span class="spec-pill-label">Voltage</span><span class="spec-pill-value"><?= htmlspecialchars($battery['nominal_voltage']) ?>V</span></div></div>
                            <div class="spec-pill"><span class="spec-pill-icon">&#128161;</span><div><span class="spec-pill-label">Energy</span><span class="spec-pill-value"><?= number_format($kwh, 2) ?> kWh</span></div></div>
                            <div class="spec-pill"><span class="spec-pill-icon">&#128737;&#65039;</span><div><span class="spec-pill-label">Warranty</span><span class="spec-pill-value"><?= !empty($battery['warranty_years']) ? (int)$battery['warranty_years'] . ' yr' : 'N/A' ?></span></div></div>
                        </div>
                        <div class="product-features">
                            <?php if (!empty($battery['has_bms'])): ?><span class="feature-tag" style="background:#D1FAE5;color:#065F46;">BMS</span><?php endif; ?>
                            <?php if (!empty($battery['cycle_life'])): ?><span class="feature-tag"><?= number_format($battery['cycle_life']) ?> Cycles</span><?php endif; ?>
                            <?php if (!empty($battery['depth_of_discharge'])): ?><span class="feature-tag"><?= htmlspecialchars($battery['depth_of_discharge']) ?>% DoD</span><?php endif; ?>
                            <?php if (!empty($battery['ip_rating'])): ?><span class="feature-tag"><?= htmlspecialchars($battery['ip_rating']) ?></span><?php endif; ?>
                            <?php if (!empty($battery['max_parallel_units']) && $battery['max_parallel_units'] > 1): ?><span class="feature-tag" style="background:#059669;color:#fff;">&#8644; x<?= (int)$battery['max_parallel_units'] ?></span><?php endif; ?>
                        </div>
                    </div>
                    <div class="product-footer">
                        <div class="product-price">
                            <span class="price-local sg-price" data-v="<?= encP($battery['price_unit_usd'], $_pk) ?>" data-r="<?= $exchange_rate ?>" data-s="<?= htmlspecialchars($currency_symbol) ?>">—</span>
                            <?php if ($currency_code !== 'USD'): ?><span class="price-usd" data-usd="<?= encP($battery['price_unit_usd'], $_pk) ?>"></span><?php endif; ?>
                            <?php if ($price_per_kwh > 0): ?><span class="price-usd"><?= number_format($price_per_kwh, 0) ?> $/kWh</span><?php endif; ?>
                        </div>
                        <a href="<?= BASE_URL ?>battery-detail.php?id=<?= (int)$battery['id'] ?>" class="btn-view-details">Details →</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <?php $qp = array_filter($_GET, fn($k) => $k !== 'page', ARRAY_FILTER_USE_KEY); ?>
            <div class="pagination-wrap">
                <p class="pagination-info">Showing <?= min($page_num * $per_page, $total) ?> of <?= number_format($total) ?> batteries</p>
                <?php if ($page_num < $total_pages): ?>
                <a href="?<?= http_build_query(array_merge($qp, ['page' => $page_num + 1])) ?>#products" class="btn-load-more">Load More ↓</a>
                <?php endif; ?>
                <?php if ($total_pages > 1): ?>
                <div style="margin-top:16px;display:flex;justify-content:center;gap:6px;flex-wrap:wrap;">
                    <?php for ($p = 1; $p <= min($total_pages, 8); $p++): ?>
                    <a href="?<?= http_build_query(array_merge($qp, ['page' => $p])) ?>#products"
                       style="width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.82rem;font-weight:600;text-decoration:none;border:1.5px solid;<?= $p===$page_num?'background:#059669;color:#fff;border-color:#059669;':'background:#fff;color:#475569;border-color:#E2E8F0;' ?>">
                        <?= $p ?></a>
                    <?php endfor; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <?php endif; // end state ?>
        </main>
    </div>

    <?php renderAds('footer'); ?>
    <script src="assets/js/comparison-widget.js"></script>
    <script src="assets/js/products.js"></script>
    <script>
    (function() {
        var k = <?= (int)$_pk ?>;
        var sym = '<?= addslashes($currency_symbol) ?>';
        var rate = <?= (float)$exchange_rate ?>;
        function decodePrice(enc) {
            if (!enc) return null;
            try {
                var pad = enc.length % 4 === 0 ? enc : enc + '==='.slice(0, 4 - enc.length % 4);
                var num = parseInt(atob(pad), 10);
                return isNaN(num) ? null : num / (k * 100);
            } catch(e) { return null; }
        }
        document.querySelectorAll('.sg-price[data-v]').forEach(function(el) {
            var usd = decodePrice(el.dataset.v);
            if (usd !== null) {
                var s = el.dataset.s || sym, r = parseFloat(el.dataset.r) || rate;
                el.textContent = s + Math.round(usd * r).toLocaleString();
            }
        });
        document.querySelectorAll('[data-usd]').forEach(function(el) {
            var usd = decodePrice(el.dataset.usd);
            if (usd !== null) el.textContent = '$' + Math.round(usd).toLocaleString() + ' USD';
        });
    })();
    function applySort(v) { var u = new URL(location.href); u.searchParams.set('sort', v); u.searchParams.delete('page'); u.hash = 'products'; location.href = u; }
    var sidebar = document.getElementById('catSidebar'), overlay = document.getElementById('catFilterOverlay'), togBtn = document.getElementById('catFilterToggle');
    if (togBtn) togBtn.addEventListener('click', function() { sidebar.classList.toggle('open'); overlay.classList.toggle('open'); document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : ''; });
    if (overlay) overlay.addEventListener('click', function() { sidebar.classList.remove('open'); overlay.classList.remove('open'); document.body.style.overflow = ''; });
    function toggleSection(h) { var b = h.nextElementSibling; if (b) b.style.display = b.style.display === 'none' ? '' : 'none'; }
    function showMoreCountries(e) { e.preventDefault(); var el = document.getElementById('moreCountries'), btn = document.getElementById('showMoreCountries'); if (el) { el.style.display = ''; if (btn) btn.style.display = 'none'; } }
    function showMoreCompanies(e) { e.preventDefault(); var el = document.getElementById('moreCompanies'), btn = document.getElementById('showMoreCompanies'); if (el) { el.style.display = ''; if (btn) btn.style.display = 'none'; } }
    </script>
    <?php include 'includes/footer.php'; ?>
</body>
</html>
