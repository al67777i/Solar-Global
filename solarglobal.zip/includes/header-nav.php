<?php
/**
 * Navigation Component (no <head> or <body> tags)
 * Include this inside <body> on pages that have their own <head>
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$current_page = $current_page ?? basename($_SERVER['PHP_SELF'], '.php');

// Customer login state
$_customer_logged_in = !empty($_SESSION['customer_logged_in']);
$_customer_name = $_SESSION['customer_name'] ?? '';
$_customer_avatar = $_SESSION['customer_avatar'] ?? '';
$_customer_email = $_SESSION['customer_email'] ?? '';

// Dynamic branding
$_site_name = $_site_name ?? get_system_setting('site_name', 'SolarGlobal');
$_site_tagline = $_site_tagline ?? get_system_setting('site_tagline', 'Smart Solar Advisor');
?>
<style>
/* ===== SolarGlobal Navigation v2 (inline) ===== */
.sg-nav {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    background: #ffffff;
    border-bottom: 1px solid #E2E8F0;
    transition: box-shadow 0.3s ease;
    font-family: 'Inter', sans-serif;
}
.sg-nav.scrolled {
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
}
.sg-nav-inner {
    max-width: 1280px;
    margin: 0 auto;
    padding: 0 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 68px;
}
.sg-logo {
    display: flex;
    align-items: center;
    gap: 10px;
    text-decoration: none;
    color: inherit;
    flex-shrink: 0;
}
.sg-logo-icon {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
}
.sg-logo-text {
    font-size: 1.25rem;
    font-weight: 700;
    color: #0F172A;
    margin: 0;
    line-height: 1.2;
}
.sg-logo-tagline {
    font-size: 0.7rem;
    color: #64748B;
    margin: 0;
    font-weight: 400;
    letter-spacing: 0.02em;
}
.sg-menu {
    display: flex;
    align-items: center;
    gap: 4px;
    list-style: none;
    margin: 0;
    padding: 0;
}
.sg-menu-item {
    position: relative;
}
.sg-menu-link {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 8px 16px;
    font-size: 0.9rem;
    font-weight: 500;
    color: #334155;
    text-decoration: none;
    border-radius: 6px;
    transition: color 0.2s, background 0.2s;
    white-space: nowrap;
    cursor: pointer;
    border: none;
    background: none;
    font-family: inherit;
}
.sg-menu-link:hover {
    color: #0F172A;
    background: #F8FAFC;
}
.sg-menu-link.active {
    color: #D97706;
    position: relative;
}
.sg-menu-link.active::after {
    content: '';
    position: absolute;
    bottom: -4px;
    left: 16px;
    right: 16px;
    height: 2px;
    background: #F59E0B;
    border-radius: 1px;
}
.sg-menu-arrow {
    font-size: 0.6rem;
    transition: transform 0.2s;
    color: #94A3B8;
}
.sg-dropdown {
    position: absolute;
    top: calc(100% + 8px);
    left: 0;
    min-width: 200px;
    background: #ffffff;
    border: 1px solid #E2E8F0;
    border-radius: 10px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    padding: 6px;
    opacity: 0;
    visibility: hidden;
    transform: translateY(-4px);
    transition: opacity 0.2s, transform 0.2s, visibility 0.2s;
    z-index: 100;
}
.sg-menu-item:hover > .sg-dropdown,
.sg-menu-item.open > .sg-dropdown {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}
.sg-menu-item:hover > .sg-menu-link .sg-menu-arrow,
.sg-menu-item.open > .sg-menu-link .sg-menu-arrow {
    transform: rotate(180deg);
}
.sg-dropdown-link {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    font-size: 0.875rem;
    font-weight: 450;
    color: #334155;
    text-decoration: none;
    border-radius: 6px;
    transition: background 0.15s, color 0.15s;
}
.sg-dropdown-link:hover {
    background: #FFF7ED;
    color: #D97706;
}
.sg-dropdown-link .sg-dd-icon {
    width: 32px;
    height: 32px;
    background: #F1F5F9;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.9rem;
    flex-shrink: 0;
}
.sg-dropdown-link:hover .sg-dd-icon {
    background: #FEF3C7;
}
.sg-nav-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
}
.sg-btn-partner {
    padding: 8px 18px;
    font-size: 0.85rem;
    font-weight: 600;
    color: #ffffff;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: opacity 0.2s, transform 0.15s;
    font-family: inherit;
    text-decoration: none;
    white-space: nowrap;
}
.sg-btn-partner:hover {
    opacity: 0.92;
    transform: translateY(-1px);
}
.sg-btn-login {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    border: 1px solid #E2E8F0;
    background: #F8FAFC;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: border-color 0.2s, background 0.2s;
    font-size: 1rem;
    color: #64748B;
}
.sg-btn-login:hover {
    border-color: #F59E0B;
    background: #FFF7ED;
    color: #D97706;
}
.sg-user-avatar {
    width: 38px; height: 38px; border-radius: 50%; border: 2px solid #F59E0B;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; overflow: hidden; background: #F59E0B; color: #1E293B;
    font-weight: 700; font-size: 0.875rem;
}
.sg-user-avatar img { width: 100%; height: 100%; object-fit: cover; }
.sg-dropdown-greeting {
    padding: 12px 14px; font-size: 0.8125rem; font-weight: 600; color: #1E293B;
    border-bottom: 1px solid #E2E8F0; margin-bottom: 4px;
}
.sg-dropdown-divider {
    height: 1px; background: #E2E8F0; margin: 4px 0;
}
.sg-cart-btn {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 38px;
    height: 38px;
    border-radius: 10px;
    border: 2px solid #E2E8F0;
    background: white;
    cursor: pointer;
    color: #475569;
    transition: all 0.2s;
    text-decoration: none;
}
.sg-cart-btn:hover { border-color: #F59E0B; color: #D97706; background: #FFF7ED; }
.sg-cart-badge {
    position: absolute;
    top: -5px; right: -5px;
    background: #F59E0B;
    color: #1E293B;
    font-size: 0.6rem;
    font-weight: 800;
    min-width: 16px;
    height: 16px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    line-height: 1;
    padding: 0 4px;
}
.sg-login-wrap {
    position: relative;
}
.sg-login-wrap .sg-dropdown {
    right: 0;
    left: auto;
    min-width: 180px;
}
.sg-partner-wrap {
    position: relative;
}
.sg-partner-wrap .sg-dropdown {
    right: 0;
    left: auto;
    min-width: 200px;
}
.sg-nav-spacer {
    height: 68px;
}

/* Mobile Bottom Nav */
.sg-bottom-nav {
    display: none;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    background: #ffffff;
    border-top: 1px solid #E2E8F0;
    box-shadow: 0 -2px 12px rgba(0,0,0,0.06);
    padding: 6px 0 max(6px, env(safe-area-inset-bottom));
}
.sg-bottom-nav-inner {
    display: flex;
    align-items: center;
    justify-content: space-around;
    max-width: 500px;
    margin: 0 auto;
}
.sg-bottom-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
    padding: 6px 12px;
    min-height: 44px;
    min-width: 44px;
    text-decoration: none;
    color: #64748B;
    border: none;
    background: none;
    cursor: pointer;
    font-family: inherit;
    transition: color 0.2s;
    -webkit-tap-highlight-color: transparent;
}
.sg-bottom-item.active {
    color: #D97706;
}
.sg-bottom-icon {
    font-size: 1.25rem;
    line-height: 1;
}
.sg-bottom-label {
    font-size: 0.65rem;
    font-weight: 500;
    letter-spacing: 0.01em;
}

/* More Menu Sheet */
.sg-more-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.4);
    z-index: 1100;
    opacity: 0;
    transition: opacity 0.3s;
}
.sg-more-overlay.active {
    display: block;
    opacity: 1;
}
.sg-more-sheet {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 1200;
    background: #ffffff;
    border-radius: 16px 16px 0 0;
    max-height: 80vh;
    overflow-y: auto;
    transform: translateY(100%);
    transition: transform 0.35s cubic-bezier(0.32, 0.72, 0, 1);
    padding-bottom: max(16px, env(safe-area-inset-bottom));
}
.sg-more-sheet.active {
    transform: translateY(0);
}
.sg-more-handle {
    width: 36px;
    height: 4px;
    background: #CBD5E1;
    border-radius: 2px;
    margin: 10px auto 4px;
}
.sg-more-header {
    padding: 12px 20px 8px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.sg-more-title {
    font-size: 1.1rem;
    font-weight: 700;
    color: #0F172A;
    margin: 0;
}
.sg-more-close {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    border: none;
    background: #F1F5F9;
    font-size: 1.1rem;
    color: #64748B;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}
.sg-more-section {
    padding: 4px 16px;
}
.sg-more-section-title {
    font-size: 0.7rem;
    font-weight: 600;
    color: #94A3B8;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    padding: 12px 8px 6px;
    margin: 0;
}
.sg-more-link {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 8px;
    text-decoration: none;
    color: #334155;
    font-size: 0.9rem;
    font-weight: 450;
    border-radius: 8px;
    transition: background 0.15s;
    min-height: 44px;
}
.sg-more-link:hover,
.sg-more-link:active {
    background: #F8FAFC;
}
.sg-more-link-icon {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    background: #F1F5F9;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
}
.sg-more-link.highlight {
    color: #D97706;
    font-weight: 600;
}
.sg-more-link.highlight .sg-more-link-icon {
    background: #FEF3C7;
}
.sg-more-divider {
    height: 1px;
    background: #F1F5F9;
    margin: 4px 20px;
}

/* Responsive */
@media (max-width: 1024px) {
    .sg-menu,
    .sg-nav-actions {
        display: none;
    }
    .sg-bottom-nav {
        display: block;
    }
    .sg-nav-inner {
        height: 56px;
    }
    .sg-nav-spacer {
        height: 56px;
    }
}
@media (min-width: 1025px) {
    .sg-bottom-nav,
    .sg-more-overlay,
    .sg-more-sheet {
        display: none !important;
    }
}
</style>

    <!-- Top Navigation -->
    <nav class="sg-nav main-nav" id="mainNav">
        <div class="sg-nav-inner nav-container">
            <!-- Logo -->
            <a href="index.php" class="sg-logo nav-logo">
                <div class="sg-logo-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                </div>
                <div>
                    <h1 class="sg-logo-text"><?= sanitize($_site_name) ?></h1>
                    <p class="sg-logo-tagline"><?= sanitize($_site_tagline) ?></p>
                </div>
            </a>

            <!-- Desktop Menu -->
            <ul class="sg-menu nav-menu" id="navMenu">
                <li class="sg-menu-item">
                    <a href="index.php" class="sg-menu-link <?php echo $current_page == 'index' ? 'active' : ''; ?>">Home</a>
                </li>
                <li class="sg-menu-item">
                    <button type="button" class="sg-menu-link <?php echo in_array($current_page, ['find-installer','stores','store-detail']) ? 'active' : ''; ?>">
                        Services <span class="sg-menu-arrow">&#9662;</span>
                    </button>
                    <div class="sg-dropdown">
                        <a href="stores.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#127978;</span>
                            <span>Browse Stores</span>
                        </a>
                        <a href="find-installer.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128270;</span>
                            <span>Find Installer</span>
                        </a>
                        <a href="index.php#calculator" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#9889;</span>
                            <span>Solar Calculator</span>
                        </a>
                    </div>
                </li>
                <li class="sg-menu-item">
                    <button type="button" class="sg-menu-link <?php echo in_array($current_page, ['inverters','batteries','panels','compare']) ? 'active' : ''; ?>">
                        Products <span class="sg-menu-arrow">&#9662;</span>
                    </button>
                    <div class="sg-dropdown">
                        <a href="inverters.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#9889;</span>
                            <span>Inverters</span>
                        </a>
                        <a href="batteries.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128267;</span>
                            <span>Batteries</span>
                        </a>
                        <a href="panels.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#9728;</span>
                            <span>Solar Panels</span>
                        </a>
                        <a href="appliances.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#9889;</span>
                            <span>Appliances</span>
                        </a>
                        <a href="compare.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#9878;</span>
                            <span>Compare Products</span>
                        </a>
                    </div>
                </li>
                <li class="sg-menu-item">
                    <a href="store.php" class="sg-menu-link <?php echo $current_page == 'store' ? 'active' : ''; ?>">Solar Shop</a>
                </li>
                <li class="sg-menu-item">
                    <a href="about.php" class="sg-menu-link <?php echo $current_page == 'about' ? 'active' : ''; ?>">About</a>
                </li>
                <li class="sg-menu-item">
                    <a href="contact.php" class="sg-menu-link <?php echo $current_page == 'contact' ? 'active' : ''; ?>">Contact</a>
                </li>
            </ul>

            <!-- Right Actions -->
            <div class="sg-nav-actions">
                <div class="sg-partner-wrap sg-menu-item">
                    <button type="button" class="sg-btn-partner">
                        Become a Partner <span class="sg-menu-arrow" style="color:rgba(255,255,255,0.7)">&#9662;</span>
                    </button>
                    <div class="sg-dropdown">
                        <a href="become-dealer.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#127978;</span>
                            <span>Open a Store</span>
                        </a>
                        <a href="become-installer.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128295;</span>
                            <span>Become an Installer</span>
                        </a>
                    </div>
                </div>
                <?php
                    $hdr_cart_count = 0;
                    if (session_status() === PHP_SESSION_NONE) session_start();
                    if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
                        foreach ($_SESSION['cart'] as $dc) {
                            if (!empty($dc['items'])) foreach ($dc['items'] as $ci) $hdr_cart_count += ($ci['quantity'] ?? 1);
                        }
                    }
                ?>
                <a href="/solarglobal/customer/cart.php?view=cart" class="sg-cart-btn" title="Shopping Cart">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
                    <?php if ($hdr_cart_count > 0): ?><span class="sg-cart-badge"><?= $hdr_cart_count ?></span><?php endif; ?>
                </a>
                <div class="sg-login-wrap sg-menu-item">
                    <?php if ($_customer_logged_in): ?>
                    <button type="button" class="sg-user-avatar" aria-label="Account menu">
                        <?php if (!empty($_customer_avatar)): ?>
                            <img src="<?= htmlspecialchars($_customer_avatar) ?>" alt="<?= htmlspecialchars($_customer_name) ?>">
                        <?php else: ?>
                            <?= strtoupper(mb_substr($_customer_name ?: 'U', 0, 1)) ?>
                        <?php endif; ?>
                    </button>
                    <div class="sg-dropdown">
                        <div class="sg-dropdown-greeting">Hi, <?= htmlspecialchars($_customer_name ?: 'Customer') ?></div>
                        <a href="/solarglobal/customer/orders.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128230;</span>
                            <span>My Orders</span>
                        </a>
                        <a href="/solarglobal/customer/cart.php?view=cart" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128722;</span>
                            <span>Cart</span>
                        </a>
                        <a href="/solarglobal/customer/watchlist.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128065;</span>
                            <span>Watchlist</span>
                        </a>
                        <a href="/solarglobal/customer/reviews.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#11088;</span>
                            <span>My Reviews</span>
                        </a>
                        <a href="/solarglobal/customer/installations.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128295;</span>
                            <span>My Installations</span>
                        </a>
                        <div class="sg-dropdown-divider"></div>
                        <a href="/solarglobal/customer/logout.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128682;</span>
                            <span>Logout</span>
                        </a>
                    </div>
                    <?php else: ?>
                    <button type="button" class="sg-btn-login" aria-label="Login options">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </button>
                    <div class="sg-dropdown">
                        <a href="customer/login.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128722;</span>
                            <span>Customer Login</span>
                        </a>
                        <a href="dealer/login.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128100;</span>
                            <span>Dealer Login</span>
                        </a>
                        <a href="installer/login.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128295;</span>
                            <span>Installer Login</span>
                        </a>
                        <a href="login.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128272;</span>
                            <span>Admin</span>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Nav spacer -->
    <div class="sg-nav-spacer"></div>

    <!-- Mobile Bottom Navigation -->
    <nav class="sg-bottom-nav bottom-nav" id="bottomNav">
        <div class="sg-bottom-nav-inner">
            <a href="index.php" class="sg-bottom-item <?php echo $current_page == 'index' ? 'active' : ''; ?>">
                <span class="sg-bottom-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                </span>
                <span class="sg-bottom-label">Home</span>
            </a>
            <a href="inverters.php" class="sg-bottom-item <?php echo in_array($current_page, ['inverters','batteries','panels','compare']) ? 'active' : ''; ?>">
                <span class="sg-bottom-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v3"/><line x1="12" y1="11" x2="12" y2="17"/><line x1="9" y1="14" x2="15" y2="14"/></svg>
                </span>
                <span class="sg-bottom-label">Products</span>
            </a>
            <a href="find-installer.php" class="sg-bottom-item <?php echo $current_page == 'find-installer' ? 'active' : ''; ?>">
                <span class="sg-bottom-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
                </span>
                <span class="sg-bottom-label">Services</span>
            </a>
            <a href="index.php#calculator" class="sg-bottom-item">
                <span class="sg-bottom-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2"/><line x1="8" y1="6" x2="16" y2="6"/><line x1="8" y1="10" x2="10" y2="10"/><line x1="14" y1="10" x2="16" y2="10"/><line x1="8" y1="14" x2="10" y2="14"/><line x1="14" y1="14" x2="16" y2="14"/><line x1="8" y1="18" x2="16" y2="18"/></svg>
                </span>
                <span class="sg-bottom-label">Calculator</span>
            </a>
            <button type="button" class="sg-bottom-item" id="moreMenuBtn" aria-label="More options">
                <span class="sg-bottom-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="1.5" fill="currentColor"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/><circle cx="12" cy="19" r="1.5" fill="currentColor"/></svg>
                </span>
                <span class="sg-bottom-label">More</span>
            </button>
        </div>
    </nav>

    <!-- More Menu Overlay -->
    <div class="sg-more-overlay more-menu-overlay" id="moreMenuOverlay"></div>

    <!-- More Menu Sheet -->
    <div class="sg-more-sheet more-menu" id="moreMenu">
        <div class="sg-more-handle"></div>
        <div class="sg-more-header">
            <h2 class="sg-more-title">Menu</h2>
            <button type="button" class="sg-more-close" id="moreMenuClose" aria-label="Close menu">&#10005;</button>
        </div>

        <!-- Solar Shop (standalone) -->
        <div class="sg-more-section">
            <a href="store.php" class="sg-more-link" style="font-weight:700;color:#F59E0B;">
                <span class="sg-more-link-icon">&#9889;</span>
                <span>Solar Shop</span>
            </a>
        </div>

        <div class="sg-more-divider"></div>

        <!-- Services -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">Services</h3>
            <a href="stores.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#127978;</span>
                <span>Browse Stores</span>
            </a>
            <a href="find-installer.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128270;</span>
                <span>Find Installer</span>
            </a>
            <a href="index.php#calculator" class="sg-more-link">
                <span class="sg-more-link-icon">&#9889;</span>
                <span>Solar Calculator</span>
            </a>
        </div>

        <div class="sg-more-divider"></div>

        <!-- Products -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">Products</h3>
            <a href="inverters.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#9889;</span>
                <span>Inverters</span>
            </a>
            <a href="batteries.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128267;</span>
                <span>Batteries</span>
            </a>
            <a href="panels.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#9728;</span>
                <span>Solar Panels</span>
            </a>
            <a href="appliances.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#9889;</span>
                <span>Appliances</span>
            </a>
            <a href="compare.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#9878;</span>
                <span>Compare Products</span>
            </a>
        </div>

        <div class="sg-more-divider"></div>

        <!-- For Business -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">For Business</h3>
            <a href="become-dealer.php" class="sg-more-link highlight">
                <span class="sg-more-link-icon">&#127978;</span>
                <span>Open Your Store</span>
            </a>
            <a href="become-installer.php" class="sg-more-link highlight">
                <span class="sg-more-link-icon">&#128295;</span>
                <span>Become an Installer</span>
            </a>
        </div>

        <div class="sg-more-divider"></div>

        <!-- Account -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">Account</h3>
            <?php if ($_customer_logged_in): ?>
            <div style="padding: 8px 16px; font-size: 0.8125rem; font-weight: 600; color: #1E293B;">Hi, <?= htmlspecialchars($_customer_name ?: 'Customer') ?></div>
            <a href="/solarglobal/customer/orders.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128230;</span>
                <span>My Orders</span>
            </a>
            <a href="/solarglobal/customer/cart.php?view=cart" class="sg-more-link">
                <span class="sg-more-link-icon">&#128722;</span>
                <span>Cart</span>
            </a>
            <a href="/solarglobal/customer/watchlist.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128065;</span>
                <span>Watchlist</span>
            </a>
            <a href="/solarglobal/customer/reviews.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#11088;</span>
                <span>My Reviews</span>
            </a>
            <a href="/solarglobal/customer/logout.php" class="sg-more-link" style="color: #DC2626;">
                <span class="sg-more-link-icon">&#128682;</span>
                <span>Logout</span>
            </a>
            <?php else: ?>
            <a href="customer/login.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128722;</span>
                <span>Customer Login</span>
            </a>
            <a href="dealer/login.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128100;</span>
                <span>Dealer Login</span>
            </a>
            <a href="installer/login.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128295;</span>
                <span>Installer Login</span>
            </a>
            <?php endif; ?>
        </div>

        <div class="sg-more-divider"></div>

        <!-- Company -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">Company</h3>
            <a href="about.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#8505;</span>
                <span>About Us</span>
            </a>
            <a href="contact.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#9993;</span>
                <span>Contact Us</span>
            </a>
        </div>

        <div class="sg-more-divider"></div>

        <!-- Admin -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">Admin</h3>
            <a href="login.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128272;</span>
                <span>Admin Panel</span>
            </a>
        </div>
    </div>

    <script>
    (function() {
        // Scroll shadow
        window.addEventListener('scroll', function() {
            var nav = document.getElementById('mainNav');
            if (nav) nav.classList.toggle('scrolled', window.scrollY > 10);
        });

        // Desktop dropdown click support
        document.querySelectorAll('.sg-menu-item > button.sg-menu-link, .sg-btn-partner, .sg-btn-login, .sg-user-avatar').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                var parent = this.closest('.sg-menu-item, .sg-partner-wrap, .sg-login-wrap');
                if (parent) {
                    document.querySelectorAll('.sg-menu-item.open, .sg-partner-wrap.open, .sg-login-wrap.open').forEach(function(el) {
                        if (el !== parent) el.classList.remove('open');
                    });
                    parent.classList.toggle('open');
                    e.stopPropagation();
                }
            });
        });
        document.addEventListener('click', function() {
            document.querySelectorAll('.sg-menu-item.open, .sg-partner-wrap.open, .sg-login-wrap.open').forEach(function(el) {
                el.classList.remove('open');
            });
        });

        // More menu toggle
        var moreBtn = document.getElementById('moreMenuBtn');
        var moreMenu = document.getElementById('moreMenu');
        var moreOverlay = document.getElementById('moreMenuOverlay');
        var moreClose = document.getElementById('moreMenuClose');

        function openMore() {
            if (moreMenu && moreOverlay) {
                moreOverlay.classList.add('active');
                moreMenu.offsetHeight;
                moreMenu.classList.add('active');
            }
        }
        function closeMore() {
            if (moreMenu && moreOverlay) {
                moreMenu.classList.remove('active');
                moreOverlay.classList.remove('active');
            }
        }
        if (moreBtn) moreBtn.addEventListener('click', openMore);
        if (moreOverlay) moreOverlay.addEventListener('click', closeMore);
        if (moreClose) moreClose.addEventListener('click', closeMore);
    })();
    </script>
