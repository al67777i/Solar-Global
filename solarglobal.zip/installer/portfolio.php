<?php
/**
 * Installer Portfolio Management
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/installer_auth.php';

set_security_headers();
require_installer_login();
require_installer_subscription();

$installer = get_installer_profile();
$db = getDB();
$errors = [];
$success = '';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please try again.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'add_project') {
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $system_size = trim($_POST['system_size'] ?? '');
            $project_type = trim($_POST['project_type'] ?? '');

            if (empty($title)) $errors[] = 'Project title is required.';

            // Handle image upload
            $image_path = null;
            if (isset($_FILES['project_image']) && $_FILES['project_image']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['project_image'];
                $allowed_types = ['image/jpeg', 'image/png', 'image/webp'];
                $max_size = 5 * 1024 * 1024; // 5MB

                if (!in_array($file['type'], $allowed_types)) {
                    $errors[] = 'Image must be JPG, PNG, or WebP format.';
                } elseif ($file['size'] > $max_size) {
                    $errors[] = 'Image file must be under 5MB.';
                } else {
                    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $filename = 'portfolio_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                    $upload_dir = __DIR__ . '/../uploads/installers/portfolio/';
                    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

                    if (move_uploaded_file($file['tmp_name'], $upload_dir . $filename)) {
                        $image_path = 'uploads/installers/portfolio/' . $filename;
                    } else {
                        $errors[] = 'Failed to upload image.';
                    }
                }
            } else {
                $errors[] = 'Project image is required.';
            }

            if (empty($errors)) {
                try {
                    $stmt = $db->prepare("
                        INSERT INTO installer_portfolio (installer_id, title, description, system_size, project_type, image_path, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $stmt->execute([
                        $installer['id'], $title, $description, $system_size, $project_type, $image_path
                    ]);
                    $success = 'Project added to portfolio!';
                } catch (Exception $e) {
                    error_log("Portfolio add error: " . $e->getMessage());
                    $errors[] = 'Failed to add project. Please try again.';
                }
            }
        } elseif ($action === 'delete_project') {
            $project_id = (int)($_POST['project_id'] ?? 0);
            if ($project_id > 0) {
                // Verify ownership
                $stmt = $db->prepare("SELECT image_path FROM installer_portfolio WHERE id = ? AND installer_id = ?");
                $stmt->execute([$project_id, $installer['id']]);
                $project = $stmt->fetch();

                if ($project) {
                    // Delete file
                    $file_path = __DIR__ . '/../' . $project['image_path'];
                    if (file_exists($file_path)) unlink($file_path);

                    $stmt = $db->prepare("DELETE FROM installer_portfolio WHERE id = ? AND installer_id = ?");
                    $stmt->execute([$project_id, $installer['id']]);
                    $success = 'Project removed from portfolio.';
                }
            }
        }
    }
}

// Fetch portfolio items
$stmt = $db->prepare("SELECT * FROM installer_portfolio WHERE installer_id = ? ORDER BY created_at DESC");
$stmt->execute([$installer['id']]);
$portfolio_items = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio - <?= sanitize($installer['business_name']) ?> | <?= get_system_setting('site_name', 'SolarGlobal') ?> Installer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 260px;
            background: #0F172A; color: white; z-index: 100;
            display: flex; flex-direction: column; transition: transform 0.3s;
        }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid #1E293B; }
        .sidebar-header h2 { font-size: 1.25rem; font-weight: 800; color: #F59E0B; }
        .sidebar-header p { font-size: 0.75rem; color: #94A3B8; margin-top: 2px; }
        .sidebar-nav { flex: 1; padding: 16px 12px; overflow-y: auto; }
        .nav-section { margin-bottom: 24px; }
        .nav-section-title { font-size: 0.6875rem; text-transform: uppercase; letter-spacing: 1px; color: #475569; padding: 0 12px; margin-bottom: 8px; font-weight: 600; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 8px; color: #CBD5E1; text-decoration: none; font-size: 0.875rem; font-weight: 500; transition: all 0.2s; }
        .nav-item:hover { background: #1E293B; color: white; }
        .nav-item.active { background: #D97706; color: white; }
        .nav-item .icon { font-size: 1.125rem; width: 24px; text-align: center; }

        .main-content { margin-left: 260px; padding: 24px 32px; min-height: 100vh; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; }
        .top-bar h1 { font-size: 1.5rem; font-weight: 700; color: #1E293B; }

        .mobile-menu-btn { display: none; background: #0F172A; color: white; border: none; width: 40px; height: 40px; border-radius: 8px; font-size: 1.25rem; cursor: pointer; }

        .form-card {
            background: white; border-radius: 14px; padding: 32px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
            margin-bottom: 24px;
        }
        .form-card h3 { font-size: 1.125rem; font-weight: 700; color: #1E293B; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid #F1F5F9; }

        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media (max-width: 600px) { .form-row { grid-template-columns: 1fr; } }

        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 0.875rem; font-weight: 600; color: #334155; margin-bottom: 6px; }
        .form-group label .required { color: #DC2626; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%; padding: 12px 16px; border: 2px solid #E2E8F0;
            border-radius: 10px; font-size: 0.9375rem; font-family: inherit;
            transition: all 0.2s; background: #F8FAFC;
        }
        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            outline: none; border-color: #F59E0B; box-shadow: 0 0 0 3px rgba(245,158,11,0.15); background: white;
        }
        .form-group textarea { resize: vertical; min-height: 80px; }

        .btn-save {
            padding: 14px 32px; border: none; border-radius: 10px; font-size: 0.9375rem; font-weight: 700; cursor: pointer;
            background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%); color: white; transition: all 0.3s;
        }
        .btn-save:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(245,158,11,0.3); }

        .success-msg { background: #DCFCE7; border: 1px solid #BBF7D0; color: #166534; padding: 12px 16px; border-radius: 10px; margin-bottom: 20px; font-size: 0.875rem; border-left: 4px solid #16A34A; }
        .error-list { background: #FEF2F2; border: 1px solid #FECACA; border-radius: 10px; padding: 12px 16px; margin-bottom: 20px; border-left: 4px solid #DC2626; }
        .error-list ul { margin: 0; padding-left: 20px; }
        .error-list li { font-size: 0.875rem; color: #991B1B; margin-bottom: 4px; }

        /* Portfolio Grid */
        .portfolio-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 24px;
        }
        .portfolio-item {
            background: white; border-radius: 14px; overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
            transition: all 0.2s;
        }
        .portfolio-item:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.08); }
        .portfolio-item img {
            width: 100%; height: 200px; object-fit: cover;
        }
        .portfolio-item .p-content { padding: 16px; }
        .portfolio-item .p-title { font-size: 1rem; font-weight: 700; color: #1E293B; margin-bottom: 6px; }
        .portfolio-item .p-desc { font-size: 0.8125rem; color: #64748B; margin-bottom: 8px; line-height: 1.4; }
        .portfolio-item .p-meta { display: flex; gap: 12px; font-size: 0.75rem; color: #94A3B8; margin-bottom: 12px; }
        .portfolio-item .p-meta span { background: #F1F5F9; padding: 3px 8px; border-radius: 4px; }
        .portfolio-item .p-actions { display: flex; justify-content: flex-end; }
        .btn-delete {
            padding: 8px 16px; border: 1px solid #FECACA; border-radius: 8px;
            background: #FEF2F2; color: #DC2626; font-size: 0.8125rem; font-weight: 600;
            cursor: pointer; transition: all 0.2s;
        }
        .btn-delete:hover { background: #DC2626; color: white; }

        .empty-state {
            text-align: center; padding: 60px 24px; color: #94A3B8;
            background: white; border-radius: 14px; border: 1px solid #E2E8F0;
        }
        .empty-state .e-icon { font-size: 3rem; margin-bottom: 12px; }
        .empty-state p { font-size: 0.9375rem; }

        @media (max-width: 900px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .mobile-menu-btn { display: block; }
        }
        .overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 90; }
        .overlay.active { display: block; }
    </style>
</head>
<body>
    <?php $current_installer_page = 'portfolio'; include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="top-bar">
            <div>
                <button class="mobile-menu-btn" onclick="toggleSidebar()">&#9776;</button>
                <h1>Portfolio</h1>
            </div>
        </div>

        <?php if ($success): ?>
            <div class="success-msg"><?= sanitize($success) ?></div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
            <div class="error-list"><ul><?php foreach ($errors as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul></div>
        <?php endif; ?>

        <!-- Add Project Form -->
        <div class="form-card">
            <h3>&#10133; Add New Project</h3>
            <form method="POST" action="" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="add_project">

                <div class="form-row">
                    <div class="form-group">
                        <label>Project Title <span class="required">*</span></label>
                        <input type="text" name="title" required maxlength="200" placeholder="e.g., Residential 10kW Installation">
                    </div>
                    <div class="form-group">
                        <label>System Size (kW)</label>
                        <input type="text" name="system_size" maxlength="50" placeholder="e.g., 10 kW">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Project Type</label>
                        <select name="project_type">
                            <option value="">Select type</option>
                            <option value="Residential">Residential</option>
                            <option value="Commercial">Commercial</option>
                            <option value="Industrial">Industrial</option>
                            <option value="Off-Grid">Off-Grid</option>
                            <option value="On-Grid">On-Grid</option>
                            <option value="Hybrid">Hybrid</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Project Image <span class="required">*</span></label>
                        <input type="file" name="project_image" accept="image/jpeg,image/png,image/webp" required style="padding:10px;">
                    </div>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" maxlength="500" placeholder="Brief description of the project..."></textarea>
                </div>

                <button type="submit" class="btn-save">&#10133; Add to Portfolio</button>
            </form>
        </div>

        <!-- Portfolio Gallery -->
        <?php if (empty($portfolio_items)): ?>
            <div class="empty-state">
                <div class="e-icon">&#128247;</div>
                <p>No projects in your portfolio yet. Add your first installation above!</p>
            </div>
        <?php else: ?>
            <div class="portfolio-grid">
                <?php foreach ($portfolio_items as $item): ?>
                    <div class="portfolio-item">
                        <img src="/solarglobal/<?= sanitize($item['image_path']) ?>" alt="<?= sanitize($item['title']) ?>">
                        <div class="p-content">
                            <div class="p-title"><?= sanitize($item['title']) ?></div>
                            <?php if ($item['description']): ?>
                                <div class="p-desc"><?= sanitize(substr($item['description'], 0, 150)) ?></div>
                            <?php endif; ?>
                            <div class="p-meta">
                                <?php if ($item['system_size']): ?>
                                    <span><?= sanitize($item['system_size']) ?></span>
                                <?php endif; ?>
                                <?php if ($item['project_type']): ?>
                                    <span><?= sanitize($item['project_type']) ?></span>
                                <?php endif; ?>
                                <span><?= date('M Y', strtotime($item['created_at'])) ?></span>
                            </div>
                            <div class="p-actions">
                                <form method="POST" action="" style="display:inline" onsubmit="return confirm('Delete this project?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete_project">
                                    <input type="hidden" name="project_id" value="<?= $item['id'] ?>">
                                    <button type="submit" class="btn-delete">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

</body>
</html>
