<?php
/**
 * Migration: Ensure price_usd column exists on all product tables
 * Copies data from price_pkr if price_usd is empty/zero
 */
require_once __DIR__ . '/../includes/db.php';
$db = getDB();

echo "=== Ensure price_usd columns ===\n";

$tables = ['inverters', 'batteries', 'panels'];

foreach ($tables as $table) {
    // Add price_usd if missing
    try {
        $db->exec("ALTER TABLE {$table} ADD COLUMN price_usd DECIMAL(10,2) DEFAULT 0");
        echo "  [+] Added price_usd to {$table}\n";
    } catch (Exception $e) {
        echo "  [=] price_usd already exists on {$table}\n";
    }

    // Copy price_pkr → price_usd where price_usd is 0 or NULL but price_pkr has data
    // Note: price_pkr values ARE in PKR, so we convert to USD (rough rate ~280 PKR/USD)
    try {
        $stmt = $db->exec("
            UPDATE {$table}
            SET price_usd = ROUND(price_pkr / 280, 2)
            WHERE (price_usd IS NULL OR price_usd = 0)
              AND price_pkr IS NOT NULL AND price_pkr > 0
        ");
        echo "  [OK] Synced price_pkr → price_usd for {$table} ({$stmt} rows)\n";
    } catch (Exception $e) {
        // price_pkr may not exist on this table
        echo "  [SKIP] {$table}: " . $e->getMessage() . "\n";
    }
}

echo "\nDone!\n";
