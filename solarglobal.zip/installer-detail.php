﻿<?php
/**
 * Installer Detail Page — Public
 * Full professional profile: stats, about, portfolio, reviews, service areas, contact
 * URL: installer-detail.php?id=1
 */
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/csrf.php';
require_once 'includes/location_helper.php';

set_security_headers();
$db = getDB();

// ─── AJAX: Submit Review (POST) ────────────────────────────
if (isset($_GET['ajax']) && $_GET['ajax'] === 'submit_review' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    if (!rate_limit('inst_review_' . ($_SERVER['REMOTE_ADDR'] ?? ''), 5, 300)) {
        echo json_encode(['error' => 'Too many requests. Please try again later.']);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) $input = $_POST;

    if (!validate_csrf_token($input['csrf_token'] ?? '')) {
        http_response_code(403);
        echo json_encode(['error' => 'Invalid security token. Please reload and try again.']);
        exit;
    }

    $installer_id    = (int)($input['installer_id'] ?? 0);
    $reviewer_name   = trim($input['reviewer_name'] ?? '');
    $reviewer_email  = trim($input['reviewer_email'] ?? '');
    $reviewer_phone  = trim($input['reviewer_phone'] ?? '');
    $rating          = (int)($input['rating'] ?? 0);
    $title           = trim($input['review_title'] ?? '');
    $review_text     = trim($input['review_text'] ?? '');
    $project_type    = trim($input['project_type'] ?? '');
    $system_size_kw  = (float)($input['system_size_kw'] ?? 0);
    $installation_date = trim($input['installation_date'] ?? '');

    $errors = [];
    if ($installer_id <= 0) $errors[] = 'Invalid installer.';
    if ($reviewer_name === '') $errors[] = 'Name is required.';
    if ($reviewer_email === '' || !filter_var($reviewer_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if ($rating < 1 || $rating > 5) $errors[] = 'Rating must be between 1 and 5.';
    if ($review_text === '') $errors[] = 'Review text is required.';

    if (!empty($errors)) {
        http_response_code(422);
        echo json_encode(['error' => implode(' ', $errors)]);
        exit;
    }

    try {
        // Check installer exists
        $chk = $db->prepare("SELECT id FROM installers WHERE id = ? AND status IN ('active','approved')");
        $chk->execute([$installer_id]);
        if (!$chk->fetch()) {
            http_response_code(404);
            echo json_encode(['error' => 'Installer not found.']);
            exit;
        }

        // Check if reviewer has a completed order with this installer
        $orderChk = $db->prepare("
            SELECT COUNT(*) FROM installer_orders
            WHERE installer_id = ? AND status = 'completed'
              AND (customer_id IN (SELECT id FROM customers WHERE email = ?)
                   OR address LIKE CONCAT('%', ?, '%'))
        ");
        $orderChk->execute([$installer_id, $reviewer_email, $reviewer_email]);
        $hasOrder = (int)$orderChk->fetchColumn() > 0;

        if (!$hasOrder) {
            // Also check by session customer_id
            $customer_id = $_SESSION['customer_id'] ?? 0;
            if ($customer_id > 0) {
                $oc2 = $db->prepare("SELECT COUNT(*) FROM installer_orders WHERE installer_id = ? AND customer_id = ? AND status = 'completed'");
                $oc2->execute([$installer_id, $customer_id]);
                $hasOrder = (int)$oc2->fetchColumn() > 0;
            }
        }

        if (!$hasOrder) {
            http_response_code(403);
            echo json_encode(['error' => 'You can only review an installer after completing an installation order with them.']);
            exit;
        }

        $stmt = $db->prepare("INSERT INTO installer_reviews
            (installer_id, reviewer_name, reviewer_email, reviewer_phone, rating, title, review_text, project_type, system_size_kw, installation_date, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())");
        $stmt->execute([
            $installer_id, $reviewer_name, $reviewer_email, $reviewer_phone,
            $rating, $title, $review_text, $project_type,
            $system_size_kw > 0 ? $system_size_kw : null,
            $installation_date ?: null
        ]);

        echo json_encode(['success' => true, 'message' => 'Thank you! Your review will be published after moderation.']);
    } catch (Exception $e) {
        error_log('Installer review submit error: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Failed to submit review. Please try again.']);
    }
    exit;
}

// ─── AJAX: Submit Installation Request (POST) ──────────────
if (isset($_GET['ajax']) && $_GET['ajax'] === 'submit_request' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    if (!rate_limit('inst_req_' . ($_SERVER['REMOTE_ADDR'] ?? ''), 5, 300)) {
        echo json_encode(['error' => 'Too many requests. Please try again later.']);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) $input = $_POST;

    if (!validate_csrf_token($input['csrf_token'] ?? '')) {
        http_response_code(403);
        echo json_encode(['error' => 'Invalid security token. Please reload and try again.']);
        exit;
    }

    $installer_id   = (int)($input['installer_id'] ?? 0);
    $system_type    = trim($input['system_type'] ?? '');
    $system_size    = trim($input['system_size'] ?? '');
    $address        = trim($input['address'] ?? '');
    $message        = trim($input['message'] ?? '');
    $scheduled_date = trim($input['scheduled_date'] ?? '');
    $preferred_time = trim($input['preferred_time'] ?? '');
    $property_type  = trim($input['property_type'] ?? '');
    $budget_per_kw  = floatval($input['budget_per_kw'] ?? 0);
    $budget_total   = ($budget_per_kw > 0 && floatval($system_size) > 0) ? $budget_per_kw * floatval($system_size) : 0;

    $is_logged_in = !empty($_SESSION['customer_id']);

    // Resolve customer details
    if ($is_logged_in) {
        $cust_stmt = $db->prepare("SELECT name, email, phone FROM customers WHERE id = ?");
        $cust_stmt->execute([$_SESSION['customer_id']]);
        $cust_data = $cust_stmt->fetch(PDO::FETCH_ASSOC);
        $customer_name  = $cust_data['name'] ?? '';
        $customer_phone = $cust_data['phone'] ?? '';
        $customer_email = $cust_data['email'] ?? '';
        $customer_id    = (int)$_SESSION['customer_id'];
    } else {
        $customer_name  = trim($input['customer_name'] ?? '');
        $customer_phone = trim($input['customer_phone'] ?? '');
        $customer_email = trim($input['customer_email'] ?? '');
        $customer_id    = 0;
    }

    $errors = [];
    if ($installer_id <= 0) $errors[] = 'Invalid installer.';

    // Validate guest fields
    if (!$is_logged_in) {
        if ($customer_name === '') $errors[] = 'Name is required.';
        if ($customer_phone === '') $errors[] = 'Phone is required.';
        if ($customer_email && !filter_var($customer_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email format.';
    }

    // Validate scheduled_date (required, must be in the future)
    if ($scheduled_date === '') {
        $errors[] = 'Preferred date is required.';
    } else {
        $date_ts = strtotime($scheduled_date);
        if (!$date_ts || $date_ts <= strtotime('today')) {
            $errors[] = 'Preferred date must be a future date.';
        }
    }

    // Validate preferred_time
    $valid_times = ['morning', 'afternoon', 'evening', 'flexible'];
    if (!in_array($preferred_time, $valid_times, true)) {
        $errors[] = 'Please select a valid preferred time.';
    }

    // Validate property_type
    $valid_properties = ['residential', 'commercial', 'industrial'];
    if (!in_array($property_type, $valid_properties, true)) {
        $errors[] = 'Please select a valid property type.';
    }

    if (!empty($errors)) {
        http_response_code(422);
        echo json_encode(['error' => implode(' ', $errors)]);
        exit;
    }

    try {
        $chk = $db->prepare("SELECT id FROM installers WHERE id = ? AND status IN ('active','approved')");
        $chk->execute([$installer_id]);
        if (!$chk->fetch()) {
            http_response_code(404);
            echo json_encode(['error' => 'Installer not found.']);
            exit;
        }

        $description = "Quote request from $customer_name ($customer_phone" . ($customer_email ? ", $customer_email" : "") . ")";

        // Insert into installer_orders as a new request
        $stmt = $db->prepare("INSERT INTO installer_orders
            (installer_id, customer_id, status, system_type, system_size_kw, property_type, customer_budget_per_kw, customer_budget_total, scheduled_date, preferred_time, description, address, customer_notes, created_at)
            VALUES (?, ?, 'requested', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([
            $installer_id,
            $customer_id,
            $system_type ?: null,
            $system_size ?: null,
            $property_type,
            $budget_per_kw ?: null,
            $budget_total ?: null,
            $scheduled_date,
            $preferred_time,
            $description,
            $address ?: null,
            $message ?: null
        ]);

        $response_name = $is_logged_in ? $customer_name : sanitize($customer_name);
        echo json_encode(['success' => true, 'message' => 'Your request has been sent! ' . $response_name . ', the installer will contact you soon.']);
    } catch (Exception $e) {
        error_log('Installer request submit error: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Failed to send request. Please try again.']);
    }
    exit;
}

// ─── Page Load ──────────────────────────────────────────────
$installer_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
$show_404 = false;
$installer = null;

if (!$installer_id || $installer_id <= 0) {
    http_response_code(404);
    $show_404 = true;
} else {
    $stmt = $db->prepare("SELECT * FROM installers WHERE id = ? AND status IN ('active','approved') LIMIT 1");
    $stmt->execute([$installer_id]);
    $installer = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$installer) {
        http_response_code(404);
        $show_404 = true;
    }
}

$logged_customer = null;
if (!empty($_SESSION['customer_id'])) {
    $stmt = $db->prepare("SELECT name, email, phone FROM customers WHERE id = ?");
    $stmt->execute([$_SESSION['customer_id']]);
    $logged_customer = $stmt->fetch(PDO::FETCH_ASSOC);
}

$reviews = [];
$portfolio = [];
$service_areas = [];
$rating_breakdown = [5=>0,4=>0,3=>0,2=>0,1=>0];
$avg_rating = 0;
$total_reviews = 0;
$orders_in_queue = 0;
$completed_orders = 0;
$page_currency = get_country_currency_info('US');

if ($installer) {
    $installerName = sanitize($installer['business_name']);
    $page_title = $installerName . ' — Solar Installer';
    $page_description = "$installerName - Certified solar installer" . (!empty($installer['city']) ? " in {$installer['city']}" : '') . ". Professional solar installation services. View ratings and request a quote.";
    $page_currency = get_country_currency_info($installer['country_code'] ?? 'US');
    $avg_rating  = round(floatval($installer['avg_rating'] ?? 0), 1);
    $total_reviews = (int)($installer['total_reviews'] ?? 0);

    // Reviews
    try {
        $rStmt = $db->prepare("SELECT reviewer_name, rating, title, review_text, project_type, system_size_kw, created_at, admin_response FROM installer_reviews WHERE installer_id = ? AND status = 'approved' ORDER BY created_at DESC LIMIT 50");
        $rStmt->execute([$installer_id]);
        $reviews = $rStmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {}

    // Portfolio
    try {
        $pStmt = $db->prepare("SELECT image_path, title, description, system_size_kw, project_type FROM installer_portfolio WHERE installer_id = ? ORDER BY created_at DESC LIMIT 20");
        $pStmt->execute([$installer_id]);
        $portfolio = $pStmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($portfolio as &$p) {
            $p['image_url'] = !empty($p['image_path']) ? get_image_url($p['image_path']) : '';
        }
        unset($p);
    } catch (Exception $e) {}

    // Service areas
    try {
        $aStmt = $db->prepare("SELECT area_name, radius_km, is_primary FROM installer_service_areas WHERE installer_id = ? ORDER BY is_primary DESC");
        $aStmt->execute([$installer_id]);
        $service_areas = $aStmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {}

    // Rating breakdown
    try {
        $bStmt = $db->prepare("SELECT rating, COUNT(*) as cnt FROM installer_reviews WHERE installer_id = ? AND status = 'approved' GROUP BY rating");
        $bStmt->execute([$installer_id]);
        foreach ($bStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $rating_breakdown[(int)$row['rating']] = (int)$row['cnt'];
        }
    } catch (Exception $e) {}

    // Orders in queue (active orders)
    try {
        $qStmt = $db->prepare("SELECT COUNT(*) FROM installer_orders WHERE installer_id = ? AND status IN ('accepted','in_progress')");
        $qStmt->execute([$installer_id]);
        $orders_in_queue = (int)$qStmt->fetchColumn();
    } catch (Exception $e) {}

    // Completed orders
    try {
        $cStmt = $db->prepare("SELECT COUNT(*) FROM installer_orders WHERE installer_id = ? AND status = 'completed'");
        $cStmt->execute([$installer_id]);
        $completed_orders = (int)$cStmt->fetchColumn();
    } catch (Exception $e) {}

} else {
    $page_title = 'Installer Not Found';
}

// Check if current user can review (has completed order)
$can_review = false;
if ($installer) {
    $customer_id = $_SESSION['customer_id'] ?? 0;
    $customer_email = $_SESSION['customer_email'] ?? '';
    if ($customer_id > 0) {
        try {
            $rc = $db->prepare("SELECT COUNT(*) FROM installer_orders WHERE installer_id = ? AND customer_id = ? AND status = 'completed'");
            $rc->execute([$installer_id, $customer_id]);
            $can_review = (int)$rc->fetchColumn() > 0;
        } catch (Exception $e) {}
    }
}

$csrf_token = generate_csrf_token();
$current_page = 'installer-detail';
if (!empty($lat) && !empty($lng)) {
    $page_extra_head = '<link rel="stylesheet" href="' . BASE_URL . 'assets/vendor/leaflet/leaflet.css"/>';
}
require_once 'includes/header.php';
?>
<style>
/* ═══════════════════════════════════════════════
   Installer Detail — Page-Specific Styles
   ═══════════════════════════════════════════════ */

/* ─── 404 Page ─── */
.id-404 {
    text-align: center; padding: 120px 24px;
    max-width: 500px; margin: 0 auto;
}
.id-404 h1 { font-size: 4rem; font-weight: 800; color: #CBD5E1; margin-bottom: 8px; }
.id-404 h2 { font-size: 1.4rem; font-weight: 700; color: #0F172A; margin-bottom: 12px; }
.id-404 p { color: #64748B; margin-bottom: 24px; }

/* ─── Buttons ─── */
.id-btn {
    display: inline-flex; align-items: center; gap: 8px;
    padding: 12px 24px; border-radius: 10px;
    font-size: 0.9rem; font-weight: 600; font-family: inherit;
    cursor: pointer; border: none; transition: all 0.2s;
    text-decoration: none;
}
.id-btn-amber { background: linear-gradient(135deg, #F59E0B, #D97706); color: #fff; }
.id-btn-amber:hover { background: linear-gradient(135deg, #D97706, #B45309); transform: translateY(-1px); box-shadow: 0 4px 15px rgba(245,158,11,0.3); text-decoration: none; color: #fff; }
.id-btn-outline { background: rgba(255,255,255,0.08); color: #fff; border: 1.5px solid rgba(255,255,255,0.2); }
.id-btn-outline:hover { background: rgba(255,255,255,0.15); border-color: rgba(255,255,255,0.4); text-decoration: none; color: #fff; }
.id-btn-white { background: #fff; color: #0F172A; }
.id-btn-white:hover { background: #F1F5F9; text-decoration: none; }

/* ─── Hero Section ─── */
.id-hero {
    background: linear-gradient(145deg, #0F172A 0%, #1E293B 60%, #0a1628 100%);
    padding: 48px 32px 40px; position: relative; overflow: hidden;
}
.id-hero::before {
    content: ''; position: absolute; top: -80px; right: -60px;
    width: 400px; height: 400px; border-radius: 50%;
    background: radial-gradient(circle, rgba(245,158,11,0.06) 0%, transparent 70%);
    pointer-events: none;
}
.id-hero-inner {
    max-width: 1200px; margin: 0 auto; position: relative; z-index: 1;
}
.id-hero-top {
    display: flex; align-items: flex-start; gap: 24px; margin-bottom: 28px;
}
.id-logo {
    width: 90px; height: 90px; border-radius: 16px; object-fit: cover;
    border: 3px solid rgba(245,158,11,0.3); flex-shrink: 0;
}
.id-initials {
    width: 90px; height: 90px; border-radius: 16px; flex-shrink: 0;
    background: linear-gradient(135deg, #F59E0B, #D97706); color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-size: 2rem; font-weight: 800;
    border: 3px solid rgba(245,158,11,0.3);
}
.id-hero-info h1 {
    font-size: 1.8rem; font-weight: 800; color: #fff; margin: 0 0 6px;
    letter-spacing: -0.02em;
}
.id-hero-location {
    display: flex; align-items: center; gap: 6px;
    color: #94A3B8; font-size: 0.9rem;
}
.id-hero-location svg { color: #F59E0B; flex-shrink: 0; }
.id-hero-badges {
    display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px;
}
.id-badge {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 4px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 600;
}
.id-badge-featured { background: rgba(245,158,11,0.15); color: #FCD34D; border: 1px solid rgba(245,158,11,0.3); }
.id-badge-verified { background: rgba(16,185,129,0.15); color: #6EE7B7; border: 1px solid rgba(16,185,129,0.3); }
.id-badge-type { background: rgba(99,102,241,0.15); color: #A5B4FC; border: 1px solid rgba(99,102,241,0.3); }

/* Rating */
.id-hero-rating {
    display: flex; align-items: center; gap: 8px; margin-top: 8px;
}
.id-stars { display: flex; gap: 2px; }
.id-star { color: #F59E0B; }
.id-star-empty { color: #475569; }
.id-rating-text { color: #94A3B8; font-size: 0.85rem; }

/* ─── Stats Row ─── */
.id-stats-row {
    display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px;
    margin-top: 28px;
}
.id-stat-card {
    background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08);
    border-radius: 14px; padding: 20px 16px; text-align: center;
    backdrop-filter: blur(8px); transition: all 0.3s;
}
.id-stat-card:hover {
    background: rgba(255,255,255,0.08); border-color: rgba(245,158,11,0.2);
    transform: translateY(-2px);
}
.id-stat-value {
    font-size: 1.8rem; font-weight: 800; color: #F59E0B;
    line-height: 1;
}
.id-stat-label {
    font-size: 0.78rem; color: #94A3B8; margin-top: 6px;
    text-transform: uppercase; letter-spacing: 0.03em;
}
.id-stat-card.queue .id-stat-value { color: #22D3EE; }
.id-stat-card.price .id-stat-value { color: #10B981; font-size: 1.3rem; }

/* ─── Contact bar ─── */
.id-contact-bar {
    display: flex; flex-wrap: wrap; align-items: center; gap: 24px;
    margin-top: 24px; padding-top: 20px;
    border-top: 1px solid rgba(255,255,255,0.08);
}
.id-contact-item {
    display: flex; align-items: center; gap: 8px;
    color: #CBD5E1; font-size: 0.875rem;
}
.id-contact-item svg { color: #F59E0B; flex-shrink: 0; }
.id-contact-item a { color: #CBD5E1; text-decoration: none; }
.id-contact-item a:hover { color: #F59E0B; }
.id-contact-actions {
    margin-left: auto; display: flex; gap: 10px;
}

/* ─── Content Area ─── */
.id-content { max-width: 1200px; margin: 0 auto; padding: 32px 24px 64px; }

/* ─── Section Cards ─── */
.id-section {
    background: #fff; border-radius: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06), 0 4px 12px rgba(0,0,0,0.04);
    margin-bottom: 24px; overflow: hidden;
}
.id-section-header {
    padding: 24px 28px 0;
    display: flex; align-items: center; justify-content: space-between;
}
.id-section-title {
    font-size: 1.15rem; font-weight: 700; color: #0F172A;
    display: flex; align-items: center; gap: 10px;
}
.id-section-title svg { color: #F59E0B; }
.id-section-body { padding: 20px 28px 28px; }

/* ─── About ─── */
.id-about-text { color: #475569; line-height: 1.8; font-size: 0.92rem; }
.id-specializations {
    display: flex; flex-wrap: wrap; gap: 8px; margin-top: 16px;
}
.id-spec-tag {
    padding: 6px 14px; border-radius: 20px; font-size: 0.8rem; font-weight: 600;
    background: linear-gradient(135deg, #FFF7ED, #FFFBEB); color: #92400E;
    border: 1px solid #FBBF24;
}

/* ─── Service Areas ─── */
.id-areas-grid {
    display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 12px;
}
.id-area-card {
    padding: 14px 18px; border-radius: 12px;
    background: #F8FAFC; border: 1px solid #E2E8F0;
    display: flex; align-items: center; gap: 10px; transition: all 0.2s;
}
.id-area-card:hover { border-color: #F59E0B; background: #FFFBEB; }
.id-area-card.primary { border-color: #F59E0B; background: #FFFBEB; }
.id-area-card svg { color: #F59E0B; flex-shrink: 0; }
.id-area-name { font-weight: 600; color: #0F172A; font-size: 0.9rem; }
.id-area-radius { color: #64748B; font-size: 0.78rem; }
.id-area-primary-tag {
    font-size: 0.65rem; font-weight: 700; text-transform: uppercase;
    color: #D97706; background: rgba(245,158,11,0.1);
    padding: 2px 8px; border-radius: 10px; margin-left: auto;
}

/* ─── Portfolio ─── */
.id-portfolio-grid {
    display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px;
}
.id-portfolio-card {
    border-radius: 14px; overflow: hidden;
    border: 1px solid #E2E8F0; transition: all 0.3s;
    background: #fff;
}
.id-portfolio-card:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
.id-portfolio-img {
    width: 100%; height: 200px; object-fit: cover;
    background: #F1F5F9;
}
.id-portfolio-info { padding: 14px 16px; }
.id-portfolio-title { font-weight: 700; color: #0F172A; font-size: 0.9rem; margin-bottom: 4px; }
.id-portfolio-meta { color: #64748B; font-size: 0.8rem; display: flex; gap: 12px; }
.id-portfolio-meta span { display: flex; align-items: center; gap: 4px; }
.id-portfolio-desc { color: #475569; font-size: 0.82rem; margin-top: 8px; line-height: 1.5; }
.id-portfolio-empty, .id-areas-empty {
    text-align: center; padding: 40px 20px; color: #94A3B8;
}

/* ─── Reviews ─── */
.id-reviews-summary {
    display: flex; align-items: center; gap: 32px; padding-bottom: 24px;
    border-bottom: 1px solid #E2E8F0; margin-bottom: 20px;
}
.id-reviews-big {
    text-align: center; min-width: 100px;
}
.id-reviews-big-num {
    font-size: 3rem; font-weight: 800; color: #0F172A; line-height: 1;
}
.id-reviews-big-text { color: #64748B; font-size: 0.82rem; margin-top: 4px; }
.id-reviews-bars { flex: 1; }
.id-review-bar-row {
    display: flex; align-items: center; gap: 8px; margin-bottom: 6px;
}
.id-review-bar-label { font-size: 0.82rem; color: #64748B; min-width: 20px; text-align: right; }
.id-review-bar-track {
    flex: 1; height: 8px; background: #F1F5F9; border-radius: 4px; overflow: hidden;
}
.id-review-bar-fill {
    height: 100%; background: linear-gradient(90deg, #F59E0B, #FBBF24);
    border-radius: 4px; transition: width 0.6s ease;
}
.id-review-bar-count { font-size: 0.78rem; color: #94A3B8; min-width: 24px; }

.id-review-card {
    padding: 20px; border-radius: 12px; background: #F8FAFC;
    border: 1px solid #E2E8F0; margin-bottom: 12px;
    transition: all 0.2s;
}
.id-review-card:hover { border-color: #CBD5E1; }
.id-review-top {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 10px;
}
.id-review-author {
    display: flex; align-items: center; gap: 12px;
}
.id-review-avatar {
    width: 40px; height: 40px; border-radius: 50%;
    background: linear-gradient(135deg, #1E293B, #334155);
    color: #fff; font-weight: 700; font-size: 0.9rem;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.id-review-name { font-weight: 600; color: #0F172A; font-size: 0.9rem; }
.id-review-date { color: #94A3B8; font-size: 0.78rem; }
.id-review-stars { display: flex; gap: 2px; }
.id-review-stars svg { width: 14px; height: 14px; }
.id-review-title { font-weight: 600; color: #0F172A; margin-bottom: 6px; font-size: 0.92rem; }
.id-review-text { color: #475569; font-size: 0.88rem; line-height: 1.7; }
.id-review-meta-tags {
    display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px;
}
.id-review-tag {
    padding: 3px 10px; border-radius: 12px; font-size: 0.72rem; font-weight: 600;
    background: #EFF6FF; color: #1D4ED8; border: 1px solid #BFDBFE;
}
.id-review-admin-response {
    margin-top: 12px; padding: 12px 16px; border-radius: 10px;
    background: #FFFBEB; border-left: 3px solid #F59E0B;
}
.id-review-admin-label { font-size: 0.75rem; font-weight: 700; color: #92400E; margin-bottom: 4px; }
.id-review-admin-text { font-size: 0.85rem; color: #78350F; line-height: 1.6; }
.id-no-reviews {
    text-align: center; padding: 40px 20px; color: #94A3B8;
}

/* ─── Review Form ─── */
.id-review-gate {
    text-align: center; padding: 32px 20px;
    background: #F8FAFC; border-radius: 14px; border: 1px solid #E2E8F0;
    margin-top: 20px;
}
.id-review-gate svg { color: #94A3B8; margin-bottom: 8px; }
.id-review-gate h4 { color: #0F172A; font-size: 1rem; margin-bottom: 6px; }
.id-review-gate p { color: #64748B; font-size: 0.85rem; line-height: 1.6; }
.id-review-form-wrap {
    margin-top: 20px; padding: 24px; background: #F8FAFC;
    border-radius: 14px; border: 1px solid #E2E8F0;
}
.id-review-form-title {
    font-size: 1rem; font-weight: 700; color: #0F172A; margin-bottom: 16px;
}
.id-rf-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.id-rf-full { grid-column: 1 / -1; }
.id-rf-group label {
    display: block; font-size: 0.82rem; font-weight: 600; color: #334155;
    margin-bottom: 5px;
}
.id-rf-group input, .id-rf-group select, .id-rf-group textarea {
    width: 100%; padding: 10px 14px; border-radius: 10px;
    border: 1.5px solid #E2E8F0; font-size: 0.88rem;
    font-family: inherit; background: #fff; transition: border-color 0.2s;
    box-sizing: border-box;
}
.id-rf-group input:focus, .id-rf-group select:focus, .id-rf-group textarea:focus {
    outline: none; border-color: #F59E0B; box-shadow: 0 0 0 3px rgba(245,158,11,0.1);
}
.id-rf-group textarea { min-height: 100px; resize: vertical; }

/* Star input */
.id-star-input { display: flex; gap: 4px; flex-direction: row-reverse; justify-content: flex-end; }
.id-star-input input { display: none; }
.id-star-input label {
    cursor: pointer; font-size: 1.6rem; color: #CBD5E1;
    transition: color 0.15s; margin: 0 !important;
}
.id-star-input label:hover,
.id-star-input label:hover ~ label,
.id-star-input input:checked ~ label { color: #F59E0B; }

/* ─── Request Section ─── */
.id-request-section {
    background: linear-gradient(145deg, #0F172A, #1E293B);
    border-radius: 20px; padding: 40px 36px; margin-top: 32px;
}
.id-request-title {
    font-size: 1.3rem; font-weight: 800; color: #fff; margin-bottom: 6px;
}
.id-request-subtitle { color: #94A3B8; font-size: 0.9rem; margin-bottom: 24px; }
.id-request-form {
    display: grid; grid-template-columns: 1fr 1fr; gap: 14px;
}
.id-request-form .id-rf-group label { color: #CBD5E1; }
.id-request-form .id-rf-group input,
.id-request-form .id-rf-group select,
.id-request-form .id-rf-group textarea {
    background: rgba(255,255,255,0.06); border-color: rgba(255,255,255,0.12);
    color: #fff;
}
.id-request-form .id-rf-group input::placeholder,
.id-request-form .id-rf-group textarea::placeholder { color: #64748B; }
.id-request-form .id-rf-group input:focus,
.id-request-form .id-rf-group select:focus,
.id-request-form .id-rf-group textarea:focus {
    border-color: #F59E0B; background: rgba(255,255,255,0.1);
    box-shadow: 0 0 0 3px rgba(245,158,11,0.15);
}
.id-request-form .id-rf-group select option { background: #1E293B; color: #fff; }

/* ─── Map container ─── */
.id-map-section { height: 300px; border-radius: 16px; overflow: hidden; margin-bottom: 24px; border: 1px solid #E2E8F0; }
#idLeafletMap { width: 100%; height: 100%; }

/* ─── Toast ─── */
.id-toast {
    position: fixed; bottom: 24px; right: 24px; z-index: 9999;
    padding: 14px 24px; border-radius: 12px; font-size: 0.9rem; font-weight: 600;
    color: #fff; transform: translateY(100px); opacity: 0; transition: all 0.4s;
    max-width: 400px;
}
.id-toast.show { transform: translateY(0); opacity: 1; }
.id-toast.success { background: linear-gradient(135deg, #059669, #10B981); }
.id-toast.error { background: linear-gradient(135deg, #DC2626, #EF4444); }
.id-toast.warning { background: linear-gradient(135deg, #D97706, #F59E0B); }

/* ─── Responsive ─── */
@media (max-width: 900px) {
    .id-stats-row { grid-template-columns: repeat(3, 1fr); }
    .id-request-form, .id-rf-grid { grid-template-columns: 1fr; }
    .id-reviews-summary { flex-direction: column; align-items: flex-start; gap: 16px; }
}
@media (max-width: 640px) {
    .id-hero { padding: 28px 16px 24px; }
    .id-hero-info h1 { font-size: 1.3rem; }
    .id-logo, .id-initials { width: 64px; height: 64px; font-size: 1.5rem; border-radius: 12px; }
    .id-stats-row { grid-template-columns: repeat(2, 1fr); gap: 10px; }
    .id-stat-value { font-size: 1.4rem; }
    .id-content { padding: 20px 16px 48px; }
    .id-section-body { padding: 16px 18px 20px; }
    .id-portfolio-grid { grid-template-columns: 1fr; }
    .id-contact-bar { gap: 14px; }
    .id-contact-actions { margin-left: 0; width: 100%; }
    .id-contact-actions .id-btn { flex: 1; justify-content: center; }
    .id-request-section { padding: 28px 20px; }
}
</style>

<?php if ($show_404): ?>
<div class="id-404">
    <h1>404</h1>
    <h2>Installer Not Found</h2>
    <p>The installer you are looking for does not exist, has been deactivated, or the link is incorrect.</p>
    <a href="<?= BASE_URL ?>find-installer.php" class="id-btn id-btn-amber">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        Find Installers
    </a>
</div>

<?php else: ?>

<?php
    $lat = floatval($installer['latitude'] ?? 0);
    $lng = floatval($installer['longitude'] ?? 0);
    $specializations = array_filter(array_map('trim', explode(',', $installer['specializations'] ?? '')));
?>

<!-- ═══ Hero ═══ -->
<section class="id-hero">
    <div class="id-hero-inner">
        <div class="id-hero-top">
            <?php if (!empty($installer['logo_path'])): ?>
                <img class="id-logo" src="<?= sanitize(get_image_url($installer['logo_path'])) ?>" alt="<?= sanitize($installer['business_name']) ?>">
            <?php else: ?>
                <div class="id-initials"><?= strtoupper(mb_substr($installer['business_name'], 0, 1)) ?></div>
            <?php endif; ?>
            <div class="id-hero-info">
                <h1><?= sanitize($installer['business_name']) ?></h1>
                <div class="id-hero-location">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <?= sanitize(trim(($installer['city'] ?? '') . ', ' . ($installer['region'] ?? ''), ', ')) ?>
                    <?php if (!empty($installer['country_code'])): ?>
                        <span style="margin-left:4px"><?= get_country_flag($installer['country_code'] ?? '', 18) ?> <?= sanitize($installer['country_code']) ?></span>
                    <?php endif; ?>
                </div>
                <div class="id-hero-badges">
                    <?php if (!empty($installer['is_featured'])): ?>
                        <span class="id-badge id-badge-featured">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                            Featured
                        </span>
                    <?php endif; ?>
                    <?php if (!empty($installer['license_number'])): ?>
                        <span class="id-badge id-badge-verified">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            Licensed
                        </span>
                    <?php endif; ?>
                    <?php foreach (array_slice($specializations, 0, 3) as $spec): ?>
                        <span class="id-badge id-badge-type"><?= sanitize($spec) ?></span>
                    <?php endforeach; ?>
                </div>
                <div class="id-hero-rating">
                    <div class="id-stars">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <?php if ($i <= round($avg_rating)): ?>
                                <svg class="id-star" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                            <?php else: ?>
                                <svg class="id-star-empty" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <span class="id-rating-text"><?= $avg_rating ?> / 5 (<?= $total_reviews ?> review<?= $total_reviews !== 1 ? 's' : '' ?>)</span>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="id-stats-row">
            <div class="id-stat-card">
                <div class="id-stat-value"><?= (int)$installer['completed_installations'] ?></div>
                <div class="id-stat-label">Installations</div>
            </div>
            <div class="id-stat-card">
                <div class="id-stat-value"><?= (int)$installer['years_experience'] ?></div>
                <div class="id-stat-label">Years Exp.</div>
            </div>
            <div class="id-stat-card">
                <div class="id-stat-value"><?= (int)$installer['team_size'] ?></div>
                <div class="id-stat-label">Team Members</div>
            </div>
            <div class="id-stat-card queue">
                <div class="id-stat-value"><?= $orders_in_queue ?></div>
                <div class="id-stat-label">In Queue</div>
            </div>
            <div class="id-stat-card price">
                <div class="id-stat-value">
                    <?php if (!empty($installer['price_per_kw']) && $installer['price_per_kw'] > 0): ?>
                        <?= $page_currency['currency_symbol'] ?? '$' ?><?= number_format($installer['price_per_kw'] * ($page_currency['exchange_rate'] ?? 1), 0) ?>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
                <div class="id-stat-label">Per kW</div>
            </div>
        </div>

        <!-- Contact Bar -->
        <div class="id-contact-bar">
            <?php if (!empty($installer['phone'])): ?>
            <div class="id-contact-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                <a href="tel:<?= sanitize($installer['phone']) ?>"><?= sanitize($installer['phone']) ?></a>
            </div>
            <?php endif; ?>
            <?php if (!empty($installer['email'])): ?>
            <div class="id-contact-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                <a href="mailto:<?= sanitize($installer['email']) ?>"><?= sanitize($installer['email']) ?></a>
            </div>
            <?php endif; ?>
            <?php if (!empty($installer['address'])): ?>
            <div class="id-contact-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                <?= sanitize($installer['address']) ?>
            </div>
            <?php endif; ?>
            <div class="id-contact-actions">
                <a href="#request-section" class="id-btn id-btn-amber">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    Request Quote
                </a>
                <?php if (!empty($installer['phone'])): ?>
                <a href="tel:<?= sanitize($installer['phone']) ?>" class="id-btn id-btn-outline">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                    Call Now
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- ═══ Main Content ═══ -->
<div class="id-content">

    <!-- ─── Map ─── -->
    <?php if ($lat && $lng): ?>
    <div class="id-map-section">
        <div id="idLeafletMap" style="min-height:260px;width:100%;border-radius:12px;z-index:1;"></div>
    </div>
    <?php endif; ?>

    <!-- ─── About ─── -->
    <div class="id-section">
        <div class="id-section-header">
            <h2 class="id-section-title">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
                About
            </h2>
        </div>
        <div class="id-section-body">
            <?php if (!empty($installer['about_text'])): ?>
                <div class="id-about-text"><?= nl2br(sanitize($installer['about_text'])) ?></div>
            <?php else: ?>
                <div class="id-about-text" style="color:#94A3B8;">No description provided yet.</div>
            <?php endif; ?>
            <?php if (!empty($specializations)): ?>
            <div class="id-specializations">
                <?php foreach ($specializations as $spec): ?>
                    <span class="id-spec-tag"><?= sanitize($spec) ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ─── Service Areas ─── -->
    <div class="id-section">
        <div class="id-section-header">
            <h2 class="id-section-title">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                Service Areas
            </h2>
        </div>
        <div class="id-section-body">
            <?php if (!empty($service_areas)): ?>
                <div class="id-areas-grid">
                    <?php foreach ($service_areas as $area): ?>
                    <div class="id-area-card <?= !empty($area['is_primary']) ? 'primary' : '' ?>">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                        <div>
                            <div class="id-area-name"><?= sanitize($area['area_name']) ?></div>
                            <div class="id-area-radius"><?= (int)$area['radius_km'] ?> km radius</div>
                        </div>
                        <?php if (!empty($area['is_primary'])): ?>
                            <span class="id-area-primary-tag">Primary</span>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="id-areas-empty">
                    <p>Service areas: within <strong><?= (int)($installer['service_radius_km'] ?? 50) ?> km</strong> of <?= sanitize($installer['city'] ?? 'base location') ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ─── Portfolio ─── -->
    <div class="id-section">
        <div class="id-section-header">
            <h2 class="id-section-title">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
                Portfolio
            </h2>
            <?php if (!empty($portfolio)): ?>
                <span style="color:#64748B; font-size:0.82rem;"><?= count($portfolio) ?> project<?= count($portfolio) !== 1 ? 's' : '' ?></span>
            <?php endif; ?>
        </div>
        <div class="id-section-body">
            <?php if (!empty($portfolio)): ?>
                <div class="id-portfolio-grid">
                    <?php foreach ($portfolio as $project): ?>
                    <div class="id-portfolio-card">
                        <?php if (!empty($project['image_url'])): ?>
                            <img class="id-portfolio-img" src="<?= sanitize($project['image_url']) ?>" alt="<?= sanitize($project['title'] ?? 'Project') ?>" loading="lazy">
                        <?php else: ?>
                            <div class="id-portfolio-img" style="display:flex;align-items:center;justify-content:center;color:#94A3B8;">
                                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
                            </div>
                        <?php endif; ?>
                        <div class="id-portfolio-info">
                            <div class="id-portfolio-title"><?= sanitize($project['title'] ?? 'Solar Installation') ?></div>
                            <div class="id-portfolio-meta">
                                <?php if (!empty($project['system_size_kw'])): ?>
                                    <span>
                                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                                        <?= number_format($project['system_size_kw'], 1) ?> kW
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($project['project_type'])): ?>
                                    <span><?= ucfirst(sanitize($project['project_type'])) ?></span>
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($project['description'])): ?>
                                <div class="id-portfolio-desc"><?= sanitize(mb_substr($project['description'], 0, 150)) ?><?= mb_strlen($project['description']) > 150 ? '...' : '' ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="id-portfolio-empty">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
                    <p style="margin-top:8px;">No portfolio projects added yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ─── Reviews ─── -->
    <div class="id-section">
        <div class="id-section-header">
            <h2 class="id-section-title">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                Reviews
            </h2>
        </div>
        <div class="id-section-body">
            <?php if ($total_reviews > 0): ?>
            <!-- Summary -->
            <div class="id-reviews-summary">
                <div class="id-reviews-big">
                    <div class="id-reviews-big-num"><?= $avg_rating ?></div>
                    <div class="id-stars" style="justify-content:center;margin:6px 0;">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <?php if ($i <= round($avg_rating)): ?>
                                <svg class="id-star" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                            <?php else: ?>
                                <svg class="id-star-empty" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <div class="id-reviews-big-text"><?= $total_reviews ?> review<?= $total_reviews !== 1 ? 's' : '' ?></div>
                </div>
                <div class="id-reviews-bars">
                    <?php for ($s = 5; $s >= 1; $s--): ?>
                        <?php $pct = $total_reviews > 0 ? round(($rating_breakdown[$s] ?? 0) / $total_reviews * 100) : 0; ?>
                        <div class="id-review-bar-row">
                            <span class="id-review-bar-label"><?= $s ?> ★</span>
                            <div class="id-review-bar-track"><div class="id-review-bar-fill" style="width:<?= $pct ?>%"></div></div>
                            <span class="id-review-bar-count"><?= $rating_breakdown[$s] ?? 0 ?></span>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>

            <!-- Review cards -->
            <div id="idReviewsList">
                <?php foreach ($reviews as $rev): ?>
                <div class="id-review-card">
                    <div class="id-review-top">
                        <div class="id-review-author">
                            <div class="id-review-avatar"><?= strtoupper(mb_substr($rev['reviewer_name'], 0, 1)) ?></div>
                            <div>
                                <div class="id-review-name"><?= sanitize($rev['reviewer_name']) ?></div>
                                <div class="id-review-date"><?= date('M j, Y', strtotime($rev['created_at'])) ?></div>
                            </div>
                        </div>
                        <div class="id-review-stars">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <?php if ($i <= (int)$rev['rating']): ?>
                                    <svg style="color:#F59E0B" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                <?php else: ?>
                                    <svg style="color:#CBD5E1" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <?php if (!empty($rev['title'])): ?>
                        <div class="id-review-title"><?= sanitize($rev['title']) ?></div>
                    <?php endif; ?>
                    <div class="id-review-text"><?= nl2br(sanitize($rev['review_text'])) ?></div>
                    <?php if (!empty($rev['project_type']) || !empty($rev['system_size_kw'])): ?>
                    <div class="id-review-meta-tags">
                        <?php if (!empty($rev['project_type'])): ?>
                            <span class="id-review-tag"><?= ucfirst(sanitize($rev['project_type'])) ?></span>
                        <?php endif; ?>
                        <?php if (!empty($rev['system_size_kw'])): ?>
                            <span class="id-review-tag"><?= number_format($rev['system_size_kw'], 1) ?> kW</span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($rev['admin_response'])): ?>
                    <div class="id-review-admin-response">
                        <div class="id-review-admin-label">Installer Response</div>
                        <div class="id-review-admin-text"><?= nl2br(sanitize($rev['admin_response'])) ?></div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="id-no-reviews">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                <p style="margin-top:8px;">No reviews yet. Be the first to leave a review after completing an installation!</p>
            </div>
            <?php endif; ?>

            <!-- Review form: gated by order -->
            <?php if ($can_review): ?>
            <div class="id-review-form-wrap">
                <div class="id-review-form-title">Write a Review</div>
                <form id="idReviewForm" onsubmit="return submitIdReview(event)">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                    <input type="hidden" name="installer_id" value="<?= $installer_id ?>">
                    <div class="id-rf-grid">
                        <div class="id-rf-group">
                            <label>Your Name *</label>
                            <input type="text" name="reviewer_name" required maxlength="150" placeholder="Full name">
                        </div>
                        <div class="id-rf-group">
                            <label>Email *</label>
                            <input type="email" name="reviewer_email" required maxlength="255" placeholder="your@email.com">
                        </div>
                        <div class="id-rf-group">
                            <label>Phone</label>
                            <input type="tel" name="reviewer_phone" maxlength="30" placeholder="Optional">
                        </div>
                        <div class="id-rf-group">
                            <label>Rating *</label>
                            <div class="id-star-input">
                                <?php for ($s = 5; $s >= 1; $s--): ?>
                                    <input type="radio" name="rating" id="idStar<?= $s ?>" value="<?= $s ?>" <?= $s === 5 ? 'checked' : '' ?>>
                                    <label for="idStar<?= $s ?>">&#9733;</label>
                                <?php endfor; ?>
                            </div>
                        </div>
                        <div class="id-rf-group id-rf-full">
                            <label>Review Title</label>
                            <input type="text" name="review_title" maxlength="200" placeholder="Brief summary of your experience">
                        </div>
                        <div class="id-rf-group id-rf-full">
                            <label>Your Review *</label>
                            <textarea name="review_text" required maxlength="2000" placeholder="Share your experience with this installer..."></textarea>
                        </div>
                        <div class="id-rf-group">
                            <label>Project Type</label>
                            <select name="project_type">
                                <option value="">Select type</option>
                                <option value="residential">Residential</option>
                                <option value="commercial">Commercial</option>
                                <option value="industrial">Industrial</option>
                            </select>
                        </div>
                        <div class="id-rf-group">
                            <label>System Size (kW)</label>
                            <input type="number" name="system_size_kw" min="0" step="0.1" placeholder="e.g. 5.0">
                        </div>
                        <div class="id-rf-group">
                            <label>Installation Date</label>
                            <input type="date" name="installation_date">
                        </div>
                        <div class="id-rf-group" style="display:flex;align-items:flex-end;">
                            <button type="submit" class="id-btn id-btn-amber" id="idReviewSubmitBtn" style="width:100%;justify-content:center;">
                                Submit Review
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <?php else: ?>
            <div class="id-review-gate">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <h4>Reviews are order-gated</h4>
                <p>You can only leave a review after completing an installation order with this installer.<br>This ensures all reviews come from verified customers.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ─── Request Installation Quote ─── -->
    <?php $is_logged_in = !empty($_SESSION['customer_id']); ?>
    <div class="id-request-section" id="request-section">
        <div class="id-request-title">Request an Installation Quote</div>
        <div class="id-request-subtitle">Fill in your details and <?= sanitize($installer['business_name']) ?> will contact you shortly.</div>

        <?php if ($is_logged_in && $logged_customer): ?>
        <div style="background:#e8f5e9;border:1px solid #4caf50;border-radius:8px;padding:10px 16px;margin-bottom:18px;color:#256029;font-size:0.97em;">
            Logged in as <strong><?= sanitize($logged_customer['name']) ?></strong> (<?= sanitize($logged_customer['email']) ?>)
        </div>
        <?php endif; ?>

        <form id="idRequestForm" onsubmit="return submitIdRequest(event)">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            <input type="hidden" name="installer_id" value="<?= $installer_id ?>">
            <div class="id-request-form">

                <?php if (!$is_logged_in): ?>
                <div class="id-rf-group">
                    <label>Your Name *</label>
                    <input type="text" name="customer_name" required maxlength="150" placeholder="Full name">
                </div>
                <div class="id-rf-group">
                    <label>Phone *</label>
                    <input type="tel" name="customer_phone" required maxlength="30" placeholder="Your phone number">
                </div>
                <div class="id-rf-group">
                    <label>Email</label>
                    <input type="email" name="customer_email" maxlength="255" placeholder="your@email.com">
                </div>
                <div class="id-rf-group id-rf-full" style="margin-bottom:4px;">
                    <a href="<?= BASE_URL ?>customer/login.php" style="color:#f59e0b;font-size:0.92em;">Login for faster booking &rarr;</a>
                </div>
                <?php endif; ?>

                <div class="id-rf-group">
                    <label>Property Type *</label>
                    <select name="property_type" required>
                        <option value="">Select property type</option>
                        <option value="residential">Residential</option>
                        <option value="commercial">Commercial</option>
                        <option value="industrial">Industrial</option>
                    </select>
                </div>
                <div class="id-rf-group">
                    <label>System Type</label>
                    <select name="system_type">
                        <option value="">Select type</option>
                        <option value="on-grid">On-Grid</option>
                        <option value="off-grid">Off-Grid</option>
                        <option value="hybrid">Hybrid</option>
                    </select>
                </div>
                <div class="id-rf-group">
                    <label>System Size (kW)</label>
                    <input type="number" name="system_size" min="0" step="0.1" placeholder="e.g. 5.0">
                </div>
                <div class="id-rf-group">
                    <label>Your Budget per kW ($)</label>
                    <input type="number" name="budget_per_kw" min="0" step="0.01" placeholder="e.g. 5.00">
                </div>
                <div class="id-rf-group">
                    <label>Preferred Date *</label>
                    <input type="date" name="scheduled_date" required min="<?= date('Y-m-d', strtotime('+1 day')) ?>">
                </div>
                <div class="id-rf-group">
                    <label>Preferred Time *</label>
                    <select name="preferred_time" required>
                        <option value="">Select time slot</option>
                        <option value="morning">Morning (8am - 12pm)</option>
                        <option value="afternoon">Afternoon (12pm - 5pm)</option>
                        <option value="evening">Evening (5pm - 8pm)</option>
                        <option value="flexible">Flexible</option>
                    </select>
                </div>
                <div class="id-rf-group">
                    <label>Address</label>
                    <input type="text" name="address" maxlength="500" placeholder="Installation address">
                </div>
                <div class="id-rf-group id-rf-full">
                    <label>Additional Details</label>
                    <textarea name="message" maxlength="2000" placeholder="Describe your requirements, roof type, budget, etc."></textarea>
                </div>
                <div class="id-rf-group id-rf-full" style="text-align:right;">
                    <button type="submit" class="id-btn id-btn-amber" id="idRequestSubmitBtn">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                        Send Request
                    </button>
                </div>
            </div>
        </form>
    </div>

</div>

<!-- Toast -->
<div class="id-toast" id="idToast"></div>

<script>
function idShowToast(msg, type) {
    var t = document.getElementById('idToast');
    t.textContent = msg;
    t.className = 'id-toast ' + (type || 'success') + ' show';
    setTimeout(function(){ t.classList.remove('show'); }, 4000);
}

function submitIdReview(e) {
    e.preventDefault();
    var form = document.getElementById('idReviewForm');
    var btn = document.getElementById('idReviewSubmitBtn');
    var fd = new FormData(form);
    var data = {};
    fd.forEach(function(v, k) { data[k] = v; });

    btn.disabled = true;
    btn.textContent = 'Submitting...';

    fetch('<?= BASE_URL ?>installer-detail.php?ajax=submit_review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d.success) {
            idShowToast(d.message, 'success');
            form.reset();
        } else {
            idShowToast(d.error || 'Failed to submit review.', 'error');
        }
    })
    .catch(function() { idShowToast('Network error. Please try again.', 'error'); })
    .finally(function() { btn.disabled = false; btn.textContent = 'Submit Review'; });

    return false;
}

function submitIdRequest(e) {
    e.preventDefault();
    var form = document.getElementById('idRequestForm');
    var btn = document.getElementById('idRequestSubmitBtn');
    var fd = new FormData(form);
    var data = {};
    fd.forEach(function(v, k) { data[k] = v; });

    // Client-side validation for new required fields
    if (!data.property_type) { idShowToast('Please select a property type.', 'error'); return false; }
    if (!data.scheduled_date) { idShowToast('Please select a preferred date.', 'error'); return false; }
    if (!data.preferred_time) { idShowToast('Please select a preferred time.', 'error'); return false; }

    btn.disabled = true;
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg> Sending...';

    fetch('<?= BASE_URL ?>installer-detail.php?ajax=submit_request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d.success) {
            idShowToast(d.message, 'success');
            form.reset();
        } else {
            idShowToast(d.error || 'Failed to send request.', 'error');
        }
    })
    .catch(function() { idShowToast('Network error. Please try again.', 'error'); })
    .finally(function() {
        btn.disabled = false;
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg> Send Request';
    });

    return false;
}
</script>
<style>@keyframes spin { to { transform: rotate(360deg); } }</style>

<?php endif; ?>

<?php if (!empty($lat) && !empty($lng)): ?>
<script src="<?= BASE_URL ?>assets/vendor/leaflet/leaflet.js"></script>
<script>
(function(){
    function initInstallerMap() {
        if (typeof L === 'undefined') {

            setTimeout(initInstallerMap, 200);
            return;
        }
        var el = document.getElementById('idLeafletMap');
        if (!el) { console.error('🗺️ Map element not found'); return; }

        var lat = <?= $lat ?>, lng = <?= $lng ?>;
        var radius = <?= (int)($installer['service_radius_km'] ?? 50) ?> * 1000;

        try {
            el.style.height = '100%';
            el.style.minHeight = '260px';

            var m = L.map(el).setView([lat, lng], 11);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap'
            }).addTo(m);
            L.marker([lat, lng]).addTo(m)
                .bindPopup('<strong><?= addslashes(sanitize($installer['business_name'])) ?></strong>')
                .openPopup();
            L.circle([lat, lng], {
                radius: radius,
                color: '#F59E0B',
                fillColor: '#F59E0B',
                fillOpacity: 0.08,
                weight: 2
            }).addTo(m);

            m.invalidateSize();
            setTimeout(function(){ m.invalidateSize(); }, 100);
            setTimeout(function(){ m.invalidateSize(); }, 300);
            setTimeout(function(){ m.invalidateSize(); }, 600);
            setTimeout(function(){ m.invalidateSize(); }, 1500);

        } catch(e) {
            console.error('🗺️ Map init error:', e);
        }
    }

    if (document.readyState === 'complete') {
        initInstallerMap();
    } else {
        window.addEventListener('load', initInstallerMap);
    }
})();
</script>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
