<?php
/**
 * Dealer Reports - Sales reporting and earnings dashboard
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

set_security_headers();
require_dealer_login();

$dealer    = get_dealer_profile();
$db        = getDB();
$dealer_id = (int)$dealer['id'];

// Currency info
$dealer_currency = get_country_currency_info($dealer['country_code'] ?? '');
$currency_symbol = $dealer_currency['currency_symbol'];
$exchange_rate   = (float)$dealer_currency['exchange_rate'];

// ─── Date Range Filtering ───────────────────────────────────────────────────

$preset = $_GET['preset'] ?? '';
$from_raw = $_GET['from'] ?? '';
$to_raw   = $_GET['to']   ?? '';

// Validate date inputs
$from_date = '';
$to_date   = '';

if ($from_raw && preg_match('/^\d{4}-\d{2}-\d{2}$/', $from_raw) && strtotime($from_raw) !== false) {
    $from_date = $from_raw;
}
if ($to_raw && preg_match('/^\d{4}-\d{2}-\d{2}$/', $to_raw) && strtotime($to_raw) !== false) {
    $to_date = $to_raw;
}

// Apply preset if no custom dates
if (!$from_date && !$to_date) {
    $today = date('Y-m-d');
    switch ($preset) {
        case 'today':
            $from_date = $today;
            $to_date   = $today;
            break;
        case 'week':
            $from_date = date('Y-m-d', strtotime('monday this week'));
            $to_date   = $today;
            break;
        case 'year':
            $from_date = date('Y-01-01');
            $to_date   = $today;
            break;
        case 'all':
            $from_date = '2000-01-01';
            $to_date   = $today;
            break;
        case 'month':
        default:
            // Default: current month
            $from_date = date('Y-m-01');
            $to_date   = $today;
            $preset    = $preset ?: 'month';
            break;
    }
}

// Ensure to_date is not before from_date
if ($from_date && $to_date && strtotime($to_date) < strtotime($from_date)) {
    $to_date = $from_date;
}

$active_preset = $preset;

// Period length in days
$period_days = (int)((strtotime($to_date) - strtotime($from_date)) / 86400) + 1;
$group_by_month = $period_days > 60;

// ─── Section 1: Summary Stats ───────────────────────────────────────────────

$total_sales   = 0;
$total_returns = 0;
$net_earnings  = 0;
$total_invoices = 0;

try {
    // Total Sales — completed orders (exclude cancelled/pending)
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(total_amount), 0)
        FROM orders
        WHERE dealer_id = ?
          AND status IN ('picked_up','confirmed','ready')
          AND DATE(created_at) BETWEEN ? AND ?
    ");
    $stmt->execute([$dealer_id, $from_date, $to_date]);
    $total_sales = (float)$stmt->fetchColumn();
} catch (Exception $e) {
    $total_sales = 0;
}

try {
    // Total Returns — completed returns
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(total_amount), 0)
        FROM sale_returns
        WHERE dealer_id = ?
          AND status = 'completed'
          AND DATE(created_at) BETWEEN ? AND ?
    ");
    $stmt->execute([$dealer_id, $from_date, $to_date]);
    $total_returns = (float)$stmt->fetchColumn();
} catch (Exception $e) {
    $total_returns = 0;
}

$net_earnings = $total_sales - $total_returns;

try {
    // Total Invoices — all orders (any status)
    $stmt = $db->prepare("
        SELECT COUNT(*)
        FROM orders
        WHERE dealer_id = ?
          AND DATE(created_at) BETWEEN ? AND ?
    ");
    $stmt->execute([$dealer_id, $from_date, $to_date]);
    $total_invoices = (int)$stmt->fetchColumn();
} catch (Exception $e) {
    $total_invoices = 0;
}

// ─── Section 2: Chart Data — Daily/Monthly Sales ────────────────────────────

$chart_labels  = [];
$chart_sales   = [];
$chart_returns = [];

try {
    if ($group_by_month) {
        // Group by month
        $stmt = $db->prepare("
            SELECT DATE_FORMAT(created_at, '%Y-%m') AS period,
                   COALESCE(SUM(CASE WHEN status IN ('picked_up','confirmed','ready') THEN total_amount ELSE 0 END), 0) AS sales
            FROM orders
            WHERE dealer_id = ? AND DATE(created_at) BETWEEN ? AND ?
            GROUP BY period
            ORDER BY period
        ");
        $stmt->execute([$dealer_id, $from_date, $to_date]);
        $sales_data = [];
        foreach ($stmt->fetchAll() as $row) {
            $sales_data[$row['period']] = (float)$row['sales'];
        }

        $stmt = $db->prepare("
            SELECT DATE_FORMAT(created_at, '%Y-%m') AS period,
                   COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) AS returns_total
            FROM sale_returns
            WHERE dealer_id = ? AND DATE(created_at) BETWEEN ? AND ?
            GROUP BY period
            ORDER BY period
        ");
        $stmt->execute([$dealer_id, $from_date, $to_date]);
        $returns_data = [];
        foreach ($stmt->fetchAll() as $row) {
            $returns_data[$row['period']] = (float)$row['returns_total'];
        }

        // Build continuous month range
        $start = new DateTime($from_date);
        $end   = new DateTime($to_date);
        $start->modify('first day of this month');
        $end->modify('first day of this month');
        while ($start <= $end) {
            $key = $start->format('Y-m');
            $chart_labels[]  = $start->format('M Y');
            $chart_sales[]   = round(($sales_data[$key] ?? 0) * $exchange_rate, 2);
            $chart_returns[] = round(($returns_data[$key] ?? 0) * $exchange_rate, 2);
            $start->modify('+1 month');
        }
    } else {
        // Group by day
        $stmt = $db->prepare("
            SELECT DATE(created_at) AS period,
                   COALESCE(SUM(CASE WHEN status IN ('picked_up','confirmed','ready') THEN total_amount ELSE 0 END), 0) AS sales
            FROM orders
            WHERE dealer_id = ? AND DATE(created_at) BETWEEN ? AND ?
            GROUP BY period
            ORDER BY period
        ");
        $stmt->execute([$dealer_id, $from_date, $to_date]);
        $sales_data = [];
        foreach ($stmt->fetchAll() as $row) {
            $sales_data[$row['period']] = (float)$row['sales'];
        }

        $stmt = $db->prepare("
            SELECT DATE(created_at) AS period,
                   COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) AS returns_total
            FROM sale_returns
            WHERE dealer_id = ? AND DATE(created_at) BETWEEN ? AND ?
            GROUP BY period
            ORDER BY period
        ");
        $stmt->execute([$dealer_id, $from_date, $to_date]);
        $returns_data = [];
        foreach ($stmt->fetchAll() as $row) {
            $returns_data[$row['period']] = (float)$row['returns_total'];
        }

        // Build continuous day range
        $current = new DateTime($from_date);
        $end     = new DateTime($to_date);
        while ($current <= $end) {
            $key = $current->format('Y-m-d');
            $chart_labels[]  = $current->format('M d');
            $chart_sales[]   = round(($sales_data[$key] ?? 0) * $exchange_rate, 2);
            $chart_returns[] = round(($returns_data[$key] ?? 0) * $exchange_rate, 2);
            $current->modify('+1 day');
        }
    }
} catch (Exception $e) {
    $chart_labels  = [];
    $chart_sales   = [];
    $chart_returns = [];
}

// ─── Section 3: Top Selling Products ────────────────────────────────────────

$top_products = [];
try {
    $stmt = $db->prepare("
        SELECT oi.product_name,
               oi.product_type,
               SUM(oi.quantity) AS qty_sold,
               SUM(oi.total_price) AS revenue
        FROM order_items oi
        JOIN orders o ON o.id = oi.order_id
        WHERE o.dealer_id = ?
          AND o.status IN ('picked_up','confirmed','ready')
          AND DATE(o.created_at) BETWEEN ? AND ?
        GROUP BY oi.product_type, oi.product_id, oi.product_name
        ORDER BY qty_sold DESC
        LIMIT 10
    ");
    $stmt->execute([$dealer_id, $from_date, $to_date]);
    $top_products = $stmt->fetchAll();
} catch (Exception $e) {
    $top_products = [];
}

// ─── Section 4: Sales by Product Type ───────────────────────────────────────

$type_breakdown = [];
try {
    $stmt = $db->prepare("
        SELECT oi.product_type,
               SUM(oi.total_price) AS revenue,
               SUM(oi.quantity) AS qty
        FROM order_items oi
        JOIN orders o ON o.id = oi.order_id
        WHERE o.dealer_id = ?
          AND o.status IN ('picked_up','confirmed','ready')
          AND DATE(o.created_at) BETWEEN ? AND ?
        GROUP BY oi.product_type
        ORDER BY revenue DESC
    ");
    $stmt->execute([$dealer_id, $from_date, $to_date]);
    $type_breakdown = $stmt->fetchAll();
} catch (Exception $e) {
    $type_breakdown = [];
}

$type_labels   = [];
$type_values   = [];
$type_colors   = [
    'inverter'               => '#1565C0',
    'battery'                => '#16A34A',
    'panel'                  => '#F59E0B',
    'installation_appliance' => '#8B5CF6',
];
$type_nice_names = [
    'inverter'               => 'Inverters',
    'battery'                => 'Batteries',
    'panel'                  => 'Panels',
    'installation_appliance' => 'Installation Items',
];
foreach ($type_breakdown as $tb) {
    $type_labels[] = $type_nice_names[$tb['product_type']] ?? ucfirst($tb['product_type']);
    $type_values[] = round((float)$tb['revenue'] * $exchange_rate, 2);
}

// ─── Section 5: Recent Returns ──────────────────────────────────────────────

$recent_returns = [];
try {
    $stmt = $db->prepare("
        SELECT sr.id, sr.return_number, sr.total_amount, sr.reason, sr.status, sr.created_at,
               o.order_number, o.id AS order_id
        FROM sale_returns sr
        LEFT JOIN orders o ON o.id = sr.order_id
        WHERE sr.dealer_id = ?
        ORDER BY sr.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$dealer_id]);
    $recent_returns = $stmt->fetchAll();
} catch (Exception $e) {
    $recent_returns = [];
}

// Helper to format local
function fmt_local(float $usd, float $rate, string $symbol): string {
    return $symbol . ' ' . number_format($usd * $rate, 2);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - <?= sanitize($dealer['business_name']) ?> | <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        /* ── Filter Bar ─────────────────────────────────────────── */
        .rpt-filter-bar {
            display: flex; flex-wrap: wrap; align-items: center; gap: 10px;
            background: white; border-radius: 12px; padding: 16px 20px;
            border: 2px solid #E2E8F0; margin-bottom: 24px;
        }
        .rpt-filter-bar .rpt-preset {
            padding: 7px 16px; border-radius: 8px; border: 1.5px solid #E2E8F0;
            background: white; color: #475569; font-size: 0.8125rem; font-weight: 600;
            cursor: pointer; text-decoration: none; transition: all 0.2s;
            font-family: 'Inter', sans-serif;
        }
        .rpt-filter-bar .rpt-preset:hover { border-color: #1565C0; color: #1565C0; }
        .rpt-filter-bar .rpt-preset.active { background: #1565C0; color: white; border-color: #1565C0; }
        .rpt-filter-sep { width: 1px; height: 28px; background: #E2E8F0; margin: 0 4px; }
        .rpt-filter-bar input[type="date"] {
            padding: 7px 12px; border-radius: 8px; border: 1.5px solid #E2E8F0;
            font-size: 0.8125rem; font-family: 'Inter', sans-serif; color: #334155;
            background: white; outline: none;
        }
        .rpt-filter-bar input[type="date"]:focus { border-color: #1565C0; }
        .rpt-filter-bar .rpt-apply-btn {
            padding: 7px 20px; border-radius: 8px; border: none;
            background: #1565C0; color: white; font-size: 0.8125rem;
            font-weight: 600; cursor: pointer; font-family: 'Inter', sans-serif;
            transition: background 0.2s;
        }
        .rpt-filter-bar .rpt-apply-btn:hover { background: #0D47A1; }
        .rpt-filter-label { font-size: 0.8125rem; color: #64748B; font-weight: 500; }

        /* ── Stat Cards ─────────────────────────────────────────── */
        .rpt-stat-grid {
            display: grid; grid-template-columns: repeat(4, 1fr);
            gap: 20px; margin-bottom: 28px;
        }
        .rpt-stat-card {
            background: white; border-radius: 12px; padding: 24px;
            border: 2px solid #E2E8F0; display: flex; align-items: center; gap: 16px;
        }
        .rpt-stat-icon {
            width: 52px; height: 52px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem; flex-shrink: 0;
        }
        .rpt-stat-icon.green  { background: #DCFCE7; color: #16A34A; }
        .rpt-stat-icon.red    { background: #FEE2E2; color: #DC2626; }
        .rpt-stat-icon.blue   { background: #DBEAFE; color: #1565C0; }
        .rpt-stat-icon.gray   { background: #F1F5F9; color: #475569; }
        .rpt-stat-info {}
        .rpt-stat-value { font-size: 1.5rem; font-weight: 800; color: #1E293B; line-height: 1.2; }
        .rpt-stat-label { font-size: 0.8125rem; color: #64748B; font-weight: 500; margin-top: 2px; }

        /* ── Charts & Content Cards ─────────────────────────────── */
        .rpt-card {
            background: white; border-radius: 12px; padding: 24px;
            border: 2px solid #E2E8F0; margin-bottom: 24px;
        }
        .rpt-card-title {
            font-size: 1rem; font-weight: 700; color: #1E293B;
            margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid #F1F5F9;
        }
        .rpt-chart-wrap { position: relative; width: 100%; max-height: 360px; }

        /* ── Two-Column Layout ──────────────────────────────────── */
        .rpt-two-col {
            display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;
        }

        /* ── Tables ─────────────────────────────────────────────── */
        .rpt-table { width: 100%; border-collapse: collapse; }
        .rpt-table th {
            text-align: left; font-size: 0.75rem; font-weight: 600;
            color: #64748B; text-transform: uppercase; letter-spacing: 0.5px;
            padding: 10px 12px; border-bottom: 2px solid #F1F5F9;
        }
        .rpt-table td {
            padding: 12px; font-size: 0.875rem; color: #334155;
            border-bottom: 1px solid #F1F5F9;
        }
        .rpt-table tr:last-child td { border-bottom: none; }
        .rpt-table tr:hover td { background: #F8FAFC; }

        /* ── Badges ─────────────────────────────────────────────── */
        .rpt-badge {
            display: inline-block; padding: 3px 10px; border-radius: 6px;
            font-size: 0.6875rem; font-weight: 700; text-transform: uppercase;
        }
        .rpt-badge-inverter  { background: #DBEAFE; color: #1565C0; }
        .rpt-badge-battery   { background: #DCFCE7; color: #16A34A; }
        .rpt-badge-panel     { background: #FEF3C7; color: #B45309; }
        .rpt-badge-installation_appliance { background: #F3E8FF; color: #7C3AED; }
        .rpt-badge-pending   { background: #FEF3C7; color: #B45309; }
        .rpt-badge-completed { background: #DCFCE7; color: #16A34A; }
        .rpt-badge-cancelled { background: #FEE2E2; color: #DC2626; }

        /* ── Doughnut Center ────────────────────────────────────── */
        .rpt-doughnut-wrap {
            display: flex; align-items: flex-start; gap: 32px;
        }
        .rpt-doughnut-canvas { width: 240px; height: 240px; flex-shrink: 0; }
        .rpt-doughnut-legend { flex: 1; }

        /* ── Empty State ────────────────────────────────────────── */
        .rpt-empty {
            text-align: center; padding: 48px 24px; color: #94A3B8;
        }
        .rpt-empty-icon { font-size: 3rem; margin-bottom: 12px; opacity: 0.5; }
        .rpt-empty-text { font-size: 0.9375rem; font-weight: 500; }

        /* ── Link ───────────────────────────────────────────────── */
        .rpt-link {
            color: #1565C0; text-decoration: none; font-weight: 600;
        }
        .rpt-link:hover { text-decoration: underline; }

        /* ── Responsive ─────────────────────────────────────────── */
        @media (max-width: 1100px) {
            .rpt-stat-grid { grid-template-columns: repeat(2, 1fr); }
            .rpt-two-col { grid-template-columns: 1fr; }
        }
        @media (max-width: 900px) {
            .rpt-stat-grid { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 600px) {
            .rpt-stat-grid { grid-template-columns: 1fr; }
            .rpt-filter-bar { flex-direction: column; align-items: stretch; }
            .rpt-filter-sep { display: none; }
            .rpt-doughnut-wrap { flex-direction: column; align-items: center; }
        }
    </style>
</head>
<body>
    <?php $current_dealer_page = 'reports'; include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="dlr-main-content">
        <!-- Page Header -->
        <div class="dlr-page-header">
            <div class="dlr-page-header-left">
                <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
                <div>
                    <h1>Sales Reports</h1>
                    <div style="font-size:0.8125rem; color:#64748B; margin-top:2px;">
                        <?= date('M d, Y', strtotime($from_date)) ?> &ndash; <?= date('M d, Y', strtotime($to_date)) ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- ═══ Date Range Filter Bar ═══ -->
        <form class="rpt-filter-bar" method="get" action="reports.php">
            <a href="?preset=today" class="rpt-preset <?= $active_preset === 'today' ? 'active' : '' ?>">Today</a>
            <a href="?preset=week" class="rpt-preset <?= $active_preset === 'week' ? 'active' : '' ?>">This Week</a>
            <a href="?preset=month" class="rpt-preset <?= $active_preset === 'month' ? 'active' : '' ?>">This Month</a>
            <a href="?preset=year" class="rpt-preset <?= $active_preset === 'year' ? 'active' : '' ?>">This Year</a>
            <a href="?preset=all" class="rpt-preset <?= $active_preset === 'all' ? 'active' : '' ?>">All Time</a>

            <div class="rpt-filter-sep"></div>

            <span class="rpt-filter-label">From</span>
            <input type="date" name="from" value="<?= sanitize($from_date) ?>" max="<?= date('Y-m-d') ?>">
            <span class="rpt-filter-label">To</span>
            <input type="date" name="to" value="<?= sanitize($to_date) ?>" max="<?= date('Y-m-d') ?>">
            <button type="submit" class="rpt-apply-btn">Apply</button>
        </form>

        <!-- ═══ Section 1: Summary Stat Cards ═══ -->
        <div class="rpt-stat-grid">
            <div class="rpt-stat-card">
                <div class="rpt-stat-icon green">&#128200;</div>
                <div class="rpt-stat-info">
                    <div class="rpt-stat-value"><?= fmt_local($total_sales, $exchange_rate, $currency_symbol) ?></div>
                    <div class="rpt-stat-label">Total Sales</div>
                </div>
            </div>
            <div class="rpt-stat-card">
                <div class="rpt-stat-icon red">&#128229;</div>
                <div class="rpt-stat-info">
                    <div class="rpt-stat-value"><?= fmt_local($total_returns, $exchange_rate, $currency_symbol) ?></div>
                    <div class="rpt-stat-label">Total Returns</div>
                </div>
            </div>
            <div class="rpt-stat-card">
                <div class="rpt-stat-icon blue">&#128176;</div>
                <div class="rpt-stat-info">
                    <div class="rpt-stat-value"><?= fmt_local($net_earnings, $exchange_rate, $currency_symbol) ?></div>
                    <div class="rpt-stat-label">Net Earnings</div>
                </div>
            </div>
            <div class="rpt-stat-card">
                <div class="rpt-stat-icon gray">&#128196;</div>
                <div class="rpt-stat-info">
                    <div class="rpt-stat-value"><?= number_format($total_invoices) ?></div>
                    <div class="rpt-stat-label">Total Invoices</div>
                </div>
            </div>
        </div>

        <!-- ═══ Section 2: Sales Chart ═══ -->
        <div class="rpt-card">
            <div class="rpt-card-title">&#128202; Sales Overview <?= $group_by_month ? '(Monthly)' : '(Daily)' ?></div>
            <?php if (empty($chart_labels)): ?>
                <div class="rpt-empty">
                    <div class="rpt-empty-icon">&#128202;</div>
                    <div class="rpt-empty-text">No sales data for this period</div>
                </div>
            <?php else: ?>
                <div class="rpt-chart-wrap">
                    <canvas id="salesChart"></canvas>
                </div>
            <?php endif; ?>
        </div>

        <!-- ═══ Sections 3 & 4: Two-column ═══ -->
        <div class="rpt-two-col">
            <!-- Section 3: Top Selling Products -->
            <div class="rpt-card">
                <div class="rpt-card-title">&#127942; Top Selling Products</div>
                <?php if (empty($top_products)): ?>
                    <div class="rpt-empty">
                        <div class="rpt-empty-icon">&#128230;</div>
                        <div class="rpt-empty-text">No products sold in this period</div>
                    </div>
                <?php else: ?>
                    <table class="rpt-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Product</th>
                                <th>Type</th>
                                <th style="text-align:right">Qty</th>
                                <th style="text-align:right">Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_products as $i => $tp): ?>
                                <tr>
                                    <td><?= $i + 1 ?></td>
                                    <td style="font-weight:600; max-width:180px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
                                        <?= sanitize($tp['product_name']) ?>
                                    </td>
                                    <td>
                                        <span class="rpt-badge rpt-badge-<?= sanitize($tp['product_type']) ?>">
                                            <?= $type_nice_names[$tp['product_type']] ?? ucfirst($tp['product_type']) ?>
                                        </span>
                                    </td>
                                    <td style="text-align:right; font-weight:600;"><?= number_format((int)$tp['qty_sold']) ?></td>
                                    <td style="text-align:right; font-weight:600;">
                                        <?= fmt_local((float)$tp['revenue'], $exchange_rate, $currency_symbol) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Section 4: Sales by Product Type -->
            <div class="rpt-card">
                <div class="rpt-card-title">&#128208; Revenue by Product Type</div>
                <?php if (empty($type_breakdown)): ?>
                    <div class="rpt-empty">
                        <div class="rpt-empty-icon">&#128208;</div>
                        <div class="rpt-empty-text">No product sales in this period</div>
                    </div>
                <?php else: ?>
                    <div class="rpt-doughnut-wrap">
                        <div class="rpt-doughnut-canvas">
                            <canvas id="typeChart" width="240" height="240"></canvas>
                        </div>
                        <div class="rpt-doughnut-legend">
                            <table class="rpt-table">
                                <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th style="text-align:right">Qty</th>
                                        <th style="text-align:right">Revenue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($type_breakdown as $tb): ?>
                                        <tr>
                                            <td>
                                                <span style="display:inline-block; width:10px; height:10px; border-radius:3px; background:<?= $type_colors[$tb['product_type']] ?? '#94A3B8' ?>; margin-right:6px; vertical-align:middle;"></span>
                                                <?= $type_nice_names[$tb['product_type']] ?? ucfirst($tb['product_type']) ?>
                                            </td>
                                            <td style="text-align:right; font-weight:600;"><?= number_format((int)$tb['qty']) ?></td>
                                            <td style="text-align:right; font-weight:600;">
                                                <?= fmt_local((float)$tb['revenue'], $exchange_rate, $currency_symbol) ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ═══ Section 5: Recent Returns ═══ -->
        <div class="rpt-card">
            <div class="rpt-card-title">&#128229; Recent Returns</div>
            <?php if (empty($recent_returns)): ?>
                <div class="rpt-empty">
                    <div class="rpt-empty-icon">&#128229;</div>
                    <div class="rpt-empty-text">No returns recorded yet</div>
                </div>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table class="rpt-table">
                        <thead>
                            <tr>
                                <th>Return #</th>
                                <th>Date</th>
                                <th>Invoice #</th>
                                <th style="text-align:right">Amount</th>
                                <th>Reason</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_returns as $rr): ?>
                                <tr>
                                    <td style="font-weight:600;"><?= sanitize($rr['return_number'] ?? ('RET-' . $rr['id'])) ?></td>
                                    <td><?= date('M d, Y', strtotime($rr['created_at'])) ?></td>
                                    <td>
                                        <?php if (!empty($rr['order_number'])): ?>
                                            <a href="orders_detail.php?id=<?= (int)$rr['order_id'] ?>" class="rpt-link">
                                                <?= sanitize($rr['order_number']) ?>
                                            </a>
                                        <?php else: ?>
                                            <span style="color:#94A3B8;">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align:right; font-weight:600;">
                                        <?= fmt_local((float)$rr['total_amount'], $exchange_rate, $currency_symbol) ?>
                                    </td>
                                    <td style="max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
                                        <?= sanitize($rr['reason'] ?: 'No reason given') ?>
                                    </td>
                                    <td>
                                        <span class="rpt-badge rpt-badge-<?= sanitize($rr['status']) ?>">
                                            <?= ucfirst(sanitize($rr['status'])) ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- ═══ Chart.js Scripts ═══ -->
    <script>
    (function() {
        var CURRENCY_SYMBOL = <?= json_encode($currency_symbol) ?>;
        var EXCHANGE_RATE   = <?= json_encode($exchange_rate) ?>;

        function fmtCurrency(val) {
            return CURRENCY_SYMBOL + ' ' + Number(val).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
        }

        // ── Sales Bar Chart ──
        var salesEl = document.getElementById('salesChart');
        if (salesEl) {
            new Chart(salesEl, {
                type: 'bar',
                data: {
                    labels: <?= json_encode($chart_labels) ?>,
                    datasets: [
                        {
                            label: 'Gross Sales',
                            data: <?= json_encode($chart_sales) ?>,
                            backgroundColor: 'rgba(21, 101, 192, 0.75)',
                            borderColor: '#1565C0',
                            borderWidth: 1,
                            borderRadius: 4,
                        },
                        {
                            label: 'Returns',
                            data: <?= json_encode($chart_returns) ?>,
                            backgroundColor: 'rgba(220, 38, 38, 0.65)',
                            borderColor: '#DC2626',
                            borderWidth: 1,
                            borderRadius: 4,
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: { font: { family: 'Inter', size: 12, weight: '600' }, padding: 16, usePointStyle: true, pointStyleWidth: 12 }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(ctx) { return ctx.dataset.label + ': ' + fmtCurrency(ctx.parsed.y); }
                            },
                            backgroundColor: '#1E293B',
                            titleFont: { family: 'Inter', size: 12 },
                            bodyFont: { family: 'Inter', size: 12 },
                            padding: 12,
                            cornerRadius: 8,
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(v) { return CURRENCY_SYMBOL + ' ' + Number(v).toLocaleString(); },
                                font: { family: 'Inter', size: 11 },
                                color: '#64748B'
                            },
                            grid: { color: '#F1F5F9' }
                        },
                        x: {
                            ticks: { font: { family: 'Inter', size: 11 }, color: '#64748B', maxRotation: 45 },
                            grid: { display: false }
                        }
                    }
                }
            });
        }

        // ── Product Type Doughnut Chart ──
        var typeEl = document.getElementById('typeChart');
        if (typeEl) {
            var typeLabels = <?= json_encode($type_labels) ?>;
            var typeValues = <?= json_encode($type_values) ?>;
            var typeColorMap = <?= json_encode(array_values(array_intersect_key(
                $type_colors,
                array_flip(array_column($type_breakdown, 'product_type'))
            ))) ?>;

            // Fallback colors
            var defaultColors = ['#1565C0', '#16A34A', '#F59E0B', '#8B5CF6', '#EC4899'];
            var chartColors = typeColorMap.length ? typeColorMap : defaultColors.slice(0, typeLabels.length);

            new Chart(typeEl, {
                type: 'doughnut',
                data: {
                    labels: typeLabels,
                    datasets: [{
                        data: typeValues,
                        backgroundColor: chartColors,
                        borderWidth: 2,
                        borderColor: '#fff',
                        hoverOffset: 6,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    cutout: '55%',
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(ctx) { return ctx.label + ': ' + fmtCurrency(ctx.parsed); }
                            },
                            backgroundColor: '#1E293B',
                            bodyFont: { family: 'Inter', size: 12 },
                            padding: 12,
                            cornerRadius: 8,
                        }
                    }
                }
            });
        }
    })();
    </script>
</body>
</html>
