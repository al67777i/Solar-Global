<!-- Image Library Picker Modal -->
<div id="imagePickerOverlay" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:9999;justify-content:center;align-items:center;">
    <div id="imagePickerModal" style="background:#fff;border-radius:12px;width:90%;max-width:900px;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
        <!-- Header -->
        <div style="padding:20px 24px;border-bottom:1px solid #e5e7eb;display:flex;justify-content:space-between;align-items:center;flex-shrink:0;">
            <h3 style="margin:0;font-size:18px;color:#1e293b;">Select from Image Library</h3>
            <button type="button" onclick="closeImagePicker()" style="background:none;border:none;font-size:24px;cursor:pointer;color:#64748b;padding:0 4px;line-height:1;">&times;</button>
        </div>

        <!-- Filters -->
        <div style="padding:12px 24px;border-bottom:1px solid #e5e7eb;display:flex;gap:12px;align-items:center;flex-wrap:wrap;flex-shrink:0;">
            <div id="imgPickerTabs" style="display:flex;gap:4px;flex-wrap:wrap;">
                <button type="button" class="img-picker-tab active" data-folder="all" onclick="imgPickerFilterFolder('all',this)">All</button>
                <button type="button" class="img-picker-tab" data-folder="inverters" onclick="imgPickerFilterFolder('inverters',this)">Inverters</button>
                <button type="button" class="img-picker-tab" data-folder="batteries" onclick="imgPickerFilterFolder('batteries',this)">Batteries</button>
                <button type="button" class="img-picker-tab" data-folder="panels" onclick="imgPickerFilterFolder('panels',this)">Panels</button>
                <button type="button" class="img-picker-tab" data-folder="general" onclick="imgPickerFilterFolder('general',this)">General</button>
            </div>
            <input type="text" id="imgPickerSearch" placeholder="Search images..." oninput="imgPickerSearchDebounced()" style="flex:1;min-width:180px;padding:8px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;">
        </div>

        <!-- Image Grid -->
        <div id="imgPickerGrid" style="padding:16px 24px;overflow-y:auto;flex:1;">
            <div id="imgPickerImages" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:12px;"></div>
            <div id="imgPickerEmpty" style="display:none;text-align:center;padding:40px 0;color:#94a3b8;">
                <div style="font-size:48px;margin-bottom:8px;">&#128247;</div>
                <p>No images found</p>
            </div>
            <div id="imgPickerLoading" style="display:none;text-align:center;padding:20px 0;color:#64748b;">Loading...</div>
        </div>

        <!-- Footer -->
        <div style="padding:16px 24px;border-top:1px solid #e5e7eb;display:flex;justify-content:space-between;align-items:center;flex-shrink:0;">
            <div id="imgPickerPageInfo" style="color:#64748b;font-size:13px;"></div>
            <div style="display:flex;gap:8px;">
                <button type="button" id="imgPickerLoadMore" onclick="imgPickerLoadMore()" style="display:none;padding:8px 16px;background:#f1f5f9;border:1px solid #d1d5db;border-radius:6px;cursor:pointer;font-size:13px;color:#475569;">Load More</button>
                <button type="button" onclick="closeImagePicker()" style="padding:8px 16px;background:#f1f5f9;border:1px solid #d1d5db;border-radius:6px;cursor:pointer;font-size:13px;color:#475569;">Cancel</button>
                <button type="button" id="imgPickerUseBtn" onclick="imgPickerUseSelected()" disabled style="padding:8px 20px;background:#3b82f6;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:13px;font-weight:600;opacity:0.5;">Use Selected</button>
            </div>
        </div>
    </div>
</div>

<style>
.img-picker-tab {
    padding: 6px 14px;
    border: 1px solid #d1d5db;
    background: #fff;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    color: #475569;
    transition: all 0.15s;
}
.img-picker-tab:hover {
    background: #f1f5f9;
}
.img-picker-tab.active {
    background: #3b82f6;
    color: #fff;
    border-color: #3b82f6;
}
.img-picker-card {
    border: 2px solid #e5e7eb;
    border-radius: 8px;
    overflow: hidden;
    cursor: pointer;
    transition: all 0.15s;
    position: relative;
    background: #f8fafc;
}
.img-picker-card:hover {
    border-color: #93c5fd;
    box-shadow: 0 2px 8px rgba(59,130,246,0.15);
}
.img-picker-card.selected {
    border-color: #3b82f6;
    box-shadow: 0 0 0 2px rgba(59,130,246,0.3);
}
.img-picker-card.selected::after {
    content: "\2713";
    position: absolute;
    top: 6px;
    right: 6px;
    width: 22px;
    height: 22px;
    background: #3b82f6;
    color: #fff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    font-weight: bold;
}
.img-picker-card img {
    width: 100%;
    height: 100px;
    object-fit: contain;
    background: #fff;
    padding: 4px;
}
.img-picker-card .img-picker-label {
    padding: 4px 6px;
    font-size: 11px;
    color: #64748b;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    border-top: 1px solid #f1f5f9;
}
</style>

<script>
(function() {
    var _imgPicker = {
        targetInputId: null,
        targetPreviewId: null,
        selectedImage: null,
        currentFolder: 'all',
        currentSearch: '',
        currentPage: 1,
        totalPages: 1,
        searchTimer: null,
        defaultFolder: 'all'
    };

    window.openImagePicker = function(targetInputId, targetPreviewId, defaultFolder) {
        _imgPicker.targetInputId = targetInputId;
        _imgPicker.targetPreviewId = targetPreviewId;
        _imgPicker.selectedImage = null;
        _imgPicker.currentPage = 1;
        _imgPicker.currentSearch = '';
        _imgPicker.defaultFolder = defaultFolder || 'all';
        _imgPicker.currentFolder = _imgPicker.defaultFolder;

        document.getElementById('imgPickerSearch').value = '';
        document.getElementById('imgPickerUseBtn').disabled = true;
        document.getElementById('imgPickerUseBtn').style.opacity = '0.5';

        // Set active tab
        var tabs = document.querySelectorAll('.img-picker-tab');
        tabs.forEach(function(tab) {
            tab.classList.toggle('active', tab.getAttribute('data-folder') === _imgPicker.currentFolder);
        });

        document.getElementById('imagePickerOverlay').style.display = 'flex';
        document.body.style.overflow = 'hidden';
        imgPickerLoadImages(false);
    };

    window.closeImagePicker = function() {
        document.getElementById('imagePickerOverlay').style.display = 'none';
        document.body.style.overflow = '';
    };

    window.imgPickerFilterFolder = function(folder, btn) {
        _imgPicker.currentFolder = folder;
        _imgPicker.currentPage = 1;
        var tabs = document.querySelectorAll('.img-picker-tab');
        tabs.forEach(function(t) { t.classList.remove('active'); });
        btn.classList.add('active');
        imgPickerLoadImages(false);
    };

    window.imgPickerSearchDebounced = function() {
        clearTimeout(_imgPicker.searchTimer);
        _imgPicker.searchTimer = setTimeout(function() {
            _imgPicker.currentSearch = document.getElementById('imgPickerSearch').value;
            _imgPicker.currentPage = 1;
            imgPickerLoadImages(false);
        }, 300);
    };

    window.imgPickerLoadMore = function() {
        _imgPicker.currentPage++;
        imgPickerLoadImages(true);
    };

    window.imgPickerUseSelected = function() {
        if (!_imgPicker.selectedImage) return;

        var input = document.getElementById(_imgPicker.targetInputId);
        if (input) {
            // Store the raw DB path (file_path), NOT the display URL
            input.value = _imgPicker.selectedImage.file_path;
        }

        var preview = document.getElementById(_imgPicker.targetPreviewId);
        if (preview) {
            // Use display URL for preview image
            var imgSrc = _imgPicker.selectedImage.thumb_url || _imgPicker.selectedImage.display_url || _imgPicker.selectedImage.file_path;
            preview.innerHTML = '<img src="' + escapeHtml(imgSrc) + '" style="width:80px;height:80px;object-fit:contain;border:1px solid #ddd;border-radius:4px;">' +
                '<small style="display:block;color:#059669;margin-top:4px;">Selected: ' + escapeHtml(_imgPicker.selectedImage.filename) + '</small>';
        }

        closeImagePicker();
    };

    function imgPickerLoadImages(append) {
        var grid = document.getElementById('imgPickerImages');
        var empty = document.getElementById('imgPickerEmpty');
        var loading = document.getElementById('imgPickerLoading');
        var loadMoreBtn = document.getElementById('imgPickerLoadMore');
        var pageInfo = document.getElementById('imgPickerPageInfo');

        if (!append) {
            grid.innerHTML = '';
            _imgPicker.selectedImage = null;
            document.getElementById('imgPickerUseBtn').disabled = true;
            document.getElementById('imgPickerUseBtn').style.opacity = '0.5';
        }

        loading.style.display = 'block';
        empty.style.display = 'none';

        var url = 'ajax/image_library_picker.php?page=' + _imgPicker.currentPage +
            '&folder=' + encodeURIComponent(_imgPicker.currentFolder) +
            '&search=' + encodeURIComponent(_imgPicker.currentSearch);

        fetch(url)
            .then(function(r) { return r.json(); })
            .then(function(data) {
                loading.style.display = 'none';

                if (!data.success) {
                    empty.style.display = 'block';
                    empty.querySelector('p').textContent = 'Error loading images';
                    return;
                }

                _imgPicker.totalPages = data.total_pages;

                if (data.images.length === 0 && !append) {
                    empty.style.display = 'block';
                    loadMoreBtn.style.display = 'none';
                    pageInfo.textContent = '0 images';
                    return;
                }

                data.images.forEach(function(img) {
                    var card = document.createElement('div');
                    card.className = 'img-picker-card';
                    card.setAttribute('data-id', img.id);
                    // Use thumb_url/display_url for display; file_path is the raw DB value
                    var thumbSrc = img.thumb_url || img.display_url || img.file_path;
                    card.innerHTML = '<img src="' + escapeHtml(thumbSrc) + '" alt="' + escapeHtml(img.alt_text || img.filename) + '" loading="lazy">' +
                        '<div class="img-picker-label" title="' + escapeHtml(img.original_filename || img.filename) + '">' + escapeHtml(img.original_filename || img.filename) + '</div>';

                    card.addEventListener('click', function() {
                        document.querySelectorAll('.img-picker-card.selected').forEach(function(c) { c.classList.remove('selected'); });
                        card.classList.add('selected');
                        _imgPicker.selectedImage = img;
                        document.getElementById('imgPickerUseBtn').disabled = false;
                        document.getElementById('imgPickerUseBtn').style.opacity = '1';
                    });

                    card.addEventListener('dblclick', function() {
                        _imgPicker.selectedImage = img;
                        imgPickerUseSelected();
                    });

                    grid.appendChild(card);
                });

                var showing = grid.children.length;
                pageInfo.textContent = 'Showing ' + showing + ' of ' + data.total + ' images';
                loadMoreBtn.style.display = (_imgPicker.currentPage < _imgPicker.totalPages) ? 'inline-block' : 'none';
            })
            .catch(function(err) {
                loading.style.display = 'none';
                empty.style.display = 'block';
                empty.querySelector('p').textContent = 'Failed to load images';
            });
    }

    function escapeHtml(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    // Close modal on overlay click
    document.getElementById('imagePickerOverlay').addEventListener('click', function(e) {
        if (e.target === this) closeImagePicker();
    });

    // Close modal on Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && document.getElementById('imagePickerOverlay').style.display === 'flex') {
            closeImagePicker();
        }
    });
})();
</script>
