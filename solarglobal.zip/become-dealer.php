<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
set_security_headers();

$db = getDB();

// Dynamic site name
$site_name = get_system_setting('site_name', 'SolarGlobal');

// Fetch dynamic pricing from admin settings
$dealer_fee     = (float)get_system_setting('dealer_monthly_fee', '1.00');
$trial_enabled  = (int)get_system_setting('dealer_free_trial_enabled', '1');
$trial_days     = (int)get_system_setting('dealer_free_trial_days', '7');
$fee_display    = $dealer_fee > 0 ? '$' . number_format($dealer_fee, 2) : 'FREE';

// Real stats from database
$stats = [];
try {
    $stats['dealers'] = (int)$db->query("SELECT COUNT(*) FROM dealers WHERE status = 'active'")->fetchColumn();
    $stats['countries'] = (int)$db->query("SELECT COUNT(DISTINCT country_code) FROM dealers WHERE status = 'active' AND country_code IS NOT NULL AND country_code != ''")->fetchColumn();
    $stats['products'] = (int)$db->query("SELECT COUNT(*) FROM dealer_products")->fetchColumn();
    $stats['orders'] = (int)$db->query("SELECT COUNT(*) FROM orders WHERE status IN ('picked_up','ready','confirmed','processing')")->fetchColumn();
} catch (Exception $e) {
    $stats = ['dealers' => 0, 'countries' => 0, 'products' => 0, 'orders' => 0];
}

// Real reviews from top-rated dealers (for testimonials)
$testimonials = [];
try {
    $stmt = $db->query("SELECT dr.review_text, dr.rating, c.name AS customer_name, c.city, c.country_code, d.business_name
        FROM dealer_reviews dr
        JOIN customers c ON dr.customer_id = c.id
        JOIN dealers d ON dr.dealer_id = d.id
        WHERE dr.status = 'approved' AND dr.rating >= 4
        ORDER BY dr.created_at DESC LIMIT 3");
    $testimonials = $stmt->fetchAll();
} catch (Exception $e) {}

$page_title = 'Become a Dealer';
$page_description = 'Open your solar store and sell inverters, batteries, and solar panels online. Join our network of authorized dealers. Low monthly fees, global reach.';
require_once 'includes/header.php';
?>

<style>
/* ── Hero ── */
.bd-hero {
    background: linear-gradient(160deg, #0a0a0a 0%, #0D1B2A 40%, #1B2838 70%, #0D3B6E 100%);
    position: relative;
    padding: 100px 20px;
    text-align: center;
    color: #fff;
    overflow: hidden;
}
.bd-hero::before {
    content: '';
    position: absolute;
    top: -100px;
    right: -80px;
    width: 500px;
    height: 500px;
    background: radial-gradient(circle, rgba(21,101,192,0.2) 0%, transparent 70%);
    border-radius: 50%;
}
.bd-hero::after {
    content: '';
    position: absolute;
    bottom: -80px;
    left: -50px;
    width: 350px;
    height: 350px;
    background: radial-gradient(circle, rgba(245,158,11,0.08) 0%, transparent 70%);
    border-radius: 50%;
}
.bd-hero-content { position: relative; z-index: 1; max-width: 720px; margin: 0 auto; }
.bd-hero h1 {
    font-size: 2.75rem;
    font-weight: 800;
    margin-bottom: 18px;
    line-height: 1.2;
    letter-spacing: -0.02em;
    color: #ffffff;
}
.bd-hero h1 span { color: #F59E0B; }
.bd-hero p {
    font-size: 1.15rem;
    line-height: 1.7;
    opacity: 0.85;
    margin-bottom: 36px;
}
.bd-hero-btns { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; }
.bd-btn-primary {
    background: #F59E0B;
    color: #0F172A;
    padding: 15px 34px;
    border-radius: 8px;
    font-weight: 700;
    font-size: 1rem;
    text-decoration: none;
    transition: transform 0.2s, box-shadow 0.2s;
    box-shadow: 0 4px 16px rgba(245,158,11,0.3);
}
.bd-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 24px rgba(245,158,11,0.4); }
.bd-btn-secondary {
    background: transparent;
    color: #fff;
    padding: 15px 34px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 1rem;
    text-decoration: none;
    border: 1.5px solid rgba(255,255,255,0.25);
    transition: background 0.2s, border-color 0.2s;
}
.bd-btn-secondary:hover { background: rgba(255,255,255,0.08); border-color: rgba(255,255,255,0.45); }

/* ── Stats ── */
.bd-stats {
    background: #0F172A;
    padding: 36px 20px;
    display: flex;
    justify-content: center;
    gap: 48px;
    flex-wrap: wrap;
}
.bd-stat { text-align: center; }
.bd-stat-num { font-size: 2.2rem; font-weight: 800; color: #F59E0B; display: block; }
.bd-stat-label { font-size: 0.85rem; color: #94A3B8; margin-top: 4px; }

/* ── Sections ── */
.bd-section { padding: 80px 20px; max-width: 1100px; margin: 0 auto; }
.bd-section-alt { background: #F8FAFC; }
.bd-title { text-align: center; font-size: 2rem; font-weight: 800; color: #0F172A; margin-bottom: 12px; }
.bd-subtitle { text-align: center; font-size: 1rem; color: #64748B; max-width: 550px; margin: 0 auto 48px; line-height: 1.6; }

/* ── Steps ── */
.bd-steps { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 28px; }
.bd-step {
    text-align: center;
    padding: 28px 16px;
    background: #fff;
    border-radius: 12px;
    border: 1px solid #E2E8F0;
    position: relative;
}
.bd-step-num {
    position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
    width: 28px; height: 28px; background: #0D3B6E; color: #fff;
    border-radius: 50%; font-size: 0.75rem; font-weight: 700;
    display: flex; align-items: center; justify-content: center;
}
.bd-step-icon { font-size: 2.5rem; margin: 12px 0 14px; display: block; }
.bd-step h3 { font-size: 1rem; font-weight: 700; color: #1E293B; margin-bottom: 6px; }
.bd-step p { font-size: 0.85rem; color: #64748B; line-height: 1.6; }

/* ── Benefits ── */
.bd-benefits { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
.bd-benefit {
    background: #fff;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    padding: 24px;
    transition: transform 0.2s, box-shadow 0.2s;
}
.bd-benefit:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,0.06); }
.bd-benefit-icon { font-size: 1.75rem; margin-bottom: 10px; display: block; }
.bd-benefit h3 { font-size: 1rem; font-weight: 700; color: #1E293B; margin-bottom: 6px; }
.bd-benefit p { font-size: 0.85rem; color: #64748B; line-height: 1.6; }

/* ── Testimonials ── */
.bd-testimonials { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; }
.bd-testimonial {
    background: #fff; border: 1px solid #E2E8F0; border-radius: 12px; padding: 24px;
}
.bd-testimonial-stars { color: #F59E0B; font-size: 1.1rem; margin-bottom: 10px; }
.bd-testimonial p { font-size: 0.9rem; color: #475569; line-height: 1.7; font-style: italic; margin-bottom: 14px; }
.bd-testimonial-author { font-size: 0.8rem; color: #94A3B8; }
.bd-testimonial-author strong { color: #1E293B; font-weight: 600; }

/* ── Pricing ── */
.bd-pricing {
    max-width: 400px;
    margin: 0 auto;
    background: #fff;
    border-radius: 16px;
    padding: 36px;
    text-align: center;
    box-shadow: 0 6px 24px rgba(0,0,0,0.08);
    border: 2px solid #0D3B6E;
    position: relative;
    overflow: hidden;
}
.bd-pricing-badge {
    position: absolute; top: 18px; right: -30px;
    background: #F59E0B; color: #0F172A;
    font-size: 0.65rem; font-weight: 700; padding: 4px 36px;
    transform: rotate(45deg); text-transform: uppercase; letter-spacing: 0.5px;
}
.bd-pricing-amount { font-size: 3.5rem; font-weight: 800; color: #0D3B6E; }
.bd-pricing-amount span { font-size: 1rem; font-weight: 400; color: #64748B; }
.bd-pricing-trial { color: #F59E0B; font-weight: 600; font-size: 0.875rem; margin: 4px 0 16px; }
.bd-pricing-features { list-style: none; padding: 0; margin: 20px 0; text-align: left; }
.bd-pricing-features li {
    padding: 9px 0; border-bottom: 1px solid #F1F5F9;
    font-size: 0.875rem; color: #475569;
}
.bd-pricing-features li::before { content: "\2713"; color: #10B981; font-weight: 700; margin-right: 10px; }

/* ── FAQ ── */
.bd-faq { max-width: 700px; margin: 0 auto; }
.bd-faq-item { border: 1px solid #E2E8F0; border-radius: 10px; margin-bottom: 10px; background: #fff; overflow: hidden; }
.bd-faq-q {
    padding: 18px 20px; font-weight: 600; font-size: 0.9375rem; color: #1E293B;
    cursor: pointer; display: flex; justify-content: space-between; align-items: center;
    user-select: none; transition: background 0.2s;
}
.bd-faq-q:hover { background: #F8FAFC; }
.bd-faq-q::after { content: "+"; font-size: 1.3rem; color: #94A3B8; transition: transform 0.3s; }
.bd-faq-item.active .bd-faq-q::after { transform: rotate(45deg); }
.bd-faq-a { padding: 0 20px; max-height: 0; overflow: hidden; transition: max-height 0.3s, padding 0.3s; color: #64748B; line-height: 1.7; font-size: 0.875rem; }
.bd-faq-item.active .bd-faq-a { padding: 0 20px 18px; max-height: 300px; }

/* ── CTA ── */
.bd-cta {
    background: linear-gradient(135deg, #0a0a0a 0%, #0D3B6E 100%);
    padding: 70px 20px; text-align: center; color: #fff;
}
.bd-cta h2 { font-size: 2rem; font-weight: 800; margin-bottom: 12px; }
.bd-cta p { font-size: 1rem; opacity: 0.8; margin-bottom: 28px; }

@media (max-width: 768px) {
    .bd-hero h1 { font-size: 2rem; }
    .bd-hero { padding: 60px 16px; }
    .bd-stats { gap: 24px; padding: 28px 16px; }
    .bd-stat-num { font-size: 1.75rem; }
    .bd-title { font-size: 1.6rem; }
    .bd-benefits { grid-template-columns: 1fr; }
    .bd-testimonials { grid-template-columns: 1fr; }
    .bd-pricing-amount { font-size: 2.75rem; }
    .bd-cta h2 { font-size: 1.5rem; }
}
</style>

<!-- Hero Section -->
<section class="bd-hero">
    <div class="bd-hero-content">
        <h1>Sell Solar Products on <span><?= sanitize($site_name) ?></span></h1>
        <p>List your products, connect with customers, and grow your solar business. Our recommendation engine matches your inventory to buyers actively looking for solar solutions.</p>
        <div class="bd-hero-btns">
            <a href="<?= BASE_URL ?>dealer/register.php" class="bd-btn-primary">Open Your Store</a>
            <a href="<?= BASE_URL ?>dealer/login.php" class="bd-btn-secondary">Dealer Login</a>
        </div>
    </div>
</section>

<!-- Stats Bar — Real Data -->
<section class="bd-stats">
    <div class="bd-stat">
        <span class="bd-stat-num"><?= $stats['dealers'] ?></span>
        <span class="bd-stat-label">Active Dealers</span>
    </div>
    <div class="bd-stat">
        <span class="bd-stat-num"><?= $stats['countries'] ?></span>
        <span class="bd-stat-label"><?= $stats['countries'] == 1 ? 'Country' : 'Countries' ?></span>
    </div>
    <div class="bd-stat">
        <span class="bd-stat-num"><?= number_format($stats['products']) ?></span>
        <span class="bd-stat-label">Products Listed</span>
    </div>
    <div class="bd-stat">
        <span class="bd-stat-num"><?= $fee_display ?></span>
        <span class="bd-stat-label">Per Month</span>
    </div>
</section>

<!-- How It Works -->
<section class="bd-section-alt">
    <div class="bd-section">
        <h2 class="bd-title">How It Works</h2>
        <p class="bd-subtitle">Get your solar store up and running in four simple steps</p>
        <div class="bd-steps">
            <div class="bd-step">
                <span class="bd-step-num">1</span>
                <span class="bd-step-icon">&#128221;</span>
                <h3>Register</h3>
                <p>Create your dealer account with business details and location.</p>
            </div>
            <div class="bd-step">
                <span class="bd-step-num">2</span>
                <span class="bd-step-icon">&#9989;</span>
                <h3>Get Verified</h3>
                <p>Our team reviews and approves your store within 24-48 hours.</p>
            </div>
            <div class="bd-step">
                <span class="bd-step-num">3</span>
                <span class="bd-step-icon">&#128230;</span>
                <h3>Add Products</h3>
                <p>List inverters, panels, batteries with your custom pricing.</p>
            </div>
            <div class="bd-step">
                <span class="bd-step-num">4</span>
                <span class="bd-step-icon">&#128176;</span>
                <h3>Start Selling</h3>
                <p>Customers find you through our recommendation engine.</p>
            </div>
        </div>
    </div>
</section>

<!-- Benefits -->
<section class="bd-section">
    <h2 class="bd-title">Why Choose <?= sanitize($site_name) ?></h2>
    <p class="bd-subtitle">Tools designed to help your solar business grow</p>
    <div class="bd-benefits">
        <div class="bd-benefit">
            <span class="bd-benefit-icon">&#128205;</span>
            <h3>Location-Based Matching</h3>
            <p>Customers near your store see your products first. Our smart system drives local sales and reduces delivery complexity.</p>
        </div>
        <div class="bd-benefit">
            <span class="bd-benefit-icon">&#129504;</span>
            <h3>Smart Recommendations</h3>
            <p>Our recommendation engine connects your products to customers based on their actual energy needs and preferences.</p>
        </div>
        <div class="bd-benefit">
            <span class="bd-benefit-icon">&#128200;</span>
            <h3>Analytics Dashboard</h3>
            <p>Track product views, customer inquiries, orders, and revenue with real-time analytics built for dealers.</p>
        </div>
        <div class="bd-benefit">
            <span class="bd-benefit-icon">&#128178;</span>
            <h3>Flat <?= $fee_display ?>/Month</h3>
            <p>No commissions, no hidden fees. One flat subscription gives you access to the full marketplace and all tools.</p>
        </div>
        <div class="bd-benefit">
            <span class="bd-benefit-icon">&#128176;</span>
            <h3>Custom Pricing Control</h3>
            <p>Set your own prices per product, manage stock levels, and create competitive offers.</p>
        </div>
        <div class="bd-benefit">
            <span class="bd-benefit-icon">&#128227;</span>
            <h3>Order Management</h3>
            <p>Full POS system with invoicing, returns, and customer management — all built in.</p>
        </div>
    </div>
</section>

<?php if (!empty($testimonials)): ?>
<!-- Real Testimonials -->
<section class="bd-section-alt">
    <div class="bd-section">
        <h2 class="bd-title">What Customers Say About Our Dealers</h2>
        <p class="bd-subtitle">Real reviews from verified customers</p>
        <div class="bd-testimonials">
            <?php foreach ($testimonials as $t): ?>
                <div class="bd-testimonial">
                    <div class="bd-testimonial-stars">
                        <?php for ($i = 1; $i <= 5; $i++) echo $i <= (int)$t['rating'] ? '&#9733;' : '&#9734;'; ?>
                    </div>
                    <p>"<?= sanitize(strlen($t['review_text']) > 180 ? substr($t['review_text'], 0, 180) . '...' : $t['review_text']) ?>"</p>
                    <div class="bd-testimonial-author">
                        <strong><?= sanitize($t['customer_name']) ?></strong> &middot; Customer of <?= sanitize($t['business_name']) ?>
                        <?php if (!empty($t['city'])): ?> &middot; <?= sanitize($t['city']) ?><?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Pricing -->
<section class="bd-section">
    <h2 class="bd-title">Simple, Transparent Pricing</h2>
    <p class="bd-subtitle">One plan, everything included, no surprises</p>
    <div class="bd-pricing">
        <?php if ($trial_enabled): ?>
            <div class="bd-pricing-badge"><?= $trial_days ?>-Day Free</div>
        <?php endif; ?>
        <div class="bd-pricing-amount"><?= $fee_display ?><span>/month</span></div>
        <?php if ($trial_enabled): ?>
            <div class="bd-pricing-trial"><?= $trial_days ?>-day free trial &middot; Cancel anytime</div>
        <?php endif; ?>
        <ul class="bd-pricing-features">
            <li>Unlimited product listings</li>
            <li>Smart recommendation placement</li>
            <li>Location-based customer matching</li>
            <li>Real-time analytics dashboard</li>
            <li>Custom store profile page</li>
            <li>Order & invoice management system</li>
            <li>Stripe-secured automatic billing</li>
            <li>Cancel anytime, no contracts</li>
        </ul>
        <?php if ($trial_enabled): ?>
            <a href="<?= BASE_URL ?>dealer/register.php" class="bd-btn-primary" style="display:inline-block;">Start <?= $trial_days ?>-Day Free Trial</a>
            <p style="font-size:0.78rem;color:#94A3B8;margin-top:10px;">No credit card required for trial</p>
        <?php else: ?>
            <a href="<?= BASE_URL ?>dealer/register.php" class="bd-btn-primary" style="display:inline-block;">Get Started Now</a>
        <?php endif; ?>
    </div>
</section>

<!-- FAQ -->
<section class="bd-section-alt">
    <div class="bd-section">
        <h2 class="bd-title">Frequently Asked Questions</h2>
        <div class="bd-faq">
            <div class="bd-faq-item">
                <div class="bd-faq-q">How do I register as a dealer?</div>
                <div class="bd-faq-a">Click "Open Your Store" to start the registration process. Provide your business details and location. Most applications are reviewed within 24-48 hours.</div>
            </div>
            <div class="bd-faq-item">
                <div class="bd-faq-q">What does the <?= $fee_display ?>/month subscription include?</div>
                <div class="bd-faq-a">Your subscription includes unlimited product listings, smart recommendation placement, location-based matching, analytics dashboard, store profile, order management, and invoicing. No commissions or hidden fees.</div>
            </div>
            <div class="bd-faq-item">
                <div class="bd-faq-q">What products can I list?</div>
                <div class="bd-faq-a">Any solar-related products: panels, inverters, batteries, charge controllers, mounting systems, cables, and accessories. All products must be genuine.</div>
            </div>
            <div class="bd-faq-item">
                <div class="bd-faq-q">How do customers find my products?</div>
                <div class="bd-faq-a">Through our recommendation engine, location-based search, product category browsing, and the solar system calculator. Nearby dealers are prioritized in search results.</div>
            </div>
            <div class="bd-faq-item">
                <div class="bd-faq-q">Can I cancel anytime?</div>
                <div class="bd-faq-a">Yes. Cancel from your dashboard at any time. Your store remains active until the end of the current billing period. No cancellation fees.</div>
            </div>
            <?php if ($trial_enabled): ?>
            <div class="bd-faq-item">
                <div class="bd-faq-q">Is the free trial really free?</div>
                <div class="bd-faq-a">Yes. You get <?= $trial_days ?> days of full access with no credit card required. After the trial, subscribe to continue or your store is simply paused.</div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Final CTA -->
<section class="bd-cta">
    <h2>Ready to Grow Your Solar Business?</h2>
    <p>Join <?= $stats['dealers'] ?> dealer<?= $stats['dealers'] != 1 ? 's' : '' ?> already on <?= sanitize($site_name) ?>. Start <?= $trial_enabled ? "your {$trial_days}-day free trial" : "for just {$fee_display}/month" ?> today.</p>
    <a href="<?= BASE_URL ?>dealer/register.php" class="bd-btn-primary">Open Your Store Now</a>
</section>

<script>
// FAQ Accordion
document.querySelectorAll('.bd-faq-q').forEach(function(q) {
    q.addEventListener('click', function() {
        var item = q.parentElement;
        var isActive = item.classList.contains('active');
        document.querySelectorAll('.bd-faq-item').forEach(function(i) { i.classList.remove('active'); });
        if (!isActive) item.classList.add('active');
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>
