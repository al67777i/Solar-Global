<?php
/**
 * CurrencyHelper - Country detection and currency conversion
 *
 * Detects user's country from location data and provides
 * currency conversion for product pricing.
 */

require_once __DIR__ . '/db.php';

class CurrencyHelper {

    private PDO $db;
    private ?array $country = null;
    private float $rate = 1.0;

    // Fallback: International/USD
    private const FALLBACK = [
        'code'           => '',
        'name'           => 'International',
        'currency_code'  => 'USD',
        'currency_symbol'=> '$',
        'exchange_rate_to_usd' => 1.0,
        'is_supported'   => 0,
        'flag_emoji'     => '🌍',
        'grid_voltage'   => 230,
        'grid_frequency' => 50,
        'electricity_rate_kwh' => 0.15,
        'net_metering_available' => 0,
    ];

    public function __construct(?string $countryCode = null) {
        $this->db = getDB();
        if ($countryCode) {
            $this->detectCountry($countryCode);
        }
    }

    /**
     * Detect country from 2-letter ISO code
     */
    public function detectCountry(string $countryCode): ?array {
        $code = strtoupper(trim($countryCode));
        if (strlen($code) < 2 || strlen($code) > 3) {
            $this->country = null;
            return null;
        }

        try {
            $stmt = $this->db->prepare("
                SELECT * FROM countries WHERE code = ? LIMIT 1
            ");
            $stmt->execute([$code]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($row) {
                $this->country = $row;
                $this->rate = max(0.001, floatval($row['exchange_rate_to_usd'] ?? 1.0));
                return $row;
            }
        } catch (PDOException $e) {
            error_log("CurrencyHelper: " . $e->getMessage());
        }

        $this->country = null;
        return null;
    }

    /**
     * Get full pricing context for API responses
     */
    public function getPricingContext(): array {
        $c = $this->country;
        if (!$c) {
            return [
                'code'          => 'USD',
                'symbol'        => '$',
                'rate'          => 1.0,
                'country_code'  => '',
                'country_name'  => 'International',
                'flag'          => '🌍',
                'is_local'      => false,
                'is_supported'  => false,
                'label'         => 'International (USD)',
            ];
        }

        $code   = $c['currency_code'] ?? 'USD';
        $symbol = $c['currency_symbol'] ?? '$';
        $rate   = $this->rate;

        return [
            'code'          => $code,
            'symbol'        => $symbol,
            'rate'          => $rate,
            'country_code'  => $c['code'] ?? '',
            'country_name'  => $c['name'] ?? 'Unknown',
            'flag'          => $c['flag_emoji'] ?? '',
            'is_local'      => true,
            'is_supported'  => (bool)($c['is_supported'] ?? false),
            'label'         => ($c['flag_emoji'] ?? '') . ' ' . ($c['name'] ?? '') . " ({$code})",
            'electricity_rate_kwh' => floatval($c['electricity_rate_kwh'] ?? 0),
            'grid_voltage'  => intval($c['grid_voltage'] ?? 230),
            'grid_frequency'=> intval($c['grid_frequency'] ?? 50),
            'net_metering_available' => (bool)($c['net_metering_available'] ?? false),
        ];
    }

    /**
     * Convert USD amount to local currency
     */
    public function convertFromUSD(float $usdAmount): float {
        return round($usdAmount * $this->rate, 2);
    }

    /**
     * Format a USD price for display in local currency
     */
    public function formatPrice(float $usdAmount): string {
        $converted = $this->convertFromUSD($usdAmount);
        $symbol = $this->country ? ($this->country['currency_symbol'] ?? '$') : '$';
        return $symbol . number_format($converted, 0, '.', ',');
    }

    /**
     * Get exchange rate
     */
    public function getRate(): float {
        return $this->rate;
    }

    /**
     * Get detected country data
     */
    public function getCountry(): ?array {
        return $this->country;
    }

    /**
     * Get country grid/electrical info for the recommendation engine
     */
    public function getGridInfo(): array {
        $c = $this->country ?: self::FALLBACK;
        $buy_rate = floatval($c['electricity_rate_kwh'] ?? 0.15);
        $sell_rate = floatval($c['sell_rate_kwh'] ?? 0);
        // If no sell rate set, default to 80% of buy rate
        if ($sell_rate <= 0) $sell_rate = $buy_rate * 0.8;
        return [
            'grid_voltage'   => intval($c['grid_voltage'] ?? 230),
            'grid_frequency' => intval($c['grid_frequency'] ?? 50),
            'electricity_rate_kwh' => $buy_rate,
            'sell_rate_kwh'  => $sell_rate,
            'net_metering_available' => (bool)($c['net_metering_available'] ?? false),
        ];
    }

    /**
     * Filter products by country availability
     * Products with matching country_code get priority,
     * products with 'global' available_regions are included as fallback
     */
    public static function filterProductsByCountry(array $products, string $countryCode): array {
        if (empty($countryCode)) return $products;

        $local = [];
        $global = [];

        foreach ($products as $p) {
            $pCountry = $p['country_code'] ?? '';
            $regions  = $p['available_regions'] ?? 'global';

            if ($pCountry === $countryCode) {
                $p['_availability'] = 'local';
                $local[] = $p;
            } elseif ($regions === 'global' || empty($pCountry)) {
                $p['_availability'] = 'international';
                $global[] = $p;
            }
        }

        // Local products first, then global
        return array_merge($local, $global);
    }

    /**
     * Get dealer products with dealer-specific pricing
     */
    public function getDealerProducts(
        float $lat, float $lng, float $radiusKm,
        string $productType, ?int $productId = null
    ): array {
        try {
            $sql = "
                SELECT
                    dp.*,
                    d.business_name, d.city, d.phone, d.latitude AS dealer_lat, d.longitude AS dealer_lng,
                    d.rating_avg, d.logo_path AS dealer_logo
                FROM dealer_products dp
                JOIN dealers d ON dp.dealer_id = d.id
                WHERE d.status = 'active'
                  AND d.subscription_status = 'active'
                  AND (d.subscription_expires_at IS NULL OR d.subscription_expires_at > NOW())
                  AND d.latitude IS NOT NULL
                  AND d.longitude IS NOT NULL
                  AND dp.product_type = ?
                  AND dp.is_active = 1
                  AND dp.stock_quantity > 0
            ";
            $params = [$productType];

            if ($productId) {
                $sql .= " AND dp.product_id = ?";
                $params[] = $productId;
            }

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Filter by distance using Haversine
            $nearby = [];
            foreach ($results as $r) {
                $dist = self::haversine($lat, $lng, floatval($r['dealer_lat']), floatval($r['dealer_lng']));
                if ($dist <= $radiusKm) {
                    $r['distance_km'] = round($dist, 1);
                    $nearby[] = $r;
                }
            }

            usort($nearby, fn($a, $b) => $a['distance_km'] <=> $b['distance_km']);
            return $nearby;

        } catch (PDOException $e) {
            error_log("CurrencyHelper::getDealerProducts: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Apply country-specific price adjustments (markup, tax, shipping)
     * Used by the recommendation engine to show country-adjusted pricing
     *
     * @param float $usdPrice Base price in USD
     * @param string $productType 'inverter', 'battery', or 'panel'
     * @return float Adjusted price in USD (before currency conversion)
     */
    public function applyPriceAdjustment(float $usdPrice, string $productType): float {
        if (!$this->country) return $usdPrice;

        $countryCode = $this->country['code'] ?? '';
        if (empty($countryCode)) return $usdPrice;

        try {
            $stmt = $this->db->prepare("SELECT * FROM country_price_adjustments WHERE country_code = ?");
            $stmt->execute([$countryCode]);
            $adjustments = [];
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $adjustments[$row['product_type']] = $row;
            }

            $price = $usdPrice;

            // Apply "all" category first
            if (isset($adjustments['all'])) {
                $all = $adjustments['all'];
                $price = $price * (1 + floatval($all['markup_percent']) / 100);
                $price = $price * (1 + floatval($all['tax_percent']) / 100);
                $price += floatval($all['shipping_flat_usd']);
            }

            // Apply category-specific on top
            if (isset($adjustments[$productType])) {
                $cat = $adjustments[$productType];
                $price = $price * (1 + floatval($cat['markup_percent']) / 100);
                $price = $price * (1 + floatval($cat['tax_percent']) / 100);
                $price += floatval($cat['shipping_flat_usd']);
            }

            return round($price, 2);
        } catch (PDOException $e) {
            error_log("CurrencyHelper::applyPriceAdjustment: " . $e->getMessage());
            return $usdPrice;
        }
    }

    /**
     * Get the price adjustment breakdown for display
     */
    public function getPriceAdjustmentBreakdown(string $productType): array {
        if (!$this->country) return ['has_adjustments' => false];

        $countryCode = $this->country['code'] ?? '';
        if (empty($countryCode)) return ['has_adjustments' => false];

        try {
            $stmt = $this->db->prepare("SELECT * FROM country_price_adjustments WHERE country_code = ?");
            $stmt->execute([$countryCode]);
            $adjustments = [];
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $adjustments[$row['product_type']] = $row;
            }

            if (empty($adjustments)) return ['has_adjustments' => false];

            $totalMarkup = 0;
            $totalTax = 0;
            $totalShipping = 0;

            if (isset($adjustments['all'])) {
                $totalMarkup += floatval($adjustments['all']['markup_percent']);
                $totalTax += floatval($adjustments['all']['tax_percent']);
                $totalShipping += floatval($adjustments['all']['shipping_flat_usd']);
            }
            if (isset($adjustments[$productType])) {
                $totalMarkup += floatval($adjustments[$productType]['markup_percent']);
                $totalTax += floatval($adjustments[$productType]['tax_percent']);
                $totalShipping += floatval($adjustments[$productType]['shipping_flat_usd']);
            }

            return [
                'has_adjustments' => true,
                'markup_percent' => $totalMarkup,
                'tax_percent' => $totalTax,
                'shipping_usd' => $totalShipping,
                'country_code' => $countryCode
            ];
        } catch (PDOException $e) {
            return ['has_adjustments' => false];
        }
    }

    /**
     * Haversine distance formula
     */
    private static function haversine(float $lat1, float $lng1, float $lat2, float $lng2): float {
        $R = 6371;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) * sin($dLat / 2) +
             cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
             sin($dLng / 2) * sin($dLng / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        return $R * $c;
    }
}
