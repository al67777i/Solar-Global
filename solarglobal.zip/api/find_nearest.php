<?php
/**
 * Find Nearest Dealers API
 * Returns dealers near user location that stock specific products.
 * Used by the "Find Nearest" section in the recommendation system overview (D7).
 */
require_once '../includes/db.php';
require_once '../includes/helpers.php';
require_once '../includes/location_helper.php';
require_once '../includes/subscription_helpers.php';

header('Content-Type: application/json; charset=utf-8');
set_security_headers();

if (!rate_limit('api_find_nearest', 30, 60)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Too many requests']);
    exit;
}

$lat = floatval($_GET['lat'] ?? 0);
$lng = floatval($_GET['lng'] ?? 0);
$inverter_id = intval($_GET['inverter_id'] ?? 0);
$battery_id = intval($_GET['battery_id'] ?? 0);
$panel_id = intval($_GET['panel_id'] ?? 0);
$radius = max(10, min(500, floatval($_GET['radius'] ?? 100)));

if ($lat == 0 || $lng == 0) {
    echo json_encode(['success' => false, 'message' => 'Location required']);
    exit;
}

if ($inverter_id == 0 && $battery_id == 0 && $panel_id == 0) {
    echo json_encode(['success' => false, 'message' => 'At least one product ID required']);
    exit;
}

try {
    $db = getDB();

    // Build haversine distance SQL
    $haversine = "
        (6371 * acos(
            LEAST(1.0, cos(radians(:lat1)) * cos(radians(d.latitude)) *
            cos(radians(d.longitude) - radians(:lng1)) +
            sin(radians(:lat2)) * sin(radians(d.latitude)))
        ))
    ";

    $subscription_filter = get_dealer_subscription_filter('d');

    // Find dealers within radius that have at least one of the selected products
    $product_conditions = [];
    $product_params = [];

    if ($inverter_id > 0) {
        $product_conditions[] = "EXISTS (SELECT 1 FROM dealer_products dp_inv WHERE dp_inv.dealer_id = d.id AND dp_inv.product_type = 'inverter' AND dp_inv.product_id = :inv_id AND dp_inv.is_active = 1)";
        $product_params[':inv_id'] = $inverter_id;
    }
    if ($battery_id > 0) {
        $product_conditions[] = "EXISTS (SELECT 1 FROM dealer_products dp_bat WHERE dp_bat.dealer_id = d.id AND dp_bat.product_type = 'battery' AND dp_bat.product_id = :bat_id AND dp_bat.is_active = 1)";
        $product_params[':bat_id'] = $battery_id;
    }
    if ($panel_id > 0) {
        $product_conditions[] = "EXISTS (SELECT 1 FROM dealer_products dp_pan WHERE dp_pan.dealer_id = d.id AND dp_pan.product_type = 'panel' AND dp_pan.product_id = :pan_id AND dp_pan.is_active = 1)";
        $product_params[':pan_id'] = $panel_id;
    }

    // At least one product must match
    $product_where = '(' . implode(' OR ', $product_conditions) . ')';

    // Query within radius
    $sql = "
        SELECT d.id AS dealer_id, d.business_name, d.city, d.country_code, d.phone,
               d.latitude, d.longitude,
               {$haversine} AS distance_km
        FROM dealers d
        WHERE d.status = 'active'
          AND {$subscription_filter}
          AND d.latitude IS NOT NULL AND d.longitude IS NOT NULL
          AND {$product_where}
        HAVING distance_km <= :radius
        ORDER BY distance_km ASC
        LIMIT 10
    ";

    $stmt = $db->prepare($sql);
    $stmt->bindValue(':lat1', $lat);
    $stmt->bindValue(':lng1', $lng);
    $stmt->bindValue(':lat2', $lat);
    $stmt->bindValue(':radius', $radius);
    foreach ($product_params as $key => $val) {
        $stmt->bindValue($key, $val, PDO::PARAM_INT);
    }
    $stmt->execute();
    $dealers_within = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Enrich each dealer with which products they have
    foreach ($dealers_within as &$dealer) {
        $dealer['distance_km'] = round(floatval($dealer['distance_km']), 1);
        $dealer['has_inverter'] = false;
        $dealer['has_battery'] = false;
        $dealer['has_panel'] = false;

        if ($inverter_id > 0) {
            $chk = $db->prepare("SELECT 1 FROM dealer_products WHERE dealer_id = ? AND product_type = 'inverter' AND product_id = ? AND is_active = 1 LIMIT 1");
            $chk->execute([$dealer['dealer_id'], $inverter_id]);
            $dealer['has_inverter'] = (bool)$chk->fetch();
        }
        if ($battery_id > 0) {
            $chk = $db->prepare("SELECT 1 FROM dealer_products WHERE dealer_id = ? AND product_type = 'battery' AND product_id = ? AND is_active = 1 LIMIT 1");
            $chk->execute([$dealer['dealer_id'], $battery_id]);
            $dealer['has_battery'] = (bool)$chk->fetch();
        }
        if ($panel_id > 0) {
            $chk = $db->prepare("SELECT 1 FROM dealer_products WHERE dealer_id = ? AND product_type = 'panel' AND product_id = ? AND is_active = 1 LIMIT 1");
            $chk->execute([$dealer['dealer_id'], $panel_id]);
            $dealer['has_panel'] = (bool)$chk->fetch();
        }

        // Remove raw lat/lng from response
        unset($dealer['latitude'], $dealer['longitude']);
    }
    unset($dealer);

    // Also find outside-radius results if within-radius is sparse (< 3 results)
    $outside_radius = [];
    if (count($dealers_within) < 3) {
        $sql_outside = "
            SELECT d.id AS dealer_id, d.business_name, d.city, d.country_code, d.phone,
                   {$haversine} AS distance_km
            FROM dealers d
            WHERE d.status = 'active'
              AND {$subscription_filter}
              AND d.latitude IS NOT NULL AND d.longitude IS NOT NULL
              AND {$product_where}
            HAVING distance_km > :radius AND distance_km <= :max_radius
            ORDER BY distance_km ASC
            LIMIT 5
        ";

        $stmt2 = $db->prepare($sql_outside);
        $stmt2->bindValue(':lat1', $lat);
        $stmt2->bindValue(':lng1', $lng);
        $stmt2->bindValue(':lat2', $lat);
        $stmt2->bindValue(':radius', $radius);
        $stmt2->bindValue(':max_radius', $radius * 5); // 5x wider search
        foreach ($product_params as $key => $val) {
            $stmt2->bindValue($key, $val, PDO::PARAM_INT);
        }
        $stmt2->execute();
        $outside_radius = $stmt2->fetchAll(PDO::FETCH_ASSOC);

        foreach ($outside_radius as &$d) {
            $d['distance_km'] = round(floatval($d['distance_km']), 1);
            unset($d['latitude'], $d['longitude']);
        }
        unset($d);
    }

    echo json_encode([
        'success' => true,
        'dealers' => $dealers_within,
        'outside_radius' => $outside_radius,
        'search' => [
            'radius_km' => $radius,
            'found_within' => count($dealers_within),
            'found_outside' => count($outside_radius),
        ]
    ]);

} catch (Exception $e) {
    error_log("find_nearest.php error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
