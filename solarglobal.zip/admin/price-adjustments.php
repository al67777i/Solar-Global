<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = getDB();
$pageTitle = 'Price Adjustments by Country';
$message = '';
$error = '';

// Fetch supported countries
$countries = $db->query("SELECT id, code, name, flag_emoji, flag_icon, currency_code, exchange_rate_to_usd FROM countries WHERE is_supported = 1 ORDER BY name ASC")->fetchAll();

// Handle save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid CSRF token.';
    } else {
        if ($_POST['action'] === 'save_adjustments') {
            $countryCode = $_POST['country_code'] ?? '';
            $adjustments = $_POST['adjustments'] ?? [];

            if (empty($countryCode)) {
                $error = 'Please select a country.';
            } else {
                $adminId = intval($_SESSION['admin_id'] ?? 0);
                $saved = 0;

                // Save exchange rate if provided
                $newRate = isset($_POST['exchange_rate']) ? floatval($_POST['exchange_rate']) : 0;
                if ($newRate > 0) {
                    $db->prepare("UPDATE countries SET exchange_rate_to_usd = ? WHERE code = ?")
                       ->execute([$newRate, $countryCode]);
                }

                foreach ($adjustments as $productType => $values) {
                    $markup = floatval($values['markup_percent'] ?? 0);
                    $tax = floatval($values['tax_percent'] ?? 0);
                    $shipping = floatval($values['shipping_flat_usd'] ?? 0);
                    $notes = trim($values['notes'] ?? '');

                    $stmt = $db->prepare("INSERT INTO country_price_adjustments (country_code, product_type, markup_percent, tax_percent, shipping_flat_usd, notes, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE markup_percent = ?, tax_percent = ?, shipping_flat_usd = ?, notes = ?, updated_by = ?");
                    $stmt->execute([$countryCode, $productType, $markup, $tax, $shipping, $notes, $adminId, $markup, $tax, $shipping, $notes, $adminId]);
                    $saved++;
                }

                $message = "Price adjustments saved for $countryCode ($saved categories updated).";
            }
        }
    }
}

// Load existing adjustments for selected country
$selectedCountry = $_GET['country'] ?? $_POST['country_code'] ?? '';
$existingAdjustments = [];
if ($selectedCountry) {
    $stmt = $db->prepare("SELECT * FROM country_price_adjustments WHERE country_code = ?");
    $stmt->execute([$selectedCountry]);
    foreach ($stmt->fetchAll() as $row) {
        $existingAdjustments[$row['product_type']] = $row;
    }
}

// Get product count stats
$stats = [];
try {
    $stats['inverters'] = $db->query("SELECT COUNT(*) FROM inverters WHERE is_active = 1")->fetchColumn();
    $stats['batteries'] = $db->query("SELECT COUNT(*) FROM batteries WHERE is_active = 1")->fetchColumn();
    $stats['panels'] = $db->query("SELECT COUNT(*) FROM panels WHERE is_active = 1")->fetchColumn();
    $stats['installation'] = $db->query("SELECT COUNT(*) FROM installation_appliances WHERE is_active = 1")->fetchColumn();
} catch (Exception $e) {}

// Get exchange rate for selected country
$exchangeRate = null;
$currencyCode = '';
if ($selectedCountry) {
    $stmt = $db->prepare("SELECT exchange_rate_to_usd, currency_code FROM countries WHERE code = ?");
    $stmt->execute([$selectedCountry]);
    $cInfo = $stmt->fetch();
    if ($cInfo) {
        $exchangeRate = floatval($cInfo['exchange_rate_to_usd']);
        $currencyCode = $cInfo['currency_code'] ?? '';
    }
}

include __DIR__ . '/includes/header.php';
?>

<style>
    .price-container { max-width: 1000px; margin: 0 auto; }
    .price-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 24px; }
    .price-card h3 { margin: 0 0 16px; font-size: 16px; color: #1f2937; }
    .country-selector { display: flex; gap: 12px; align-items: center; margin-bottom: 24px; }
    .country-selector select { flex: 1; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; }
    .country-selector .btn-load { background: #3b82f6; color: #fff; border: none; padding: 10px 20px; border-radius: 8px; font-weight: 600; cursor: pointer; }
    .country-selector .btn-load:hover { background: #2563eb; }

    .adjustment-grid { display: grid; grid-template-columns: 1fr; gap: 16px; }
    .adj-row { display: grid; grid-template-columns: 120px 1fr 1fr 1fr 1fr 2fr; gap: 12px; align-items: center; padding: 12px 16px; background: #f9fafb; border-radius: 8px; }
    .adj-row.header { background: #1f2937; color: #fff; font-weight: 600; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
    .adj-row label { font-weight: 600; font-size: 13px; color: #374151; }
    .adj-row input { width: 100%; padding: 8px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px; text-align: center; }
    .adj-row input:focus { outline: none; border-color: #f59e0b; box-shadow: 0 0 0 2px rgba(245,158,11,0.1); }
    .adj-row .notes-input { text-align: left; }

    .slider-group { display: flex; align-items: center; gap: 8px; }
    .slider-group input[type="range"] { flex: 1; accent-color: #f59e0b; }
    .slider-group .slider-val { min-width: 45px; text-align: center; font-weight: 600; font-size: 13px; color: #f59e0b; }

    .btn-save { background: #f59e0b; color: #fff; border: none; padding: 14px 32px; border-radius: 8px; font-weight: 700; font-size: 15px; cursor: pointer; margin-top: 16px; }
    .btn-save:hover { background: #d97706; }

    .price-example { background: #fffbeb; border: 1px solid #fcd34d; border-radius: 8px; padding: 16px; margin-top: 16px; font-size: 13px; }
    .price-example h4 { margin: 0 0 8px; color: #92400e; font-size: 14px; }
    .price-example .calc { font-family: monospace; color: #374151; }

    .stats-bar { display: flex; gap: 16px; margin-bottom: 16px; }
    .stat-chip { padding: 6px 12px; background: #f3f4f6; border-radius: 6px; font-size: 12px; color: #6b7280; }
    .stat-chip strong { color: #1f2937; }

    .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 14px; }
    .alert-success { background: #d1fae5; color: #065f46; border: 1px solid #6ee7b7; }
    .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }

    @media (max-width: 900px) {
        .adj-row { grid-template-columns: 1fr 1fr; gap: 8px; }
        .adj-row.header { display: none; }
    }
</style>

<div class="price-container">
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="price-card">
        <h3>Country Price Adjustment System</h3>
        <p style="font-size:13px;color:#6b7280;margin-bottom:16px;">
            All products are stored in <strong>USD</strong>. Use the sliders below to set country-specific markups, taxes, and shipping costs.
            The final price shown to users = <code>USD Price × (1 + Markup%) × (1 + Tax%) + Shipping</code>
        </p>

        <div class="stats-bar">
            <span class="stat-chip"><strong><?= $stats['panels'] ?? 0 ?></strong> Panels</span>
            <span class="stat-chip"><strong><?= $stats['inverters'] ?? 0 ?></strong> Inverters</span>
            <span class="stat-chip"><strong><?= $stats['batteries'] ?? 0 ?></strong> Batteries</span>
            <span class="stat-chip"><strong><?= $stats['installation'] ?? 0 ?></strong> Installation</span>
        </div>

        <!-- Country Selector -->
        <form method="GET" class="country-selector">
            <select name="country" id="country-select">
                <option value="">-- Select Country --</option>
                <?php foreach ($countries as $c): ?>
                    <option value="<?= htmlspecialchars($c['code']) ?>" <?= $selectedCountry === $c['code'] ? 'selected' : '' ?>>
                        <?= get_country_flag($c, 18) ?> <?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['code']) ?>) <?= $c['currency_code'] ? '— ' . $c['currency_code'] : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn-load">Load</button>
        </form>
    </div>

    <?php if ($selectedCountry): ?>
    <div class="price-card" style="background:#eff6ff;border:1px solid #bfdbfe;">
        <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
            <div><strong>Exchange Rate:</strong> 1 USD = </div>
            <div>
                <input type="number" name="exchange_rate" form="adjustments-form" step="0.01" min="0.01" max="999999"
                       value="<?= number_format($exchangeRate ?: 1, 2, '.', '') ?>"
                       style="width:120px; padding:6px 10px; border:2px solid #3b82f6; border-radius:6px; font-size:16px; font-weight:700; color:#1d4ed8; text-align:center;">
            </div>
            <div><strong><?= htmlspecialchars($currencyCode) ?></strong></div>
            <div style="font-size:12px;color:#6b7280;">Edit the rate above. Prices shown on the frontend use this rate for local currency conversion.</div>
        </div>
    </div>

    <form method="POST" id="adjustments-form">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_adjustments">
        <input type="hidden" name="country_code" value="<?= htmlspecialchars($selectedCountry) ?>">

        <div class="price-card">
            <h3>Adjustments for: <?= htmlspecialchars($selectedCountry) ?></h3>

            <div class="adjustment-grid">
                <div class="adj-row header">
                    <span>Category</span>
                    <span>Markup %</span>
                    <span>Tax %</span>
                    <span>Shipping (USD)</span>
                    <span>Preview</span>
                    <span>Notes</span>
                </div>

                <?php
                $categories = ['all' => 'All Products', 'inverter' => 'Inverters', 'battery' => 'Batteries', 'panel' => 'Panels', 'installation' => 'Installation'];
                foreach ($categories as $key => $label):
                    $adj = $existingAdjustments[$key] ?? ['markup_percent' => 0, 'tax_percent' => 0, 'shipping_flat_usd' => 0, 'notes' => ''];
                ?>
                <div class="adj-row" data-category="<?= $key ?>">
                    <label><?= $label ?></label>
                    <div class="slider-group">
                        <input type="range" name="adjustments[<?= $key ?>][markup_percent]" min="0" max="200" step="1" value="<?= floatval($adj['markup_percent']) ?>" class="markup-slider" oninput="updatePreview(this)">
                        <span class="slider-val"><?= floatval($adj['markup_percent']) ?>%</span>
                    </div>
                    <div class="slider-group">
                        <input type="range" name="adjustments[<?= $key ?>][tax_percent]" min="0" max="50" step="0.5" value="<?= floatval($adj['tax_percent']) ?>" class="tax-slider" oninput="updatePreview(this)">
                        <span class="slider-val"><?= floatval($adj['tax_percent']) ?>%</span>
                    </div>
                    <div>
                        <input type="number" name="adjustments[<?= $key ?>][shipping_flat_usd]" value="<?= floatval($adj['shipping_flat_usd']) ?>" min="0" step="0.01" placeholder="0.00" oninput="updatePreview(this)">
                    </div>
                    <div class="preview-price" style="font-size:12px;color:#059669;font-weight:600;">
                        $100 → $<span class="calc-result">100.00</span>
                    </div>
                    <div>
                        <input type="text" name="adjustments[<?= $key ?>][notes]" value="<?= htmlspecialchars($adj['notes'] ?? '') ?>" placeholder="Optional notes..." class="notes-input">
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="price-example">
                <h4>How pricing works:</h4>
                <div class="calc">
                    Base price (USD) = $1,000<br>
                    + Markup 30% = $1,000 × 1.30 = $1,300<br>
                    + Tax 17% = $1,300 × 1.17 = $1,521<br>
                    + Shipping $50 = <strong>$1,571 final</strong><br><br>
                    <em>"All Products" applies as base, category-specific adds on top if set.</em>
                </div>
            </div>

            <button type="submit" class="btn-save">Save Price Adjustments</button>
        </div>
    </form>
    <?php endif; ?>
</div>

<script>
function updatePreview(el) {
    const row = el.closest('.adj-row');
    const markup = parseFloat(row.querySelector('.markup-slider')?.value || 0);
    const tax = parseFloat(row.querySelector('.tax-slider')?.value || 0);
    const shipping = parseFloat(row.querySelector('input[type="number"]')?.value || 0);

    // Update slider value displays
    const sliderVals = row.querySelectorAll('.slider-val');
    if (sliderVals[0]) sliderVals[0].textContent = markup + '%';
    if (sliderVals[1]) sliderVals[1].textContent = tax + '%';

    // Calculate preview for $100 base
    const base = 100;
    const final = (base * (1 + markup/100) * (1 + tax/100)) + shipping;
    const calcResult = row.querySelector('.calc-result');
    if (calcResult) calcResult.textContent = final.toFixed(2);
}

// Init all previews on load
document.querySelectorAll('.adj-row:not(.header)').forEach(row => {
    const slider = row.querySelector('.markup-slider');
    if (slider) updatePreview(slider);
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
