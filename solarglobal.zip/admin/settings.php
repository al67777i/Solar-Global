<?php
/**
 * Admin Settings Page
 * Manage site settings, favicon, logo, and view analytics
 */
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once '../includes/csrf.php';

$success_message = '';
$error_message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid request. Please try again.';
    } elseif (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_site_info':
                $site_name = sanitize($_POST['site_name'] ?? '');
                $site_tagline = sanitize($_POST['site_tagline'] ?? '');
                $contact_email = sanitize($_POST['contact_email'] ?? '');
                $contact_phone = sanitize($_POST['contact_phone'] ?? '');
                $whatsapp_number = sanitize($_POST['whatsapp_number'] ?? '');
                
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_at)
                        VALUES
                            ('site_name', ?, NOW()),
                            ('site_tagline', ?, NOW()),
                            ('contact_email', ?, NOW()),
                            ('contact_phone', ?, NOW()),
                            ('whatsapp_number', ?, NOW())
                        ON DUPLICATE KEY UPDATE
                            setting_value = VALUES(setting_value),
                            updated_at = NOW()
                    ");
                    $stmt->execute([$site_name, $site_tagline, $contact_email, $contact_phone, $whatsapp_number]);
                    $success_message = 'Site information updated successfully!';
                } catch (Exception $e) {
                    $error_message = 'Error updating site information: ' . $e->getMessage();
                }
                break;
                
            case 'upload_favicon':
                if (isset($_FILES['favicon']) && $_FILES['favicon']['error'] === UPLOAD_ERR_OK) {
                    $result = handle_image_upload($_FILES['favicon'], '../uploads/site/');
                    if ($result['success']) {
                        try {
                            $stmt = $pdo->prepare("
                                INSERT INTO system_settings (setting_key, setting_value, updated_at)
                                VALUES ('favicon', ?, NOW())
                                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                            ");
                            $stmt->execute([$result['path']]);
                            $success_message = 'Favicon uploaded successfully!';
                        } catch (Exception $e) {
                            $error_message = 'Error saving favicon: ' . $e->getMessage();
                        }
                    } else {
                        $error_message = $result['error'];
                    }
                }
                break;
                
            case 'upload_logo':
                if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                    $result = handle_image_upload($_FILES['logo'], '../uploads/site/');
                    if ($result['success']) {
                        try {
                            $stmt = $pdo->prepare("
                                INSERT INTO system_settings (setting_key, setting_value, updated_at)
                                VALUES ('logo', ?, NOW())
                                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                            ");
                            $stmt->execute([$result['path']]);
                            $success_message = 'Logo uploaded successfully!';
                        } catch (Exception $e) {
                            $error_message = 'Error saving logo: ' . $e->getMessage();
                        }
                    } else {
                        $error_message = $result['error'];
                    }
                }
                break;

            case 'change_password':
                $current_password = $_POST['current_password'] ?? '';
                $new_password = $_POST['new_password'] ?? '';
                $confirm_password = $_POST['confirm_password'] ?? '';

                if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
                    $error_message = 'All password fields are required.';
                } elseif (strlen($new_password) < 8) {
                    $error_message = 'New password must be at least 8 characters long.';
                } elseif ($new_password !== $confirm_password) {
                    $error_message = 'New password and confirmation do not match.';
                } else {
                    try {
                        // Verify current password
                        $admin_id = $_SESSION['admin_id'] ?? 0;
                        $stmt = $pdo->prepare("SELECT password_hash FROM admin_users WHERE id = ?");
                        $stmt->execute([$admin_id]);
                        $admin = $stmt->fetch();

                        if (!$admin || !password_verify($current_password, $admin['password_hash'])) {
                            $error_message = 'Current password is incorrect.';
                        } else {
                            // Update password
                            $new_hash = password_hash($new_password, PASSWORD_BCRYPT);
                            $stmt = $pdo->prepare("UPDATE admin_users SET password_hash = ? WHERE id = ?");
                            $stmt->execute([$new_hash, $admin_id]);
                            $success_message = 'Password changed successfully!';
                        }
                    } catch (Exception $e) {
                        $error_message = 'Error changing password: ' . $e->getMessage();
                    }
                }
                break;

            case 'update_stripe':
                $stripe_fields = [
                    'stripe_mode', 'stripe_test_secret_key', 'stripe_test_publishable_key',
                    'stripe_live_secret_key', 'stripe_live_publishable_key', 'stripe_webhook_secret',
                    'dealer_monthly_fee', 'installer_monthly_fee', 'payment_currency'
                ];

                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_at)
                        VALUES (?, ?, NOW())
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                    ");

                    foreach ($stripe_fields as $field) {
                        $value = trim($_POST[$field] ?? '');
                        $stmt->execute([$field, $value]);
                    }
                    $success_message = 'Payment settings updated successfully!';
                } catch (Exception $e) {
                    $error_message = 'Error updating payment settings: ' . $e->getMessage();
                }
                break;

            case 'update_analytics':
                $ga_id = trim($_POST['google_analytics_id'] ?? '');
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_at)
                        VALUES ('google_analytics_id', ?, NOW())
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                    ");
                    $stmt->execute([$ga_id]);
                    $success_message = 'Google Analytics settings updated successfully!';
                } catch (Exception $e) {
                    $error_message = 'Error updating analytics settings: ' . $e->getMessage();
                }
                break;

            case 'update_recaptcha':
                $recaptcha_fields = ['recaptcha_site_key', 'recaptcha_secret_key'];
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_at)
                        VALUES (?, ?, NOW())
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                    ");
                    foreach ($recaptcha_fields as $field) {
                        $stmt->execute([$field, trim($_POST[$field] ?? '')]);
                    }
                    $success_message = 'reCAPTCHA settings updated successfully!';
                } catch (Exception $e) {
                    $error_message = 'Error updating reCAPTCHA settings: ' . $e->getMessage();
                }
                break;

            case 'update_google_oauth':
                $oauth_fields = ['google_oauth_client_id', 'google_maps_api_key'];
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_at)
                        VALUES (?, ?, NOW())
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                    ");
                    foreach ($oauth_fields as $field) {
                        $stmt->execute([$field, trim($_POST[$field] ?? '')]);
                    }
                    $success_message = 'Google API settings updated successfully!';
                } catch (Exception $e) {
                    $error_message = 'Error updating Google API settings: ' . $e->getMessage();
                }
                break;

            case 'update_retention':
                $retention_fields = [
                    'retention_plan_basic_months', 'retention_plan_basic_fee',
                    'retention_plan_standard_months', 'retention_plan_standard_fee',
                    'retention_plan_premium_months', 'retention_plan_premium_fee',
                    'retention_plan_enterprise_months', 'retention_plan_enterprise_fee',
                    'retention_order_history_months'
                ];
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_at)
                        VALUES (?, ?, NOW())
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                    ");
                    foreach ($retention_fields as $field) {
                        $stmt->execute([$field, trim($_POST[$field] ?? '0')]);
                    }
                    $success_message = 'Data retention plans updated successfully!';
                } catch (Exception $e) {
                    $error_message = 'Error updating retention plans: ' . $e->getMessage();
                }
                break;

            case 'update_cron_secret':
                try {
                    $token = trim($_POST['cron_secret_token'] ?? '');
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_at)
                        VALUES ('cron_secret_token', ?, NOW())
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                    ");
                    $stmt->execute([$token]);
                    $success_message = 'Cron secret token updated!';
                } catch (Exception $e) {
                    $error_message = 'Error saving cron token: ' . $e->getMessage();
                }
                break;

            case 'update_registration_security':
                $reg_fields = ['require_email_verification'];
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_at)
                        VALUES (?, ?, NOW())
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                    ");
                    foreach ($reg_fields as $field) {
                        $value = isset($_POST[$field]) ? '1' : '0';
                        $stmt->execute([$field, $value]);
                    }
                    $success_message = 'Registration security settings updated successfully!';
                } catch (Exception $e) {
                    $error_message = 'Error updating registration settings: ' . $e->getMessage();
                }
                break;

            case 'update_email_settings':
                $email_fields = [
                    'mail_driver'       => sanitize($_POST['mail_driver'] ?? 'php_mail'),
                    'smtp_host'         => sanitize($_POST['smtp_host'] ?? ''),
                    'smtp_port'         => intval($_POST['smtp_port'] ?? 587),
                    'smtp_encryption'   => sanitize($_POST['smtp_encryption'] ?? 'tls'),
                    'smtp_username'     => sanitize($_POST['smtp_username'] ?? ''),
                    'smtp_password'     => $_POST['smtp_password'] ?? '', // not sanitized — may have special chars
                    'mail_from_address' => sanitize($_POST['mail_from_address'] ?? ''),
                    'mail_from_name'    => sanitize($_POST['mail_from_name'] ?? ''),
                ];
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_at)
                        VALUES (?, ?, NOW())
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                    ");
                    foreach ($email_fields as $key => $value) {
                        $stmt->execute([$key, (string)$value]);
                    }
                    $success_message = 'Email settings saved successfully!';
                } catch (Exception $e) {
                    $error_message = 'Error saving email settings: ' . $e->getMessage();
                }
                break;

            case 'test_email':
                $test_to = sanitize($_POST['test_email_address'] ?? '');
                if (!filter_var($test_to, FILTER_VALIDATE_EMAIL)) {
                    $error_message = 'Please enter a valid email address for the test.';
                } else {
                    require_once '../includes/mailer.php';
                    $siteName = get_system_setting('site_name', 'SolarGlobal');
                    $result = sg_send_email(
                        $test_to,
                        "$siteName - Test Email",
                        "<p>This is a test email from <strong>$siteName</strong>.</p>
                         <p>If you received this, your email configuration is working correctly!</p>
                         <p style='color:#64748B;font-size:13px;margin-top:20px;'>Sent at: " . date('Y-m-d H:i:s T') . "</p>"
                    );
                    if ($result) {
                        $success_message = "Test email sent successfully to $test_to!";
                    } else {
                        $error_message = "Failed to send test email. Check your SMTP credentials and server settings. See PHP error log for details.";
                    }
                }
                break;

            case 'update_trial':
                $trial_fields = [
                    'dealer_free_trial_enabled', 'dealer_free_trial_days',
                    'installer_free_trial_enabled', 'installer_free_trial_days',
                    'subscription_grace_period_days'
                ];

                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO system_settings (setting_key, setting_value, updated_at)
                        VALUES (?, ?, NOW())
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                    ");

                    foreach ($trial_fields as $field) {
                        $value = trim($_POST[$field] ?? '0');
                        $stmt->execute([$field, $value]);
                    }
                    $success_message = 'Free trial settings updated successfully!';
                } catch (Exception $e) {
                    $error_message = 'Error updating trial settings: ' . $e->getMessage();
                }
                break;

            case 'change_username':
                $new_username = trim($_POST['new_username'] ?? '');
                $password_confirm = $_POST['password_for_username'] ?? '';

                if (empty($new_username) || empty($password_confirm)) {
                    $error_message = 'Username and password are required.';
                } elseif (strlen($new_username) < 3) {
                    $error_message = 'Username must be at least 3 characters.';
                } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $new_username)) {
                    $error_message = 'Username can only contain letters, numbers, and underscores.';
                } else {
                    try {
                        $admin_id = $_SESSION['admin_id'] ?? 0;
                        $stmt = $pdo->prepare("SELECT password_hash FROM admin_users WHERE id = ?");
                        $stmt->execute([$admin_id]);
                        $admin = $stmt->fetch();

                        if (!$admin || !password_verify($password_confirm, $admin['password_hash'])) {
                            $error_message = 'Password is incorrect.';
                        } else {
                            // Check if username already taken
                            $stmt = $pdo->prepare("SELECT id FROM admin_users WHERE username = ? AND id != ?");
                            $stmt->execute([$new_username, $admin_id]);
                            if ($stmt->fetch()) {
                                $error_message = 'That username is already taken.';
                            } else {
                                $stmt = $pdo->prepare("UPDATE admin_users SET username = ? WHERE id = ?");
                                $stmt->execute([$new_username, $admin_id]);
                                $_SESSION['admin_username'] = $new_username;
                                $success_message = 'Username changed to "' . htmlspecialchars($new_username) . '" successfully!';
                            }
                        }
                    } catch (Exception $e) {
                        $error_message = 'Error changing username: ' . $e->getMessage();
                    }
                }
                break;
        }
    }
}

// Get current settings
$settings = [];
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
} catch (Exception $e) {
    $error_message = 'Error loading settings: ' . $e->getMessage();
}

// Get visitor statistics
$stats = [
    'today' => getVisitorCount($pdo, 'today'),
    'week' => getVisitorCount($pdo, 'week'),
    'month' => getVisitorCount($pdo, 'month'),
    'all' => getVisitorCount($pdo, 'all')
];

// Get recent visitors
$recent_visitors = [];
try {
    $stmt = $pdo->query("
        SELECT ip_address, page_url, referer, location, visit_date
        FROM visitor_stats
        ORDER BY visit_date DESC
        LIMIT 20
    ");
    $recent_visitors = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Silently fail
}
$pageTitle = 'Site Settings';
?>
<?php include 'includes/header.php'; ?>
    <style>
        .settings-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .settings-card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }
        
        .settings-card h2 {
            font-size: 1.5rem;
            color: #0D3B6E;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            font-weight: 600;
            color: #0D3B6E;
            margin-bottom: 8px;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #E2E8F0;
            border-radius: 8px;
            font-size: 1rem;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #1565C0;
        }
        
        .image-preview {
            margin-top: 15px;
            padding: 20px;
            background: #F8FAFC;
            border-radius: 8px;
            text-align: center;
        }
        
        .image-preview img {
            max-width: 200px;
            max-height: 200px;
            border-radius: 8px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            text-align: center;
        }
        
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: 800;
            color: #0D3B6E;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 0.875rem;
            color: #64748B;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .visitors-table {
            width: 100%;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }
        
        .visitors-table table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .visitors-table th {
            background: #0D3B6E;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        
        .visitors-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #E2E8F0;
        }
        
        .visitors-table tr:hover {
            background: #F8FAFC;
        }
        
        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: #0D3B6E;
            color: white;
        }
        
        .btn-primary:hover {
            background: #1565C0;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #D1FAE5;
            color: #065F46;
            border: 2px solid #10B981;
        }
        
        .alert-error {
            background: #FEE2E2;
            color: #991B1B;
            border: 2px solid #EF4444;
        }
    </style>

        <h2 style="font-size: 1.5rem; color: #0D3B6E; margin-bottom: 10px;">Site Settings</h2>
        <p style="color: #64748B; margin-bottom: 20px;">Manage your site configuration, branding, and view analytics</p>

        <?php if ($success_message): ?>
            <div class="alert alert-success"><?php echo sanitize($success_message); ?></div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error"><?php echo sanitize($error_message); ?></div>
        <?php endif; ?>
        
        <!-- Visitor Statistics -->
        <h2 style="margin-bottom: 20px;">📊 Visitor Statistics</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📅</div>
                <div class="stat-value"><?php echo number_format($stats['today']); ?></div>
                <div class="stat-label">Today</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📆</div>
                <div class="stat-value"><?php echo number_format($stats['week']); ?></div>
                <div class="stat-label">This Week</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-value"><?php echo number_format($stats['month']); ?></div>
                <div class="stat-label">This Month</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🌍</div>
                <div class="stat-value"><?php echo number_format($stats['all']); ?></div>
                <div class="stat-label">All Time</div>
            </div>
        </div>
        
        <!-- Account Security -->
        <h2 style="margin-bottom: 20px;">🔐 Account Security</h2>
        <div class="settings-grid" style="margin-bottom: 40px;">
            <!-- Change Password -->
            <div class="settings-card" style="border-left: 4px solid #EF4444;">
                <h2>🔑 Change Password</h2>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="change_password">
                    <?= csrf_field() ?>

                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="current_password" required autocomplete="current-password" placeholder="Enter current password">
                    </div>

                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" required minlength="8" autocomplete="new-password" placeholder="Minimum 8 characters">
                    </div>

                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" required minlength="8" autocomplete="new-password" placeholder="Re-enter new password">
                    </div>

                    <button type="submit" class="btn btn-primary" style="background: #EF4444;" onmouseover="this.style.background='#DC2626'" onmouseout="this.style.background='#EF4444'">🔒 Change Password</button>
                </form>
            </div>

            <!-- Change Username -->
            <div class="settings-card" style="border-left: 4px solid #F59E0B;">
                <h2>👤 Change Username</h2>
                <p style="color: #64748B; margin-bottom: 15px;">Current: <strong><?= sanitize($_SESSION['admin_username'] ?? 'admin') ?></strong></p>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="change_username">
                    <?= csrf_field() ?>

                    <div class="form-group">
                        <label>New Username</label>
                        <input type="text" name="new_username" required minlength="3" pattern="[a-zA-Z0-9_]+" placeholder="Letters, numbers, underscores only">
                    </div>

                    <div class="form-group">
                        <label>Confirm with Password</label>
                        <input type="password" name="password_for_username" required placeholder="Enter your password to confirm">
                    </div>

                    <button type="submit" class="btn btn-primary" style="background: #F59E0B;" onmouseover="this.style.background='#D97706'" onmouseout="this.style.background='#F59E0B'">👤 Change Username</button>
                </form>
            </div>
        </div>

        <!-- Settings Forms -->
        <h2 style="margin-bottom: 20px;">⚙️ Site Configuration</h2>
        <div class="settings-grid">
            <!-- Site Information -->
            <div class="settings-card">
                <h2>🏢 Site Information</h2>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_site_info">
                    <?= csrf_field() ?>

                    <div class="form-group">
                        <label>Site Name</label>
                        <input type="text" name="site_name" value="<?php echo sanitize($settings['site_name'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label>Site Tagline</label>
                        <input type="text" name="site_tagline" value="<?php echo sanitize($settings['site_tagline'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label>Contact Email</label>
                        <input type="email" name="contact_email" value="<?php echo sanitize($settings['contact_email'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label>Contact Phone</label>
                        <input type="text" name="contact_phone" value="<?php echo sanitize($settings['contact_phone'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label>WhatsApp Number</label>
                        <input type="text" name="whatsapp_number" value="<?php echo sanitize($settings['whatsapp_number'] ?? ''); ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>
            
            <!-- Favicon Upload -->
            <div class="settings-card">
                <h2>🎨 Favicon</h2>
                <form method="POST" action="" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="upload_favicon">
                    <?= csrf_field() ?>

                    <div class="form-group">
                        <label>Upload Favicon (32x32 or 64x64 PNG/ICO)</label>
                        <input type="file" name="favicon" accept="image/png,image/x-icon">
                    </div>

                    <?php if (isset($settings['favicon'])): ?>
                        <div class="image-preview">
                            <p><strong>Current Favicon:</strong></p>
                            <img src="../<?php echo sanitize($settings['favicon'] ?? ''); ?>" alt="Favicon">
                        </div>
                    <?php endif; ?>
                    
                    <button type="submit" class="btn btn-primary">Upload Favicon</button>
                </form>
            </div>
            
            <!-- Logo Upload -->
            <div class="settings-card">
                <h2>🖼️ Logo</h2>
                <form method="POST" action="" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="upload_logo">
                    <?= csrf_field() ?>

                    <div class="form-group">
                        <label>Upload Logo (PNG with transparent background recommended)</label>
                        <input type="file" name="logo" accept="image/png,image/jpeg,image/webp">
                    </div>

                    <?php if (isset($settings['logo'])): ?>
                        <div class="image-preview">
                            <p><strong>Current Logo:</strong></p>
                            <img src="../<?php echo sanitize($settings['logo'] ?? ''); ?>" alt="Logo">
                        </div>
                    <?php endif; ?>
                    
                    <button type="submit" class="btn btn-primary">Upload Logo</button>
                </form>
            </div>
        </div>
        
        <!-- Google Analytics -->
        <h2 style="margin-bottom: 20px;">📊 Google Analytics</h2>
        <div class="settings-grid" style="margin-bottom: 40px;">
            <div class="settings-card" style="border-left: 4px solid #4285F4; grid-column: 1 / -1;">
                <h2>📊 Analytics Tracking</h2>
                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_analytics">
                    <div class="settings-field">
                        <label>Google Analytics Measurement ID</label>
                        <input type="text" name="google_analytics_id" value="<?= sanitize($settings['google_analytics_id'] ?? '') ?>" placeholder="G-XXXXXXXXXX">
                        <small style="color: #64748B; display: block; margin-top: 4px;">Enter your GA4 Measurement ID (e.g. G-ABC123XYZ). Leave blank to disable tracking.</small>
                    </div>
                    <button type="submit" class="btn btn-primary" style="background: #4285F4; margin-top: 12px;" onmouseover="this.style.background='#3367D6'" onmouseout="this.style.background='#4285F4'">📊 Save Analytics Settings</button>
                </form>
            </div>
        </div>

        <!-- reCAPTCHA Settings -->
        <h2 style="margin-bottom: 20px;">🛡️ reCAPTCHA v3 (Bot Protection)</h2>
        <div class="settings-grid" style="margin-bottom: 40px;">
            <div class="settings-card" style="border-left: 4px solid #4CAF50; grid-column: 1 / -1;">
                <h2>🛡️ Google reCAPTCHA v3</h2>
                <p style="color: #64748B; font-size: 0.875rem; margin-bottom: 16px;">
                    Protects login and registration forms from bots. Get keys from <a href="https://www.google.com/recaptcha/admin" target="_blank" style="color: #4CAF50;">Google reCAPTCHA Admin</a>. Select reCAPTCHA v3. Leave blank to disable.
                </p>
                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_recaptcha">
                    <div class="form-group">
                        <label>reCAPTCHA Site Key (Public)</label>
                        <input type="text" name="recaptcha_site_key" value="<?= sanitize($settings['recaptcha_site_key'] ?? '') ?>" placeholder="6Lc...">
                        <small style="color: #64748B; display: block; margin-top: 4px;">Used in the frontend to render the invisible reCAPTCHA badge.</small>
                    </div>
                    <div class="form-group">
                        <label>reCAPTCHA Secret Key (Private)</label>
                        <input type="password" name="recaptcha_secret_key" value="<?= sanitize($settings['recaptcha_secret_key'] ?? '') ?>" placeholder="6Lc...">
                        <small style="color: #64748B; display: block; margin-top: 4px;">Used server-side to verify tokens. Never expose this key publicly.</small>
                    </div>
                    <button type="submit" class="btn btn-primary" style="background: #4CAF50; margin-top: 12px;" onmouseover="this.style.background='#43A047'" onmouseout="this.style.background='#4CAF50'">🛡️ Save reCAPTCHA Settings</button>
                </form>
            </div>
        </div>

        <!-- Registration Security -->
        <h2 style="margin-bottom: 20px;">📧 Registration Security</h2>
        <div class="settings-grid" style="margin-bottom: 40px;">
            <div class="settings-card" style="border-left: 4px solid #8B5CF6; grid-column: 1 / -1;">
                <h2>📧 Email Verification</h2>
                <p style="color: #64748B; font-size: 0.875rem; margin-bottom: 16px;">
                    When enabled, all new registrations (dealer, installer, customer) must verify their email address with a 6-digit code before their account is activated.
                </p>
                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_registration_security">

                    <div class="form-group">
                        <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
                            <input type="checkbox" name="require_email_verification" value="1" <?= ($settings['require_email_verification'] ?? '0') === '1' ? 'checked' : '' ?> style="width: 20px; height: 20px; accent-color: #8B5CF6;">
                            <span>Require Email Verification for New Accounts</span>
                        </label>
                        <small style="color: #64748B; display: block; margin-top: 8px; margin-left: 32px;">
                            When enabled: users receive a 6-digit code via email that expires in 15 minutes. They must enter this code to activate their account.<br>
                            When disabled: accounts are activated immediately upon registration without email verification.
                        </small>
                    </div>

                    <button type="submit" class="btn btn-primary" style="background: #8B5CF6;" onmouseover="this.style.background='#7C3AED'" onmouseout="this.style.background='#8B5CF6'">📧 Save Registration Settings</button>
                </form>
            </div>
        </div>

        <!-- Email / SMTP Configuration -->
        <h2 style="margin-bottom: 20px;">📨 Email Configuration</h2>
        <div class="settings-grid" style="margin-bottom: 40px;">
            <div class="settings-card" style="border-left: 4px solid #0EA5E9; grid-column: 1 / -1;">
                <h2>📨 Mail Server Settings</h2>
                <p style="color: #64748B; font-size: 0.875rem; margin-bottom: 16px;">
                    Configure how the system sends emails (verification codes, password resets, notifications). Choose PHP Mail for basic sending or SMTP for reliable delivery.
                </p>
                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_email_settings">

                    <div class="form-group">
                        <label>Mail Driver</label>
                        <select name="mail_driver" id="mail_driver" onchange="toggleSmtpFields()" style="padding: 10px 14px; border: 1px solid #CBD5E1; border-radius: 8px; font-size: 0.9rem; width: 100%;">
                            <option value="php_mail" <?= ($settings['mail_driver'] ?? 'php_mail') === 'php_mail' ? 'selected' : '' ?>>PHP mail() — Basic (no authentication)</option>
                            <option value="smtp" <?= ($settings['mail_driver'] ?? '') === 'smtp' ? 'selected' : '' ?>>SMTP — Recommended for production</option>
                        </select>
                        <small style="color: #64748B; display: block; margin-top: 4px;">SMTP is recommended for reliable email delivery. Most shared hosting and cloud servers block PHP mail().</small>
                    </div>

                    <div id="smtp-fields" style="display: <?= ($settings['mail_driver'] ?? 'php_mail') === 'smtp' ? 'block' : 'none' ?>; border: 1px solid #E2E8F0; border-radius: 8px; padding: 20px; margin-bottom: 16px; background: #F8FAFC;">
                        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 16px;">
                            <div class="form-group" style="margin-bottom: 12px;">
                                <label>SMTP Host</label>
                                <input type="text" name="smtp_host" value="<?= sanitize($settings['smtp_host'] ?? '') ?>" placeholder="smtp.gmail.com / smtp.mailgun.org / mail.yourdomain.com">
                                <small style="color: #64748B;">Gmail: smtp.gmail.com | Outlook: smtp-mail.outlook.com | Mailgun: smtp.mailgun.org</small>
                            </div>
                            <div class="form-group" style="margin-bottom: 12px;">
                                <label>SMTP Port</label>
                                <input type="number" name="smtp_port" value="<?= sanitize($settings['smtp_port'] ?? '587') ?>" placeholder="587">
                                <small style="color: #64748B;">587 (TLS) or 465 (SSL)</small>
                            </div>
                        </div>
                        <div class="form-group" style="margin-bottom: 12px;">
                            <label>Encryption</label>
                            <select name="smtp_encryption" style="padding: 10px 14px; border: 1px solid #CBD5E1; border-radius: 8px; font-size: 0.9rem; width: 100%;">
                                <option value="tls" <?= ($settings['smtp_encryption'] ?? 'tls') === 'tls' ? 'selected' : '' ?>>TLS (Recommended — Port 587)</option>
                                <option value="ssl" <?= ($settings['smtp_encryption'] ?? '') === 'ssl' ? 'selected' : '' ?>>SSL (Port 465)</option>
                                <option value="none" <?= ($settings['smtp_encryption'] ?? '') === 'none' ? 'selected' : '' ?>>None (Not recommended)</option>
                            </select>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                            <div class="form-group" style="margin-bottom: 12px;">
                                <label>SMTP Username</label>
                                <input type="text" name="smtp_username" value="<?= sanitize($settings['smtp_username'] ?? '') ?>" placeholder="your-email@gmail.com" autocomplete="off">
                                <small style="color: #64748B;">Usually your full email address</small>
                            </div>
                            <div class="form-group" style="margin-bottom: 12px;">
                                <label>SMTP Password</label>
                                <input type="password" name="smtp_password" value="<?= sanitize($settings['smtp_password'] ?? '') ?>" placeholder="••••••••" autocomplete="new-password">
                                <small style="color: #64748B;">For Gmail: use an <a href="https://myaccount.google.com/apppasswords" target="_blank" style="color:#0EA5E9;">App Password</a>, not your regular password</small>
                            </div>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        <div class="form-group">
                            <label>From Email Address</label>
                            <input type="email" name="mail_from_address" value="<?= sanitize($settings['mail_from_address'] ?? '') ?>" placeholder="noreply@yourdomain.com">
                            <small style="color: #64748B;">The "From" address on all outgoing emails</small>
                        </div>
                        <div class="form-group">
                            <label>From Name</label>
                            <input type="text" name="mail_from_name" value="<?= sanitize($settings['mail_from_name'] ?? '') ?>" placeholder="<?= sanitize($settings['site_name'] ?? 'SolarGlobal') ?>">
                            <small style="color: #64748B;">Display name shown in the recipient's inbox</small>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="background: #0EA5E9;" onmouseover="this.style.background='#0284C7'" onmouseout="this.style.background='#0EA5E9'">📨 Save Email Settings</button>
                </form>

                <!-- Test Email -->
                <div style="margin-top: 24px; padding-top: 20px; border-top: 1px solid #E2E8F0;">
                    <h3 style="font-size: 0.95rem; margin: 0 0 12px; color: #334155;">🧪 Send Test Email</h3>
                    <form method="POST" style="display: flex; gap: 12px; align-items: flex-end; flex-wrap: wrap;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="test_email">
                        <div class="form-group" style="flex: 1; min-width: 250px; margin-bottom: 0;">
                            <input type="email" name="test_email_address" placeholder="recipient@example.com" required style="padding: 10px 14px; border: 1px solid #CBD5E1; border-radius: 8px; font-size: 0.9rem; width: 100%;">
                        </div>
                        <button type="submit" class="btn btn-primary" style="background: #10B981; white-space: nowrap;" onmouseover="this.style.background='#059669'" onmouseout="this.style.background='#10B981'">🧪 Send Test</button>
                    </form>
                </div>
            </div>
        </div>

        <script>
        function toggleSmtpFields() {
            var driver = document.getElementById('mail_driver').value;
            document.getElementById('smtp-fields').style.display = driver === 'smtp' ? 'block' : 'none';
        }
        </script>

        <!-- Google API Keys -->
        <h2 style="margin-bottom: 20px;">🔑 Google API Keys</h2>
        <div class="settings-grid" style="margin-bottom: 40px;">
            <div class="settings-card" style="border-left: 4px solid #EA4335; grid-column: 1 / -1;">
                <h2>🔑 Google OAuth & Maps</h2>
                <p style="color: #64748B; font-size: 0.875rem; margin-bottom: 16px;">
                    Configure Google OAuth for customer login and Google Maps API for the dealer/installer finder.
                </p>
                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_google_oauth">
                    <div class="form-group">
                        <label>Google OAuth Client ID</label>
                        <input type="text" name="google_oauth_client_id" value="<?= sanitize($settings['google_oauth_client_id'] ?? '') ?>" placeholder="123456789-xxxxx.apps.googleusercontent.com">
                        <small style="color: #64748B; display: block; margin-top: 4px;">From Google Cloud Console &rarr; APIs &amp; Services &rarr; Credentials. Used for customer Google Sign-In.</small>
                    </div>
                    <div class="form-group">
                        <label>Google Maps API Key</label>
                        <input type="text" name="google_maps_api_key" value="<?= sanitize($settings['google_maps_api_key'] ?? '') ?>" placeholder="AIzaSy...">
                        <small style="color: #64748B; display: block; margin-top: 4px;">Enable Maps JavaScript API + Places API + Geocoding API in Google Cloud Console.</small>
                    </div>
                    <button type="submit" class="btn btn-primary" style="background: #EA4335;" onmouseover="this.style.background='#D93025'" onmouseout="this.style.background='#EA4335'">🔑 Save Google API Settings</button>
                </form>
            </div>
        </div>

        <!-- Payment Settings -->
        <h2 style="margin-bottom: 20px;">💳 Payment Settings</h2>
        <div class="settings-grid" style="margin-bottom: 40px;">
            <div class="settings-card" style="border-left: 4px solid #16A34A; grid-column: 1 / -1;">
                <h2>💳 Stripe Configuration</h2>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_stripe">
                    <?= csrf_field() ?>

                    <div class="form-group">
                        <label>Stripe Mode</label>
                        <div style="display: flex; gap: 20px; margin-top: 5px;">
                            <label style="display: flex; align-items: center; gap: 8px; font-weight: 400; cursor: pointer;">
                                <input type="radio" name="stripe_mode" value="test" <?= ($settings['stripe_mode'] ?? 'test') === 'test' ? 'checked' : '' ?>>
                                <span style="background: #FEF3C7; color: #92400E; padding: 4px 12px; border-radius: 4px; font-size: 0.875rem; font-weight: 600;">TEST</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 8px; font-weight: 400; cursor: pointer;">
                                <input type="radio" name="stripe_mode" value="live" <?= ($settings['stripe_mode'] ?? 'test') === 'live' ? 'checked' : '' ?>>
                                <span style="background: #DCFCE7; color: #166534; padding: 4px 12px; border-radius: 4px; font-size: 0.875rem; font-weight: 600;">LIVE</span>
                            </label>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div>
                            <h3 style="color: #92400E; margin-bottom: 15px; font-size: 0.95rem;">Test Keys</h3>
                            <div class="form-group">
                                <label>Test Secret Key</label>
                                <input type="password" name="stripe_test_secret_key" value="<?= sanitize($settings['stripe_test_secret_key'] ?? '') ?>" placeholder="sk_test_...">
                            </div>
                            <div class="form-group">
                                <label>Test Publishable Key</label>
                                <input type="text" name="stripe_test_publishable_key" value="<?= sanitize($settings['stripe_test_publishable_key'] ?? '') ?>" placeholder="pk_test_...">
                            </div>
                        </div>
                        <div>
                            <h3 style="color: #166534; margin-bottom: 15px; font-size: 0.95rem;">Live Keys</h3>
                            <div class="form-group">
                                <label>Live Secret Key</label>
                                <input type="password" name="stripe_live_secret_key" value="<?= sanitize($settings['stripe_live_secret_key'] ?? '') ?>" placeholder="sk_live_...">
                            </div>
                            <div class="form-group">
                                <label>Live Publishable Key</label>
                                <input type="text" name="stripe_live_publishable_key" value="<?= sanitize($settings['stripe_live_publishable_key'] ?? '') ?>" placeholder="pk_live_...">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Webhook Secret</label>
                        <input type="password" name="stripe_webhook_secret" value="<?= sanitize($settings['stripe_webhook_secret'] ?? '') ?>" placeholder="whsec_...">
                        <small style="color: #64748B; display: block; margin-top: 4px;">Webhook URL: <?= (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'yourdomain.com') ?>/solarglobal/api/stripe_webhook.php</small>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label>Dealer Monthly Fee ($)</label>
                            <input type="number" name="dealer_monthly_fee" step="0.01" min="0" value="<?= sanitize($settings['dealer_monthly_fee'] ?? '1.00') ?>" placeholder="1.00">
                        </div>
                        <div class="form-group">
                            <label>Installer Monthly Fee ($)</label>
                            <input type="number" name="installer_monthly_fee" step="0.01" min="0" value="<?= sanitize($settings['installer_monthly_fee'] ?? '0.00') ?>" placeholder="0.00 = Free">
                            <small style="color: #64748B; display: block; margin-top: 4px;">Set to 0 for free installer access</small>
                        </div>
                        <div class="form-group">
                            <label>Currency</label>
                            <input type="text" name="payment_currency" value="<?= sanitize($settings['payment_currency'] ?? 'usd') ?>" placeholder="usd" maxlength="3" style="text-transform: lowercase;">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="background: #16A34A;" onmouseover="this.style.background='#15803D'" onmouseout="this.style.background='#16A34A'">💳 Save Payment Settings</button>
                </form>
            </div>
        </div>

        <!-- Free Trial Settings -->
        <div class="settings-grid" style="margin-bottom: 40px;">
            <div class="settings-card" style="border-left: 4px solid #8B5CF6; grid-column: 1 / -1;">
                <h2>🎁 Free Trial Settings</h2>
                <p style="color: #64748B; font-size: 0.875rem; margin-bottom: 20px;">
                    When enabled, new dealers/installers get a free trial period without needing to pay. After the trial expires, they must subscribe to keep their store active.
                    <strong>By default, free trial is OFF</strong> — dealers must pay immediately to activate their store.
                </p>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_trial">
                    <?= csrf_field() ?>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div style="background: #F5F3FF; padding: 20px; border-radius: 12px;">
                            <h3 style="margin-bottom: 12px; font-size: 0.95rem; color: #6D28D9;">Dealer Free Trial</h3>
                            <div class="form-group">
                                <label>Enable Free Trial for Dealers</label>
                                <div style="display: flex; gap: 16px; margin-top: 5px;">
                                    <label style="display: flex; align-items: center; gap: 6px; font-weight: 400; cursor: pointer;">
                                        <input type="radio" name="dealer_free_trial_enabled" value="1" <?= ($settings['dealer_free_trial_enabled'] ?? '0') === '1' ? 'checked' : '' ?>>
                                        <span style="background: #DCFCE7; color: #166534; padding: 3px 10px; border-radius: 4px; font-size: 0.8rem; font-weight: 600;">ON</span>
                                    </label>
                                    <label style="display: flex; align-items: center; gap: 6px; font-weight: 400; cursor: pointer;">
                                        <input type="radio" name="dealer_free_trial_enabled" value="0" <?= ($settings['dealer_free_trial_enabled'] ?? '0') === '0' ? 'checked' : '' ?>>
                                        <span style="background: #FEE2E2; color: #991B1B; padding: 3px 10px; border-radius: 4px; font-size: 0.8rem; font-weight: 600;">OFF</span>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Trial Duration (days)</label>
                                <input type="number" name="dealer_free_trial_days" min="1" max="365" value="<?= sanitize($settings['dealer_free_trial_days'] ?? '30') ?>">
                            </div>
                        </div>
                        <div style="background: #F0FDF4; padding: 20px; border-radius: 12px;">
                            <h3 style="margin-bottom: 12px; font-size: 0.95rem; color: #15803D;">Installer Free Trial</h3>
                            <div class="form-group">
                                <label>Enable Free Trial for Installers</label>
                                <div style="display: flex; gap: 16px; margin-top: 5px;">
                                    <label style="display: flex; align-items: center; gap: 6px; font-weight: 400; cursor: pointer;">
                                        <input type="radio" name="installer_free_trial_enabled" value="1" <?= ($settings['installer_free_trial_enabled'] ?? '0') === '1' ? 'checked' : '' ?>>
                                        <span style="background: #DCFCE7; color: #166534; padding: 3px 10px; border-radius: 4px; font-size: 0.8rem; font-weight: 600;">ON</span>
                                    </label>
                                    <label style="display: flex; align-items: center; gap: 6px; font-weight: 400; cursor: pointer;">
                                        <input type="radio" name="installer_free_trial_enabled" value="0" <?= ($settings['installer_free_trial_enabled'] ?? '0') === '0' ? 'checked' : '' ?>>
                                        <span style="background: #FEE2E2; color: #991B1B; padding: 3px 10px; border-radius: 4px; font-size: 0.8rem; font-weight: 600;">OFF</span>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Trial Duration (days)</label>
                                <input type="number" name="installer_free_trial_days" min="1" max="365" value="<?= sanitize($settings['installer_free_trial_days'] ?? '30') ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Grace Period Setting -->
                    <div style="background: #FFF7ED; padding: 20px; border-radius: 12px; margin-top: 20px; border: 1px solid #FDBA74;">
                        <h3 style="margin-bottom: 12px; font-size: 0.95rem; color: #C2410C;">&#9888; Subscription Grace Period</h3>
                        <p style="font-size: 0.8125rem; color: #9A3412; margin-bottom: 12px;">
                            After a subscription expires, the store stays visible for this many days before being hidden from customers.
                        </p>
                        <div class="form-group" style="margin-bottom: 0;">
                            <label>Grace Period (days)</label>
                            <input type="number" name="subscription_grace_period_days" min="0" max="30" value="<?= sanitize($settings['subscription_grace_period_days'] ?? '5') ?>" style="max-width: 120px;">
                        </div>
                    </div>

                    <div style="background: #FFFBEB; border: 1px solid #FDE68A; padding: 12px 16px; border-radius: 8px; margin: 16px 0; font-size: 0.8125rem; color: #92400E;">
                        <strong>How it works:</strong> When free trial is ON, new registrations automatically get an active store for the trial period.
                        When OFF, dealers must complete Stripe payment immediately — their store won't appear in recommendations until they pay.
                        Existing dealers are not affected by changing this setting. After a subscription expires, the grace period gives dealers/installers
                        time to renew before their store is hidden from customers.
                    </div>

                    <button type="submit" class="btn btn-primary" style="background: #8B5CF6;" onmouseover="this.style.background='#7C3AED'" onmouseout="this.style.background='#8B5CF6'">🎁 Save Trial Settings</button>
                </form>
            </div>
        </div>

        <!-- Data Retention Plans -->
        <h2 style="margin-bottom: 20px;">&#128451; Data Retention Plans</h2>
        <div class="settings-card" style="margin-bottom: 30px;">
            <div class="card-body">
                <h2>&#128451; Backup & Data Retention</h2>
                <p style="color: #64748B; margin-bottom: 16px;">Configure how long invoices, order history, and records are retained for dealers/installers. Each tier has a monthly add-on fee.</p>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                    <input type="hidden" name="action" value="update_retention">

                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 16px; margin-bottom: 20px;">
                        <!-- Basic -->
                        <div style="padding: 16px; border-radius: 10px; border: 1px solid #E2E8F0; background: #F8FAFC;">
                            <h4 style="color: #0F172A; margin-bottom: 8px;">Basic (Included)</h4>
                            <div style="margin-bottom: 8px;">
                                <label style="font-size: 0.82rem; color: #64748B;">Duration (months)</label><br>
                                <input type="number" name="retention_plan_basic_months" min="1" max="12" value="<?= sanitize($settings['retention_plan_basic_months'] ?? '6') ?>" style="width: 100px; padding: 6px; border: 1px solid #E2E8F0; border-radius: 6px;">
                            </div>
                            <div>
                                <label style="font-size: 0.82rem; color: #64748B;">Add-on Fee ($/mo)</label><br>
                                <input type="number" name="retention_plan_basic_fee" min="0" step="0.01" value="<?= sanitize($settings['retention_plan_basic_fee'] ?? '0.00') ?>" style="width: 100px; padding: 6px; border: 1px solid #E2E8F0; border-radius: 6px;">
                            </div>
                        </div>
                        <!-- Standard -->
                        <div style="padding: 16px; border-radius: 10px; border: 1px solid #BFDBFE; background: #EFF6FF;">
                            <h4 style="color: #1D4ED8; margin-bottom: 8px;">Standard</h4>
                            <div style="margin-bottom: 8px;">
                                <label style="font-size: 0.82rem; color: #64748B;">Duration (months)</label><br>
                                <input type="number" name="retention_plan_standard_months" min="1" max="60" value="<?= sanitize($settings['retention_plan_standard_months'] ?? '24') ?>" style="width: 100px; padding: 6px; border: 1px solid #BFDBFE; border-radius: 6px;">
                            </div>
                            <div>
                                <label style="font-size: 0.82rem; color: #64748B;">Add-on Fee ($/mo)</label><br>
                                <input type="number" name="retention_plan_standard_fee" min="0" step="0.01" value="<?= sanitize($settings['retention_plan_standard_fee'] ?? '2.00') ?>" style="width: 100px; padding: 6px; border: 1px solid #BFDBFE; border-radius: 6px;">
                            </div>
                        </div>
                        <!-- Premium -->
                        <div style="padding: 16px; border-radius: 10px; border: 1px solid #FDE68A; background: #FFFBEB;">
                            <h4 style="color: #92400E; margin-bottom: 8px;">Premium (5 Years)</h4>
                            <div style="margin-bottom: 8px;">
                                <label style="font-size: 0.82rem; color: #64748B;">Duration (months)</label><br>
                                <input type="number" name="retention_plan_premium_months" min="1" max="120" value="<?= sanitize($settings['retention_plan_premium_months'] ?? '60') ?>" style="width: 100px; padding: 6px; border: 1px solid #FDE68A; border-radius: 6px;">
                            </div>
                            <div>
                                <label style="font-size: 0.82rem; color: #64748B;">Add-on Fee ($/mo)</label><br>
                                <input type="number" name="retention_plan_premium_fee" min="0" step="0.01" value="<?= sanitize($settings['retention_plan_premium_fee'] ?? '5.00') ?>" style="width: 100px; padding: 6px; border: 1px solid #FDE68A; border-radius: 6px;">
                            </div>
                        </div>
                        <!-- Enterprise -->
                        <div style="padding: 16px; border-radius: 10px; border: 1px solid #C4B5FD; background: #F5F3FF;">
                            <h4 style="color: #5B21B6; margin-bottom: 8px;">Enterprise (10 Years)</h4>
                            <div style="margin-bottom: 8px;">
                                <label style="font-size: 0.82rem; color: #64748B;">Duration (months)</label><br>
                                <input type="number" name="retention_plan_enterprise_months" min="1" max="240" value="<?= sanitize($settings['retention_plan_enterprise_months'] ?? '120') ?>" style="width: 100px; padding: 6px; border: 1px solid #C4B5FD; border-radius: 6px;">
                            </div>
                            <div>
                                <label style="font-size: 0.82rem; color: #64748B;">Add-on Fee ($/mo)</label><br>
                                <input type="number" name="retention_plan_enterprise_fee" min="0" step="0.01" value="<?= sanitize($settings['retention_plan_enterprise_fee'] ?? '10.00') ?>" style="width: 100px; padding: 6px; border: 1px solid #C4B5FD; border-radius: 6px;">
                            </div>
                        </div>
                    </div>

                    <div style="margin-bottom: 16px;">
                        <label style="font-weight: 600; color: #0F172A;">Order History Max Retention (months)</label><br>
                        <input type="number" name="retention_order_history_months" min="6" max="240" value="<?= sanitize($settings['retention_order_history_months'] ?? '120') ?>" style="width: 120px; padding: 6px; border: 1px solid #E2E8F0; border-radius: 6px; margin-top: 4px;">
                        <small style="color: #64748B; display: block; margin-top: 4px;">Maximum months to keep order/invoice records before auto-purge.</small>
                    </div>

                    <button type="submit" class="btn btn-primary" style="background: #7C3AED;" onmouseover="this.style.background='#6D28D9'" onmouseout="this.style.background='#7C3AED'">&#128451; Save Retention Plans</button>
                </form>

                <hr style="margin: 24px 0; border: none; border-top: 1px solid #E2E8F0;">

                <h4 style="color: #0F172A; margin-bottom: 8px;">&#128274; Cron Job Security</h4>
                <p style="color: #64748B; font-size: 0.82rem; margin-bottom: 12px;">
                    Secret token required for HTTP-triggered cron jobs. Set this in your cron URL:
                    <code style="background: #F1F5F9; padding: 2px 6px; border-radius: 4px; font-size: 0.78rem;">
                        /api/cron_subscription_check.php?token=YOUR_TOKEN
                    </code>
                </p>
                <form method="POST" style="display: flex; gap: 10px; align-items: end;">
                    <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                    <input type="hidden" name="action" value="update_cron_secret">
                    <div>
                        <label style="font-size: 0.82rem; color: #64748B;">Cron Secret Token</label><br>
                        <input type="text" name="cron_secret_token" value="<?= sanitize($settings['cron_secret_token'] ?? '') ?>"
                               placeholder="Generate or enter a secret token"
                               style="width: 320px; padding: 6px 10px; border: 1px solid #E2E8F0; border-radius: 6px; font-family: monospace; font-size: 0.85rem;">
                    </div>
                    <button type="button" onclick="this.previousElementSibling.querySelector('input[name=cron_secret_token]').value = crypto.randomUUID().replace(/-/g,'')"
                            style="padding: 6px 14px; background: #F1F5F9; border: 1px solid #E2E8F0; border-radius: 6px; cursor: pointer; font-size: 0.82rem; white-space: nowrap;">
                        &#127922; Generate
                    </button>
                    <button type="submit" class="btn btn-primary" style="background: #334155; font-size: 0.85rem; padding: 6px 16px;"
                            onmouseover="this.style.background='#1E293B'" onmouseout="this.style.background='#334155'">Save</button>
                </form>
            </div>
        </div>

        <!-- Recent Visitors -->
        <?php if (!empty($recent_visitors)): ?>
            <h2 style="margin-bottom: 20px;">👥 Recent Visitors</h2>
            <div class="visitors-table">
                <table>
                    <thead>
                        <tr>
                            <th>IP Address</th>
                            <th>Page</th>
                            <th>Referer</th>
                            <th>Location</th>
                            <th>Date/Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_visitors as $visitor): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($visitor['ip_address']); ?></td>
                                <td><?php echo htmlspecialchars($visitor['page_url']); ?></td>
                                <td><?php echo htmlspecialchars(substr($visitor['referer'], 0, 50)); ?></td>
                                <td><?php echo htmlspecialchars($visitor['location']); ?></td>
                                <td><?php echo date('M d, Y H:i', strtotime($visitor['visit_date'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

<?php include 'includes/footer.php'; ?>
