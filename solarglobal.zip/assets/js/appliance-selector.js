﻿/**
 * Appliance Selector Logic
 * Handles appliance grid, selection, and home illustration
 */

let allAppliances = [];
let currentCategory = 'all';

/**
 * Load appliances from API with seasonal intelligence
 */
async function loadAppliances(retryCount = 0) {
    const maxRetries = 3;
    try {

        const cityId = window.appState?.selectedCity?.id || localStorage.getItem('selectedCityId') || '';
        // Get country code from location data
        let country = '';
        try {
            const loc = JSON.parse(localStorage.getItem('solarglobal_location') || '{}');
            country = loc.countryCode || '';
        } catch(e) {}
        if (!country) country = window.appState?.selectedCity?.country_code || '';
        let url = 'api/appliances.php?seasonal';
        if (cityId) url += `&city_id=${cityId}`;
        if (country) url += `&country=${encodeURIComponent(country)}`;
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();

        if (data.success && data.appliances) {
            allAppliances = data.appliances.map(a => ({
                ...a,
                id: parseInt(a.id),
                watt_typical: parseInt(a.watt_typical) || 0
            }));

            // Store season info
            window.currentSeason = data.season || 'summer';
            window.currentTemperature = data.temperature;

            renderSeasonBanner();
            renderApplianceGrid();
        } else {
            showError('Failed to load appliances. Server returned: ' + (data.message || 'Unknown error'));
            console.error('Failed to load appliances:', data);
        }
    } catch (error) {
        console.error(`Error loading appliances (attempt ${retryCount + 1}):`, error);

        // Only retry for network/fetch errors, not DOM errors
        const isNetworkError = error instanceof TypeError || error.message.includes('HTTP') || error.message.includes('fetch') || error.message.includes('network');
        if (isNetworkError && retryCount < maxRetries - 1) {

            await new Promise(r => setTimeout(r, (retryCount + 1) * 800));
            return loadAppliances(retryCount + 1);
        }

        if (error.message.includes('HTTP')) {
            showError(`Server error: ${error.message}. Please check if the server is running.`);
        } else if (isNetworkError) {
            showError('Unable to connect to server. Please check your internet connection and refresh the page.');
        } else {
            // DOM or rendering error — log but don't show scary network error
            console.error('Rendering error in appliance loader:', error);
        }
    }
}

/**
 * Render seasonal recommendation banner above the grid
 */
function renderSeasonBanner() {
    const wrapper = document.querySelector('.appliance-selector-wrapper');
    if (!wrapper) return;

    // Remove existing banner
    const existing = document.getElementById('season-banner');
    if (existing) existing.remove();

    const season = window.currentSeason;
    const temp = window.currentTemperature;
    const cityName = window.appState?.selectedCity?.name_en || localStorage.getItem('selectedCityName') || '';

    const seasonConfig = {
        summer: { icon: '☀️', label: 'Summer', color: '#F59E0B', bg: '#FFFBEB', border: '#FDE68A' },
        winter: { icon: '❄️', label: 'Winter', color: '#3B82F6', bg: '#EFF6FF', border: '#BFDBFE' },
        monsoon: { icon: '🌧️', label: 'Monsoon', color: '#10B981', bg: '#ECFDF5', border: '#A7F3D0' },
        spring: { icon: '🌸', label: 'Spring', color: '#EC4899', bg: '#FDF2F8', border: '#FBCFE8' }
    };

    const cfg = seasonConfig[season] || seasonConfig.summer;
    const tempStr = temp ? ` • ${temp}°C` : '';

    const banner = document.createElement('div');
    banner.id = 'season-banner';
    banner.style.cssText = `
        background: ${cfg.bg}; border: 2px solid ${cfg.border}; border-radius: 12px;
        padding: 14px 20px; margin-bottom: 16px; display: flex; align-items: center;
        gap: 12px; flex-wrap: wrap;
    `;
    banner.innerHTML = `
        <span style="font-size:1.5rem;">${cfg.icon}</span>
        <div style="flex:1;">
            <strong style="color:${cfg.color};">${cfg.label} Season${cityName ? ' in ' + cityName : ''}${tempStr}</strong>
            <p style="margin:2px 0 0; font-size:0.82rem; color:#64748B;">
                Appliances are sorted by seasonal relevance. <span style="color:${cfg.color};">★ Highlighted</span> items are recommended for current weather.
            </p>
        </div>
        <div style="display:flex; gap:6px; flex-wrap:wrap;">
            <span class="season-badge-legend" style="background:#DCFCE7; color:#166534; padding:3px 8px; border-radius:6px; font-size:0.72rem; font-weight:600;">● Essential</span>
            <span class="season-badge-legend" style="background:#FEF3C7; color:#92400E; padding:3px 8px; border-radius:6px; font-size:0.72rem; font-weight:600;">● Recommended</span>
            <span class="season-badge-legend" style="background:#F1F5F9; color:#64748B; padding:3px 8px; border-radius:6px; font-size:0.72rem; font-weight:600;">● Optional</span>
        </div>
    `;

    // Insert before category filters (filters may be nested inside a child container)
    const filters = wrapper.querySelector('.category-filters');
    if (filters && filters.parentNode) {
        filters.parentNode.insertBefore(banner, filters);
    } else {
        wrapper.prepend(banner);
    }
}

/**
 * Show error message to user
 */
function showError(message) {
    const grid = document.getElementById('appliance-grid');
    if (grid) {
        grid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #EF4444;">
                <div style="font-size: 48px; margin-bottom: 16px;">⚠️</div>
                <div style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">Error</div>
                <div style="font-size: 14px;">${message}</div>
                <button onclick="location.reload()" class="btn btn-primary" style="margin-top: 20px;">
                    Refresh Page
                </button>
            </div>
        `;
    }
}

/**
 * Render appliance grid with seasonal indicators
 */
function renderApplianceGrid() {
    const grid = document.getElementById('appliance-grid');
    if (!grid) return;

    let filtered;
    let showingTopPicks = false;

    if (currentCategory === 'all') {
        // "All" tab: show only top recommended items (highly_recommended, essential, recommended)
        // Skip 'normal' and 'not_recommended' — user can find those in category tabs
        const topPicks = allAppliances.filter(a => {
            const rec = a.seasonal?.recommendation || 'normal';
            return rec === 'highly_recommended' || rec === 'essential' || rec === 'recommended';
        });
        // Cap at 20 items for a clean view
        filtered = topPicks.slice(0, 20);
        showingTopPicks = true;
    } else {
        filtered = allAppliances.filter(a => a.category === currentCategory);
    }

    grid.innerHTML = filtered.map(appliance => {
        const s = appliance.seasonal || {};
        const rec = s.recommendation || 'normal';

        let badgeHtml = '';
        let cardExtraClass = '';
        if (rec === 'highly_recommended') {
            badgeHtml = `<div class="seasonal-badge highly-rec">★ Recommended</div>`;
            cardExtraClass = ' seasonal-highlight';
        } else if (rec === 'essential') {
            badgeHtml = `<div class="seasonal-badge essential">● Essential</div>`;
        } else if (rec === 'recommended') {
            badgeHtml = `<div class="seasonal-badge recommended">● Seasonal</div>`;
        } else if (rec === 'not_recommended') {
            badgeHtml = `<div class="seasonal-badge not-rec">○ Off-season</div>`;
            cardExtraClass = ' seasonal-dim';
        }

        const usageInfo = s.usage_hours ? `~${s.usage_hours}h/day` : '';

        return `
        <div class="appliance-card${cardExtraClass}" data-id="${appliance.id}" data-category="${appliance.category}" data-recommendation="${rec}">
            ${badgeHtml}
            <div class="appliance-icon">
                ${appliance.image_path && appliance.image_path !== '' && appliance.image_path !== 'null' && appliance.image_path !== null
                    ? `<img src="${appliance.image_path}" style="width:48px;height:48px;object-fit:contain;" alt="${appliance.name_en}">`
                    : `<span style="font-size:2.8rem;line-height:1;">${appliance.icon || '⚡'}</span>`}
            </div>
            <div class="appliance-name-en">${appliance.name_en}</div>
            <div class="appliance-name-ur">${appliance.name_en}</div>
            <div class="appliance-watts">${appliance.watt_typical}W ${usageInfo ? `<span class="usage-hint">${usageInfo}</span>` : ''}</div>
        </div>`;
    }).join('');

    // Add hint when showing top picks
    if (showingTopPicks) {
        grid.innerHTML += `
            <div style="grid-column: 1 / -1; text-align: center; padding: 16px 20px; margin-top: 8px;
                background: #F8FAFC; border: 1px dashed #CBD5E1; border-radius: 10px; color: #64748B; font-size: 0.85rem;">
                Showing top ${filtered.length} recommended appliances for your location.
                <br>Use the <strong>category tabs</strong> above (Cooling, Kitchen, etc.) to browse all available appliances.
            </div>`;
    }

    // FIXED: Use event delegation instead of individual handlers

    // Remove old listener if exists
    const oldGrid = grid;
    const newGrid = oldGrid.cloneNode(true);
    oldGrid.parentNode.replaceChild(newGrid, oldGrid);
    
    // Add single delegated listener
    newGrid.addEventListener('click', function(event) {
        const card = event.target.closest('.appliance-card');
        if (!card) return;
        
        event.preventDefault();
        event.stopPropagation();
        
        const id = parseInt(card.dataset.id);

        if (!id || isNaN(id)) {
            console.error('❌ Invalid appliance ID');
            return;
        }
        
        addApplianceToHome(id, card);
    }, true); // Use capture phase
    
    // Add visual feedback
    newGrid.querySelectorAll('.appliance-card').forEach(card => {
        card.style.cursor = 'pointer';
    });

    // Animate cards in (wrapped in try-catch to prevent crash if anime.js not loaded)
    try {
        if (typeof anime !== 'undefined' && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            anime({
                targets: '.appliance-card',
                opacity: [0, 1],
                translateY: [10, 0],
                duration: 350,
                delay: anime.stagger(30),
                easing: 'easeOutCubic'
            });
        }
    } catch (e) {
        console.warn('Animation skipped:', e.message);
    }
}

/**
 * Add appliance to home - Shows dialog first
 */
function addApplianceToHome(applianceId, cardElement) {
    // CRITICAL FIX: Use == (loose equality) or parseInt both sides
    // to handle cPanel MySQL returning string IDs vs XAMPP returning int IDs
    const searchId = parseInt(applianceId);
    const appliance = allAppliances.find(a => parseInt(a.id) === searchId);
    if (!appliance) {
        console.error('❌ Appliance not found! ID:', applianceId, 'Type:', typeof applianceId,
            'Available IDs:', allAppliances.map(a => ({ id: a.id, type: typeof a.id })).slice(0, 5));
        return;
    }

    showApplianceDialog(appliance, cardElement);
}

/**
 * Show appliance configuration dialog
 */
function showApplianceDialog(appliance, cardElement) {
    // Remove existing dialog
    const existing = document.getElementById('appliance-dialog-overlay');
    if (existing) existing.remove();

    // Smart defaults based on seasonal data
    const usageHours = appliance.seasonal?.usage_hours || 8;
    const halfHours = Math.round(usageHours / 2);
    const defaultStart = Math.max(0, 12 - halfHours);
    const defaultEnd = Math.min(24, 12 + halfHours);
    const hourLabels = h => { if(h===0) return '12AM'; if(h===12) return '12PM'; return h<12? h+'AM':(h-12)+'PM'; };

    let hourGrid = '';
    for(let h=0;h<24;h++){
        const on = h>=defaultStart && h<defaultEnd;
        const solar = h>=5 && h<=17;
        hourGrid += `<div class="dlg-hour ${on?'active':''} ${solar?'solar':''}" data-h="${h}" title="${hourLabels(h)}">${hourLabels(h)}</div>`;
    }

    const iconHtml = (appliance.image_path && appliance.image_path !== 'null')
        ? `<img src="${appliance.image_path}" style="width:64px;height:64px;object-fit:contain;" alt="">`
        : `<span style="font-size:64px">${appliance.icon}</span>`;

    const overlay = document.createElement('div');
    overlay.id = 'appliance-dialog-overlay';
    overlay.innerHTML = `
    <div class="appliance-dialog">
        <button class="dlg-close" onclick="this.closest('#appliance-dialog-overlay').remove()">&times;</button>
        <div class="dlg-header">
            <div class="dlg-icon">${iconHtml}</div>
            <div><h3>${appliance.name_en}</h3><p class="dlg-urdu">${appliance.name_en}</p><p class="dlg-watts">${appliance.watt_typical}W per unit</p></div>
        </div>
        <div class="dlg-section">
            <label class="dlg-label">📦 Quantity</label>
            <div class="dlg-qty-row">
                <button class="dlg-qty-btn" onclick="let v=document.getElementById('dlg-qty');v.value=Math.max(1,+v.value-1);document.getElementById('dlg-total-w').textContent=(v.value*${appliance.watt_typical})+'W'">−</button>
                <input type="number" id="dlg-qty" value="1" min="1" max="20" class="dlg-qty-input" oninput="document.getElementById('dlg-total-w').textContent=(this.value*${appliance.watt_typical})+'W'">
                <button class="dlg-qty-btn" onclick="let v=document.getElementById('dlg-qty');v.value=Math.min(20,+v.value*1+1);document.getElementById('dlg-total-w').textContent=(v.value*${appliance.watt_typical})+'W'">+</button>
                <span class="dlg-total">Total: <strong id="dlg-total-w">${appliance.watt_typical}W</strong></span>
            </div>
        </div>
        <div class="dlg-section">
            <label class="dlg-label">⚡ Load Factor: <strong id="dlg-lf-val">100%</strong></label>
            <input type="range" id="dlg-load-factor" min="30" max="100" value="100" step="5" class="dlg-slider"
                oninput="document.getElementById('dlg-lf-val').textContent=this.value+'%'">
            <div class="dlg-slider-marks"><span>30%</span><span>50%</span><span>70%</span><span>100%</span></div>
        </div>
        <div class="dlg-section">
            <label class="dlg-label">⏰ Usage Hours <small>(click to toggle)</small></label>
            <div class="dlg-actions"><button class="dlg-act-btn" id="dlg-sel-all">Select All</button><button class="dlg-act-btn" id="dlg-clr-all">Clear All</button></div>
            <div class="dlg-hour-grid">${hourGrid}</div>
            <div class="dlg-legend"><span>☀️ Solar hours</span><span>🔵 Selected</span></div>
        </div>
        <div class="dlg-footer">
            <button class="dlg-cancel" onclick="this.closest('#appliance-dialog-overlay').remove()">Cancel</button>
            <button class="dlg-confirm" id="dlg-confirm-btn">➕ Add to Home</button>
        </div>
    </div>`;

    document.body.appendChild(overlay);

    // Hour toggle
    overlay.querySelectorAll('.dlg-hour').forEach(el => {
        el.addEventListener('click', () => el.classList.toggle('active'));
    });
    // Select/clear all
    overlay.querySelector('#dlg-sel-all').addEventListener('click', () => {
        overlay.querySelectorAll('.dlg-hour').forEach(el => el.classList.add('active'));
    });
    overlay.querySelector('#dlg-clr-all').addEventListener('click', () => {
        overlay.querySelectorAll('.dlg-hour').forEach(el => el.classList.remove('active'));
    });
    // Confirm
    overlay.querySelector('#dlg-confirm-btn').addEventListener('click', () => {
        const qty = Math.max(1, parseInt(document.getElementById('dlg-qty').value) || 1);
        const lf = parseInt(document.getElementById('dlg-load-factor').value) || 100;
        const hourlyUsage = Array(24).fill(0);
        overlay.querySelectorAll('.dlg-hour.active').forEach(el => {
            hourlyUsage[parseInt(el.dataset.h)] = 1;
        });
        const hours = hourlyUsage.filter(h=>h===1).length;

        for(let i=0; i<qty; i++){
            window.appState.selectedAppliances.push({
                id: Date.now() + i,
                applianceId: appliance.id,
                name_en: appliance.name_en,
                name_ur: appliance.name_en,
                icon: appliance.icon,
                image_path: appliance.image_path || null,
                watt_typical: appliance.watt_typical,
                loadFactor: lf,
                hourlyUsage: [...hourlyUsage],
                hours: hours
            });
        }
        overlay.remove();
        animateApplianceToHouse(cardElement, appliance);
        updateLoadTotals();
        renderSelectedAppliances();
    });
    // Close on overlay click
    overlay.addEventListener('click', (e) => { if(e.target === overlay) overlay.remove(); });
}

/**
 * Animate appliance flying to house
 */
function animateApplianceToHouse(cardElement, appliance) {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const icon = cardElement.querySelector('.appliance-icon');
    const target = document.getElementById('home-panel');

    if (!icon || !target) return;

    const flyingIcon = icon.cloneNode(true);
    flyingIcon.style.position = 'fixed';
    flyingIcon.style.zIndex = '9999';
    flyingIcon.style.fontSize = '48px';
    flyingIcon.style.pointerEvents = 'none';

    const iconRect = icon.getBoundingClientRect();
    const targetRect = target.getBoundingClientRect();

    flyingIcon.style.left = iconRect.left + 'px';
    flyingIcon.style.top = iconRect.top + 'px';

    document.body.appendChild(flyingIcon);

    anime({
        targets: flyingIcon,
        left: targetRect.left + targetRect.width / 2 - 24,
        top: targetRect.top + 30,
        scale: [1, 0.3],
        opacity: [1, 0],
        duration: 500,
        easing: 'easeInOutCubic',
        complete: () => flyingIcon.remove()
    });
}

/**
 * Render selected appliances in home
 */
function renderSelectedAppliances() {
    const container = document.getElementById('selected-appliances');
    if (!container) return;
    
    // Update home panel count
    const countEl = document.getElementById('home-panel-count');
    if (countEl) {
        const n = window.appState.selectedAppliances.length;
        countEl.textContent = n === 0 ? 'No appliances added yet' : `${n} appliance${n>1?'s':''} added`;
    }

    if (window.appState.selectedAppliances.length === 0) {
        container.innerHTML = `<div class="empty-message">
            <span style="font-size:2.5rem;display:block;margin-bottom:8px;">👆</span>
            <strong>Click appliances above to add them</strong>
            <p style="margin:6px 0 0;font-size:0.8125rem;color:var(--slate-400);">Select your home appliances to calculate your solar needs</p>
        </div>`;
        return;
    }

    container.innerHTML = window.appState.selectedAppliances.map(item => {
        if (!item.hourlyUsage) {
            item.hourlyUsage = Array(24).fill(0);
            if (item.startTime !== undefined && item.endTime !== undefined) {
                for (let h = item.startTime; h < item.endTime; h++) {
                    item.hourlyUsage[h] = 1;
                }
            }
        }
        if (!item.loadFactor) item.loadFactor = 100;

        const hours = item.hourlyUsage.filter(h => h === 1).length;
        item.hours = hours;
        const actualWatts = Math.round(item.watt_typical * (item.loadFactor / 100));
        const dailyKwh = ((actualWatts * hours) / 1000).toFixed(2);

        const iconDisplay = (item.image_path && item.image_path !== '' && item.image_path !== 'null')
            ? `<img src="${item.image_path}" style="width:32px;height:32px;object-fit:contain;" alt="${item.name_en}">`
            : `<span style="font-size: 28px;">${item.icon}</span>`;

        const formatHourLabel = (h) => {
            if (h === 0) return '12<br>AM';
            if (h === 12) return '12<br>PM';
            if (h < 12) return `${h}<br>AM`;
            return `${h - 12}<br>PM`;
        };

        const hourlyGrid = Array.from({length: 24}, (_, h) => {
            const isActive = item.hourlyUsage[h] === 1;
            const isSolarPeak = h >= 5 && h <= 17;
            return `
                <div class="hour-block ${isActive ? 'active' : ''} ${isSolarPeak ? 'solar-peak' : ''}"
                     data-id="${item.id}"
                     data-hour="${h}"
                     title="${h}:00">
                    <div class="hour-label">${formatHourLabel(h)}</div>
                </div>
            `;
        }).join('');

        return `
        <div class="selected-appliance-row">
            <div class="appliance-info-row">
                <span class="selected-icon">${iconDisplay}</span>
                <div class="appliance-name-section">
                    <span class="selected-name">${item.name_en}</span>
                    <span class="selected-watts">
                        <span class="watt-badge">⚡ ${actualWatts}W</span>
                        <span class="kwh-badge">🔋 ${dailyKwh} kWh</span>
                        <span class="hours-badge">⏱ ${hours}h/day</span>
                    </span>
                </div>
                <button class="btn-remove" data-id="${item.id}" aria-label="Remove">×</button>
            </div>

            <!-- Load Factor Slider -->
            <div class="load-factor-section">
                <div class="load-factor-header">
                    <span class="load-factor-label">⚡ Load Factor:</span>
                    <span class="load-factor-value" id="load-value-${item.id}">${item.loadFactor}%</span>
                </div>
                <div class="load-factor-slider-container">
                    <input type="range"
                           class="load-factor-slider"
                           id="load-slider-${item.id}"
                           data-id="${item.id}"
                           min="30"
                           max="100"
                           value="${item.loadFactor}"
                           step="5">
                    <div class="load-factor-markers">
                        <span>30%</span>
                        <span>50%</span>
                        <span>70%</span>
                        <span>100%</span>
                    </div>
                </div>
            </div>

            <div class="hourly-usage-section">
                <div class="hourly-usage-header">
                    <span class="usage-label">⏰ Usage Hours (click to toggle):</span>
                    <div class="usage-actions">
                        <button class="btn-select-all" data-id="${item.id}">All On</button>
                        <button class="btn-clear-all" data-id="${item.id}">All Off</button>
                    </div>
                </div>
                <div class="hourly-usage-grid" id="grid-${item.id}">
                    ${hourlyGrid}
                </div>
                <div class="solar-peak-legend">
                    <span class="legend-item">
                        <span class="legend-box solar"></span>
                        ☀️ Solar Hours
                    </span>
                    <span class="legend-item">
                        <span class="legend-box active"></span>
                        ON
                    </span>
                    <span class="legend-item">
                        <span class="legend-box inactive"></span>
                        OFF
                    </span>
                </div>
            </div>
        </div>
    `}).join('');
    
    // Add remove handlers
    container.querySelectorAll('.btn-remove').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const id = parseInt(btn.dataset.id);
            removeAppliance(id);
        });
    });
    
    // Add hour block click handlers
    container.querySelectorAll('.hour-block').forEach(block => {
        block.addEventListener('click', (e) => {
            e.stopPropagation();
            const id = parseInt(block.dataset.id);
            const hour = parseInt(block.dataset.hour);
            toggleHourUsage(id, hour);
        });
    });
    
    // Add select all / clear all handlers
    container.querySelectorAll('.btn-select-all').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const id = parseInt(btn.dataset.id);
            setAllHours(id, 1);
        });
    });
    
    container.querySelectorAll('.btn-clear-all').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const id = parseInt(btn.dataset.id);
            setAllHours(id, 0);
        });
    });
    
    // Add load factor slider handlers
    container.querySelectorAll('.load-factor-slider').forEach(slider => {
        slider.addEventListener('input', (e) => {
            const id = parseInt(slider.dataset.id);
            const value = parseInt(e.target.value);
            updateLoadFactor(id, value);
        });
    });

    // Show/hide Clear All button
    var clearBtn = document.getElementById('clear-all-appliances');
    if (clearBtn) clearBtn.style.display = window.appState.selectedAppliances.length > 0 ? 'inline-flex' : 'none';
}

/**
 * Update load factor for an appliance
 */
function updateLoadFactor(instanceId, loadFactor) {
    const instance = window.appState.selectedAppliances.find(a => a.id === instanceId);
    if (!instance) return;

    instance.loadFactor = loadFactor;

    const valueDisplay = document.getElementById(`load-value-${instanceId}`);
    if (valueDisplay) valueDisplay.textContent = `${loadFactor}%`;

    const actualWatts = Math.round(instance.watt_typical * (loadFactor / 100));
    const hours = instance.hourlyUsage.filter(h => h === 1).length;
    const dailyKwh = ((actualWatts * hours) / 1000).toFixed(2);

    const wattsDisplay = document.querySelector(`.selected-appliance-row [data-id="${instanceId}"]`)
        ?.closest('.selected-appliance-row')
        ?.querySelector('.selected-watts');

    if (wattsDisplay) {
        wattsDisplay.innerHTML = `
            <span class="watt-badge">⚡ ${actualWatts}W</span>
            <span class="kwh-badge">🔋 ${dailyKwh} kWh</span>
            <span class="hours-badge">⏱ ${hours}h/day</span>
        `;
    }

    updateLoadTotals();
}

/**
 * Toggle hour usage for an appliance
 */
function toggleHourUsage(instanceId, hour) {
    const instance = window.appState.selectedAppliances.find(a => a.id === instanceId);
    if (!instance) return;

    instance.hourlyUsage[hour] = instance.hourlyUsage[hour] === 1 ? 0 : 1;
    instance.hours = instance.hourlyUsage.filter(h => h === 1).length;

    const block = document.querySelector(`.hour-block[data-id="${instanceId}"][data-hour="${hour}"]`);
    if (block) block.classList.toggle('active');

    // Update badges
    const actualWatts = Math.round(instance.watt_typical * (instance.loadFactor / 100));
    const dailyKwh = ((actualWatts * instance.hours) / 1000).toFixed(2);
    const wattsDisplay = document.querySelector(`.selected-appliance-row [data-id="${instanceId}"]`)
        ?.closest('.selected-appliance-row')
        ?.querySelector('.selected-watts');
    if (wattsDisplay) {
        wattsDisplay.innerHTML = `
            <span class="watt-badge">⚡ ${actualWatts}W</span>
            <span class="kwh-badge">🔋 ${dailyKwh} kWh</span>
            <span class="hours-badge">⏱ ${instance.hours}h/day</span>
        `;
    }

    updateLoadTotals();
}

/**
 * Set all hours for an appliance
 */
function setAllHours(instanceId, value) {
    const instance = window.appState.selectedAppliances.find(a => a.id === instanceId);
    if (!instance) return;
    
    // Set all hours
    instance.hourlyUsage = Array(24).fill(value);
    instance.hours = value === 1 ? 24 : 0;
    
    // Re-render
    renderSelectedAppliances();
    updateLoadTotals();
}



/**
 * Remove appliance
 */
function removeAppliance(instanceId) {
    // Remove this specific instance
    window.appState.selectedAppliances = window.appState.selectedAppliances.filter(a => a.id !== instanceId);
    
    updateLoadTotals();
    renderSelectedAppliances();
}

/**
 * Update load totals
 */
function updateLoadTotals() {
    let totalWatts = 0;
    let totalDailyWh = 0;
    
    window.appState.selectedAppliances.forEach(item => {
        // Apply load factor to calculate actual watts
        const loadFactor = item.loadFactor || 100;
        const actualWatts = item.watt_typical * (loadFactor / 100);
        
        totalWatts += actualWatts;
        totalDailyWh += actualWatts * item.hours;
    });
    
    const dailyKwh = totalDailyWh / 1000;
    const dailyUnits = dailyKwh; // 1 kWh = 1 Unit
    
    window.appState.totalWatts = totalWatts;
    window.appState.dailyKwh = dailyKwh;
    
    // Update display
    const wattsEl = document.getElementById('total-watts');
    const kwhEl = document.getElementById('daily-kwh');
    const unitsEl = document.getElementById('daily-units');
    const btnCalculate = document.getElementById('btn-calculate');
    
    if (wattsEl) {
        // Animate counter
        if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            const oldValue = parseInt(wattsEl.textContent) || 0;
            anime({
                targets: { val: oldValue },
                val: totalWatts,
                round: 1,
                duration: 400,
                easing: 'easeOutCubic',
                update: function(anim) {
                    wattsEl.textContent = Math.round(anim.animations[0].currentValue) + ' W';
                }
            });
        } else {
            wattsEl.textContent = totalWatts + ' W';
        }
    }
    
    if (kwhEl) {
        kwhEl.textContent = dailyKwh.toFixed(2) + ' kWh';
    }
    
    if (unitsEl) {
        unitsEl.textContent = dailyUnits.toFixed(2) + ' Units';
    }
    
    if (btnCalculate) {
        btnCalculate.disabled = totalWatts === 0;
    }

    // Keep floating widget in sync
    if (typeof updateFabWidget === 'function') updateFabWidget();
}

/**
 * Setup category filters
 */
function setupCategoryFilters() {
    const buttons = document.querySelectorAll('.category-btn');
    
    buttons.forEach(btn => {
        btn.addEventListener('click', () => {
            // Update active state
            buttons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            // Update category
            currentCategory = btn.dataset.category;
            
            // Re-render grid with animation
            const grid = document.getElementById('appliance-grid');
            if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
                anime({
                    targets: '.appliance-card',
                    translateY: [0, -10],
                    opacity: [1, 0],
                    duration: 200,
                    easing: 'easeInCubic',
                    complete: () => {
                        renderApplianceGrid();
                    }
                });
            } else {
                renderApplianceGrid();
            }
        });
    });
}

/**
 * Populate breakdown table in Step 2
 */
window.populateBreakdownTable = function() {
    const tbody = document.getElementById('breakdown-tbody');
    if (!tbody) return;
    
    let totalDailyKwh = 0;
    
    const rows = window.appState.selectedAppliances.map((item, index) => {
        const hours = Math.floor(item.hours);
        const minutes = Math.round((item.hours - hours) * 60);
        const timeDisplay = minutes > 0 ? `${hours}h ${minutes}m` : `${hours}h`;
        
        const name = item.name_en;
        // BUGFIX: Apply load factor to power calculation
        const loadFactor = item.loadFactor || 100;
        const actualWatts = Math.round(item.watt_typical * (loadFactor / 100));
        const dailyWh = actualWatts * item.hours;
        const dailyKwh = dailyWh / 1000;
        const dailyUnits = dailyKwh; // 1 kWh = 1 Unit
        
        totalDailyKwh += dailyKwh;
        
        return `
            <tr>
                <td>${index + 1}</td>
                <td><span class="appliance-icon-small">${item.icon}</span> ${name}</td>
                <td>${timeDisplay}</td>
                <td>${actualWatts}W <small style="color:#64748B">(${loadFactor}%)</small></td>
                <td>${dailyKwh.toFixed(2)} kWh</td>
                <td class="units-cell">${dailyUnits.toFixed(2)}</td>
            </tr>
        `;
    });
    
    tbody.innerHTML = rows.join('');
    
    // Add total row
    const totalUnits = totalDailyKwh;
    tbody.innerHTML += `
        <tr class="total-row">
            <td colspan="4"><strong>${t('total_units_per_day') || 'Total Units Per Day'}</strong></td>
            <td><strong>${totalDailyKwh.toFixed(2)} kWh</strong></td>
            <td class="units-cell"><strong>${totalUnits.toFixed(2)} Units</strong></td>
        </tr>
    `;
};

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    loadAppliances();
    setupCategoryFilters();
    setupQuickPresets();
});

/**
 * Setup Quick Preset Buttons
 */
function setupQuickPresets() {
    // Show presets after appliances load
    const checkPresets = setInterval(() => {
        if (allAppliances.length > 0 && allAppliances[0].seasonal) {
            clearInterval(checkPresets);
            const presetsDiv = document.getElementById('quick-presets');
            if (presetsDiv) presetsDiv.style.display = 'flex';
        }
    }, 500);

    document.getElementById('preset-essential')?.addEventListener('click', () => {
        applyPreset(['essential', 'highly_recommended'], 'Essential');
    });

    document.getElementById('preset-comfort')?.addEventListener('click', () => {
        applyPreset(['essential', 'highly_recommended', 'recommended'], 'Comfort');
    });

    document.getElementById('preset-full')?.addEventListener('click', () => {
        applyPreset(['essential', 'highly_recommended', 'recommended', 'normal'], 'Full Home');
    });

    // Clear All appliances button
    document.getElementById('clear-all-appliances')?.addEventListener('click', function() {
        if (!window.appState.selectedAppliances.length) return;
        if (!confirm('Clear all ' + window.appState.selectedAppliances.length + ' selected appliances?')) return;
        window.appState.selectedAppliances = [];
        updateLoadTotals();
        renderSelectedAppliances();
        saveState();
    });
}

/**
 * Apply a preset - auto-add appliances matching recommendation levels
 */
function applyPreset(levels, presetName) {
    const toAdd = allAppliances.filter(a =>
        a.seasonal && levels.includes(a.seasonal.recommendation)
    );

    if (toAdd.length === 0) {
        alert('No appliances found for this preset.');
        return;
    }

    if (!confirm(`Add ${toAdd.length} appliances (${presetName} Package) with recommended usage hours?`)) {
        return;
    }

    // Daily kWh limits per preset
    var PRESET_LIMITS = { 'Essential': 18, 'Comfort': 50, 'Full Home': 100 };
    var dailyLimit = PRESET_LIMITS[presetName] || 999;

    // Sort by recommendation priority (essential first, then highly_recommended, etc.)
    const priorityOrder = ['essential', 'highly_recommended', 'recommended', 'normal'];
    const sorted = [...toAdd].sort((a, b) => {
        const aIdx = priorityOrder.indexOf(a.seasonal?.recommendation || 'normal');
        const bIdx = priorityOrder.indexOf(b.seasonal?.recommendation || 'normal');
        return aIdx - bIdx;
    });

    // Clear existing selections
    window.appState.selectedAppliances = [];

    let runningKwh = 0;

    sorted.forEach(appliance => {
        const usageHours = appliance.seasonal?.usage_hours || 6;
        const halfHours = Math.round(usageHours / 2);
        const startHour = Math.max(0, 12 - halfHours);
        const endHour = Math.min(24, 12 + halfHours);

        const hourlyUsage = Array(24).fill(0);
        for (let h = startHour; h < endHour; h++) {
            hourlyUsage[h] = 1;
        }

        // For 24h appliances (fridge, router, cameras)
        if (usageHours >= 24) {
            hourlyUsage.fill(1);
        }

        const hours = hourlyUsage.filter(h => h === 1).length;
        const applianceKwh = (appliance.watt_typical * hours) / 1000;

        // Check if adding this appliance would exceed the daily limit
        if (runningKwh + applianceKwh > dailyLimit) {
            return; // Skip this appliance
        }
        runningKwh += applianceKwh;

        window.appState.selectedAppliances.push({
            id: Date.now() + Math.random(),
            applianceId: appliance.id,
            name_en: appliance.name_en,
            name_ur: appliance.name_en,
            icon: appliance.icon,
            image_path: appliance.image_path || null,
            watt_typical: appliance.watt_typical,
            loadFactor: 100,
            hourlyUsage: hourlyUsage,
            hours: hours
        });
    });

    updateLoadTotals();
    renderSelectedAppliances();
    saveState();

    // Visual feedback
    const btn = document.getElementById('btn-calculate');
    if (btn) btn.disabled = false;

    // Show success message
    const banner = document.getElementById('season-banner');
    if (banner) {
        const msg = document.createElement('div');
        msg.style.cssText = 'background:#DCFCE7; color:#166534; padding:8px 14px; border-radius:8px; margin-top:8px; font-size:0.85rem; font-weight:500;';
        const addedCount = window.appState.selectedAppliances.length;
        const limitNote = addedCount < toAdd.length ? ` (${toAdd.length - addedCount} skipped to stay within ${dailyLimit} kWh/day limit)` : '';
        msg.textContent = `✓ ${addedCount} appliances added with smart seasonal hours${limitNote}. Click "Calculate My Load" to continue.`;
        banner.appendChild(msg);
        setTimeout(() => msg.remove(), 5000);
    }

    // Update FAB
    updateFabWidget();
}

/* =====================================================
   FLOATING ACTION WIDGET
   Shows persistent load summary while adding appliances
   ===================================================== */

/**
 * Initialize FAB toggle behavior
 */
(function initFab() {
    document.addEventListener('DOMContentLoaded', () => {
        const toggle = document.getElementById('fab-toggle');
        const panel = document.getElementById('fab-panel');
        if (!toggle || !panel) return;

        toggle.addEventListener('click', () => {
            panel.classList.toggle('open');
        });

        // Close when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.fab-widget')) {
                panel.classList.remove('open');
            }
        });

        // FAB calc button mirrors main calc button
        const fabCalc = document.getElementById('fab-calc-btn');
        if (fabCalc) {
            fabCalc.addEventListener('click', () => {
                const mainCalc = document.getElementById('btn-calculate');
                if (mainCalc && !mainCalc.disabled) mainCalc.click();
            });
        }
    });
})();

/**
 * Show/hide FAB based on current step
 */
window.updateFabVisibility = function(step) {
    const fab = document.getElementById('fab-load-widget');
    if (!fab) return;
    fab.style.display = (step === 1) ? 'block' : 'none';
};

/**
 * Update the floating action widget with current appliance data
 */
function updateFabWidget() {
    const fab = document.getElementById('fab-load-widget');
    if (!fab) return;

    const items = window.appState?.selectedAppliances || [];
    const count = items.length;

    // Update badge
    const badge = document.getElementById('fab-count');
    if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'flex' : 'none';
    }

    // Update stats
    let totalW = 0, totalDailyWh = 0;
    items.forEach(item => {
        const lf = item.loadFactor || 100;
        const w = item.watt_typical * (lf / 100);
        totalW += w;
        totalDailyWh += w * (item.hours || 0);
    });
    const dailyKwh = totalDailyWh / 1000;

    const fabW = document.getElementById('fab-watts');
    const fabK = document.getElementById('fab-kwh');
    const fabU = document.getElementById('fab-units');
    if (fabW) fabW.textContent = Math.round(totalW) + 'W';
    if (fabK) fabK.textContent = dailyKwh.toFixed(1) + ' kWh';
    if (fabU) fabU.textContent = dailyKwh.toFixed(1);

    // Update FAB calc button state
    const fabCalc = document.getElementById('fab-calc-btn');
    if (fabCalc) fabCalc.disabled = count === 0;

    // Update items list
    const list = document.getElementById('fab-items-list');
    if (!list) return;

    if (count === 0) {
        list.innerHTML = `<div class="fab-empty">
            <span class="fab-empty-icon">📦</span>
            No appliances added yet
        </div>`;
        return;
    }

    // Group by appliance name for compact display
    const grouped = {};
    items.forEach(item => {
        const key = item.applianceId || item.name_en;
        if (!grouped[key]) {
            grouped[key] = { ...item, qty: 1 };
        } else {
            grouped[key].qty++;
        }
    });

    list.innerHTML = Object.values(grouped).map(item => {
        const lf = item.loadFactor || 100;
        const w = Math.round(item.watt_typical * (lf / 100));
        const iconHtml = (item.image_path && item.image_path !== 'null')
            ? `<img src="${item.image_path}" style="width:20px;height:20px;object-fit:contain;" alt="">`
            : item.icon;
        return `<div class="fab-item">
            <div class="fab-item-icon">${iconHtml}</div>
            <div class="fab-item-info">
                <div class="fab-item-name">${item.name_en}${item.qty > 1 ? ` ×${item.qty}` : ''}</div>
                <div class="fab-item-detail">${item.hours || 0}h/day • ${lf}% load</div>
            </div>
            <div class="fab-item-watts">${w * item.qty}W</div>
        </div>`;
    }).join('');
}
