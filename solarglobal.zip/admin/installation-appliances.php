<?php
/**
 * Admin: Installation Appliances Management
 * CRUD for breakers, wires, frames, mounting, connectors, etc.
 */
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/csrf.php';
require_once '../includes/helpers.php';

$db = getDB();
$message = '';
$error = '';
$showForm = false;
$editData = null;

// Category definitions
$categories = [
    'breaker'         => ['label' => 'Circuit Breaker',   'icon' => '&#9889;'],
    'wire'            => ['label' => 'Wire / Cable',      'icon' => '&#128268;'],
    'frame'           => ['label' => 'Frame',             'icon' => '&#128296;'],
    'mounting'        => ['label' => 'Mounting Hardware',  'icon' => '&#128296;'],
    'connector'       => ['label' => 'Connector',         'icon' => '&#128268;'],
    'combiner_box'    => ['label' => 'Combiner Box',      'icon' => '&#128230;'],
    'surge_protector' => ['label' => 'Surge Protector',   'icon' => '&#9889;'],
    'cable_tray'      => ['label' => 'Cable Tray',        'icon' => '&#128230;'],
    'other'           => ['label' => 'Other',             'icon' => '&#128296;'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid CSRF token';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'add' || $action === 'edit') {
            $id = intval($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $category = trim($_POST['category'] ?? 'other');
            $brand = trim($_POST['brand'] ?? '');
            $specifications = trim($_POST['specifications'] ?? '');
            $price_usd = floatval($_POST['price_usd'] ?? 0);
            $icon = trim($_POST['icon'] ?? '');
            $is_active = isset($_POST['is_active']) ? 1 : 0;

            if (empty($name)) {
                $error = 'Name is required';
            } elseif (!array_key_exists($category, $categories)) {
                $error = 'Invalid category';
            } else {
                // Handle image upload
                $image_path = $_POST['existing_image'] ?? null;
                if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                    $upload_result = handle_image_upload($_FILES['image'], '../uploads/installation/');
                    if ($upload_result['success']) {
                        $image_path = $upload_result['path'];
                    }
                }

                if ($action === 'add') {
                    $stmt = $db->prepare("INSERT INTO installation_appliances (name, category, brand, specifications, price_usd, image_path, icon, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$name, $category, $brand, $specifications, $price_usd, $image_path, $icon, $is_active]);
                    $message = 'Installation appliance added successfully!';
                } else {
                    $stmt = $db->prepare("UPDATE installation_appliances SET name = ?, category = ?, brand = ?, specifications = ?, price_usd = ?, image_path = ?, icon = ?, is_active = ? WHERE id = ?");
                    $stmt->execute([$name, $category, $brand, $specifications, $price_usd, $image_path, $icon, $is_active, $id]);
                    $message = 'Installation appliance updated successfully!';
                }
            }
        } elseif ($action === 'delete') {
            $id = intval($_POST['id'] ?? 0);
            $db->prepare("DELETE FROM installation_appliances WHERE id = ?")->execute([$id]);
            $message = 'Installation appliance deleted!';
        } elseif ($action === 'show_add') {
            $showForm = true;
        } elseif ($action === 'show_edit') {
            $showForm = true;
            $id = intval($_POST['id'] ?? 0);
            $stmt = $db->prepare("SELECT * FROM installation_appliances WHERE id = ?");
            $stmt->execute([$id]);
            $editData = $stmt->fetch();
        }
    }
}

// Filter by category
$filterCat = $_GET['cat'] ?? '';
$sql = "SELECT * FROM installation_appliances";
$params = [];
if ($filterCat && array_key_exists($filterCat, $categories)) {
    $sql .= " WHERE category = ?";
    $params[] = $filterCat;
}
$sql .= " ORDER BY category ASC, name ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

// Count by category
$catCounts = $db->query("SELECT category, COUNT(*) as cnt FROM installation_appliances GROUP BY category")->fetchAll(PDO::FETCH_KEY_PAIR);

$pageTitle = "Installation Appliances";
include 'includes/header.php';
?>

<style>
.form-container { background: white; padding: 30px; margin-bottom: 20px; border-radius: 8px; border: 2px solid #8b5cf6; }
.cat-filter { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 20px; }
.cat-filter a { padding: 6px 14px; border-radius: 20px; font-size: 13px; text-decoration: none; background: #f1f5f9; color: #475569; transition: all 0.2s; }
.cat-filter a:hover, .cat-filter a.active { background: #8b5cf6; color: white; }
.cat-filter .count { font-size: 11px; opacity: 0.7; margin-left: 4px; }
.spec-text { font-size: 12px; color: #64748b; max-width: 300px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
</style>

<?php if ($message): ?>
    <div class="alert alert-success"><?= sanitize($message) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-error"><?= sanitize($error) ?></div>
<?php endif; ?>

<?php if ($showForm): ?>
<div class="form-container">
    <h2><?= $editData ? 'Edit Installation Appliance' : 'Add New Installation Appliance' ?></h2>
    <form method="POST" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $editData ? 'edit' : 'add' ?>">
        <?php if ($editData): ?>
            <input type="hidden" name="id" value="<?= $editData['id'] ?>">
            <input type="hidden" name="existing_image" value="<?= $editData['image_path'] ?? '' ?>">
        <?php endif; ?>

        <div class="form-group">
            <label>Name *</label>
            <input type="text" name="name" value="<?= sanitize($editData['name'] ?? '') ?>" required placeholder="e.g. DC Circuit Breaker (32A)">
        </div>

        <div class="form-group">
            <label>Category *</label>
            <select name="category" required>
                <?php foreach ($categories as $key => $cat): ?>
                <option value="<?= $key ?>" <?= ($editData['category'] ?? 'other') == $key ? 'selected' : '' ?>>
                    <?= $cat['label'] ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Brand</label>
            <input type="text" name="brand" value="<?= sanitize($editData['brand'] ?? '') ?>" placeholder="e.g. Schneider, ABB, Generic">
        </div>

        <div class="form-group">
            <label>Specifications</label>
            <textarea name="specifications" rows="3" placeholder="e.g. 32A DC, 600V rated, DIN rail mount, IP20"><?= sanitize($editData['specifications'] ?? '') ?></textarea>
        </div>

        <div class="form-group">
            <label>Price (USD) *</label>
            <input type="number" name="price_usd" step="0.01" min="0" value="<?= $editData['price_usd'] ?? '0.00' ?>" required>
        </div>

        <div class="form-group">
            <label>Icon (Emoji)</label>
            <input type="text" name="icon" value="<?= sanitize($editData['icon'] ?? '') ?>" placeholder="e.g. &#9889;">
            <small>Shown when no image is uploaded</small>
        </div>

        <div class="form-group">
            <label>Image (Optional)</label>
            <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
            <small>Max 2MB. JPG, PNG, or WebP</small>
            <?php if ($editData && $editData['image_path']): ?>
                <div style="margin-top: 10px;">
                    <img src="<?= sanitize($editData['image_path']) ?>" style="width:80px;height:80px;object-fit:contain;border:1px solid #ddd;padding:5px;border-radius:4px;">
                    <p style="font-size:12px;color:#64748b;">Current image</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label><input type="checkbox" name="is_active" <?= ($editData['is_active'] ?? 1) ? 'checked' : '' ?>> Active</label>
        </div>

        <div class="action-buttons">
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="installation-appliances.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php else: ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Installation Appliances (<?= count($items) ?>)</h2>
        <form method="POST" style="display: inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="show_add">
            <button type="submit" class="btn btn-primary">+ Add New Item</button>
        </form>
    </div>

    <!-- Category filter pills -->
    <div class="cat-filter">
        <a href="installation-appliances.php" class="<?= empty($filterCat) ? 'active' : '' ?>">
            All<span class="count">(<?= count($items) ?>)</span>
        </a>
        <?php foreach ($categories as $key => $cat): ?>
            <?php $cnt = $catCounts[$key] ?? 0; if ($cnt > 0): ?>
            <a href="?cat=<?= $key ?>" class="<?= $filterCat === $key ? 'active' : '' ?>">
                <?= $cat['label'] ?><span class="count">(<?= $cnt ?>)</span>
            </a>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th style="width:50px;">Image</th>
                <th>Name</th>
                <th>Category</th>
                <th>Brand</th>
                <th>Specs</th>
                <th>Price</th>
                <th>Active</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
            <tr>
                <td style="font-size:24px;">
                    <?php if ($item['image_path']): ?>
                        <img src="<?= sanitize($item['image_path']) ?>" style="width:40px;height:40px;object-fit:contain;">
                    <?php else: ?>
                        <?= $item['icon'] ?: '&#128296;' ?>
                    <?php endif; ?>
                </td>
                <td><strong><?= sanitize($item['name']) ?></strong></td>
                <td><span class="badge badge-blue"><?= $categories[$item['category']]['label'] ?? $item['category'] ?></span></td>
                <td><?= sanitize($item['brand'] ?? '-') ?></td>
                <td><span class="spec-text" title="<?= sanitize($item['specifications'] ?? '') ?>"><?= sanitize($item['specifications'] ?? '-') ?></span></td>
                <td>$<?= number_format($item['price_usd'], 2) ?></td>
                <td><?= $item['is_active'] ? '&#10003;' : '&#10007;' ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="show_edit">
                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                        <button type="submit" class="btn btn-secondary btn-sm">Edit</button>
                    </form>
                    <form method="POST" style="display:inline;" onsubmit="return confirm('Delete <?= sanitize($item['name']) ?>?');">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= $item['id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($items)): ?>
            <tr><td colspan="8" style="text-align:center;padding:40px;color:#94a3b8;">No installation appliances found. Add your first item above.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
