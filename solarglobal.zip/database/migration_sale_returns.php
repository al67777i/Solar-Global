<?php
/**
 * Migration: Create sale_returns and sale_return_items tables, alter orders table
 * Run once: http://localhost/solarglobal/database/migration_sale_returns.php
 */
require_once __DIR__ . '/../includes/db.php';

$db = getDB();

$queries = [
    'Create sale_returns table' => "
        CREATE TABLE IF NOT EXISTS sale_returns (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            dealer_id INT NOT NULL,
            return_number VARCHAR(25) NOT NULL UNIQUE,
            subtotal_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            tax_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            currency VARCHAR(3) DEFAULT 'USD',
            reason TEXT NULL,
            notes TEXT NULL,
            status ENUM('pending','completed','cancelled') DEFAULT 'completed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_order_id (order_id),
            INDEX idx_dealer_id (dealer_id),
            INDEX idx_status (status),
            INDEX idx_created_at (created_at),
            CONSTRAINT fk_sale_returns_order FOREIGN KEY (order_id) REFERENCES orders(id),
            CONSTRAINT fk_sale_returns_dealer FOREIGN KEY (dealer_id) REFERENCES dealers(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    'Create sale_return_items table' => "
        CREATE TABLE IF NOT EXISTS sale_return_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            return_id INT NOT NULL,
            order_item_id INT NOT NULL,
            product_type ENUM('inverter','battery','panel','installation_appliance') NOT NULL,
            product_id INT NOT NULL,
            product_name VARCHAR(250) NOT NULL,
            quantity_returned INT NOT NULL DEFAULT 1,
            unit_price DECIMAL(12,2) NOT NULL,
            total_price DECIMAL(12,2) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_return_id (return_id),
            INDEX idx_order_item_id (order_item_id),
            CONSTRAINT fk_return_items_return FOREIGN KEY (return_id) REFERENCES sale_returns(id) ON DELETE CASCADE,
            CONSTRAINT fk_return_items_order_item FOREIGN KEY (order_item_id) REFERENCES order_items(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    'Add refund_amount to orders' => "
        ALTER TABLE orders ADD COLUMN IF NOT EXISTS refund_amount DECIMAL(12,2) DEFAULT 0 AFTER total_amount
    ",

    'Add net_amount to orders' => "
        ALTER TABLE orders ADD COLUMN IF NOT EXISTS net_amount DECIMAL(12,2) DEFAULT 0 AFTER refund_amount
    ",
];

echo "<h1>Migration: Sale Returns</h1><pre>\n";

foreach ($queries as $label => $sql) {
    try {
        $db->exec($sql);
        echo "&#10004; $label\n";
    } catch (PDOException $e) {
        $msg = $e->getMessage();
        if (strpos($msg, 'Duplicate') !== false || strpos($msg, 'already exists') !== false) {
            echo "&#9197; $label (already exists)\n";
        } else {
            echo "&#10060; $label: $msg\n";
        }
    }
}

// Backfill net_amount = total_amount - refund_amount for existing orders
try {
    $db->exec("UPDATE orders SET net_amount = total_amount - refund_amount WHERE net_amount = 0 AND total_amount > 0");
    $count = $db->query("SELECT ROW_COUNT()")->fetchColumn();
    echo "\n&#10004; Backfilled net_amount for $count existing orders\n";
} catch (PDOException $e) {
    echo "\n&#10060; Backfill net_amount: " . $e->getMessage() . "\n";
}

// Verify
echo "\n--- Verification ---\n";
try {
    $tables = ['sale_returns', 'sale_return_items'];
    foreach ($tables as $t) {
        $cols = $db->query("SHOW COLUMNS FROM $t")->fetchAll(PDO::FETCH_COLUMN);
        echo "&#10004; $t columns: " . implode(', ', $cols) . "\n";
    }

    $orderCols = $db->query("SHOW COLUMNS FROM orders WHERE Field IN ('refund_amount','net_amount')")->fetchAll(PDO::FETCH_COLUMN);
    echo "&#10004; orders new columns: " . implode(', ', $orderCols) . "\n";
} catch (PDOException $e) {
    echo "&#10060; Verification error: " . $e->getMessage() . "\n";
}

echo "\nDone! Sale returns migration complete.\n</pre>";
