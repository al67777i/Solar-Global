<?php
/**
 * Weather API Endpoint
 * Provides weather forecast, solar generation potential, and weather summary
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

require_once __DIR__ . '/../includes/WeatherService.php';
require_once __DIR__ . '/../includes/helpers.php';

if (!rate_limit('api_weather', 30, 60)) { respond_rate_limited(); }

$action = $_GET['action'] ?? 'forecast';
$cityId = (int)($_GET['city_id'] ?? 0);

if (!$cityId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'city_id parameter required']);
    exit;
}

try {
    $weather = new WeatherService();

    switch ($action) {
        case 'forecast':
            $days = min(30, max(1, (int)($_GET['days'] ?? 30)));
            $result = $weather->getForecast($cityId, $days);
            echo json_encode($result);
            break;

        case 'generation':
            $panelWatts = (int)($_GET['panel_watts'] ?? 550);
            $numPanels = (int)($_GET['num_panels'] ?? 4);
            if ($panelWatts < 100 || $numPanels < 1) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Invalid panel configuration']);
                break;
            }
            $result = $weather->calculateDailyGenerationPotential($cityId, $panelWatts, $numPanels);
            echo json_encode($result);
            break;

        case 'summary':
            $summary = $weather->getWeatherSummary($cityId);
            if ($summary) {
                echo json_encode(['success' => true, 'data' => $summary]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Unable to get weather summary']);
            }
            break;

        case 'clean_cache':
            $weather->cleanExpiredCache();
            echo json_encode(['success' => true, 'message' => 'Expired cache cleaned']);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action. Use: forecast, generation, summary']);
    }
} catch (Exception $e) {
    error_log("Weather API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error']);
}
