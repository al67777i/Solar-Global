<?php
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/csrf.php';
set_security_headers();
trackVisitor($pdo);

$site_name = get_system_setting('site_name', 'SolarGlobal');
$contact_email = get_system_setting('contact_email', 'info@solarglobal.com');
$contact_phone = get_system_setting('contact_phone', '');
$whatsapp_number = get_system_setting('whatsapp_number', '');
// Clean phone for tel: links (remove spaces, dashes)
$phone_clean = preg_replace('/[^+0-9]/', '', $contact_phone);
$whatsapp_clean = preg_replace('/[^0-9]/', '', $whatsapp_number);
$page_title = "Contact Us - $site_name Solar System Recommender";
$page_description = "Get in touch with $site_name for solar system recommendations, support, and inquiries. Contact us via WhatsApp, email, or phone.";
$page_keywords = "contact $site_name, solar support, solar inquiry, solar panel help";

// Handle form submission
$success_message = '';
$error_message = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid request. Please try again.';
    } else {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $subject = sanitize($_POST['subject'] ?? '');
    $message = sanitize($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($message)) {
        $error_message = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = 'Please enter a valid email address.';
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO contact_messages (name, email, phone, subject, message, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$name, $email, $phone, $subject, $message]);
            $success_message = 'Thank you for contacting us! We will get back to you soon.';

            // Clear form
            $_POST = [];
        } catch (Exception $e) {
            $error_message = 'Sorry, there was an error sending your message. Please try again or contact us directly via WhatsApp.';
        }
    }
    } // end CSRF else
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo $page_description; ?>">
    <meta name="keywords" content="<?php echo $page_keywords; ?>">
    <meta name="author" content="<?= htmlspecialchars($site_name) ?>">
    <meta name="robots" content="index, follow">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo getCurrentUrl(); ?>">
    <meta property="og:title" content="<?php echo $page_title; ?>">
    <meta property="og:description" content="<?php echo $page_description; ?>">

    <!-- Canonical URL -->
    <link rel="canonical" href="<?php echo getCurrentUrl(); ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="favicon.ico">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- PWA Meta -->
    <meta name="theme-color" content="#0D3B6E">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="mobile-web-app-capable" content="yes">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/frontend.css">
    <link rel="stylesheet" href="assets/css/mobile-app.css">

    <!-- Anime.js -->
    <script src="assets/js/anime.min.js"></script>

    <style>
        :root {
            --ct-primary: #0D3B6E;
            --ct-accent: #10B981;
            --ct-accent-dark: #059669;
            --ct-dark: #0a0f1a;
            --ct-dark-mid: #0f172a;
            --ct-text-light: #f8fafc;
            --ct-text-dark: #334155;
            --ct-text-muted: #64748B;
            --ct-bg-light: #f8fafc;
            --ct-white: #ffffff;
            --ct-shadow: 0 4px 24px rgba(0,0,0,0.08);
            --ct-shadow-lg: 0 12px 40px rgba(0,0,0,0.12);
            --ct-radius: 16px;
            --ct-radius-sm: 12px;
        }

        html { scroll-behavior: smooth; }

        /* ===== HERO ===== */
        .ct-hero {
            position: relative;
            min-height: 50vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            background: linear-gradient(160deg, var(--ct-dark) 0%, var(--ct-primary) 100%);
            overflow: hidden;
            padding: 100px 20px 80px;
        }

        .ct-hero::before {
            content: '';
            position: absolute;
            inset: 0;
            background-image:
                radial-gradient(circle at 20% 50%, rgba(16,185,129,0.08) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(13,59,110,0.15) 0%, transparent 50%);
        }

        .ct-hero::after {
            content: '';
            position: absolute;
            inset: 0;
            background-image:
                linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px);
            background-size: 60px 60px;
        }

        .ct-hero-dots {
            position: absolute;
            inset: 0;
            overflow: hidden;
            pointer-events: none;
        }

        .ct-dot {
            position: absolute;
            border-radius: 50%;
            background: rgba(16,185,129,0.15);
        }

        .ct-dot:nth-child(1) { width: 6px; height: 6px; top: 15%; left: 10%; }
        .ct-dot:nth-child(2) { width: 10px; height: 10px; top: 25%; left: 80%; }
        .ct-dot:nth-child(3) { width: 4px; height: 4px; top: 60%; left: 20%; }
        .ct-dot:nth-child(4) { width: 8px; height: 8px; top: 70%; left: 70%; }
        .ct-dot:nth-child(5) { width: 5px; height: 5px; top: 40%; left: 50%; }
        .ct-dot:nth-child(6) { width: 12px; height: 12px; top: 80%; left: 40%; background: rgba(13,59,110,0.2); }
        .ct-dot:nth-child(7) { width: 7px; height: 7px; top: 10%; left: 60%; }
        .ct-dot:nth-child(8) { width: 3px; height: 3px; top: 50%; left: 90%; }

        @keyframes ct-float {
            0%, 100% { transform: translateY(0) translateX(0); opacity: 0.4; }
            25% { transform: translateY(-20px) translateX(10px); opacity: 1; }
            50% { transform: translateY(-10px) translateX(-5px); opacity: 0.6; }
            75% { transform: translateY(-25px) translateX(8px); opacity: 0.9; }
        }

        .ct-hero-content {
            position: relative;
            z-index: 2;
            max-width: 700px;
        }

        .ct-hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(16,185,129,0.12);
            border: 1px solid rgba(16,185,129,0.25);
            padding: 8px 20px;
            border-radius: 50px;
            color: var(--ct-accent);
            font-size: 0.875rem;
            font-weight: 600;
            margin-bottom: 24px;
            opacity: 0;
            transform: translateY(30px);
        }

        .ct-hero h1 {
            font-size: 3rem;
            font-weight: 900;
            color: var(--ct-text-light);
            margin: 0 0 20px;
            line-height: 1.15;
            letter-spacing: -0.02em;
            opacity: 0;
            transform: translateY(30px);
        }

        .ct-hero-sub {
            font-size: 1.2rem;
            color: rgba(248,250,252,0.8);
            line-height: 1.7;
            margin: 0;
            opacity: 0;
            transform: translateY(30px);
        }

        @keyframes ct-fadeInUp {
            from { opacity: 0; transform: translateY(28px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ===== CONTACT SECTION ===== */
        .ct-section {
            padding: 80px 20px;
            background: var(--ct-bg-light);
        }

        .ct-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .ct-section-header {
            text-align: center;
            margin-bottom: 56px;
        }

        .ct-section-header h2 {
            font-size: 2rem;
            font-weight: 800;
            color: var(--ct-dark-mid);
            margin: 0 0 12px;
        }

        .ct-section-header p {
            font-size: 1.05rem;
            color: var(--ct-text-muted);
            margin: 0;
            line-height: 1.7;
        }

        .ct-grid {
            display: grid;
            grid-template-columns: 1fr 1.2fr;
            gap: 48px;
            align-items: start;
        }

        /* --- Info Cards --- */
        .ct-info-stack {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .ct-info-card {
            display: flex;
            align-items: flex-start;
            gap: 18px;
            background: var(--ct-white);
            border-radius: var(--ct-radius-sm);
            padding: 24px;
            border-left: 4px solid var(--ct-accent);
            box-shadow: var(--ct-shadow);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            opacity: 0;
            transform: translateY(20px);
        }

        .ct-info-card.ct-visible {
            opacity: 1;
            transform: translateY(0);
        }

        .ct-info-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--ct-shadow-lg);
        }

        .ct-info-card--whatsapp { border-left-color: #25D366; }
        .ct-info-card--email { border-left-color: #3B82F6; }
        .ct-info-card--phone { border-left-color: var(--ct-primary); }
        .ct-info-card--address { border-left-color: var(--ct-accent); }
        .ct-info-card--hours { border-left-color: #F59E0B; }

        .ct-info-icon {
            flex-shrink: 0;
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .ct-info-card--whatsapp .ct-info-icon { background: rgba(37,211,102,0.1); color: #25D366; }
        .ct-info-card--email .ct-info-icon { background: rgba(59,130,246,0.1); color: #3B82F6; }
        .ct-info-card--phone .ct-info-icon { background: rgba(13,59,110,0.1); color: var(--ct-primary); }
        .ct-info-card--address .ct-info-icon { background: rgba(16,185,129,0.1); color: var(--ct-accent); }
        .ct-info-card--hours .ct-info-icon { background: rgba(245,158,11,0.1); color: #F59E0B; }

        .ct-info-icon svg { width: 22px; height: 22px; }

        .ct-info-text h3 {
            font-size: 1rem;
            font-weight: 700;
            color: var(--ct-dark-mid);
            margin: 0 0 6px;
        }

        .ct-info-text p {
            font-size: 0.925rem;
            color: var(--ct-text-muted);
            margin: 0;
            line-height: 1.6;
        }

        .ct-info-text a {
            color: var(--ct-primary);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.2s;
        }

        .ct-info-text a:hover { color: var(--ct-accent); }

        .ct-wa-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #25D366;
            color: #fff;
            padding: 10px 22px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.875rem;
            margin-top: 10px;
            transition: all 0.3s ease;
        }

        .ct-wa-btn:hover { background: #1fad55; transform: translateY(-2px); }
        .ct-wa-btn svg { width: 18px; height: 18px; }

        /* --- Form Card --- */
        .ct-form-card {
            background: var(--ct-white);
            border-radius: var(--ct-radius);
            padding: 40px;
            box-shadow: var(--ct-shadow-lg);
        }

        .ct-form-title {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--ct-dark-mid);
            margin: 0 0 8px;
        }

        .ct-form-subtitle {
            font-size: 0.925rem;
            color: var(--ct-text-muted);
            margin: 0 0 28px;
            line-height: 1.6;
        }

        /* Alerts */
        .ct-alert {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px 20px;
            border-radius: var(--ct-radius-sm);
            margin-bottom: 24px;
            font-weight: 500;
            font-size: 0.925rem;
            animation: ct-fadeInUp 0.5s ease both;
        }

        .ct-alert svg { flex-shrink: 0; width: 22px; height: 22px; }

        .ct-alert--success {
            background: #ecfdf5;
            color: #065F46;
            border: 1px solid #a7f3d0;
        }

        .ct-alert--error {
            background: #fef2f2;
            color: #991B1B;
            border: 1px solid #fecaca;
        }

        /* Form fields */
        .ct-form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .ct-field {
            margin-bottom: 20px;
        }

        .ct-field label {
            display: block;
            font-weight: 600;
            font-size: 0.875rem;
            color: var(--ct-dark-mid);
            margin-bottom: 8px;
        }

        .ct-field label .ct-req { color: #EF4444; margin-left: 2px; }

        .ct-field input,
        .ct-field textarea,
        .ct-field select {
            width: 100%;
            padding: 12px 16px;
            border: 1.5px solid #e2e8f0;
            border-radius: 10px;
            font-size: 0.95rem;
            font-family: 'Inter', sans-serif;
            color: var(--ct-dark-mid);
            background: var(--ct-white);
            transition: border-color 0.25s ease, box-shadow 0.25s ease;
            box-sizing: border-box;
        }

        .ct-field input::placeholder,
        .ct-field textarea::placeholder {
            color: #94a3b8;
        }

        .ct-field input:focus,
        .ct-field textarea:focus,
        .ct-field select:focus {
            outline: none;
            border-color: var(--ct-accent);
            box-shadow: 0 0 0 3px rgba(16,185,129,0.15);
        }

        .ct-field textarea {
            min-height: 130px;
            resize: vertical;
        }

        .ct-submit-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            padding: 15px 32px;
            background: linear-gradient(135deg, var(--ct-accent) 0%, var(--ct-accent-dark) 100%);
            color: #fff;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 700;
            font-family: 'Inter', sans-serif;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .ct-submit-btn::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255,255,255,0.15) 0%, transparent 50%);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .ct-submit-btn:hover::before { opacity: 1; }

        .ct-submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(16,185,129,0.35);
        }

        .ct-submit-btn:active { transform: translateY(0); }

        .ct-submit-btn svg { width: 20px; height: 20px; }

        .ct-submit-btn.ct-loading .ct-btn-text { visibility: hidden; }
        .ct-submit-btn.ct-loading .ct-btn-icon { visibility: hidden; }

        .ct-submit-btn.ct-loading::after {
            content: '';
            position: absolute;
            width: 22px;
            height: 22px;
            border: 3px solid rgba(255,255,255,0.3);
            border-top-color: #fff;
            border-radius: 50%;
            animation: ct-spin 0.7s linear infinite;
        }

        @keyframes ct-spin { to { transform: rotate(360deg); } }

        /* ===== MAP SECTION ===== */
        .ct-map-section {
            padding: 80px 20px;
            background: var(--ct-white);
        }

        .ct-map-wrapper {
            position: relative;
            max-width: 1200px;
            margin: 0 auto;
        }

        .ct-map-frame {
            width: 100%;
            height: 450px;
            border: 0;
            border-radius: var(--ct-radius);
            box-shadow: var(--ct-shadow-lg);
        }

        .ct-map-overlay {
            position: relative;
            max-width: 480px;
            margin: -60px auto 0;
            background: var(--ct-white);
            border-radius: var(--ct-radius);
            padding: 28px 32px;
            box-shadow: var(--ct-shadow-lg);
            display: flex;
            align-items: flex-start;
            gap: 16px;
            z-index: 2;
        }

        .ct-map-pin {
            flex-shrink: 0;
            width: 48px;
            height: 48px;
            background: rgba(16,185,129,0.1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--ct-accent);
        }

        .ct-map-pin svg { width: 24px; height: 24px; }

        .ct-map-info h3 {
            font-size: 1.05rem;
            font-weight: 700;
            color: var(--ct-dark-mid);
            margin: 0 0 6px;
        }

        .ct-map-info p {
            font-size: 0.875rem;
            color: var(--ct-text-muted);
            margin: 0 0 14px;
            line-height: 1.6;
        }

        .ct-directions-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--ct-accent);
            text-decoration: none;
            padding: 8px 18px;
            border: 1.5px solid var(--ct-accent);
            border-radius: 8px;
            transition: all 0.25s ease;
        }

        .ct-directions-btn:hover {
            background: var(--ct-accent);
            color: #fff;
        }

        .ct-directions-btn svg { width: 16px; height: 16px; }

        /* ===== FAQ SECTION ===== */
        .ct-faq-section {
            padding: 80px 20px;
            background: var(--ct-bg-light);
        }

        .ct-faq-list {
            max-width: 800px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .ct-faq-item {
            background: var(--ct-white);
            border-radius: var(--ct-radius-sm);
            box-shadow: 0 2px 12px rgba(0,0,0,0.05);
            overflow: hidden;
            transition: box-shadow 0.3s ease;
        }

        .ct-faq-item:hover { box-shadow: var(--ct-shadow); }

        .ct-faq-q {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            width: 100%;
            padding: 20px 24px;
            border: none;
            background: none;
            font-size: 1rem;
            font-weight: 600;
            color: var(--ct-dark-mid);
            font-family: 'Inter', sans-serif;
            cursor: pointer;
            text-align: left;
            line-height: 1.5;
        }

        .ct-faq-q:hover { color: var(--ct-accent); }

        .ct-faq-chevron {
            flex-shrink: 0;
            width: 20px;
            height: 20px;
            color: var(--ct-text-muted);
            transition: transform 0.35s ease, color 0.2s;
        }

        .ct-faq-item.ct-open .ct-faq-chevron {
            transform: rotate(180deg);
            color: var(--ct-accent);
        }

        .ct-faq-a {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease, padding 0.3s ease;
        }

        .ct-faq-item.ct-open .ct-faq-a {
            max-height: 300px;
        }

        .ct-faq-a-inner {
            padding: 0 24px 20px;
            font-size: 0.925rem;
            color: var(--ct-text-muted);
            line-height: 1.7;
        }

        /* ===== CTA STRIP ===== */
        .ct-cta-strip {
            background: linear-gradient(135deg, var(--ct-dark) 0%, var(--ct-primary) 100%);
            padding: 48px 20px;
            text-align: center;
        }

        .ct-cta-strip h3 {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--ct-text-light);
            margin: 0 0 8px;
        }

        .ct-cta-strip p {
            font-size: 1rem;
            color: rgba(248,250,252,0.7);
            margin: 0 0 24px;
        }

        .ct-cta-wa {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: #25D366;
            color: #fff;
            padding: 14px 32px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .ct-cta-wa:hover { background: #1fad55; transform: translateY(-3px); box-shadow: 0 8px 24px rgba(37,211,102,0.35); }
        .ct-cta-wa svg { width: 22px; height: 22px; }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 900px) {
            .ct-grid {
                grid-template-columns: 1fr;
                gap: 40px;
            }

            .ct-form-row {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 640px) {
            .ct-hero { min-height: 40vh; padding: 80px 16px 60px; }
            .ct-hero h1 { font-size: 2rem; }
            .ct-hero-sub { font-size: 1rem; }
            .ct-section, .ct-map-section, .ct-faq-section { padding: 56px 16px; }
            .ct-form-card { padding: 28px 20px; }
            .ct-map-overlay { margin: -40px 16px 0; padding: 20px; flex-direction: column; }
            .ct-map-frame { height: 320px; }
            .ct-section-header h2 { font-size: 1.6rem; }
            .ct-cta-strip h3 { font-size: 1.25rem; }
        }
    </style>
</head>
<body>
    <?php include 'includes/header-nav.php'; ?>
    <?php include_once 'includes/ad_display.php'; ?>

    <?php renderAds('header'); ?>

    <!-- Hero Section -->
    <section class="ct-hero">
        <div class="ct-hero-dots">
            <span class="ct-dot"></span><span class="ct-dot"></span><span class="ct-dot"></span>
            <span class="ct-dot"></span><span class="ct-dot"></span><span class="ct-dot"></span>
            <span class="ct-dot"></span><span class="ct-dot"></span>
        </div>

        <!-- Animated floating shapes (anime.js) -->
        <svg class="ct-float-shape" id="ct-shape-1" style="position:absolute;top:10%;left:6%;opacity:0;z-index:1;" width="44" height="44" viewBox="0 0 44 44" fill="none">
            <rect x="4" y="4" width="36" height="36" rx="8" stroke="rgba(16,185,129,0.2)" stroke-width="1.5"/>
        </svg>
        <svg class="ct-float-shape" id="ct-shape-2" style="position:absolute;top:20%;right:10%;opacity:0;z-index:1;" width="52" height="52" viewBox="0 0 52 52" fill="none">
            <circle cx="26" cy="26" r="22" stroke="rgba(255,255,255,0.08)" stroke-width="1.5"/>
            <circle cx="26" cy="26" r="10" stroke="rgba(16,185,129,0.15)" stroke-width="1" fill="rgba(16,185,129,0.03)"/>
        </svg>
        <svg class="ct-float-shape" id="ct-shape-3" style="position:absolute;bottom:18%;left:12%;opacity:0;z-index:1;" width="36" height="36" viewBox="0 0 36 36" fill="none">
            <path d="M18 2L34 18L18 34L2 18Z" stroke="rgba(16,185,129,0.18)" stroke-width="1.5"/>
        </svg>
        <svg class="ct-float-shape" id="ct-shape-4" style="position:absolute;bottom:25%;right:15%;opacity:0;z-index:1;" width="30" height="30" viewBox="0 0 30 30" fill="none">
            <polygon points="15,2 28,28 2,28" stroke="rgba(255,255,255,0.1)" stroke-width="1.5"/>
        </svg>

        <div class="ct-hero-content">
            <div class="ct-hero-badge" id="ct-hero-badge">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
                We'd Love to Hear From You
            </div>
            <h1 id="ct-hero-title">Let's Talk Solar</h1>
            <p class="ct-hero-sub" id="ct-hero-sub">Have a question or need help? Reach out and our team will get back to you promptly.</p>
        </div>
    </section>

    <!-- Contact Info + Form Section -->
    <section class="ct-section">
        <div class="ct-container">
            <div class="ct-section-header">
                <h2>Get in Touch</h2>
                <p>Choose a convenient way to connect with our team</p>
            </div>
            <div class="ct-grid">
                <!-- Left: Contact Cards -->
                <div class="ct-info-stack">
                    <!-- WhatsApp -->
                    <div class="ct-info-card ct-info-card--whatsapp" data-ct-animate>
                        <div class="ct-info-icon">
                            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                        </div>
                        <div class="ct-info-text">
                            <h3>WhatsApp</h3>
                            <p>Chat with us instantly for quick support</p>
                            <a href="https://wa.me/<?= sanitize($whatsapp_clean ?: '923054957063') ?>" class="ct-wa-btn" target="_blank" rel="noopener">
                                <svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                                Chat on WhatsApp
                            </a>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="ct-info-card ct-info-card--email" data-ct-animate>
                        <div class="ct-info-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                        </div>
                        <div class="ct-info-text">
                            <h3>Email</h3>
                            <p>Send us a detailed inquiry anytime</p>
                            <a href="mailto:<?= sanitize($contact_email) ?>"><?= sanitize($contact_email) ?></a>
                        </div>
                    </div>

                    <!-- Phone -->
                    <div class="ct-info-card ct-info-card--phone" data-ct-animate>
                        <div class="ct-info-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                        </div>
                        <div class="ct-info-text">
                            <h3>Phone</h3>
                            <p>Call us during business hours</p>
                            <?php if (!empty($contact_phone)): ?>
                            <a href="tel:<?= sanitize($phone_clean) ?>"><?= sanitize($contact_phone) ?></a>
                            <?php else: ?>
                            <span style="color:#94A3B8;">Not configured</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Address -->
                    <div class="ct-info-card ct-info-card--address" data-ct-animate>
                        <div class="ct-info-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        </div>
                        <div class="ct-info-text">
                            <h3>Our Office</h3>
                            <p><strong>SolarGlobal Headquarters</strong><br>Kangniwala Main Kangni Wala Bazar, Mohalla Shama Ul Arfeen, Gujranwala, Pakistan</p>
                        </div>
                    </div>

                    <!-- Business Hours -->
                    <div class="ct-info-card ct-info-card--hours" data-ct-animate>
                        <div class="ct-info-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        </div>
                        <div class="ct-info-text">
                            <h3>Business Hours</h3>
                            <p>Monday &ndash; Saturday: 9:00 AM &ndash; 6:00 PM (PKT)<br>Sunday: Closed</p>
                        </div>
                    </div>
                </div>

                <!-- Right: Contact Form -->
                <div class="ct-form-card">
                    <h2 class="ct-form-title">Send Us a Message</h2>
                    <p class="ct-form-subtitle">Fill out the form below and we'll respond within 24 hours.</p>

                    <?php if ($success_message): ?>
                        <div class="ct-alert ct-alert--success">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($error_message): ?>
                        <div class="ct-alert ct-alert--error">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
                            <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="" id="ctContactForm">
                        <?= csrf_field() ?>
                        <div class="ct-form-row">
                            <div class="ct-field">
                                <label>Full Name <span class="ct-req">*</span></label>
                                <input type="text" name="name" required placeholder="Your name" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                            </div>
                            <div class="ct-field">
                                <label>Email Address <span class="ct-req">*</span></label>
                                <input type="email" name="email" required placeholder="you@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="ct-form-row">
                            <div class="ct-field">
                                <label>Phone Number</label>
                                <input type="tel" name="phone" placeholder="+92 300 0000000" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                            </div>
                            <div class="ct-field">
                                <label>Subject</label>
                                <select name="subject">
                                    <option value="General Inquiry" <?php echo ($_POST['subject'] ?? '') === 'General Inquiry' ? 'selected' : ''; ?>>General Inquiry</option>
                                    <option value="Solar System Recommendation" <?php echo ($_POST['subject'] ?? '') === 'Solar System Recommendation' ? 'selected' : ''; ?>>Solar System Recommendation</option>
                                    <option value="Technical Support" <?php echo ($_POST['subject'] ?? '') === 'Technical Support' ? 'selected' : ''; ?>>Technical Support</option>
                                    <option value="Partnership" <?php echo ($_POST['subject'] ?? '') === 'Partnership' ? 'selected' : ''; ?>>Partnership Opportunity</option>
                                    <option value="Feedback" <?php echo ($_POST['subject'] ?? '') === 'Feedback' ? 'selected' : ''; ?>>Feedback</option>
                                    <option value="Other" <?php echo ($_POST['subject'] ?? '') === 'Other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="ct-field">
                            <label>Message <span class="ct-req">*</span></label>
                            <textarea name="message" required placeholder="Tell us how we can help..."><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
                        </div>
                        <button type="submit" class="ct-submit-btn" id="ctSubmitBtn">
                            <span class="ct-btn-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                            </span>
                            <span class="ct-btn-text">Send Message</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Map Section -->
    <section class="ct-map-section">
        <div class="ct-container">
            <div class="ct-section-header">
                <h2>Visit Our Office</h2>
                <p>We welcome walk-in visitors during business hours</p>
            </div>
            <div class="ct-map-wrapper">
                <iframe
                    class="ct-map-frame"
                    src="https://www.google.com/maps/embed/v1/place?key=<?= sanitize(get_system_setting('google_maps_api_key', '')) ?>&q=Kangniwala+Main+Kangni+Wala+Bazar+Gujranwala+Pakistan&zoom=15"
                    allowfullscreen
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"
                ></iframe>
                <div class="ct-map-overlay">
                    <div class="ct-map-pin">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    </div>
                    <div class="ct-map-info">
                        <h3>SolarGlobal Headquarters</h3>
                        <p>Kangniwala Main Kangni Wala Bazar, Mohalla Shama Ul Arfeen, Gujranwala, Pakistan</p>
                        <a href="https://www.google.com/maps/search/Kangniwala+Main+Kangni+Wala+Bazar+Gujranwala+Pakistan" class="ct-directions-btn" target="_blank" rel="noopener">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>
                            Get Directions
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="ct-faq-section">
        <div class="ct-container">
            <div class="ct-section-header">
                <h2>Frequently Asked Questions</h2>
                <p>Quick answers to common questions about <?= htmlspecialchars($site_name) ?></p>
            </div>
            <div class="ct-faq-list">
                <div class="ct-faq-item">
                    <button class="ct-faq-q" type="button">
                        How does <?= htmlspecialchars($site_name) ?>'s recommendation work?
                        <svg class="ct-faq-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="ct-faq-a"><div class="ct-faq-a-inner">Our smart solar calculator analyzes your energy consumption, location, roof specifications, and budget to recommend the optimal solar panel system. We use data from hundreds of verified solar products and local dealers to provide accurate, personalized recommendations.</div></div>
                </div>
                <div class="ct-faq-item">
                    <button class="ct-faq-q" type="button">
                        Is the solar calculator free to use?
                        <svg class="ct-faq-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="ct-faq-a"><div class="ct-faq-a-inner">Yes, absolutely! <?= htmlspecialchars($site_name) ?>'s solar system calculator and all recommendation tools are completely free. We believe everyone should have access to transparent solar information to make informed decisions about their energy future.</div></div>
                </div>
                <div class="ct-faq-item">
                    <button class="ct-faq-q" type="button">
                        Can I customize the recommended system?
                        <svg class="ct-faq-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="ct-faq-a"><div class="ct-faq-a-inner">Absolutely. After receiving your initial recommendation, you can adjust panel types, inverter brands, battery options, and system size. Our platform lets you compare different configurations side-by-side so you can find the perfect balance of performance and budget.</div></div>
                </div>
                <div class="ct-faq-item">
                    <button class="ct-faq-q" type="button">
                        How do I find solar dealers near me?
                        <svg class="ct-faq-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="ct-faq-a"><div class="ct-faq-a-inner">Use our Dealer Finder tool to search by city or area. We list verified solar dealers with their ratings, contact information, and product offerings. You can reach out to them directly through our platform or visit their locations.</div></div>
                </div>
                <div class="ct-faq-item">
                    <button class="ct-faq-q" type="button">
                        What payment methods do dealers accept?
                        <svg class="ct-faq-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="ct-faq-a"><div class="ct-faq-a-inner">Payment methods vary by dealer. Most accept bank transfers, cash payments, and installment plans. Some dealers offer financing options. We recommend contacting your chosen dealer directly to discuss payment options and any available financing plans.</div></div>
                </div>
                <div class="ct-faq-item">
                    <button class="ct-faq-q" type="button">
                        How can I become a dealer on <?= htmlspecialchars($site_name) ?>?
                        <svg class="ct-faq-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="ct-faq-a"><div class="ct-faq-a-inner">We welcome new dealers to join our growing network. Simply reach out to us through the contact form above or via WhatsApp, and our partnership team will guide you through the registration process. We verify all dealers to ensure quality service for our users.</div></div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Strip -->
    <section class="ct-cta-strip">
        <h3>Still Have Questions?</h3>
        <p>Chat with us on WhatsApp for an instant response</p>
        <a href="https://wa.me/<?= sanitize($whatsapp_clean ?: '923054957063') ?>" class="ct-cta-wa" target="_blank" rel="noopener">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            Chat on WhatsApp
        </a>
    </section>

    <?php renderAds('footer'); ?>

    <?php include 'includes/footer.php'; ?>

    <!-- Schema.org Structured Data -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "ContactPage",
        "name": "Contact <?= $site_name ?>",
        "description": "Contact <?= $site_name ?> for solar system recommendations and support",
        "url": "<?php echo getCurrentUrl(); ?>",
        "mainEntity": {
            "@type": "Organization",
            "name": "<?= $site_name ?>",
            "telephone": "<?= sanitize($phone_clean ?: '+923054957063') ?>",
            "email": "<?= sanitize($contact_email) ?>",
            "address": {
                "@type": "PostalAddress",
                "name": "SolarGlobal Headquarters",
                "streetAddress": "Kangniwala Main Kangni Wala Bazar, Mohalla Shama Ul Arfeen",
                "addressLocality": "Gujranwala",
                "addressRegion": "Punjab",
                "postalCode": "52250",
                "addressCountry": "PK"
            },
            "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
                "opens": "09:00",
                "closes": "18:00"
            }
        }
    }
    </script>

    <script>
    (function() {
        'use strict';

        // ═══════════════════════════════════════════
        // HERO ENTRANCE — anime.js timeline
        // ═══════════════════════════════════════════
        var heroTL = anime.timeline({ easing: 'easeOutExpo' });

        heroTL.add({
            targets: '#ct-hero-badge',
            opacity: [0, 1],
            translateY: [40, 0],
            duration: 900
        })
        .add({
            targets: '#ct-hero-title',
            opacity: [0, 1],
            translateY: [50, 0],
            scale: [0.95, 1],
            duration: 1000
        }, '-=600')
        .add({
            targets: '#ct-hero-sub',
            opacity: [0, 1],
            translateY: [30, 0],
            duration: 800
        }, '-=500');

        // ═══════════════════════════════════════════
        // FLOATING SHAPES — continuous animation
        // ═══════════════════════════════════════════
        anime({
            targets: '#ct-shape-1',
            opacity: [0, 0.6],
            translateY: ['0px', '-15px'],
            rotate: [0, 12],
            duration: 4500,
            delay: 400,
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });
        anime({
            targets: '#ct-shape-2',
            opacity: [0, 0.5],
            translateY: ['0px', '18px'],
            rotate: [0, -15],
            scale: [1, 1.08],
            duration: 5500,
            delay: 700,
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });
        anime({
            targets: '#ct-shape-3',
            opacity: [0, 0.5],
            translateX: ['0px', '12px'],
            translateY: ['0px', '-10px'],
            rotate: [0, 45],
            duration: 6000,
            delay: 200,
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });
        anime({
            targets: '#ct-shape-4',
            opacity: [0, 0.45],
            translateY: ['0px', '-16px'],
            rotate: [0, -30],
            duration: 5000,
            delay: 1000,
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });

        // ═══════════════════════════════════════════
        // DOTS — staggered floating with anime.js
        // ═══════════════════════════════════════════
        anime({
            targets: '.ct-dot',
            translateY: function() { return anime.random(-25, 25) + 'px'; },
            translateX: function() { return anime.random(-15, 15) + 'px'; },
            opacity: [0.15, 0.7],
            scale: [0.8, 1.3],
            duration: function() { return anime.random(3000, 5500); },
            delay: anime.stagger(250),
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutQuad'
        });

        // ═══════════════════════════════════════════
        // SCROLL ANIMATIONS — info cards, form, map
        // ═══════════════════════════════════════════
        var animateCards = document.querySelectorAll('[data-ct-animate]');
        if (animateCards.length && 'IntersectionObserver' in window) {
            var cardObserver = new IntersectionObserver(function(entries) {
                var visible = [];
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        visible.push(entry.target);
                        cardObserver.unobserve(entry.target);
                    }
                });
                if (visible.length > 0) {
                    anime({
                        targets: visible,
                        opacity: [0, 1],
                        translateY: [35, 0],
                        scale: [0.97, 1],
                        delay: anime.stagger(100),
                        duration: 700,
                        easing: 'easeOutCubic'
                    });
                }
            }, { threshold: 0.1 });

            animateCards.forEach(function(card) {
                card.style.opacity = '0';
                card.style.transform = 'translateY(35px)';
                cardObserver.observe(card);
            });
        } else {
            animateCards.forEach(function(card) { card.classList.add('ct-visible'); });
        }

        // Section headers
        document.querySelectorAll('.ct-section-header, .ct-map-title, .ct-faq-title').forEach(function(el) {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            var obs = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        anime({
                            targets: entry.target,
                            opacity: [0, 1],
                            translateY: [20, 0],
                            duration: 700,
                            easing: 'easeOutCubic'
                        });
                        obs.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.2 });
            obs.observe(el);
        });

        // ═══════════════════════════════════════════
        // FAQ Accordion
        // ═══════════════════════════════════════════
        document.querySelectorAll('.ct-faq-q').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var item = this.closest('.ct-faq-item');
                var isOpen = item.classList.contains('ct-open');
                document.querySelectorAll('.ct-faq-item.ct-open').forEach(function(el) {
                    el.classList.remove('ct-open');
                });
                if (!isOpen) item.classList.add('ct-open');
            });
        });

        // ═══════════════════════════════════════════
        // Submit button loading state
        // ═══════════════════════════════════════════
        var form = document.getElementById('ctContactForm');
        if (form) {
            form.addEventListener('submit', function() {
                var btn = document.getElementById('ctSubmitBtn');
                if (btn) btn.classList.add('ct-loading');
            });
        }
    })();
    </script>
</body>
</html>
