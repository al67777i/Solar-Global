<?php
/**
 * AJAX endpoint - Get installer reviews for admin moderation
 * GET: ?installer_id=X - returns reviews for that installer
 * POST: action=approve|reject, review_id=X - moderate a review
 */
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/csrf.php';

header('Content-Type: application/json');

$db = getDB();

// Handle POST (approve/reject review)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }

    $action = $input['action'] ?? '';
    $reviewId = intval($input['review_id'] ?? 0);

    if (!in_array($action, ['approve', 'reject'])) {
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
        exit;
    }

    if ($reviewId <= 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid review ID']);
        exit;
    }

    $newStatus = $action === 'approve' ? 'approved' : 'rejected';

    try {
        $stmt = $db->prepare("UPDATE installer_reviews SET status = ? WHERE id = ?");
        $stmt->execute([$newStatus, $reviewId]);

        // If approved, update the installer's avg_rating and total_reviews
        if ($action === 'approve') {
            $stmt = $db->prepare("
                UPDATE installers i SET
                    avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM installer_reviews WHERE installer_id = i.id AND status = 'approved'),
                    total_reviews = (SELECT COUNT(*) FROM installer_reviews WHERE installer_id = i.id AND status = 'approved')
                WHERE i.id = (SELECT installer_id FROM installer_reviews WHERE id = ?)
            ");
            $stmt->execute([$reviewId]);
        }

        echo json_encode(['success' => true, 'status' => $newStatus]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

// Handle GET - fetch reviews
$installerId = intval($_GET['installer_id'] ?? 0);

if ($installerId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid installer ID']);
    exit;
}

try {
    $stmt = $db->prepare("
        SELECT id, reviewer_name, reviewer_email, rating, title, review_text,
               project_type, system_size_kw, status, verified, created_at
        FROM installer_reviews
        WHERE installer_id = ?
        ORDER BY created_at DESC
        LIMIT 50
    ");
    $stmt->execute([$installerId]);
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'reviews' => $reviews
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
