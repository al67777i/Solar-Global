<?php
/**
 * Add Products to Dealer Store
 * Search-based catalog browser with country/company filters
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

set_security_headers();
require_dealer_login();
require_dealer_subscription();

$dealer = get_dealer_profile();
$db = getDB();

// Dealer's currency info
$dealer_country = $dealer['country_code'] ?? '';
$dealer_currency = get_country_currency_info($dealer_country);

// ─── AJAX: Search products ───────────────────────────────────────────
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    header('Content-Type: application/json');

    $tab = $_GET['type'] ?? 'inverter';
    if (!in_array($tab, ['inverter', 'battery', 'panel', 'installation_appliance'])) {
        echo json_encode(['success' => false, 'error' => 'Invalid product type']);
        exit;
    }

    $search = trim($_GET['q'] ?? '');
    $company_id = (int)($_GET['company_id'] ?? 0);
    $country = trim($_GET['country'] ?? '');
    $category = trim($_GET['category'] ?? '');
    $limit = 15;
    $has_filter = ($search !== '' && mb_strlen($search) >= 3) || $company_id > 0 || $country !== '';

    // Get already-added IDs — exclude them from results
    $existing = $db->prepare("SELECT product_id FROM dealer_products WHERE dealer_id = ? AND product_type = ?");
    $existing->execute([$dealer['id'], $tab]);
    $existing_ids = $existing->fetchAll(PDO::FETCH_COLUMN);

    $params = [];
    $where = [];

    // Build exclude clause for already-added products
    $exclude_clause = '';
    if (!empty($existing_ids)) {
        $placeholders = implode(',', array_fill(0, count($existing_ids), '?'));
    }

    if ($tab === 'inverter') {
        $sql_base = "SELECT i.*, COALESCE(c.name, i.company) AS company_name, c.country AS company_country FROM inverters i LEFT JOIN companies c ON i.company_id = c.id";
        $where[] = "i.is_active = 1";
        if (!empty($existing_ids)) {
            $where[] = "i.id NOT IN ($placeholders)";
            $params = array_merge($params, $existing_ids);
        }
        if ($search !== '' && mb_strlen($search) >= 3) {
            $where[] = "(i.model LIKE ? OR i.company LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        if ($company_id > 0) {
            $where[] = "i.company_id = ?";
            $params[] = $company_id;
        }
        if ($country !== '') {
            $where[] = "c.country = ?";
            $params[] = $country;
        }
        $order = $has_filter ? "ORDER BY i.company, i.output_power_w" : "ORDER BY RAND()";
        $count_sql = "SELECT COUNT(*) FROM inverters i LEFT JOIN companies c ON i.company_id = c.id WHERE " . implode(' AND ', $where);
        $sql = "$sql_base WHERE " . implode(' AND ', $where) . " $order LIMIT $limit";
    } elseif ($tab === 'battery') {
        $sql_base = "SELECT b.*, COALESCE(c.name, b.brand) AS company_name, c.country AS company_country FROM batteries b LEFT JOIN companies c ON b.company_id = c.id";
        $where[] = "b.is_active = 1";
        if (!empty($existing_ids)) {
            $where[] = "b.id NOT IN ($placeholders)";
            $params = array_merge($params, $existing_ids);
        }
        if ($search !== '' && mb_strlen($search) >= 3) {
            $where[] = "(b.model LIKE ? OR b.brand LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        if ($company_id > 0) {
            $where[] = "b.company_id = ?";
            $params[] = $company_id;
        }
        if ($country !== '') {
            $where[] = "c.country = ?";
            $params[] = $country;
        }
        $order = $has_filter ? "ORDER BY b.brand, b.capacity_ah" : "ORDER BY RAND()";
        $count_sql = "SELECT COUNT(*) FROM batteries b LEFT JOIN companies c ON b.company_id = c.id WHERE " . implode(' AND ', $where);
        $sql = "$sql_base WHERE " . implode(' AND ', $where) . " $order LIMIT $limit";
    } elseif ($tab === 'panel') {
        $sql_base = "SELECT p.*, COALESCE(c.name, p.brand) AS company_name, c.country AS company_country FROM panels p LEFT JOIN companies c ON p.company_id = c.id";
        $where[] = "p.is_active = 1";
        if (!empty($existing_ids)) {
            $where[] = "p.id NOT IN ($placeholders)";
            $params = array_merge($params, $existing_ids);
        }
        if ($search !== '' && mb_strlen($search) >= 3) {
            $where[] = "(p.name LIKE ? OR p.brand LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        if ($company_id > 0) {
            $where[] = "p.company_id = ?";
            $params[] = $company_id;
        }
        if ($country !== '') {
            $where[] = "c.country = ?";
            $params[] = $country;
        }
        $order = $has_filter ? "ORDER BY p.brand, p.wattage" : "ORDER BY RAND()";
        $count_sql = "SELECT COUNT(*) FROM panels p LEFT JOIN companies c ON p.company_id = c.id WHERE " . implode(' AND ', $where);
        $sql = "$sql_base WHERE " . implode(' AND ', $where) . " $order LIMIT $limit";
    } else {
        // installation_appliance — filter by category
        $sql_base = "SELECT ia.*, COALESCE(c.name, ia.brand) AS company_name, c.country AS company_country FROM installation_appliances ia LEFT JOIN companies c ON ia.company_id = c.id";
        $where[] = "ia.is_active = 1";
        if (!empty($existing_ids)) {
            $where[] = "ia.id NOT IN ($placeholders)";
            $params = array_merge($params, $existing_ids);
        }
        if ($category !== '') {
            $where[] = "ia.category = ?";
            $params[] = $category;
            $has_filter = true;
        }
        if ($search !== '' && mb_strlen($search) >= 3) {
            $where[] = "(ia.name LIKE ? OR ia.brand LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        $order = $has_filter ? "ORDER BY ia.category, ia.name" : "ORDER BY ia.category, ia.name";
        $count_sql = "SELECT COUNT(*) FROM installation_appliances ia LEFT JOIN companies c ON ia.company_id = c.id WHERE " . implode(' AND ', $where);
        $sql = "$sql_base WHERE " . implode(' AND ', $where) . " $order LIMIT $limit";
    }

    // Get total count
    $stmt = $db->prepare($count_sql);
    $stmt->execute($params);
    $total = (int)$stmt->fetchColumn();

    // Get products
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $products = [];
    foreach ($rows as $item) {
        $specs = [];
        if ($tab === 'inverter') {
            $specs = [
                'power_rating' => ($item['power_rating'] ?? 0) . 'W',
                'type' => $item['type'] ?? 'hybrid',
                'vdc_type' => $item['vdc_type'] ?? '48V',
                'mppt_channels' => ($item['mppt_channels'] ?? 2) . ' MPPT',
            ];
        } elseif ($tab === 'battery') {
            $specs = [
                'capacity' => ($item['capacity_ah'] ?? 0) . 'Ah',
                'voltage' => ($item['nominal_voltage'] ?? 0) . 'V',
                'type' => strtoupper($item['type'] ?? 'lfp'),
                'cycle_life' => ($item['cycle_life'] ?? '?') . ' cycles',
            ];
        } elseif ($tab === 'panel') {
            $specs = [
                'wattage' => ($item['wattage'] ?? 0) . 'W',
                'type' => strtoupper($item['type'] ?? 'mono'),
                'efficiency' => ($item['efficiency'] ?? '?') . '% eff',
            ];
        } else {
            $specs = [
                'category' => $item['category'] ?? 'General',
            ];
        }
        if (isset($item['warranty_years'])) {
            $specs['warranty'] = ($item['warranty_years'] ?? '?') . 'yr warranty';
        }

        $usd_price = ($tab === 'battery') ? (float)($item['price_unit_usd'] ?? 0) : (float)($item['price_usd'] ?? 0);
        $item_name = ($tab === 'battery') ? ($item['model'] ?? '') : ($item['name'] ?? '');
        $products[] = [
            'id' => (int)$item['id'],
            'name' => $item_name,
            'brand' => $item['company_name'] ?? $item['brand'],
            'price_usd' => $usd_price,
            'price_local' => convert_usd_to_local($usd_price, $dealer_country),
            'specs' => $specs,
        ];
    }

    echo json_encode(['success' => true, 'products' => $products, 'total' => $total]);
    exit;
}

// ─── AJAX: Add product ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Invalid security token. Please refresh the page.']);
            exit;
        }
    }

    $product_type = $_POST['product_type'] ?? '';
    $product_id = (int)($_POST['product_id'] ?? 0);
    $dealer_price_local = floatval($_POST['dealer_price'] ?? 0);
    // Convert local currency price to USD for storage
    $dealer_price = convert_local_to_usd($dealer_price_local, $dealer_country);
    $stock_qty = max(0, (int)($_POST['stock_quantity'] ?? 0));
    $error = '';
    $success = '';

    if (!in_array($product_type, ['inverter', 'battery', 'panel', 'installation_appliance'])) {
        $error = 'Invalid product type.';
    } elseif ($product_id <= 0) {
        $error = 'Invalid product.';
    } elseif ($dealer_price_local <= 0) {
        $error = 'Price must be greater than 0.';
    } else {
        $stmt = $db->prepare("SELECT id FROM dealer_products WHERE dealer_id = ? AND product_type = ? AND product_id = ?");
        $stmt->execute([$dealer['id'], $product_type, $product_id]);
        if ($stmt->fetch()) {
            $error = 'This product is already in your store.';
        } else {
            $stock_status = $stock_qty > 5 ? 'in_stock' : ($stock_qty > 0 ? 'low_stock' : 'out_of_stock');
            $tableMap = ['inverter' => 'inverters', 'battery' => 'batteries', 'panel' => 'panels', 'installation_appliance' => 'installation_appliances'];
            $base_table = $tableMap[$product_type];
            $stmt = $db->prepare("SELECT price_usd FROM $base_table WHERE id = ?");
            $stmt->execute([$product_id]);
            $base = $stmt->fetch();
            $original_price = $base ? $base['price_usd'] : null;

            $stmt = $db->prepare("
                INSERT INTO dealer_products (dealer_id, product_type, product_id, dealer_price,
                    currency, original_price, stock_quantity, stock_status, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
            ");
            $stmt->execute([$dealer['id'], $product_type, $product_id, $dealer_price, $dealer_currency['currency_code'], $original_price, $stock_qty, $stock_status]);
            $success = 'Product added to your store!';
        }
    }

    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => $error === '',
            'message' => $error === '' ? $success : $error,
        ]);
        exit;
    }
}

// ─── Load companies per product type for filters ────────────────────
$companies_stmt = $db->query("
    SELECT c.id, c.name, c.country,
        (SELECT COUNT(*) FROM inverters WHERE company_id = c.id AND is_active = 1) AS inverter_count,
        (SELECT COUNT(*) FROM batteries WHERE company_id = c.id AND is_active = 1) AS battery_count,
        (SELECT COUNT(*) FROM panels WHERE company_id = c.id AND is_active = 1) AS panel_count,
        (SELECT COUNT(*) FROM installation_appliances WHERE company_id = c.id AND is_active = 1) AS ia_count
    FROM companies c WHERE c.is_active = 1 ORDER BY c.name
");
$companies = $companies_stmt->fetchAll(PDO::FETCH_ASSOC);

// Distinct company countries for product filter
$countries_stmt = $db->query("SELECT DISTINCT country FROM companies WHERE country IS NOT NULL AND country != '' AND is_active = 1 ORDER BY country");
$company_countries = $countries_stmt->fetchAll(PDO::FETCH_COLUMN);

// Installation appliance categories
$ia_categories_stmt = $db->query("SELECT DISTINCT category FROM installation_appliances WHERE is_active = 1 ORDER BY category");
$ia_categories = $ia_categories_stmt->fetchAll(PDO::FETCH_COLUMN);

// Get product counts for tab labels
$tab_counts = [];
try {
    $tab_counts['inverter'] = (int)$db->query("SELECT COUNT(*) FROM inverters WHERE is_active = 1")->fetchColumn();
    $tab_counts['battery'] = (int)$db->query("SELECT COUNT(*) FROM batteries WHERE is_active = 1")->fetchColumn();
    $tab_counts['panel'] = (int)$db->query("SELECT COUNT(*) FROM panels WHERE is_active = 1")->fetchColumn();
    $tab_counts['installation_appliance'] = (int)$db->query("SELECT COUNT(*) FROM installation_appliances WHERE is_active = 1")->fetchColumn();
} catch (Exception $e) {
    $tab_counts = ['inverter' => 0, 'battery' => 0, 'panel' => 0, 'installation_appliance' => 0];
}

// Generate CSRF token for JS
$csrf_token = $_SESSION['csrf_token'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Products - <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        .container { max-width: 100%; padding: 0; }

        /* Tabs */
        .tabs {
            display: flex; gap: 4px; margin-bottom: 20px; background: white;
            border-radius: 10px; padding: 4px; box-shadow: 0 1px 4px rgba(0,0,0,0.05);
        }
        .tab {
            flex: 1; padding: 10px; text-align: center; border-radius: 8px;
            text-decoration: none; font-weight: 600; font-size: 0.875rem;
            color: #64748B; transition: all 0.2s; cursor: pointer; border: none;
            background: transparent;
        }
        .tab.active { background: #1565C0; color: white; }
        .tab:hover:not(.active) { background: #F1F5F9; }

        /* Filter bar */
        .filter-bar {
            display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap;
            align-items: stretch;
        }
        .filter-bar select,
        .filter-bar input[type="text"] {
            padding: 10px 14px; border: 2px solid #E2E8F0; border-radius: 8px;
            font-size: 0.875rem; font-family: inherit; background: white;
            transition: border-color 0.2s;
        }
        .filter-bar select:focus,
        .filter-bar input[type="text"]:focus { outline: none; border-color: #1565C0; }
        .filter-bar input[type="text"] { flex: 1; min-width: 200px; }
        .filter-bar select { min-width: 160px; }
        .btn-search {
            padding: 10px 24px; background: #1565C0; color: white; border: none;
            border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.875rem;
            transition: background 0.2s;
        }
        .btn-search:hover { background: #0D47A1; }
        .btn-clear {
            padding: 10px 16px; background: #E2E8F0; color: #475569; border: none;
            border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.875rem;
            transition: background 0.2s;
        }
        .btn-clear:hover { background: #CBD5E1; }

        /* Empty state */
        .empty-state {
            text-align: center; padding: 60px 20px; background: white;
            border-radius: 12px; border: 2px dashed #CBD5E1;
        }
        .empty-state .icon { font-size: 3rem; margin-bottom: 16px; opacity: 0.5; }
        .empty-state h3 { font-size: 1.125rem; color: #1E293B; margin-bottom: 8px; }
        .empty-state p { color: #64748B; font-size: 0.875rem; max-width: 400px; margin: 0 auto; line-height: 1.5; }

        /* Loading spinner */
        .loading {
            text-align: center; padding: 40px;
        }
        .spinner {
            width: 40px; height: 40px; border: 4px solid #E2E8F0;
            border-top-color: #1565C0; border-radius: 50%;
            animation: spin 0.8s linear infinite; margin: 0 auto 12px;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        .loading p { color: #64748B; font-size: 0.875rem; }

        /* Results info */
        .results-info {
            font-size: 0.875rem; color: #64748B; margin-bottom: 16px;
            display: flex; justify-content: space-between; align-items: center;
        }

        /* Product grid */
        .catalog-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 16px;
        }
        .catalog-card {
            background: white; border-radius: 12px; padding: 20px;
            border: 2px solid #E2E8F0; transition: all 0.2s; position: relative;
        }
        .catalog-card:hover { border-color: #1565C0; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }

        .cc-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
        .cc-brand { font-size: 0.75rem; font-weight: 600; color: #1565C0; text-transform: uppercase; }
        .cc-base-price { font-size: 0.875rem; color: #64748B; }
        .cc-name { font-size: 1rem; font-weight: 700; color: #1E293B; margin-bottom: 8px; }

        .cc-specs {
            display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px;
        }
        .cc-spec {
            padding: 3px 10px; background: #F1F5F9; border-radius: 6px;
            font-size: 0.75rem; color: #475569; font-weight: 500;
        }

        .cc-add-form { display: flex; gap: 8px; flex-wrap: wrap; align-items: end; }
        .cc-add-form .fg { flex: 1; min-width: 100px; }
        .cc-add-form label { display: block; font-size: 0.75rem; font-weight: 600; color: #64748B; margin-bottom: 4px; }
        .cc-add-form input {
            width: 100%; padding: 8px 10px; border: 1px solid #E2E8F0;
            border-radius: 6px; font-size: 0.875rem;
        }
        .btn-add-product {
            padding: 8px 20px; background: #F59E0B; color: #1E293B; border: none;
            border-radius: 6px; font-weight: 700; font-size: 0.875rem; cursor: pointer;
            white-space: nowrap; transition: background 0.2s;
        }
        .btn-add-product:hover { background: #D97706; }
        .btn-add-product:disabled { opacity: 0.5; cursor: not-allowed; }

        /* Toast */
        .toast {
            position: fixed; bottom: 24px; right: 24px; padding: 14px 24px;
            border-radius: 10px; font-size: 0.875rem; font-weight: 600;
            color: white; z-index: 9999; transform: translateY(100px);
            opacity: 0; transition: all 0.3s ease; max-width: 360px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.15);
        }
        .toast.show { transform: translateY(0); opacity: 1; }
        .toast.success { background: #16A34A; }
        .toast.error { background: #DC2626; }

        /* Responsive */
        @media (max-width: 640px) {
            .top-bar { padding: 12px 16px; }
            .container { padding: 0 12px; }
            .filter-bar { flex-direction: column; }
            .filter-bar select,
            .filter-bar input[type="text"] { min-width: 100%; }
            .catalog-grid { grid-template-columns: 1fr; }
            .tabs { flex-wrap: wrap; }
            .tab { min-width: calc(50% - 4px); }
        }
    </style>
</head>
<body>
    <?php $current_dealer_page = 'add-products'; include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="dlr-main-content">
        <div class="dlr-page-header">
            <div class="dlr-page-header-left">
                <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
                <h1>&#10133; Add Products to Your Store</h1>
            </div>
            <div></div>
        </div>

        <div class="container">
        <!-- Product type tabs -->
        <div class="tabs">
            <button class="tab active" data-type="inverter">&#9889; Inverters (<?= $tab_counts['inverter'] ?>)</button>
            <button class="tab" data-type="battery">&#128267; Batteries (<?= $tab_counts['battery'] ?>)</button>
            <button class="tab" data-type="panel">&#9728; Panels (<?= $tab_counts['panel'] ?>)</button>
            <button class="tab" data-type="installation_appliance">&#128268; Installation (<?= $tab_counts['installation_appliance'] ?>)</button>
        </div>

        <!-- Filters for inverter/battery/panel -->
        <div class="filter-bar" id="filterBarProducts">
            <select id="filterCountry">
                <option value="">-- All Countries --</option>
                <?php foreach ($company_countries as $cc): ?>
                    <option value="<?= sanitize($cc) ?>"><?= sanitize($cc) ?></option>
                <?php endforeach; ?>
            </select>
            <select id="filterCompany">
                <option value="">-- All Companies --</option>
            </select>
            <input type="text" id="filterSearch" placeholder="Search by name or brand...">
            <button class="btn-search" id="btnSearch">Search</button>
            <button class="btn-clear" id="btnClear">Clear</button>
        </div>

        <!-- Filters for installation appliances (category-based) -->
        <div class="filter-bar" id="filterBarIA" style="display:none;">
            <select id="filterCategory">
                <option value="">-- All Categories --</option>
                <?php foreach ($ia_categories as $cat): ?>
                    <option value="<?= sanitize($cat) ?>"><?= ucwords(str_replace('_', ' ', $cat)) ?></option>
                <?php endforeach; ?>
            </select>
            <input type="text" id="filterSearchIA" placeholder="Search installation items...">
            <button class="btn-search" id="btnSearchIA">Search</button>
            <button class="btn-clear" id="btnClearIA">Clear</button>
        </div>

        <!-- Results area -->
        <div id="resultsArea">
            <div class="loading">
                <div class="spinner"></div>
                <p>Loading products...</p>
            </div>
        </div>
    </div>

    <!-- Toast notification -->
    <div class="toast" id="toast"></div>

    <script>
    (function() {
        var CSRF_TOKEN = <?= json_encode($csrf_token) ?>;
        var ALL_COMPANIES = <?= json_encode($companies) ?>;
        var CURRENCY_SYMBOL = <?= json_encode($dealer_currency['currency_symbol']) ?>;
        var CURRENCY_CODE = <?= json_encode($dealer_currency['currency_code']) ?>;
        var EXCHANGE_RATE = <?= json_encode($dealer_currency['exchange_rate']) ?>;

        var currentTab = 'inverter';
        var isLoading = false;

        // Elements
        var tabs = document.querySelectorAll('.tab');
        var filterBarProducts = document.getElementById('filterBarProducts');
        var filterBarIA = document.getElementById('filterBarIA');
        var countrySelect = document.getElementById('filterCountry');
        var companySelect = document.getElementById('filterCompany');
        var searchInput = document.getElementById('filterSearch');
        var btnSearch = document.getElementById('btnSearch');
        var btnClear = document.getElementById('btnClear');
        var categorySelect = document.getElementById('filterCategory');
        var searchInputIA = document.getElementById('filterSearchIA');
        var btnSearchIA = document.getElementById('btnSearchIA');
        var btnClearIA = document.getElementById('btnClearIA');
        var resultsArea = document.getElementById('resultsArea');
        var toast = document.getElementById('toast');

        // ── Map tab type to company count field ──
        var typeCountKey = {
            'inverter': 'inverter_count',
            'battery': 'battery_count',
            'panel': 'panel_count',
            'installation_appliance': 'ia_count'
        };

        // ── Populate company dropdown for current tab + country ──
        function populateCompanies() {
            var key = typeCountKey[currentTab];
            var selectedCountry = countrySelect.value || '';
            var prevCompany = companySelect.value;
            companySelect.innerHTML = '<option value="">-- All Companies --</option>';
            var filtered = ALL_COMPANIES.filter(function(c) {
                if (parseInt(c[key] || 0) <= 0) return false;
                if (selectedCountry && c.country !== selectedCountry) return false;
                return true;
            });
            filtered.sort(function(a, b) { return a.name.localeCompare(b.name); });
            filtered.forEach(function(c) {
                var opt = document.createElement('option');
                opt.value = c.id;
                opt.textContent = c.name + ' (' + c[key] + ')';
                companySelect.appendChild(opt);
            });
            // Restore previous selection if still available
            if (prevCompany) {
                companySelect.value = prevCompany;
                if (companySelect.value !== prevCompany) companySelect.value = '';
            }
        }

        // ── Toggle filter bars based on tab ──
        function updateFilterBars() {
            if (currentTab === 'installation_appliance') {
                filterBarProducts.style.display = 'none';
                filterBarIA.style.display = 'flex';
            } else {
                filterBarProducts.style.display = 'flex';
                filterBarIA.style.display = 'none';
                populateCompanies();
            }
        }

        // ── Tab switching ──
        tabs.forEach(function(t) {
            t.addEventListener('click', function() {
                tabs.forEach(function(x) { x.classList.remove('active'); });
                t.classList.add('active');
                currentTab = t.dataset.type;
                updateFilterBars();
                doSearch();
            });
        });

        // ── Product tab events ──
        countrySelect.addEventListener('change', function() { populateCompanies(); doSearch(); });
        companySelect.addEventListener('change', function() { doSearch(); });
        btnSearch.addEventListener('click', function() { doSearch(); });
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') { e.preventDefault(); doSearch(); }
        });
        btnClear.addEventListener('click', function() {
            countrySelect.value = '';
            companySelect.value = '';
            searchInput.value = '';
            populateCompanies();
            doSearch();
        });

        // ── Installation tab events ──
        categorySelect.addEventListener('change', function() { doSearch(); });
        btnSearchIA.addEventListener('click', function() { doSearch(); });
        searchInputIA.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') { e.preventDefault(); doSearch(); }
        });
        btnClearIA.addEventListener('click', function() {
            categorySelect.value = '';
            searchInputIA.value = '';
            doSearch();
        });

        // ── Show loading ──
        function showLoading() {
            resultsArea.innerHTML =
                '<div class="loading">' +
                    '<div class="spinner"></div>' +
                    '<p>Loading products...</p>' +
                '</div>';
        }

        // ── Toast notification ──
        function showToast(msg, type) {
            toast.textContent = msg;
            toast.className = 'toast ' + type + ' show';
            setTimeout(function() { toast.classList.remove('show'); }, 3000);
        }

        // ── Escape HTML ──
        function esc(str) {
            var d = document.createElement('div');
            d.textContent = str || '';
            return d.innerHTML;
        }

        // ── AJAX search ──
        function doSearch() {
            if (isLoading) return;
            isLoading = true;
            showLoading();

            var params = 'ajax=1&type=' + encodeURIComponent(currentTab);

            if (currentTab === 'installation_appliance') {
                var q = searchInputIA.value.trim();
                var cat = categorySelect.value || '';
                if (q) params += '&q=' + encodeURIComponent(q);
                if (cat) params += '&category=' + encodeURIComponent(cat);
            } else {
                var q = searchInput.value.trim();
                var companyId = companySelect.value || '';
                var country = countrySelect.value || '';
                if (q) params += '&q=' + encodeURIComponent(q);
                if (companyId) params += '&company_id=' + encodeURIComponent(companyId);
                if (country) params += '&country=' + encodeURIComponent(country);
            }

            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'add-products.php?' + params, true);
            xhr.onload = function() {
                isLoading = false;
                if (xhr.status === 200) {
                    try {
                        var data = JSON.parse(xhr.responseText);
                        if (data.success) {
                            renderResults(data.products, data.total);
                        } else {
                            showToast(data.error || 'Search failed.', 'error');
                            resultsArea.innerHTML = '<div class="empty-state"><div class="icon">&#128533;</div><h3>Error</h3><p>' + esc(data.error || 'Unknown error') + '</p></div>';
                        }
                    } catch(e) {
                        console.error('AJAX parse error:', e, xhr.responseText.substring(0, 200));
                        showToast('Invalid response from server.', 'error');
                        resultsArea.innerHTML = '<div class="empty-state"><div class="icon">&#128533;</div><h3>Error</h3><p>Could not load products. Try refreshing the page.</p></div>';
                    }
                } else {
                    showToast('Server error (' + xhr.status + ').', 'error');
                }
            };
            xhr.onerror = function() {
                isLoading = false;
                showToast('Network error.', 'error');
            };
            xhr.send();
        }

        // ── Render product results ──
        function renderResults(products, total) {
            if (!products || products.length === 0) {
                resultsArea.innerHTML =
                    '<div class="empty-state">' +
                        '<div class="icon">&#9989;</div>' +
                        '<h3>All products added!</h3>' +
                        '<p>You\'ve already added all available products in this category, or no products match your filter.</p>' +
                    '</div>';
                return;
            }

            var showing = products.length;
            var html = '<div class="results-info"><span>Showing ' + showing + ' of ' + total + ' results</span></div>';
            html += '<div class="catalog-grid">';

            products.forEach(function(p) {
                var localPrice = Number(p.price_local || (p.price_usd * EXCHANGE_RATE));
                html += '<div class="catalog-card" id="card-' + p.id + '">';
                html += '<div class="cc-header">';
                html += '<span class="cc-brand">' + esc(p.brand) + '</span>';
                html += '<span class="cc-base-price">Base: ' + CURRENCY_SYMBOL + ' ' + localPrice.toLocaleString(undefined, {minimumFractionDigits:0, maximumFractionDigits:0}) + '</span>';
                html += '</div>';
                html += '<div class="cc-name">' + esc(p.name) + '</div>';
                html += '<div class="cc-specs">';
                if (p.specs) {
                    for (var key in p.specs) {
                        html += '<span class="cc-spec">' + esc(p.specs[key]) + '</span>';
                    }
                }
                html += '</div>';
                html += '<form class="cc-add-form" onsubmit="return window._addProduct(event, this, ' + p.id + ')">';
                html += '<input type="hidden" name="product_type" value="' + esc(currentTab) + '">';
                html += '<input type="hidden" name="product_id" value="' + p.id + '">';
                html += '<div class="fg">';
                html += '<label>Your Price (' + esc(CURRENCY_CODE) + ')</label>';
                html += '<input type="number" name="dealer_price" value="' + localPrice.toFixed(2) + '" step="0.01" min="0.01" required>';
                html += '</div>';
                html += '<div class="fg">';
                html += '<label>Stock Qty</label>';
                html += '<input type="number" name="stock_quantity" value="10" min="0" required>';
                html += '</div>';
                html += '<button type="submit" class="btn-add-product">+ Add</button>';
                html += '</form>';
                html += '</div>';
            });

            html += '</div>';
            resultsArea.innerHTML = html;
        }

        // ── AJAX add product ──
        window._addProduct = function(e, form, productId) {
            e.preventDefault();
            var btn = form.querySelector('.btn-add-product');
            btn.disabled = true;
            btn.textContent = 'Adding...';

            var formData = new FormData(form);
            formData.append('csrf_token', CSRF_TOKEN);

            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'add-products.php', true);
            xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            xhr.onload = function() {
                if (xhr.status === 200) {
                    try {
                        var data = JSON.parse(xhr.responseText);
                        if (data.success) {
                            showToast(data.message || 'Product added!', 'success');
                            var card = document.getElementById('card-' + productId);
                            if (card) {
                                card.style.transition = 'opacity 0.3s, transform 0.3s';
                                card.style.opacity = '0';
                                card.style.transform = 'scale(0.95)';
                                setTimeout(function() { card.remove(); }, 300);
                            }
                        } else {
                            showToast(data.message || 'Failed to add.', 'error');
                            btn.disabled = false;
                            btn.textContent = '+ Add';
                        }
                    } catch(ex) {
                        showToast('Invalid response.', 'error');
                        btn.disabled = false;
                        btn.textContent = '+ Add';
                    }
                } else {
                    showToast('Server error.', 'error');
                    btn.disabled = false;
                    btn.textContent = '+ Add';
                }
            };
            xhr.onerror = function() {
                showToast('Network error.', 'error');
                btn.disabled = false;
                btn.textContent = '+ Add';
            };
            xhr.send(formData);
            return false;
        };

        // ── Init: populate companies for default tab and load products ──
        updateFilterBars();
        doSearch();

    })();
    </script>
    </main>
</body>
</html>
