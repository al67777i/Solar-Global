<?php
require_once 'includes/db.php';
require_once 'includes/helpers.php';
set_security_headers();
trackVisitor($pdo);

// Anti-scraping
if (is_bot_request() && !rate_limit('bot_appliances_' . ($_SERVER['REMOTE_ADDR'] ?? ''), 10, 60)) {
    http_response_code(429);
    echo '<h1>429 Too Many Requests</h1>';
    exit;
}
if (!rate_limit('page_appliances_' . ($_SERVER['REMOTE_ADDR'] ?? ''), 60, 60)) {
    http_response_code(429);
    echo '<h1>429 Too Many Requests</h1><p>Please slow down.</p>';
    exit;
}

$current_page = 'appliances';

// ─── Filters ─────────────────────────────────────────────────────────
$search = trim($_GET['search'] ?? '');
$category = $_GET['category'] ?? '';
$sort = $_GET['sort'] ?? 'category';
$page_num = max(1, (int) ($_GET['page'] ?? 1));
$per_page = 24;
$offset = ($page_num - 1) * $per_page;

// ─── Get all categories ──────────────────────────────────────────────
$categories = $pdo->query("SELECT DISTINCT category FROM appliances WHERE is_active = 1 ORDER BY category ASC")->fetchAll(PDO::FETCH_COLUMN);

// ─── Build query ─────────────────────────────────────────────────────
$where = ["is_active = 1"];
$params = [];

if ($search) {
    $where[] = "(name_en LIKE ? OR category LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($category) {
    $where[] = "category = ?";
    $params[] = $category;
}

$where_sql = implode(' AND ', $where);

// Count
$cntStmt = $pdo->prepare("SELECT COUNT(*) FROM appliances WHERE $where_sql");
$cntStmt->execute($params);
$total = (int) $cntStmt->fetchColumn();
$total_pages = max(1, ceil($total / $per_page));

// Sort
$order_map = [
    'category' => 'category ASC, name_en ASC',
    'name' => 'name_en ASC',
    'watt_asc' => 'watt_typical ASC',
    'watt_desc' => 'watt_typical DESC',
];
$order_by = $order_map[$sort] ?? 'category ASC, name_en ASC';

// Fetch
$stmt = $pdo->prepare("SELECT * FROM appliances WHERE $where_sql ORDER BY $order_by LIMIT $per_page OFFSET $offset");
$stmt->execute($params);
$appliances = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Stats
$total_all = (int) $pdo->query("SELECT COUNT(*) FROM appliances WHERE is_active = 1")->fetchColumn();
$total_cats = count($categories);
$avg_watt = (int) $pdo->query("SELECT ROUND(AVG(watt_typical)) FROM appliances WHERE is_active = 1")->fetchColumn();

// Category counts for the grid
$cat_counts = [];
$catStmt = $pdo->query("
    SELECT category, COUNT(*) as cnt, MIN(watt_typical) as min_w, MAX(watt_typical) as max_w,
           ROUND(AVG(watt_typical)) as avg_w
    FROM appliances WHERE is_active = 1 GROUP BY category ORDER BY category ASC
");
$cat_counts = $catStmt->fetchAll(PDO::FETCH_ASSOC);

// Category icons
$cat_icons = [
    'Cooling' => '❄️',
    'Lighting' => '💡',
    'Kitchen' => '🍳',
    'Entertainment' => '📺',
    'Electronics' => '💻',
    'Laundry' => '👕',
    'Heating' => '🔥',
    'Water Heating' => '🚿',
    'Security' => '🔒',
    'Ventilation' => '🌀',
    'Outdoor' => '🌿',
    'Health' => '❤️',
    'Utility' => '🔧',
    'Appliances' => '🏠',
];

// ─── SEO ─────────────────────────────────────────────────────────────
$site_name = get_system_setting('site_name', 'SolarGlobal');
if ($category) {
    $page_title = "$category Solar Appliances - Power Requirements | $site_name";
    $page_description = "Browse $category appliances and their power requirements for solar system sizing. Find wattage, surge load, and usage data.";
} else {
    $page_title = "Solar Appliances Guide - Power Requirements & Wattage | $site_name";
    $page_description = "Complete guide to household appliance power requirements for solar system planning. Browse $total_all appliances across $total_cats categories.";
}
$page_keywords = "solar appliances, appliance wattage, power requirements, solar system sizing, household power consumption";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>

    <meta name="description" content="<?= htmlspecialchars($page_description) ?>">
    <meta name="keywords" content="<?= htmlspecialchars($page_keywords) ?>">
    <meta name="author" content="<?= htmlspecialchars($site_name) ?>">
    <meta name="robots" content="index, follow">

    <meta property="og:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($page_description) ?>">
    <meta property="og:url" content="<?= htmlspecialchars(getCurrentUrl()) ?>">

    <link rel="canonical" href="<?= htmlspecialchars(getBaseUrl() . '/appliances') ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <meta name="theme-color" content="#0D3B6E">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/frontend.css">
    <link rel="stylesheet" href="assets/css/products.css">
    <link rel="stylesheet" href="assets/css/mobile-app.css">

    <!-- JSON-LD -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": <?= json_encode($page_title) ?>,
        "description": <?= json_encode($page_description) ?>,
        "url": <?= json_encode(getCurrentUrl()) ?>,
        "isPartOf": { "@type": "WebSite", "name": <?= json_encode($site_name) ?>, "url": <?= json_encode(getBaseUrl() . '/') ?> },
        "breadcrumb": {
            "@type": "BreadcrumbList",
            "itemListElement": [
                {"@type":"ListItem","position":1,"name":"Home","item":<?= json_encode(getBaseUrl() . '/') ?>},
                {"@type":"ListItem","position":2,"name":"Appliances","item":<?= json_encode(getBaseUrl() . '/appliances.php') ?>}
                <?php if ($category): ?>,{"@type":"ListItem","position":3,"name":<?= json_encode($category) ?>,"item":<?= json_encode(getCurrentUrl()) ?>}<?php endif; ?>
            ]
        },
        "numberOfItems": <?= $total ?>
    }
    </script>

    <style>
        /* ── Hero ─────────────────────────────────────────────────── */
        .app-hero {
            background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%);
            padding: 48px 0 40px;
        }

        .app-hero-inner {
            max-width: 1280px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .app-hero .breadcrumb {
            margin-bottom: 16px;
        }

        .app-hero .breadcrumb a {
            color: #94A3B8;
            text-decoration: none;
            font-size: 0.85rem;
        }

        .app-hero .breadcrumb a:hover {
            color: #F59E0B;
        }

        .app-hero .breadcrumb span {
            color: #64748B;
            font-size: 0.85rem;
        }

        .app-hero h1 {
            font-size: 2rem;
            font-weight: 800;
            color: #fff;
            margin: 0 0 8px;
        }

        .app-hero .hero-sub {
            font-size: 1.05rem;
            color: #94A3B8;
            margin: 0 0 24px;
        }

        .app-hero-stats {
            display: flex;
            gap: 32px;
            flex-wrap: wrap;
        }

        .app-hero-stat-val {
            font-size: 1.5rem;
            font-weight: 800;
            color: #F59E0B;
            display: block;
        }

        .app-hero-stat-lbl {
            font-size: 0.8rem;
            color: #94A3B8;
            display: block;
            margin-top: 2px;
        }

        /* ── Search Bar ───────────────────────────────────────────── */
        .app-search-bar {
            background: #F8FAFC;
            border-bottom: 1px solid #E2E8F0;
            padding: 12px 0;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .app-search-inner {
            max-width: 1280px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .app-search-input {
            flex: 1;
            min-width: 200px;
            padding: 10px 16px;
            border: 1.5px solid #CBD5E1;
            border-radius: 10px;
            font-size: 0.9rem;
            font-family: inherit;
            background: #fff;
            color: #1E293B;
            outline: none;
        }

        .app-search-input:focus {
            border-color: #F59E0B;
            box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.15);
        }

        .app-cat-select {
            padding: 10px 14px;
            border: 1.5px solid #CBD5E1;
            border-radius: 10px;
            font-size: 0.9rem;
            font-family: inherit;
            background: #fff;
            color: #1E293B;
            cursor: pointer;
        }

        .app-cat-select:focus {
            border-color: #F59E0B;
            box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.15);
            outline: none;
        }

        /* ── Category Grid ────────────────────────────────────────── */
        .cat-section {
            max-width: 1280px;
            margin: 0 auto;
            padding: 40px 20px 60px;
        }

        .cat-section h2 {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1E293B;
            margin: 0 0 8px;
        }

        .cat-section .subtitle {
            font-size: 0.95rem;
            color: #64748B;
            margin: 0 0 32px;
        }

        .cat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 20px;
        }

        .cat-card {
            background: #fff;
            border: 1px solid #E2E8F0;
            border-radius: 14px;
            padding: 24px;
            display: flex;
            flex-direction: column;
            gap: 14px;
            transition: all 0.2s;
            text-decoration: none;
            color: inherit;
            cursor: pointer;
        }

        .cat-card:hover {
            border-color: #F59E0B;
            box-shadow: 0 8px 24px rgba(245, 158, 11, 0.10);
            transform: translateY(-3px);
        }

        .cat-card-header {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .cat-card-icon {
            font-size: 2.2rem;
            line-height: 1;
            width: 56px;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #F8FAFC;
            border-radius: 12px;
            border: 1px solid #E2E8F0;
            flex-shrink: 0;
        }

        .cat-card-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: #1E293B;
        }

        .cat-card-count {
            font-size: 0.8rem;
            color: #64748B;
            margin-top: 2px;
        }

        .cat-card-stats {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .cat-stat {
            background: #F8FAFC;
            border-radius: 8px;
            padding: 8px 12px;
            flex: 1;
            min-width: 80px;
        }

        .cat-stat-value {
            font-size: 0.95rem;
            font-weight: 700;
            color: #F59E0B;
            display: block;
        }

        .cat-stat-label {
            font-size: 0.7rem;
            color: #64748B;
            display: block;
            margin-top: 2px;
        }

        .cat-card-action {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 0.9rem;
            font-weight: 600;
            color: #F59E0B;
            margin-top: auto;
        }

        .cat-card-action .arrow {
            transition: transform 0.2s;
        }

        .cat-card:hover .cat-card-action .arrow {
            transform: translateX(4px);
        }

        /* ── Appliance Cards ──────────────────────────────────────── */
        .app-products {
            max-width: 1280px;
            margin: 0 auto;
            padding: 20px 20px 60px;
        }

        .app-back-link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 0.9rem;
            color: #64748B;
            text-decoration: none;
            margin-bottom: 24px;
        }

        .app-back-link:hover {
            color: #F59E0B;
        }

        .app-results-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 24px;
        }

        .app-results-header h2 {
            font-size: 1.25rem;
            font-weight: 700;
            color: #1E293B;
            margin: 0;
        }

        .app-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
        }

        .app-card {
            background: #fff;
            border: 1px solid #E2E8F0;
            border-radius: 14px;
            padding: 0;
            overflow: hidden;
            transition: all 0.2s;
        }

        .app-card:hover {
            border-color: #F59E0B;
            box-shadow: 0 8px 24px rgba(245, 158, 11, 0.10);
            transform: translateY(-2px);
        }

        .app-card-top {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 20px 20px 0;
        }

        .app-card-icon {
            font-size: 2.5rem;
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #F1F5F9;
            border-radius: 12px;
            flex-shrink: 0;
        }

        .app-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #1E293B;
        }

        .app-card-cat {
            font-size: 0.78rem;
            color: #64748B;
            margin-top: 2px;
        }

        .app-card-specs {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 8px;
            padding: 16px 20px;
        }

        .app-spec {
            background: #F8FAFC;
            border-radius: 8px;
            padding: 10px 12px;
        }

        .app-spec-label {
            font-size: 0.7rem;
            color: #94A3B8;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: block;
        }

        .app-spec-value {
            font-size: 0.95rem;
            font-weight: 700;
            color: #1E293B;
            display: block;
            margin-top: 2px;
        }

        .app-spec-value.highlight {
            color: #F59E0B;
        }

        .app-card-tags {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
            padding: 0 20px 16px;
        }

        .app-tag {
            font-size: 0.72rem;
            font-weight: 600;
            padding: 3px 10px;
            border-radius: 20px;
            background: #F1F5F9;
            color: #64748B;
        }

        .app-tag.summer {
            background: #FEF3C7;
            color: #92400E;
        }

        .app-tag.winter {
            background: #DBEAFE;
            color: #1E40AF;
        }

        .app-tag.year {
            background: #DCFCE7;
            color: #166534;
        }

        .app-card-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 20px;
            border-top: 1px solid #F1F5F9;
            background: #FAFBFC;
        }

        .app-watt-main {
            font-size: 1.3rem;
            font-weight: 800;
            color: #F59E0B;
        }

        .app-watt-label {
            font-size: 0.72rem;
            color: #94A3B8;
        }

        .app-use-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            background: linear-gradient(135deg, #F59E0B, #D97706);
            color: #fff;
            border-radius: 8px;
            font-size: 0.82rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s;
        }

        .app-use-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
        }

        /* ── Responsive ───────────────────────────────────────────── */
        @media (max-width: 768px) {
            .app-hero h1 {
                font-size: 1.5rem;
            }

            .app-hero-stats {
                gap: 20px;
            }

            .cat-grid {
                grid-template-columns: 1fr;
            }

            .app-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 480px) {
            .cat-grid {
                grid-template-columns: 1fr;
            }

            .app-card-specs {
                grid-template-columns: 1fr;
            }
        }

        /* Anti-scraping */
        .app-spec-value,
        .app-watt-main {
            user-select: none;
            -webkit-user-select: none;
        }
    </style>
</head>

<body>
    <?php include 'includes/header-nav.php'; ?>
    <?php include_once 'includes/ad_display.php'; ?>
    <?php renderAds('header'); ?>

    <!-- Hero Section -->
    <div class="app-hero">
        <div class="app-hero-inner">
            <div class="breadcrumb">
                <a href="<?= BASE_URL ?>">Home</a> <span>/</span>
                <?php if ($category): ?>
                    <a href="<?= BASE_URL ?>appliances.php">Appliances</a> <span>/</span>
                    <span><?= htmlspecialchars($category) ?></span>
                <?php else: ?>
                    <span>Appliances</span>
                <?php endif; ?>
            </div>

            <h1>
                <?php if ($category): ?>
                    <?= htmlspecialchars($category) ?> Appliances
                <?php else: ?>
                    Solar Appliance Guide
                <?php endif; ?>
            </h1>

            <p class="hero-sub">
                <?php if ($category): ?>
                    Browse <?= number_format($total) ?> appliances in <?= htmlspecialchars($category) ?> category
                <?php else: ?>
                    Power requirements for <?= number_format($total_all) ?> common household appliances across
                    <?= $total_cats ?> categories
                <?php endif; ?>
            </p>

            <div class="app-hero-stats">
                <div>
                    <span class="app-hero-stat-val"><?= number_format($total_all) ?></span>
                    <span class="app-hero-stat-lbl">Appliances</span>
                </div>
                <div>
                    <span class="app-hero-stat-val"><?= $total_cats ?></span>
                    <span class="app-hero-stat-lbl">Categories</span>
                </div>
                <div>
                    <span class="app-hero-stat-val"><?= number_format($avg_watt) ?>W</span>
                    <span class="app-hero-stat-lbl">Avg. Power</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Search / Filter Bar -->
    <div class="app-search-bar">
        <form class="app-search-inner" method="GET" action="<?= BASE_URL ?>appliances.php">
            <input type="text" name="search" class="app-search-input" placeholder="Search appliances..."
                value="<?= htmlspecialchars($search) ?>">
            <select name="category" class="app-cat-select" onchange="this.form.submit()">
                <option value="">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>>
                        <?= htmlspecialchars($cat) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="sort" class="app-cat-select" onchange="this.form.submit()">
                <option value="category" <?= $sort === 'category' ? 'selected' : '' ?>>By Category</option>
                <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>Name A→Z</option>
                <option value="watt_asc" <?= $sort === 'watt_asc' ? 'selected' : '' ?>>Watts: Low→High</option>
                <option value="watt_desc" <?= $sort === 'watt_desc' ? 'selected' : '' ?>>Watts: High→Low</option>
            </select>
            <button type="submit"
                style="padding:10px 20px;background:linear-gradient(135deg,#F59E0B,#D97706);color:#fff;border:none;border-radius:10px;font-weight:600;font-size:0.88rem;cursor:pointer;">Search</button>
            <?php if ($search || $category): ?>
                <a href="<?= BASE_URL ?>appliances.php"
                    style="font-size:0.78rem;color:#DC2626;text-decoration:none;font-weight:600;">&#10005; Clear</a>
            <?php endif; ?>
        </form>
    </div>

    <?php if (!$category && !$search): ?>
        <!-- ═══ VIEW 1: Category Grid (no category selected) ═══ -->
        <div class="cat-section">
            <h2>Browse by Category</h2>
            <p class="subtitle">Select a category to explore appliance power requirements</p>

            <div class="cat-grid">
                <?php foreach ($cat_counts as $cc): ?>
                    <a class="cat-card" href="<?= BASE_URL ?>appliances.php?category=<?= urlencode($cc['category']) ?>">
                        <div class="cat-card-header">
                            <div class="cat-card-icon"><?= $cat_icons[$cc['category']] ?? '⚡' ?></div>
                            <div>
                                <div class="cat-card-title"><?= htmlspecialchars($cc['category']) ?></div>
                                <div class="cat-card-count"><?= (int) $cc['cnt'] ?> appliances</div>
                            </div>
                        </div>
                        <div class="cat-card-stats">
                            <div class="cat-stat">
                                <span class="cat-stat-value"><?= number_format($cc['min_w']) ?>W</span>
                                <span class="cat-stat-label">Min</span>
                            </div>
                            <div class="cat-stat">
                                <span class="cat-stat-value"><?= number_format($cc['max_w']) ?>W</span>
                                <span class="cat-stat-label">Max</span>
                            </div>
                            <div class="cat-stat">
                                <span class="cat-stat-value"><?= number_format($cc['avg_w']) ?>W</span>
                                <span class="cat-stat-label">Avg</span>
                            </div>
                        </div>
                        <div class="cat-card-action">
                            Browse Appliances <span class="arrow">&rarr;</span>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

    <?php else: ?>
        <!-- ═══ VIEW 2: Appliance Cards (category or search active) ═══ -->
        <div class="app-products">
            <?php if ($category): ?>
                <a href="<?= BASE_URL ?>appliances.php" class="app-back-link">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="15 18 9 12 15 6" />
                    </svg>
                    Back to all categories
                </a>
            <?php endif; ?>

            <div class="app-results-header">
                <h2>
                    <?php if ($category): ?>
                        <?= htmlspecialchars($category) ?> &mdash; <?= number_format($total) ?>
                        appliance<?= $total !== 1 ? 's' : '' ?>
                    <?php elseif ($search): ?>
                        Search: "<?= htmlspecialchars($search) ?>" &mdash; <?= number_format($total) ?>
                        result<?= $total !== 1 ? 's' : '' ?>
                    <?php else: ?>
                        All Appliances &mdash; <?= number_format($total) ?> items
                    <?php endif; ?>
                </h2>
            </div>

            <?php if (empty($appliances)): ?>
                <div style="text-align:center; padding:60px 20px;">
                    <div style="font-size:3rem; margin-bottom:16px;">🔍</div>
                    <h3 style="color:#1E293B; margin:0 0 8px;">No appliances found</h3>
                    <p style="color:#64748B;">Try adjusting your search or category filter.</p>
                    <a href="<?= BASE_URL ?>appliances.php"
                        style="display:inline-block;margin-top:16px;padding:10px 24px;background:linear-gradient(135deg,#F59E0B,#D97706);color:#fff;border-radius:10px;font-weight:600;text-decoration:none;">View
                        All</a>
                </div>
            <?php else: ?>
                <div class="app-grid">
                    <?php foreach ($appliances as $idx => $app):
                        if ($idx > 0 && $idx % 8 === 0)
                            echo getInlineAdHtml('sidebar');

                        $icon = $app['icon'] ?: ($cat_icons[$app['category']] ?? '⚡');
                        $season = $app['season_tags'] ?? 'all_year';
                        $summer_h = $app['usage_hours_summer'] ?? 4;
                        $winter_h = $app['usage_hours_winter'] ?? 4;
                        $surge = $app['surge_load_watts'] ?? 0;
                        $standby = $app['standby_watts'] ?? 0;
                        $daily_kwh_summer = round(($app['watt_typical'] * $summer_h) / 1000, 2);
                        $daily_kwh_winter = round(($app['watt_typical'] * $winter_h) / 1000, 2);
                        ?>
                        <div class="app-card">
                            <div class="app-card-top">
                                <div class="app-card-icon"><?= $icon ?></div>
                                <div>
                                    <div class="app-card-title"><?= htmlspecialchars($app['name_en']) ?></div>
                                    <div class="app-card-cat"><?= htmlspecialchars($app['category']) ?></div>
                                </div>
                            </div>

                            <div class="app-card-specs">
                                <div class="app-spec">
                                    <span class="app-spec-label">Typical</span>
                                    <span class="app-spec-value highlight"><?= number_format($app['watt_typical']) ?>W</span>
                                </div>
                                <?php if ($surge > 0): ?>
                                    <div class="app-spec">
                                        <span class="app-spec-label">Surge</span>
                                        <span class="app-spec-value"><?= number_format($surge) ?>W</span>
                                    </div>
                                <?php else: ?>
                                    <div class="app-spec">
                                        <span class="app-spec-label">Standby</span>
                                        <span class="app-spec-value"><?= $standby > 0 ? number_format($standby) . 'W' : '—' ?></span>
                                    </div>
                                <?php endif; ?>
                                <div class="app-spec">
                                    <span class="app-spec-label">Summer Use</span>
                                    <span class="app-spec-value"><?= $summer_h ?>h/day</span>
                                </div>
                                <div class="app-spec">
                                    <span class="app-spec-label">Winter Use</span>
                                    <span class="app-spec-value"><?= $winter_h ?>h/day</span>
                                </div>
                            </div>

                            <div class="app-card-tags">
                                <?php if (str_contains($season, 'summer')): ?>
                                    <span class="app-tag summer">☀️ Summer</span>
                                <?php elseif (str_contains($season, 'winter')): ?>
                                    <span class="app-tag winter">❄️ Winter</span>
                                <?php else: ?>
                                    <span class="app-tag year">🔄 All Year</span>
                                <?php endif; ?>
                                <span class="app-tag">~<?= $daily_kwh_summer ?> kWh/day</span>
                                <?php if ($surge > 0): ?>
                                    <span class="app-tag" style="background:#FEE2E2;color:#991B1B;">⚡ High Surge</span>
                                <?php endif; ?>
                            </div>

                            <div class="app-card-footer">
                                <div>
                                    <span class="app-watt-main"><?= number_format($app['watt_typical']) ?>W</span>
                                    <span class="app-watt-label">typical load</span>
                                </div>
                                <a href="<?= BASE_URL ?>index.php#calculator" class="app-use-btn">
                                    Use in Calculator →
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Load More -->
                <?php $qp = array_filter($_GET, fn($k) => $k !== 'page', ARRAY_FILTER_USE_KEY); ?>
                <div style="text-align:center; margin-top:32px;">
                    <p style="color:#64748B;font-size:0.85rem;margin-bottom:12px;">Showing
                        <?= min($page_num * $per_page, $total) ?> of <?= $total ?> appliance<?= $total !== 1 ? 's' : '' ?></p>
                    <?php if ($page_num < $total_pages): ?>
                        <a href="?<?= http_build_query(array_merge($qp, ['page' => $page_num + 1])) ?>"
                            style="display:inline-flex;align-items:center;gap:8px;padding:12px 32px;background:linear-gradient(135deg,#F59E0B,#D97706);color:#fff;border-radius:10px;font-weight:700;font-size:0.9rem;text-decoration:none;box-shadow:0 4px 15px rgba(245,158,11,0.3);">
                            Load More <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2">
                                <polyline points="6 9 12 15 18 9" />
                            </svg>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php renderAds('footer'); ?>

    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": <?= json_encode($page_title) ?>,
        "description": <?= json_encode($page_description) ?>,
        "url": <?= json_encode(getCurrentUrl()) ?>,
        "numberOfItems": <?= (int) $total ?>
    }
    </script>

    <?php include 'includes/footer.php'; ?>
</body>

</html>