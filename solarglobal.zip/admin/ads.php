<?php
/**
 * Custom Ads Management - Admin Panel
 * Create, edit, delete custom advertisements with image upload
 */
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/helpers.php';
require_once '../includes/csrf.php';

set_security_headers();
$db = getDB();
$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid CSRF token.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'create' || $action === 'update') {
            $title = trim($_POST['title'] ?? '');
            $redirect_url = trim($_POST['redirect_url'] ?? '');
            $position = $_POST['position'] ?? 'sidebar';
            $country_code = strtoupper(trim($_POST['country_code'] ?? ''));
            if ($country_code === '' || $country_code === 'ALL') $country_code = null; // universal
            $width = intval($_POST['width'] ?? 728);
            $height = intval($_POST['height'] ?? 90);
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            $priority = intval($_POST['priority'] ?? 0);
            $start_date = $_POST['start_date'] ?: null;
            $end_date = $_POST['end_date'] ?: null;

            if (empty($title) || empty($redirect_url)) {
                $error = 'Title and redirect URL are required.';
            } else {
                $image_path = $_POST['existing_image'] ?? '';

                // Handle image upload
                if (!empty($_FILES['ad_image']['tmp_name'])) {
                    $upload_dir = '../uploads/ads/';
                    $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
                    $result = handle_image_upload($_FILES['ad_image'], $upload_dir, $allowed, 5242880);
                    if ($result['success']) {
                        $image_path = $result['path'];
                    } else {
                        $error = $result['error'];
                    }
                }

                if (empty($error)) {
                    if ($action === 'create') {
                        if (empty($image_path)) {
                            $error = 'Ad image is required.';
                        } else {
                            $stmt = $db->prepare("INSERT INTO custom_ads (title, image_path, redirect_url, position, country_code, width, height, is_active, priority, start_date, end_date) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
                            $stmt->execute([$title, $image_path, $redirect_url, $position, $country_code, $width, $height, $is_active, $priority, $start_date, $end_date]);
                            $message = 'Ad created successfully!';
                        }
                    } else {
                        $id = intval($_POST['ad_id']);
                        $stmt = $db->prepare("UPDATE custom_ads SET title=?, image_path=?, redirect_url=?, position=?, country_code=?, width=?, height=?, is_active=?, priority=?, start_date=?, end_date=? WHERE id=?");
                        $stmt->execute([$title, $image_path, $redirect_url, $position, $country_code, $width, $height, $is_active, $priority, $start_date, $end_date, $id]);
                        $message = 'Ad updated successfully!';
                    }
                }
            }
        } elseif ($action === 'delete') {
            $id = intval($_POST['ad_id']);
            $db->prepare("DELETE FROM custom_ads WHERE id = ?")->execute([$id]);
            $message = 'Ad deleted successfully!';
        } elseif ($action === 'toggle') {
            $id = intval($_POST['ad_id']);
            $db->prepare("UPDATE custom_ads SET is_active = NOT is_active WHERE id = ?")->execute([$id]);
            $message = 'Ad status toggled!';
        }
    }
}

// Get all countries for targeting dropdown
$countries = $db->query("SELECT code, name, flag_icon, flag_emoji FROM countries WHERE is_supported = 1 ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Get all ads
$ads = $db->query("SELECT * FROM custom_ads ORDER BY priority DESC, created_at DESC")->fetchAll();

// Get ad stats
$totalImpressions = $db->query("SELECT SUM(impressions) FROM custom_ads")->fetchColumn() ?: 0;
$totalClicks = $db->query("SELECT SUM(clicks) FROM custom_ads")->fetchColumn() ?: 0;
$activeAds = $db->query("SELECT COUNT(*) FROM custom_ads WHERE is_active = 1")->fetchColumn();

$pageTitle = "Ads Management";
include 'includes/header.php';
?>

<!-- Stats -->
<div class="dashboard-grid grid-4">
    <div class="stat-card">
        <div class="stat-icon">📢</div>
        <div class="stat-content">
            <div class="stat-value"><?= count($ads) ?></div>
            <div class="stat-label">Total Ads</div>
        </div>
    </div>
    <div class="stat-card stat-green">
        <div class="stat-icon">✅</div>
        <div class="stat-content">
            <div class="stat-value"><?= $activeAds ?></div>
            <div class="stat-label">Active</div>
        </div>
    </div>
    <div class="stat-card stat-blue">
        <div class="stat-icon">👁️</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($totalImpressions) ?></div>
            <div class="stat-label">Impressions</div>
        </div>
    </div>
    <div class="stat-card stat-orange">
        <div class="stat-icon">🖱️</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($totalClicks) ?></div>
            <div class="stat-label">Clicks</div>
        </div>
    </div>
</div>

<?php if ($message): ?>
<div class="alert alert-success"><?= sanitize($message) ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-error"><?= sanitize($error) ?></div>
<?php endif; ?>

<!-- Create Ad Form -->
<div class="card" id="create-form-card">
    <h2>Create New Ad</h2>
    <form method="POST" enctype="multipart/form-data" class="form-grid" id="create-ad-form">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">

        <div class="form-row">
            <div class="form-group">
                <label>Ad Title *</label>
                <input type="text" name="title" required placeholder="e.g. Summer Solar Sale">
            </div>
            <div class="form-group">
                <label>Redirect URL *</label>
                <input type="url" name="redirect_url" required placeholder="https://example.com/offer">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Position</label>
                <select name="position" class="ad-position-select" onchange="updateRecommendedSize(this)">
                    <option value="header">Header Banner (Recommended: 728x90)</option>
                    <option value="sidebar">Sidebar (Recommended: 300x250)</option>
                    <option value="footer">Above Footer (Recommended: 728x90)</option>
                    <option value="popup">Popup (Recommended: 400x300)</option>
                    <option value="between-steps">Between Wizard Steps (Recommended: 468x60)</option>
                </select>
            </div>
            <div class="form-group">
                <label>Target Country</label>
                <select name="country_code" class="ad-country-select">
                    <option value="ALL">🌍 Universal (All Countries)</option>
                    <?php foreach ($countries as $ct): ?>
                    <option value="<?= htmlspecialchars($ct['code']) ?>"><?= get_country_flag($ct, 16) ?> <?= sanitize($ct['name']) ?> (<?= sanitize($ct['code']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Width (px)</label>
                <input type="number" name="width" value="728" min="50" max="2000" class="ad-width-input">
            </div>
            <div class="form-group">
                <label>Height (px)</label>
                <input type="number" name="height" value="90" min="50" max="2000" class="ad-height-input">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Ad Image * (JPG/PNG/WEBP/GIF, max 5MB)</label>
                <input type="file" name="ad_image" accept="image/jpeg,image/png,image/webp,image/gif" required class="ad-image-input" onchange="previewAdImage(this)">
                <div class="ad-image-preview" style="margin-top:10px;display:none;">
                    <img src="" alt="Preview" style="max-width:100%;border:1px solid #ddd;border-radius:4px;">
                </div>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Start Date</label>
                <input type="date" name="start_date">
            </div>
            <div class="form-group">
                <label>End Date</label>
                <input type="date" name="end_date">
            </div>
            <div class="form-group">
                <label>Priority (higher = shown first)</label>
                <input type="number" name="priority" value="0" min="0" max="100">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="is_active" checked> Active
                </label>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Create Ad</button>
    </form>
</div>

<!-- Edit Ad Form (hidden by default) -->
<div class="card" id="edit-form-card" style="display:none;">
    <h2>Edit Ad <button type="button" class="btn btn-sm btn-secondary" onclick="cancelEdit()" style="float:right;">Cancel</button></h2>
    <form method="POST" enctype="multipart/form-data" class="form-grid" id="edit-ad-form">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="ad_id" id="edit-ad-id">
        <input type="hidden" name="existing_image" id="edit-existing-image">

        <div class="form-row">
            <div class="form-group">
                <label>Ad Title *</label>
                <input type="text" name="title" id="edit-title" required placeholder="e.g. Summer Solar Sale">
            </div>
            <div class="form-group">
                <label>Redirect URL *</label>
                <input type="url" name="redirect_url" id="edit-redirect-url" required placeholder="https://example.com/offer">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Position</label>
                <select name="position" id="edit-position" class="ad-position-select" onchange="updateRecommendedSize(this)">
                    <option value="header">Header Banner (Recommended: 728x90)</option>
                    <option value="sidebar">Sidebar (Recommended: 300x250)</option>
                    <option value="footer">Above Footer (Recommended: 728x90)</option>
                    <option value="popup">Popup (Recommended: 400x300)</option>
                    <option value="between-steps">Between Wizard Steps (Recommended: 468x60)</option>
                </select>
            </div>
            <div class="form-group">
                <label>Target Country</label>
                <select name="country_code" id="edit-country-code" class="ad-country-select">
                    <option value="ALL">🌍 Universal (All Countries)</option>
                    <?php foreach ($countries as $ct): ?>
                    <option value="<?= htmlspecialchars($ct['code']) ?>"><?= get_country_flag($ct, 16) ?> <?= sanitize($ct['name']) ?> (<?= sanitize($ct['code']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Width (px)</label>
                <input type="number" name="width" id="edit-width" value="728" min="50" max="2000" class="ad-width-input">
            </div>
            <div class="form-group">
                <label>Height (px)</label>
                <input type="number" name="height" id="edit-height" value="90" min="50" max="2000" class="ad-height-input">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Ad Image (JPG/PNG/WEBP/GIF, max 5MB) — Leave empty to keep current</label>
                <input type="file" name="ad_image" accept="image/jpeg,image/png,image/webp,image/gif" class="ad-image-input" onchange="previewAdImage(this)">
                <div class="ad-image-preview" style="margin-top:10px;">
                    <img src="" alt="Current Image" id="edit-image-preview" style="max-width:100%;max-height:150px;border:1px solid #ddd;border-radius:4px;">
                </div>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Start Date</label>
                <input type="date" name="start_date" id="edit-start-date">
            </div>
            <div class="form-group">
                <label>End Date</label>
                <input type="date" name="end_date" id="edit-end-date">
            </div>
            <div class="form-group">
                <label>Priority (higher = shown first)</label>
                <input type="number" name="priority" id="edit-priority" value="0" min="0" max="100">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="is_active" id="edit-is-active"> Active
                </label>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Update Ad</button>
    </form>
</div>

<!-- Existing Ads -->
<div class="card">
    <h2>All Advertisements</h2>
    <?php if (empty($ads)): ?>
        <p class="text-muted">No ads created yet.</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Preview</th>
                    <th>Title</th>
                    <th>Position</th>
                    <th>Target</th>
                    <th>Size</th>
                    <th>Status</th>
                    <th>Impressions</th>
                    <th>Clicks</th>
                    <th>CTR</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($ads as $ad): ?>
                <tr>
                    <td>
                        <?php if ($ad['image_path']): ?>
                        <img src="../<?= sanitize($ad['image_path']) ?>" alt="Ad" style="width:80px;height:50px;object-fit:cover;border-radius:4px;">
                        <?php endif; ?>
                    </td>
                    <td>
                        <strong><?= sanitize($ad['title']) ?></strong>
                        <br><small class="text-muted"><?= sanitize(substr($ad['redirect_url'], 0, 40)) ?></small>
                    </td>
                    <td><span class="badge badge-blue"><?= sanitize($ad['position']) ?></span></td>
                    <td>
                        <?php if (empty($ad['country_code'])): ?>
                            <span class="badge badge-green">🌍 Universal</span>
                        <?php else: ?>
                            <?= get_country_flag($ad['country_code'], 18) ?> <strong><?= sanitize($ad['country_code']) ?></strong>
                        <?php endif; ?>
                    </td>
                    <td><?= intval($ad['width']) ?>x<?= intval($ad['height']) ?></td>
                    <td>
                        <span class="badge badge-<?= $ad['is_active'] ? 'green' : 'red' ?>">
                            <?= $ad['is_active'] ? 'Active' : 'Inactive' ?>
                        </span>
                    </td>
                    <td><?= number_format($ad['impressions']) ?></td>
                    <td><?= number_format($ad['clicks']) ?></td>
                    <td><?= $ad['impressions'] > 0 ? round(($ad['clicks'] / $ad['impressions']) * 100, 1) . '%' : '0%' ?></td>
                    <td>
                        <form method="POST" style="display:inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="ad_id" value="<?= $ad['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-secondary" title="Toggle">
                                <?= $ad['is_active'] ? '⏸️' : '▶️' ?>
                            </button>
                        </form>
                        <button type="button" class="btn btn-sm btn-primary" title="Edit" onclick='editAd(<?= json_encode($ad, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✏️</button>
                        <form method="POST" style="display:inline" onsubmit="return confirm('Delete this ad?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="ad_id" value="<?= $ad['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-danger">🗑️</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<script>
// Position to recommended size mapping
const sizeMap = {
    'header': {w: 728, h: 90},
    'sidebar': {w: 300, h: 250},
    'footer': {w: 728, h: 90},
    'popup': {w: 400, h: 300},
    'between-steps': {w: 468, h: 60}
};

// Update width/height inputs based on selected position
function updateRecommendedSize(selectEl) {
    const form = selectEl.closest('form');
    const position = selectEl.value;
    const size = sizeMap[position];
    if (size) {
        form.querySelector('.ad-width-input').value = size.w;
        form.querySelector('.ad-height-input').value = size.h;
    }
}

// Preview selected image at the chosen dimensions
function previewAdImage(input) {
    const form = input.closest('form');
    const previewContainer = form.querySelector('.ad-image-preview');
    const previewImg = previewContainer.querySelector('img');
    const width = form.querySelector('.ad-width-input').value;
    const height = form.querySelector('.ad-height-input').value;

    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            previewImg.style.width = Math.min(width, 600) + 'px';
            previewImg.style.height = Math.min(height, 400) + 'px';
            previewImg.style.objectFit = 'contain';
            previewContainer.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        previewContainer.style.display = 'none';
    }
}

// Edit ad: populate the edit form and show it
function editAd(ad) {
    document.getElementById('edit-ad-id').value = ad.id;
    document.getElementById('edit-title').value = ad.title;
    document.getElementById('edit-redirect-url').value = ad.redirect_url;
    document.getElementById('edit-position').value = ad.position;
    document.getElementById('edit-width').value = ad.width || 728;
    document.getElementById('edit-height').value = ad.height || 90;
    document.getElementById('edit-priority').value = ad.priority || 0;
    document.getElementById('edit-start-date').value = ad.start_date || '';
    document.getElementById('edit-end-date').value = ad.end_date || '';
    document.getElementById('edit-is-active').checked = ad.is_active == 1;
    document.getElementById('edit-country-code').value = ad.country_code || 'ALL';
    document.getElementById('edit-existing-image').value = ad.image_path || '';

    // Show current image preview
    const previewImg = document.getElementById('edit-image-preview');
    if (ad.image_path) {
        previewImg.src = '../' + ad.image_path;
        previewImg.parentElement.style.display = 'block';
    } else {
        previewImg.parentElement.style.display = 'none';
    }

    // Show edit form, hide create form
    document.getElementById('edit-form-card').style.display = 'block';
    document.getElementById('create-form-card').style.display = 'none';

    // Scroll to edit form
    document.getElementById('edit-form-card').scrollIntoView({behavior: 'smooth', block: 'start'});
}

// Cancel editing: hide edit form, show create form
function cancelEdit() {
    document.getElementById('edit-form-card').style.display = 'none';
    document.getElementById('create-form-card').style.display = 'block';
}
</script>

<?php include 'includes/footer.php'; ?>
