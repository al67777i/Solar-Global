<?php
/**
 * Point of Sale (POS) System for Dealers
 * Handles walk-in sales with cart, receipt printing, and recent sales log.
 */

$pageTitle = 'Point of Sale';

require_once __DIR__ . '/../includes/dealer_auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

set_security_headers();
require_dealer_login();
require_dealer_subscription();

$db       = getDB();
$dealerId = $_SESSION['dealer_id'];
$dealer   = get_dealer_profile();

// Dealer's currency
$dealer_country  = $dealer['country_code'] ?? '';
$dealer_currency = get_country_currency_info($dealer_country);

/* =====================================================================
 * AJAX HANDLERS — respond and exit before any HTML is output
 * ===================================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    /* ---------- search_products ------------------------------------ */
    if ($action === 'search_products') {
        $q = trim($_POST['q'] ?? '');
        if (strlen($q) < 1) {
            respond_json(['products' => []]);
        }
        $like = '%' . $q . '%';

        $rows = [];

        // Inverters
        $stmt = $db->prepare("
            SELECT dp.id AS dp_id, dp.product_type, dp.product_id,
                   dp.dealer_price, dp.stock_quantity, dp.stock_status,
                   CONCAT(i.company, ' ', i.model) AS product_name,
                   CONCAT(i.output_power_w, 'W') AS spec_summary,
                   i.company AS company_name
            FROM dealer_products dp
            JOIN inverters i ON i.id = dp.product_id
            WHERE dp.dealer_id = ? AND dp.product_type = 'inverter'
              AND dp.is_active = 1 AND dp.stock_quantity > 0
              AND (i.model LIKE ? OR i.company LIKE ?)
            ORDER BY i.company, i.model
            LIMIT 20
        ");
        $stmt->execute([$dealerId, $like, $like]);
        $rows = array_merge($rows, $stmt->fetchAll());

        // Batteries
        $stmt = $db->prepare("
            SELECT dp.id AS dp_id, dp.product_type, dp.product_id,
                   dp.dealer_price, dp.stock_quantity, dp.stock_status,
                   CONCAT(b.brand, ' ', b.model) AS product_name,
                   CONCAT(b.capacity_ah, 'Ah/', b.nominal_voltage, 'V') AS spec_summary,
                   b.brand AS company_name
            FROM dealer_products dp
            JOIN batteries b ON b.id = dp.product_id
            WHERE dp.dealer_id = ? AND dp.product_type = 'battery'
              AND dp.is_active = 1 AND dp.stock_quantity > 0
              AND (b.model LIKE ? OR b.brand LIKE ?)
            ORDER BY b.brand, b.model
            LIMIT 20
        ");
        $stmt->execute([$dealerId, $like, $like]);
        $rows = array_merge($rows, $stmt->fetchAll());

        // Panels
        $stmt = $db->prepare("
            SELECT dp.id AS dp_id, dp.product_type, dp.product_id,
                   dp.dealer_price, dp.stock_quantity, dp.stock_status,
                   CONCAT(p.brand, ' ', p.name) AS product_name,
                   CONCAT(p.wattage, 'W') AS spec_summary,
                   p.brand AS company_name
            FROM dealer_products dp
            JOIN panels p ON p.id = dp.product_id
            WHERE dp.dealer_id = ? AND dp.product_type = 'panel'
              AND dp.is_active = 1 AND dp.stock_quantity > 0
              AND (p.name LIKE ? OR p.brand LIKE ?)
            ORDER BY p.brand, p.name
            LIMIT 20
        ");
        $stmt->execute([$dealerId, $like, $like]);
        $rows = array_merge($rows, $stmt->fetchAll());

        // Installation appliances
        $stmt = $db->prepare("
            SELECT dp.id AS dp_id, dp.product_type, dp.product_id,
                   dp.dealer_price, dp.stock_quantity, dp.stock_status,
                   ia.name AS product_name,
                   ia.category AS spec_summary,
                   COALESCE(ia.brand, 'Generic') AS company_name
            FROM dealer_products dp
            JOIN installation_appliances ia ON ia.id = dp.product_id
            WHERE dp.dealer_id = ? AND dp.product_type = 'installation_appliance'
              AND dp.is_active = 1 AND dp.stock_quantity > 0
              AND (ia.name LIKE ? OR ia.brand LIKE ?)
            ORDER BY ia.name
            LIMIT 20
        ");
        $stmt->execute([$dealerId, $like, $like]);
        $rows = array_merge($rows, $stmt->fetchAll());

        // Limit combined to 40
        $rows = array_slice($rows, 0, 40);
        respond_json(['products' => $rows]);
    }

    /* ---------- complete_sale -------------------------------------- */
    if ($action === 'complete_sale') {
        if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
            respond_json(['success' => false, 'message' => 'Invalid security token.'], 403);
        }

        $cartJson     = $_POST['cart'] ?? '[]';
        $custName     = trim($_POST['customer_name'] ?? '');
        $custPhone    = trim($_POST['customer_phone'] ?? '');
        $custEmail    = trim($_POST['customer_email'] ?? '');
        $cart         = json_decode($cartJson, true);

        if (empty($cart) || !is_array($cart)) {
            respond_json(['success' => false, 'message' => 'Cart is empty.']);
        }

        // Validate and price each cart item fresh from DB
        $lineItems = [];
        $subtotal  = 0.0;

        foreach ($cart as $item) {
            $dpId = (int)($item['dp_id'] ?? 0);
            $qty  = max(1, (int)($item['qty'] ?? 1));
            if (!$dpId) continue;

            $stmt = $db->prepare("
                SELECT dp.id, dp.product_type, dp.product_id,
                       dp.dealer_price, dp.stock_quantity,
                       CASE dp.product_type
                           WHEN 'inverter'             THEN (SELECT CONCAT(i.company,' ',i.model) FROM inverters i WHERE i.id=dp.product_id)
                           WHEN 'battery'              THEN (SELECT CONCAT(b.brand,' ',b.model) FROM batteries b WHERE b.id=dp.product_id)
                           WHEN 'panel'                THEN (SELECT CONCAT(p.brand,' ',p.name) FROM panels p WHERE p.id=dp.product_id)
                           WHEN 'installation_appliance' THEN (SELECT ia.name FROM installation_appliances ia WHERE ia.id=dp.product_id)
                       END AS product_name
                FROM dealer_products dp
                WHERE dp.id = ? AND dp.dealer_id = ? AND dp.is_active = 1
            ");
            $stmt->execute([$dpId, $dealerId]);
            $dp = $stmt->fetch();

            if (!$dp) continue;
            if ($dp['stock_quantity'] < $qty) {
                respond_json(['success' => false, 'message' => 'Insufficient stock for: ' . ($dp['product_name'] ?? 'item')]);
            }

            $lineTotal  = round((float)$dp['dealer_price'] * $qty, 2);
            $subtotal  += $lineTotal;
            $lineItems[] = [
                'dp_id'        => $dpId,
                'product_type' => $dp['product_type'],
                'product_id'   => $dp['product_id'],
                'product_name' => $dp['product_name'] ?? 'Product',
                'unit_price'   => (float)$dp['dealer_price'],
                'qty'          => $qty,
                'line_total'   => $lineTotal,
                'stock_qty'    => (int)$dp['stock_quantity'],
            ];
        }

        if (empty($lineItems)) {
            respond_json(['success' => false, 'message' => 'No valid items in cart.']);
        }

        // Tax lookup — use dealer country
        $taxPercent = 0.0;
        if (!empty($dealer['country_code'])) {
            $stmtTax = $db->prepare("
                SELECT AVG(tax_percent) AS avg_tax
                FROM country_price_adjustments
                WHERE country_code = ?
            ");
            $stmtTax->execute([$dealer['country_code']]);
            $taxRow = $stmtTax->fetch();
            $taxPercent = $taxRow ? (float)($taxRow['avg_tax'] ?? 0) : 0.0;
        }

        $taxAmount = round($subtotal * ($taxPercent / 100), 2);
        $total     = round($subtotal + $taxAmount, 2);

        // Generate order number: POS-YYYYMMDD-XXXX
        $today       = date('Ymd');
        $prefix      = 'POS-' . $today . '-';
        $stmtCount   = $db->prepare("
            SELECT COUNT(*) FROM orders
            WHERE order_number LIKE ? AND DATE(created_at) = CURDATE()
        ");
        $stmtCount->execute([$prefix . '%']);
        $seqNum     = (int)$stmtCount->fetchColumn() + 1;
        $orderNumber = $prefix . str_pad($seqNum, 4, '0', STR_PAD_LEFT);

        // Ensure uniqueness (race-condition safety)
        $stmtCheck = $db->prepare("SELECT id FROM orders WHERE order_number = ?");
        $stmtCheck->execute([$orderNumber]);
        while ($stmtCheck->fetch()) {
            $seqNum++;
            $orderNumber = $prefix . str_pad($seqNum, 4, '0', STR_PAD_LEFT);
            $stmtCheck->execute([$orderNumber]);
        }

        // Guest customer record for walk-in
        $customerId = null;
        $guestEmail = !empty($custEmail) ? $custEmail : ('pos-walkin-' . $dealerId . '@internal.pos');
        $guestName  = !empty($custName)  ? $custName  : 'Walk-in Customer';

        // Upsert guest customer
        $stmtCust = $db->prepare("
            SELECT id FROM customers WHERE email = ?
        ");
        $stmtCust->execute([$guestEmail]);
        $existingCust = $stmtCust->fetch();

        if ($existingCust) {
            $customerId = (int)$existingCust['id'];
            // Update name/phone if provided
            if (!empty($custName) || !empty($custPhone)) {
                $db->prepare("UPDATE customers SET name = ?, phone = ? WHERE id = ?")
                   ->execute([$guestName, $custPhone ?: null, $customerId]);
            }
        } else {
            $db->prepare("
                INSERT INTO customers (name, email, phone, email_verified, is_active, created_at)
                VALUES (?, ?, ?, 1, 1, NOW())
            ")->execute([$guestName, $guestEmail, $custPhone ?: null]);
            $customerId = (int)$db->lastInsertId();
        }

        // Begin transaction
        $db->beginTransaction();
        try {
            // Insert order
            $stmtOrder = $db->prepare("
                INSERT INTO orders (order_number, customer_id, dealer_id, status,
                                    total_amount, currency, item_count, notes, confirmed_at, created_at, updated_at)
                VALUES (?, ?, ?, 'picked_up', ?, ?, ?, 'POS walk-in sale', NOW(), NOW(), NOW())
            ");
            $stmtOrder->execute([$orderNumber, $customerId, $dealerId, $total, $dealer_currency['currency_code'], count($lineItems)]);
            $orderId = (int)$db->lastInsertId();

            // Insert order items & decrement stock
            $stmtItem = $db->prepare("
                INSERT INTO order_items (order_id, product_type, product_id, product_name,
                                         quantity, unit_price, total_price, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmtStock = $db->prepare("
                UPDATE dealer_products
                SET stock_quantity = GREATEST(0, stock_quantity - ?),
                    stock_status = CASE
                        WHEN GREATEST(0, stock_quantity - ?) > 5 THEN 'in_stock'
                        WHEN GREATEST(0, stock_quantity - ?) > 0 THEN 'low_stock'
                        ELSE 'out_of_stock'
                    END,
                    updated_at = NOW()
                WHERE id = ? AND dealer_id = ?
            ");

            foreach ($lineItems as $li) {
                $stmtItem->execute([
                    $orderId,
                    $li['product_type'],
                    $li['product_id'],
                    $li['product_name'],
                    $li['qty'],
                    $li['unit_price'],
                    $li['line_total'],
                ]);
                $stmtStock->execute([
                    $li['qty'], $li['qty'], $li['qty'],
                    $li['dp_id'], $dealerId,
                ]);
            }

            $db->commit();

            respond_json([
                'success'      => true,
                'order_id'     => $orderId,
                'order_number' => $orderNumber,
                'subtotal'     => $subtotal,
                'tax_percent'  => $taxPercent,
                'tax_amount'   => $taxAmount,
                'total'        => $total,
                'customer'     => ['name' => $guestName, 'phone' => $custPhone, 'email' => $custEmail],
                'items'        => $lineItems,
            ]);
        } catch (Exception $e) {
            $db->rollBack();
            error_log('POS sale error: ' . $e->getMessage());
            respond_json(['success' => false, 'message' => 'Transaction failed. Please try again.'], 500);
        }
    }

    /* ---------- get_receipt --------------------------------------- */
    if ($action === 'get_receipt') {
        $orderId = (int)($_POST['order_id'] ?? 0);
        if (!$orderId) respond_json(['success' => false, 'message' => 'Invalid order.'], 400);

        $stmtO = $db->prepare("
            SELECT o.*, c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email
            FROM orders o
            JOIN customers c ON c.id = o.customer_id
            WHERE o.id = ? AND o.dealer_id = ?
        ");
        $stmtO->execute([$orderId, $dealerId]);
        $order = $stmtO->fetch();

        if (!$order) respond_json(['success' => false, 'message' => 'Order not found.'], 404);

        $stmtI = $db->prepare("
            SELECT * FROM order_items WHERE order_id = ? ORDER BY id
        ");
        $stmtI->execute([$orderId]);
        $items = $stmtI->fetchAll();

        respond_json(['success' => true, 'order' => $order, 'items' => $items]);
    }

    respond_json(['success' => false, 'message' => 'Unknown action.'], 400);
}

/* =====================================================================
 * PAGE DATA — recent sales
 * ===================================================================== */
$stmtRecent = $db->prepare("
    SELECT o.id, o.order_number, o.total_amount, o.item_count, o.created_at,
           c.name AS customer_name
    FROM orders o
    JOIN customers c ON c.id = o.customer_id
    WHERE o.dealer_id = ? AND o.order_number LIKE 'POS-%'
    ORDER BY o.created_at DESC
    LIMIT 10
");
$stmtRecent->execute([$dealerId]);
$recentSales = $stmtRecent->fetchAll();

$csrfToken = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?> - <?= sanitize($dealer['business_name']) ?> | SolarGlobal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* ============================================================
         * Base & Layout
         * ============================================================ */
        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            min-height: 100vh;
            color: #1E293B;
        }

        /* Main POS grid */
        .pos-wrapper {
            display: grid;
            grid-template-columns: 60% 40%;
            gap: 0;
            height: calc(100vh - 73px);
        }

        /* ============================================================
         * Left panel — Search + Results
         * ============================================================ */
        .left-panel {
            background: #F8FAFC;
            display: flex;
            flex-direction: column;
            border-right: 2px solid #E2E8F0;
            overflow: hidden;
        }

        .search-area {
            padding: 16px 20px;
            background: white;
            border-bottom: 1px solid #E2E8F0;
        }
        .search-area h2 {
            font-size: 0.8125rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.8px;
            color: #64748B; margin-bottom: 10px;
        }
        .search-box-wrap {
            position: relative;
        }
        .search-box-wrap .search-icon {
            position: absolute; left: 12px; top: 50%; transform: translateY(-50%);
            font-size: 1rem; color: #94A3B8; pointer-events: none;
        }
        #searchInput {
            width: 100%;
            padding: 11px 12px 11px 38px;
            border: 2px solid #E2E8F0;
            border-radius: 10px;
            font-size: 0.9375rem;
            font-family: 'Inter', sans-serif;
            outline: none;
            transition: border-color 0.2s;
            background: #F8FAFC;
        }
        #searchInput:focus { border-color: #F59E0B; background: white; }

        .results-area {
            flex: 1;
            overflow-y: auto;
            padding: 12px 20px 20px;
        }

        .results-hint {
            text-align: center;
            padding: 48px 24px;
            color: #94A3B8;
        }
        .results-hint .hint-icon { font-size: 2.5rem; margin-bottom: 12px; }
        .results-hint p { font-size: 0.9375rem; }

        .result-item {
            background: white;
            border: 1px solid #E2E8F0;
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            transition: all 0.15s;
        }
        .result-item:hover { border-color: #F59E0B; box-shadow: 0 2px 8px rgba(245,158,11,0.15); }
        .result-item:active { transform: scale(0.99); }

        .result-type-badge {
            width: 36px; height: 36px; border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1rem; flex-shrink: 0;
        }
        .rt-inverter { background: #DBEAFE; }
        .rt-battery  { background: #DCFCE7; }
        .rt-panel    { background: #FEF3C7; }
        .rt-installation_appliance { background: #F3E8FF; }

        .result-info { flex: 1; min-width: 0; }
        .result-name {
            font-size: 0.9rem; font-weight: 600; color: #1E293B;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .result-meta { font-size: 0.775rem; color: #64748B; margin-top: 2px; }

        .result-price-area { text-align: right; flex-shrink: 0; }
        .result-price { font-size: 1rem; font-weight: 700; color: #1E293B; }
        .result-stock {
            font-size: 0.7rem; font-weight: 600; padding: 2px 7px;
            border-radius: 4px; margin-top: 4px; display: inline-block;
        }
        .stock-in_stock    { background: #DCFCE7; color: #166534; }
        .stock-low_stock   { background: #FEF3C7; color: #92400E; }
        .stock-out_of_stock { background: #FEE2E2; color: #991B1B; }

        .result-add-btn {
            background: #F59E0B; color: #1E293B;
            border: none; border-radius: 7px;
            padding: 8px 12px; font-size: 1rem;
            font-weight: 700; cursor: pointer;
            transition: background 0.15s; flex-shrink: 0;
        }
        .result-add-btn:hover { background: #D97706; }

        .no-results {
            text-align: center; padding: 32px 16px; color: #94A3B8;
            font-size: 0.9rem;
        }

        /* Recent sales sidebar (below search on left) */
        .recent-panel {
            padding: 12px 20px;
            background: white;
            border-top: 1px solid #E2E8F0;
            max-height: 220px;
            overflow-y: auto;
        }
        .recent-panel h3 {
            font-size: 0.75rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.8px;
            color: #64748B; margin-bottom: 10px;
        }
        .recent-item {
            display: flex; align-items: center; justify-content: space-between;
            padding: 7px 0; border-bottom: 1px solid #F1F5F9;
            font-size: 0.8125rem; cursor: pointer;
            transition: color 0.15s;
        }
        .recent-item:last-child { border-bottom: none; }
        .recent-item:hover .r-num { color: #F59E0B; }
        .r-num { font-weight: 700; color: #1E293B; }
        .r-customer { color: #64748B; margin-left: 8px; flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .r-total { font-weight: 600; color: #1E293B; flex-shrink: 0; }
        .r-time { font-size: 0.7rem; color: #94A3B8; margin-left: 8px; flex-shrink: 0; }

        /* ============================================================
         * Right panel — Cart
         * ============================================================ */
        .right-panel {
            background: white;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .cart-header {
            padding: 16px 20px;
            border-bottom: 1px solid #E2E8F0;
            display: flex; align-items: center; justify-content: space-between;
        }
        .cart-header h2 {
            font-size: 0.8125rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.8px; color: #64748B;
        }
        .cart-clear-btn {
            background: none; border: none; color: #94A3B8; cursor: pointer;
            font-size: 0.75rem; font-weight: 500; padding: 4px 8px;
            border-radius: 4px; transition: all 0.15s;
        }
        .cart-clear-btn:hover { background: #FEE2E2; color: #DC2626; }

        .cart-items {
            flex: 1;
            overflow-y: auto;
            padding: 12px 20px;
        }

        .cart-empty {
            text-align: center; padding: 40px 16px; color: #94A3B8;
        }
        .cart-empty .ce-icon { font-size: 2.5rem; margin-bottom: 10px; }
        .cart-empty p { font-size: 0.9rem; }

        .cart-item {
            display: flex; align-items: flex-start; gap: 10px;
            padding: 10px 0; border-bottom: 1px solid #F1F5F9;
        }
        .cart-item:last-child { border-bottom: none; }
        .ci-info { flex: 1; min-width: 0; }
        .ci-name { font-size: 0.875rem; font-weight: 600; color: #1E293B; }
        .ci-type { font-size: 0.7rem; color: #94A3B8; text-transform: uppercase; margin-top: 2px; }
        .ci-controls {
            display: flex; align-items: center; gap: 6px; margin-top: 6px;
        }
        .qty-btn {
            width: 26px; height: 26px; border-radius: 6px;
            border: 1px solid #E2E8F0; background: #F8FAFC;
            font-size: 1rem; font-weight: 700; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            transition: all 0.15s; color: #475569;
        }
        .qty-btn:hover { background: #F59E0B; color: #1E293B; border-color: #F59E0B; }
        .qty-display {
            min-width: 32px; text-align: center;
            font-size: 0.9rem; font-weight: 700; color: #1E293B;
        }
        .ci-price {
            text-align: right; flex-shrink: 0;
        }
        .ci-line-total { font-size: 0.9rem; font-weight: 700; color: #1E293B; }
        .ci-unit-price { font-size: 0.7rem; color: #94A3B8; }
        .ci-remove {
            background: none; border: none; color: #CBD5E1; cursor: pointer;
            font-size: 1.125rem; padding: 2px 4px; border-radius: 4px;
            transition: color 0.15s; align-self: center;
        }
        .ci-remove:hover { color: #DC2626; }

        /* Customer info */
        .customer-section {
            padding: 14px 20px;
            border-top: 1px solid #E2E8F0;
            background: #FAFAFA;
        }
        .customer-section h3 {
            font-size: 0.75rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.8px;
            color: #64748B; margin-bottom: 10px;
        }
        .cust-grid {
            display: grid; grid-template-columns: 1fr 1fr; gap: 8px;
        }
        .cust-grid .full-col { grid-column: 1 / -1; }
        .cust-input {
            width: 100%; padding: 8px 10px;
            border: 1px solid #E2E8F0; border-radius: 7px;
            font-size: 0.8125rem; font-family: 'Inter', sans-serif;
            outline: none; background: white; transition: border-color 0.2s;
        }
        .cust-input:focus { border-color: #F59E0B; }
        .cust-input::placeholder { color: #CBD5E1; }

        /* Summary */
        .cart-summary {
            padding: 14px 20px;
            border-top: 2px solid #E2E8F0;
        }
        .summary-row {
            display: flex; justify-content: space-between; align-items: center;
            font-size: 0.875rem; margin-bottom: 6px;
        }
        .summary-row .s-label { color: #64748B; }
        .summary-row .s-value { font-weight: 600; color: #1E293B; }
        .summary-row.total-row {
            margin-top: 10px; padding-top: 10px;
            border-top: 1px solid #E2E8F0;
            font-size: 1.0625rem;
        }
        .summary-row.total-row .s-label { font-weight: 700; color: #1E293B; }
        .summary-row.total-row .s-value { font-weight: 800; color: #1E293B; font-size: 1.2rem; }
        .tax-note { font-size: 0.7rem; color: #94A3B8; margin-top: 4px; text-align: right; }

        /* Complete sale button */
        .complete-btn {
            margin: 12px 20px 16px;
            padding: 14px;
            background: #F59E0B;
            color: #1E293B;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            width: calc(100% - 40px);
            transition: background 0.2s;
            letter-spacing: 0.3px;
        }
        .complete-btn:hover:not(:disabled) { background: #D97706; }
        .complete-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        /* ============================================================
         * Receipt Modal
         * ============================================================ */
        .modal-overlay {
            display: none;
            position: fixed; inset: 0;
            background: rgba(15,23,42,0.7);
            z-index: 500;
            align-items: center; justify-content: center;
        }
        .modal-overlay.active { display: flex; }

        .modal-box {
            background: white;
            border-radius: 14px;
            width: 420px; max-width: 95vw;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .modal-head {
            padding: 20px 24px 16px;
            border-bottom: 1px solid #E2E8F0;
            display: flex; align-items: center; justify-content: space-between;
        }
        .modal-head h2 { font-size: 1.125rem; font-weight: 700; color: #1E293B; }
        .modal-close {
            background: none; border: none; font-size: 1.25rem;
            color: #94A3B8; cursor: pointer; padding: 4px 8px; border-radius: 6px;
        }
        .modal-close:hover { background: #F1F5F9; color: #475569; }
        .modal-body { padding: 20px 24px; }
        .modal-foot {
            padding: 16px 24px;
            border-top: 1px solid #E2E8F0;
            display: flex; gap: 10px;
        }
        .modal-btn {
            flex: 1; padding: 12px;
            border-radius: 8px; border: none;
            font-size: 0.9rem; font-weight: 600; cursor: pointer;
            transition: background 0.15s;
        }
        .btn-print { background: #1E293B; color: white; }
        .btn-print:hover { background: #0F172A; }
        .btn-new-sale { background: #F59E0B; color: #1E293B; }
        .btn-new-sale:hover { background: #D97706; }

        /* ============================================================
         * Thermal Receipt Styles (screen + print)
         * ============================================================ */
        .receipt {
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.8125rem;
            color: #000;
            line-height: 1.5;
        }
        .receipt-header { text-align: center; margin-bottom: 12px; }
        .receipt-header .biz-name { font-size: 1.05rem; font-weight: 700; }
        .receipt-header .order-num { font-size: 0.9rem; font-weight: 700; margin-top: 4px; }
        .receipt-header .receipt-date { font-size: 0.75rem; color: #475569; margin-top: 2px; }

        .receipt-divider {
            border: none; border-top: 1px dashed #CBD5E1; margin: 10px 0;
        }
        .receipt-customer { margin-bottom: 10px; }
        .receipt-customer div { font-size: 0.8rem; }

        .receipt-items { width: 100%; border-collapse: collapse; }
        .receipt-items th {
            text-align: left; font-size: 0.7rem;
            text-transform: uppercase; color: #64748B;
            padding: 3px 0; border-bottom: 1px solid #E2E8F0;
        }
        .receipt-items th:last-child { text-align: right; }
        .receipt-items td { padding: 4px 0; font-size: 0.8rem; vertical-align: top; }
        .receipt-items td:last-child { text-align: right; font-weight: 600; }
        .receipt-items .item-qty { color: #64748B; font-size: 0.75rem; }

        .receipt-totals { margin-top: 10px; }
        .receipt-totals .rt-row {
            display: flex; justify-content: space-between;
            font-size: 0.8rem; padding: 2px 0;
        }
        .receipt-totals .rt-row.grand {
            font-weight: 700; font-size: 1rem;
            border-top: 1px solid #000; margin-top: 6px; padding-top: 6px;
        }
        .receipt-footer {
            text-align: center; margin-top: 16px;
            font-size: 0.75rem; color: #64748B;
        }

        /* ============================================================
         * Loading spinner
         * ============================================================ */
        .spinner {
            display: inline-block; width: 16px; height: 16px;
            border: 2px solid rgba(255,255,255,0.4);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
            vertical-align: middle; margin-right: 6px;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        /* Toast notifications */
        #toast {
            position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
            background: #1E293B; color: white;
            padding: 10px 20px; border-radius: 8px;
            font-size: 0.875rem; font-weight: 500;
            z-index: 999; opacity: 0; transition: opacity 0.3s;
            pointer-events: none; white-space: nowrap;
        }
        #toast.show { opacity: 1; }
        #toast.toast-error { background: #DC2626; }
        #toast.toast-success { background: #16A34A; }

        /* ============================================================
         * Print styles — 80mm thermal printer
         * ============================================================ */
        @media print {
            body * { visibility: hidden !important; }
            #printArea, #printArea * { visibility: visible !important; }
            #printArea {
                position: fixed; top: 0; left: 0;
                width: 80mm;
                visibility: visible !important;
            }
            .modal-foot { display: none !important; }
            .receipt {
                font-family: 'Courier New', Courier, monospace;
                font-size: 9pt;
                line-height: 1.4;
                color: #000;
            }
            .receipt-header .biz-name { font-size: 11pt; }
            .receipt-divider { border-top: 1px dashed #000; }
            .receipt-totals .rt-row.grand { font-size: 11pt; }
            @page {
                size: 80mm auto;
                margin: 4mm 2mm;
            }
        }

        /* ============================================================
         * Responsive
         * ============================================================ */
        @media (max-width: 768px) {
            .pos-wrapper {
                grid-template-columns: 1fr;
                grid-template-rows: auto auto;
                height: auto;
                min-height: calc(100vh - 73px);
            }
            .left-panel, .right-panel { height: auto; }
            .results-area { max-height: 50vh; }
            .cart-items { max-height: 40vh; }
            .recent-panel { max-height: 160px; }
        }
    </style>
</head>
<body>
<?php $current_dealer_page = 'pos'; include __DIR__ . '/includes/sidebar.php'; ?>
<main class="dlr-main-content" style="padding: 0; overflow: hidden;">
    <div class="dlr-page-header" style="padding: 12px 20px; margin-bottom: 0;">
        <div class="dlr-page-header-left">
            <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
            <h1 style="font-size: 1.25rem;">&#128179; Point of Sale</h1>
        </div>
        <div></div>
    </div>

<!-- POS Grid -->
<div class="pos-wrapper">

    <!-- ===================== LEFT PANEL ===================== -->
    <div class="left-panel">

        <!-- Search bar -->
        <div class="search-area">
            <h2>&#128269; Search Products</h2>
            <div class="search-box-wrap">
                <span class="search-icon">&#128269;</span>
                <input type="text" id="searchInput"
                       placeholder="Type product name or brand..."
                       autocomplete="off" autofocus>
            </div>
        </div>

        <!-- Results -->
        <div class="results-area" id="resultsArea">
            <div class="results-hint" id="searchHint">
                <div class="hint-icon">&#9728;&#65039;</div>
                <p>Search your inventory to add items to the cart</p>
            </div>
        </div>

        <!-- Recent Sales -->
        <div class="recent-panel">
            <h3>&#128203; Recent Sales (Last 10)</h3>
            <?php if (empty($recentSales)): ?>
                <p style="font-size:0.8rem;color:#94A3B8;padding:8px 0;">No sales yet today.</p>
            <?php else: ?>
                <?php foreach ($recentSales as $rs): ?>
                    <div class="recent-item" onclick="loadReceipt(<?= (int)$rs['id'] ?>)">
                        <span class="r-num"><?= sanitize($rs['order_number']) ?></span>
                        <span class="r-customer"><?= sanitize($rs['customer_name']) ?></span>
                        <span class="r-total"><?= sanitize($dealer_currency['currency_symbol']) ?> <?= number_format(convert_usd_to_local((float)$rs['total_amount'], $dealer_country), 2) ?></span>
                        <span class="r-time"><?= date('H:i', strtotime($rs['created_at'])) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- ===================== RIGHT PANEL (CART) ===================== -->
    <div class="right-panel">

        <!-- Cart header -->
        <div class="cart-header">
            <h2>&#128722; Cart <span id="cartCount" style="font-weight:400;color:#94A3B8">(0 items)</span></h2>
            <button class="cart-clear-btn" onclick="clearCart()">Clear all</button>
        </div>

        <!-- Cart items -->
        <div class="cart-items" id="cartItems">
            <div class="cart-empty" id="cartEmpty">
                <div class="ce-icon">&#128722;</div>
                <p>Cart is empty<br><small>Search and add products</small></p>
            </div>
        </div>

        <!-- Customer info -->
        <div class="customer-section">
            <h3>&#128100; Customer Info <span style="font-weight:400;text-transform:none;letter-spacing:0;color:#94A3B8;font-size:0.7rem">(optional)</span></h3>
            <div class="cust-grid">
                <input type="text" id="custName" class="cust-input full-col" placeholder="Customer name">
                <input type="tel" id="custPhone" class="cust-input" placeholder="Phone number">
                <input type="email" id="custEmail" class="cust-input" placeholder="Email address">
            </div>
        </div>

        <!-- Summary -->
        <div class="cart-summary" id="cartSummary">
            <div class="summary-row">
                <span class="s-label">Subtotal</span>
                <span class="s-value" id="subtotalVal"><?= sanitize($dealer_currency['currency_symbol']) ?> 0.00</span>
            </div>
            <div class="summary-row" id="taxRow" style="display:none">
                <span class="s-label" id="taxLabel">Tax</span>
                <span class="s-value" id="taxVal"><?= sanitize($dealer_currency['currency_symbol']) ?> 0.00</span>
            </div>
            <div class="summary-row total-row">
                <span class="s-label">Total</span>
                <span class="s-value" id="totalVal"><?= sanitize($dealer_currency['currency_symbol']) ?> 0.00</span>
            </div>
        </div>

        <!-- Complete sale -->
        <button class="complete-btn" id="completeBtn" onclick="completeSale()" disabled>
            Complete Sale
        </button>
    </div>
</div>

<!-- ===================== RECEIPT MODAL ===================== -->
<div class="modal-overlay" id="receiptModal">
    <div class="modal-box">
        <div class="modal-head">
            <h2>&#129534; Sale Complete</h2>
            <button class="modal-close" onclick="closeModal()">&#10005;</button>
        </div>
        <div class="modal-body">
            <div id="printArea">
                <div class="receipt" id="receiptContent">
                    <!-- Populated by JS -->
                </div>
            </div>
        </div>
        <div class="modal-foot">
            <button class="modal-btn btn-print" onclick="window.print()">&#128424; Print Receipt</button>
            <button class="modal-btn btn-new-sale" onclick="newSale()">&#43; New Sale</button>
        </div>
    </div>
</div>

<!-- Toast -->
<div id="toast"></div>

<!-- CSRF token for JS -->
<input type="hidden" id="csrfToken" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
<input type="hidden" id="dealerBizName" value="<?= htmlspecialchars($dealer['business_name'], ENT_QUOTES, 'UTF-8') ?>">
<input type="hidden" id="dealerPhone" value="<?= htmlspecialchars($dealer['phone'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
<input type="hidden" id="dealerCity" value="<?= htmlspecialchars($dealer['city'] ?? '', ENT_QUOTES, 'UTF-8') ?>">

<script>
/* ============================================================
 * State
 * ============================================================ */
var cart    = [];   // [{dp_id, product_type, product_name, unit_price, qty, stock_qty}]
var searchTimer = null;
var taxPct  = 0;    // Will be set after first sale from server
var CUR_SYM = <?= json_encode($dealer_currency['currency_symbol']) ?>;
var CUR_CODE = <?= json_encode($dealer_currency['currency_code']) ?>;
var EXCH_RATE = <?= json_encode($dealer_currency['exchange_rate']) ?>;

/* ============================================================
 * Search
 * ============================================================ */
document.getElementById('searchInput').addEventListener('input', function() {
    clearTimeout(searchTimer);
    var q = this.value.trim();
    if (q.length === 0) {
        showHint();
        return;
    }
    searchTimer = setTimeout(function() { doSearch(q); }, 280);
});

function doSearch(q) {
    var resultsArea = document.getElementById('resultsArea');
    resultsArea.innerHTML = '<div class="results-hint"><div class="hint-icon" style="font-size:1.5rem;animation:spin 0.6s linear infinite;display:inline-block;">&#9696;</div><p style="margin-top:8px">Searching...</p></div>';

    var fd = new FormData();
    fd.append('action', 'search_products');
    fd.append('q', q);

    fetch('pos.php', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(data) { renderResults(data.products || []); })
        .catch(function() {
            resultsArea.innerHTML = '<div class="no-results">Search failed. Please try again.</div>';
        });
}

function renderResults(products) {
    var area = document.getElementById('resultsArea');
    if (products.length === 0) {
        area.innerHTML = '<div class="no-results">&#128269; No products found in your inventory matching that search.</div>';
        return;
    }

    var icons = {
        'inverter': '&#9889;',
        'battery': '&#128267;',
        'panel': '&#9728;&#65039;',
        'installation_appliance': '&#128296;'
    };

    var html = '';
    products.forEach(function(p) {
        var inCart = cart.find(function(c) { return c.dp_id == p.dp_id; });
        var addLabel = inCart ? '&#10003; In Cart' : '&#43; Add';
        var addStyle = inCart ? 'background:#DCFCE7;color:#166534;' : '';
        html += '<div class="result-item" onclick="addToCart(' + JSON.stringify(p).replace(/"/g,'&quot;') + ')">' +
            '<div class="result-type-badge rt-' + escHtml(p.product_type) + '">' + (icons[p.product_type] || '&#128230;') + '</div>' +
            '<div class="result-info">' +
                '<div class="result-name">' + escHtml(p.product_name) + '</div>' +
                '<div class="result-meta">' + escHtml(p.company_name) + ' &mdash; ' + escHtml(p.spec_summary) + '</div>' +
            '</div>' +
            '<div class="result-price-area">' +
                '<div class="result-price">' + CUR_SYM + ' ' + (parseFloat(p.dealer_price) * EXCH_RATE).toFixed(2) + '</div>' +
                '<div class="result-stock stock-' + escHtml(p.stock_status) + '">' + escHtml(p.stock_quantity) + ' left</div>' +
            '</div>' +
            '<button class="result-add-btn" style="' + addStyle + '" title="Add to cart">' + addLabel + '</button>' +
        '</div>';
    });
    area.innerHTML = html;
}

function showHint() {
    document.getElementById('resultsArea').innerHTML =
        '<div class="results-hint" id="searchHint"><div class="hint-icon">&#9728;&#65039;</div><p>Search your inventory to add items to the cart</p></div>';
}

/* ============================================================
 * Cart management
 * ============================================================ */
function addToCart(p) {
    var dpId = parseInt(p.dp_id);
    var existing = cart.find(function(c) { return c.dp_id === dpId; });
    if (existing) {
        if (existing.qty < parseInt(p.stock_quantity)) {
            existing.qty++;
            showToast('Quantity updated', 'success');
        } else {
            showToast('Max stock reached (' + p.stock_quantity + ')', 'error');
            return;
        }
    } else {
        cart.push({
            dp_id:        dpId,
            product_type: p.product_type,
            product_name: p.product_name,
            unit_price:   parseFloat(p.dealer_price),
            qty:          1,
            stock_qty:    parseInt(p.stock_quantity)
        });
        showToast(p.product_name + ' added', 'success');
    }
    renderCart();
    // Re-render results to update "In Cart" state
    var q = document.getElementById('searchInput').value.trim();
    if (q.length > 0) doSearch(q);
}

function changeQty(dpId, delta) {
    var item = cart.find(function(c) { return c.dp_id === dpId; });
    if (!item) return;
    var newQty = item.qty + delta;
    if (newQty <= 0) { removeFromCart(dpId); return; }
    if (newQty > item.stock_qty) { showToast('Insufficient stock', 'error'); return; }
    item.qty = newQty;
    renderCart();
}

function removeFromCart(dpId) {
    cart = cart.filter(function(c) { return c.dp_id !== dpId; });
    renderCart();
}

function clearCart() {
    if (cart.length === 0) return;
    if (!confirm('Clear all items from cart?')) return;
    cart = [];
    renderCart();
}

function renderCart() {
    var container = document.getElementById('cartItems');
    var emptyMsg  = document.getElementById('cartEmpty');
    var countEl   = document.getElementById('cartCount');
    var btn       = document.getElementById('completeBtn');

    if (cart.length === 0) {
        container.innerHTML = '<div class="cart-empty"><div class="ce-icon">&#128722;</div><p>Cart is empty<br><small>Search and add products</small></p></div>';
        countEl.textContent = '(0 items)';
        btn.disabled = true;
        updateSummary(0);
        return;
    }

    countEl.textContent = '(' + cart.length + ' item' + (cart.length !== 1 ? 's' : '') + ')';
    btn.disabled = false;

    var icons = {
        'inverter': '&#9889;', 'battery': '&#128267;',
        'panel': '&#9728;', 'installation_appliance': '&#128296;'
    };

    var html = '';
    var subtotal = 0;
    cart.forEach(function(item) {
        var lineTotal = item.unit_price * item.qty;
        subtotal += lineTotal;
        html += '<div class="cart-item" id="ci-' + item.dp_id + '">' +
            '<div class="ci-info">' +
                '<div class="ci-name">' + (icons[item.product_type] || '') + ' ' + escHtml(item.product_name) + '</div>' +
                '<div class="ci-type">' + escHtml(item.product_type.replace('_', ' ')) + '</div>' +
                '<div class="ci-controls">' +
                    '<button class="qty-btn" onclick="changeQty(' + item.dp_id + ', -1)">&#8722;</button>' +
                    '<span class="qty-display">' + item.qty + '</span>' +
                    '<button class="qty-btn" onclick="changeQty(' + item.dp_id + ', 1)">&#43;</button>' +
                    '<span style="font-size:0.75rem;color:#94A3B8;margin-left:4px">/ ' + item.stock_qty + ' avail</span>' +
                '</div>' +
            '</div>' +
            '<div class="ci-price">' +
                '<div class="ci-line-total">' + CUR_SYM + ' ' + (lineTotal * EXCH_RATE).toFixed(2) + '</div>' +
                '<div class="ci-unit-price">' + CUR_SYM + ' ' + (item.unit_price * EXCH_RATE).toFixed(2) + ' each</div>' +
            '</div>' +
            '<button class="ci-remove" onclick="removeFromCart(' + item.dp_id + ')" title="Remove">&#10005;</button>' +
        '</div>';
    });
    container.innerHTML = html;
    updateSummary(subtotal);
}

function updateSummary(subtotal) {
    var taxAmt = subtotal * (taxPct / 100);
    var total  = subtotal + taxAmt;

    document.getElementById('subtotalVal').textContent = CUR_SYM + ' ' + (subtotal * EXCH_RATE).toFixed(2);
    document.getElementById('totalVal').textContent    = CUR_SYM + ' ' + (total * EXCH_RATE).toFixed(2);

    if (taxPct > 0) {
        document.getElementById('taxRow').style.display = '';
        document.getElementById('taxLabel').textContent = 'Tax (' + taxPct.toFixed(1) + '%)';
        document.getElementById('taxVal').textContent   = CUR_SYM + ' ' + (taxAmt * EXCH_RATE).toFixed(2);
    } else {
        document.getElementById('taxRow').style.display = 'none';
    }
}

/* ============================================================
 * Complete sale
 * ============================================================ */
function completeSale() {
    if (cart.length === 0) { showToast('Cart is empty', 'error'); return; }

    var btn = document.getElementById('completeBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Processing...';

    var fd = new FormData();
    fd.append('action',         'complete_sale');
    fd.append('csrf_token',     document.getElementById('csrfToken').value);
    fd.append('cart',           JSON.stringify(cart.map(function(c) { return { dp_id: c.dp_id, qty: c.qty }; })));
    fd.append('customer_name',  document.getElementById('custName').value.trim());
    fd.append('customer_phone', document.getElementById('custPhone').value.trim());
    fd.append('customer_email', document.getElementById('custEmail').value.trim());

    fetch('pos.php', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            btn.disabled = false;
            btn.innerHTML = 'Complete Sale';

            if (!data.success) {
                showToast(data.message || 'Sale failed', 'error');
                return;
            }

            // Update known tax rate for UI
            taxPct = parseFloat(data.tax_percent) || 0;

            // Show receipt
            showReceipt(data);

            // Clear cart
            cart = [];
            renderCart();
            document.getElementById('custName').value  = '';
            document.getElementById('custPhone').value = '';
            document.getElementById('custEmail').value = '';
            document.getElementById('searchInput').value = '';
            showHint();

            // Prepend to recent sales list without reload
            prependRecentSale(data);
        })
        .catch(function(err) {
            btn.disabled = false;
            btn.innerHTML = 'Complete Sale';
            showToast('Network error. Please try again.', 'error');
        });
}

function prependRecentSale(data) {
    var panel = document.querySelector('.recent-panel');
    var existing = panel.querySelector('p');
    if (existing) existing.remove();

    var custName = (data.customer && data.customer.name && data.customer.name !== 'Walk-in Customer')
        ? data.customer.name : 'Walk-in';

    var div = document.createElement('div');
    div.className = 'recent-item';
    div.setAttribute('onclick', 'loadReceipt(' + data.order_id + ')');
    div.innerHTML =
        '<span class="r-num">' + escHtml(data.order_number) + '</span>' +
        '<span class="r-customer">' + escHtml(custName) + '</span>' +
        '<span class="r-total">' + CUR_SYM + ' ' + (parseFloat(data.total) * EXCH_RATE).toFixed(2) + '</span>' +
        '<span class="r-time">just now</span>';

    var firstItem = panel.querySelector('.recent-item');
    if (firstItem) {
        panel.insertBefore(div, firstItem);
    } else {
        panel.appendChild(div);
    }

    // Keep max 10 in list
    var items = panel.querySelectorAll('.recent-item');
    if (items.length > 10) items[items.length - 1].remove();
}

/* ============================================================
 * Receipt
 * ============================================================ */
function showReceipt(data) {
    var biz   = document.getElementById('dealerBizName').value;
    var phone = document.getElementById('dealerPhone').value;
    var city  = document.getElementById('dealerCity').value;

    var itemsHtml = '';
    data.items.forEach(function(item) {
        itemsHtml +=
            '<tr>' +
                '<td>' + escHtml(item.product_name) + '<div class="item-qty">x' + item.qty + ' @ ' + CUR_SYM + ' ' + (parseFloat(item.unit_price) * EXCH_RATE).toFixed(2) + '</div></td>' +
                '<td>' + CUR_SYM + ' ' + (parseFloat(item.line_total) * EXCH_RATE).toFixed(2) + '</td>' +
            '</tr>';
    });

    var taxRow = '';
    if (parseFloat(data.tax_percent) > 0) {
        taxRow = '<div class="rt-row"><span>Tax (' + parseFloat(data.tax_percent).toFixed(1) + '%)</span><span>' + CUR_SYM + ' ' + (parseFloat(data.tax_amount) * EXCH_RATE).toFixed(2) + '</span></div>';
    }

    var custInfo = '';
    if (data.customer) {
        if (data.customer.name && data.customer.name !== 'Walk-in Customer') {
            custInfo += '<div><strong>' + escHtml(data.customer.name) + '</strong></div>';
        }
        if (data.customer.phone) custInfo += '<div>Tel: ' + escHtml(data.customer.phone) + '</div>';
        if (data.customer.email) custInfo += '<div>' + escHtml(data.customer.email) + '</div>';
    }

    var now = new Date();
    var dateStr = now.toLocaleString('en-US', { year:'numeric', month:'short', day:'2-digit',
                                                hour:'2-digit', minute:'2-digit' });

    var html = '<div class="receipt-header">' +
            '<div class="biz-name">' + escHtml(biz) + '</div>' +
            (city  ? '<div style="font-size:0.75rem;color:#475569">' + escHtml(city) + '</div>' : '') +
            (phone ? '<div style="font-size:0.75rem;color:#475569">Tel: ' + escHtml(phone) + '</div>' : '') +
            '<div class="order-num">' + escHtml(data.order_number) + '</div>' +
            '<div class="receipt-date">' + dateStr + '</div>' +
        '</div>' +
        '<hr class="receipt-divider">';

    if (custInfo) {
        html += '<div class="receipt-customer">' + custInfo + '</div>';
        html += '<hr class="receipt-divider">';
    }

    html +=
        '<table class="receipt-items">' +
            '<thead><tr><th>Item</th><th>Total</th></tr></thead>' +
            '<tbody>' + itemsHtml + '</tbody>' +
        '</table>' +
        '<div class="receipt-totals">' +
            '<div class="rt-row"><span>Subtotal</span><span>' + CUR_SYM + ' ' + (parseFloat(data.subtotal) * EXCH_RATE).toFixed(2) + '</span></div>' +
            taxRow +
            '<div class="rt-row grand"><span>TOTAL</span><span>' + CUR_SYM + ' ' + (parseFloat(data.total) * EXCH_RATE).toFixed(2) + '</span></div>' +
        '</div>' +
        '<hr class="receipt-divider">' +
        '<div class="receipt-footer">' +
            '<div>Thank you for your purchase!</div>' +
            '<div style="margin-top:4px;color:#94A3B8">Powered by SolarGlobal</div>' +
        '</div>';

    document.getElementById('receiptContent').innerHTML = html;
    document.getElementById('receiptModal').classList.add('active');
}

function loadReceipt(orderId) {
    var fd = new FormData();
    fd.append('action',   'get_receipt');
    fd.append('order_id', orderId);

    fetch('pos.php', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (!data.success) { showToast(data.message || 'Could not load receipt', 'error'); return; }

            var o = data.order;
            var items = data.items;

            var parsed = {
                order_number: o.order_number,
                subtotal:     parseFloat(o.total_amount),
                tax_percent:  0,
                tax_amount:   0,
                total:        parseFloat(o.total_amount),
                customer: {
                    name:  o.customer_name,
                    phone: o.customer_phone,
                    email: o.customer_email !== o.order_number && o.customer_email.indexOf('@internal.pos') === -1 ? o.customer_email : ''
                },
                items: items.map(function(i) {
                    return {
                        product_name: i.product_name,
                        qty:          i.quantity,
                        unit_price:   parseFloat(i.unit_price),
                        line_total:   parseFloat(i.total_price)
                    };
                })
            };

            showReceipt(parsed);
        })
        .catch(function() { showToast('Network error', 'error'); });
}

function closeModal() {
    document.getElementById('receiptModal').classList.remove('active');
}

function newSale() {
    closeModal();
    document.getElementById('searchInput').focus();
}

/* ============================================================
 * Utilities
 * ============================================================ */
function escHtml(str) {
    if (str == null) return '';
    return String(str)
        .replace(/&/g,  '&amp;')
        .replace(/</g,  '&lt;')
        .replace(/>/g,  '&gt;')
        .replace(/"/g,  '&quot;')
        .replace(/'/g,  '&#39;');
}

var toastTimer = null;
function showToast(msg, type) {
    var t = document.getElementById('toast');
    t.textContent = msg;
    t.className   = 'show' + (type ? ' toast-' + type : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function() { t.className = ''; }, 2800);
}

// Close modal on overlay click
document.getElementById('receiptModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

// Keyboard: Escape closes modal
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeModal();
});
</script>

</main>
</body>
</html>
