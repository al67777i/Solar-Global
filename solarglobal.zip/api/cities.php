<?php
/**
 * Cities API Endpoint
 * Returns city data, sun data, and seasonal information
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/city_helper.php';
require_once __DIR__ . '/../includes/helpers.php';

if (!rate_limit('api_cities', 60, 60)) { respond_rate_limited(); }

$action = $_GET['action'] ?? 'list';

try {
    switch ($action) {
        case 'list':
            $cities = getAllCities();
            echo json_encode(['success' => true, 'data' => $cities]);
            break;

        case 'grouped':
            $grouped = getCitiesByProvince();
            echo json_encode(['success' => true, 'data' => $grouped]);
            break;

        case 'detail':
            $id = (int)($_GET['id'] ?? 0);
            if (!$id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'City ID required']);
                break;
            }
            $city = getCityById($id);
            if (!$city) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'City not found']);
                break;
            }
            $sunData = getSunDataForCity($id);
            $city['sun_data'] = $sunData;
            echo json_encode(['success' => true, 'data' => $city]);
            break;

        case 'sun_data':
            $id = (int)($_GET['city_id'] ?? 0);
            $month = isset($_GET['month']) ? (int)$_GET['month'] : null;
            if (!$id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'City ID required']);
                break;
            }
            $data = getSunDataForCity($id, $month);
            echo json_encode(['success' => true, 'data' => $data]);
            break;

        case 'seasonal_appliances':
            $cityId = (int)($_GET['city_id'] ?? 0);
            $season = $_GET['season'] ?? getCurrentSeason();
            $validSeasons = ['summer', 'winter', 'monsoon', 'spring', 'all_year'];
            if (!in_array($season, $validSeasons)) {
                $season = getCurrentSeason();
            }
            if ($cityId) {
                $appliances = getRecommendedAppliances($cityId);
            } else {
                $appliances = getSeasonalAppliances($season);
            }
            echo json_encode([
                'success' => true,
                'season' => $season,
                'data' => $appliances
            ]);
            break;

        case 'generation_forecast':
            $cityId = (int)($_GET['city_id'] ?? 0);
            $panelWatts = (int)($_GET['panel_watts'] ?? 550);
            $numPanels = (int)($_GET['num_panels'] ?? 4);
            if (!$cityId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'City ID required']);
                break;
            }
            $forecast = getMonthlyGenerationForecast($cityId, $panelWatts, $numPanels);
            $annualKwh = array_sum(array_column($forecast, 'monthly_kwh'));
            echo json_encode([
                'success' => true,
                'city_id' => $cityId,
                'panel_watts' => $panelWatts,
                'num_panels' => $numPanels,
                'total_capacity_kw' => round(($panelWatts * $numPanels) / 1000, 2),
                'annual_generation_kwh' => round($annualKwh, 2),
                'monthly_forecast' => $forecast
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
} catch (Exception $e) {
    error_log("Cities API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error']);
}
