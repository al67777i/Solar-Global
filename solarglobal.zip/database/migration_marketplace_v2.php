<?php
/**
 * Phase 2 Migration: Marketplace Tables
 * Creates: customers, orders, order_items, dealer_reviews, installer_orders, watchlist
 * Updates: dealer_products to support installation_appliance type
 *
 * Run once: http://localhost/solarglobal/database/migration_marketplace_v2.php
 */
require_once __DIR__ . '/../includes/db.php';
$db = getDB();

$queries = [

    // ===== CUSTOMERS =====
    'customers: create table' => "
        CREATE TABLE IF NOT EXISTS customers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(150) NOT NULL,
            email VARCHAR(255) NOT NULL,
            google_id VARCHAR(100) NULL COMMENT 'Google OAuth sub ID',
            password_hash VARCHAR(255) NULL COMMENT 'NULL if Google-only login',
            phone VARCHAR(30) NULL,
            country_code VARCHAR(3) NULL,
            city VARCHAR(100) NULL,
            latitude DECIMAL(10,7) NULL,
            longitude DECIMAL(10,7) NULL,
            avatar_url VARCHAR(500) NULL,
            otp_code VARCHAR(10) NULL COMMENT '6-digit OTP for email login',
            otp_expires_at TIMESTAMP NULL,
            email_verified TINYINT(1) DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            last_login_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uk_email (email),
            UNIQUE KEY uk_google_id (google_id),
            INDEX idx_country (country_code),
            INDEX idx_active (is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    // ===== ORDERS =====
    'orders: create table' => "
        CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_number VARCHAR(20) NOT NULL COMMENT 'Unique display number e.g. ORD-20260518-0001',
            customer_id INT NOT NULL,
            dealer_id INT NOT NULL,
            status ENUM('pending','confirmed','ready','picked_up','cancelled') DEFAULT 'pending',
            total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            currency VARCHAR(3) DEFAULT 'USD',
            item_count INT DEFAULT 0,
            notes TEXT NULL COMMENT 'Customer notes',
            admin_notes TEXT NULL,
            pickup_deadline TIMESTAMP NULL COMMENT 'Auto-cancel if not picked up by this time',
            confirmed_at TIMESTAMP NULL,
            ready_at TIMESTAMP NULL,
            picked_up_at TIMESTAMP NULL,
            cancelled_at TIMESTAMP NULL,
            cancel_reason VARCHAR(255) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uk_order_number (order_number),
            INDEX idx_customer (customer_id),
            INDEX idx_dealer (dealer_id),
            INDEX idx_status (status),
            INDEX idx_created (created_at),
            INDEX idx_pickup_deadline (pickup_deadline),
            CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
            CONSTRAINT fk_orders_dealer FOREIGN KEY (dealer_id) REFERENCES dealers(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    // ===== ORDER ITEMS =====
    'order_items: create table' => "
        CREATE TABLE IF NOT EXISTS order_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            product_type ENUM('inverter','battery','panel','installation_appliance') NOT NULL,
            product_id INT NOT NULL,
            product_name VARCHAR(250) NOT NULL COMMENT 'Snapshot of name at order time',
            quantity INT NOT NULL DEFAULT 1,
            unit_price DECIMAL(12,2) NOT NULL,
            total_price DECIMAL(12,2) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_order (order_id),
            INDEX idx_product (product_type, product_id),
            CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    // ===== DEALER REVIEWS =====
    'dealer_reviews: create table' => "
        CREATE TABLE IF NOT EXISTS dealer_reviews (
            id INT AUTO_INCREMENT PRIMARY KEY,
            dealer_id INT NOT NULL,
            customer_id INT NOT NULL,
            order_id INT NOT NULL COMMENT 'One review per completed order',
            rating TINYINT NOT NULL COMMENT '1 to 5 stars',
            review_text TEXT NULL,
            status ENUM('pending','approved','rejected') DEFAULT 'pending',
            admin_response TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uk_order_review (order_id),
            INDEX idx_dealer (dealer_id),
            INDEX idx_customer (customer_id),
            INDEX idx_status (status),
            INDEX idx_rating (dealer_id, rating),
            CONSTRAINT fk_dealer_reviews_dealer FOREIGN KEY (dealer_id) REFERENCES dealers(id) ON DELETE CASCADE,
            CONSTRAINT fk_dealer_reviews_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
            CONSTRAINT fk_dealer_reviews_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    // ===== INSTALLER ORDERS (Installation Service Requests) =====
    'installer_orders: create table' => "
        CREATE TABLE IF NOT EXISTS installer_orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            customer_id INT NOT NULL,
            installer_id INT NOT NULL,
            status ENUM('requested','accepted','in_progress','completed','cancelled') DEFAULT 'requested',
            system_size_kw DECIMAL(8,2) NULL,
            system_type ENUM('on-grid','off-grid','hybrid') DEFAULT 'hybrid',
            description TEXT NULL COMMENT 'Customer description of needed work',
            address TEXT NULL COMMENT 'Installation address',
            latitude DECIMAL(10,7) NULL,
            longitude DECIMAL(10,7) NULL,
            estimated_cost DECIMAL(12,2) NULL COMMENT 'Installer quote',
            total_amount DECIMAL(12,2) NULL COMMENT 'Final agreed amount',
            currency VARCHAR(3) DEFAULT 'USD',
            scheduled_date DATE NULL,
            accepted_at TIMESTAMP NULL,
            started_at TIMESTAMP NULL,
            completed_at TIMESTAMP NULL,
            cancelled_at TIMESTAMP NULL,
            cancel_reason VARCHAR(255) NULL,
            customer_notes TEXT NULL,
            installer_notes TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_customer (customer_id),
            INDEX idx_installer (installer_id),
            INDEX idx_status (status),
            INDEX idx_scheduled (scheduled_date),
            CONSTRAINT fk_installer_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
            CONSTRAINT fk_installer_orders_installer FOREIGN KEY (installer_id) REFERENCES installers(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    // ===== WATCHLIST =====
    'watchlist: create table' => "
        CREATE TABLE IF NOT EXISTS watchlist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            customer_id INT NOT NULL,
            product_type ENUM('inverter','battery','panel','installation_appliance') NOT NULL,
            product_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uk_customer_product (customer_id, product_type, product_id),
            INDEX idx_customer (customer_id),
            CONSTRAINT fk_watchlist_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    // ===== CUSTOMER SESSIONS =====
    'customer_sessions: create table' => "
        CREATE TABLE IF NOT EXISTS customer_sessions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            customer_id INT NOT NULL,
            session_token VARCHAR(64) NOT NULL,
            ip_address VARCHAR(45) NULL,
            user_agent VARCHAR(500) NULL,
            expires_at TIMESTAMP NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uk_token (session_token),
            INDEX idx_customer (customer_id),
            INDEX idx_expires (expires_at),
            CONSTRAINT fk_customer_sessions_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ",

    // ===== UPDATE dealer_products to support installation_appliance =====
    'dealer_products: add installation_appliance type' => "
        ALTER TABLE dealer_products MODIFY COLUMN product_type ENUM('inverter','battery','panel','installation_appliance') NOT NULL
    ",

    // ===== UPDATE dealer_product_requests to support installation_appliance =====
    'dealer_product_requests: add installation_appliance type' => "
        ALTER TABLE dealer_product_requests MODIFY COLUMN product_type ENUM('inverter','battery','panel','installation_appliance') NOT NULL
    ",

    // ===== ADD avg_rating and total_reviews to dealers if missing =====
    'dealers: add avg_rating alias' => "
        ALTER TABLE dealers ADD COLUMN IF NOT EXISTS avg_rating DECIMAL(3,2) DEFAULT 0 COMMENT 'Alias for rating_avg for consistency'
    ",
    'dealers: add total_reviews' => "
        ALTER TABLE dealers ADD COLUMN IF NOT EXISTS total_reviews INT DEFAULT 0
    ",
];

echo "<h1>Phase 2: Marketplace Tables Migration</h1><pre>\n";

foreach ($queries as $label => $sql) {
    try {
        $db->exec($sql);
        echo "&#10004; $label\n";
    } catch (PDOException $e) {
        $msg = $e->getMessage();
        if (strpos($msg, 'already exists') !== false || strpos($msg, 'Duplicate') !== false) {
            echo "&#9197; $label (already exists)\n";
        } else {
            echo "&#10060; $label: $msg\n";
        }
    }
}

// Verify all tables
echo "\n--- Verification ---\n";
$expected = ['customers', 'orders', 'order_items', 'dealer_reviews', 'installer_orders', 'watchlist', 'customer_sessions'];
$tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
foreach ($expected as $t) {
    if (in_array($t, $tables)) {
        $count = $db->query("SELECT COUNT(*) FROM $t")->fetchColumn();
        echo "&#10004; $t exists ($count rows)\n";
    } else {
        echo "&#10060; $t MISSING!\n";
    }
}

// Clean up temp files
foreach (['_check_tables.php', '_check_tables2.php'] as $f) {
    $path = __DIR__ . '/' . $f;
    if (file_exists($path)) { unlink($path); echo "&#10004; Removed $f\n"; }
}

echo "\nPhase 2 migration complete!\n</pre>";
