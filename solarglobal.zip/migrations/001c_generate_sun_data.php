<?php
/**
 * Generate sun_data for all cities that don't have data yet
 * Uses latitude-based solar model for Pakistan
 */

require_once __DIR__ . '/../includes/db.php';

$db = getDB();

// Get cities without sun_data
$stmt = $db->query("
    SELECT c.id, c.name_en, c.latitude, c.longitude, c.elevation_m
    FROM cities c
    LEFT JOIN sun_data s ON c.id = s.city_id
    WHERE s.id IS NULL
    ORDER BY c.id
");
$cities = $stmt->fetchAll();

if (empty($cities)) {
    echo "All cities already have sun_data. Nothing to do.\n";
    exit(0);
}

echo "Generating sun_data for " . count($cities) . " cities...\n";

// Pakistan monthly average temperatures by latitude band (simplified model)
// Based on historical climate data
function getMonthlyTemp($lat, $elevation, $month) {
    // Base temperatures for Pakistan plains (30°N) by month
    $baseTemps = [12, 15, 21, 28, 34, 38, 35, 34, 31, 26, 19, 13];

    // Latitude adjustment: ~1.5°C cooler per degree north above 30°N
    $latAdjust = ($lat - 30.0) * -1.5;

    // Elevation adjustment: ~6.5°C per 1000m
    $elevAdjust = ($elevation / 1000.0) * -6.5;

    return round($baseTemps[$month - 1] + $latAdjust + $elevAdjust, 1);
}

// Calculate daylight hours from latitude and day of year
function getDaylightHours($lat, $dayOfYear) {
    $latRad = deg2rad($lat);
    $declination = 23.45 * sin(deg2rad((360/365) * ($dayOfYear - 81)));
    $decRad = deg2rad($declination);

    $hourAngle = acos(-tan($latRad) * tan($decRad));
    $daylight = (2 * $hourAngle * 12) / M_PI;

    return min(max($daylight, 8.0), 16.0);
}

// Peak sun hours model for Pakistan
function getPeakSunHours($lat, $month, $cloudCover, $elevation) {
    // Mid-day of each month
    $daysInMonth = [15, 46, 74, 105, 135, 166, 196, 227, 258, 288, 319, 349];
    $daylight = getDaylightHours($lat, $daysInMonth[$month - 1]);

    // Base PSH is roughly 55-65% of daylight in clear conditions for Pakistan
    $basePSH = $daylight * 0.58;

    // Cloud cover reduction
    $cloudFactor = 1.0 - ($cloudCover / 100.0) * 0.7;

    // Elevation bonus (clearer air at altitude)
    $elevBonus = min($elevation / 5000.0 * 0.15, 0.15);

    // Seasonal variation for Pakistan (monsoon July-Sept)
    $psh = $basePSH * $cloudFactor * (1 + $elevBonus);

    return round(min(max($psh, 3.0), 8.0), 2);
}

// Get cloud cover estimate by month and location
function getCloudCover($lat, $month, $isCoastal) {
    // Pakistan cloud cover patterns (monsoon heavy July-Aug)
    $baseClouds = [25, 22, 18, 14, 12, 18, 42, 40, 22, 12, 15, 22];

    // Northern areas get more clouds
    $latAdjust = max(0, ($lat - 30) * 2);

    // Coastal humidity adds clouds
    $coastalAdjust = $isCoastal ? 8 : 0;

    return min($baseClouds[$month - 1] + $latAdjust + $coastalAdjust, 65);
}

function getHumidity($lat, $month, $isCoastal, $elevation) {
    $baseHumidity = [60, 55, 45, 35, 30, 40, 65, 68, 55, 45, 50, 58];
    $coastalAdd = $isCoastal ? 15 : 0;
    $elevReduce = min($elevation / 2000.0 * 10, 10);
    return min(max($baseHumidity[$month - 1] + $coastalAdd - $elevReduce, 20), 85);
}

function getSunrise($lat, $month) {
    // Approximate sunrise for Pakistan timezone (UTC+5)
    $baseSunrise = ['07:10', '06:50', '06:20', '05:48', '05:22', '05:12', '05:22', '05:38', '05:58', '06:18', '06:48', '07:08'];
    $latAdjust = ($lat - 31.0) * -0.5; // minutes per degree lat

    $parts = explode(':', $baseSunrise[$month - 1]);
    $minutes = (int)$parts[0] * 60 + (int)$parts[1] + round($latAdjust);
    $h = str_pad(floor($minutes / 60), 2, '0', STR_PAD_LEFT);
    $m = str_pad($minutes % 60, 2, '0', STR_PAD_LEFT);
    return "$h:$m";
}

function getSunset($lat, $month) {
    $baseSunset = ['17:25', '17:55', '18:22', '18:47', '19:12', '19:25', '19:20', '19:00', '18:25', '17:47', '17:15', '17:10'];
    $latAdjust = ($lat - 31.0) * 0.5;

    $parts = explode(':', $baseSunset[$month - 1]);
    $minutes = (int)$parts[0] * 60 + (int)$parts[1] + round($latAdjust);
    $h = str_pad(floor($minutes / 60), 2, '0', STR_PAD_LEFT);
    $m = str_pad($minutes % 60, 2, '0', STR_PAD_LEFT);
    return "$h:$m";
}

// Insert prepared statement
$insert = $db->prepare("
    INSERT INTO sun_data (city_id, month, avg_sunrise, avg_sunset, avg_daylight_hours, peak_sun_hours, avg_irradiance_kwh_m2, avg_temperature_c, avg_cloud_cover_percent, avg_humidity_percent, panel_efficiency_factor)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

$coastalCities = ['Karachi', 'Gwadar', 'Thatta', 'Hub'];
$count = 0;

foreach ($cities as $city) {
    $isCoastal = in_array($city['name_en'], $coastalCities);

    for ($month = 1; $month <= 12; $month++) {
        $temp = getMonthlyTemp($city['latitude'], $city['elevation_m'], $month);
        $cloudCover = getCloudCover($city['latitude'], $month, $isCoastal);
        $humidity = getHumidity($city['latitude'], $month, $isCoastal, $city['elevation_m']);
        $psh = getPeakSunHours($city['latitude'], $month, $cloudCover, $city['elevation_m']);

        $daysInMonth = [15, 46, 74, 105, 135, 166, 196, 227, 258, 288, 319, 349];
        $daylight = getDaylightHours($city['latitude'], $daysInMonth[$month - 1]);

        // Irradiance ~ PSH * 1.0-1.1 factor
        $irradiance = round($psh * 1.02, 2);

        // Panel efficiency factor
        // Temp derating: -0.4%/°C above 25°C
        $tempLoss = max(0, ($temp - 25) * 0.004);
        // Cloud/humidity penalty
        $cloudLoss = ($cloudCover / 100) * 0.15;
        $humidityLoss = max(0, ($humidity - 50) / 100) * 0.05;

        $efficiencyFactor = round(max(0.55, min(0.90, 0.85 - $tempLoss - $cloudLoss - $humidityLoss)), 3);

        $sunrise = getSunrise($city['latitude'], $month);
        $sunset = getSunset($city['latitude'], $month);

        $insert->execute([
            $city['id'],
            $month,
            $sunrise,
            $sunset,
            round($daylight, 2),
            $psh,
            $irradiance,
            $temp,
            $cloudCover,
            $humidity,
            $efficiencyFactor
        ]);
        $count++;
    }
    echo "  ✓ {$city['name_en']} (lat: {$city['latitude']}, elev: {$city['elevation_m']}m)\n";
}

echo "\nDone! Inserted $count sun_data records for " . count($cities) . " cities.\n";

// Verify
$total = $db->query("SELECT COUNT(*) FROM sun_data")->fetchColumn();
$cityCount = $db->query("SELECT COUNT(DISTINCT city_id) FROM sun_data")->fetchColumn();
echo "Total sun_data records: $total (covering $cityCount cities)\n";
