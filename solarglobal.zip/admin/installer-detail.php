<?php
/**
 * Admin - Installer Detail
 * View full details, reviews, and orders for a specific installer
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = getDB();
$installer_id = (int)($_GET['id'] ?? 0);
$success = '';
$error = '';

if (!$installer_id) {
    $pageTitle = 'Installer Not Found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="content-wrapper" style="padding:24px;">
        <div style="background:white;border-radius:12px;padding:60px 24px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.04);">
            <div style="font-size:3rem;margin-bottom:16px;">&#9888;</div>
            <h2 style="color:#1E293B;margin-bottom:8px;">Installer Not Found</h2>
            <p style="color:#64748B;margin-bottom:24px;">No installer ID was provided.</p>
            <a href="installers.php" style="display:inline-block;padding:10px 24px;background:#0F172A;color:white;border-radius:8px;text-decoration:none;font-weight:600;font-size:0.875rem;">Back to Installers</a>
        </div>
    </div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';

    if ($action === 'approve_review') {
        $review_id = (int)($_POST['review_id'] ?? 0);
        if ($review_id) {
            $db->prepare("UPDATE installer_reviews SET status = 'approved' WHERE id = ? AND installer_id = ?")
               ->execute([$review_id, $installer_id]);
            // Recalc avg rating
            $db->prepare("UPDATE installers SET avg_rating = (SELECT AVG(rating) FROM installer_reviews WHERE installer_id = ? AND status = 'approved'), total_reviews = (SELECT COUNT(*) FROM installer_reviews WHERE installer_id = ? AND status = 'approved') WHERE id = ?")
               ->execute([$installer_id, $installer_id, $installer_id]);
            $success = 'Review approved.';
        }
    } elseif ($action === 'reject_review') {
        $review_id = (int)($_POST['review_id'] ?? 0);
        if ($review_id) {
            $db->prepare("UPDATE installer_reviews SET status = 'rejected' WHERE id = ? AND installer_id = ?")
               ->execute([$review_id, $installer_id]);
            $db->prepare("UPDATE installers SET avg_rating = (SELECT AVG(rating) FROM installer_reviews WHERE installer_id = ? AND status = 'approved'), total_reviews = (SELECT COUNT(*) FROM installer_reviews WHERE installer_id = ? AND status = 'approved') WHERE id = ?")
               ->execute([$installer_id, $installer_id, $installer_id]);
            $success = 'Review rejected.';
        }
    } elseif ($action === 'toggle_featured') {
        $db->prepare("UPDATE installers SET is_featured = NOT is_featured WHERE id = ?")
           ->execute([$installer_id]);
        $success = 'Featured status toggled.';
    } elseif ($action === 'approve') {
        $db->prepare("UPDATE installers SET status = 'approved' WHERE id = ?")
           ->execute([$installer_id]);
        $success = 'Installer approved.';
    } elseif ($action === 'activate') {
        $db->prepare("UPDATE installers SET status = 'active' WHERE id = ?")
           ->execute([$installer_id]);
        $success = 'Installer activated.';
    } elseif ($action === 'suspend') {
        $db->prepare("UPDATE installers SET status = 'suspended' WHERE id = ?")
           ->execute([$installer_id]);
        $success = 'Installer suspended.';
    }

    // Redirect to avoid resubmission
    if ($success) {
        header("Location: installer-detail.php?id={$installer_id}&msg=" . urlencode($success));
        exit;
    }
}

// Check for redirect message
if (!empty($_GET['msg'])) {
    $success = $_GET['msg'];
}

// Fetch installer
$stmt = $db->prepare("SELECT * FROM installers WHERE id = ?");
$stmt->execute([$installer_id]);
$installer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$installer) {
    $pageTitle = 'Installer Not Found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="content-wrapper" style="padding:24px;">
        <div style="background:white;border-radius:12px;padding:60px 24px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.04);">
            <div style="font-size:3rem;margin-bottom:16px;">&#9888;</div>
            <h2 style="color:#1E293B;margin-bottom:8px;">Installer Not Found</h2>
            <p style="color:#64748B;margin-bottom:24px;">No installer exists with ID ' . $installer_id . '.</p>
            <a href="installers.php" style="display:inline-block;padding:10px 24px;background:#0F172A;color:white;border-radius:8px;text-decoration:none;font-weight:600;font-size:0.875rem;">Back to Installers</a>
        </div>
    </div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = sanitize($installer['business_name']) . ' - Installer Detail';

// Fetch reviews
$reviews_stmt = $db->prepare("SELECT * FROM installer_reviews WHERE installer_id = ? ORDER BY created_at DESC");
$reviews_stmt->execute([$installer_id]);
$reviews = $reviews_stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch orders with customer info
$orders_stmt = $db->prepare("
    SELECT o.*, c.name AS customer_name, c.email AS customer_email
    FROM installer_orders o
    LEFT JOIN customers c ON o.customer_id = c.id
    WHERE o.installer_id = ?
    ORDER BY o.created_at DESC
");
$orders_stmt->execute([$installer_id]);
$orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);

// Compute stats
$completed_installs = 0;
$total_revenue = 0;
$orders_by_status = [];
foreach ($orders as $o) {
    $st = $o['status'];
    $orders_by_status[$st] = ($orders_by_status[$st] ?? 0) + 1;
    if ($st === 'completed') {
        $completed_installs++;
        $total_revenue += (float)($o['total_amount'] ?? 0);
    }
}

$reviews_by_status = [];
foreach ($reviews as $r) {
    $st = $r['status'];
    $reviews_by_status[$st] = ($reviews_by_status[$st] ?? 0) + 1;
}

$avg_rating = $installer['avg_rating'] ? number_format((float)$installer['avg_rating'], 1) : null;
$total_review_count = count($reviews);

// Status colors
$status_colors = [
    'pending'   => ['bg' => '#FEF3C7', 'color' => '#92400E'],
    'approved'  => ['bg' => '#DBEAFE', 'color' => '#1E40AF'],
    'active'    => ['bg' => '#DCFCE7', 'color' => '#166534'],
    'suspended' => ['bg' => '#FEE2E2', 'color' => '#991B1B'],
    'rejected'  => ['bg' => '#F1F5F9', 'color' => '#475569'],
];
$sc = $status_colors[$installer['status']] ?? $status_colors['pending'];

include __DIR__ . '/includes/header.php';
?>

<style>
.detail-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}
.detail-stat-card {
    background: white;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    border: 1px solid #E2E8F0;
    text-align: center;
}
.detail-stat-value {
    font-size: 1.5rem;
    font-weight: 800;
    color: #0F172A;
}
.detail-stat-value.amber { color: #F59E0B; }
.detail-stat-value.green { color: #16A34A; }
.detail-stat-value.blue { color: #1565C0; }
.detail-stat-value.purple { color: #7C3AED; }
.detail-stat-label {
    font-size: 0.8125rem;
    color: #64748B;
    margin-top: 4px;
}

.profile-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    border: 1px solid #E2E8F0;
    padding: 28px;
    margin-bottom: 24px;
}
.profile-grid {
    display: grid;
    grid-template-columns: 1fr 200px;
    gap: 32px;
}
@media (max-width: 768px) {
    .profile-grid { grid-template-columns: 1fr; }
}
.profile-field {
    margin-bottom: 14px;
}
.profile-field-label {
    font-size: 0.75rem;
    font-weight: 600;
    color: #94A3B8;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 2px;
}
.profile-field-value {
    font-size: 0.9rem;
    color: #1E293B;
    line-height: 1.5;
}
.profile-logo {
    width: 180px;
    height: 180px;
    border-radius: 12px;
    object-fit: cover;
    background: #F1F5F9;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid #E2E8F0;
    overflow: hidden;
}
.profile-logo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.section-title {
    font-size: 1.1rem;
    font-weight: 700;
    color: #1E293B;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.section-count {
    font-size: 0.75rem;
    font-weight: 600;
    padding: 2px 10px;
    border-radius: 12px;
    background: #F1F5F9;
    color: #64748B;
}

.review-card {
    background: white;
    border-radius: 10px;
    border: 1px solid #E2E8F0;
    padding: 20px;
    margin-bottom: 14px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.03);
}
.review-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 10px;
    flex-wrap: wrap;
    gap: 8px;
}
.review-stars {
    color: #F59E0B;
    font-size: 0.9rem;
    letter-spacing: 1px;
}
.review-meta {
    font-size: 0.75rem;
    color: #94A3B8;
}
.review-title {
    font-weight: 700;
    font-size: 0.95rem;
    color: #1E293B;
    margin-bottom: 6px;
}
.review-body {
    font-size: 0.85rem;
    color: #475569;
    line-height: 1.6;
    margin-bottom: 12px;
}
.review-details {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
    font-size: 0.75rem;
    color: #64748B;
    margin-bottom: 12px;
}
.review-detail-item span {
    font-weight: 600;
    color: #475569;
}
.verified-badge {
    display: inline-block;
    padding: 2px 8px;
    background: #DCFCE7;
    color: #166534;
    font-size: 0.65rem;
    font-weight: 700;
    border-radius: 4px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.review-status {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 4px;
    font-size: 0.7rem;
    font-weight: 600;
}
.review-actions {
    display: flex;
    gap: 6px;
    margin-top: 10px;
}
.action-btn {
    padding: 5px 14px;
    border: none;
    border-radius: 5px;
    font-size: 0.75rem;
    font-weight: 600;
    cursor: pointer;
    transition: opacity 0.2s;
}
.action-btn:hover { opacity: 0.85; }
.action-btn-approve { background: #16A34A; color: white; }
.action-btn-reject { background: #DC2626; color: white; }
.action-btn-activate { background: #1565C0; color: white; }
.action-btn-suspend { background: #F59E0B; color: white; }
.action-btn-featured { background: #7C3AED; color: white; }

.orders-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 800px;
}
.orders-table th {
    padding: 12px 16px;
    text-align: left;
    font-size: 0.8125rem;
    color: #64748B;
    font-weight: 600;
    background: #F8FAFC;
}
.orders-table td {
    padding: 12px 16px;
    font-size: 0.85rem;
    color: #475569;
    border-bottom: 1px solid #F1F5F9;
}

.featured-badge {
    display: inline-block;
    padding: 3px 10px;
    background: #FEF3C7;
    color: #92400E;
    font-size: 0.7rem;
    font-weight: 700;
    border-radius: 4px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-badge {
    display: inline-block;
    padding: 3px 12px;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 600;
}

.top-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}
</style>

<div class="content-wrapper" style="padding: 24px;">

    <!-- Page Header -->
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap; gap:12px;">
        <div style="display:flex; align-items:center; gap:16px; flex-wrap:wrap;">
            <a href="installers.php" style="display:inline-flex; align-items:center; gap:6px; padding:8px 16px; background:#F1F5F9; color:#475569; border-radius:8px; text-decoration:none; font-size:0.8125rem; font-weight:600; transition:background 0.2s;">
                &#8592; Back to Installers
            </a>
            <h2 style="font-size:1.4rem; color:#1E293B; margin:0;">
                <?= sanitize($installer['business_name']) ?>
            </h2>
            <span class="status-badge" style="background:<?= $sc['bg'] ?>; color:<?= $sc['color'] ?>;">
                <?= ucfirst(sanitize($installer['status'])) ?>
            </span>
            <?php if (!empty($installer['is_featured'])): ?>
                <span class="featured-badge">&#9733; Featured</span>
            <?php endif; ?>
        </div>
        <div class="top-actions">
            <?php if ($installer['status'] === 'pending'): ?>
                <form method="POST" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="approve">
                    <button type="submit" class="action-btn action-btn-approve">Approve</button>
                </form>
            <?php elseif ($installer['status'] === 'approved'): ?>
                <form method="POST" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="activate">
                    <button type="submit" class="action-btn action-btn-activate">Activate</button>
                </form>
            <?php elseif ($installer['status'] === 'suspended'): ?>
                <form method="POST" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="activate">
                    <button type="submit" class="action-btn action-btn-activate">Reactivate</button>
                </form>
            <?php endif; ?>
            <?php if (in_array($installer['status'], ['active', 'approved'])): ?>
                <form method="POST" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="suspend">
                    <button type="submit" class="action-btn action-btn-suspend" onclick="return confirm('Suspend this installer?')">Suspend</button>
                </form>
            <?php endif; ?>
            <form method="POST" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="toggle_featured">
                <button type="submit" class="action-btn action-btn-featured">
                    <?= !empty($installer['is_featured']) ? 'Remove Featured' : 'Make Featured' ?>
                </button>
            </form>
        </div>
    </div>

    <?php if ($success): ?>
        <div style="background:#DCFCE7; color:#166534; padding:12px 16px; border-radius:8px; margin-bottom:16px; font-size:0.875rem;">
            <?= sanitize($success) ?>
        </div>
    <?php endif; ?>

    <!-- Stats Row -->
    <div class="detail-stats">
        <div class="detail-stat-card">
            <div class="detail-stat-value green"><?= $completed_installs ?></div>
            <div class="detail-stat-label">Completed Installations</div>
        </div>
        <div class="detail-stat-card">
            <div class="detail-stat-value blue">$<?= number_format($total_revenue, 2) ?></div>
            <div class="detail-stat-label">Total Revenue</div>
        </div>
        <div class="detail-stat-card">
            <div class="detail-stat-value amber"><?= $avg_rating ?? 'N/A' ?></div>
            <div class="detail-stat-label">Avg Rating</div>
        </div>
        <div class="detail-stat-card">
            <div class="detail-stat-value"><?= $total_review_count ?></div>
            <div class="detail-stat-label">Total Reviews</div>
        </div>
        <div class="detail-stat-card">
            <div class="detail-stat-value purple"><?= (int)($installer['team_size'] ?? 0) ?></div>
            <div class="detail-stat-label">Team Size</div>
        </div>
        <div class="detail-stat-card">
            <div class="detail-stat-value"><?= (int)($installer['years_experience'] ?? 0) ?></div>
            <div class="detail-stat-label">Years Experience</div>
        </div>
    </div>

    <!-- Profile Card -->
    <div class="profile-card">
        <h3 class="section-title">Installer Profile</h3>
        <div class="profile-grid">
            <div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:0 32px;">
                    <div class="profile-field">
                        <div class="profile-field-label">Business Name</div>
                        <div class="profile-field-value"><?= sanitize($installer['business_name'] ?? '') ?></div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Owner Name</div>
                        <div class="profile-field-value"><?= sanitize($installer['owner_name'] ?? '') ?: '-' ?></div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Email</div>
                        <div class="profile-field-value">
                            <a href="mailto:<?= sanitize($installer['email'] ?? '') ?>" style="color:#1565C0; text-decoration:none;"><?= sanitize($installer['email'] ?? '') ?></a>
                        </div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Phone</div>
                        <div class="profile-field-value"><?= sanitize($installer['phone'] ?? '') ?: '-' ?></div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Address</div>
                        <div class="profile-field-value"><?= sanitize($installer['address'] ?? '') ?: '-' ?></div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">City / Region</div>
                        <div class="profile-field-value">
                            <?= sanitize($installer['city'] ?? '') ?>
                            <?= ($installer['city'] ?? '') && ($installer['region'] ?? '') ? ', ' : '' ?>
                            <?= sanitize($installer['region'] ?? '') ?>
                            <?= !($installer['city'] ?? '') && !($installer['region'] ?? '') ? '-' : '' ?>
                        </div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Country</div>
                        <div class="profile-field-value"><?= sanitize($installer['country_code'] ?? '') ?: '-' ?></div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Service Radius</div>
                        <div class="profile-field-value"><?= $installer['service_radius_km'] ? sanitize($installer['service_radius_km']) . ' km' : '-' ?></div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">License Number</div>
                        <div class="profile-field-value"><?= sanitize($installer['license_number'] ?? '') ?: '-' ?></div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Specializations</div>
                        <div class="profile-field-value"><?= sanitize($installer['specializations'] ?? '') ?: '-' ?></div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Price per kW</div>
                        <div class="profile-field-value"><?= isset($installer['price_per_kw']) && $installer['price_per_kw'] ? '$' . number_format((float)$installer['price_per_kw'], 2) : '-' ?></div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Completed Installations</div>
                        <div class="profile-field-value"><?= (int)($installer['completed_installations'] ?? 0) ?></div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Coordinates</div>
                        <div class="profile-field-value">
                            <?php if ($installer['latitude'] && $installer['longitude']): ?>
                                <?= sanitize($installer['latitude']) ?>, <?= sanitize($installer['longitude']) ?>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="profile-field">
                        <div class="profile-field-label">Joined</div>
                        <div class="profile-field-value"><?= $installer['created_at'] ? date('M j, Y', strtotime($installer['created_at'])) : '-' ?></div>
                    </div>
                </div>
                <?php if (!empty($installer['about_text'])): ?>
                    <div class="profile-field" style="margin-top:8px;">
                        <div class="profile-field-label">About</div>
                        <div class="profile-field-value" style="max-width:700px;"><?= nl2br(sanitize($installer['about_text'])) ?></div>
                    </div>
                <?php endif; ?>
            </div>
            <div style="display:flex; justify-content:center; align-items:flex-start;">
                <div class="profile-logo">
                    <?php if (!empty($installer['logo_path'])): ?>
                        <img src="../<?= sanitize($installer['logo_path']) ?>" alt="Logo">
                    <?php else: ?>
                        <span style="font-size:3rem; color:#CBD5E1;">&#9888;</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Reviews Section -->
    <div style="margin-bottom:24px;">
        <h3 class="section-title">
            Reviews
            <span class="section-count"><?= $total_review_count ?> total</span>
            <?php if (!empty($reviews_by_status['pending'])): ?>
                <span class="section-count" style="background:#FEF3C7; color:#92400E;"><?= $reviews_by_status['pending'] ?> pending</span>
            <?php endif; ?>
        </h3>

        <?php if (empty($reviews)): ?>
            <div style="background:white; border-radius:10px; padding:40px; text-align:center; color:#94A3B8; border:1px solid #E2E8F0; box-shadow:0 1px 4px rgba(0,0,0,0.03);">
                No reviews yet for this installer.
            </div>
        <?php else: ?>
            <?php foreach ($reviews as $review):
                $r_sc = $status_colors[$review['status']] ?? $status_colors['pending'];
                $stars_html = '';
                for ($i = 1; $i <= 5; $i++) {
                    $stars_html .= $i <= (int)$review['rating'] ? '&#9733;' : '&#9734;';
                }
            ?>
                <div class="review-card">
                    <div class="review-header">
                        <div>
                            <span class="review-stars"><?= $stars_html ?></span>
                            <span style="font-size:0.8rem; color:#64748B; margin-left:6px;"><?= (int)$review['rating'] ?>/5</span>
                            <?php if (!empty($review['verified'])): ?>
                                <span class="verified-badge" style="margin-left:8px;">Verified</span>
                            <?php endif; ?>
                        </div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <span class="review-status" style="background:<?= $r_sc['bg'] ?>; color:<?= $r_sc['color'] ?>;">
                                <?= ucfirst(sanitize($review['status'])) ?>
                            </span>
                            <span class="review-meta"><?= $review['created_at'] ? date('M j, Y', strtotime($review['created_at'])) : '' ?></span>
                        </div>
                    </div>

                    <?php if (!empty($review['title'])): ?>
                        <div class="review-title"><?= sanitize($review['title']) ?></div>
                    <?php endif; ?>

                    <?php if (!empty($review['review_text'])): ?>
                        <div class="review-body"><?= nl2br(sanitize($review['review_text'])) ?></div>
                    <?php endif; ?>

                    <div class="review-details">
                        <div class="review-detail-item">Reviewer: <span><?= sanitize($review['reviewer_name'] ?? '') ?></span></div>
                        <?php if (!empty($review['reviewer_email'])): ?>
                            <div class="review-detail-item">Email: <span><?= sanitize($review['reviewer_email']) ?></span></div>
                        <?php endif; ?>
                        <?php if (!empty($review['project_type'])): ?>
                            <div class="review-detail-item">Project: <span><?= sanitize($review['project_type']) ?></span></div>
                        <?php endif; ?>
                        <?php if (!empty($review['system_size_kw'])): ?>
                            <div class="review-detail-item">System: <span><?= sanitize($review['system_size_kw']) ?> kW</span></div>
                        <?php endif; ?>
                        <?php if (!empty($review['installation_date'])): ?>
                            <div class="review-detail-item">Installed: <span><?= date('M j, Y', strtotime($review['installation_date'])) ?></span></div>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($review['admin_response'])): ?>
                        <div style="background:#F8FAFC; border-radius:6px; padding:10px 14px; margin-bottom:10px; font-size:0.8rem; color:#475569;">
                            <strong style="color:#1E293B;">Admin Response:</strong> <?= nl2br(sanitize($review['admin_response'])) ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($review['status'] === 'pending'): ?>
                        <div class="review-actions">
                            <form method="POST" style="display:inline">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="approve_review">
                                <input type="hidden" name="review_id" value="<?= (int)$review['id'] ?>">
                                <button type="submit" class="action-btn action-btn-approve">Approve</button>
                            </form>
                            <form method="POST" style="display:inline">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="reject_review">
                                <input type="hidden" name="review_id" value="<?= (int)$review['id'] ?>">
                                <button type="submit" class="action-btn action-btn-reject">Reject</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Orders Section -->
    <div style="margin-bottom:24px;">
        <h3 class="section-title">
            Orders
            <span class="section-count"><?= count($orders) ?> total</span>
        </h3>

        <div style="background:white; border-radius:12px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.04); border:1px solid #E2E8F0; overflow-x:auto;">
            <?php if (empty($orders)): ?>
                <div style="padding:40px; text-align:center; color:#94A3B8;">
                    No orders found for this installer.
                </div>
            <?php else: ?>
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>System Type</th>
                            <th>Size (kW)</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Scheduled</th>
                            <th>Completed</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order):
                            $o_status_colors = [
                                'requested'   => ['bg' => '#FEF3C7', 'color' => '#92400E'],
                                'accepted'    => ['bg' => '#DBEAFE', 'color' => '#1E40AF'],
                                'in_progress' => ['bg' => '#E0E7FF', 'color' => '#3730A3'],
                                'completed'   => ['bg' => '#DCFCE7', 'color' => '#166534'],
                                'cancelled'   => ['bg' => '#FEE2E2', 'color' => '#991B1B'],
                            ];
                            $o_sc = $o_status_colors[$order['status']] ?? $o_status_colors['requested'];
                        ?>
                            <tr>
                                <td style="font-weight:600; color:#1E293B;">#<?= (int)$order['id'] ?></td>
                                <td>
                                    <div style="font-weight:600; color:#1E293B;"><?= sanitize($order['customer_name'] ?? 'Unknown') ?></div>
                                    <div style="font-size:0.75rem; color:#94A3B8;"><?= sanitize($order['customer_email'] ?? '') ?></div>
                                </td>
                                <td><?= sanitize($order['system_type'] ?? '-') ?></td>
                                <td><?= $order['system_size_kw'] ? sanitize($order['system_size_kw']) : '-' ?></td>
                                <td style="font-weight:600;">
                                    <?php if ($order['total_amount']): ?>
                                        <?= sanitize($order['currency'] ?? '$') ?><?= number_format((float)$order['total_amount'], 2) ?>
                                    <?php elseif ($order['estimated_cost']): ?>
                                        <span style="color:#94A3B8;">~<?= sanitize($order['currency'] ?? '$') ?><?= number_format((float)$order['estimated_cost'], 2) ?></span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="status-badge" style="background:<?= $o_sc['bg'] ?>; color:<?= $o_sc['color'] ?>;">
                                        <?= ucfirst(str_replace('_', ' ', sanitize($order['status']))) ?>
                                    </span>
                                </td>
                                <td><?= $order['scheduled_date'] ? date('M j, Y', strtotime($order['scheduled_date'])) : '-' ?></td>
                                <td><?= $order['completed_at'] ? date('M j, Y', strtotime($order['completed_at'])) : '-' ?></td>
                                <td style="font-size:0.75rem; color:#94A3B8;"><?= $order['created_at'] ? date('M j, Y', strtotime($order['created_at'])) : '-' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
