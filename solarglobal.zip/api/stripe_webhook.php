<?php
/**
 * Stripe Webhook Handler
 * Receives and processes Stripe webhook events for dealer/installer subscriptions
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/stripe_config.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// Get raw POST body
$payload = file_get_contents('php://input');
$sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

// Get webhook secret
$keys = getStripeKeys();
$webhookSecret = $keys['webhook_secret'];

// Verify signature if webhook secret is configured
if (!empty($webhookSecret)) {
    if (!verifyStripeWebhookSignature($payload, $sigHeader, $webhookSecret)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid signature']);
        error_log('Stripe webhook: Invalid signature');
        exit();
    }
}

// Parse the event
$event = json_decode($payload, true);
if (!$event || !isset($event['type'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid payload']);
    exit();
}

$db = getDB();
$eventType = $event['type'];
$data = $event['data']['object'] ?? [];

// Log the event
error_log('Stripe webhook received: ' . $eventType . ' | ID: ' . ($event['id'] ?? 'unknown'));

try {
    switch ($eventType) {

        case 'checkout.session.completed':
            handleCheckoutCompleted($db, $data);
            break;

        case 'invoice.payment_succeeded':
            handleInvoicePaymentSucceeded($db, $data);
            break;

        case 'invoice.payment_failed':
            handleInvoicePaymentFailed($db, $data);
            break;

        case 'customer.subscription.deleted':
            handleSubscriptionDeleted($db, $data);
            break;

        case 'customer.subscription.updated':
            handleSubscriptionUpdated($db, $data);
            break;

        default:
            // Acknowledge unhandled events
            break;
    }

    http_response_code(200);
    echo json_encode(['status' => 'ok']);

} catch (Exception $e) {
    error_log('Stripe webhook error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}

// --- Handler functions ---

/**
 * Handle checkout.session.completed event
 * Activates the subscription for the dealer or installer
 */
function handleCheckoutCompleted(PDO $db, array $data): void {
    $customerId = $data['customer'] ?? '';
    $subscriptionId = $data['subscription'] ?? '';
    $customerEmail = $data['customer_details']['email'] ?? ($data['customer_email'] ?? '');
    $metadata = $data['metadata'] ?? [];
    $type = $metadata['type'] ?? '';
    $entityId = $metadata['dealer_id'] ?? ($metadata['installer_id'] ?? null);

    if ($type === 'dealer' && $entityId) {
        updateEntitySubscription($db, 'dealers', (int)$entityId, $customerId, $subscriptionId, 'active');
    } elseif ($type === 'installer' && $entityId) {
        updateEntitySubscription($db, 'installers', (int)$entityId, $customerId, $subscriptionId, 'active');
    } else {
        // Try to find by email in both tables
        if (!empty($customerEmail)) {
            $found = findAndUpdateByEmail($db, $customerEmail, $customerId, $subscriptionId, 'active');
            if (!$found) {
                error_log("Stripe webhook: checkout.session.completed - no matching dealer/installer for email: $customerEmail");
            }
        }
    }
}

/**
 * Handle invoice.payment_succeeded event
 * Renews the subscription period
 */
function handleInvoicePaymentSucceeded(PDO $db, array $data): void {
    $subscriptionId = $data['subscription'] ?? '';
    $customerId = $data['customer'] ?? '';

    if (empty($subscriptionId)) return;

    // Renew for dealers
    $stmt = $db->prepare("
        UPDATE dealers SET
            subscription_status = 'active',
            subscription_expires_at = DATE_ADD(NOW(), INTERVAL 1 MONTH)
        WHERE stripe_subscription_id = ? OR stripe_customer_id = ?
    ");
    $stmt->execute([$subscriptionId, $customerId]);

    // Renew for installers
    $stmt = $db->prepare("
        UPDATE installers SET
            subscription_status = 'active',
            subscription_expires_at = DATE_ADD(NOW(), INTERVAL 1 MONTH)
        WHERE stripe_subscription_id = ? OR stripe_customer_id = ?
    ");
    $stmt->execute([$subscriptionId, $customerId]);
}

/**
 * Handle invoice.payment_failed event
 * Sets subscription to past_due
 */
function handleInvoicePaymentFailed(PDO $db, array $data): void {
    $subscriptionId = $data['subscription'] ?? '';
    $customerId = $data['customer'] ?? '';

    if (empty($subscriptionId)) return;

    $stmt = $db->prepare("UPDATE dealers SET subscription_status = 'past_due' WHERE stripe_subscription_id = ? OR stripe_customer_id = ?");
    $stmt->execute([$subscriptionId, $customerId]);

    $stmt = $db->prepare("UPDATE installers SET subscription_status = 'past_due' WHERE stripe_subscription_id = ? OR stripe_customer_id = ?");
    $stmt->execute([$subscriptionId, $customerId]);
}

/**
 * Handle customer.subscription.deleted event
 * Sets subscription to canceled
 */
function handleSubscriptionDeleted(PDO $db, array $data): void {
    $subscriptionId = $data['id'] ?? '';
    $customerId = $data['customer'] ?? '';

    if (empty($subscriptionId)) return;

    $stmt = $db->prepare("UPDATE dealers SET subscription_status = 'canceled' WHERE stripe_subscription_id = ? OR stripe_customer_id = ?");
    $stmt->execute([$subscriptionId, $customerId]);

    $stmt = $db->prepare("UPDATE installers SET subscription_status = 'canceled' WHERE stripe_subscription_id = ? OR stripe_customer_id = ?");
    $stmt->execute([$subscriptionId, $customerId]);
}

/**
 * Handle customer.subscription.updated event
 * Updates subscription status based on Stripe status
 */
function handleSubscriptionUpdated(PDO $db, array $data): void {
    $subscriptionId = $data['id'] ?? '';
    $customerId = $data['customer'] ?? '';
    $stripeStatus = $data['status'] ?? '';

    if (empty($subscriptionId)) return;

    // Map Stripe statuses to our statuses
    $statusMap = [
        'active' => 'active',
        'past_due' => 'past_due',
        'canceled' => 'canceled',
        'unpaid' => 'past_due',
        'incomplete' => 'past_due',
        'incomplete_expired' => 'canceled',
        'trialing' => 'active',
    ];

    $localStatus = $statusMap[$stripeStatus] ?? 'none';

    $stmt = $db->prepare("UPDATE dealers SET subscription_status = ? WHERE stripe_subscription_id = ? OR stripe_customer_id = ?");
    $stmt->execute([$localStatus, $subscriptionId, $customerId]);

    $stmt = $db->prepare("UPDATE installers SET subscription_status = ? WHERE stripe_subscription_id = ? OR stripe_customer_id = ?");
    $stmt->execute([$localStatus, $subscriptionId, $customerId]);
}

// --- Utility functions ---

/**
 * Update entity subscription fields by ID
 */
function updateEntitySubscription(PDO $db, string $table, int $id, string $customerId, string $subscriptionId, string $status): void {
    $stmt = $db->prepare("
        UPDATE {$table} SET
            stripe_customer_id = ?,
            stripe_subscription_id = ?,
            subscription_status = ?,
            subscription_started_at = COALESCE(subscription_started_at, NOW()),
            subscription_expires_at = DATE_ADD(NOW(), INTERVAL 1 MONTH)" .
            ", status = CASE WHEN status IN ('approved','pending','inactive') THEN 'active' ELSE status END" . "
        WHERE id = ?
    ");
    $stmt->execute([$customerId, $subscriptionId, $status, $id]);
}

/**
 * Try to find dealer/installer by email and update subscription
 */
function findAndUpdateByEmail(PDO $db, string $email, string $customerId, string $subscriptionId, string $status): bool {
    // Check dealers first
    $stmt = $db->prepare("SELECT id FROM dealers WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $dealer = $stmt->fetch();
    if ($dealer) {
        updateEntitySubscription($db, 'dealers', (int)$dealer['id'], $customerId, $subscriptionId, $status);
        return true;
    }

    // Check installers
    $stmt = $db->prepare("SELECT id FROM installers WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $installer = $stmt->fetch();
    if ($installer) {
        updateEntitySubscription($db, 'installers', (int)$installer['id'], $customerId, $subscriptionId, $status);
        return true;
    }

    return false;
}
