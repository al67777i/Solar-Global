/**
 * Recommender V9 — Dual-mode solar recommendation engine
 *
 * Features:
 *  - Two modes: Informative (general/educational) & Shop (dealer inventory)
 *  - Country-aware currency (auto-detects from location)
 *  - Inverter type selection (on-grid / off-grid / hybrid)
 *  - Net metering with sell-back rate slider
 *  - Battery backup configuration
 *  - Parallel inverter cost comparison
 *  - Nearby shop/dealer matching (shop mode)
 *  - Component customization (swap inverter, panel, battery)
 */

// ─── State ─────────────────────────────────────────────────────────────────
let backupHours = 8;
let selectedSystemType = "hybrid";
let netMeteringEnabled = false;
let sellbackRate = 80;
let shopRadius = 25;
let recommendationMode = "informative"; // 'informative' or 'shop'

// Currency state (updated from API response)
let activeCurrency = {
  code: "USD",
  symbol: "$",
  rate: 1.0,
  label: "International (USD)",
  flag: "",
  is_local: false,
};

// ─── Currency-Aware Price Formatting ───────────────────────────────────────
function fmtPrice(usdAmount) {
  if (!usdAmount && usdAmount !== 0) return "—";
  const converted = Math.round((usdAmount || 0) * activeCurrency.rate);
  return activeCurrency.symbol + converted.toLocaleString();
}

function fmtPriceRaw(usdAmount) {
  return Math.round((usdAmount || 0) * activeCurrency.rate).toLocaleString();
}

function escHtml(str) {
  if (!str) return "";
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ─── Recommendation Mode Selector ──────────────────────────────────────────
function initSystemTypeSelector() {
  const container = document.getElementById("system-type-container");
  if (!container) return;

  const loc = window.SolarLocation?.getLocation?.() || {};
  const hasLocation = !!loc.lat;
  const countryName = loc.name || "";

  container.innerHTML = `
    <div class="system-type-section">

        <!-- ═══ SYSTEM TYPE CARDS ═══ -->
        <div class="section-header" style="margin-top:2rem;">
            <h2 class="section-title">
                <span class="title-icon">⚡</span>
                Choose Your System Type
            </h2>
            <p class="section-subtitle">This determines how your solar system connects to the electrical grid</p>
        </div>

        <div class="system-type-cards">
            <!-- On-Grid -->
            <div class="system-type-card" id="type-on-grid" onclick="selectSystemType('on-grid')" tabindex="0">
                <div class="stc-icon-wrap stc-ongrid">
                    <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
                        <circle cx="24" cy="24" r="22" stroke="currentColor" stroke-width="2" fill="none"/>
                        <path d="M14 24h20M24 14v20" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
                        <circle cx="24" cy="24" r="6" fill="currentColor" opacity="0.2"/>
                    </svg>
                </div>
                <h3 class="stc-title">On-Grid</h3>
                <p class="stc-desc">Connected to utility grid. Export surplus energy for credits. No battery needed.</p>
                <ul class="stc-features">
                    <li>Lowest upfront cost</li>
                    <li>Net metering income</li>
                    <li>No backup during outage</li>
                </ul>
                <div class="stc-badge stc-badge-savings">Best for Savings</div>
            </div>

            <!-- Hybrid (default) -->
            <div class="system-type-card selected" id="type-hybrid" onclick="selectSystemType('hybrid')" tabindex="0">
                <div class="stc-recommended">RECOMMENDED</div>
                <div class="stc-icon-wrap stc-hybrid">
                    <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
                        <rect x="4" y="16" width="16" height="16" rx="3" stroke="currentColor" stroke-width="2"/>
                        <rect x="28" y="16" width="16" height="16" rx="3" stroke="currentColor" stroke-width="2"/>
                        <path d="M20 24h8" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
                        <path d="M24 8v6M24 34v6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-dasharray="2 3"/>
                    </svg>
                </div>
                <h3 class="stc-title">Hybrid</h3>
                <p class="stc-desc">Best of both worlds. Battery backup + optional grid export for maximum flexibility.</p>
                <ul class="stc-features">
                    <li>Battery backup during outage</li>
                    <li>Optional net metering</li>
                    <li>Most versatile solution</li>
                </ul>
                <div class="stc-badge stc-badge-recommended">Most Popular</div>
            </div>

            <!-- Off-Grid -->
            <div class="system-type-card" id="type-off-grid" onclick="selectSystemType('off-grid')" tabindex="0">
                <div class="stc-icon-wrap stc-offgrid">
                    <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
                        <circle cx="24" cy="24" r="22" stroke="currentColor" stroke-width="2" fill="none"/>
                        <path d="M16 16l16 16M32 16L16 32" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
                    </svg>
                </div>
                <h3 class="stc-title">Off-Grid</h3>
                <p class="stc-desc">Completely independent. Full battery storage for 100% self-sufficiency.</p>
                <ul class="stc-features">
                    <li>Total energy independence</li>
                    <li>No electricity bills</li>
                    <li>Higher battery cost</li>
                </ul>
                <div class="stc-badge stc-badge-independence">Full Independence</div>
            </div>
        </div>

        <!-- Net Metering Section -->
        <div id="net-metering-section" class="net-metering-section" style="display:none;">
            <div class="nm-header">
                <h3><span>📊</span> Net Metering Configuration</h3>
                <label class="nm-toggle">
                    <input type="checkbox" id="net-metering-toggle" onchange="toggleNetMetering(this.checked)">
                    <span class="nm-toggle-slider"></span>
                    <span class="nm-toggle-label">Enable Net Metering</span>
                </label>
            </div>
            <div id="net-metering-controls" class="nm-controls" style="display:none;">
                <div class="nm-slider-group">
                    <label class="nm-label">
                        Grid Sell-Back Rate
                        <span class="nm-value" id="sellback-display">${sellbackRate}%</span>
                    </label>
                    <p class="nm-help">For every 100 units you export, the grid returns <strong id="sellback-units">${sellbackRate}</strong> units</p>
                    <input type="range" id="sellback-slider" min="0" max="100" value="${sellbackRate}" step="5"
                           class="nm-slider" oninput="updateSellbackRate(this.value)">
                    <div class="nm-slider-labels"><span>0%</span><span>50%</span><span>100%</span></div>
                </div>
                <div class="nm-slider-group">
                    <label class="nm-label">
                        Electricity Rate
                        <span class="nm-value" id="rate-display">per kWh</span>
                    </label>
                    <input type="number" id="electricity-rate" class="nm-input" placeholder="e.g. 15" min="0" step="0.5"
                           oninput="updateElectricityRate(this.value)">
                    <p class="nm-help">Cost per kWh in your local currency</p>
                </div>
            </div>
        </div>

        <!-- Backup Hours -->
        <div id="backup-section" class="backup-section">
            <h3><span>🔋</span> Battery Backup Duration</h3>
            <div class="backup-slider-wrap">
                <input type="range" id="backup-hours-slider" min="1" max="24" value="8" step="0.5"
                       class="backup-slider" oninput="updateBackupHours(this.value)">
                <div class="backup-display">
                    <span class="backup-value" id="backup-hours-display">8</span>
                    <span class="backup-unit">hours</span>
                </div>
            </div>
            <div class="backup-info">
                <div class="backup-stat">
                    <span class="stat-label">Night Load</span>
                    <span class="stat-value" id="backup-load-display">—</span>
                </div>
                <div class="backup-stat">
                    <span class="stat-label">Battery Required</span>
                    <span class="stat-value" id="backup-battery-display">—</span>
                </div>
            </div>
        </div>

        <!-- Preferred Countries of Origin -->
        <div class="country-preference-section" style="margin-top: 1.5rem; padding: 1.5rem; border: 1.5px solid #E2E8F0; border-radius: 16px; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
            <h3 style="font-size: 1.1rem; font-weight: 700; color: #1e293b; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 8px;">
                <span>🌍</span> Preferred Countries of Origin
            </h3>
            <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 1rem;">
                Filter solar components (inverter, panels, battery) by manufacturing country. Leave all unchecked to show all options.
            </p>
            <div id="preferred-countries-grid" class="country-pill-grid">
                <!-- Populated dynamically -->
            </div>
        </div>

    </div>`;

  // Render country list
  renderCountryPreferences();

  // Set defaults
  selectSystemType("hybrid");
  recommendationMode = "informative";
}

function renderCountryPreferences() {
  const grid = document.getElementById("preferred-countries-grid");
  if (!grid || !window.dbCountries) return;

  // Get user's country code from location
  const userLoc = window.SolarLocation?.getLocation?.() || {};
  const userCC = (
    userLoc.countryCode ||
    window.userCountryCode ||
    ""
  ).toLowerCase();

  // Sort: user's country first, then by product_count DESC
  const sortedCountries = [...window.dbCountries].sort((a, b) => {
    const aIsUser =
      (a.code || "").toLowerCase() === userCC ||
      (a.name || "").toLowerCase() === userCC;
    const bIsUser =
      (b.code || "").toLowerCase() === userCC ||
      (b.name || "").toLowerCase() === userCC;
    if (aIsUser && !bIsUser) return -1;
    if (!aIsUser && bIsUser) return 1;
    return (b.product_count || 0) - (a.product_count || 0);
  });

  // SMART DEFAULT SELECTION: Top manufacturing countries + user's country
  const topManufacturingCountries = [
    "China",
    "United States",
    "Germany",
    "Japan",
    "South Korea",
    "India",
    "Taiwan",
    "Netherlands",
  ];

  // Get user's country from various sources
  let userCountry = null;
  if (window.appState?.detectedCountry) {
    userCountry = window.appState.detectedCountry;
  } else if (window.dbCountries) {
    // Try to detect from browser/IP (if available in window)
    const detected = window.userCountryCode || window.detectedCountry;
    if (detected) {
      const found = window.dbCountries.find(
        (c) =>
          c.code?.toLowerCase() === detected.toLowerCase() ||
          c.name?.toLowerCase() === detected.toLowerCase(),
      );
      if (found) userCountry = found.name;
    }
  }

  // Default selected countries: top manufacturers + user's country
  const defaultSelected = new Set(topManufacturingCountries);
  if (userCountry && !defaultSelected.has(userCountry)) {
    defaultSelected.add(userCountry);
  }

  // Add Select All / Clear All / Smart Default buttons
  const controls = `
        <div class="country-controls" style="margin-bottom: 1rem; display: flex; gap: 0.5rem; flex-wrap: wrap; align-items: center; width: 100%;">
            <button type="button" onclick="selectSmartDefaults()" class="btn-country-control btn-primary" title="Select top manufacturing countries + your country">
                ⭐ Smart Selection (${defaultSelected.size})
            </button>
            <button type="button" onclick="selectAllCountries()" class="btn-country-control">
                ✓ Select All
            </button>
            <button type="button" onclick="clearAllCountries()" class="btn-country-control">
                ✗ Clear All
            </button>
            <span class="country-count" style="margin-left: auto; color: #64748b; font-size: 0.85rem;">
                ${sortedCountries.length} countries available
            </span>
        </div>
    `;

  // Render countries with pill design
  grid.innerHTML =
    controls +
    sortedCountries
      .map((c) => {
        const isDefaultSelected = defaultSelected.has(c.name);
        const isTopManufacturer = topManufacturingCountries.includes(c.name);
        const productCount = c.product_count || 0;

        return `
        <div class="country-pill ${isDefaultSelected ? "active" : ""}"
             id="lbl-country-${c.code}"
             onclick="toggleCountryPill(this, '${c.code}')"
             role="checkbox"
             aria-checked="${isDefaultSelected}">
            <input type="checkbox" value="${c.name}" class="country-pref-checkbox"
                   ${isDefaultSelected ? "checked" : ""}
                   style="display:none;">
            <span class="pill-flag">${c.flag_emoji || "🏳️"}</span>
            <span class="pill-name">
                ${c.name}
                ${isTopManufacturer ? '<span class="badge-top" title="Top manufacturer">⭐</span>' : ""}
                ${userCountry === c.name ? '<span class="badge-your" title="Your country">📍</span>' : ""}
            </span>
            <span class="pill-count">(${productCount})</span>
        </div>
        `;
      })
      .join("");

  // Store default selected for smart selection button
  window._defaultSelectedCountries = defaultSelected;
}

// Add helper functions
window.toggleCountryPill = function (el, code) {
  const cb = el.querySelector(".country-pref-checkbox");
  if (cb) {
    cb.checked = !cb.checked;
    if (cb.checked) {
      el.classList.add("active");
      el.setAttribute("aria-checked", "true");
    } else {
      el.classList.remove("active");
      el.setAttribute("aria-checked", "false");
    }
  }
};

window.selectAllCountries = function () {
  document.querySelectorAll(".country-pref-checkbox").forEach((cb) => {
    cb.checked = true;
    const pill = cb.closest(".country-pill");
    if (pill) {
      pill.classList.add("active");
      pill.setAttribute("aria-checked", "true");
    }
  });
};

window.clearAllCountries = function () {
  document.querySelectorAll(".country-pref-checkbox").forEach((cb) => {
    cb.checked = false;
    const pill = cb.closest(".country-pill");
    if (pill) {
      pill.classList.remove("active");
      pill.setAttribute("aria-checked", "false");
    }
  });
};

window.selectSmartDefaults = function () {
  // First clear all
  window.clearAllCountries();

  // Then select defaults
  const defaultSet = window._defaultSelectedCountries || new Set();
  document.querySelectorAll(".country-pref-checkbox").forEach((cb) => {
    if (defaultSet.has(cb.value)) {
      cb.checked = true;
      const pill = cb.closest(".country-pill");
      if (pill) {
        pill.classList.add("active");
        pill.setAttribute("aria-checked", "true");
      }
    }
  });
};

function calculateAndApplySmartDefaults() {
  let nightWh = 0;
  let dayWh = 0;
  const appliances = window.appState?.selectedAppliances || [];
  const nightHours = [18, 19, 20, 21, 22, 23, 0, 1, 2, 3, 4, 5];
  const dayHours = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17];

  const usageType = window.appState?.usageType || "residential";
  if (
    (usageType === "commercial" || usageType === "industrial") &&
    window._hourlyLoadKw
  ) {
    // Use live graph data
    nightHours.forEach((h) => {
      if (window._hourlyLoadKw[h] !== undefined)
        nightWh += window._hourlyLoadKw[h] * 1000;
    });
    dayHours.forEach((h) => {
      if (window._hourlyLoadKw[h] !== undefined)
        dayWh += window._hourlyLoadKw[h] * 1000;
    });
  } else {
    // Sum appliance hourly loads
    appliances.forEach((app) => {
      const qty = app.quantity || 1;
      const w = app.watt_typical || app.wattage || 0;
      const factor = (app.loadFactor || 100) / 100;
      if (app.hourlyUsage) {
        nightHours.forEach((h) => {
          if (app.hourlyUsage[h] === 1) nightWh += w * qty * factor;
        });
        dayHours.forEach((h) => {
          if (app.hourlyUsage[h] === 1) dayWh += w * qty * factor;
        });
      }
    });
  }

  const totalWh = dayWh + nightWh;
  const rNight = totalWh > 0 ? nightWh / totalWh : 0;

  let sysType = "hybrid";
  let hBackup = 4.0;

  if (rNight < 0.15 || nightWh < 1000) {
    sysType = "on-grid";
    hBackup = 0;
    window.lastCalculatedBackupHours = 4.0; // fallback default
  } else {
    sysType = "hybrid";
    const pNightAvg = nightWh / 12;
    // Smart defaults: always recommend at least 8h for residential
    const usageTypeForDefault = window.appState?.usageType || "residential";
    if (usageTypeForDefault === "industrial") {
      hBackup = pNightAvg <= 5000 ? 4.0 : 2.0;
    } else if (usageTypeForDefault === "commercial") {
      hBackup = pNightAvg <= 3000 ? 6.0 : 4.0;
    } else {
      // Residential: minimum 8h, scale up for low night load
      if (pNightAvg <= 200) {
        hBackup = 12.0; // Very light night load → long backup
      } else if (pNightAvg <= 500) {
        hBackup = 10.0;
      } else if (pNightAvg <= 1000) {
        hBackup = 8.0;
      } else if (pNightAvg <= 3000) {
        hBackup = 8.0;
      } else if (pNightAvg <= 8000) {
        hBackup = 6.0;
      } else {
        hBackup = 4.0;
      }
    }
    window.lastCalculatedBackupHours = hBackup;
  }

  // Apply system type
  selectSystemType(sysType);

  // Apply backup hours - ensure slider max allows 24h
  const slider = document.getElementById("backup-hours-slider");
  if (slider) {
    slider.max = 24; // Ensure max is 24
    slider.value = hBackup;
  }
  updateBackupHours(hBackup);
}
window.calculateAndApplySmartDefaults = calculateAndApplySmartDefaults;

// ─── System Type Selection ─────────────────────────────────────────────────
function selectSystemType(type) {
  selectedSystemType = type;

  document
    .querySelectorAll(".system-type-card")
    .forEach((c) => c.classList.remove("selected"));
  const card = document.getElementById("type-" + type);
  if (card) card.classList.add("selected");

  const nmSection = document.getElementById("net-metering-section");
  // Net metering only for on-grid and hybrid - NOT off-grid
  if (nmSection)
    nmSection.style.display =
      type === "on-grid" || type === "hybrid" ? "block" : "none";

  const backupSection = document.getElementById("backup-section");
  // Backup hours only for off-grid and hybrid - NOT on-grid
  if (backupSection)
    backupSection.style.display = type === "on-grid" ? "none" : "block";

  if (type === "on-grid") {
    backupHours = 0;
    const display = document.getElementById("backup-hours-display");
    if (display) display.textContent = "0";
    const slider = document.getElementById("backup-hours-slider");
    if (slider) slider.value = 0;
    // Auto-enable net metering for on-grid
    const toggle = document.getElementById("net-metering-toggle");
    if (toggle && !toggle.checked) {
      toggle.checked = true;
      toggleNetMetering(true);
    }
  } else if (type === "off-grid") {
    // Off-grid: disable net metering if it was on
    netMeteringEnabled = false;
    const toggle = document.getElementById("net-metering-toggle");
    if (toggle && toggle.checked) {
      toggle.checked = false;
      toggleNetMetering(false);
    }
  } else {
    const slider = document.getElementById("backup-hours-slider");
    if (slider && parseFloat(slider.value) === 0) {
      const defaultH = window.lastCalculatedBackupHours || 4.0;
      slider.value = defaultH;
      updateBackupHours(defaultH);
    }
  }

  if (window.appState) window.appState.systemType = type;
  // Trigger forecast recalculation with new system type
  triggerForecastUpdate();
}

function toggleNetMetering(enabled) {
  netMeteringEnabled = enabled;
  const controls = document.getElementById("net-metering-controls");
  if (controls) controls.style.display = enabled ? "flex" : "none";
  // Trigger forecast recalculation with updated net metering state
  triggerForecastUpdate();
}

function updateSellbackRate(val) {
  sellbackRate = parseInt(val);
  const display = document.getElementById("sellback-display");
  const units = document.getElementById("sellback-units");
  if (display) display.textContent = val + "%";
  if (units) units.textContent = val;
  // Trigger forecast recalculation with updated sellback rate
  triggerForecastUpdate();
}

/** Push current net metering / system type state to the energy forecast module */
function triggerForecastUpdate() {
  if (
    window.energyForecast &&
    window.energyForecast.updateFromConfigurator &&
    typeof configuratorState !== "undefined" &&
    configuratorState.current
  ) {
    const payload = Object.assign({}, configuratorState, {
      systemType: window.appState?.systemType || selectedSystemType || "hybrid",
      netMetering: netMeteringEnabled,
      sellbackRate: sellbackRate,
    });
    window.energyForecast.updateFromConfigurator(payload);
  }
}

function updateElectricityRate(val) {
  const display = document.getElementById("rate-display");
  if (display) display.textContent = val ? val + "/kWh" : "per kWh";
}

function updateBackupHours(val) {
  backupHours = parseFloat(val);
  const display = document.getElementById("backup-hours-display");
  if (display) display.textContent = val;

  const totalWatts = window.appState?.totalWatts || 0;
  const loadDisplay = document.getElementById("backup-load-display");
  const battDisplay = document.getElementById("backup-battery-display");

  if (loadDisplay) loadDisplay.textContent = totalWatts.toLocaleString() + "W";
  if (battDisplay && totalWatts > 0) {
    const sysV = totalWatts <= 1440 ? 12 : totalWatts <= 3600 ? 24 : 48;
    const reqWh = totalWatts * backupHours * 1.2;
    const reqAh = Math.ceil(reqWh / sysV);
    battDisplay.textContent =
      "~" + reqAh.toLocaleString() + "Ah @ " + sysV + "V";
  }
}

function updateShopRadius(val) {
  shopRadius = parseInt(val);
  const display = document.getElementById("shop-radius-display");
  if (display) display.textContent = val;
}

// ─── Main API Call ─────────────────────────────────────────────────────────
async function findSolarSystemV8() {
  const _usageCheck = window.appState?.usageType || "residential";
  const _isManualType =
    _usageCheck === "commercial" || _usageCheck === "industrial";
  const _hasGraphData =
    _isManualType &&
    window._hourlyLoadKw &&
    Math.max(...window._hourlyLoadKw) > 0;
  if (
    !window.appState?.selectedAppliances?.length &&
    !window.appState?.manualLoad &&
    !_hasGraphData
  ) {
    alert(
      _isManualType
        ? "Please set your peak load using the load graph before generating recommendations."
        : "Please select at least one appliance.",
    );
    return;
  }

  const modeLabel =
    recommendationMode === "shop"
      ? "Finding dealers & pricing"
      : "Analyzing your energy needs";
  showLoading(modeLabel + "...");

  try {
    let appliances = (window.appState.selectedAppliances || []).map((item) => {
      if (!item.hourlyUsage) {
        item.hourlyUsage = Array(24).fill(0);
        if (item.startTime !== undefined && item.endTime !== undefined) {
          for (let h = item.startTime; h < item.endTime; h++)
            item.hourlyUsage[h] = 1;
        }
      }
      const entry = {
        id: item.applianceId || item.id || 0,
        quantity: item.quantity || 1,
        hours: item.hourlyUsage.filter((h) => h === 1).length,
        hourlyUsage: item.hourlyUsage,
        loadFactor: item.loadFactor || 100,
      };
      // For manual/commercial/industrial loads, pass watt data directly
      if (item.isManualLoad || item.watt_typical) {
        entry.watt_typical = item.watt_typical || 0;
        entry.surge_load_watts = item.surge_load_watts || 0;
        entry.is_manual_load = true;
        entry.name_en = item.name_en || "Manual Load";
        if (item.hourlyLoad) entry.hourlyLoad = item.hourlyLoad;
      }
      return entry;
    });

    // Fallback: if no valid manual load in appliances but manualLoad or graph data exists, build from it
    const usageType = window.appState.usageType || "residential";
    if (usageType === "commercial" || usageType === "industrial") {
      const hasManual = appliances.some(
        (a) => a.is_manual_load && a.watt_typical > 0,
      );
      if (!hasManual) {
        // Try manualLoad state first, then live graph data
        const ml = window.appState.manualLoad;
        const liveGraph = window._hourlyLoadKw || [];
        const livePeakKw = Math.max(...liveGraph, 0);
        const liveHourlyW = liveGraph.map((kw) => Math.round(kw * 1000));

        let peakW = ml?.peak_watts || livePeakKw * 1000;
        let hourlyW =
          ml?.hourly_load?.length === 24 ? ml.hourly_load : liveHourlyW;

        if (peakW > 0) {
          const hourlyUsage = hourlyW.map((w) => (w > 0 ? 1 : 0));
          appliances = [
            {
              id: 0,
              quantity: 1,
              hours: hourlyUsage.filter((h) => h === 1).length || 10,
              hourlyUsage:
                hourlyUsage.length === 24 ? hourlyUsage : Array(24).fill(1),
              loadFactor: 100,
              watt_typical: peakW,
              surge_load_watts: Math.round(peakW * 1.5),
              is_manual_load: true,
              name_en:
                usageType === "industrial"
                  ? "Industrial Load"
                  : "Commercial Load",
              hourlyLoad: hourlyW.length === 24 ? hourlyW : [],
            },
          ];
        }
      }
    }

    const csrfToken = window.csrfToken || "";
    if (!csrfToken) {
      hideLoading();
      alert("Security token missing. Please refresh the page.");
      return;
    }

    const loc = window.SolarLocation?.getLocation?.() || {};
    const solarData = window.SolarLocation?.getSolarData?.() || {};
    const cityId =
      window.citySelector?.getCityId?.() ||
      localStorage.getItem("selectedCityId") ||
      0;

    // Build manual_load top-level field for commercial/industrial
    let manualLoadPayload = null;
    if (usageType === "commercial" || usageType === "industrial") {
      const ml = window.appState.manualLoad;
      if (ml && ml.peak_watts > 0) {
        manualLoadPayload = {
          peak_watts: ml.peak_watts,
          daily_kwh: ml.daily_kwh || 0,
          operating_hours: ml.operating_hours || 10,
          three_phase: ml.three_phase || false,
          hourly_load: ml.hourly_load || [],
          usage_type: ml.usage_type || usageType,
        };
      } else {
        // Fallback: read directly from the live graph
        const lg = window._hourlyLoadKw || [];
        const pk = Math.max(...lg, 0);
        if (pk > 0) {
          manualLoadPayload = {
            peak_watts: pk * 1000,
            daily_kwh: lg.reduce((s, v) => s + v, 0),
            operating_hours: lg.filter((v) => v > 0).length || 10,
            three_phase: window.appState.selectedPhase === 3,
            hourly_load: lg.map((kw) => Math.round(kw * 1000)),
            usage_type: usageType,
          };
        }
      }
    }

    const selectedCountries = [];
    document
      .querySelectorAll(".country-pref-checkbox:checked")
      .forEach((cb) => {
        selectedCountries.push(cb.value);
      });

    const payload = {
      csrf_token: csrfToken,
      appliances,
      manual_load: manualLoadPayload,
      backup_hours: backupHours,
      city_id: parseInt(cityId) || 0,
      system_type: selectedSystemType,
      recommendation_mode: recommendationMode,
      country_code: loc.countryCode || "",
      net_metering: netMeteringEnabled,
      sellback_rate: sellbackRate,
      electricity_rate: parseFloat(
        document.getElementById("electricity-rate")?.value || 0,
      ),
      latitude: loc.lat || 0,
      longitude: loc.lng || 0,
      shop_radius_km: shopRadius,
      peak_sun_hours: solarData.avg_sun_hours || solarData.peakSunHours || 0,
      ambient_temp_c: solarData.avg_temperature || solarData.temperature || 0,
      usage_type: window.appState.usageType || "residential",
      three_phase:
        window.appState.manualLoad?.three_phase ||
        window.appState.selectedPhase === 3,
      preferred_countries: selectedCountries,
    };

    const response = await fetch("api/recommend_v8.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    // Read raw text first so we can diagnose empty / non-JSON bodies
    const rawText = await response.text();

    // Check if response is ok
    if (!response.ok) {
      throw new Error(
        `Server responded with status: ${response.status} ${response.statusText}`,
      );
    }

    if (!rawText || rawText.trim() === "") {
      throw new Error(
        "Server returned an empty response. The calculation may have timed out. " +
        "Try reducing backup hours or the number of appliances, then try again."
      );
    }

    let data;
    try {
      data = JSON.parse(rawText);
    } catch (parseErr) {
      // Log the raw response to help diagnose PHP errors/warnings prepended to JSON
      console.error("Raw server response:", rawText.substring(0, 500));
      throw new Error(
        "Server returned an invalid response (not valid JSON). " +
        "A PHP error may have occurred. Check the browser console for details."
      );
    }
    hideLoading();

    if (data.success) {
      // Update currency from response
      if (data.currency) {
        activeCurrency = {
          code: data.currency.code || "USD",
          symbol: data.currency.symbol || "$",
          rate: data.currency.rate || 1.0,
          label: data.currency.label || "USD",
          flag: data.currency.flag || "",
          is_local: data.currency.is_local || false,
        };
      }

      window.appState.recommendations = data;
      window.appState.activeCurrency = activeCurrency;
      if (typeof saveState === "function") saveState();

      renderV9Results(data);
      goToStep(3);
    } else {
      handleV8Error(data);
    }
  } catch (err) {
    hideLoading();
    console.error("Recommendation Error:", err);

    // Better error message
    let errorMessage = "Unable to connect to the recommendation server. ";

    if (
      err.message.includes("Failed to fetch") ||
      err.message.includes("NetworkError")
    ) {
      errorMessage += "Please check your internet connection and try again.";
    } else if (err.message.includes("status:")) {
      errorMessage += `Server error: ${err.message}. Please try again later.`;
    } else if (err.message.includes("JSON")) {
      errorMessage +=
        "Received invalid response from server. Please refresh and try again.";
    } else {
      errorMessage += "Please refresh the page and try again.";
    }

    // Display error in UI instead of alert
    const container = document.getElementById("recommendations-container");
    if (container) {
      container.innerHTML = `
                <div class="v8-error-container" style="max-width: 600px; margin: 3rem auto; padding: 2rem; background: #fef2f2; border: 2px solid #fecaca; border-radius: 12px;">
                    <div style="text-align: center; margin-bottom: 1.5rem;">
                        <div style="font-size: 3rem; margin-bottom: 0.5rem;">⚠️</div>
                        <h2 style="color: #991b1b; font-size: 1.5rem; margin: 0;">Connection Error</h2>
                    </div>
                    <p style="color: #7f1d1d; font-size: 1rem; line-height: 1.6; margin-bottom: 1.5rem;">
                        ${errorMessage}
                    </p>
                    <div style="margin-bottom: 1rem; padding: 1rem; background: white; border-radius: 8px; font-size: 0.875rem; color: #64748b;">
                        <strong>Technical details:</strong> ${err.message}
                    </div>
                    <div style="display: flex; gap: 1rem; justify-content: center;">
                        <button onclick="location.reload()" class="btn-primary" style="padding: 0.75rem 1.5rem; background: #dc2626; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">
                            🔄 Refresh Page
                        </button>
                        <button onclick="goToStep(2)" class="btn-secondary" style="padding: 0.75rem 1.5rem; background: white; color: #dc2626; border: 2px solid #dc2626; border-radius: 8px; cursor: pointer; font-weight: 600;">
                            ← Go Back
                        </button>
                    </div>
                </div>
            `;
    } else {
      alert(errorMessage);
    }
  }
}

// ─── Error Handler ─────────────────────────────────────────────────────────
function handleV8Error(data) {
  const container = document.getElementById("recommendations-container");
  const typeNames = {
    "on-grid": "On-Grid",
    "off-grid": "Off-Grid",
    hybrid: "Hybrid",
  };
  const selectedType = typeNames[selectedSystemType] || selectedSystemType;

  let title = "System Not Available";
  let msg = data.message || "Something went wrong.";
  let suggestion = "";

  if (data.error === "no_inverters") {
    title = `No ${selectedType} Inverters Available`;
    msg = `We couldn't find any ${selectedType.toLowerCase()} inverters that match your ${data.min_watts || ""}W load requirements.`;
    suggestion = `<div class="v8-error-suggestions">
            <p><strong>Suggestions:</strong></p>
            <ul>
                <li>Try a different system type (${Object.values(typeNames)
                  .filter((t) => t !== selectedType)
                  .join(" or ")})</li>
                <li>Reduce your appliance load to require a smaller inverter</li>
                <li>Switch to "Informative" mode for general sizing recommendations</li>
            </ul>
        </div>`;
  } else if (data.error === "no_panels") {
    title = "No Solar Panels Available";
    msg = "No active solar panels found in the system database.";
  }

  if (container) {
    container.innerHTML = `
        <div class="v8-error-state">
            <div class="error-icon">⚠️</div>
            <h2>${title}</h2>
            <p>${msg}</p>
            ${suggestion}
            <div style="display:flex;gap:12px;justify-content:center;margin-top:20px;">
                <button onclick="goToStep(2)" class="btn btn-secondary">Change Configuration</button>
                <button onclick="goToStep(1)" class="btn btn-primary">Modify Appliances</button>
            </div>
        </div>`;
  }
  goToStep(3);
}

// ─── Render V9 Results ─────────────────────────────────────────────────────
function renderV9Results(data) {
  const container = document.getElementById("recommendations-container");
  if (!container) return;

  const {
    load_analysis,
    categories,
    total_options,
    parallel_options,
    net_metering,
    nearby_shops,
    system_type,
    mode,
    currency,
  } = data;
  const isShopMode = mode === "shop";

  const typeLabels = {
    "on-grid": { icon: "⚡", name: "On-Grid", color: "#059669" },
    "off-grid": { icon: "🔌", name: "Off-Grid", color: "#DC2626" },
    hybrid: { icon: "🔄", name: "Hybrid", color: "#7C3AED" },
  };
  const typeInfo = typeLabels[system_type] || typeLabels["hybrid"];

  const catStyles = {
    on_grid: {
      bg: "linear-gradient(135deg, #059669 0%, #047857 100%)",
      icon: "⚡",
      color: "#059669",
    },
    budget: {
      bg: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
      icon: "💰",
      color: "#10b981",
    },
    balanced: {
      bg: "linear-gradient(135deg, #6366f1 0%, #4f46e5 100%)",
      icon: "⚖️",
      color: "#6366f1",
    },
    premium: {
      bg: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",
      icon: "👑",
      color: "#f59e0b",
    },
    traditional: {
      bg: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
      icon: "🔧",
      color: "#667eea",
    },
    maintenance_free: {
      bg: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
      icon: "💧",
      color: "#f093fb",
    },
    premium_bms: {
      bg: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
      icon: "⚡",
      color: "#4facfe",
    },
    reduced_backup: {
      bg: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",
      icon: "⚠️",
      color: "#f59e0b",
    },
  };

  let html = "";

  // ── Mode + Currency Badge ──
  const currencyLabel = currency?.label || "USD";
  const modeBadge = isShopMode
    ? `<span class="v9-mode-badge v9-mode-shop">🏪 Shop Mode</span>`
    : `<span class="v9-mode-badge v9-mode-info">📘 Informative</span>`;

  html += `
    <div class="v9-top-bar">
        ${modeBadge}
        <span class="v9-currency-badge">${escHtml(currencyLabel)}</span>
        ${!activeCurrency.is_local ? '<span class="v9-intl-note">Approximate prices in USD</span>' : ""}
    </div>`;

  // ── System Type Badge + Load Summary ──
  html += `
    <div class="v8-load-summary">
        <div class="v8-load-bg"></div>
        <div class="v8-load-content">
            <div class="v8-system-badge" style="background:${typeInfo.color}">
                ${typeInfo.icon} ${typeInfo.name} System
            </div>
            <div class="v8-system-badges-row" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;">
                ${
                  system_type === "on-grid"
                    ? `
                    <span style="background:rgba(16,185,129,0.2);color:#10b981;padding:3px 10px;border-radius:12px;font-size:0.75rem;font-weight:700;">✅ Net Metering</span>
                    <span style="background:rgba(239,68,68,0.2);color:#ef4444;padding:3px 10px;border-radius:12px;font-size:0.75rem;font-weight:600;">❌ No Battery Backup</span>
                `
                    : ""
                }
                ${
                  system_type === "off-grid"
                    ? `
                    <span style="background:rgba(59,130,246,0.2);color:#3b82f6;padding:3px 10px;border-radius:12px;font-size:0.75rem;font-weight:700;">✅ ${load_analysis.backup_hours_requested || ""}h Battery Backup</span>
                    <span style="background:rgba(239,68,68,0.2);color:#ef4444;padding:3px 10px;border-radius:12px;font-size:0.75rem;font-weight:600;">❌ No Net Metering</span>
                    <span style="background:rgba(16,185,129,0.2);color:#10b981;padding:3px 10px;border-radius:12px;font-size:0.75rem;font-weight:700;">✅ 100% Independence</span>
                `
                    : ""
                }
                ${
                  system_type === "hybrid"
                    ? `
                    <span style="background:rgba(59,130,246,0.2);color:#3b82f6;padding:3px 10px;border-radius:12px;font-size:0.75rem;font-weight:700;">✅ ${load_analysis.backup_hours_requested || ""}h Battery Backup</span>
                    <span style="background:rgba(16,185,129,0.2);color:#10b981;padding:3px 10px;border-radius:12px;font-size:0.75rem;font-weight:700;">✅ Net Metering Optional</span>
                    <span style="background:rgba(245,158,11,0.2);color:#f59e0b;padding:3px 10px;border-radius:12px;font-size:0.75rem;font-weight:700;">✅ Grid Safety Net</span>
                `
                    : ""
                }
            </div>
            <div class="v8-load-stats">
                <div class="v8-stat">
                    <div class="v8-stat-value">${load_analysis.peak_load_watts.toLocaleString()}W</div>
                    <div class="v8-stat-label">Peak Load</div>
                </div>
                <div class="v8-stat">
                    <div class="v8-stat-value">${load_analysis.daily_energy_kwh} kWh</div>
                    <div class="v8-stat-label">Daily Energy</div>
                </div>
                ${
                  system_type !== "on-grid"
                    ? `
                <div class="v8-stat">
                    <div class="v8-stat-value">${load_analysis.backup_hours_requested}h</div>
                    <div class="v8-stat-label">Backup</div>
                </div>`
                    : ""
                }
                <div class="v8-stat">
                    <div class="v8-stat-value">${total_options}</div>
                    <div class="v8-stat-label">Options</div>
                </div>
            </div>
        </div>
    </div>`;

  // ── Net Metering Summary ──
  if (net_metering && system_type !== "off-grid") {
    html += `
        <div class="v8-net-metering-result">
            <div class="nm-result-header">
                <span class="nm-icon">📊</span>
                <h3>Net Metering Projection</h3>
            </div>
            <div class="nm-result-grid">
                <div class="nm-result-stat">
                    <span class="nm-r-value">${net_metering.monthly_export_units}</span>
                    <span class="nm-r-label">Units Exported/mo</span>
                </div>
                <div class="nm-result-stat">
                    <span class="nm-r-value">${net_metering.monthly_received_back}</span>
                    <span class="nm-r-label">Units Received Back</span>
                </div>
                <div class="nm-result-stat nm-highlight">
                    <span class="nm-r-value">${fmtPrice(net_metering.monthly_savings)}</span>
                    <span class="nm-r-label">Monthly Savings</span>
                </div>
                <div class="nm-result-stat nm-highlight">
                    <span class="nm-r-value">${fmtPrice(net_metering.annual_savings)}</span>
                    <span class="nm-r-label">Annual Savings</span>
                </div>
            </div>
        </div>`;
  }

  // ── Algorithm Notes (hybrid sizing info, fallback warnings) ──
  if (data.algorithm_notes && data.algorithm_notes.length > 0) {
    data.algorithm_notes.forEach((note) => {
      if (note.type === "hybrid_sizing_note") {
        html += `
                <div class="v8-algo-note v8-algo-info">
                    <span class="algo-note-icon">ℹ️</span>
                    <span>${escHtml(note.message)}</span>
                </div>`;
      } else if (note.type === "no_battery_configs") {
        html += `
                <div class="v8-algo-note v8-algo-warning">
                    <span class="algo-note-icon">⚠️</span>
                    <div>
                        <strong>${escHtml(note.message)}</strong>
                        ${
                          note.suggestions && note.suggestions.length
                            ? `
                        <ul class="algo-suggestions">
                            ${note.suggestions.map((s) => `<li>${escHtml(s)}</li>`).join("")}
                        </ul>`
                            : ""
                        }
                    </div>
                </div>`;
      } else if (note.type === "reduced_backup_available") {
        html += `
                <div class="v8-algo-note v8-algo-success">
                    <span class="algo-note-icon">✅</span>
                    <span>${escHtml(note.message)} — ${note.options_count} option(s) shown below</span>
                </div>`;
      } else if (note.type === "phase_recommendation") {
        html += `
                <div class="v8-algo-note v8-algo-warning">
                    <span class="algo-note-icon">⚠️</span>
                    <div>
                        <strong>System Phase Recommendation:</strong> ${escHtml(note.message)}
                        ${note.warning ? `<p class="algo-warning-sub" style="margin-top: 5px; font-size: 0.9em; color: #b45309; font-weight: 500;">${escHtml(note.warning)}</p>` : ""}
                    </div>
                </div>`;
      }
    });
  }

  // ── Parallel Options ──
  if (parallel_options && parallel_options.length > 0) {
    html += `
        <div class="v8-parallel-section">
            <div class="parallel-header">
                <span>🔗</span>
                <h3>Parallel Inverter Options</h3>
                <p>Connect multiple smaller inverters instead of one large unit</p>
            </div>
            <div class="parallel-options-grid">
                ${parallel_options
                  .map(
                    (po) => `
                <div class="parallel-option-card">
                    <div class="po-badge">${po.units_needed}x Units</div>
                    <div class="po-name">${escHtml(po.inverter.company_name)} ${escHtml(po.inverter.name)}</div>
                    <div class="po-specs">
                        <span>${po.inverter.power_rating}W each</span>
                        <span>= ${po.total_watts.toLocaleString()}W total</span>
                    </div>
                    <div class="po-cost">${fmtPrice(po.total_cost)}</div>
                    <div class="po-extra">+${po.headroom_pct}% headroom</div>
                </div>`,
                  )
                  .join("")}
            </div>
        </div>`;
  }

  // ── Category Quick Nav ──
  html += `
    <div class="v8-quick-nav">
        ${categories
          .map((cat, idx) => {
            const s = catStyles[cat.category_id] || catStyles["traditional"];
            return `<button onclick="document.getElementById('v8cat-${idx}').scrollIntoView({behavior:'smooth'})"
                        class="v8-nav-btn" style="background:${s.bg}">
                    ${s.icon} ${cat.category_name.replace(/[^\w\s]/g, "").trim()}
                </button>`;
          })
          .join("")}
    </div>`;

  // ── Phase Detection Notification ──
  if (data.phase_detection_note) {
    const note = data.phase_detection_note;
    html += `
            <div class="phase-recommendation ${note.recommended ? "recommended" : "info"}">
                <div class="phase-icon">⚡</div>
                <div class="phase-content">
                    <h4>${note.recommended ? "3-Phase Recommended" : "Phase Detection"}</h4>
                    <p>${escHtml(note.reason || note.message || "")}</p>
                    ${note.warning ? `<p class="warning">${escHtml(note.warning)}</p>` : ""}
                </div>
            </div>
        `;
  }

  // ── Render Categories — NEW V10 Premium Layout ──
  // Detect available tiers
  const hasBudget = categories.find((c) => c.category_id === "budget");
  const hasBalanced = categories.find((c) => c.category_id === "balanced");
  const hasPremium = categories.find((c) => c.category_id === "premium");
  const hasOnGrid = categories.find((c) => c.category_id === "on_grid");

  const isOnGridSystem = system_type === "on-grid";
  const isThreeTierLayout = hasBudget && hasBalanced && hasPremium;

  if (isThreeTierLayout || isOnGridSystem) {
    // ── V10.1: Single Mixed Grid — all tiers combined, sorted by price ──
    const tierMeta = {
      budget: {
        icon: "💰",
        label: "Budget",
        color: "#10b981",
        bg: "linear-gradient(135deg, #10b981, #059669)",
      },
      balanced: {
        icon: "⚖️",
        label: "Balanced",
        color: "#6366f1",
        bg: "linear-gradient(135deg, #6366f1, #4f46e5)",
      },
      premium: {
        icon: "👑",
        label: "Premium",
        color: "#f59e0b",
        bg: "linear-gradient(135deg, #f59e0b, #d97706)",
      },
      on_grid: {
        icon: "⚡",
        label: "On-Grid",
        color: "#059669",
        bg: "linear-gradient(135deg, #059669, #047857)",
      },
    };

    // Merge all options into one list with tier info
    let allMixed = [];
    categories.forEach((cat, catIdx) => {
      const meta = tierMeta[cat.category_id] || tierMeta["budget"];
      (cat.options || []).forEach((opt, optIdx) => {
        allMixed.push({
          opt,
          catIdx,
          optIdx,
          tier: cat.category_id,
          tierIcon: meta.icon,
          tierLabel: meta.label,
          tierColor: meta.color,
          tierBg: meta.bg,
          price: opt.total_cost || 0,
        });
      });
    });

    // Sort by price ascending (cheapest first)
    allMixed.sort((a, b) => a.price - b.price);

    const initialShow = 6;

    html += `<div class="v10-mixed-grid" id="v10-mixed-grid">`;
    allMixed.forEach((item, idx) => {
      const hiddenClass = idx >= initialShow ? " v10-hidden-card" : "";
      html += `<div class="v10-mixed-wrap${hiddenClass}" data-midx="${idx}">`;
      html += renderV10MixedCard(item, idx, isShopMode, isOnGridSystem);
      html += `</div>`;
    });
    html += `</div>`;

    // Show More button
    if (allMixed.length > initialShow) {
      const remaining = allMixed.length - initialShow;
      html += `<div class="v10-showmore-wrap" id="v10-showmore-mixed">
                <button class="v10-showmore-btn" onclick="v10ShowMoreMixed(${initialShow})">
                    <span class="v10-showmore-icon">▼</span>
                    Show More Recommendations
                    <span class="v10-showmore-count">(${remaining} more)</span>
                </button>
            </div>`;
    }
  } else {
    // Fallback: Separate sections for non-standard categories
    categories.forEach((cat, catIdx) => {
      const s = catStyles[cat.category_id] || catStyles["traditional"];

      html += `
        <div id="v8cat-${catIdx}" class="v8-category">
            <div class="v8-cat-header" style="background:${s.bg}">
                <div class="v8-cat-header-bg"></div>
                <div class="v8-cat-header-content">
                    <div class="v8-cat-icon">${s.icon}</div>
                    <h2 class="v8-cat-title">${cat.category_name}</h2>
                    <p class="v8-cat-desc">${cat.category_description}</p>
                    <div class="v8-cat-meta">
                        <span>🔋 ${cat.battery_types}</span>
                        <span>${cat.best_for}</span>
                    </div>
                </div>
            </div>`;

      if (!cat.has_options) {
        html += `
            <div class="v8-cat-empty">
                <span class="empty-icon">📭</span>
                <h3>No Options Available</h3>
                <p>No matching products found for this configuration.</p>
            </div>`;
      } else {
        const initialShow = 6;
        const totalOpts = cat.options.length;
        html += `<div class="v8-options-grid" id="v8-grid-${catIdx}">`;
        cat.options.forEach((opt, optIdx) => {
          const hidden = optIdx >= initialShow ? ' style="display:none"' : "";
          html += `<div class="v8-option-wrap" data-cat="${catIdx}" data-idx="${optIdx}"${hidden}>`;
          html += renderV9OptionCard(opt, optIdx, catIdx, s.color, isShopMode);
          html += `</div>`;
        });
        html += `</div>`;
        if (totalOpts > initialShow) {
          html += `
                <div class="v8-load-more-wrap" id="v8-loadmore-${catIdx}">
                    <button class="v8-load-more-btn" onclick="loadMoreOptions(${catIdx}, ${initialShow})">
                        Load More <span class="v8-lm-count">(Showing ${initialShow} of ${totalOpts})</span>
                    </button>
                </div>`;
        }
      }

      html += `</div>`;
    });
  } // End of else block for old layout

  // ── Nearby Shops (Shop Mode) ──
  if (isShopMode && nearby_shops && nearby_shops.length > 0) {
    html += renderNearbyShops(nearby_shops, data.shop_search);
  } else if (isShopMode) {
    html += `
        <div class="v9-no-dealers">
            <div class="v9-no-dealers-icon">🏪</div>
            <h3>No Dealers Found Nearby</h3>
            <p>No registered solar dealers found within ${shopRadius}km of your location.
               Try increasing the search radius or switch to Informative mode for general recommendations.</p>
            <button onclick="goToStep(2);" class="btn btn-secondary">
                Back to Configuration
            </button>
        </div>`;
  }

  // ── Footer ──
  html += `
    <div class="v8-footer-actions">
        <button onclick="goToStep(2)" class="btn btn-secondary">Back to Configuration</button>
    </div>`;

  container.innerHTML = html;

  // Animate
  if (
    typeof anime === "function" &&
    !window.matchMedia("(prefers-reduced-motion:reduce)").matches
  ) {
    anime({
      targets: ".v10-opt-card, .v8-option-card",
      scale: [0.95, 1],
      opacity: [0, 1],
      duration: 400,
      delay: anime.stagger(50),
      easing: "easeOutBack",
    });
  }
}

// ─── Render V10 Mixed Card (single card with tier header badge) ──────────────
function renderV10MixedCard(item, globalIdx, isShopMode, isOnGrid) {
  const { opt, catIdx, optIdx, tier, tierIcon, tierLabel, tierColor, tierBg } =
    item;
  const inv = opt.inverter;
  const bat = opt.battery_config;
  const pan = opt.panel_config;
  const sameBrand = opt.same_brand || false;
  const qualityScore = opt.quality_score || Math.round(opt.inverter_score || 0);
  const stars = getQualityStars(qualityScore);

  const invFlag = inv.country_flag || "";
  const batFlag = bat?.battery?.country_flag || "";
  const panFlag = pan?.panel?.country_flag || "";
  const dealers = opt.dealer_availability || [];
  const hasDealers = isShopMode && dealers.length > 0;

  let c = `<div class="v10-mixed-card" style="--tier-color:${tierColor}">`;

  // ── Tier Header Badge (colored strip at top of card) ──
  c += `<div class="v10-card-tier-header" style="background:${tierBg}">
        <span class="v10-tier-badge-icon">${tierIcon}</span>
        <span class="v10-tier-badge-label">${tierLabel}</span>
        <span class="v10-tier-badge-score">${qualityScore}/100 Quality</span>
    </div>`;

  // ── Card Body ──
  c += `<div class="v10-card-body">`;

  // Quality stars
  c += `<div class="v10-quality-row"><span class="v10-stars">${stars}</span></div>`;

  // Inverter
  c += `<div class="v10-comp">
        <div class="v10-comp-ico ico-inv">⚡</div>
        <div class="v10-comp-body">
            <div class="v10-comp-title">${invFlag ? `<span class="v8-flag">${invFlag}</span> ` : ""}${escHtml(inv.company_name || "")} ${escHtml(inv.name)}</div>
            <div class="v10-comp-specs">${inv.power_rating}W · ${inv.type || opt.system_type} · ${inv.vdc_type || "48V"}${inv.mppt_channels > 1 ? ` · ${inv.mppt_channels} MPPT` : ""}${inv.three_phase == 1 ? " · 3Φ" : ""}${inv.parallel_capable == 1 ? ` · ∥x${inv.max_parallel_units}` : ""}</div>
        </div>
        <div class="v10-comp-price">${fmtPrice(inv.price_usd || inv.unit_price_usd)}</div>
    </div>`;

  // Battery
  if (!isOnGrid && bat) {
    const hasBms = bat.battery?.has_bms == 1 || bat.battery?.is_bms === "Yes";
    c += `<div class="v10-comp">
            <div class="v10-comp-ico ico-bat">🔋</div>
            <div class="v10-comp-body">
                <div class="v10-comp-title">${batFlag ? `<span class="v8-flag">${batFlag}</span> ` : ""}${bat.quantity}x ${escHtml(bat.battery?.company_name || "")} ${bat.battery?.capacity_ah}Ah</div>
                <div class="v10-comp-specs">${bat.battery?.type || ""} · ${bat.usable_kwh}kWh · ${bat.backup_hours}h backup · ${bat.cycle_life} cycles</div>
                <div class="v10-comp-wiring-info">
                    ${bat.config_code ? `<span class="v10-cfg-badge">${bat.config_code}</span>` : ""}
                    ${bat.string_voltage ? `<span class="v10-volt-badge">${bat.string_voltage}V</span>` : ""}
                    <span class="v10-bms-pill ${hasBms ? "v10-bms-yes" : "v10-bms-no"}">${hasBms ? "BMS" : "No BMS"}</span>
                </div>
            </div>
            <div class="v10-comp-price">${fmtPrice(bat.total_cost)}</div>
        </div>`;
  } else if (isOnGrid) {
    c += `<div class="v10-no-battery">
            <div class="v10-comp-ico ico-nobat">⚡</div>
            <div class="v10-comp-body">
                <div class="v10-comp-title">No Battery Required</div>
                <div class="v10-comp-specs">On-Grid — energy exported to grid</div>
            </div>
        </div>`;
  }

  // Panels
  if (pan) {
    c += `<div class="v10-comp">
            <div class="v10-comp-ico ico-pan">☀️</div>
            <div class="v10-comp-body">
                <div class="v10-comp-title">${panFlag ? `<span class="v8-flag">${panFlag}</span> ` : ""}${pan.quantity}x ${escHtml(pan.panel?.company_name || "")} ${pan.panel?.wattage}W</div>
                <div class="v10-comp-specs">${pan.total_kwp}kWp · ${pan.daily_gen_kwh} kWh/day${pan.wiring ? " · " + pan.wiring : ""}</div>
            </div>
            <div class="v10-comp-price">${fmtPrice(pan.total_cost)}</div>
        </div>`;
  }

  // Dealer strip
  if (isShopMode && hasDealers) {
    c += `<div class="v10-dealer-row">
            <span style="font-weight:600;color:#059669;">Available at:</span>
            ${dealers
              .slice(0, 2)
              .map(
                (d) =>
                  `<span>${escHtml(d.business_name)} (${d.distance_km}km)</span>`,
              )
              .join(" · ")}
            ${dealers.length > 2 ? `<span style="color:#64748b">+${dealers.length - 2} more</span>` : ""}
        </div>`;
  }

  // Quick stats
  c += `<div class="v10-stats-strip">`;
  if (!isOnGrid && bat)
    c += `<div class="v10-mini-stat"><span class="v10-ms-val">${bat.backup_hours}h</span><span class="v10-ms-lbl">Backup</span></div>`;
  c += `<div class="v10-mini-stat"><span class="v10-ms-val">${qualityScore}</span><span class="v10-ms-lbl">Quality</span></div>`;
  if (!isOnGrid && bat)
    c += `<div class="v10-mini-stat"><span class="v10-ms-val">${bat.dod_percent}%</span><span class="v10-ms-lbl">DoD</span></div>`;
  if (pan)
    c += `<div class="v10-mini-stat"><span class="v10-ms-val">${pan.daily_gen_kwh}</span><span class="v10-ms-lbl">kWh/day</span></div>`;
  c += `</div>`;

  c += `</div>`; // close v10-card-body

  // ── Footer ──
  c += `<div class="v10-card-foot">
        <div class="v10-total-row">
            <span class="v10-total-label">Total System Cost</span>
            <span class="v10-total-price">${fmtPrice(opt.total_cost)}</span>
        </div>
        <div class="v10-action-row">
            <button class="v10-btn-select" style="background:${tierBg}" onclick="selectV8Option(${catIdx}, ${optIdx})">Select & Configure</button>
            <button class="v10-btn-customize" onclick="openCustomizer(${catIdx}, ${optIdx})" title="Customize components">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M13.5 3.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM5.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm8 4.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM1 3.5h9m3 0h2M1 8h1.5m3 0H15M1 12.5h9m3 0h2"/></svg>
            </button>
        </div>
    </div>`;

  c += `</div>`; // close v10-mixed-card
  return c;
}

// ─── Show More Mixed — reveals hidden cards in batches ────────────────────────
window.v10ShowMoreMixed = function (batchSize) {
  const grid = document.getElementById("v10-mixed-grid");
  if (!grid) return;

  const hidden = grid.querySelectorAll(".v10-hidden-card");
  let shown = 0;
  hidden.forEach((card) => {
    if (shown < batchSize) {
      card.classList.remove("v10-hidden-card");
      card.style.opacity = "0";
      card.style.transform = "translateY(12px)";
      // Stagger animation
      setTimeout(() => {
        card.style.transition = "opacity 0.35s ease, transform 0.35s ease";
        card.style.opacity = "1";
        card.style.transform = "translateY(0)";
      }, shown * 60);
      shown++;
    }
  });

  // Update button
  const remaining = grid.querySelectorAll(".v10-hidden-card").length;
  const wrap = document.getElementById("v10-showmore-mixed");
  if (wrap) {
    if (remaining === 0) {
      wrap.innerHTML = `<div class="v10-all-shown">✓ All ${grid.children.length} recommendations shown</div>`;
    } else {
      wrap.querySelector(".v10-showmore-count").textContent =
        `(${remaining} more)`;
    }
  }
};

// ─── Render Single Tier Column (Budget/Balanced/Premium) ──────────────────────
function renderTierColumn(category, catIdx, accentColor, icon, isShopMode) {
  if (!category)
    return '<div class="v8-tier-column"><div class="v8-no-option">No options available</div></div>';

  const catStyles = {
    budget: {
      bg: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
      title: "Budget",
      subtitle: "Lowest Cost",
    },
    balanced: {
      bg: "linear-gradient(135deg, #6366f1 0%, #4f46e5 100%)",
      title: "Balanced",
      subtitle: "Best Value",
    },
    premium: {
      bg: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",
      title: "Premium",
      subtitle: "Top Quality",
    },
  };

  const style = catStyles[category.category_id] || catStyles["balanced"];

  // v9.5: Support both single option (legacy) and multiple options (new)
  const options =
    category.options || (category.option ? [category.option] : []);
  const hasOptions = options.length > 0;
  const optionsCount = options.length;

  let html = `<div class="v8-tier-column v8-tier-${category.category_id}">`;

  // Header
  html += `
        <div class="v8-tier-header" style="background: ${style.bg};">
            <div class="v8-tier-icon">${icon}</div>
            <h3 class="v8-tier-title">${style.title}</h3>
            <p class="v8-tier-subtitle">${style.subtitle}</p>
            ${optionsCount > 1 ? `<span class="v8-tier-count">${optionsCount} Options</span>` : ""}
        </div>
    `;

  // Content - Show all options in a grid
  if (hasOptions) {
    html += `<div class="v8-tier-options-wrapper">`;
    options.forEach((opt, idx) => {
      // Add quality stars badge
      const qualityScore = opt.quality_score || 50;
      const stars = getQualityStars(qualityScore);
      const badge = opt.badge || "";

      html += `<div class="v8-tier-option-card">`;
      if (badge) {
        html += `<div class="v8-option-badge v8-badge-${badge.toLowerCase().replace(/\s+/g, "-")}">${badge}</div>`;
      }
      html += `<div class="v8-quality-stars">${stars}</div>`;
      html += renderV9OptionCard(opt, idx, catIdx, accentColor, isShopMode);
      html += `</div>`;
    });
    html += `</div>`; // Close wrapper

    // Load More button if there are additional options in all_options
    const allOptionsCount = category.all_options?.length || 0;
    if (allOptionsCount > optionsCount) {
      html += `
                <button class="v8-load-more-tier" onclick="loadMoreTierOptions('${category.category_id}')">
                    Show All ${allOptionsCount} Options
                </button>
            `;
    }
  } else {
    html += `<div class="v8-no-option">No options available for this tier</div>`;
  }

  html += `</div>`; // Close column

  return html;
}

// ─── Get Quality Stars (0-100 score) ──────────────────────────────────────────
function getQualityStars(score) {
  if (score >= 90) return "⭐⭐⭐⭐⭐";
  if (score >= 75) return "⭐⭐⭐⭐☆";
  if (score >= 60) return "⭐⭐⭐☆☆";
  if (score >= 40) return "⭐⭐☆☆☆";
  return "⭐☆☆☆☆";
}

// ─── Load More Options for a specific tier ───────────────────────────────────
window.loadMoreTierOptions = function (tierId) {
  const data = window.appState?.recommendations;
  if (!data) return;

  // Find the category
  const category = data.categories.find((c) => c.category_id === tierId);
  if (!category || !category.all_options || category.all_options.length <= 1) {
    alert("No additional options available for this tier.");
    return;
  }

  // Create modal with all options
  const modal = document.createElement("div");
  modal.className = "v9-customizer-overlay active";
  modal.innerHTML = `
        <div class="v9-customizer-modal" style="max-width: 900px;">
            <div class="v9-cm-header">
                <h3>All ${category.category_name} Options</h3>
                <button class="v9-cm-close" onclick="this.closest('.v9-customizer-overlay').remove()">×</button>
            </div>
            <div class="v9-cm-body">
                <p style="color: #64748b; margin-bottom: 20px;">
                    Showing ${category.all_options.length} options sorted by ${tierId === "budget" ? "price" : tierId === "premium" ? "quality" : "value"}.
                </p>
                <div class="v8-options-grid" style="padding: 0;">
                    ${category.all_options
                      .map((opt, idx) =>
                        renderV9OptionCard(opt, idx, 0, "#6366f1", false),
                      )
                      .join("")}
                </div>
            </div>
        </div>
    `;

  document.body.appendChild(modal);

  // Close on overlay click
  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.remove();
  });
};

// ─── Option Card (v9 — currency-aware + shop mode) ─────────────────────────
function renderV9OptionCard(opt, optIdx, catIdx, accentColor, isShopMode) {
  const inv = opt.inverter;
  const bat = opt.battery_config;
  const pan = opt.panel_config;
  const isFirst = optIdx === 0;
  const dealers = opt.dealer_availability || [];
  const hasDealers = isShopMode && dealers.length > 0;

  let dealerHtml = "";
  if (isShopMode) {
    if (hasDealers) {
      dealerHtml = `
            <div class="v9-dealer-strip">
                <div class="v9-dealer-label">Available at:</div>
                ${dealers
                  .slice(0, 3)
                  .map(
                    (d) => `
                <div class="v9-dealer-chip">
                    <span class="v9-dc-name">${escHtml(d.business_name)}</span>
                    <span class="v9-dc-dist">${d.distance_km}km</span>
                    ${d.phone ? `<a href="tel:${d.phone}" class="v9-dc-phone" title="Call">📞</a>` : ""}
                </div>`,
                  )
                  .join("")}
                ${dealers.length > 3 ? `<span class="v9-dc-more">+${dealers.length - 3} more</span>` : ""}
            </div>`;
    } else {
      dealerHtml = `
            <div class="v9-dealer-strip v9-no-stock">
                <span class="v9-no-stock-label">No nearby dealer stock for these exact components</span>
            </div>`;
    }
  }

  // Country flags
  const invFlag = inv.country_flag || "";
  const batFlag = bat?.battery?.country_flag || "";
  const panFlag = pan?.panel?.country_flag || "";
  const sameBrand = opt.same_brand || false;
  const qualityScore = opt.quality_score || Math.round(opt.inverter_score || 0);

  return `
    <div class="v8-option-card ${isFirst ? "v8-recommended" : ""} ${isShopMode ? "v9-shop-card" : ""}" data-cat="${catIdx}" data-opt="${optIdx}">
        ${isFirst ? '<div class="v8-rec-badge">Best Match</div>' : ""}
        ${sameBrand ? '<div class="v8-same-brand-badge">🏭 Same Brand</div>' : ""}

        <!-- Inverter -->
        <div class="v8-component v8-comp-inverter">
            <div class="v8-comp-icon">⚡</div>
            <div class="v8-comp-info">
                <div class="v8-comp-name">${invFlag ? `<span class="v8-flag">${invFlag}</span> ` : ""}${escHtml(inv.company_name || "")} ${escHtml(inv.name)}</div>
                <div class="v8-comp-specs">
                    ${inv.power_rating}W · ${inv.type || opt.system_type} · ${inv.vdc_type || "48V"}
                    ${inv.mppt_channels > 1 ? ` · <span class="v8-mppt-tag">${inv.mppt_channels} MPPT</span>` : ""}
                    ${inv.three_phase == 1 ? ' · <span class="v8-phase-tag">3Φ</span>' : ""}
                    ${inv.parallel_capable == 1 ? ` · <span class="v8-parallel-tag">Parallel x${inv.max_parallel_units}</span>` : ""}
                </div>
            </div>
            <div class="v8-comp-price">${fmtPrice(inv.price_usd || inv.unit_price_usd)}</div>
        </div>

        ${
          bat
            ? `
        <!-- Battery -->
        <div class="v8-component v8-comp-battery">
            <div class="v8-comp-icon">🔋</div>
            <div class="v8-comp-info">
                <div class="v8-comp-name">${batFlag ? `<span class="v8-flag">${batFlag}</span> ` : ""}${bat.quantity}x ${escHtml(bat.battery?.company_name || "")} ${bat.battery?.capacity_ah}Ah</div>
                <div class="v8-comp-specs">
                    ${bat.battery?.type || ""} · ${bat.usable_kwh}kWh · ${bat.backup_hours}h backup · ${bat.cycle_life} cycles
                    ${bat.battery?.has_bms == 1 || bat.battery?.is_bms === "Yes" ? ' · <span class="v8-bms-tag">BMS</span>' : ' · <span class="v8-nobms-tag">No BMS</span>'}
                </div>
                <div class="v8-comp-wiring">
                    ${bat.config_code ? `<span class="v8-config-badge">${bat.config_code}</span>` : ""}
                    ${bat.string_voltage ? `<span class="v8-voltage-badge">${bat.string_voltage}V</span>` : ""}
                    <span class="v8-wiring-text">${escHtml(bat.wiring || "")}</span>
                </div>
            </div>
            <div class="v8-comp-price">${fmtPrice(bat.total_cost)}</div>
        </div>`
            : `
        <div class="v8-component v8-comp-no-battery">
            <div class="v8-comp-icon">⚡</div>
            <div class="v8-comp-info">
                <div class="v8-comp-name">No Battery Required</div>
                <div class="v8-comp-specs">On-Grid system — power exported to grid</div>
            </div>
            <div class="v8-comp-price">—</div>
        </div>`
        }

        ${
          pan
            ? `
        <!-- Panels -->
        <div class="v8-component v8-comp-panel">
            <div class="v8-comp-icon">☀️</div>
            <div class="v8-comp-info">
                <div class="v8-comp-name">${panFlag ? `<span class="v8-flag">${panFlag}</span> ` : ""}${pan.quantity}x ${escHtml(pan.panel?.company_name || "")} ${pan.panel?.wattage}W</div>
                <div class="v8-comp-specs">${pan.total_kwp}kWp · ${pan.daily_gen_kwh} kWh/day · ${pan.wiring || ""}</div>
            </div>
            <div class="v8-comp-price">${fmtPrice(pan.total_cost)}</div>
        </div>`
            : ""
        }

        ${dealerHtml}

        <!-- Quick Stats -->
        <div class="v8-quick-stats">
            ${bat ? `<div class="v8-qs"><span class="v8-qs-val">${bat.backup_hours}h</span><span class="v8-qs-label">Backup</span></div>` : ""}
            <div class="v8-qs"><span class="v8-qs-val">${qualityScore}</span><span class="v8-qs-label">Quality</span></div>
            ${bat ? `<div class="v8-qs"><span class="v8-qs-val">${bat.dod_percent}%</span><span class="v8-qs-label">DoD</span></div>` : ""}
            ${bat?.string_voltage ? `<div class="v8-qs"><span class="v8-qs-val">${bat.string_voltage}V</span><span class="v8-qs-label">String V</span></div>` : ""}
            ${pan ? `<div class="v8-qs"><span class="v8-qs-val">${pan.daily_gen_kwh}</span><span class="v8-qs-label">kWh/day</span></div>` : ""}
        </div>

        <!-- Total + Actions -->
        <div class="v8-card-footer">
            <div class="v8-total-cost">
                <span class="v8-total-label">Total</span>
                ${fmtPrice(opt.total_cost)}
            </div>
            <div class="v9-card-actions">
                <button class="v8-select-btn" onclick="selectV8Option(${catIdx}, ${optIdx})">
                    Select & Configure
                </button>
                <button class="v9-customize-btn" onclick="openCustomizer(${catIdx}, ${optIdx})" title="Customize components">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                        <path d="M13.5 3.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM5.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm8 4.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM1 3.5h9m3 0h2M1 8h1.5m3 0H15M1 12.5h9m3 0h2"/>
                    </svg>
                </button>
            </div>
        </div>
    </div>`;
}

// ─── Nearby Shops Section ──────────────────────────────────────────────────
function renderNearbyShops(shops, searchInfo) {
  return `
    <div class="v8-shops-section">
        <div class="shops-header">
            <span>🏪</span>
            <h3>Nearby Solar Dealers</h3>
            <p>${shops.length} dealer${shops.length > 1 ? "s" : ""} within ${searchInfo?.radius_km || shopRadius}km</p>
        </div>
        <div class="shops-grid">
            ${shops
              .slice(0, 6)
              .map(
                (shop) => `
            <div class="shop-card">
                <div class="shop-card-head">
                    <span class="shop-distance">${shop.distance_km}km away</span>
                </div>
                <h4 class="shop-name">${escHtml(shop.business_name || "Solar Shop")}</h4>
                <p class="shop-address">${escHtml(shop.city || shop.address || "")}</p>
                ${shop.phone ? `<a href="tel:${shop.phone}" class="shop-phone">📞 ${escHtml(shop.phone)}</a>` : ""}
                ${shop.rating_avg > 0 ? `<div class="shop-rating">⭐ ${shop.rating_avg}/5</div>` : ""}
            </div>`,
              )
              .join("")}
        </div>
    </div>`;
}

// ─── Load More Options ────────────────────────────────────────────────────
function loadMoreOptions(catIdx, batchSize) {
  const grid = document.getElementById(`v8-grid-${catIdx}`);
  if (!grid) return;

  const hiddenItems = grid.querySelectorAll(
    `.v8-option-wrap[data-cat="${catIdx}"][style*="display:none"]`,
  );
  let shown = 0;
  hiddenItems.forEach((item) => {
    if (shown < batchSize) {
      item.style.display = "";
      shown++;
    }
  });

  // Update or hide Load More button
  const remaining = grid.querySelectorAll(
    `.v8-option-wrap[data-cat="${catIdx}"][style*="display:none"]`,
  ).length;
  const loadMoreWrap = document.getElementById(`v8-loadmore-${catIdx}`);
  if (loadMoreWrap) {
    if (remaining === 0) {
      loadMoreWrap.style.display = "none";
    } else {
      const totalItems = grid.querySelectorAll(
        `.v8-option-wrap[data-cat="${catIdx}"]`,
      ).length;
      const visibleNow = totalItems - remaining;
      loadMoreWrap.querySelector(".v8-lm-count").textContent =
        `(Showing ${visibleNow} of ${totalItems})`;
    }
  }

  // Animate new items
  if (typeof anime === "function") {
    anime({
      targets: grid.querySelectorAll(
        `.v8-option-wrap[data-cat="${catIdx}"]:not([style*="display:none"]) .v8-option-card`,
      ),
      scale: [0.95, 1],
      opacity: [0.5, 1],
      duration: 300,
      delay: anime.stagger(30),
      easing: "easeOutBack",
    });
  }
}

// ─── Inline Customizer (swap components) ───────────────────────────────────
function openCustomizer(catIdx, optIdx) {
  const rec = window.appState?.recommendations;
  if (!rec?.categories) return;

  const cat = rec.categories[catIdx];
  const opt = cat?.options?.[optIdx];
  if (!opt) return;

  const overlay = document.createElement("div");
  overlay.className = "v9-customizer-overlay";
  overlay.onclick = (e) => {
    if (e.target === overlay) overlay.remove();
  };

  const allOptions = rec.categories.flatMap((c) => c.options || []);
  const inverters = [
    ...new Map(allOptions.map((o) => [o.inverter.id, o.inverter])).values(),
  ];
  const panels = [
    ...new Map(
      allOptions
        .filter((o) => o.panel_config?.panel)
        .map((o) => [o.panel_config.panel.id, o.panel_config.panel]),
    ).values(),
  ];
  const batteries = [
    ...new Map(
      allOptions
        .filter((o) => o.battery_config?.battery)
        .map((o) => [o.battery_config.battery.id, o.battery_config.battery]),
    ).values(),
  ];

  const bat = opt.battery_config;
  const pan = opt.panel_config;
  const inv = opt.inverter;

  // Build wiring diagram HTML
  let wiringHtml = "";
  if (bat?.wiring_diagram && bat.wiring_diagram.length > 0) {
    wiringHtml = `
        <div class="v10-wiring-section">
            <div class="v10-wiring-title">🔌 Battery Wiring Diagram</div>
            <div class="v10-wiring-config">${bat.config_code || ""} · ${bat.string_voltage || ""}V String</div>
            <div class="v10-wiring-diagram">
                ${bat.wiring_diagram
                  .map(
                    (d) => `
                <div class="v10-string-row">
                    <span class="v10-string-label">${d.label}</span>
                    <div class="v10-string-chain">
                        ${d.batteries.map((b) => `<span class="v10-bat-node">${b}</span>`).join('<span class="v10-wire">─</span>')}
                    </div>
                    <span class="v10-string-voltage">${d.voltage}</span>
                </div>`,
                  )
                  .join("")}
            </div>
            ${
              bat.wiring_notes && bat.wiring_notes.length > 0
                ? `
            <div class="v10-wiring-notes">
                ${bat.wiring_notes.map((n) => `<div class="v10-note">⚠️ ${n}</div>`).join("")}
            </div>`
                : ""
            }
        </div>`;
  } else if (bat) {
    wiringHtml = `
        <div class="v10-wiring-section">
            <div class="v10-wiring-title">🔌 Battery Connection</div>
            <div class="v10-wiring-text">${escHtml(bat.wiring || "Single battery")}</div>
        </div>`;
  }

  // Panel diagram HTML
  let panelDiagramHtml = "";
  if (pan?.panel_diagram && pan.panel_diagram.length > 0) {
    panelDiagramHtml = `
        <div class="v10-wiring-section v10-panel-section">
            <div class="v10-wiring-title">☀️ Panel String Layout</div>
            <div class="v10-wiring-config">${pan.total_strings || 1} string${pan.total_strings > 1 ? "s" : ""} · ${pan.panels_per_string || 1} per string · ${pan.string_voltage || ""}V</div>
            <div class="v10-wiring-diagram">
                ${pan.panel_diagram
                  .map(
                    (d) => `
                <div class="v10-string-row">
                    <span class="v10-string-label">${d.label}</span>
                    <div class="v10-string-chain">
                        ${d.panels.map((p) => `<span class="v10-panel-node">${p}</span>`).join('<span class="v10-wire">─</span>')}
                    </div>
                    <span class="v10-string-voltage">${d.voltage}</span>
                </div>`,
                  )
                  .join("")}
            </div>
        </div>`;
  }

  // BMS badge
  const invBms = inv.bms === "Yes" || inv.bms === "1" ? true : false;
  const bmsHtml = `<span class="v10-bms-indicator ${invBms ? "v10-bms-yes" : "v10-bms-no"}">${invBms ? "🔗 BMS Required" : "🔓 No BMS Required"}</span>`;

  overlay.innerHTML = `
    <div class="v9-customizer-modal v10-modal">
        <div class="v9-cm-header v10-cm-header">
            <div>
                <h3>⚙️ Customize System</h3>
                <p class="v10-cm-subtitle">${cat.label || cat.category || "Option"} — ${opt.system_type || ""}</p>
            </div>
            <button class="v9-cm-close" onclick="this.closest('.v9-customizer-overlay').remove()">&times;</button>
        </div>

        <div class="v9-cm-body v10-cm-body">
            <!-- Inverter -->
            <div class="v9-cm-section v10-section">
                <label class="v9-cm-label">⚡ Inverter ${bmsHtml}</label>
                <select class="v9-cm-select" id="v9-cust-inverter" onchange="updateCustomizerTotal()">
                    ${inverters
                      .map(
                        (i) => `
                    <option value="${i.id}" ${i.id == inv.id ? "selected" : ""}
                            data-price="${i.price_usd || i.unit_price_usd || 0}" data-watts="${i.power_rating}" data-bms="${i.bms || "No"}">
                        ${i.company_name || ""} ${i.name} — ${i.power_rating}W — ${fmtPrice(i.price_usd || i.unit_price_usd || 0)}
                    </option>`,
                      )
                      .join("")}
                </select>
            </div>

            <!-- Panels -->
            ${
              panels.length > 0
                ? `
            <div class="v9-cm-section v10-section">
                <label class="v9-cm-label">☀️ Solar Panel</label>
                <select class="v9-cm-select" id="v9-cust-panel" onchange="updateCustomizerTotal()">
                    ${panels
                      .map(
                        (p) => `
                    <option value="${p.id}" ${p.id == pan?.panel?.id ? "selected" : ""}
                            data-price="${p.price_usd}" data-watts="${p.wattage}">
                        ${p.company_name || ""} ${p.wattage}W ${p.panel_type || p.type || ""} — ${fmtPrice(p.price_usd)}/panel
                    </option>`,
                      )
                      .join("")}
                </select>
                <div class="v9-cm-qty">
                    <label>Qty:</label>
                    <input type="number" id="v9-cust-panel-qty" value="${pan?.quantity || 4}" min="1" max="50"
                           class="v9-cm-qty-input" onchange="updateCustomizerTotal()">
                </div>
            </div>`
                : ""
            }

            <!-- Batteries -->
            ${
              batteries.length > 0 && bat
                ? `
            <div class="v9-cm-section v10-section">
                <label class="v9-cm-label">🔋 Battery</label>
                <select class="v9-cm-select" id="v9-cust-battery" onchange="updateCustomizerTotal()">
                    ${batteries
                      .map(
                        (b) => `
                    <option value="${b.id}" ${b.id == bat?.battery?.id ? "selected" : ""}
                            data-price="${b.price_unit_usd || b.price_usd}" data-ah="${b.capacity_ah}"
                            data-type="${b.type}" data-voltage="${b.nominal_voltage}"
                            data-bms="${b.is_bms || "No"}">
                        ${b.company_name || ""} ${b.capacity_ah}Ah ${b.type} ${b.nominal_voltage}V ${b.is_bms === "Yes" ? "🔗BMS" : ""} — ${fmtPrice(b.price_unit_usd || b.price_usd)}/unit
                    </option>`,
                      )
                      .join("")}
                </select>
                <div class="v9-cm-qty">
                    <label>Total batteries:</label>
                    <input type="number" id="v9-cust-battery-qty" value="${Math.min(bat?.quantity || 1, 16)}" min="1" max="16"
                           class="v9-cm-qty-input" onchange="updateCustomizerTotal()">
                    <span class="v10-config-info" id="v10-config-display">${bat.config_code || ""}</span>
                </div>
            </div>`
                : ""
            }

            <!-- Wiring Diagrams -->
            ${wiringHtml}
            ${panelDiagramHtml}
        </div>

        <div class="v9-cm-footer v10-cm-footer">
            <div class="v9-cm-total">
                <span class="v9-cm-total-label">Estimated Total</span>
                <span class="v9-cm-total-value" id="v9-cust-total">${fmtPrice(opt.total_cost)}</span>
            </div>
            <div class="v10-footer-actions">
                <button class="v10-cm-reset" onclick="updateCustomizerTotal()">↺ Reset</button>
                <button class="v9-cm-apply" onclick="applyCustomization(${catIdx}, ${optIdx}); this.closest('.v9-customizer-overlay').remove();">
                    ✓ Apply Changes
                </button>
            </div>
        </div>
    </div>`;

  document.body.appendChild(overlay);
  requestAnimationFrame(() => overlay.classList.add("active"));
}

function updateCustomizerTotal() {
  const invSel = document.getElementById("v9-cust-inverter");
  const panSel = document.getElementById("v9-cust-panel");
  const batSel = document.getElementById("v9-cust-battery");
  const panQty = parseInt(
    document.getElementById("v9-cust-panel-qty")?.value || 0,
  );
  const batQty = parseInt(
    document.getElementById("v9-cust-battery-qty")?.value || 0,
  );

  let total = 0;
  if (invSel)
    total += parseFloat(invSel.selectedOptions[0]?.dataset.price || 0);
  if (panSel)
    total += parseFloat(panSel.selectedOptions[0]?.dataset.price || 0) * panQty;
  if (batSel)
    total += parseFloat(batSel.selectedOptions[0]?.dataset.price || 0) * batQty;

  // Update BMS indicator based on selected inverter
  if (invSel) {
    const selBms = invSel.selectedOptions[0]?.dataset.bms;
    const indicator = document.querySelector(".v10-bms-indicator");
    if (indicator) {
      const hasBms = selBms === "Yes" || selBms === "1";
      indicator.className = `v10-bms-indicator ${hasBms ? "v10-bms-yes" : "v10-bms-no"}`;
      indicator.textContent = hasBms ? "🔗 BMS Required" : "🔓 No BMS Required";
    }
  }

  const display = document.getElementById("v9-cust-total");
  if (display) display.textContent = fmtPrice(total);
}

function applyCustomization(catIdx, optIdx) {
  const rec = window.appState?.recommendations;
  if (!rec?.categories) return;

  const opt = rec.categories[catIdx]?.options?.[optIdx];
  if (!opt) return;

  // Read customized values
  const invSel = document.getElementById("v9-cust-inverter");
  const panSel = document.getElementById("v9-cust-panel");
  const batSel = document.getElementById("v9-cust-battery");
  const panQty = parseInt(
    document.getElementById("v9-cust-panel-qty")?.value || 0,
  );
  const batQty = parseInt(
    document.getElementById("v9-cust-battery-qty")?.value || 0,
  );

  // Update the option in-memory
  let newTotal = 0;

  if (invSel) {
    const selOpt = invSel.selectedOptions[0];
    opt.inverter.price_usd = parseFloat(selOpt.dataset.price || 0);
    opt.inverter.power_rating = parseInt(selOpt.dataset.watts || 0);
    newTotal += opt.inverter.price_usd;
  }

  if (panSel && opt.panel_config) {
    const selOpt = panSel.selectedOptions[0];
    const panelPrice = parseFloat(selOpt.dataset.price || 0);
    opt.panel_config.quantity = panQty;
    opt.panel_config.total_cost = panelPrice * panQty;
    opt.panel_config.total_wattage =
      parseInt(selOpt.dataset.watts || 0) * panQty;
    opt.panel_config.total_kwp = (
      opt.panel_config.total_wattage / 1000
    ).toFixed(2);
    newTotal += opt.panel_config.total_cost;
  }

  if (batSel && opt.battery_config) {
    const selOpt = batSel.selectedOptions[0];
    const batPrice = parseFloat(selOpt.dataset.price || 0);
    opt.battery_config.quantity = batQty;
    opt.battery_config.total_cost = batPrice * batQty;
    newTotal += opt.battery_config.total_cost;
  }

  opt.total_cost = Math.round(newTotal);

  // Re-render the results
  if (typeof renderV9Results === "function" && rec) {
    renderV9Results(rec);
  }
}

// ─── Option Selection ──────────────────────────────────────────────────────
function selectV8Option(catIdx, optIdx) {
  const rec = window.appState?.recommendations;
  if (!rec?.categories) return;

  const cat = rec.categories[catIdx];
  const opt = cat?.options?.[optIdx];
  if (!opt) return;

  window.appState.selectedSystem = opt;
  window.appState.selectedCategory = cat;
  window.appState.activeCurrency = activeCurrency;
  if (typeof saveState === "function") saveState();

  // Skip system overview — go directly to customization (Step 4)
  if (typeof initializeConfigurator === "function") {
    initializeConfigurator(
      opt,
      rec.load_analysis,
      rec.categories.flatMap((c) => c.options || []),
    );
  }
  if (typeof goToStep === "function") goToStep(4);
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// ─── Go back to recommendations list from overview ───────────────────────
window.backToRecommendations = function () {
  const overviewEl = document.getElementById("system-overview-container");
  const recsEl = document.getElementById("recommendations-container");
  if (overviewEl && recsEl) {
    overviewEl.style.display = "none";
    recsEl.style.display = "block";
  }
};

// ─── Proceed to configurator (step 4) from System Overview ───────────────
window.proceedToConfigurator = function () {
  const rec = window.appState?.recommendations;
  const opt = window.appState.selectedSystem;
  if (!opt || !rec) return;

  if (typeof initializeConfigurator === "function") {
    initializeConfigurator(
      opt,
      rec.load_analysis,
      rec.categories.flatMap((c) => c.options || []),
    );
  }
  if (typeof goToStep === "function") goToStep(4);
  window.scrollTo({ top: 0, behavior: "smooth" });
};

// ─── System Overview Renderer (Step 4 — Energy Flow Animation) ────────────
function renderSystemOverview(opt, loadAnalysis, category) {
  const container = document.getElementById("system-overview-container");
  if (!container) return;

  const inv = opt.inverter;
  const bat = opt.battery_config;
  const pan = opt.panel_config;
  const isOnGrid = opt.system_type === "on-grid" || !bat;
  const isHybrid = opt.system_type === "hybrid";

  const solarKwp =
    pan?.total_kwp || ((pan?.total_wattage || 0) / 1000).toFixed(2);
  const dailyGen = pan?.daily_generation_kwh || pan?.daily_gen_kwh || 0;
  const dailyUsage = loadAnalysis.daily_energy_kwh || 0;
  const surplus = Math.max(0, dailyGen - dailyUsage);
  const deficit = Math.max(0, dailyUsage - dailyGen);

  const typeColors = {
    "on-grid": "#059669",
    "off-grid": "#DC2626",
    hybrid: "#7C3AED",
  };
  const typeColor = typeColors[opt.system_type] || "#7C3AED";

  container.innerHTML = `
    <div class="sov-wrap">
        <div class="sov-header">
            <div class="sov-badge" style="background:${typeColor}">${opt.system_type === "on-grid" ? "⚡" : opt.system_type === "off-grid" ? "🔌" : "🔄"} ${(opt.system_type || "hybrid").replace("-", " ").replace(/\b\w/g, (l) => l.toUpperCase())} System</div>
            <h2>Your Selected Solar System</h2>
            <p>${category.category_description || ""}</p>
        </div>

        <!-- Energy Flow Animation -->
        <div class="sov-energy-flow">
            <div class="sov-flow-diagram">
                <!-- Sun/Panels -->
                <div class="sov-node sov-node-solar">
                    <div class="sov-node-icon">☀️</div>
                    <div class="sov-node-label">Solar Panels</div>
                    <div class="sov-node-value">${solarKwp} kWp</div>
                    <div class="sov-node-sub">${dailyGen} kWh/day</div>
                </div>

                <!-- Flow arrows -->
                <div class="sov-flow-arrows">
                    <div class="sov-arrow sov-arrow-solar-home">
                        <div class="sov-arrow-line"></div>
                        <div class="sov-arrow-particles"></div>
                        <div class="sov-arrow-label">${Math.min(dailyGen, dailyUsage).toFixed(1)} kWh</div>
                    </div>

                    ${
                      !isOnGrid && bat
                        ? `
                    <div class="sov-arrow sov-arrow-solar-battery">
                        <div class="sov-arrow-line"></div>
                        <div class="sov-arrow-particles sov-particles-charge"></div>
                        <div class="sov-arrow-label">Charge</div>
                    </div>
                    <div class="sov-arrow sov-arrow-battery-home">
                        <div class="sov-arrow-line"></div>
                        <div class="sov-arrow-particles sov-particles-discharge"></div>
                        <div class="sov-arrow-label">${bat.backup_hours || 0}h backup</div>
                    </div>`
                        : ""
                    }

                    ${
                      isOnGrid || isHybrid
                        ? `
                    <div class="sov-arrow sov-arrow-grid ${surplus > 0 ? "sov-arrow-export" : "sov-arrow-import"}">
                        <div class="sov-arrow-line"></div>
                        <div class="sov-arrow-particles ${surplus > 0 ? "sov-particles-export" : "sov-particles-import"}"></div>
                        <div class="sov-arrow-label">${surplus > 0 ? `Export ${surplus.toFixed(1)} kWh` : `Import ${deficit.toFixed(1)} kWh`}</div>
                    </div>`
                        : ""
                    }
                </div>

                <!-- Home -->
                <div class="sov-node sov-node-home">
                    <div class="sov-node-icon">🏠</div>
                    <div class="sov-node-label">Your Home</div>
                    <div class="sov-node-value">${dailyUsage} kWh/day</div>
                    <div class="sov-node-sub">${loadAnalysis.peak_load_watts}W peak</div>
                </div>

                ${
                  !isOnGrid && bat
                    ? `
                <!-- Battery -->
                <div class="sov-node sov-node-battery">
                    <div class="sov-node-icon">🔋</div>
                    <div class="sov-node-label">Battery Bank</div>
                    <div class="sov-node-value">${bat.usable_kwh || bat.total_kwh || "?"} kWh</div>
                    <div class="sov-node-sub">${bat.quantity}x ${bat.battery?.capacity_ah || "?"}Ah</div>
                </div>`
                    : ""
                }

                ${
                  isOnGrid || isHybrid
                    ? `
                <!-- Grid -->
                <div class="sov-node sov-node-grid">
                    <div class="sov-node-icon">🏭</div>
                    <div class="sov-node-label">Power Grid</div>
                    <div class="sov-node-value">${isOnGrid ? "Net Metering" : "Backup + Export"}</div>
                    <div class="sov-node-sub">${surplus > 0 ? "Sell " + surplus.toFixed(1) + " kWh/day" : "Buy " + deficit.toFixed(1) + " kWh/day"}</div>
                </div>`
                    : ""
                }
            </div>
        </div>

        <!-- Component Summary Cards -->
        <div class="sov-components">
            <div class="sov-comp-card">
                <div class="sov-comp-icon">⚡</div>
                <div class="sov-comp-details">
                    <div class="sov-comp-title">${escHtml(inv.company_name || "")} ${escHtml(inv.name)}</div>
                    <div class="sov-comp-specs">${inv.power_rating || inv.max_load_watts}W ${inv.type || opt.system_type} · ${inv.vdc_type || inv.voltage_class || "48V"}</div>
                </div>
                <div class="sov-comp-price">${fmtPrice(inv.price_usd || inv.unit_price_usd)}</div>
            </div>

            ${
              bat
                ? `
            <div class="sov-comp-card">
                <div class="sov-comp-icon">🔋</div>
                <div class="sov-comp-details">
                    <div class="sov-comp-title">${bat.quantity}x ${escHtml(bat.battery?.company_name || "")} ${bat.battery?.capacity_ah}Ah</div>
                    <div class="sov-comp-specs">${bat.battery?.type || ""} · ${bat.usable_kwh || "?"}kWh usable · ${bat.wiring || ""}</div>
                </div>
                <div class="sov-comp-price">${fmtPrice(bat.total_cost)}</div>
            </div>`
                : ""
            }

            <div class="sov-comp-card">
                <div class="sov-comp-icon">☀️</div>
                <div class="sov-comp-details">
                    <div class="sov-comp-title">${pan.quantity}x ${escHtml(pan.panel?.company_name || "")} ${pan.panel?.watt_peak || pan.panel?.wattage}W</div>
                    <div class="sov-comp-specs">${solarKwp} kWp · ${dailyGen} kWh/day generation</div>
                </div>
                <div class="sov-comp-price">${fmtPrice(pan.total_cost)}</div>
            </div>
        </div>

        <!-- Total + Key Metrics -->
        <div class="sov-summary">
            <div class="sov-total">
                <span class="sov-total-label">Total System Cost</span>
                <span class="sov-total-value">${fmtPrice(opt.total_cost)}</span>
            </div>
            <div class="sov-metrics">
                ${!isOnGrid ? `<div class="sov-metric"><span class="sov-metric-val">${bat?.backup_hours || 0}h</span><span class="sov-metric-lbl">Backup</span></div>` : ""}
                <div class="sov-metric"><span class="sov-metric-val">${dailyGen}</span><span class="sov-metric-lbl">kWh/day Gen</span></div>
                ${(isOnGrid || isHybrid) && surplus > 0 ? `<div class="sov-metric"><span class="sov-metric-val">${surplus.toFixed(1)}</span><span class="sov-metric-lbl">kWh/day Export</span></div>` : ""}
                ${!isOnGrid ? `<div class="sov-metric"><span class="sov-metric-val">${bat?.usable_kwh || "?"}</span><span class="sov-metric-lbl">kWh Storage</span></div>` : ""}
            </div>
        </div>

        <!-- D7: Find Nearest Dealers for Selected Package -->
        <div class="sov-find-nearest" id="sov-find-nearest">
            <div class="sov-fn-header">
                <span class="sov-fn-icon">📍</span>
                <h3>Find These Products Near You</h3>
                <p>Searching for nearby dealers with your selected components...</p>
            </div>
            <div class="sov-fn-results" id="sov-fn-results">
                <div class="sov-fn-loading">
                    <div class="sov-fn-spinner"></div>
                    <span>Searching dealers...</span>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="sov-actions">
            <button onclick="window.backToRecommendations()" class="sov-btn-back">← Back to Options</button>
            <button onclick="window.proceedToConfigurator()" class="sov-btn-customize">
                Customize Components →
            </button>
        </div>
    </div>`;

  // Trigger animations after render
  setTimeout(() => {
    container.querySelectorAll(".sov-arrow-particles").forEach((el, i) => {
      el.style.animationDelay = `${i * 0.3}s`;
    });
  }, 100);

  // D7: Search for nearest dealers with selected products
  findNearestDealers(opt);
}

// ─── D7: Find Nearest Dealers for Selected Package ────────────────────────
function findNearestDealers(opt) {
  const loc = window.SolarLocation?.getLocation?.() || {};
  const resultsEl = document.getElementById("sov-fn-results");
  const headerEl = document.getElementById("sov-find-nearest");

  if (!loc.lat || !loc.lng) {
    if (resultsEl) {
      resultsEl.innerHTML = `
                <div class="sov-fn-no-location">
                    <span>📍</span>
                    <p>Enable location to find dealers near you with these products.</p>
                </div>`;
    }
    return;
  }

  const inv_id = opt.inverter?.id || 0;
  const bat_id = opt.battery_config?.battery?.id || 0;
  const pan_id = opt.panel_config?.panel?.id || 0;

  // Use the existing findNearbyShops via a lightweight AJAX call
  const params = new URLSearchParams({
    ajax: "find_nearest",
    lat: loc.lat,
    lng: loc.lng,
    inverter_id: inv_id,
    battery_id: bat_id,
    panel_id: pan_id,
    radius: 100, // wider radius for find nearest
    csrf_token:
      window.appState?.csrfToken ||
      document.querySelector('meta[name="csrf-token"]')?.content ||
      "",
  });

  fetch(
    (window.BASE_URL || "/solarglobal/") +
      "api/find_nearest.php?" +
      params.toString(),
  )
    .then((r) => r.json())
    .then((data) => {
      if (!resultsEl) return;

      if (!data.success || !data.dealers || data.dealers.length === 0) {
        resultsEl.innerHTML = `
                    <div class="sov-fn-empty">
                        <span class="sov-fn-empty-icon">🔍</span>
                        <p>No nearby dealers found with these exact products.</p>
                        <p class="sov-fn-hint">Try visiting the <a href="${window.BASE_URL || "/solarglobal/"}store.php" target="_blank" rel="noopener noreferrer">Solar Shop</a> to browse available products by distance.</p>
                    </div>`;
        return;
      }

      let html = `<div class="sov-fn-list">`;
      data.dealers.forEach((d) => {
        const hasInv = d.has_inverter;
        const hasBat = d.has_battery;
        const hasPan = d.has_panel;
        const products = [];
        if (hasInv) products.push("⚡ Inverter");
        if (hasBat) products.push("🔋 Battery");
        if (hasPan) products.push("☀️ Panels");

        html += `
                <div class="sov-fn-dealer">
                    <div class="sov-fn-dealer-info">
                        <div class="sov-fn-dealer-name">${escHtml(d.business_name)}</div>
                        <div class="sov-fn-dealer-location">${escHtml(d.city || "")} · ${d.distance_km} km away</div>
                        <div class="sov-fn-dealer-products">${products.join(" · ")}</div>
                    </div>
                    <div class="sov-fn-dealer-actions">
                        ${d.phone ? `<a href="tel:${d.phone}" class="sov-fn-call" title="Call">📞</a>` : ""}
                        <a href="${window.BASE_URL || "/solarglobal/"}store-detail.php?id=${d.dealer_id}" class="sov-fn-visit" target="_blank" rel="noopener noreferrer">Visit Store →</a>
                    </div>
                </div>`;
      });
      html += `</div>`;

      if (data.outside_radius && data.outside_radius.length > 0) {
        html += `<div class="sov-fn-outside">
                    <p class="sov-fn-outside-label">Also available further away:</p>`;
        data.outside_radius.forEach((d) => {
          html += `<div class="sov-fn-dealer sov-fn-far">
                        <div class="sov-fn-dealer-info">
                            <div class="sov-fn-dealer-name">${escHtml(d.business_name)}</div>
                            <div class="sov-fn-dealer-location">${d.distance_km} km away</div>
                        </div>
                        <a href="${window.BASE_URL || "/solarglobal/"}store-detail.php?id=${d.dealer_id}" class="sov-fn-visit" target="_blank" rel="noopener noreferrer">Visit Store →</a>
                    </div>`;
        });
        html += `</div>`;
      }

      resultsEl.innerHTML = html;
    })
    .catch((err) => {
      console.error("Find nearest error:", err);
      if (resultsEl) {
        resultsEl.innerHTML = `<p class="sov-fn-error">Could not search nearby dealers. Try again later.</p>`;
      }
    });
}

// ─── Backward Compatibility ────────────────────────────────────────────────
window.findSolarSystem = findSolarSystemV8;
window.selectSystemOption = (idx) => selectV8Option(0, idx);
window.initSystemTypeSelector = initSystemTypeSelector;

// ─── Init ──────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  initSystemTypeSelector();
});
