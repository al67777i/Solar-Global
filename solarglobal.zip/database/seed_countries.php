<?php
/**
 * Seed Countries Migration Script
 * Inserts all 195+ recognized world countries into the countries table.
 * Uses INSERT IGNORE to avoid duplicating existing rows (UNIQUE on `code`).
 *
 * Usage: php seed_countries.php
 */

require_once __DIR__ . '/../includes/db.php';
$db = getDB();

// All 195+ recognized countries with accurate data
// sort_order: major solar markets first, then alphabetical
$countries = [
    // === MAJOR SOLAR MARKETS (sort_order 1-20) ===
    ['Pakistan', 'PK', '🇵🇰', 'PKR', '₨', 0.0750, 'Asia/Karachi', 'ur', 'Excellent', 5.50, 1],
    ['India', 'IN', '🇮🇳', 'INR', '₹', 0.0800, 'Asia/Kolkata', 'hi', 'Excellent', 5.50, 2],
    ['China', 'CN', '🇨🇳', 'CNY', '¥', 0.0850, 'Asia/Shanghai', 'zh', 'Very Good', 4.50, 3],
    ['United States', 'US', '🇺🇸', 'USD', '$', 0.1500, 'America/New_York', 'en', 'Very Good', 4.50, 4],
    ['Germany', 'DE', '🇩🇪', 'EUR', '€', 0.3500, 'Europe/Berlin', 'de', 'Moderate', 3.00, 5],
    ['Japan', 'JP', '🇯🇵', 'JPY', '¥', 0.2500, 'Asia/Tokyo', 'ja', 'Good', 3.80, 6],
    ['Australia', 'AU', '🇦🇺', 'AUD', '$', 0.2500, 'Australia/Sydney', 'en', 'Excellent', 5.80, 7],
    ['South Korea', 'KR', '🇰🇷', 'KRW', '₩', 0.1100, 'Asia/Seoul', 'ko', 'Good', 3.60, 8],
    ['Brazil', 'BR', '🇧🇷', 'BRL', 'R$', 0.1400, 'America/Sao_Paulo', 'pt', 'Excellent', 5.40, 9],
    ['United Kingdom', 'GB', '🇬🇧', 'GBP', '£', 0.3000, 'Europe/London', 'en', 'Moderate', 2.80, 10],
    ['Italy', 'IT', '🇮🇹', 'EUR', '€', 0.2500, 'Europe/Rome', 'it', 'Very Good', 4.20, 11],
    ['Spain', 'ES', '🇪🇸', 'EUR', '€', 0.2400, 'Europe/Madrid', 'es', 'Excellent', 5.00, 12],
    ['France', 'FR', '🇫🇷', 'EUR', '€', 0.2100, 'Europe/Paris', 'fr', 'Good', 3.50, 13],
    ['Turkey', 'TR', '🇹🇷', 'TRY', '₺', 0.0900, 'Europe/Istanbul', 'tr', 'Very Good', 4.50, 14],
    ['Netherlands', 'NL', '🇳🇱', 'EUR', '€', 0.3000, 'Europe/Amsterdam', 'nl', 'Moderate', 2.80, 15],
    ['Saudi Arabia', 'SA', '🇸🇦', 'SAR', '﷼', 0.0500, 'Asia/Riyadh', 'ar', 'Excellent', 6.20, 16],
    ['United Arab Emirates', 'AE', '🇦🇪', 'AED', 'د.إ', 0.0800, 'Asia/Dubai', 'ar', 'Excellent', 6.00, 17],
    ['Egypt', 'EG', '🇪🇬', 'EGP', '£', 0.0400, 'Africa/Cairo', 'ar', 'Excellent', 6.00, 18],
    ['South Africa', 'ZA', '🇿🇦', 'ZAR', 'R', 0.1200, 'Africa/Johannesburg', 'en', 'Excellent', 5.50, 19],
    ['Mexico', 'MX', '🇲🇽', 'MXN', '$', 0.0900, 'America/Mexico_City', 'es', 'Very Good', 5.00, 20],

    // === ASIA (remaining) ===
    ['Afghanistan', 'AF', '🇦🇫', 'AFN', '؋', 0.0500, 'Asia/Kabul', 'ps', 'Excellent', 5.50, 100],
    ['Armenia', 'AM', '🇦🇲', 'AMD', '֏', 0.0700, 'Asia/Yerevan', 'hy', 'Good', 4.20, 100],
    ['Azerbaijan', 'AZ', '🇦🇿', 'AZN', '₼', 0.0500, 'Asia/Baku', 'az', 'Good', 4.00, 100],
    ['Bahrain', 'BH', '🇧🇭', 'BHD', '.د.ب', 0.0300, 'Asia/Bahrain', 'ar', 'Excellent', 6.00, 100],
    ['Bangladesh', 'BD', '🇧🇩', 'BDT', '৳', 0.0600, 'Asia/Dhaka', 'bn', 'Very Good', 4.80, 100],
    ['Bhutan', 'BT', '🇧🇹', 'BTN', 'Nu', 0.0300, 'Asia/Thimphu', 'dz', 'Good', 4.00, 100],
    ['Brunei', 'BN', '🇧🇳', 'BND', '$', 0.0400, 'Asia/Brunei', 'ms', 'Good', 4.20, 100],
    ['Cambodia', 'KH', '🇰🇭', 'KHR', '៛', 0.1800, 'Asia/Phnom_Penh', 'km', 'Very Good', 5.00, 100],
    ['Cyprus', 'CY', '🇨🇾', 'EUR', '€', 0.2200, 'Asia/Nicosia', 'el', 'Excellent', 5.50, 100],
    ['Georgia', 'GE', '🇬🇪', 'GEL', '₾', 0.0600, 'Asia/Tbilisi', 'ka', 'Good', 3.80, 100],
    ['Indonesia', 'ID', '🇮🇩', 'IDR', 'Rp', 0.1000, 'Asia/Jakarta', 'id', 'Very Good', 4.80, 100],
    ['Iran', 'IR', '🇮🇷', 'IRR', '﷼', 0.0100, 'Asia/Tehran', 'fa', 'Excellent', 5.50, 100],
    ['Iraq', 'IQ', '🇮🇶', 'IQD', 'ع.د', 0.0300, 'Asia/Baghdad', 'ar', 'Excellent', 5.80, 100],
    ['Israel', 'IL', '🇮🇱', 'ILS', '₪', 0.1500, 'Asia/Jerusalem', 'he', 'Excellent', 5.50, 100],
    ['Jordan', 'JO', '🇯🇴', 'JOD', 'د.ا', 0.1100, 'Asia/Amman', 'ar', 'Excellent', 5.80, 100],
    ['Kazakhstan', 'KZ', '🇰🇿', 'KZT', '₸', 0.0500, 'Asia/Almaty', 'kk', 'Good', 4.00, 100],
    ['Kuwait', 'KW', '🇰🇼', 'KWD', 'د.ك', 0.0200, 'Asia/Kuwait', 'ar', 'Excellent', 6.00, 100],
    ['Kyrgyzstan', 'KG', '🇰🇬', 'KGS', 'сом', 0.0200, 'Asia/Bishkek', 'ky', 'Good', 4.00, 100],
    ['Laos', 'LA', '🇱🇦', 'LAK', '₭', 0.0800, 'Asia/Vientiane', 'lo', 'Very Good', 4.50, 100],
    ['Lebanon', 'LB', '🇱🇧', 'LBP', 'ل.ل', 0.1000, 'Asia/Beirut', 'ar', 'Very Good', 4.80, 100],
    ['Malaysia', 'MY', '🇲🇾', 'MYR', 'RM', 0.0900, 'Asia/Kuala_Lumpur', 'ms', 'Very Good', 4.50, 100],
    ['Maldives', 'MV', '🇲🇻', 'MVR', 'Rf', 0.2500, 'Indian/Maldives', 'dv', 'Excellent', 5.50, 100],
    ['Mongolia', 'MN', '🇲🇳', 'MNT', '₮', 0.0600, 'Asia/Ulaanbaatar', 'mn', 'Very Good', 4.80, 100],
    ['Myanmar', 'MM', '🇲🇲', 'MMK', 'K', 0.0500, 'Asia/Yangon', 'my', 'Very Good', 4.80, 100],
    ['Nepal', 'NP', '🇳🇵', 'NPR', '₨', 0.0500, 'Asia/Kathmandu', 'ne', 'Good', 4.50, 100],
    ['North Korea', 'KP', '🇰🇵', 'KPW', '₩', 0.0400, 'Asia/Pyongyang', 'ko', 'Good', 3.80, 100],
    ['Oman', 'OM', '🇴🇲', 'OMR', 'ر.ع', 0.0400, 'Asia/Muscat', 'ar', 'Excellent', 6.00, 100],
    ['Philippines', 'PH', '🇵🇭', 'PHP', '₱', 0.1800, 'Asia/Manila', 'tl', 'Very Good', 4.80, 100],
    ['Qatar', 'QA', '🇶🇦', 'QAR', 'ر.ق', 0.0300, 'Asia/Qatar', 'ar', 'Excellent', 6.00, 100],
    ['Singapore', 'SG', '🇸🇬', 'SGD', '$', 0.2200, 'Asia/Singapore', 'en', 'Good', 4.00, 100],
    ['Sri Lanka', 'LK', '🇱🇰', 'LKR', '₨', 0.0800, 'Asia/Colombo', 'si', 'Excellent', 5.20, 100],
    ['Syria', 'SY', '🇸🇾', 'SYP', '£', 0.0200, 'Asia/Damascus', 'ar', 'Excellent', 5.50, 100],
    ['Taiwan', 'TW', '🇹🇼', 'TWD', 'NT$', 0.1000, 'Asia/Taipei', 'zh', 'Good', 3.80, 100],
    ['Tajikistan', 'TJ', '🇹🇯', 'TJS', 'SM', 0.0200, 'Asia/Dushanbe', 'tg', 'Good', 4.50, 100],
    ['Thailand', 'TH', '🇹🇭', 'THB', '฿', 0.1200, 'Asia/Bangkok', 'th', 'Very Good', 4.80, 100],
    ['Timor-Leste', 'TL', '🇹🇱', 'USD', '$', 0.1500, 'Asia/Dili', 'pt', 'Very Good', 5.00, 100],
    ['Turkmenistan', 'TM', '🇹🇲', 'TMT', 'T', 0.0100, 'Asia/Ashgabat', 'tk', 'Excellent', 5.50, 100],
    ['Uzbekistan', 'UZ', '🇺🇿', 'UZS', 'сўм', 0.0300, 'Asia/Tashkent', 'uz', 'Very Good', 5.00, 100],
    ['Vietnam', 'VN', '🇻🇳', 'VND', '₫', 0.0800, 'Asia/Ho_Chi_Minh', 'vi', 'Very Good', 4.50, 100],
    ['Yemen', 'YE', '🇾🇪', 'YER', '﷼', 0.0600, 'Asia/Aden', 'ar', 'Excellent', 6.00, 100],
    ['Palestine', 'PS', '🇵🇸', 'ILS', '₪', 0.1500, 'Asia/Gaza', 'ar', 'Excellent', 5.50, 100],

    // === EUROPE ===
    ['Albania', 'AL', '🇦🇱', 'ALL', 'L', 0.0800, 'Europe/Tirane', 'sq', 'Good', 4.00, 200],
    ['Andorra', 'AD', '🇦🇩', 'EUR', '€', 0.1200, 'Europe/Andorra', 'ca', 'Good', 4.00, 200],
    ['Austria', 'AT', '🇦🇹', 'EUR', '€', 0.2500, 'Europe/Vienna', 'de', 'Moderate', 3.20, 200],
    ['Belarus', 'BY', '🇧🇾', 'BYN', 'Br', 0.0700, 'Europe/Minsk', 'be', 'Moderate', 2.80, 200],
    ['Belgium', 'BE', '🇧🇪', 'EUR', '€', 0.3000, 'Europe/Brussels', 'nl', 'Moderate', 2.80, 200],
    ['Bosnia and Herzegovina', 'BA', '🇧🇦', 'BAM', 'KM', 0.0800, 'Europe/Sarajevo', 'bs', 'Good', 3.80, 200],
    ['Bulgaria', 'BG', '🇧🇬', 'BGN', 'лв', 0.1100, 'Europe/Sofia', 'bg', 'Good', 3.80, 200],
    ['Croatia', 'HR', '🇭🇷', 'EUR', '€', 0.1400, 'Europe/Zagreb', 'hr', 'Good', 3.80, 200],
    ['Czech Republic', 'CZ', '🇨🇿', 'CZK', 'Kč', 0.2200, 'Europe/Prague', 'cs', 'Moderate', 3.00, 200],
    ['Denmark', 'DK', '🇩🇰', 'DKK', 'kr', 0.3500, 'Europe/Copenhagen', 'da', 'Moderate', 2.60, 200],
    ['Estonia', 'EE', '🇪🇪', 'EUR', '€', 0.1600, 'Europe/Tallinn', 'et', 'Low', 2.40, 200],
    ['Finland', 'FI', '🇫🇮', 'EUR', '€', 0.1800, 'Europe/Helsinki', 'fi', 'Low', 2.20, 200],
    ['Greece', 'GR', '🇬🇷', 'EUR', '€', 0.2000, 'Europe/Athens', 'el', 'Excellent', 5.00, 200],
    ['Hungary', 'HU', '🇭🇺', 'HUF', 'Ft', 0.1200, 'Europe/Budapest', 'hu', 'Good', 3.50, 200],
    ['Iceland', 'IS', '🇮🇸', 'ISK', 'kr', 0.1200, 'Atlantic/Reykjavik', 'is', 'Low', 2.00, 200],
    ['Ireland', 'IE', '🇮🇪', 'EUR', '€', 0.2800, 'Europe/Dublin', 'en', 'Moderate', 2.60, 200],
    ['Kosovo', 'XK', '🇽🇰', 'EUR', '€', 0.0700, 'Europe/Belgrade', 'sq', 'Good', 3.80, 200],
    ['Latvia', 'LV', '🇱🇻', 'EUR', '€', 0.1600, 'Europe/Riga', 'lv', 'Low', 2.50, 200],
    ['Liechtenstein', 'LI', '🇱🇮', 'CHF', 'CHF', 0.2000, 'Europe/Vaduz', 'de', 'Moderate', 3.00, 200],
    ['Lithuania', 'LT', '🇱🇹', 'EUR', '€', 0.1500, 'Europe/Vilnius', 'lt', 'Low', 2.50, 200],
    ['Luxembourg', 'LU', '🇱🇺', 'EUR', '€', 0.2200, 'Europe/Luxembourg', 'fr', 'Moderate', 2.80, 200],
    ['Malta', 'MT', '🇲🇹', 'EUR', '€', 0.1500, 'Europe/Malta', 'mt', 'Excellent', 5.20, 200],
    ['Moldova', 'MD', '🇲🇩', 'MDL', 'L', 0.0800, 'Europe/Chisinau', 'ro', 'Good', 3.50, 200],
    ['Monaco', 'MC', '🇲🇨', 'EUR', '€', 0.2000, 'Europe/Monaco', 'fr', 'Good', 4.00, 200],
    ['Montenegro', 'ME', '🇲🇪', 'EUR', '€', 0.1000, 'Europe/Podgorica', 'sr', 'Good', 4.00, 200],
    ['North Macedonia', 'MK', '🇲🇰', 'MKD', 'ден', 0.0800, 'Europe/Skopje', 'mk', 'Good', 3.80, 200],
    ['Norway', 'NO', '🇳🇴', 'NOK', 'kr', 0.1500, 'Europe/Oslo', 'no', 'Low', 2.20, 200],
    ['Poland', 'PL', '🇵🇱', 'PLN', 'zł', 0.2000, 'Europe/Warsaw', 'pl', 'Moderate', 3.00, 200],
    ['Portugal', 'PT', '🇵🇹', 'EUR', '€', 0.2200, 'Europe/Lisbon', 'pt', 'Very Good', 4.80, 200],
    ['Romania', 'RO', '🇷🇴', 'RON', 'lei', 0.1300, 'Europe/Bucharest', 'ro', 'Good', 3.50, 200],
    ['Russia', 'RU', '🇷🇺', 'RUB', '₽', 0.0500, 'Europe/Moscow', 'ru', 'Moderate', 3.00, 200],
    ['San Marino', 'SM', '🇸🇲', 'EUR', '€', 0.2000, 'Europe/San_Marino', 'it', 'Good', 4.00, 200],
    ['Serbia', 'RS', '🇷🇸', 'RSD', 'din', 0.0700, 'Europe/Belgrade', 'sr', 'Good', 3.50, 200],
    ['Slovakia', 'SK', '🇸🇰', 'EUR', '€', 0.1800, 'Europe/Bratislava', 'sk', 'Moderate', 3.20, 200],
    ['Slovenia', 'SI', '🇸🇮', 'EUR', '€', 0.1600, 'Europe/Ljubljana', 'sl', 'Good', 3.40, 200],
    ['Sweden', 'SE', '🇸🇪', 'SEK', 'kr', 0.2000, 'Europe/Stockholm', 'sv', 'Low', 2.40, 200],
    ['Switzerland', 'CH', '🇨🇭', 'CHF', 'CHF', 0.2500, 'Europe/Zurich', 'de', 'Moderate', 3.20, 200],
    ['Ukraine', 'UA', '🇺🇦', 'UAH', '₴', 0.0500, 'Europe/Kyiv', 'uk', 'Good', 3.50, 200],
    ['Vatican City', 'VA', '🇻🇦', 'EUR', '€', 0.2000, 'Europe/Vatican', 'it', 'Good', 4.20, 200],

    // === AFRICA (all 54 countries) ===
    ['Algeria', 'DZ', '🇩🇿', 'DZD', 'د.ج', 0.0400, 'Africa/Algiers', 'ar', 'Excellent', 6.00, 300],
    ['Angola', 'AO', '🇦🇴', 'AOA', 'Kz', 0.0800, 'Africa/Luanda', 'pt', 'Very Good', 5.00, 300],
    ['Benin', 'BJ', '🇧🇯', 'XOF', 'CFA', 0.2000, 'Africa/Porto-Novo', 'fr', 'Very Good', 5.00, 300],
    ['Botswana', 'BW', '🇧🇼', 'BWP', 'P', 0.0800, 'Africa/Gaborone', 'en', 'Excellent', 5.80, 300],
    ['Burkina Faso', 'BF', '🇧🇫', 'XOF', 'CFA', 0.2500, 'Africa/Ouagadougou', 'fr', 'Excellent', 5.80, 300],
    ['Burundi', 'BI', '🇧🇮', 'BIF', 'FBu', 0.1500, 'Africa/Bujumbura', 'rn', 'Very Good', 5.00, 300],
    ['Cabo Verde', 'CV', '🇨🇻', 'CVE', '$', 0.2800, 'Atlantic/Cape_Verde', 'pt', 'Very Good', 5.50, 300],
    ['Cameroon', 'CM', '🇨🇲', 'XAF', 'FCFA', 0.1000, 'Africa/Douala', 'fr', 'Very Good', 5.00, 300],
    ['Central African Republic', 'CF', '🇨🇫', 'XAF', 'FCFA', 0.1500, 'Africa/Bangui', 'fr', 'Very Good', 5.00, 300],
    ['Chad', 'TD', '🇹🇩', 'XAF', 'FCFA', 0.2000, 'Africa/Ndjamena', 'fr', 'Excellent', 6.00, 300],
    ['Comoros', 'KM', '🇰🇲', 'KMF', 'CF', 0.2500, 'Indian/Comoro', 'ar', 'Very Good', 5.20, 300],
    ['Congo (Brazzaville)', 'CG', '🇨🇬', 'XAF', 'FCFA', 0.1000, 'Africa/Brazzaville', 'fr', 'Very Good', 4.50, 300],
    ['Congo (Kinshasa)', 'CD', '🇨🇩', 'CDF', 'FC', 0.1000, 'Africa/Kinshasa', 'fr', 'Very Good', 4.80, 300],
    ['Djibouti', 'DJ', '🇩🇯', 'DJF', 'Fdj', 0.2500, 'Africa/Djibouti', 'fr', 'Excellent', 6.00, 300],
    ['Equatorial Guinea', 'GQ', '🇬🇶', 'XAF', 'FCFA', 0.1500, 'Africa/Malabo', 'es', 'Very Good', 4.50, 300],
    ['Eritrea', 'ER', '🇪🇷', 'ERN', 'Nfk', 0.0400, 'Africa/Asmara', 'ti', 'Excellent', 6.00, 300],
    ['Eswatini', 'SZ', '🇸🇿', 'SZL', 'E', 0.0800, 'Africa/Mbabane', 'en', 'Very Good', 5.00, 300],
    ['Ethiopia', 'ET', '🇪🇹', 'ETB', 'Br', 0.0300, 'Africa/Addis_Ababa', 'am', 'Excellent', 5.50, 300],
    ['Gabon', 'GA', '🇬🇦', 'XAF', 'FCFA', 0.1200, 'Africa/Libreville', 'fr', 'Good', 4.20, 300],
    ['Gambia', 'GM', '🇬🇲', 'GMD', 'D', 0.2000, 'Africa/Banjul', 'en', 'Very Good', 5.50, 300],
    ['Ghana', 'GH', '🇬🇭', 'GHS', '₵', 0.1200, 'Africa/Accra', 'en', 'Very Good', 5.00, 300],
    ['Guinea', 'GN', '🇬🇳', 'GNF', 'FG', 0.1500, 'Africa/Conakry', 'fr', 'Very Good', 5.00, 300],
    ['Guinea-Bissau', 'GW', '🇬🇼', 'XOF', 'CFA', 0.2500, 'Africa/Bissau', 'pt', 'Very Good', 5.20, 300],
    ['Ivory Coast', 'CI', '🇨🇮', 'XOF', 'CFA', 0.1500, 'Africa/Abidjan', 'fr', 'Very Good', 5.00, 300],
    ['Kenya', 'KE', '🇰🇪', 'KES', 'KSh', 0.2000, 'Africa/Nairobi', 'sw', 'Very Good', 5.50, 300],
    ['Lesotho', 'LS', '🇱🇸', 'LSL', 'L', 0.0800, 'Africa/Maseru', 'en', 'Very Good', 5.20, 300],
    ['Liberia', 'LR', '🇱🇷', 'LRD', '$', 0.3500, 'Africa/Monrovia', 'en', 'Very Good', 4.80, 300],
    ['Libya', 'LY', '🇱🇾', 'LYD', 'ل.د', 0.0200, 'Africa/Tripoli', 'ar', 'Excellent', 6.20, 300],
    ['Madagascar', 'MG', '🇲🇬', 'MGA', 'Ar', 0.1500, 'Indian/Antananarivo', 'mg', 'Very Good', 5.20, 300],
    ['Malawi', 'MW', '🇲🇼', 'MWK', 'MK', 0.1000, 'Africa/Blantyre', 'en', 'Very Good', 5.50, 300],
    ['Mali', 'ML', '🇲🇱', 'XOF', 'CFA', 0.2000, 'Africa/Bamako', 'fr', 'Excellent', 6.00, 300],
    ['Mauritania', 'MR', '🇲🇷', 'MRU', 'UM', 0.1000, 'Africa/Nouakchott', 'ar', 'Excellent', 6.20, 300],
    ['Mauritius', 'MU', '🇲🇺', 'MUR', '₨', 0.1200, 'Indian/Mauritius', 'en', 'Very Good', 5.20, 300],
    ['Morocco', 'MA', '🇲🇦', 'MAD', 'د.م.', 0.1200, 'Africa/Casablanca', 'ar', 'Excellent', 5.50, 300],
    ['Mozambique', 'MZ', '🇲🇿', 'MZN', 'MT', 0.1200, 'Africa/Maputo', 'pt', 'Very Good', 5.20, 300],
    ['Namibia', 'NA', '🇳🇦', 'NAD', '$', 0.1200, 'Africa/Windhoek', 'en', 'Excellent', 6.00, 300],
    ['Niger', 'NE', '🇳🇪', 'XOF', 'CFA', 0.1500, 'Africa/Niamey', 'fr', 'Excellent', 6.20, 300],
    ['Nigeria', 'NG', '🇳🇬', 'NGN', '₦', 0.0800, 'Africa/Lagos', 'en', 'Very Good', 5.00, 300],
    ['Rwanda', 'RW', '🇷🇼', 'RWF', 'FRw', 0.1200, 'Africa/Kigali', 'rw', 'Very Good', 5.00, 300],
    ['Sao Tome and Principe', 'ST', '🇸🇹', 'STN', 'Db', 0.2000, 'Africa/Sao_Tome', 'pt', 'Very Good', 4.50, 300],
    ['Senegal', 'SN', '🇸🇳', 'XOF', 'CFA', 0.2000, 'Africa/Dakar', 'fr', 'Excellent', 5.50, 300],
    ['Seychelles', 'SC', '🇸🇨', 'SCR', '₨', 0.2500, 'Indian/Mahe', 'en', 'Very Good', 5.20, 300],
    ['Sierra Leone', 'SL', '🇸🇱', 'SLE', 'Le', 0.2500, 'Africa/Freetown', 'en', 'Very Good', 5.00, 300],
    ['Somalia', 'SO', '🇸🇴', 'SOS', 'Sh', 0.1500, 'Africa/Mogadishu', 'so', 'Excellent', 6.00, 300],
    ['South Sudan', 'SS', '🇸🇸', 'SSP', '£', 0.1000, 'Africa/Juba', 'en', 'Excellent', 5.80, 300],
    ['Sudan', 'SD', '🇸🇩', 'SDG', 'ج.س', 0.0500, 'Africa/Khartoum', 'ar', 'Excellent', 6.20, 300],
    ['Tanzania', 'TZ', '🇹🇿', 'TZS', 'TSh', 0.1000, 'Africa/Dar_es_Salaam', 'sw', 'Very Good', 5.50, 300],
    ['Togo', 'TG', '🇹🇬', 'XOF', 'CFA', 0.2000, 'Africa/Lome', 'fr', 'Very Good', 5.00, 300],
    ['Tunisia', 'TN', '🇹🇳', 'TND', 'د.ت', 0.0600, 'Africa/Tunis', 'ar', 'Excellent', 5.50, 300],
    ['Uganda', 'UG', '🇺🇬', 'UGX', 'USh', 0.1500, 'Africa/Kampala', 'en', 'Very Good', 5.20, 300],
    ['Zambia', 'ZM', '🇿🇲', 'ZMW', 'ZK', 0.0600, 'Africa/Lusaka', 'en', 'Very Good', 5.50, 300],
    ['Zimbabwe', 'ZW', '🇿🇼', 'ZWL', '$', 0.1000, 'Africa/Harare', 'en', 'Very Good', 5.50, 300],

    // === NORTH AMERICA & CARIBBEAN ===
    ['Canada', 'CA', '🇨🇦', 'CAD', '$', 0.1200, 'America/Toronto', 'en', 'Good', 3.50, 400],
    ['Antigua and Barbuda', 'AG', '🇦🇬', 'XCD', '$', 0.3500, 'America/Antigua', 'en', 'Very Good', 5.50, 400],
    ['Bahamas', 'BS', '🇧🇸', 'BSD', '$', 0.3500, 'America/Nassau', 'en', 'Very Good', 5.50, 400],
    ['Barbados', 'BB', '🇧🇧', 'BBD', '$', 0.3000, 'America/Barbados', 'en', 'Very Good', 5.50, 400],
    ['Belize', 'BZ', '🇧🇿', 'BZD', '$', 0.2000, 'America/Belize', 'en', 'Very Good', 5.20, 400],
    ['Costa Rica', 'CR', '🇨🇷', 'CRC', '₡', 0.1500, 'America/Costa_Rica', 'es', 'Very Good', 4.80, 400],
    ['Cuba', 'CU', '🇨🇺', 'CUP', '₱', 0.0400, 'America/Havana', 'es', 'Very Good', 5.20, 400],
    ['Dominica', 'DM', '🇩🇲', 'XCD', '$', 0.3000, 'America/Dominica', 'en', 'Very Good', 5.00, 400],
    ['Dominican Republic', 'DO', '🇩🇴', 'DOP', '$', 0.1800, 'America/Santo_Domingo', 'es', 'Very Good', 5.50, 400],
    ['El Salvador', 'SV', '🇸🇻', 'USD', '$', 0.1500, 'America/El_Salvador', 'es', 'Very Good', 5.20, 400],
    ['Grenada', 'GD', '🇬🇩', 'XCD', '$', 0.3000, 'America/Grenada', 'en', 'Very Good', 5.50, 400],
    ['Guatemala', 'GT', '🇬🇹', 'GTQ', 'Q', 0.1500, 'America/Guatemala', 'es', 'Very Good', 5.00, 400],
    ['Haiti', 'HT', '🇭🇹', 'HTG', 'G', 0.3500, 'America/Port-au-Prince', 'fr', 'Very Good', 5.50, 400],
    ['Honduras', 'HN', '🇭🇳', 'HNL', 'L', 0.1500, 'America/Tegucigalpa', 'es', 'Very Good', 5.00, 400],
    ['Jamaica', 'JM', '🇯🇲', 'JMD', '$', 0.3000, 'America/Jamaica', 'en', 'Very Good', 5.50, 400],
    ['Nicaragua', 'NI', '🇳🇮', 'NIO', 'C$', 0.1800, 'America/Managua', 'es', 'Very Good', 5.20, 400],
    ['Panama', 'PA', '🇵🇦', 'PAB', 'B/.', 0.1500, 'America/Panama', 'es', 'Very Good', 4.80, 400],
    ['Saint Kitts and Nevis', 'KN', '🇰🇳', 'XCD', '$', 0.3000, 'America/St_Kitts', 'en', 'Very Good', 5.50, 400],
    ['Saint Lucia', 'LC', '🇱🇨', 'XCD', '$', 0.3000, 'America/St_Lucia', 'en', 'Very Good', 5.50, 400],
    ['Saint Vincent and the Grenadines', 'VC', '🇻🇨', 'XCD', '$', 0.3000, 'America/St_Vincent', 'en', 'Very Good', 5.50, 400],
    ['Trinidad and Tobago', 'TT', '🇹🇹', 'TTD', '$', 0.0500, 'America/Port_of_Spain', 'en', 'Very Good', 5.20, 400],

    // === SOUTH AMERICA ===
    ['Argentina', 'AR', '🇦🇷', 'ARS', '$', 0.0500, 'America/Argentina/Buenos_Aires', 'es', 'Very Good', 4.80, 500],
    ['Bolivia', 'BO', '🇧🇴', 'BOB', 'Bs.', 0.0600, 'America/La_Paz', 'es', 'Excellent', 5.50, 500],
    ['Chile', 'CL', '🇨🇱', 'CLP', '$', 0.1300, 'America/Santiago', 'es', 'Excellent', 5.50, 500],
    ['Colombia', 'CO', '🇨🇴', 'COP', '$', 0.1000, 'America/Bogota', 'es', 'Very Good', 4.80, 500],
    ['Ecuador', 'EC', '🇪🇨', 'USD', '$', 0.0900, 'America/Guayaquil', 'es', 'Very Good', 4.50, 500],
    ['Guyana', 'GY', '🇬🇾', 'GYD', '$', 0.2000, 'America/Guyana', 'en', 'Very Good', 4.80, 500],
    ['Paraguay', 'PY', '🇵🇾', 'PYG', '₲', 0.0500, 'America/Asuncion', 'es', 'Very Good', 5.00, 500],
    ['Peru', 'PE', '🇵🇪', 'PEN', 'S/.', 0.0800, 'America/Lima', 'es', 'Excellent', 5.50, 500],
    ['Suriname', 'SR', '🇸🇷', 'SRD', '$', 0.1500, 'America/Paramaribo', 'nl', 'Very Good', 4.80, 500],
    ['Uruguay', 'UY', '🇺🇾', 'UYU', '$', 0.1500, 'America/Montevideo', 'es', 'Good', 4.00, 500],
    ['Venezuela', 'VE', '🇻🇪', 'VES', 'Bs.S', 0.0100, 'America/Caracas', 'es', 'Very Good', 5.00, 500],

    // === OCEANIA ===
    ['New Zealand', 'NZ', '🇳🇿', 'NZD', '$', 0.2200, 'Pacific/Auckland', 'en', 'Good', 3.80, 600],
    ['Fiji', 'FJ', '🇫🇯', 'FJD', '$', 0.2000, 'Pacific/Fiji', 'en', 'Very Good', 5.20, 600],
    ['Kiribati', 'KI', '🇰🇮', 'AUD', '$', 0.3500, 'Pacific/Tarawa', 'en', 'Excellent', 5.50, 600],
    ['Marshall Islands', 'MH', '🇲🇭', 'USD', '$', 0.3500, 'Pacific/Majuro', 'en', 'Excellent', 5.50, 600],
    ['Micronesia', 'FM', '🇫🇲', 'USD', '$', 0.3500, 'Pacific/Chuuk', 'en', 'Very Good', 5.20, 600],
    ['Nauru', 'NR', '🇳🇷', 'AUD', '$', 0.3500, 'Pacific/Nauru', 'en', 'Excellent', 5.50, 600],
    ['Palau', 'PW', '🇵🇼', 'USD', '$', 0.3000, 'Pacific/Palau', 'en', 'Very Good', 5.20, 600],
    ['Papua New Guinea', 'PG', '🇵🇬', 'PGK', 'K', 0.2500, 'Pacific/Port_Moresby', 'en', 'Very Good', 5.00, 600],
    ['Samoa', 'WS', '🇼🇸', 'WST', 'T', 0.2500, 'Pacific/Apia', 'sm', 'Very Good', 5.20, 600],
    ['Solomon Islands', 'SB', '🇸🇧', 'SBD', '$', 0.3000, 'Pacific/Guadalcanal', 'en', 'Very Good', 5.00, 600],
    ['Tonga', 'TO', '🇹🇴', 'TOP', 'T$', 0.3000, 'Pacific/Tongatapu', 'to', 'Very Good', 5.20, 600],
    ['Tuvalu', 'TV', '🇹🇻', 'AUD', '$', 0.3500, 'Pacific/Funafuti', 'en', 'Excellent', 5.50, 600],
    ['Vanuatu', 'VU', '🇻🇺', 'VUV', 'VT', 0.2800, 'Pacific/Efate', 'bi', 'Very Good', 5.00, 600],
];

// Build and execute the INSERT IGNORE statement
// solarglobal.countries schema: code, name, currency_code, currency_symbol, flag_emoji, electricity_rate_kwh, is_supported
$sql = "INSERT IGNORE INTO countries (code, name, currency_code, currency_symbol, flag_emoji, electricity_rate_kwh, is_supported) VALUES ";

$placeholders = [];
$values = [];

foreach ($countries as $c) {
    $placeholders[] = "(?, ?, ?, ?, ?, ?, 1)";
    $values[] = $c[1];  // code
    $values[] = $c[0];  // name
    $values[] = $c[3];  // currency_code
    $values[] = $c[4];  // currency_symbol
    $values[] = $c[2];  // flag_emoji
    $values[] = $c[5];  // electricity_rate_kwh (USD/kWh)
}

$sql .= implode(', ', $placeholders);

try {
    $stmt = $db->prepare($sql);
    $stmt->execute($values);

    $insertedCount = $stmt->rowCount();
    $totalCountries = count($countries);

    echo "=== Countries Seed Complete ===" . PHP_EOL;
    echo "Total countries in seed data: {$totalCountries}" . PHP_EOL;
    echo "New countries inserted: {$insertedCount}" . PHP_EOL;
    echo "Skipped (already existed): " . ($totalCountries - $insertedCount) . PHP_EOL;

    // Verify total in table
    $countStmt = $db->query("SELECT COUNT(*) as total FROM countries");
    $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "Total countries now in database: {$total}" . PHP_EOL;

} catch (PDOException $e) {
    echo "Error seeding countries: " . $e->getMessage() . PHP_EOL;
    exit(1);
}
