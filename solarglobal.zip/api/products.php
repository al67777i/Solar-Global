<?php
/**
 * Public Products API — Paginated, rate-limited product listings
 *
 * GET ?action=list&type=inverter|battery|panel&page=1&per_page=12&brand=...&sort=price_asc|price_desc|rating|newest
 * GET ?action=search&q=keyword&page=1&per_page=12
 * GET ?action=brands&type=inverter
 * GET ?action=stats
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');

// Rate limiting: 30 requests per minute
if (!rate_limit('api_products', 30, 60)) {
    respond_rate_limited();
}

$action = $_GET['action'] ?? 'list';
$db = getDB();

switch ($action) {

    // ─── List products by type with pagination ───
    case 'list':
        $type = $_GET['type'] ?? 'inverter';
        $page = max(1, (int)($_GET['page'] ?? 1));
        $per_page = min(50, max(1, (int)($_GET['per_page'] ?? 12)));
        $offset = ($page - 1) * $per_page;
        $brand = trim($_GET['brand'] ?? '');
        $sort = $_GET['sort'] ?? 'newest';
        $country = trim($_GET['country'] ?? '');

        // Determine table
        $tables = [
            'inverter' => ['table' => 'inverters', 'name_col' => 'name', 'price_col' => 'price_usd'],
            'battery'  => ['table' => 'batteries', 'name_col' => 'name', 'price_col' => 'price_usd'],
            'panel'    => ['table' => 'panels', 'name_col' => 'name', 'price_col' => 'price_usd'],
        ];

        if (!isset($tables[$type])) {
            respond_json(['error' => 'Invalid product type. Use: inverter, battery, panel'], 400);
        }

        $t = $tables[$type];
        $table = $t['table'];
        $conditions = ["is_active = 1"];
        $params = [];

        // Brand filter
        if (!empty($brand)) {
            $conditions[] = "LOWER(brand) = LOWER(?)";
            $params[] = $brand;
        }

        $where = 'WHERE ' . implode(' AND ', $conditions);

        // Sort
        $order = match($sort) {
            'price_asc'  => "price_usd ASC",
            'price_desc' => "price_usd DESC",
            'name'       => "name ASC",
            default      => "id DESC", // newest
        };

        // Count total
        $count_stmt = $db->prepare("SELECT COUNT(*) FROM $table $where");
        $count_stmt->execute($params);
        $total = (int)$count_stmt->fetchColumn();

        // Fetch page
        $sql = "SELECT * FROM $table $where ORDER BY $order LIMIT ? OFFSET ?";
        $params[] = $per_page;
        $params[] = $offset;
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Clean up image paths
        foreach ($products as &$p) {
            if (!empty($p['image_path'])) {
                $p['image_url'] = get_image_url($p['image_path']);
            }
        }

        respond_json([
            'success' => true,
            'type' => $type,
            'page' => $page,
            'per_page' => $per_page,
            'total' => $total,
            'total_pages' => ceil($total / $per_page),
            'products' => $products,
        ]);
        break;

    // ─── Search across all product types ───
    case 'search':
        $q = trim($_GET['q'] ?? '');
        if (strlen($q) < 2) {
            respond_json(['error' => 'Search query must be at least 2 characters'], 400);
        }

        $page = max(1, (int)($_GET['page'] ?? 1));
        $per_page = min(50, max(1, (int)($_GET['per_page'] ?? 12)));
        $offset = ($page - 1) * $per_page;
        $like = '%' . $q . '%';

        // Search all three product tables with UNION
        $sql = "
            SELECT 'inverter' as product_type, id, name, brand, price_usd, image_path
            FROM inverters WHERE is_active = 1 AND (name LIKE ? OR brand LIKE ?)
            UNION ALL
            SELECT 'battery' as product_type, id, name, brand, price_usd, image_path
            FROM batteries WHERE is_active = 1 AND (name LIKE ? OR brand LIKE ?)
            UNION ALL
            SELECT 'panel' as product_type, id, name, brand, price_usd, image_path
            FROM panels WHERE is_active = 1 AND (name LIKE ? OR brand LIKE ?)
            ORDER BY name ASC
            LIMIT ? OFFSET ?
        ";

        $stmt = $db->prepare($sql);
        $stmt->execute([$like, $like, $like, $like, $like, $like, $per_page, $offset]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Count total
        $count_sql = "
            SELECT (
                (SELECT COUNT(*) FROM inverters WHERE is_active = 1 AND (model LIKE ? OR company LIKE ?)) +
                (SELECT COUNT(*) FROM batteries WHERE is_active = 1 AND (name LIKE ? OR brand LIKE ?)) +
                (SELECT COUNT(*) FROM panels WHERE is_active = 1 AND (name LIKE ? OR brand LIKE ?))
            ) as total
        ";
        $count_stmt = $db->prepare($count_sql);
        $count_stmt->execute([$like, $like, $like, $like, $like, $like]);
        $total = (int)$count_stmt->fetchColumn();

        foreach ($results as &$r) {
            if (!empty($r['image_path'])) {
                $r['image_url'] = get_image_url($r['image_path']);
            }
        }

        respond_json([
            'success' => true,
            'query' => $q,
            'page' => $page,
            'per_page' => $per_page,
            'total' => $total,
            'total_pages' => ceil($total / $per_page),
            'results' => $results,
        ]);
        break;

    // ─── List available brands for a product type ───
    case 'brands':
        $type = $_GET['type'] ?? 'inverter';
        $tables = ['inverter' => 'inverters', 'battery' => 'batteries', 'panel' => 'panels'];

        if (!isset($tables[$type])) {
            respond_json(['error' => 'Invalid product type'], 400);
        }

        $table = $tables[$type];
        $stmt = $db->query("
            SELECT brand, COUNT(*) as product_count
            FROM $table
            WHERE is_active = 1 AND brand IS NOT NULL AND brand != ''
            GROUP BY brand
            ORDER BY product_count DESC
        ");
        $brands = $stmt->fetchAll(PDO::FETCH_ASSOC);

        respond_json([
            'success' => true,
            'type' => $type,
            'brands' => $brands,
        ]);
        break;

    // ─── Product stats (counts per type) ───
    case 'stats':
        $stats = [];
        foreach (['inverters', 'batteries', 'panels'] as $table) {
            $count = $db->query("SELECT COUNT(*) FROM $table WHERE is_active = 1")->fetchColumn();
            $stats[$table] = (int)$count;
        }

        // Dealer count
        $stats['dealers'] = (int)$db->query("SELECT COUNT(*) FROM dealers WHERE status = 'active'")->fetchColumn();
        $stats['installers'] = (int)$db->query("SELECT COUNT(*) FROM installers WHERE status = 'active'")->fetchColumn();

        respond_json([
            'success' => true,
            'stats' => $stats,
        ]);
        break;

    default:
        respond_json(['error' => 'Unknown action. Use: list, search, brands, stats'], 400);
}
