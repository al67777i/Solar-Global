<?php
/**
 * Installer Login Page
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/installer_auth.php';

set_security_headers();

// If already logged in, go to dashboard
if (is_installer_logged_in()) {
    header('Location: /solarglobal/installer/dashboard.php');
    exit();
}

$error = '';
$info_message = '';

// Check URL params
if (isset($_GET['timeout'])) $info_message = 'Your session has expired. Please login again.';
if (isset($_GET['suspended'])) $error = 'Your account has been suspended. Please contact support.';
if (isset($_GET['registered'])) $info_message = 'Registration successful! You can now login.';
if (isset($_GET['logout'])) $info_message = 'You have been logged out successfully.';
if (isset($_GET['reset'])) $info_message = 'Password has been reset. Login with your new password.';

// Rate limiting
if (!isset($_SESSION['installer_login_attempts'])) {
    $_SESSION['installer_login_attempts'] = 0;
    $_SESSION['installer_login_attempt_time'] = time();
}
if (time() - $_SESSION['installer_login_attempt_time'] > 600) {
    $_SESSION['installer_login_attempts'] = 0;
    $_SESSION['installer_login_attempt_time'] = time();
}
$is_blocked = $_SESSION['installer_login_attempts'] >= 5;
$block_remaining = 0;
if ($is_blocked) {
    $block_remaining = 900 - (time() - $_SESSION['installer_login_attempt_time']);
    if ($block_remaining <= 0) {
        $_SESSION['installer_login_attempts'] = 0;
        $is_blocked = false;
    }
}

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_blocked) {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } elseif (!validate_honeypot('website_url')) {
        $error = 'Submission rejected.';
    } else {
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $error = 'Please enter both email and password.';
        } else {
            try {
                $db = getDB();
                $stmt = $db->prepare("SELECT * FROM installers WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $installer = $stmt->fetch();

                if ($installer && password_verify($password, $installer['password_hash'])) {
                    // Check status
                    if ($installer['status'] === 'rejected') {
                        $error = 'Your registration was rejected. Reason: ' . ($installer['rejection_reason'] ?: 'Not specified.');
                    } elseif ($installer['status'] === 'suspended') {
                        $error = 'Your account has been suspended. Please contact support.';
                    } else {
                        // Login success
                        installer_login($installer);
                        $_SESSION['installer_login_attempts'] = 0;

                        $redirect = $_SESSION['installer_redirect_after_login'] ?? '/solarglobal/installer/dashboard.php';
                        unset($_SESSION['installer_redirect_after_login']);
                        header('Location: ' . $redirect);
                        exit();
                    }
                } else {
                    $_SESSION['installer_login_attempts']++;
                    $error = 'Invalid email or password.';
                }
            } catch (Exception $e) {
                error_log("Installer login error: " . $e->getMessage());
                $error = 'An error occurred. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installer Login - SolarGlobal</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0F172A 0%, #1E293B 50%, #0F172A 100%);
            min-height: 100vh; display: flex; align-items: center;
            justify-content: center; padding: 20px;
        }

        .login-wrapper { width: 100%; max-width: 440px; }

        .login-card {
            background: white; border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 48px 40px; position: relative; overflow: hidden;
        }
        .login-card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0;
            height: 4px; background: linear-gradient(90deg, #F59E0B, #D97706, #F59E0B);
        }

        .logo { text-align: center; margin-bottom: 36px; }
        .logo .sun { font-size: 3rem; margin-bottom: 8px; }
        .logo h1 { font-size: 1.75rem; font-weight: 800; color: #0F172A; }
        .logo p { font-size: 0.875rem; color: #64748B; margin-top: 4px; }

        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block; font-size: 0.875rem; font-weight: 600;
            color: #334155; margin-bottom: 8px;
        }
        .input-wrap {
            position: relative; display: flex; align-items: center;
        }
        .input-wrap .icon {
            position: absolute; left: 14px; font-size: 1.125rem; color: #94A3B8;
            pointer-events: none;
        }
        .form-group input {
            width: 100%; padding: 14px 16px 14px 44px;
            border: 2px solid #E2E8F0; border-radius: 10px;
            font-size: 0.9375rem; font-family: inherit;
            transition: all 0.2s; background: #F8FAFC;
        }
        .form-group input:focus {
            outline: none; border-color: #F59E0B;
            box-shadow: 0 0 0 3px rgba(245,158,11,0.15); background: white;
        }

        .form-options {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 24px; font-size: 0.875rem;
        }
        .form-options label {
            display: flex; align-items: center; gap: 6px; color: #64748B; cursor: pointer;
        }
        .form-options a { color: #F59E0B; text-decoration: none; font-weight: 500; }
        .form-options a:hover { text-decoration: underline; }

        .btn-login {
            width: 100%; padding: 15px; border: none; border-radius: 12px;
            font-size: 1rem; font-weight: 700; cursor: pointer;
            background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
            color: white; transition: all 0.3s;
            display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .btn-login:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(245,158,11,0.4);
        }
        .btn-login:disabled { opacity: 0.6; cursor: not-allowed; }

        .divider {
            display: flex; align-items: center; gap: 16px;
            margin: 28px 0; color: #94A3B8; font-size: 0.8125rem;
        }
        .divider::before, .divider::after {
            content: ''; flex: 1; height: 1px; background: #E2E8F0;
        }

        .btn-register {
            width: 100%; padding: 14px; border: 2px solid #0F172A;
            border-radius: 12px; font-size: 0.9375rem; font-weight: 600;
            cursor: pointer; background: transparent; color: #0F172A;
            transition: all 0.3s; text-decoration: none; text-align: center;
            display: block;
        }
        .btn-register:hover {
            background: #0F172A; color: white;
        }

        .back-home {
            text-align: center; margin-top: 24px;
        }
        .back-home a {
            color: rgba(255,255,255,0.7); text-decoration: none;
            font-size: 0.875rem; transition: color 0.2s;
        }
        .back-home a:hover { color: white; }

        .error-msg {
            background: #FEF2F2; border: 1px solid #FECACA; color: #991B1B;
            padding: 12px 16px; border-radius: 10px; margin-bottom: 20px;
            font-size: 0.875rem; border-left: 4px solid #DC2626;
        }
        .info-msg {
            background: #EFF6FF; border: 1px solid #BFDBFE; color: #1E40AF;
            padding: 12px 16px; border-radius: 10px; margin-bottom: 20px;
            font-size: 0.875rem; border-left: 4px solid #3B82F6;
        }
        .block-msg {
            background: #FFFBEB; border: 1px solid #FDE68A; color: #92400E;
            padding: 12px 16px; border-radius: 10px; margin-bottom: 20px;
            font-size: 0.875rem; border-left: 4px solid #F59E0B;
        }

        .pw-toggle {
            position: absolute; right: 14px; cursor: pointer; font-size: 1.125rem;
            color: #94A3B8; background: none; border: none; padding: 4px;
        }
        .pw-toggle:hover { color: #475569; }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="login-card">
            <div class="logo">
                <div class="sun">&#9889;</div>
                <h1>SolarGlobal</h1>
                <p>Installer Portal</p>
            </div>

            <?php if ($info_message): ?>
                <div class="info-msg"><?= sanitize($info_message) ?></div>
            <?php endif; ?>

            <?php if ($is_blocked): ?>
                <div class="block-msg">
                    Too many failed attempts. Try again in <?= ceil($block_remaining / 60) ?> minutes.
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="error-msg"><?= sanitize($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="" id="loginForm">
                <?= csrf_field() ?>
                <?= render_honeypot_field('website_url') ?>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-wrap">
                        <span class="icon">&#9993;</span>
                        <input type="email" id="email" name="email" required
                               value="<?= sanitize($_POST['email'] ?? '') ?>"
                               placeholder="your@email.com"
                               <?= $is_blocked ? 'disabled' : '' ?>>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-wrap">
                        <span class="icon">&#128274;</span>
                        <input type="password" id="password" name="password" required
                               placeholder="Enter your password"
                               <?= $is_blocked ? 'disabled' : '' ?>>
                        <button type="button" class="pw-toggle" onclick="togglePassword()" id="pwToggle">&#128065;</button>
                    </div>
                </div>

                <div class="form-options">
                    <label>
                        <input type="checkbox" name="remember"> Remember me
                    </label>
                    <a href="forgot-password.php">Forgot password?</a>
                </div>

                <button type="submit" class="btn-login" <?= $is_blocked ? 'disabled' : '' ?>>
                    &#128274; Login to Dashboard
                </button>
            </form>

            <div class="divider">or</div>

            <a href="register.php" class="btn-register">
                &#9889; Register as Solar Installer
            </a>
        </div>

        <div class="back-home">
            <a href="/solarglobal/index.php">&larr; Back to SolarGlobal</a>
        </div>
    </div>

    <script>
    function togglePassword() {
        const pw = document.getElementById('password');
        const btn = document.getElementById('pwToggle');
        if (pw.type === 'password') {
            pw.type = 'text';
            btn.innerHTML = '&#128064;';
        } else {
            pw.type = 'password';
            btn.innerHTML = '&#128065;';
        }
    }
    </script>
</body>
</html>
