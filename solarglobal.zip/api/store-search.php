<?php
/**
 * Store Live Search API
 * Returns JSON results for AJAX search across all product types
 * GET /api/store-search.php?q=huawei
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');

// Rate limit
if (!rate_limit('store_search', 30, 60)) {
    http_response_code(429);
    echo json_encode(['error' => 'Too many requests', 'results' => []]);
    exit;
}

$q = trim($_GET['q'] ?? '');
if (strlen($q) < 2) {
    echo json_encode(['results' => []]);
    exit;
}

$like = "%{$q}%";
$limit = 10;
$results = [];

try {
    $sql = "
        (SELECT i.id, i.model, i.image_path, i.unit_price_usd, 'inverter' AS product_type, c.name AS company
         FROM inverters i LEFT JOIN companies c ON i.company_id = c.id
         WHERE i.is_active = 1 AND (i.model LIKE ? OR c.name LIKE ?)
         LIMIT ?)
        UNION ALL
        (SELECT b.id, b.model AS name, b.image_path, b.price_unit_usd AS price_usd, 'battery' AS product_type, c.name AS company
         FROM batteries b LEFT JOIN companies c ON b.company_id = c.id
         WHERE b.is_active = 1 AND (b.model LIKE ? OR c.name LIKE ?)
         LIMIT ?)
        UNION ALL
        (SELECT p.id, p.name, p.image_path, p.price_usd, 'panel' AS product_type, c.name AS company
         FROM panels p LEFT JOIN companies c ON p.company_id = c.id
         WHERE p.is_active = 1 AND (p.name LIKE ? OR c.name LIKE ?)
         LIMIT ?)
        ORDER BY name ASC
        LIMIT ?
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $like, $like, $limit,
        $like, $like, $limit,
        $like, $like, $limit,
        $limit
    ]);

    $rows = $stmt->fetchAll();
    foreach ($rows as $row) {
        $results[] = [
            'id'           => (int)$row['id'],
            'name'         => $row['name'],
            'company'      => $row['company'] ?? '',
            'product_type' => $row['product_type'],
            'price'        => (float)$row['price_usd'],
            'image'        => !empty($row['image_path']) ? get_image_url($row['image_path']) : '',
        ];
    }
} catch (Exception $e) {
    error_log("Store search error: " . $e->getMessage());
}

echo json_encode(['results' => $results]);
