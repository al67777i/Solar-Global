<?php
/**
 * Dealer Orders AJAX API
 * Handles order status management for authenticated dealers.
 *
 * Endpoints (POST):
 *   action=get_orders       — List dealer orders with filters & pagination
 *   action=get_order_detail — Single order with all items
 *   action=update_status    — Transition order status (CSRF required)
 *   action=dashboard_stats  — Aggregate stats for dealer dashboard
 */

declare(strict_types=1);

session_start();

header('Content-Type: application/json');

// ── Includes ──────────────────────────────────────────────────────────────────
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/csrf.php';
require_once __DIR__ . '/../../includes/helpers.php';

if (!rate_limit('api_dealer_orders', 30, 60)) { respond_rate_limited(); }

// ── Auth guard ────────────────────────────────────────────────────────────────
if (empty($_SESSION['dealer_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$dealer_id = (int) $_SESSION['dealer_id'];

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Send a JSON success response and exit.
 *
 * @param array $payload  Additional fields merged into {"success":true,...}.
 */
function json_success(array $payload = []): void
{
    echo json_encode(array_merge(['success' => true], $payload));
    exit;
}

/**
 * Send a JSON error response and exit.
 *
 * @param string $message  Human-readable error description.
 * @param int    $code     HTTP status code (default 400).
 */
function json_error(string $message, int $code = 400): void
{
    http_response_code($code);
    echo json_encode(['error' => $message]);
    exit;
}

// ── Request parsing ───────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed', 405);
}

$action = trim($_POST['action'] ?? '');
if ($action === '') {
    json_error('Missing action parameter');
}

$db = getDB();

// ── Route ──────────────────────────────────────────────────────────────────────
switch ($action) {

    // =========================================================================
    // 1. GET ORDERS — list with filters & pagination
    // =========================================================================
    case 'get_orders':
        $status  = trim($_POST['status']  ?? '');
        $search  = trim($_POST['search']  ?? '');
        $page    = max(1, (int) ($_POST['page']  ?? 1));
        $per_page = 20;
        $offset  = ($page - 1) * $per_page;

        $valid_statuses = ['pending', 'confirmed', 'ready', 'picked_up', 'cancelled'];

        // Build WHERE clause
        $where  = 'WHERE o.dealer_id = :dealer_id';
        $params = [':dealer_id' => $dealer_id];

        if ($status !== '' && in_array($status, $valid_statuses, true)) {
            $where .= ' AND o.status = :status';
            $params[':status'] = $status;
        }

        if ($search !== '') {
            $where .= ' AND (o.order_number LIKE :search
                             OR c.full_name   LIKE :search
                             OR c.phone       LIKE :search)';
            $params[':search'] = '%' . $search . '%';
        }

        // Count total
        $count_sql = "SELECT COUNT(*) FROM orders o
                      LEFT JOIN customers c ON c.id = o.customer_id
                      $where";
        $stmt = $db->prepare($count_sql);
        $stmt->execute($params);
        $total = (int) $stmt->fetchColumn();

        // Fetch page
        $list_sql = "SELECT
                         o.id,
                         o.order_number,
                         o.status,
                         o.total_amount,
                         o.pickup_deadline,
                         o.confirmed_at,
                         o.ready_at,
                         o.picked_up_at,
                         o.cancelled_at,
                         o.cancel_reason,
                         o.customer_id,
                         c.full_name  AS customer_name,
                         c.phone      AS customer_phone
                     FROM orders o
                     LEFT JOIN customers c ON c.id = o.customer_id
                     $where
                     ORDER BY o.id DESC
                     LIMIT :limit OFFSET :offset";

        $stmt = $db->prepare($list_sql);
        // PDO requires binding integers via bindValue for LIMIT/OFFSET
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val);
        }
        $stmt->bindValue(':limit',  $per_page, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset,   PDO::PARAM_INT);
        $stmt->execute();
        $orders = $stmt->fetchAll();

        json_success([
            'orders'      => $orders,
            'pagination'  => [
                'total'        => $total,
                'per_page'     => $per_page,
                'current_page' => $page,
                'total_pages'  => (int) ceil($total / $per_page),
            ],
        ]);
        break;

    // =========================================================================
    // 2. GET ORDER DETAIL — single order + items
    // =========================================================================
    case 'get_order_detail':
        $order_id = (int) ($_POST['order_id'] ?? 0);
        if ($order_id <= 0) {
            json_error('Invalid order_id');
        }

        // Fetch order — ownership verified via dealer_id
        $stmt = $db->prepare(
            "SELECT
                 o.*,
                 c.full_name  AS customer_name,
                 c.phone      AS customer_phone,
                 c.email      AS customer_email
             FROM orders o
             LEFT JOIN customers c ON c.id = o.customer_id
             WHERE o.id = :order_id AND o.dealer_id = :dealer_id"
        );
        $stmt->execute([':order_id' => $order_id, ':dealer_id' => $dealer_id]);
        $order = $stmt->fetch();

        if (!$order) {
            json_error('Order not found', 404);
        }

        // Fetch items
        $stmt = $db->prepare(
            "SELECT
                 oi.product_type,
                 oi.product_id,
                 oi.product_name,
                 oi.quantity,
                 oi.unit_price,
                 oi.total_price
             FROM order_items oi
             WHERE oi.order_id = :order_id
             ORDER BY oi.product_name ASC"
        );
        $stmt->execute([':order_id' => $order_id]);
        $items = $stmt->fetchAll();

        json_success([
            'order' => $order,
            'items' => $items,
        ]);
        break;

    // =========================================================================
    // 3. UPDATE STATUS — transition with business rules
    // =========================================================================
    case 'update_status':
        // CSRF validation
        $csrf_token = trim($_POST['csrf_token'] ?? '');
        if (!validate_csrf_token($csrf_token)) {
            json_error('Invalid CSRF token', 403);
        }

        $order_id     = (int) ($_POST['order_id']     ?? 0);
        $new_status   = trim($_POST['new_status']     ?? '');
        $cancel_reason = trim($_POST['cancel_reason'] ?? '');

        if ($order_id <= 0) {
            json_error('Invalid order_id');
        }

        $allowed_statuses = ['pending', 'confirmed', 'ready', 'picked_up', 'cancelled'];
        if (!in_array($new_status, $allowed_statuses, true)) {
            json_error('Invalid status value');
        }

        // Fetch current order — ownership check included
        $stmt = $db->prepare(
            "SELECT id, status FROM orders WHERE id = :order_id AND dealer_id = :dealer_id"
        );
        $stmt->execute([':order_id' => $order_id, ':dealer_id' => $dealer_id]);
        $order = $stmt->fetch();

        if (!$order) {
            json_error('Order not found', 404);
        }

        $current_status = $order['status'];

        // ── Validate transition ────────────────────────────────────────────────
        $valid_transitions = [
            'pending'   => ['confirmed', 'cancelled'],
            'confirmed' => ['ready',     'cancelled'],
            'ready'     => ['picked_up', 'cancelled'],
            'picked_up' => [],
            'cancelled' => [],
        ];

        if (!isset($valid_transitions[$current_status])) {
            json_error('Unknown current status');
        }

        if (!in_array($new_status, $valid_transitions[$current_status], true)) {
            json_error(
                "Cannot transition order from '{$current_status}' to '{$new_status}'",
                422
            );
        }

        // ── Build UPDATE fields ────────────────────────────────────────────────
        $set_parts  = ['status = :new_status'];
        $set_params = [
            ':new_status' => $new_status,
            ':order_id'   => $order_id,
            ':dealer_id'  => $dealer_id,
        ];

        switch ($new_status) {
            case 'confirmed':
                $set_parts[] = 'confirmed_at    = NOW()';
                $set_parts[] = 'pickup_deadline = DATE_ADD(NOW(), INTERVAL 24 HOUR)';
                break;

            case 'ready':
                $set_parts[] = 'ready_at = NOW()';
                break;

            case 'picked_up':
                $set_parts[] = 'picked_up_at = NOW()';
                break;

            case 'cancelled':
                $set_parts[] = 'cancelled_at = NOW()';
                if ($cancel_reason !== '') {
                    $set_parts[]                  = 'cancel_reason = :cancel_reason';
                    $set_params[':cancel_reason'] = $cancel_reason;
                }
                break;
        }

        $set_clause = implode(', ', $set_parts);

        try {
            $db->beginTransaction();

            // Update order
            $stmt = $db->prepare(
                "UPDATE orders
                 SET $set_clause
                 WHERE id = :order_id AND dealer_id = :dealer_id"
            );
            $stmt->execute($set_params);

            // ── Restore stock on cancellation ──────────────────────────────────
            if ($new_status === 'cancelled') {
                $stmt = $db->prepare(
                    "SELECT product_type, product_id, quantity
                     FROM order_items
                     WHERE order_id = :order_id"
                );
                $stmt->execute([':order_id' => $order_id]);
                $items = $stmt->fetchAll();

                foreach ($items as $item) {
                    // Increment stock_quantity
                    $stmt = $db->prepare(
                        "UPDATE dealer_products
                         SET stock_quantity = stock_quantity + :qty
                         WHERE dealer_id     = :dealer_id
                           AND product_type  = :product_type
                           AND product_id    = :product_id"
                    );
                    $stmt->execute([
                        ':qty'          => (int) $item['quantity'],
                        ':dealer_id'    => $dealer_id,
                        ':product_type' => $item['product_type'],
                        ':product_id'   => (int) $item['product_id'],
                    ]);

                    // Update stock_status to 'in_stock' if quantity is now > 0
                    $stmt = $db->prepare(
                        "UPDATE dealer_products
                         SET stock_status = CASE
                             WHEN stock_quantity > 0 THEN 'in_stock'
                             ELSE stock_status
                         END
                         WHERE dealer_id    = :dealer_id
                           AND product_type = :product_type
                           AND product_id   = :product_id"
                    );
                    $stmt->execute([
                        ':dealer_id'    => $dealer_id,
                        ':product_type' => $item['product_type'],
                        ':product_id'   => (int) $item['product_id'],
                    ]);
                }
            }

            $db->commit();
        } catch (PDOException $e) {
            $db->rollBack();
            error_log('orders.php update_status error: ' . $e->getMessage());
            json_error('Failed to update order status. Please try again.', 500);
        }

        json_success([
            'order_id'   => $order_id,
            'new_status' => $new_status,
            'message'    => 'Order status updated successfully',
        ]);
        break;

    // =========================================================================
    // 4. DASHBOARD STATS
    // =========================================================================
    case 'dashboard_stats':
        // Total orders
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM orders WHERE dealer_id = :dealer_id"
        );
        $stmt->execute([':dealer_id' => $dealer_id]);
        $total_orders = (int) $stmt->fetchColumn();

        // Pending count
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM orders
             WHERE dealer_id = :dealer_id AND status = 'pending'"
        );
        $stmt->execute([':dealer_id' => $dealer_id]);
        $pending_count = (int) $stmt->fetchColumn();

        // Revenue today (picked_up orders)
        $stmt = $db->prepare(
            "SELECT COALESCE(SUM(total_amount), 0)
             FROM orders
             WHERE dealer_id = :dealer_id
               AND status    = 'picked_up'
               AND DATE(picked_up_at) = CURDATE()"
        );
        $stmt->execute([':dealer_id' => $dealer_id]);
        $revenue_today = (float) $stmt->fetchColumn();

        // Revenue this month
        $stmt = $db->prepare(
            "SELECT COALESCE(SUM(total_amount), 0)
             FROM orders
             WHERE dealer_id = :dealer_id
               AND status    = 'picked_up'
               AND YEAR(picked_up_at)  = YEAR(NOW())
               AND MONTH(picked_up_at) = MONTH(NOW())"
        );
        $stmt->execute([':dealer_id' => $dealer_id]);
        $revenue_month = (float) $stmt->fetchColumn();

        // Recent 5 orders
        $stmt = $db->prepare(
            "SELECT
                 o.id,
                 o.order_number,
                 o.status,
                 o.total_amount,
                 o.pickup_deadline,
                 o.confirmed_at,
                 o.ready_at,
                 o.picked_up_at,
                 o.cancelled_at,
                 c.full_name AS customer_name,
                 c.phone     AS customer_phone
             FROM orders o
             LEFT JOIN customers c ON c.id = o.customer_id
             WHERE o.dealer_id = :dealer_id
             ORDER BY o.id DESC
             LIMIT 5"
        );
        $stmt->execute([':dealer_id' => $dealer_id]);
        $recent_orders = $stmt->fetchAll();

        // Confirmed orders still awaiting readiness
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM orders
             WHERE dealer_id = :dealer_id AND status = 'confirmed'"
        );
        $stmt->execute([':dealer_id' => $dealer_id]);
        $confirmed_count = (int) $stmt->fetchColumn();

        json_success([
            'stats' => [
                'total_orders'    => $total_orders,
                'pending_count'   => $pending_count,
                'confirmed_count' => $confirmed_count,
                'revenue_today'   => $revenue_today,
                'revenue_month'   => $revenue_month,
            ],
            'recent_orders' => $recent_orders,
        ]);
        break;

    // =========================================================================
    // Unknown action
    // =========================================================================
    default:
        json_error('Unknown action');
        break;
}
