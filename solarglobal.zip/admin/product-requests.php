<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';

$db = getDB();
$pageTitle = 'Product Requests';
$message = '';

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $requestId = intval($_POST['request_id'] ?? 0);
        $action = $_POST['action'];
        $adminNotes = trim($_POST['admin_notes'] ?? '');
        $adminId = intval($_SESSION['admin_id'] ?? 0);

        if ($requestId > 0) {
            if ($action === 'approve') {
                $db->prepare("UPDATE dealer_product_requests SET status = 'approved', admin_notes = ?, handled_by = ?, handled_at = NOW() WHERE id = ?")->execute([$adminNotes, $adminId, $requestId]);
                $message = 'Request approved.';
            } elseif ($action === 'reject') {
                $db->prepare("UPDATE dealer_product_requests SET status = 'rejected', admin_notes = ?, handled_by = ?, handled_at = NOW() WHERE id = ?")->execute([$adminNotes, $adminId, $requestId]);
                $message = 'Request rejected.';
            } elseif ($action === 'mark_added') {
                $db->prepare("UPDATE dealer_product_requests SET status = 'added', admin_notes = ?, handled_by = ?, handled_at = NOW() WHERE id = ?")->execute([$adminNotes, $adminId, $requestId]);
                $message = 'Request marked as added to catalog.';
            }
        }
    }
}

// Fetch requests
$statusFilter = $_GET['status'] ?? 'pending';
$validStatuses = ['pending', 'approved', 'rejected', 'added', 'all'];
if (!in_array($statusFilter, $validStatuses)) $statusFilter = 'pending';

$sql = "SELECT r.*, d.business_name, d.owner_name, d.country_code as dealer_country
        FROM dealer_product_requests r
        LEFT JOIN dealers d ON r.dealer_id = d.id";
if ($statusFilter !== 'all') {
    $sql .= " WHERE r.status = ?";
}
$sql .= " ORDER BY r.created_at DESC LIMIT 50";

if ($statusFilter !== 'all') {
    $stmt = $db->prepare($sql);
    $stmt->execute([$statusFilter]);
} else {
    $stmt = $db->query($sql);
}
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Count by status
$counts = $db->query("SELECT status, COUNT(*) as cnt FROM dealer_product_requests GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);

include __DIR__ . '/includes/header.php';
?>

<style>
    .requests-container { max-width: 1100px; margin: 0 auto; }
    .status-tabs { display: flex; gap: 8px; margin-bottom: 24px; }
    .status-tab { padding: 8px 16px; border-radius: 6px; font-size: 13px; font-weight: 500; text-decoration: none; color: #6b7280; background: #f3f4f6; }
    .status-tab.active { background: #f59e0b; color: #fff; }
    .status-tab .count { background: rgba(0,0,0,0.1); padding: 1px 6px; border-radius: 10px; font-size: 11px; margin-left: 4px; }
    .request-card { background: #fff; border-radius: 10px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); margin-bottom: 16px; display: grid; grid-template-columns: 1fr auto; gap: 16px; }
    .request-info h4 { margin: 0 0 4px; font-size: 15px; }
    .request-info .meta { font-size: 12px; color: #6b7280; margin-bottom: 8px; }
    .request-info .specs { font-size: 13px; color: #374151; background: #f9fafb; padding: 8px 12px; border-radius: 6px; margin-top: 8px; }
    .request-actions { display: flex; flex-direction: column; gap: 8px; min-width: 160px; }
    .request-actions form { display: flex; flex-direction: column; gap: 6px; }
    .btn-sm { padding: 6px 12px; border: none; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer; }
    .btn-approve { background: #d1fae5; color: #065f46; }
    .btn-reject { background: #fee2e2; color: #991b1b; }
    .btn-added { background: #dbeafe; color: #1d4ed8; }
    .badge-type { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
    .empty-state { text-align: center; padding: 48px; color: #6b7280; }
</style>

<div class="requests-container">
    <?php if ($message): ?>
        <div class="alert alert-success" style="background:#d1fae5;border:1px solid #6ee7b7;padding:12px 16px;border-radius:8px;margin-bottom:16px;color:#065f46;"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="status-tabs">
        <?php foreach (['pending', 'approved', 'rejected', 'added', 'all'] as $s): ?>
            <a href="?status=<?= $s ?>" class="status-tab <?= $statusFilter === $s ? 'active' : '' ?>">
                <?= ucfirst($s) ?>
                <?php if (isset($counts[$s])): ?><span class="count"><?= $counts[$s] ?></span><?php endif; ?>
            </a>
        <?php endforeach; ?>
    </div>

    <?php if (empty($requests)): ?>
        <div class="empty-state">No product requests found.</div>
    <?php else: ?>
        <?php foreach ($requests as $req): ?>
        <div class="request-card">
            <div class="request-info">
                <h4>
                    <span class="badge-type" style="background:#<?= $req['product_type']==='inverter'?'dbeafe':($req['product_type']==='battery'?'d1fae5':'fef3c7') ?>">
                        <?= htmlspecialchars($req['product_type']) ?>
                    </span>
                    <?= htmlspecialchars($req['brand']) ?> — <?= htmlspecialchars($req['model_name']) ?>
                </h4>
                <div class="meta">
                    Requested by <strong><?= htmlspecialchars($req['business_name'] ?? 'Unknown') ?></strong>
                    (<?= htmlspecialchars($req['dealer_country'] ?? '') ?>)
                    on <?= date('M j, Y', strtotime($req['created_at'])) ?>
                </div>
                <?php if ($req['specifications']): ?>
                    <div class="specs"><strong>Specs:</strong> <?= htmlspecialchars($req['specifications']) ?></div>
                <?php endif; ?>
                <?php if ($req['reason']): ?>
                    <div class="specs"><strong>Reason:</strong> <?= htmlspecialchars($req['reason']) ?></div>
                <?php endif; ?>
                <?php if ($req['reference_url']): ?>
                    <div style="margin-top:6px;font-size:12px;"><a href="<?= htmlspecialchars($req['reference_url']) ?>" target="_blank" rel="noopener">Reference Link</a></div>
                <?php endif; ?>
            </div>

            <?php if ($req['status'] === 'pending'): ?>
            <div class="request-actions">
                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="request_id" value="<?= $req['id'] ?>">
                    <input type="text" name="admin_notes" placeholder="Notes (optional)" style="padding:6px 8px;border:1px solid #d1d5db;border-radius:4px;font-size:12px;">
                    <button type="submit" name="action" value="approve" class="btn-sm btn-approve">Approve</button>
                    <button type="submit" name="action" value="reject" class="btn-sm btn-reject">Reject</button>
                    <button type="submit" name="action" value="mark_added" class="btn-sm btn-added">Mark as Added</button>
                </form>
            </div>
            <?php elseif ($req['status'] === 'approved'): ?>
            <div class="request-actions">
                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="request_id" value="<?= $req['id'] ?>">
                    <input type="text" name="admin_notes" placeholder="Notes" style="padding:6px 8px;border:1px solid #d1d5db;border-radius:4px;font-size:12px;">
                    <button type="submit" name="action" value="mark_added" class="btn-sm btn-added">Mark as Added</button>
                </form>
            </div>
            <?php else: ?>
            <div style="font-size:12px;color:#6b7280;text-align:right;">
                <div style="text-transform:uppercase;font-weight:600;"><?= htmlspecialchars($req['status']) ?></div>
                <?php if ($req['admin_notes']): ?><div style="margin-top:4px;"><?= htmlspecialchars($req['admin_notes']) ?></div><?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
