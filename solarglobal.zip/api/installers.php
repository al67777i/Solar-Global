<?php
/**
 * Installer Search API
 * GET /api/installers.php?lat=...&lng=...&radius=50&type=residential&min_rating=3
 * Returns JSON array of matching active installers sorted by rating & distance
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

if (!rate_limit('api_installers', 30, 60)) { respond_rate_limited(); }

$db = getDB();

$lat = floatval($_GET['lat'] ?? 0);
$lng = floatval($_GET['lng'] ?? 0);
$radius = intval($_GET['radius'] ?? 100); // km
$projectType = $_GET['type'] ?? '';
$minRating = floatval($_GET['min_rating'] ?? 0);
$limit = min(intval($_GET['limit'] ?? 20), 50);
$offset = intval($_GET['offset'] ?? 0);

// Validate
if ($lat == 0 && $lng == 0) {
    // No location - return all active installers ordered by rating
    $sql = "SELECT id, business_name, owner_name, city, region, country_code,
                   logo_path, price_per_kw, specializations, years_experience,
                   team_size, completed_installations, avg_rating, total_reviews,
                   is_featured, latitude, longitude, service_radius_km, about_text
            FROM installers
            WHERE status = 'active'";
    $params = [];

    if ($minRating > 0) {
        $sql .= " AND avg_rating >= ?";
        $params[] = $minRating;
    }
    if ($projectType && in_array($projectType, ['residential', 'commercial', 'industrial'])) {
        $sql .= " AND specializations LIKE ?";
        $params[] = '%' . $projectType . '%';
    }

    $sql .= " ORDER BY is_featured DESC, avg_rating DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $installers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'count' => count($installers),
        'installers' => $installers
    ]);
    exit;
}

// Haversine formula for distance-based search
$sql = "SELECT id, business_name, owner_name, city, region, country_code,
               logo_path, price_per_kw, specializations, years_experience,
               team_size, completed_installations, avg_rating, total_reviews,
               is_featured, latitude, longitude, service_radius_km, about_text,
               (6371 * ACOS(
                   COS(RADIANS(?)) * COS(RADIANS(latitude)) *
                   COS(RADIANS(longitude) - RADIANS(?)) +
                   SIN(RADIANS(?)) * SIN(RADIANS(latitude))
               )) AS distance_km
        FROM installers
        WHERE status = 'active'
        HAVING distance_km <= LEAST(?, service_radius_km)";

$params = [$lat, $lng, $lat, $radius];

if ($minRating > 0) {
    $sql .= " AND avg_rating >= ?";
    $params[] = $minRating;
}
if ($projectType && in_array($projectType, ['residential', 'commercial', 'industrial'])) {
    // Need to add this before HAVING, restructure
    $sql = "SELECT id, business_name, owner_name, city, region, country_code,
                   logo_path, price_per_kw, specializations, years_experience,
                   team_size, completed_installations, avg_rating, total_reviews,
                   is_featured, latitude, longitude, service_radius_km, about_text,
                   (6371 * ACOS(
                       COS(RADIANS(?)) * COS(RADIANS(latitude)) *
                       COS(RADIANS(longitude) - RADIANS(?)) +
                       SIN(RADIANS(?)) * SIN(RADIANS(latitude))
                   )) AS distance_km
            FROM installers
            WHERE status = 'active' AND specializations LIKE ?";

    if ($minRating > 0) {
        $sql .= " AND avg_rating >= ?";
    }

    $sql .= " HAVING distance_km <= LEAST(?, service_radius_km)
              ORDER BY is_featured DESC, avg_rating DESC, distance_km ASC
              LIMIT ? OFFSET ?";

    $params = [$lat, $lng, $lat, '%' . $projectType . '%'];
    if ($minRating > 0) {
        $params[] = $minRating;
    }
    $params[] = $radius;
    $params[] = $limit;
    $params[] = $offset;
} else {
    $sql .= " ORDER BY is_featured DESC, avg_rating DESC, distance_km ASC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
}

try {
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $installers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Round distances
    foreach ($installers as &$inst) {
        $inst['distance_km'] = round(floatval($inst['distance_km']), 1);
    }

    echo json_encode([
        'success' => true,
        'count' => count($installers),
        'search' => ['lat' => $lat, 'lng' => $lng, 'radius' => $radius],
        'installers' => $installers
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error',
        'message' => $e->getMessage()
    ]);
}
