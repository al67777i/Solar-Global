/**
 * SolarGlobal 3D Connection Diagram
 * Realistic house with solar panels on roof, animated energy flow
 * Supports: On-Grid, Hybrid, Off-Grid
 */
(function () {
  "use strict";

  const COLORS = {
    solar: "#f59e0b",
    battery: "#3b82f6",
    inverter: "#0d3b6e",
    load: "#10b981",
    grid: "#8b5cf6",
    dcWire: "#ef4444",
    acWire: "#10b981",
  };

  function render(containerId, systemData) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const inv = systemData.inverter || {};
    const bat = systemData.battery_config;
    const pan = systemData.panel_config;
    const loadAnalysis = window.appState?.recommendations?.load_analysis || {};
    const systemType = systemData.system_type || inv.type || "hybrid";
    const isOnGrid = systemType === "on-grid" || !bat;
    const isOffGrid = systemType === "off-grid";

    const panelCount = pan?.quantity || 6;
    const panelWatts = pan?.total_wattage || 0;
    const dailyGen = pan?.daily_gen_kwh || pan?.daily_generation_kwh || 0;
    const invName =
      (inv.company_name || inv.company || "") +
      " " +
      (inv.name || inv.model || "");
    const invW =
      inv.max_load_watts || inv.power_rating || inv.output_power_w || 0;
    const batAh = bat?.total_ah || 0;
    const batQty = bat?.quantity || 0;
    const backupH = bat?.backup_hours || 0;
    const totalLoad =
      loadAnalysis.total_load_watts || loadAnalysis.peak_load_watts || 0;
    const applianceCount = loadAnalysis.appliance_details?.length || 0;

    container.innerHTML = buildHTML(
      systemType,
      isOnGrid,
      isOffGrid,
      panelCount,
      panelWatts,
      dailyGen,
      invName.trim(),
      invW,
      batAh,
      batQty,
      backupH,
      totalLoad,
      applianceCount,
      pan,
      bat,
      inv,
    );

    requestAnimationFrame(() => animateEntrance(container));
  }

  function buildHTML(
    systemType,
    isOnGrid,
    isOffGrid,
    panelCount,
    panelWatts,
    dailyGen,
    invName,
    invW,
    batAh,
    batQty,
    backupH,
    totalLoad,
    applianceCount,
    pan,
    bat,
    inv,
  ) {
    // Build roof panel SVG
    const roofPanels = buildRoofPanels(panelCount);

    // Energy flow description
    let flowDesc = "";
    if (isOnGrid) {
      flowDesc = "Solar → Inverter ↔ Grid → Home";
    } else if (isOffGrid) {
      flowDesc = "Solar → Inverter ↔ Battery → Home";
    } else {
      flowDesc = "Solar → Inverter ↔ Battery + Grid → Home";
    }

    return `
        <div class="cd3d-wrapper">
            <div class="cd3d-title">
                <h3>System Connection Overview</h3>
                <p>${flowDesc}</p>
            </div>

            <div class="cd3d-house-diagram">
                <svg viewBox="0 0 900 520" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;overflow:visible;">
                    <defs>
                        ${buildDefs()}
                    </defs>

                    <!-- Sky background -->
                    <rect x="0" y="0" width="900" height="520" fill="url(#skyGrad)" rx="12"/>

                    <!-- Ground -->
                    <rect x="0" y="390" width="900" height="130" fill="url(#groundGrad)"/>

                    <!-- Sun -->
                    <circle cx="820" cy="60" r="42" fill="#FCD34D" opacity="0.95" filter="url(#sunGlow)">
                        <animate attributeName="opacity" values="0.9;1.0;0.9" dur="4s" repeatCount="indefinite"/>
                    </circle>
                    <circle cx="820" cy="60" r="52" fill="none" stroke="#FCD34D" stroke-width="3" opacity="0.3">
                        <animate attributeName="r" values="52;58;52" dur="3s" repeatCount="indefinite"/>
                        <animate attributeName="opacity" values="0.3;0.1;0.3" dur="3s" repeatCount="indefinite"/>
                    </circle>

                    <!-- HOUSE -->
                    <!-- House walls -->
                    <rect x="280" y="255" width="280" height="160" fill="#E8E0D0" stroke="#B8A890" stroke-width="2"/>
                    <!-- House door -->
                    <rect x="385" y="330" width="50" height="85" fill="#8B6914" rx="4"/>
                    <circle cx="426" cy="374" r="4" fill="#F59E0B"/>
                    <!-- Windows -->
                    <rect x="300" y="280" width="55" height="45" fill="#BAE6FD" stroke="#7CB9E8" stroke-width="1.5" rx="3"/>
                    <line x1="327" y1="280" x2="327" y2="325" stroke="#7CB9E8" stroke-width="1"/>
                    <line x1="300" y1="302" x2="355" y2="302" stroke="#7CB9E8" stroke-width="1"/>
                    <rect x="485" y="280" width="55" height="45" fill="#BAE6FD" stroke="#7CB9E8" stroke-width="1.5" rx="3"/>
                    <line x1="512" y1="280" x2="512" y2="325" stroke="#7CB9E8" stroke-width="1"/>
                    <line x1="485" y1="302" x2="540" y2="302" stroke="#7CB9E8" stroke-width="1"/>

                    <!-- ROOF -->
                    <polygon points="255,260 840,260 840,260 560,130 280,130" fill="#CC4444" stroke="#AA3333" stroke-width="2"/>
                    <polygon points="255,260 280,260 280,130" fill="#AA3333"/>

                    <!-- SOLAR PANELS ON ROOF -->
                    ${roofPanels}
                    <!-- Panel count label -->
                    <rect x="390" y="138" width="100" height="22" rx="11" fill="rgba(0,0,0,0.6)"/>
                    <text x="440" y="153" text-anchor="middle" font-size="11" fill="#FCD34D" font-weight="700">${panelCount} Panels · ${(panelWatts / 1000).toFixed(1)}kWp</text>

                    <!-- DC Cable from panels to inverter -->
                    <path id="dcPath" d="M 540 260 L 540 310 L 170 310 L 170 360" fill="none" stroke="#EF4444" stroke-width="4" stroke-dasharray="10 5" opacity="0.85"/>
                    <!-- DC+ label -->
                    <rect x="200" y="300" width="36" height="16" rx="4" fill="#EF4444"/>
                    <text x="218" y="312" text-anchor="middle" font-size="9" fill="white" font-weight="800">DC+</text>

                    <!-- INVERTER BOX -->
                    <rect x="110" y="340" width="120" height="90" rx="12" fill="#0D3B6E" stroke="#1565C0" stroke-width="2">
                        <animate attributeName="filter" values="none;url(#invGlow);none" dur="3s" repeatCount="indefinite"/>
                    </rect>
                    <text x="170" y="375" text-anchor="middle" font-size="22">&#x26A1;</text>
                    <text x="170" y="395" text-anchor="middle" font-size="10" fill="#93C5FD" font-weight="700">INVERTER</text>
                    <text x="170" y="408" text-anchor="middle" font-size="8" fill="#64748B">${invW > 0 ? (invW / 1000).toFixed(1) + "kW" : ""}</text>
                    <text x="170" y="420" text-anchor="middle" font-size="7.5" fill="#475569">${invName.length > 18 ? invName.substring(0, 18) + "…" : invName}</text>

                    <!-- AC Cable from inverter to home -->
                    <path id="acHomePath" d="M 230 380 L 280 380" fill="none" stroke="#10B981" stroke-width="4" stroke-dasharray="8 4"/>
                    <rect x="238" y="368" width="30" height="16" rx="4" fill="#10B981"/>
                    <text x="253" y="380" text-anchor="middle" font-size="9" fill="white" font-weight="800">AC</text>

                    ${
                      !isOnGrid && bat
                        ? `
                    <!-- Battery connection -->
                    <path id="batPath" d="M 170 430 L 170 465 L 720 465 L 720 430" fill="none" stroke="#3B82F6" stroke-width="4" stroke-dasharray="10 5" opacity="0.85"/>
                    <!-- BATTERY PACK -->
                    <rect x="665" y="340" width="110" height="90" rx="12" fill="#1E3A5F" stroke="#3B82F6" stroke-width="2"/>
                    <text x="720" y="373" text-anchor="middle" font-size="20">&#x1F50B;</text>
                    <text x="720" y="393" text-anchor="middle" font-size="10" fill="#93C5FD" font-weight="700">BATTERY</text>
                    <text x="720" y="407" text-anchor="middle" font-size="8.5" fill="#64748B">${batQty}× ${bat?.battery?.capacity_ah || 0}Ah</text>
                    <text x="720" y="420" text-anchor="middle" font-size="9" fill="#F59E0B" font-weight="700">${backupH}h Backup</text>
                    <!-- Battery charge animation -->
                    <rect x="676" y="430" width="88" height="8" rx="4" fill="#1E293B"/>
                    <rect x="676" y="430" width="66" height="8" rx="4" fill="#10B981">
                        <animate attributeName="width" values="20;66;20" dur="4s" repeatCount="indefinite"/>
                    </rect>
                    `
                        : ""
                    }

                    ${
                      !isOffGrid
                        ? `
                    <!-- Grid connection -->
                    <path id="gridPath" d="M 170 340 L 170 290 L 80 290 L 80 220" fill="none" stroke="#8B5CF6" stroke-width="3" stroke-dasharray="8 5" opacity="0.75"/>
                    <!-- GRID ICON -->
                    <rect x="40" y="165" width="80" height="70" rx="10" fill="#4C1D95" stroke="#7C3AED" stroke-width="1.5"/>
                    <text x="80" y="193" text-anchor="middle" font-size="18">&#x1F50C;</text>
                    <text x="80" y="210" text-anchor="middle" font-size="9.5" fill="#C4B5FD" font-weight="700">GRID</text>
                    <text x="80" y="225" text-anchor="middle" font-size="8" fill="#7C3AED">230V AC</text>
                    `
                        : ""
                    }

                    <!-- HOME LOAD LABEL -->
                    <rect x="310" y="395" width="160" height="28" rx="8" fill="rgba(16,185,129,0.15)" stroke="#10B981" stroke-width="1.5"/>
                    <text x="390" y="413" text-anchor="middle" font-size="10" fill="#10B981" font-weight="700">&#x1F3E0; ${totalLoad > 0 ? (totalLoad / 1000).toFixed(1) + "kW Load" : "Your Home"}  ${applianceCount > 0 ? "· " + applianceCount + " Appliances" : ""}</text>

                    <!-- ANIMATED ENERGY PARTICLES -->
                    <!-- Solar DC particles -->
                    <circle r="6" fill="#F59E0B" opacity="0.9" filter="url(#particleGlow)">
                        <animateMotion dur="2.2s" repeatCount="indefinite" path="M 540 260 L 540 310 L 170 310 L 170 360"/>
                    </circle>
                    <circle r="4" fill="#FCD34D" opacity="0.7">
                        <animateMotion dur="2.2s" repeatCount="indefinite" begin="1.1s" path="M 540 260 L 540 310 L 170 310 L 170 360"/>
                    </circle>

                    <!-- AC to home particles -->
                    <circle r="5" fill="#10B981" opacity="0.9" filter="url(#particleGlow)">
                        <animateMotion dur="1.2s" repeatCount="indefinite" path="M 230 380 L 280 380"/>
                    </circle>

                    ${
                      !isOnGrid && bat
                        ? `
                    <!-- Battery charge particles -->
                    <circle r="5" fill="#3B82F6" opacity="0.85" filter="url(#particleGlow)">
                        <animateMotion dur="3s" repeatCount="indefinite" path="M 170 430 L 170 465 L 720 465 L 720 430"/>
                    </circle>
                    `
                        : ""
                    }

                    ${
                      !isOffGrid
                        ? `
                    <!-- Grid particles (bidirectional - dashed = slower) -->
                    <circle r="4" fill="#8B5CF6" opacity="0.75">
                        <animateMotion dur="2.5s" repeatCount="indefinite" begin="0.5s" path="M 80 220 L 80 290 L 170 290 L 170 340"/>
                    </circle>
                    `
                        : ""
                    }

                    <!-- DAILY GENERATION BADGE -->
                    <rect x="760" y="365" width="115" height="50" rx="10" fill="rgba(245,158,11,0.15)" stroke="#F59E0B" stroke-width="1.5"/>
                    <text x="817" y="385" text-anchor="middle" font-size="9" fill="#92400E" font-weight="600">Daily Generation</text>
                    <text x="817" y="403" text-anchor="middle" font-size="14" fill="#F59E0B" font-weight="900">${dailyGen > 0 ? dailyGen.toFixed(1) : "—"} kWh</text>

                </svg>
            </div>

            <!-- Wiring Specs -->
            <div class="cd3d-specs">
                <div class="cd3d-spec-item">
                    <span class="cd3d-spec-color" style="background:#EF4444"></span>
                    <span class="cd3d-spec-label">DC Solar</span>
                    <span class="cd3d-spec-value">6mm² · ${pan?.string_voltage || "—"}V DC</span>
                </div>
                ${
                  !isOnGrid && bat
                    ? `
                <div class="cd3d-spec-item">
                    <span class="cd3d-spec-color" style="background:#3B82F6"></span>
                    <span class="cd3d-spec-label">DC Battery</span>
                    <span class="cd3d-spec-value">16mm² · ${bat?.string_voltage || (bat?.series || 1) * (bat?.battery?.nominal_voltage || bat?.battery?.voltage || 12)}V DC</span>
                </div>
                `
                    : ""
                }
                <div class="cd3d-spec-item">
                    <span class="cd3d-spec-color" style="background:#10B981"></span>
                    <span class="cd3d-spec-label">AC Output</span>
                    <span class="cd3d-spec-value">4mm² · 230V AC</span>
                </div>
                ${
                  !isOffGrid
                    ? `
                <div class="cd3d-spec-item">
                    <span class="cd3d-spec-color" style="background:#8B5CF6"></span>
                    <span class="cd3d-spec-label">Grid ${systemType === "on-grid" ? "(Net Metering)" : "(Backup)"}</span>
                    <span class="cd3d-spec-value">4mm² · 230V AC</span>
                </div>
                `
                    : `
                <div class="cd3d-spec-item">
                    <span class="cd3d-spec-color" style="background:#10B981"></span>
                    <span class="cd3d-spec-label">Off-Grid</span>
                    <span class="cd3d-spec-value">100% Independent</span>
                </div>
                `
                }
            </div>
        </div>`;
  }

  function buildRoofPanels(count) {
    // Place panels on the roof slope (from x=295 to x=820, y range 135-255)
    const panels = [];
    const cols = Math.min(count, 8);
    const rows = Math.ceil(count / cols);
    const panW = 58;
    const panH = 36;
    const startX = 310;
    const startY = 148;
    const xStep = 64;
    const yStep = 42;
    let n = 1;

    for (let r = 0; r < rows && n <= count; r++) {
      for (let c = 0; c < cols && n <= count; c++) {
        const x = startX + c * xStep;
        const y = startY + r * yStep;
        // Simple roof skew transform
        const skewX = r * 2;
        panels.push(`
                <g transform="translate(${x + skewX}, ${y})">
                    <!-- Panel frame -->
                    <rect x="0" y="0" width="${panW}" height="${panH}" rx="3"
                          fill="hsl(${210 + c * 3 + r * 5}, 75%, ${65 + r * 3}%)"
                          stroke="#1E40AF" stroke-width="1.5"/>
                    <!-- Cell lines -->
                    <line x1="${panW * 0.33}" y1="2" x2="${panW * 0.33}" y2="${panH - 2}" stroke="#1E40AF" stroke-width="0.7" opacity="0.6"/>
                    <line x1="${panW * 0.66}" y1="2" x2="${panW * 0.66}" y2="${panH - 2}" stroke="#1E40AF" stroke-width="0.7" opacity="0.6"/>
                    <line x1="2" y1="${panH * 0.5}" x2="${panW - 2}" y2="${panH * 0.5}" stroke="#1E40AF" stroke-width="0.7" opacity="0.6"/>
                    <!-- Reflection gloss -->
                    <rect x="0" y="0" width="${panW}" height="${panH}" rx="3"
                          fill="url(#panelGloss)" pointer-events="none"/>
                    <!-- P label -->
                    <text x="${panW / 2}" y="${panH / 2 + 4}" text-anchor="middle"
                          font-size="8" fill="white" font-weight="700" opacity="0.7">P${n}</text>
                    <!-- Solar shimmer -->
                    <rect x="0" y="0" width="${panW}" height="${panH}" rx="3"
                          fill="rgba(255,255,150,0.08)">
                        <animate attributeName="opacity" values="0;0.15;0" dur="${2 + c * 0.3 + r * 0.2}s" repeatCount="indefinite"/>
                    </rect>
                </g>`);
        n++;
      }
    }
    return panels.join("\n");
  }

  function buildDefs() {
    return `
        <!-- Gradients -->
        <linearGradient id="skyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#1E3A5F"/>
            <stop offset="60%" stop-color="#1B4F72"/>
            <stop offset="100%" stop-color="#2C3E50"/>
        </linearGradient>
        <linearGradient id="groundGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#2D5016"/>
            <stop offset="100%" stop-color="#1A3009"/>
        </linearGradient>
        <linearGradient id="panelGloss" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="white" stop-opacity="0.18"/>
            <stop offset="50%" stop-color="white" stop-opacity="0"/>
            <stop offset="100%" stop-color="white" stop-opacity="0.06"/>
        </linearGradient>
        <!-- Filters -->
        <filter id="sunGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="8" result="blur"/>
            <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
        <filter id="invGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="4" result="blur"/>
            <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
        <filter id="particleGlow" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="2.5" result="blur"/>
            <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>`;
  }

  function animateEntrance(container) {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    if (typeof anime !== "function") return;

    anime({
      targets: container.querySelectorAll(".cd3d-spec-item"),
      translateX: [-20, 0],
      opacity: [0, 1],
      duration: 500,
      delay: anime.stagger(80, { start: 300 }),
      easing: "easeOutCubic",
    });
  }

  window.connectionDiagram3D = { render };
})();
