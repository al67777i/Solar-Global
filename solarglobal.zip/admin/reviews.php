<?php
/**
 * Admin Review Management
 * View, approve, reject, and manage dealer reviews
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

$pdo = getDB();
$success_message = '';
$error_message = '';

// ── Helper: recalculate dealer stats ──
function recalcDealerStats($pdo, $dealer_id) {
    $stmt = $pdo->prepare("UPDATE dealers SET
        avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM dealer_reviews WHERE dealer_id = ? AND status = 'approved'),
        total_reviews = (SELECT COUNT(*) FROM dealer_reviews WHERE dealer_id = ? AND status = 'approved')
        WHERE id = ?");
    $stmt->execute([$dealer_id, $dealer_id, $dealer_id]);
}

// ── Handle POST actions ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        $action = $_POST['action'];
        $review_id = (int)($_POST['review_id'] ?? 0);

        // Fetch the review to get entity id before any mutation
        $entity_id = null;
        $review_type_post = $_POST['review_type'] ?? 'dealer';
        $reviews_table = $review_type_post === 'installer' ? 'installer_reviews' : 'dealer_reviews';
        $entity_col = $review_type_post === 'installer' ? 'installer_id' : 'dealer_id';
        $entity_table = $review_type_post === 'installer' ? 'installers' : 'dealers';
        $updated_sql = $reviews_table === 'dealer_reviews' ? ', updated_at = NOW()' : '';
        if ($review_id) {
            $stmt = $pdo->prepare("SELECT $entity_col as entity_id FROM $reviews_table WHERE id = ?");
            $stmt->execute([$review_id]);
            $entity_id = $stmt->fetchColumn();
        }

        try {
            switch ($action) {
                case 'approve':
                    $stmt = $pdo->prepare("UPDATE $reviews_table SET status = 'approved'$updated_sql WHERE id = ?");
                    $stmt->execute([$review_id]);
                    if ($entity_id) {
                        if ($review_type_post === 'installer') {
                            $stmt = $pdo->prepare("UPDATE installers SET
                                avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM installer_reviews WHERE installer_id = ? AND status = 'approved'),
                                total_reviews = (SELECT COUNT(*) FROM installer_reviews WHERE installer_id = ? AND status = 'approved')
                                WHERE id = ?");
                            $stmt->execute([$entity_id, $entity_id, $entity_id]);
                        } else {
                            recalcDealerStats($pdo, $entity_id);
                        }
                    }
                    $success_message = 'Review approved successfully.';
                    break;

                case 'pending':
                    $stmt = $pdo->prepare("UPDATE $reviews_table SET status = 'pending'$updated_sql WHERE id = ?");
                    $stmt->execute([$review_id]);
                    if ($entity_id) {
                        if ($review_type_post === 'installer') {
                            $stmt = $pdo->prepare("UPDATE installers SET
                                avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM installer_reviews WHERE installer_id = ? AND status = 'approved'),
                                total_reviews = (SELECT COUNT(*) FROM installer_reviews WHERE installer_id = ? AND status = 'approved')
                                WHERE id = ?");
                            $stmt->execute([$entity_id, $entity_id, $entity_id]);
                        } else {
                            recalcDealerStats($pdo, $entity_id);
                        }
                    }
                    $success_message = 'Review set back to pending.';
                    break;

                case 'reject':
                    $reason = trim($_POST['rejection_reason'] ?? '');
                    $stmt = $pdo->prepare("UPDATE $reviews_table SET status = 'rejected', admin_response = CASE WHEN ? != '' THEN ? ELSE admin_response END$updated_sql WHERE id = ?");
                    $stmt->execute([$reason, $reason, $review_id]);
                    if ($entity_id) {
                        if ($review_type_post === 'installer') {
                            $stmt = $pdo->prepare("UPDATE installers SET
                                avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM installer_reviews WHERE installer_id = ? AND status = 'approved'),
                                total_reviews = (SELECT COUNT(*) FROM installer_reviews WHERE installer_id = ? AND status = 'approved')
                                WHERE id = ?");
                            $stmt->execute([$entity_id, $entity_id, $entity_id]);
                        } else {
                            recalcDealerStats($pdo, $entity_id);
                        }
                    }
                    $success_message = 'Review rejected.';
                    break;

                case 'delete':
                    $stmt = $pdo->prepare("DELETE FROM $reviews_table WHERE id = ?");
                    $stmt->execute([$review_id]);
                    if ($entity_id) {
                        if ($review_type_post === 'installer') {
                            $stmt = $pdo->prepare("UPDATE installers SET
                                avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM installer_reviews WHERE installer_id = ? AND status = 'approved'),
                                total_reviews = (SELECT COUNT(*) FROM installer_reviews WHERE installer_id = ? AND status = 'approved')
                                WHERE id = ?");
                            $stmt->execute([$entity_id, $entity_id, $entity_id]);
                        } else {
                            recalcDealerStats($pdo, $entity_id);
                        }
                    }
                    $success_message = 'Review deleted permanently.';
                    break;

                case 'admin_response':
                    $response_text = trim($_POST['admin_response'] ?? '');
                    $stmt = $pdo->prepare("UPDATE $reviews_table SET admin_response = ?$updated_sql WHERE id = ?");
                    $stmt->execute([$response_text, $review_id]);
                    $success_message = 'Admin response saved.';
                    break;
            }
        } catch (Exception $e) {
            $error_message = 'Error: ' . $e->getMessage();
        }
    }
}

// ── Filters ──
$status_filter = $_GET['status'] ?? 'all';
$search = trim($_GET['search'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;
$review_type = in_array($_GET['type'] ?? 'dealer', ['dealer', 'installer']) ? ($_GET['type'] ?? 'dealer') : 'dealer';

// Build WHERE clause
$alias = $review_type === 'installer' ? 'ir' : 'dr';
$where_clauses = [];
$params = [];

if ($status_filter !== 'all' && in_array($status_filter, ['approved', 'pending', 'rejected'])) {
    $where_clauses[] = "$alias.status = ?";
    $params[] = $status_filter;
}

if ($search !== '') {
    if ($review_type === 'installer') {
        $where_clauses[] = "(i.business_name LIKE ? OR $alias.reviewer_name LIKE ? OR $alias.review_text LIKE ?)";
    } else {
        $where_clauses[] = "(d.business_name LIKE ? OR c.name LIKE ? OR $alias.review_text LIKE ?)";
    }
    $search_param = '%' . $search . '%';
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

$where_sql = $where_clauses ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

// ── Counts per status ──
$counts_table = $review_type === 'installer' ? 'installer_reviews' : 'dealer_reviews';
$counts = ['all' => 0, 'approved' => 0, 'pending' => 0, 'rejected' => 0];
try {
    $stmt = $pdo->query("SELECT status, COUNT(*) as cnt FROM $counts_table GROUP BY status");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $counts[$row['status']] = (int)$row['cnt'];
        $counts['all'] += (int)$row['cnt'];
    }
} catch (Exception $e) { /* silent */ }

// ── Summary stats ──
$summary_avg = 0;
try {
    $stmt = $pdo->query("SELECT COALESCE(AVG(rating), 0) FROM $counts_table WHERE status = 'approved'");
    $summary_avg = round($stmt->fetchColumn(), 1);
} catch (Exception $e) { /* silent */ }

// ── Fetch reviews ──
$reviews = [];
$total_rows = 0;
try {
    if ($review_type === 'installer') {
        // Count
        $count_sql = "SELECT COUNT(*) FROM installer_reviews ir
            LEFT JOIN installers i ON ir.installer_id = i.id
            $where_sql";
        $stmt = $pdo->prepare($count_sql);
        $stmt->execute($params);
        $total_rows = (int)$stmt->fetchColumn();

        // Data
        $data_sql = "SELECT ir.*, i.business_name AS dealer_name, ir.reviewer_name AS customer_name, ir.reviewer_email AS customer_email, io.id AS order_number
            FROM installer_reviews ir
            LEFT JOIN installers i ON ir.installer_id = i.id
            LEFT JOIN installer_orders io ON ir.order_id = io.id
            $where_sql
            ORDER BY ir.created_at DESC
            LIMIT $per_page OFFSET $offset";
        $stmt = $pdo->prepare($data_sql);
        $stmt->execute($params);
        $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Count
        $count_sql = "SELECT COUNT(*) FROM dealer_reviews dr
            LEFT JOIN dealers d ON dr.dealer_id = d.id
            LEFT JOIN customers c ON dr.customer_id = c.id
            $where_sql";
        $stmt = $pdo->prepare($count_sql);
        $stmt->execute($params);
        $total_rows = (int)$stmt->fetchColumn();

        // Data
        $data_sql = "SELECT dr.*, d.business_name AS dealer_name, c.name AS customer_name, c.email AS customer_email, o.order_number
            FROM dealer_reviews dr
            LEFT JOIN dealers d ON dr.dealer_id = d.id
            LEFT JOIN customers c ON dr.customer_id = c.id
            LEFT JOIN orders o ON dr.order_id = o.id
            $where_sql
            ORDER BY dr.created_at DESC
            LIMIT $per_page OFFSET $offset";
        $stmt = $pdo->prepare($data_sql);
        $stmt->execute($params);
        $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $error_message = 'Error loading reviews: ' . $e->getMessage();
}

$total_pages = max(1, ceil($total_rows / $per_page));

// Build query string helper for pagination links
function buildQs($overrides = []) {
    $params = array_merge($_GET, $overrides);
    return '?' . http_build_query($params);
}

$pageTitle = 'Review Management';
?>
<?php include 'includes/header.php'; ?>

<style>
    /* ── Summary Cards ── */
    .review-summary {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 16px;
        margin-bottom: 28px;
    }
    .summary-card {
        background: #fff;
        border-radius: 12px;
        padding: 20px 24px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        text-align: center;
    }
    .summary-card .value {
        font-size: 2rem;
        font-weight: 700;
        color: #0D3B6E;
    }
    .summary-card .label {
        font-size: 0.85rem;
        color: #64748B;
        margin-top: 4px;
    }

    /* ── Filter tabs ── */
    .filter-tabs {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
        border-bottom: 2px solid #E2E8F0;
        flex-wrap: wrap;
    }
    .filter-tab {
        padding: 12px 24px;
        background: none;
        border: none;
        border-bottom: 3px solid transparent;
        cursor: pointer;
        font-weight: 600;
        color: #64748B;
        transition: all 0.3s ease;
        text-decoration: none;
        font-size: 0.95rem;
    }
    .filter-tab:hover { color: #0D3B6E; }
    .filter-tab.active {
        color: #0D3B6E;
        border-bottom-color: #0D3B6E;
    }
    .filter-tab .badge {
        display: inline-block;
        background: #E2E8F0;
        color: #475569;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.75rem;
        margin-left: 8px;
    }
    .filter-tab.active .badge {
        background: #0D3B6E;
        color: #fff;
    }

    /* ── Search ── */
    .search-bar {
        margin-bottom: 24px;
    }
    .search-bar form {
        display: flex;
        gap: 10px;
        max-width: 520px;
    }
    .search-bar input[type="text"] {
        flex: 1;
        padding: 10px 16px;
        border: 2px solid #E2E8F0;
        border-radius: 8px;
        font-size: 0.95rem;
        font-family: inherit;
        outline: none;
        transition: border-color 0.2s;
    }
    .search-bar input[type="text"]:focus {
        border-color: #1565C0;
    }
    .search-bar button {
        padding: 10px 20px;
        background: #0D3B6E;
        color: #fff;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        font-size: 0.95rem;
    }
    .search-bar button:hover { background: #1565C0; }

    /* ── Reviews grid ── */
    .reviews-grid {
        display: grid;
        gap: 20px;
    }

    /* ── Review card ── */
    .review-card {
        background: #fff;
        border-radius: 12px;
        padding: 24px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        border-left: 4px solid #E2E8F0;
    }
    .review-card.status-approved  { border-left-color: #10B981; }
    .review-card.status-pending   { border-left-color: #F59E0B; }
    .review-card.status-rejected  { border-left-color: #EF4444; }

    .review-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 14px;
        flex-wrap: wrap;
        gap: 10px;
    }
    .review-header h3 {
        font-size: 1.1rem;
        color: #0D3B6E;
        margin: 0 0 4px 0;
    }
    .review-meta {
        font-size: 0.85rem;
        color: #64748B;
        display: flex;
        flex-wrap: wrap;
        gap: 14px;
    }

    /* Status badges */
    .status-badge {
        padding: 5px 12px;
        border-radius: 6px;
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.03em;
        white-space: nowrap;
    }
    .status-badge.approved { background: #DCFCE7; color: #166534; }
    .status-badge.pending  { background: #FEF3C7; color: #92400E; }
    .status-badge.rejected { background: #FEE2E2; color: #991B1B; }

    /* Stars */
    .stars { display: inline-flex; gap: 2px; font-size: 1.1rem; }
    .stars .star-filled { color: #F59E0B; }
    .stars .star-empty  { color: #E2E8F0; }

    /* Review body */
    .review-text {
        background: #F8FAFC;
        padding: 14px 16px;
        border-radius: 8px;
        margin: 12px 0;
        line-height: 1.6;
        color: #475569;
    }

    /* Admin response box */
    .admin-response-box {
        background: #F1F5F9;
        border-left: 3px solid #94A3B8;
        padding: 12px 16px;
        border-radius: 0 8px 8px 0;
        margin: 12px 0;
        font-size: 0.9rem;
        color: #334155;
    }
    .admin-response-box strong {
        color: #0D3B6E;
    }

    /* Dealer link */
    .dealer-link {
        color: #1565C0;
        text-decoration: none;
        font-weight: 600;
    }
    .dealer-link:hover { text-decoration: underline; }

    /* ── Action bar ── */
    .review-actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        align-items: flex-start;
        margin-top: 14px;
        padding-top: 14px;
        border-top: 1px solid #E2E8F0;
    }
    .review-actions form { display: inline-flex; align-items: flex-start; gap: 6px; }

    .btn-sm {
        padding: 6px 14px;
        border-radius: 6px;
        font-weight: 600;
        border: none;
        cursor: pointer;
        font-size: 0.8rem;
        transition: all 0.2s;
    }
    .btn-approve  { background: #10B981; color: #fff; }
    .btn-approve:hover { background: #059669; }
    .btn-pending  { background: #F59E0B; color: #fff; }
    .btn-pending:hover { background: #D97706; }
    .btn-reject   { background: #EF4444; color: #fff; }
    .btn-reject:hover { background: #DC2626; }
    .btn-delete   { background: #7F1D1D; color: #fff; }
    .btn-delete:hover { background: #991B1B; }
    .btn-save     { background: #0D3B6E; color: #fff; }
    .btn-save:hover { background: #1565C0; }

    /* Rejection / response textareas */
    .inline-textarea {
        width: 100%;
        max-width: 400px;
        padding: 8px 10px;
        border: 2px solid #E2E8F0;
        border-radius: 6px;
        font-family: inherit;
        font-size: 0.85rem;
        resize: vertical;
        min-height: 56px;
    }
    .inline-textarea:focus { border-color: #1565C0; outline: none; }

    /* Collapsible sections */
    .toggle-section {
        display: none;
        margin-top: 10px;
    }
    .toggle-section.open { display: block; }
    .toggle-link {
        color: #1565C0;
        cursor: pointer;
        font-size: 0.85rem;
        font-weight: 600;
        background: none;
        border: none;
        padding: 0;
        text-decoration: underline;
    }
    .toggle-link:hover { color: #0D3B6E; }

    /* ── Pagination ── */
    .pagination {
        display: flex;
        justify-content: center;
        gap: 6px;
        margin-top: 30px;
        flex-wrap: wrap;
    }
    .pagination a, .pagination span {
        display: inline-block;
        padding: 8px 14px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.875rem;
        text-decoration: none;
        color: #475569;
        background: #fff;
        border: 1px solid #E2E8F0;
        transition: all 0.2s;
    }
    .pagination a:hover { background: #F1F5F9; border-color: #1565C0; color: #0D3B6E; }
    .pagination .current {
        background: #0D3B6E;
        color: #fff;
        border-color: #0D3B6E;
    }
    .pagination .disabled {
        opacity: 0.4;
        pointer-events: none;
    }

    /* ── Alerts ── */
    .alert {
        padding: 14px 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-weight: 500;
    }
    .alert-success { background: #DCFCE7; color: #166534; border: 2px solid #10B981; }
    .alert-error   { background: #FEE2E2; color: #991B1B; border: 2px solid #EF4444; }

    /* ── Empty state ── */
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #64748B;
    }
    .empty-state-icon { font-size: 4rem; margin-bottom: 16px; }

    /* ── Responsive ── */
    @media (max-width: 640px) {
        .review-header { flex-direction: column; }
        .review-actions { flex-direction: column; }
        .review-actions form { width: 100%; }
        .btn-sm { width: 100%; text-align: center; }
        .filter-tab { padding: 10px 14px; font-size: 0.85rem; }
        .search-bar form { flex-direction: column; }
        .search-bar button { width: 100%; }
        .review-summary { grid-template-columns: repeat(2, 1fr); }
    }
</style>

    <?php if ($success_message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success_message) ?></div>
    <?php endif; ?>
    <?php if ($error_message): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error_message) ?></div>
    <?php endif; ?>

    <!-- Review Type Tabs -->
    <div style="display:flex;gap:8px;margin-bottom:20px;">
        <a href="?type=dealer" style="padding:10px 24px;border-radius:8px;font-weight:700;font-size:0.95rem;text-decoration:none;<?= $review_type === 'dealer' ? 'background:#0D3B6E;color:#fff;' : 'background:#E2E8F0;color:#475569;' ?>">
            Dealer Reviews
        </a>
        <a href="?type=installer" style="padding:10px 24px;border-radius:8px;font-weight:700;font-size:0.95rem;text-decoration:none;<?= $review_type === 'installer' ? 'background:#0D3B6E;color:#fff;' : 'background:#E2E8F0;color:#475569;' ?>">
            Installer Reviews
        </a>
    </div>

    <!-- Summary Stats -->
    <div class="review-summary">
        <div class="summary-card">
            <div class="value"><?= $counts['all'] ?></div>
            <div class="label">Total Reviews</div>
        </div>
        <div class="summary-card">
            <div class="value"><?= $summary_avg ?></div>
            <div class="label">Avg. Approved Rating</div>
        </div>
        <div class="summary-card">
            <div class="value"><?= $counts['approved'] ?></div>
            <div class="label">Approved</div>
        </div>
        <div class="summary-card">
            <div class="value"><?= $counts['pending'] ?></div>
            <div class="label">Pending</div>
        </div>
        <div class="summary-card">
            <div class="value"><?= $counts['rejected'] ?></div>
            <div class="label">Rejected</div>
        </div>
    </div>

    <!-- Filter Tabs -->
    <div class="filter-tabs">
        <a href="?status=all&type=<?= $review_type ?><?= $search ? '&search=' . urlencode($search) : '' ?>"
           class="filter-tab <?= $status_filter === 'all' ? 'active' : '' ?>">
            All <span class="badge"><?= $counts['all'] ?></span>
        </a>
        <a href="?status=approved&type=<?= $review_type ?><?= $search ? '&search=' . urlencode($search) : '' ?>"
           class="filter-tab <?= $status_filter === 'approved' ? 'active' : '' ?>">
            Approved <span class="badge"><?= $counts['approved'] ?></span>
        </a>
        <a href="?status=pending&type=<?= $review_type ?><?= $search ? '&search=' . urlencode($search) : '' ?>"
           class="filter-tab <?= $status_filter === 'pending' ? 'active' : '' ?>">
            Pending <span class="badge"><?= $counts['pending'] ?></span>
        </a>
        <a href="?status=rejected&type=<?= $review_type ?><?= $search ? '&search=' . urlencode($search) : '' ?>"
           class="filter-tab <?= $status_filter === 'rejected' ? 'active' : '' ?>">
            Rejected <span class="badge"><?= $counts['rejected'] ?></span>
        </a>
    </div>

    <!-- Search Bar -->
    <div class="search-bar">
        <form method="GET">
            <input type="hidden" name="status" value="<?= htmlspecialchars($status_filter) ?>">
            <input type="hidden" name="type" value="<?= htmlspecialchars($review_type) ?>">
            <input type="text" name="search" placeholder="Search by <?= $review_type === 'installer' ? 'installer' : 'dealer' ?>, customer, or review text..."
                   value="<?= htmlspecialchars($search) ?>">
            <button type="submit">Search</button>
        </form>
    </div>

    <!-- Reviews List -->
    <?php if (empty($reviews)): ?>
        <div class="empty-state">
            <div class="empty-state-icon">&#9734;</div>
            <h2>No Reviews Found</h2>
            <p>No <?= $status_filter !== 'all' ? htmlspecialchars($status_filter) : '' ?> reviews match your criteria.</p>
        </div>
    <?php else: ?>
        <div class="reviews-grid">
            <?php foreach ($reviews as $review): ?>
                <div class="review-card status-<?= htmlspecialchars($review['status']) ?>">
                    <div class="review-header">
                        <div>
                            <h3><?= htmlspecialchars($review['customer_name'] ?? 'Unknown Customer') ?></h3>
                            <div class="review-meta">
                                <?php if (!empty($review['customer_email'])): ?>
                                    <span><?= htmlspecialchars($review['customer_email']) ?></span>
                                <?php endif; ?>
                                <span>
                                    <?= $review_type === 'installer' ? 'Installer' : 'Dealer' ?>:
                                    <?php
                                    $entity_id_val = $review_type === 'installer' ? ($review['installer_id'] ?? 0) : ($review['dealer_id'] ?? 0);
                                    $entity_link = $review_type === 'installer' ? 'installer-detail.php' : 'dealer-detail.php';
                                    ?>
                                    <?php if ($entity_id_val): ?>
                                        <a class="dealer-link" href="<?= $entity_link ?>?id=<?= (int)$entity_id_val ?>">
                                            <?= htmlspecialchars($review['dealer_name'] ?? 'N/A') ?>
                                        </a>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </span>
                                <?php if (!empty($review['order_number'])): ?>
                                    <span>Order #<?= htmlspecialchars($review['order_number']) ?></span>
                                <?php endif; ?>
                                <span><?= date('M d, Y H:i', strtotime($review['created_at'])) ?></span>
                            </div>
                        </div>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <!-- Stars -->
                            <span class="stars">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <span class="<?= $i <= (int)$review['rating'] ? 'star-filled' : 'star-empty' ?>">&#9733;</span>
                                <?php endfor; ?>
                            </span>
                            <span class="status-badge <?= htmlspecialchars($review['status']) ?>">
                                <?= htmlspecialchars($review['status']) ?>
                            </span>
                        </div>
                    </div>

                    <!-- Review text -->
                    <div class="review-text">
                        <?= nl2br(htmlspecialchars($review['review_text'] ?? '')) ?>
                    </div>

                    <!-- Existing admin response -->
                    <?php if (!empty($review['admin_response'])): ?>
                        <div class="admin-response-box">
                            <strong>Admin Response:</strong><br>
                            <?= nl2br(htmlspecialchars($review['admin_response'])) ?>
                        </div>
                    <?php endif; ?>

                    <!-- Actions -->
                    <div class="review-actions">
                        <?php if ($review['status'] !== 'approved'): ?>
                            <form method="POST">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="approve">
                                <input type="hidden" name="review_id" value="<?= (int)$review['id'] ?>">
                                <input type="hidden" name="review_type" value="<?= $review_type ?>">
                                <button type="submit" class="btn-sm btn-approve">Approve</button>
                            </form>
                        <?php endif; ?>

                        <?php if ($review['status'] !== 'pending'): ?>
                            <form method="POST">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="pending">
                                <input type="hidden" name="review_id" value="<?= (int)$review['id'] ?>">
                                <input type="hidden" name="review_type" value="<?= $review_type ?>">
                                <button type="submit" class="btn-sm btn-pending">Make Pending</button>
                            </form>
                        <?php endif; ?>

                        <?php if ($review['status'] !== 'rejected'): ?>
                            <button type="button" class="btn-sm btn-reject" onclick="toggleSection('reject-<?= (int)$review['id'] ?>')">Reject</button>
                        <?php endif; ?>

                        <button type="button" class="toggle-link" onclick="toggleSection('response-<?= (int)$review['id'] ?>')">
                            <?= empty($review['admin_response']) ? 'Add Response' : 'Edit Response' ?>
                        </button>

                        <form method="POST" onsubmit="return confirm('Permanently delete this review?');" style="margin-left:auto;">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="review_id" value="<?= (int)$review['id'] ?>">
                            <input type="hidden" name="review_type" value="<?= $review_type ?>">
                            <button type="submit" class="btn-sm btn-delete">Delete</button>
                        </form>
                    </div>

                    <!-- Reject section (hidden) -->
                    <div class="toggle-section" id="reject-<?= (int)$review['id'] ?>">
                        <form method="POST" style="display:flex;flex-direction:column;gap:8px;max-width:420px;">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="reject">
                            <input type="hidden" name="review_id" value="<?= (int)$review['id'] ?>">
                            <input type="hidden" name="review_type" value="<?= $review_type ?>">
                            <textarea name="rejection_reason" class="inline-textarea" placeholder="Optional rejection reason..."></textarea>
                            <button type="submit" class="btn-sm btn-reject" style="align-self:flex-start;">Confirm Reject</button>
                        </form>
                    </div>

                    <!-- Admin response section (hidden) -->
                    <div class="toggle-section" id="response-<?= (int)$review['id'] ?>">
                        <form method="POST" style="display:flex;flex-direction:column;gap:8px;max-width:420px;">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="admin_response">
                            <input type="hidden" name="review_id" value="<?= (int)$review['id'] ?>">
                            <input type="hidden" name="review_type" value="<?= $review_type ?>">
                            <textarea name="admin_response" class="inline-textarea" placeholder="Write admin response..."><?= htmlspecialchars($review['admin_response'] ?? '') ?></textarea>
                            <button type="submit" class="btn-sm btn-save" style="align-self:flex-start;">Save Response</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <a href="<?= buildQs(['page' => $page - 1]) ?>" class="<?= $page <= 1 ? 'disabled' : '' ?>">&laquo; Prev</a>
                <?php
                $start = max(1, $page - 3);
                $end = min($total_pages, $page + 3);
                if ($start > 1): ?>
                    <a href="<?= buildQs(['page' => 1]) ?>">1</a>
                    <?php if ($start > 2): ?><span>...</span><?php endif; ?>
                <?php endif;
                for ($i = $start; $i <= $end; $i++): ?>
                    <?php if ($i === $page): ?>
                        <span class="current"><?= $i ?></span>
                    <?php else: ?>
                        <a href="<?= buildQs(['page' => $i]) ?>"><?= $i ?></a>
                    <?php endif; ?>
                <?php endfor;
                if ($end < $total_pages): ?>
                    <?php if ($end < $total_pages - 1): ?><span>...</span><?php endif; ?>
                    <a href="<?= buildQs(['page' => $total_pages]) ?>"><?= $total_pages ?></a>
                <?php endif; ?>
                <a href="<?= buildQs(['page' => $page + 1]) ?>" class="<?= $page >= $total_pages ? 'disabled' : '' ?>">Next &raquo;</a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <script>
        function toggleSection(id) {
            var el = document.getElementById(id);
            if (el) el.classList.toggle('open');
        }
    </script>

<?php include 'includes/footer.php'; ?>
