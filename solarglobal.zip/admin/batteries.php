<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/csrf.php';
require_once '../includes/helpers.php';

$db = getDB();
$message = '';
$error = '';
$showForm = false;
$editData = null;

// AJAX: inline image assign from table row
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_image') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'error' => 'Invalid token']);
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $image_path = trim($_POST['image_path'] ?? '');
    if ($id > 0 && $image_path) {
        $db->prepare("UPDATE batteries SET image_path = ? WHERE id = ?")->execute([$image_path, $id]);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid data']);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid token';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'add' || $action === 'edit') {
            $id = intval($_POST['id'] ?? 0);
            $company_id = intval($_POST['company_id'] ?? 0);
            $model = trim($_POST['model'] ?? '');
            $nominal_voltage = floatval($_POST['nominal_voltage'] ?? 12);
            $capacity_ah = intval($_POST['capacity_ah'] ?? 0);
            $price_unit_usd = floatval($_POST['price_unit_usd'] ?? 0);
            $type = trim($_POST['type'] ?? '');
            $is_bms = isset($_POST['is_bms']) ? 'Yes' : 'No';
            $warranty_years = intval($_POST['warranty_years'] ?? 0);
            $cycle_life = intval($_POST['cycle_life'] ?? 0);
            $depth_of_discharge = floatval($_POST['depth_of_discharge'] ?? 0);
            $charging_current_max = floatval($_POST['charging_current_max'] ?? 0);
            $weight_kg = floatval($_POST['weight_kg'] ?? 0);
            $dimensions = trim($_POST['dimensions'] ?? '');
            $maintenance_free = isset($_POST['maintenance_free']) ? 1 : 0;
            $operating_temp = trim($_POST['operating_temp'] ?? '');
            $communication = trim($_POST['communication'] ?? '');
            $certifications = trim($_POST['certifications'] ?? '');
            $country = trim($_POST['country'] ?? '');
            $notes = trim($_POST['notes'] ?? '');
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            $availability_status = trim($_POST['availability_status'] ?? 'available');

            if (empty($model) || $company_id == 0) {
                $error = 'Model and company required';
            } else {
                $image_path = $_POST['existing_image'] ?? null;
                if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                    $upload_result = handle_image_upload($_FILES['image'], '../uploads/batteries/');
                    if ($upload_result['success']) {
                        $image_path = $upload_result['path'];
                    }
                }

                if (empty($error)) {
                    if ($action === 'add') {
                        $stmt = $db->prepare("INSERT INTO batteries (company_id, model, image_path, nominal_voltage, capacity_ah, price_unit_usd, type, is_bms, warranty_years, cycle_life, depth_of_discharge, charging_current_max, weight_kg, dimensions, maintenance_free, operating_temp, communication, certifications, country, notes, is_active, availability_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$company_id, $model, $image_path, $nominal_voltage, $capacity_ah, $price_unit_usd, $type, $is_bms, $warranty_years, $cycle_life, $depth_of_discharge, $charging_current_max, $weight_kg, $dimensions, $maintenance_free, $operating_temp, $communication, $certifications, $country, $notes, $is_active, $availability_status]);
                        $message = 'Battery added successfully!';
                    } else {
                        $stmt = $db->prepare("UPDATE batteries SET company_id = ?, model = ?, image_path = ?, nominal_voltage = ?, capacity_ah = ?, price_unit_usd = ?, type = ?, is_bms = ?, warranty_years = ?, cycle_life = ?, depth_of_discharge = ?, charging_current_max = ?, weight_kg = ?, dimensions = ?, maintenance_free = ?, operating_temp = ?, communication = ?, certifications = ?, country = ?, notes = ?, is_active = ?, availability_status = ? WHERE id = ?");
                        $stmt->execute([$company_id, $model, $image_path, $nominal_voltage, $capacity_ah, $price_unit_usd, $type, $is_bms, $warranty_years, $cycle_life, $depth_of_discharge, $charging_current_max, $weight_kg, $dimensions, $maintenance_free, $operating_temp, $communication, $certifications, $country, $notes, $is_active, $availability_status, $id]);
                        $message = 'Battery updated successfully!';
                    }
                }
            }
        } elseif ($action === 'delete') {
            $id = intval($_POST['id'] ?? 0);
            $db->prepare("DELETE FROM batteries WHERE id = ?")->execute([$id]);
            $message = 'Battery deleted successfully!';
        } elseif ($action === 'show_add') {
            $showForm = true;
        } elseif ($action === 'show_edit') {
            $showForm = true;
            $id = intval($_POST['id'] ?? 0);
            $stmt = $db->prepare("SELECT * FROM batteries WHERE id = ?");
            $stmt->execute([$id]);
            $editData = $stmt->fetch();
        }
    }
}

// ── Pagination + Filters ──
$search_q   = trim($_GET['search'] ?? '');
$filter_co  = trim($_GET['company_id'] ?? '');
$filter_ty  = trim($_GET['type'] ?? '');
$per_page   = max(10, min(200, (int)($_GET['per_page'] ?? 25)));
$page_num   = max(1, (int)($_GET['page'] ?? 1));
$offset     = ($page_num - 1) * $per_page;

$where  = [];
$params = [];
if ($search_q)  { $where[] = "(b.model LIKE ? OR c.name LIKE ?)"; $params[] = "%$search_q%"; $params[] = "%$search_q%"; }
if ($filter_co) { $where[] = "b.company_id = ?"; $params[] = (int)$filter_co; }
if ($filter_ty) { $where[] = "b.type = ?"; $params[] = $filter_ty; }
$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$cnt = $db->prepare("SELECT COUNT(*) FROM batteries b LEFT JOIN companies c ON b.company_id=c.id $where_sql");
$cnt->execute($params);
$total_bat   = (int)$cnt->fetchColumn();
$total_pages = max(1, ceil($total_bat / $per_page));
$page_num    = min($page_num, $total_pages);

$batStmt = $db->prepare("SELECT b.*, c.name as company_name FROM batteries b LEFT JOIN companies c ON b.company_id = c.id $where_sql ORDER BY b.nominal_voltage, b.capacity_ah DESC LIMIT $per_page OFFSET $offset");
$batStmt->execute($params);
$batteries = $batStmt->fetchAll();

$companies = $db->query("SELECT id, name FROM companies ORDER BY name ASC")->fetchAll();

$pageTitle = "Batteries";
include 'includes/header.php';
?>

<style>
.form-container { background: white; padding: 30px; margin-bottom: 20px; border-radius: 8px; border: 2px solid #3b82f6; }
.form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
@media (max-width: 768px) { .form-grid { grid-template-columns: 1fr; } }
.form-section { margin-top: 20px; margin-bottom: 10px; padding-bottom: 6px; border-bottom: 2px solid #e5e7eb; color: #1e40af; font-size: 1.05rem; font-weight: 600; }
.form-section:first-of-type { margin-top: 0; }
</style>

<?php if ($message): ?>
    <div class="alert alert-success"><?= sanitize($message) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-error"><?= sanitize($error) ?></div>
<?php endif; ?>

<?php if ($showForm): ?>
<div class="form-container">
    <h2><?= $editData ? 'Edit Battery' : 'Add New Battery' ?></h2>
    <form method="POST" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $editData ? 'edit' : 'add' ?>">
        <?php if ($editData): ?>
            <input type="hidden" name="id" value="<?= $editData['id'] ?>">
            <input type="hidden" name="existing_image" id="existing_image" value="<?= $editData['image_path'] ?? '' ?>">
        <?php else: ?>
            <input type="hidden" name="existing_image" id="existing_image" value="">
        <?php endif; ?>

        <!-- Basic Info -->
        <h3 class="form-section">Basic Info</h3>
        <div class="form-grid">
            <div class="form-group">
                <label>Company *</label>
                <select name="company_id" required>
                    <option value="">Select Company</option>
                    <?php foreach ($companies as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($editData['company_id'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= sanitize($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Battery Model *</label>
                <input type="text" name="model" value="<?= sanitize($editData['model'] ?? '') ?>" required>
            </div>

            <div class="form-group">
                <label>Battery Type</label>
                <select name="type">
                    <option value="">Select Type</option>
                    <?php
                    $types = ['lithium', 'lfp', 'lead-acid', 'gel', 'agm', 'Lithium-Ion', 'LiFePO4'];
                    foreach ($types as $t): ?>
                        <option value="<?= $t ?>" <?= ($editData['type'] ?? '') === $t ? 'selected' : '' ?>><?= ucfirst($t) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Nominal Voltage *</label>
                <input type="number" step="0.1" name="nominal_voltage" value="<?= $editData['nominal_voltage'] ?? 12 ?>" required>
                <small>Enter voltage (e.g., 12, 24, 48, 51.2)</small>
            </div>

            <div class="form-group">
                <label>Capacity (Ah) *</label>
                <input type="number" name="capacity_ah" value="<?= $editData['capacity_ah'] ?? '' ?>" required>
            </div>

            <div class="form-group">
                <label>Price (USD) *</label>
                <input type="number" name="price_unit_usd" value="<?= $editData['price_unit_usd'] ?? '' ?>" step="0.01" required>
                <small>Unit price in USD</small>
            </div>
        </div>

        <div class="form-group">
            <label>Product Image</label>
            <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
            <small>Max 2MB. JPG, PNG, or WebP</small>
            <div style="margin-top:8px;">
                <button type="button" class="btn btn-secondary btn-sm" onclick="openImagePicker('existing_image','battery-image-preview','batteries')" style="font-size:13px;">&#128247; Select from Library</button>
            </div>
            <div id="battery-image-preview" style="margin-top:8px;">
                <?php if (!empty($editData['image_path'])): ?>
                    <img src="<?= htmlspecialchars(get_image_url($editData['image_path'])) ?>" style="width:80px;height:80px;object-fit:contain;border:1px solid #ddd;border-radius:4px;">
                    <small style="display:block;color:#666;">Current image</small>
                <?php endif; ?>
            </div>
        </div>

        <!-- Performance -->
        <h3 class="form-section">Performance</h3>
        <div class="form-grid">
            <div class="form-group">
                <label>Cycle Life</label>
                <input type="number" name="cycle_life" value="<?= $editData['cycle_life'] ?? '' ?>" min="0" placeholder="e.g. 3000">
                <small>Number of charge/discharge cycles</small>
            </div>

            <div class="form-group">
                <label>Depth of Discharge (%)</label>
                <input type="number" name="depth_of_discharge" value="<?= $editData['depth_of_discharge'] ?? '' ?>" step="0.01" min="0" max="100" placeholder="e.g. 80">
                <small>Max recommended DoD percentage</small>
            </div>

            <div class="form-group">
                <label>Max Charging Current (A)</label>
                <input type="number" name="charging_current_max" value="<?= $editData['charging_current_max'] ?? '' ?>" step="0.01" min="0" placeholder="e.g. 50">
            </div>
        </div>

        <!-- Physical -->
        <h3 class="form-section">Physical</h3>
        <div class="form-grid">
            <div class="form-group">
                <label>Weight (kg)</label>
                <input type="number" name="weight_kg" value="<?= $editData['weight_kg'] ?? '' ?>" step="0.01" min="0" placeholder="e.g. 25.5">
            </div>

            <div class="form-group">
                <label>Dimensions</label>
                <input type="text" name="dimensions" value="<?= sanitize($editData['dimensions'] ?? '') ?>" placeholder="e.g. 520 x 240 x 220 mm">
            </div>

            <div class="form-group">
                <label>Operating Temperature</label>
                <input type="text" name="operating_temp" value="<?= sanitize($editData['operating_temp'] ?? '') ?>" placeholder="e.g. -20 to 60 C">
            </div>

            <div class="form-group" style="display:flex;align-items:center;gap:8px;padding-top:24px;">
                <label><input type="checkbox" name="maintenance_free" <?= ($editData['maintenance_free'] ?? 0) ? 'checked' : '' ?>> Maintenance Free</label>
            </div>
        </div>

        <!-- Technical -->
        <h3 class="form-section">Technical</h3>
        <div class="form-grid">
            <div class="form-group">
                <label>Communication</label>
                <input type="text" name="communication" value="<?= sanitize($editData['communication'] ?? '') ?>" placeholder="e.g. RS485, CAN, Bluetooth">
            </div>

            <div class="form-group">
                <label>Certifications</label>
                <input type="text" name="certifications" value="<?= sanitize($editData['certifications'] ?? '') ?>" placeholder="e.g. IEC, UL, CE">
            </div>

            <div class="form-group">
                <label>Country of Origin</label>
                <input type="text" name="country" value="<?= sanitize($editData['country'] ?? '') ?>" placeholder="e.g. Pakistan, China">
            </div>
        </div>

        <!-- Warranty -->
        <h3 class="form-section">Warranty & Status</h3>
        <div class="form-grid">
            <div class="form-group">
                <label>Warranty (Years)</label>
                <input type="number" name="warranty_years" value="<?= $editData['warranty_years'] ?? '' ?>" min="0" placeholder="e.g. 5">
            </div>

            <div class="form-group">
                <label>Availability Status *</label>
                <select name="availability_status" required>
                    <option value="available" <?= ($editData['availability_status'] ?? 'available') === 'available' ? 'selected' : '' ?>>✅ Available</option>
                    <option value="upcoming" <?= ($editData['availability_status'] ?? '') === 'upcoming' ? 'selected' : '' ?>>🔜 Upcoming</option>
                    <option value="discontinued" <?= ($editData['availability_status'] ?? '') === 'discontinued' ? 'selected' : '' ?>>❌ Discontinued</option>
                </select>
                <small>Product availability in market</small>
            </div>
        </div>

        <!-- Other -->
        <h3 class="form-section">Other</h3>
        <div class="form-group">
            <label><input type="checkbox" name="is_bms" <?= ($editData['is_bms'] ?? 'No') === 'Yes' ? 'checked' : '' ?>> Has Built-in BMS</label>
        </div>

        <div class="form-group">
            <label><input type="checkbox" name="is_active" <?= ($editData['is_active'] ?? 1) ? 'checked' : '' ?>> Active</label>
        </div>

        <div class="form-group">
            <label>Notes</label>
            <textarea name="notes" rows="3"><?= sanitize($editData['notes'] ?? '') ?></textarea>
        </div>

        <div class="action-buttons">
            <button type="submit" class="btn btn-primary">Save Battery</button>
            <a href="batteries.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php else: ?>
<div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
        <h2 style="margin:0;">All Batteries <span style="font-size:0.85rem;color:#64748b;font-weight:400;">(<?= $total_bat ?> total)</span></h2>
        <form method="POST" style="display:inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="show_add">
            <button type="submit" class="btn btn-primary">+ Add New Battery</button>
        </form>
    </div>

    <!-- Search & Filters -->
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:18px;padding:14px 16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;">
        <input type="text" name="search" value="<?= htmlspecialchars($search_q) ?>" placeholder="Search name or company..." style="flex:1;min-width:180px;padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
        <select name="company_id" style="padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
            <option value="">All Companies</option>
            <?php foreach ($companies as $co): ?>
                <option value="<?= $co['id'] ?>" <?= (string)$filter_co === (string)$co['id'] ? 'selected' : '' ?>><?= sanitize($co['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="type" style="padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
            <option value="">All Types</option>
            <?php foreach (['Lead-Acid','Gel','AGM','Lithium-Ion','LiFePO4','Tubular'] as $t): ?>
                <option value="<?= $t ?>" <?= $filter_ty === $t ? 'selected' : '' ?>><?= $t ?></option>
            <?php endforeach; ?>
        </select>
        <select name="per_page" style="padding:7px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:0.85rem;">
            <?php foreach ([10,25,50,100] as $opt): ?>
                <option value="<?= $opt ?>" <?= $per_page == $opt ? 'selected' : '' ?>><?= $opt ?> per page</option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary btn-sm">Filter</button>
        <?php if ($search_q || $filter_co || $filter_ty): ?>
            <a href="batteries.php" class="btn btn-secondary btn-sm">✕ Clear</a>
        <?php endif; ?>
    </form>

    <div style="overflow-x:auto;">
    <table class="data-table" id="bat-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Company</th>
                <th>Voltage</th>
                <th>Capacity</th>
                <th>Price</th>
                <th>Type</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="bat-tbody">
            <!-- rows loaded via AJAX -->
        </tbody>
    </table>
    </div>

    <!-- count + load more -->
    <div style="margin-top:14px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
        <div id="bat-count" style="font-size:0.85rem;color:#64748b;">Loading&hellip;</div>
        <button type="button" id="bat-load-more" style="display:none;padding:8px 22px;background:#3b82f6;color:#fff;border:none;border-radius:7px;font-size:0.85rem;font-weight:600;cursor:pointer;" onclick="batLoadMore()">Load More</button>
    </div>
</div>
<?php endif; ?>

<?php include 'includes/image_picker_modal.php'; ?>

<script>
/* ── Batteries AJAX Load More ────────────────────────────────────── */
var _bat = {
    page       : 1,
    totalPages : 1,
    total      : 0,
    loaded     : 0,
    loading    : false,
    search     : <?= json_encode($search_q) ?>,
    company_id : <?= json_encode($filter_co) ?>,
    filter     : <?= json_encode($filter_ty) ?>,
    per_page   : <?= (int)$per_page ?>
};

function escHb(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function batRowHtml(b) {
    var img = b.img_url
        ? '<img src="' + b.img_url + '" style="width:60px;height:60px;object-fit:contain;border-radius:4px;border:1px solid #e2e8f0;">'
        : '<span style="color:#cbd5e1;font-size:1.5rem;">\uD83D\uDDBC</span>';

    var pinBtn = b.image_path ? '<a href="battery_pinpoints.php?id=' + b.id + '" class="btn btn-primary btn-sm">Pinpoints</a> ' : '';
    var csrf = document.querySelector('input[name="csrf_token"]') ? document.querySelector('input[name="csrf_token"]').value : '';

    return '<tr>' +
        '<td>' + b.id + '</td>' +
        '<td id="bat-img-' + b.id + '">' + img + '</td>' +
        '<td><strong>' + escHb(b.model) + '</strong></td>' +
        '<td>' + escHb(b.company_name) + '</td>' +
        '<td><span class="badge badge-blue">' + b.nominal_voltage + 'V</span></td>' +
        '<td>' + b.capacity_ah + 'Ah</td>' +
        '<td>' + Number(b.price_unit_usd).toLocaleString(undefined,{maximumFractionDigits:0}) + '</td>' +
        '<td>' + escHb(b.type || '-') + '</td>' +
        '<td>' +
            '<button type="button" class="btn btn-secondary btn-sm" onclick="openInlineImagePicker(' + b.id + ')" title="Assign Image">&#128247;</button> ' +
            '<form method="POST" style="display:inline;"><input type="hidden" name="csrf_token" value="' + csrf + '"><input type="hidden" name="action" value="show_edit"><input type="hidden" name="id" value="' + b.id + '"><button type="submit" class="btn btn-secondary btn-sm">Edit</button></form> ' +
            pinBtn +
            '<form method="POST" style="display:inline;" onsubmit="return confirm(\'Delete?\');"><input type="hidden" name="csrf_token" value="' + csrf + '"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="' + b.id + '"><button type="submit" class="btn btn-danger btn-sm">Delete</button></form>' +
        '</td>' +
    '</tr>';
}

function batFetch(append) {
    if (_bat.loading) return;
    _bat.loading = true;
    var tbody   = document.getElementById('bat-tbody');
    var countEl = document.getElementById('bat-count');
    var loadBtn = document.getElementById('bat-load-more');

    if (!append) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:20px;color:#64748b;">Loading&hellip;</td></tr>';
        _bat.page   = 1;
        _bat.loaded = 0;
        loadBtn.style.display = 'none';
    }

    var url = 'ajax/products_browse.php?type=batteries' +
        '&page=' + _bat.page +
        '&per_page=' + _bat.per_page +
        '&search=' + encodeURIComponent(_bat.search) +
        '&company_id=' + encodeURIComponent(_bat.company_id) +
        '&filter=' + encodeURIComponent(_bat.filter);

    fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(data) {
            _bat.loading = false;
            if (!data.success) { tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#dc2626;">Error loading data</td></tr>'; return; }

            _bat.totalPages = data.total_pages;
            _bat.total      = data.total;

            if (!append) tbody.innerHTML = '';

            if (data.rows.length === 0 && !append) {
                tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:30px;color:#94a3b8;">No batteries found.</td></tr>';
                countEl.textContent = '0 batteries';
                loadBtn.style.display = 'none';
                return;
            }

            data.rows.forEach(function(b) {
                tbody.insertAdjacentHTML('beforeend', batRowHtml(b));
            });

            _bat.loaded += data.rows.length;
            countEl.textContent = 'Showing ' + _bat.loaded + ' of ' + _bat.total + ' batteries';
            loadBtn.style.display = (_bat.page < _bat.totalPages) ? 'inline-block' : 'none';
        })
        .catch(function() { _bat.loading = false; });
}

function batLoadMore() {
    _bat.page++;
    batFetch(true);
}

window.addEventListener('DOMContentLoaded', function() { batFetch(false); });

document.addEventListener('DOMContentLoaded', function() {
    var filterForm = document.querySelector('form[method="GET"]');
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var fd = new FormData(filterForm);
            _bat.search     = fd.get('search') || '';
            _bat.company_id = fd.get('company_id') || '';
            _bat.filter     = fd.get('type') || '';
            _bat.per_page   = parseInt(fd.get('per_page')) || 25;
            batFetch(false);
            history.replaceState(null, '', '?' + new URLSearchParams(Object.fromEntries(fd.entries())).toString());
        });
    }
});

/* ── Inline image picker for batteries ───────────────────────────── */
var _inlinePickerId = null;

function openInlineImagePicker(id) {
    _inlinePickerId = id;
    openImagePicker('_inline_tmp_img', '_inline_tmp_prev', 'batteries');
}

(function() {
    var _interval = setInterval(function() {
        if (window.imgPickerUseSelected) {
            clearInterval(_interval);
            var _origUse = window.imgPickerUseSelected;
            window.imgPickerUseSelected = function() {
                _origUse();
                if (_inlinePickerId) {
                    var rowId = _inlinePickerId;
                    _inlinePickerId = null;
                    var imgPath = document.getElementById('_inline_tmp_img').value;
                    if (!imgPath) { alert('No image selected.'); return; }
                    var fd = new FormData();
                    fd.append('action', 'update_image');
                    fd.append('id', rowId);
                    fd.append('image_path', imgPath);
                    fd.append('csrf_token', '<?= generate_csrf_token() ?>');
                    fetch('batteries.php', { method: 'POST', body: fd })
                        .then(function(r) { return r.json(); })
                        .then(function(d) {
                            if (d.success) { location.reload(); }
                            else { alert(d.error || 'Failed to update image.'); }
                        })
                        .catch(function() { alert('Network error. Please try again.'); });
                }
            };
        }
    }, 100);
})();
</script>
<input type="hidden" id="_inline_tmp_img" value="">
<div id="_inline_tmp_prev" style="display:none;"></div>

<?php include 'includes/footer.php'; ?>

