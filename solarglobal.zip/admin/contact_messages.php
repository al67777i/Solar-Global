<?php
/**
 * Admin Contact Messages Viewer
 * View and manage contact form submissions
 */
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once '../includes/csrf.php';

$success_message = '';
$error_message = '';

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid request. Please try again.';
    } else
    if ($_POST['action'] === 'update_status') {
        $message_id = (int)$_POST['message_id'];
        $status = sanitize($_POST['status']);
        
        try {
            $stmt = $pdo->prepare("UPDATE contact_messages SET status = ? WHERE id = ?");
            $stmt->execute([$status, $message_id]);
            $success_message = 'Status updated successfully!';
        } catch (Exception $e) {
            $error_message = 'Error updating status: ' . $e->getMessage();
        }
    } elseif ($_POST['action'] === 'delete_message') {
        $message_id = (int)$_POST['message_id'];
        
        try {
            $stmt = $pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
            $stmt->execute([$message_id]);
            $success_message = 'Message deleted successfully!';
        } catch (Exception $e) {
            $error_message = 'Error deleting message: ' . $e->getMessage();
        }
    }
}

// Get filter
$filter = $_GET['filter'] ?? 'all';
$where = '';
if ($filter === 'new') {
    $where = "WHERE status = 'new'";
} elseif ($filter === 'read') {
    $where = "WHERE status = 'read'";
} elseif ($filter === 'replied') {
    $where = "WHERE status = 'replied'";
}

// Get messages
$messages = [];
try {
    $stmt = $pdo->query("
        SELECT * FROM contact_messages 
        $where
        ORDER BY created_at DESC
    ");
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error_message = 'Error loading messages: ' . $e->getMessage();
}

// Get counts
$counts = ['all' => 0, 'new' => 0, 'read' => 0, 'replied' => 0];
try {
    $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM contact_messages GROUP BY status");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $counts[$row['status']] = $row['count'];
        $counts['all'] += $row['count'];
    }
} catch (Exception $e) {
    // Silently fail
}
$pageTitle = "Contact Messages";
include 'includes/header.php';
?>
    <style>
        .filter-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            border-bottom: 2px solid #E2E8F0;
        }
        
        .filter-tab {
            padding: 12px 24px;
            background: none;
            border: none;
            border-bottom: 3px solid transparent;
            cursor: pointer;
            font-weight: 600;
            color: #64748B;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .filter-tab:hover {
            color: #0D3B6E;
        }
        
        .filter-tab.active {
            color: #0D3B6E;
            border-bottom-color: #0D3B6E;
        }
        
        .filter-tab .badge {
            display: inline-block;
            background: #E2E8F0;
            color: #475569;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            margin-left: 8px;
        }
        
        .filter-tab.active .badge {
            background: #0D3B6E;
            color: white;
        }
        
        .messages-grid {
            display: grid;
            gap: 20px;
        }
        
        .message-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            border-left: 4px solid #E2E8F0;
        }
        
        .message-card.new {
            border-left-color: #10B981;
            background: #F0FDF4;
        }
        
        .message-card.read {
            border-left-color: #3B82F6;
        }
        
        .message-card.replied {
            border-left-color: #8B5CF6;
        }
        
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
        }
        
        .message-info h3 {
            font-size: 1.25rem;
            color: #0D3B6E;
            margin: 0 0 5px 0;
        }
        
        .message-meta {
            font-size: 0.875rem;
            color: #64748B;
        }
        
        .message-meta span {
            margin-right: 15px;
        }
        
        .status-badge {
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .status-badge.new {
            background: #D1FAE5;
            color: #065F46;
        }
        
        .status-badge.read {
            background: #DBEAFE;
            color: #1E40AF;
        }
        
        .status-badge.replied {
            background: #EDE9FE;
            color: #5B21B6;
        }
        
        .message-subject {
            font-size: 1rem;
            color: #475569;
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        .message-body {
            background: #F8FAFC;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            line-height: 1.6;
            color: #475569;
        }
        
        .message-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 8px 16px;
            border-radius: 6px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            font-size: 0.875rem;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary {
            background: #0D3B6E;
            color: white;
        }
        
        .btn-primary:hover {
            background: #1565C0;
        }
        
        .btn-success {
            background: #10B981;
            color: white;
        }
        
        .btn-success:hover {
            background: #059669;
        }
        
        .btn-danger {
            background: #EF4444;
            color: white;
        }
        
        .btn-danger:hover {
            background: #DC2626;
        }
        
        .btn-whatsapp {
            background: #25D366;
            color: white;
        }
        
        .btn-whatsapp:hover {
            background: #20BA5A;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #64748B;
        }
        
        .empty-state-icon {
            font-size: 4rem;
            margin-bottom: 20px;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #D1FAE5;
            color: #065F46;
            border: 2px solid #10B981;
        }
        
        .alert-error {
            background: #FEE2E2;
            color: #991B1B;
            border: 2px solid #EF4444;
        }
    </style>

    <div class="admin-content">
        <div class="admin-header">
            <h1>📧 Contact Messages</h1>
            <p>View and manage customer inquiries</p>
        </div>
        
        <?php if ($success_message): ?>
            <div class="alert alert-success">✓ <?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
            <div class="alert alert-error">✗ <?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <!-- Filter Tabs -->
        <div class="filter-tabs">
            <a href="?filter=all" class="filter-tab <?php echo $filter === 'all' ? 'active' : ''; ?>">
                All Messages
                <span class="badge"><?php echo $counts['all']; ?></span>
            </a>
            <a href="?filter=new" class="filter-tab <?php echo $filter === 'new' ? 'active' : ''; ?>">
                New
                <span class="badge"><?php echo $counts['new']; ?></span>
            </a>
            <a href="?filter=read" class="filter-tab <?php echo $filter === 'read' ? 'active' : ''; ?>">
                Read
                <span class="badge"><?php echo $counts['read']; ?></span>
            </a>
            <a href="?filter=replied" class="filter-tab <?php echo $filter === 'replied' ? 'active' : ''; ?>">
                Replied
                <span class="badge"><?php echo $counts['replied']; ?></span>
            </a>
        </div>
        
        <!-- Messages Grid -->
        <?php if (empty($messages)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">📭</div>
                <h2>No Messages Found</h2>
                <p>You don't have any <?php echo $filter === 'all' ? '' : $filter; ?> messages yet.</p>
            </div>
        <?php else: ?>
            <div class="messages-grid">
                <?php foreach ($messages as $message): ?>
                    <div class="message-card <?php echo $message['status']; ?>">
                        <div class="message-header">
                            <div class="message-info">
                                <h3><?php echo htmlspecialchars($message['name']); ?></h3>
                                <div class="message-meta">
                                    <span>📧 <?php echo htmlspecialchars($message['email']); ?></span>
                                    <?php if ($message['phone']): ?>
                                        <span>📞 <?php echo htmlspecialchars($message['phone']); ?></span>
                                    <?php endif; ?>
                                    <span>🕒 <?php echo date('M d, Y H:i', strtotime($message['created_at'])); ?></span>
                                </div>
                            </div>
                            <span class="status-badge <?php echo $message['status']; ?>">
                                <?php echo $message['status']; ?>
                            </span>
                        </div>
                        
                        <?php if ($message['subject']): ?>
                            <div class="message-subject">
                                📋 Subject: <?php echo htmlspecialchars($message['subject']); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="message-body">
                            <?php echo nl2br(htmlspecialchars($message['message'])); ?>
                        </div>
                        
                        <div class="message-actions">
                            <!-- Email Reply -->
                            <a href="mailto:<?php echo htmlspecialchars($message['email']); ?>" 
                               class="btn btn-primary">
                                📧 Reply via Email
                            </a>
                            
                            <!-- WhatsApp Reply -->
                            <?php if ($message['phone']): ?>
                                <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $message['phone']); ?>" 
                                   target="_blank"
                                   class="btn btn-whatsapp">
                                    💬 Reply via WhatsApp
                                </a>
                            <?php endif; ?>
                            
                            <!-- Mark as Read -->
                            <?php if ($message['status'] === 'new'): ?>
                                <form method="POST" style="display: inline;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                                    <input type="hidden" name="status" value="read">
                                    <button type="submit" class="btn btn-primary">Mark as Read</button>
                                </form>
                            <?php endif; ?>
                            
                            <!-- Mark as Replied -->
                            <?php if ($message['status'] !== 'replied'): ?>
                                <form method="POST" style="display: inline;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                                    <input type="hidden" name="status" value="replied">
                                    <button type="submit" class="btn btn-success">Mark as Replied</button>
                                </form>
                            <?php endif; ?>
                            
                            <!-- Delete -->
                            <form method="POST" style="display: inline;"
                                  onsubmit="return confirm('Are you sure you want to delete this message?');">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete_message">
                                <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                                <button type="submit" class="btn btn-danger">🗑️ Delete</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    </div>
<?php include 'includes/footer.php'; ?>
