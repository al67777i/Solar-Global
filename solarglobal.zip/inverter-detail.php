<?php
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/location_helper.php';
require_once 'includes/subscription_helpers.php';
set_security_headers();

// Track visitor
trackVisitor($pdo);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: inverters.php');
    exit;
}

// Get inverter details
$stmt = $pdo->prepare("
    SELECT i.*, c.name as company_name, c.country, c.description as company_description,
           c.logo_path as company_logo, c.website as company_website
    FROM inverters i
    JOIN companies c ON i.company_id = c.id
    WHERE i.id = ? AND i.is_active = 1
");
$stmt->execute([$id]);
$inverter = $stmt->fetch();

if (!$inverter) {
    header('Location: inverters.php');
    exit;
}

// ═══ COUNTRY FLAG ════════════════════════════════════════════════════
$origin_country = $inverter['country'] ?: $inverter['country'];
$flag_emoji = '';
if ($origin_country) {
    $flagStmt = $pdo->prepare("
        SELECT flag_emoji, flag_icon, code FROM countries
        WHERE LOWER(name COLLATE utf8mb4_general_ci) = LOWER(?)
           OR LOWER(code COLLATE utf8mb4_general_ci) = LOWER(?)
        LIMIT 1
    ");
    $flagStmt->execute([$origin_country, $origin_country]);
    $flagRow = $flagStmt->fetch();
    if ($flagRow) $flag_emoji = $flagRow['flag_emoji'] ?? '';
}

// ═══ USER CURRENCY ═══════════════════════════════════════════════════
$loc = json_decode($_COOKIE['sg_location'] ?? '{}', true);
$user_cc = get_user_country_code();
$currency_info   = get_country_currency_info($user_cc);
$currency_symbol = $currency_info['currency_symbol'];
$currency_code   = $currency_info['currency_code'];
$exchange_rate   = max(0.001, $currency_info['exchange_rate']);

function toLocalInv($usd, $rate) { return round($usd * $rate, 0); }
function formatLocalInv($usd, $rate, $symbol) { return $symbol . number_format(toLocalInv($usd, $rate)); }

$site_name = get_system_setting('site_name', 'SolarGlobal');
$page_title = $inverter['model'] . " - " . $inverter['company_name'] . " | " . $site_name;
$page_description = $inverter['model'] . " - " . $inverter['output_power_w'] . "W " . $inverter['type'] . " inverter. Price: " . formatLocalInv($inverter['unit_price_usd'], $exchange_rate, $currency_symbol) . ". Efficiency: " . $inverter['max_efficiency'] . ".";
$page_keywords = $inverter['model'] . ", " . $inverter['company_name'] . " inverter, " . $inverter['type'] . " inverter, solar inverter";
$current_page = 'inverters';
$page_og_type = 'product';

// ═══ WHERE TO BUY — nearby dealers ═══════════════════════════════════
$dealers = [];
$user_lat = $loc['lat'] ?? null;
$user_lng = $loc['lng'] ?? null;
$dealer_filter = get_dealer_subscription_filter('d');

if ($user_lat && $user_lng) {
    $haversine = haversine_sql('d.latitude', 'd.longitude');
    $dStmt = $pdo->prepare("
        SELECT d.id, d.business_name, d.city, d.country_code,
               dp.dealer_price, dp.stock_quantity,
               {$haversine} AS distance_km
        FROM dealer_products dp
        JOIN dealers d ON dp.dealer_id = d.id
        WHERE dp.product_type = 'inverter' AND dp.product_id = ? AND dp.is_active = 1
          AND d.latitude IS NOT NULL AND d.longitude IS NOT NULL
          AND {$dealer_filter}
        ORDER BY distance_km ASC
        LIMIT 10
    ");
    $dStmt->execute([$user_lat, $user_lng, $user_lat, $id]);
    $dealers = $dStmt->fetchAll(PDO::FETCH_ASSOC);
}

// Country-based fallback when no coordinates available
if (empty($dealers) && !empty($user_cc)) {
    $dStmt = $pdo->prepare("
        SELECT d.id, d.business_name, d.city, d.country_code,
               dp.dealer_price, dp.stock_quantity,
               NULL AS distance_km
        FROM dealer_products dp
        JOIN dealers d ON dp.dealer_id = d.id
        WHERE dp.product_type = 'inverter' AND dp.product_id = ? AND dp.is_active = 1
          AND d.country_code = ?
          AND {$dealer_filter}
        ORDER BY dp.dealer_price ASC
        LIMIT 10
    ");
    $dStmt->execute([$id, $user_cc]);
    $dealers = $dStmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get similar inverters
$stmt = $pdo->prepare("
    SELECT i.*, c.name as company_name
    FROM inverters i
    JOIN companies c ON i.company_id = c.id
    WHERE i.id != ?
    AND i.type = ?
    AND i.output_power_w BETWEEN ? AND ?
    AND i.is_active = 1
    ORDER BY ABS(i.unit_price_usd - ?) ASC
    LIMIT 4
");
$stmt->execute([
    $id,
    $inverter['type'],
    $inverter['output_power_w'] * 0.7,
    $inverter['output_power_w'] * 1.3,
    $inverter['unit_price_usd']
]);
$similar = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0D3B6E">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="mobile-web-app-capable" content="yes">
    <title><?php echo $page_title; ?></title>

    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo $page_description; ?>">
    <meta name="keywords" content="<?php echo $page_keywords; ?>">
    <meta name="author" content="<?= htmlspecialchars($site_name) ?>">
    <meta name="robots" content="index, follow">

    <!-- Open Graph -->
    <meta property="og:title" content="<?php echo $page_title; ?>">
    <meta property="og:description" content="<?php echo $page_description; ?>">
    <meta property="og:url" content="<?php echo getCurrentUrl(); ?>">
    <meta property="og:type" content="product">
    
    <!-- Canonical URL -->
    <link rel="canonical" href="<?php echo getCurrentUrl(); ?>">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/frontend.css">
    <link rel="stylesheet" href="assets/css/products.css">
    <link rel="stylesheet" href="assets/css/mobile-app.css">
</head>
<body>
    <?php include 'includes/header-nav.php'; ?>
    <?php include_once 'includes/ad_display.php'; ?>

    <?php renderAds('header'); ?>

    <!-- Breadcrumb -->
    <div class="breadcrumb">
        <div class="container">
            <a href="index.php">Home</a> / 
            <a href="inverters.php">Inverters</a> / 
            <span><?php echo htmlspecialchars($inverter['model']); ?></span>
        </div>
    </div>
    
    <!-- Product Detail -->
    <div class="product-detail-container">
        <div class="product-detail-grid">
            <!-- Product Image -->
            <div class="product-detail-image">
                <?php 
                $main_img_url = !empty($inverter['image_path']) ? get_image_url($inverter['image_path']) : '';
                if ($main_img_url): ?>
                <div class="img-zoom-wrapper" id="imgZoomWrapper">
                    <img src="<?= htmlspecialchars($main_img_url) ?>"
                         alt="<?= htmlspecialchars($inverter['model']) ?>"
                         id="mainProductImage"
                         class="product-main-img"
                         draggable="false">
                    <!-- Floating zoom box that appears ON the image next to cursor -->
                    <div class="img-zoom-float" id="imgZoomFloat"
                         style="background-image:url('<?= htmlspecialchars($main_img_url) ?>')"></div>
                </div>
                <p class="zoom-hint">🔍 Hover over image to zoom</p>
                <?php else: ?>
                <div class="product-detail-image-placeholder">
                    <span class="product-icon">⚡</span>
                    <p style="margin:12px 0 0;color:#94A3B8;font-size:0.9rem;">No image available</p>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Product Info -->
            <div class="product-detail-info">
                <div class="product-badge <?php echo strtolower($inverter['type']); ?>">
                    <?php echo $inverter['type']; ?>
                </div>
                
                <div class="product-detail-company">
                    <?php if ($flagRow || $flag_emoji): ?><span style="font-size:1.2em;margin-right:4px;"><?= get_country_flag($flagRow ?? $inverter['country_origin'], 20) ?></span><?php endif; ?>
                    <?php echo htmlspecialchars($inverter['company_name']); ?>
                    (<?php echo htmlspecialchars($origin_country); ?>)
                </div>

                <h1><?php echo htmlspecialchars($inverter['model']); ?></h1>

                <div class="product-detail-price">
                    <?= formatLocalInv($inverter['unit_price_usd'], $exchange_rate, $currency_symbol) ?>
                    <?php if ($currency_code !== 'USD'): ?>
                        <span style="font-size:0.7em;color:#94A3B8;margin-left:8px;">~$<?= number_format($inverter['unit_price_usd']) ?> USD</span>
                    <?php endif; ?>
                </div>
                
                <div class="product-detail-specs">
                    <div class="detail-spec-item">
                        <div class="detail-spec-label">Power Capacity</div>
                        <div class="detail-spec-value"><?php echo number_format($inverter['output_power_w']); ?>W</div>
                    </div>
                    <div class="detail-spec-item">
                        <div class="detail-spec-label">Voltage Class</div>
                        <div class="detail-spec-value"><?php echo $inverter['battery_voltage_range']; ?></div>
                    </div>
                    <div class="detail-spec-item">
                        <div class="detail-spec-label">Efficiency</div>
                        <div class="detail-spec-value"><?php echo $inverter['max_efficiency']; ?></div>
                    </div>
                    <div class="detail-spec-item">
                        <div class="detail-spec-label">Warranty</div>
                        <div class="detail-spec-value"><?php echo $inverter['warranty_years']; ?> Years</div>
                    </div>
                </div>
                
                <div class="product-detail-actions">
                    <a href="contact.php" class="btn btn-primary">
                        📞 Contact for Quote
                    </a>
                    <button type="button" class="btn btn-success" onclick="addToCompare(<?php echo $inverter['id']; ?>, 'inverter', '<?php echo htmlspecialchars(addslashes($inverter['model'])); ?>'); return false;">
                        📊 Add to Compare
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Product Tabs -->
        <div class="product-tabs">
            <div class="tab-buttons">
                <button type="button" class="tab-btn active" onclick="switchTab('specifications')">Specifications</button>
                <button type="button" class="tab-btn" onclick="switchTab('features')">Features</button>
                <button type="button" class="tab-btn" onclick="switchTab('dealers')">Where to Buy<?php if (!empty($dealers)): ?> <span style="background:#F59E0B;color:#fff;border-radius:20px;padding:1px 7px;font-size:0.7rem;margin-left:4px;"><?= count($dealers) ?></span><?php endif; ?></button>
                <button type="button" class="tab-btn" onclick="switchTab('company')">About Brand</button>
            </div>
            
            <!-- Specifications Tab -->
            <div id="specifications" class="tab-content active">
                <div class="specs-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Specification</th>
                                <th>Value</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>Model Name</strong></td>
                                <td><?php echo htmlspecialchars($inverter['model']); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Brand</strong></td>
                                <td><?php echo htmlspecialchars($inverter['company_name']); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Type</strong></td>
                                <td><?php echo $inverter['type']; ?></td>
                            </tr>
                            <tr>
                                <td><strong>Max Load Capacity</strong></td>
                                <td><?php echo number_format($inverter['output_power_w']); ?> Watts</td>
                            </tr>
                            <tr>
                                <td><strong>Voltage Class</strong></td>
                                <td><?php echo $inverter['battery_voltage_range']; ?></td>
                            </tr>
                            <tr>
                                <td><strong>Efficiency</strong></td>
                                <td><?php echo $inverter['max_efficiency']; ?></td>
                            </tr>
                            <?php if ($inverter['ip_rating']): ?>
                            <tr>
                                <td><strong>IP Rating</strong></td>
                                <td><?php echo $inverter['ip_rating']; ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if ($inverter['min_pv_voltage'] && $inverter['max_pv_voltage']): ?>
                            <tr>
                                <td><strong>Input Voltage Range</strong></td>
                                <td><?php echo $inverter['min_pv_voltage']; ?>V - <?php echo $inverter['max_pv_voltage']; ?>V DC</td>
                            </tr>
                            <?php endif; ?>
                            <?php if ($inverter['mppt_count']): ?>
                            <tr>
                                <td><strong>MPPT Trackers</strong></td>
                                <td><?php echo $inverter['mppt_count']; ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td><strong>Output Voltage</strong></td>
                                <td><?php echo $inverter['output_voltage']; ?>V AC</td>
                            </tr>
                            <tr>
                                <td><strong>Output Frequency</strong></td>
                                <td><?php echo $inverter['output_frequency']; ?> Hz</td>
                            </tr>
                            <?php if ($inverter['surge_power_w']): ?>
                            <tr>
                                <td><strong>Surge Power</strong></td>
                                <td><?php echo number_format($inverter['surge_power_w']); ?> Watts</td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td><strong>Warranty</strong></td>
                                <td><?php echo $inverter['warranty_years']; ?> Years</td>
                            </tr>
                            <?php if ($inverter['weight_kg']): ?>
                            <tr>
                                <td><strong>Weight</strong></td>
                                <td><?php echo $inverter['weight_kg']; ?> kg</td>
                            </tr>
                            <?php endif; ?>
                            <?php if ($inverter['dimensions']): ?>
                            <tr>
                                <td><strong>Dimensions</strong></td>
                                <td><?php echo $inverter['dimensions']; ?> mm</td>
                            </tr>
                            <?php endif; ?>
                            <?php if ($inverter['cooling_method']): ?>
                            <tr>
                                <td><strong>Cooling Method</strong></td>
                                <td><?php echo $inverter['cooling_method']; ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if ($inverter['display_type']): ?>
                            <tr>
                                <td><strong>Display</strong></td>
                                <td><?php echo $inverter['display_type']; ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if ($inverter['communication']): ?>
                            <tr>
                                <td><strong>Communication</strong></td>
                                <td><?php echo $inverter['communication']; ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if ($inverter['certifications']): ?>
                            <tr>
                                <td><strong>Certifications</strong></td>
                                <td><?php echo $inverter['certifications']; ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if ($inverter['country']): ?>
                            <tr>
                                <td><strong>Country of Origin</strong></td>
                                <td><?php echo $inverter['country']; ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if (!empty($inverter['supports_parallel']) && $inverter['supports_parallel'] === 'Yes'): ?>
                            <tr>
                                <td><strong>Parallel Operation</strong></td>
                                <td>
                                    <span style="color: #10B981; font-weight: 600;">✓ Up to <?php echo $inverter['max_parallel_units']; ?> units</span>
                                    <?php if ($inverter['max_parallel_units'] > 1): ?>
                                        <br><small style="color:#6B7280;">Max system: <?php echo number_format($inverter['output_power_w'] * $inverter['max_parallel_units']); ?>W (<?php echo $inverter['max_parallel_units']; ?> × <?php echo number_format($inverter['output_power_w']); ?>W)</small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td><strong>Price</strong></td>
                                <td>
                                    <strong style="color: #10B981; font-size: 1.25rem;"><?= formatLocalInv($inverter['unit_price_usd'], $exchange_rate, $currency_symbol) ?></strong>
                                    <?php if ($currency_code !== 'USD'): ?>
                                        <span style="font-size:0.85rem;color:#94A3B8;margin-left:6px;">~$<?= number_format($inverter['unit_price_usd']) ?> USD</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Features Tab -->
            <div id="features" class="tab-content">
                <div class="features-content">
                    <h3>Key Features</h3>
                    <ul class="features-list">
                        <li>✓ <?php echo $inverter['type']; ?> inverter technology</li>
                        <li>✓ <?php echo number_format($inverter['output_power_w']); ?>W continuous power output</li>
                        <li>✓ <?php echo $inverter['max_efficiency']; ?> conversion efficiency</li>
                        <?php if ($inverter['surge_power_w']): ?>
                        <li>✓ <?php echo number_format($inverter['surge_power_w']); ?>W surge power capacity</li>
                        <?php endif; ?>
                        <?php if ($inverter['mppt_count']): ?>
                        <li>✓ <?php echo $inverter['mppt_count']; ?> MPPT tracker<?php echo $inverter['mppt_count'] > 1 ? 's' : ''; ?> for optimal solar harvesting</li>
                        <?php endif; ?>
                        <?php if (!empty($inverter['supports_parallel']) && $inverter['supports_parallel'] === 'Yes'): ?>
                        <li>✓ Parallel operation: up to <?php echo $inverter['max_parallel_units']; ?> units (max <?php echo number_format($inverter['output_power_w'] * $inverter['max_parallel_units']); ?>W system)</li>
                        <?php endif; ?>
                        <?php if ($inverter['ip_rating']): ?>
                        <li>✓ <?php echo $inverter['ip_rating']; ?> protection rating</li>
                        <?php endif; ?>
                        <li>✓ <?php echo $inverter['warranty_years']; ?> year manufacturer warranty</li>
                        <?php if ($inverter['display_type']): ?>
                        <li>✓ <?php echo $inverter['display_type']; ?> display for monitoring</li>
                        <?php endif; ?>
                        <?php if ($inverter['communication']): ?>
                        <li>✓ <?php echo $inverter['communication']; ?> connectivity</li>
                        <?php endif; ?>
                        <?php if ($inverter['certifications']): ?>
                        <li>✓ Certified: <?php echo $inverter['certifications']; ?></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
            <!-- Where to Buy Tab -->
            <div id="dealers" class="tab-content">
                <div class="dealers-content">
                    <h3 style="font-size:1.2rem;font-weight:700;color:#0D3B6E;margin:0 0 6px;">Where to Buy</h3>
                    <p style="color:#64748B;font-size:0.9rem;margin:0 0 24px;">Dealers near you that stock this inverter</p>

                    <?php if (!empty($dealers)): ?>
                        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;">
                            <?php foreach ($dealers as $dlr):
                                $dist = round($dlr['distance_km'], 1);
                                $dlr_price = $dlr['dealer_price'] ? formatLocalInv($dlr['dealer_price'], $exchange_rate, $currency_symbol) : '';
                                $dlr_flag = '';
                                if ($dlr['country_code']) {
                                    $dfStmt = $pdo->prepare("SELECT flag_emoji, flag_icon, code FROM countries WHERE code = ? LIMIT 1");
                                    $dfStmt->execute([$dlr['country_code']]);
                                    $dfRow = $dfStmt->fetch();
                                    if ($dfRow) $dlr_flag = get_country_flag($dfRow, 18);
                                }
                            ?>
                            <div style="background:#fff;border:1px solid #E2E8F0;border-radius:12px;padding:20px;transition:all 0.2s;">
                                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                                    <div>
                                        <div style="font-weight:700;color:#1E293B;font-size:1rem;">
                                            <?= $dlr_flag ? $dlr_flag . ' ' : '' ?><?= htmlspecialchars($dlr['business_name']) ?>
                                        </div>
                                        <div style="font-size:0.82rem;color:#64748B;"><?= htmlspecialchars($dlr['city'] ?? '') ?></div>
                                    </div>
                                    <span style="background:#FEF3C7;color:#92400E;padding:4px 10px;border-radius:20px;font-size:0.78rem;font-weight:700;white-space:nowrap;">
                                        📍 <?= $dist ?> km
                                    </span>
                                </div>
                                <?php if ($dlr_price): ?>
                                <div style="font-size:1.1rem;font-weight:800;color:#F59E0B;margin-bottom:12px;"><?= $dlr_price ?></div>
                                <?php endif; ?>
                                <a href="<?= BASE_URL ?>store-detail.php?id=<?= (int)$dlr['id'] ?>" style="display:inline-flex;align-items:center;gap:6px;padding:8px 18px;background:linear-gradient(135deg,#F59E0B,#D97706);color:#fff;border-radius:8px;font-size:0.85rem;font-weight:600;text-decoration:none;">
                                    Visit Store →
                                </a>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php elseif ($user_lat && $user_lng): ?>
                        <div style="text-align:center;padding:40px 20px;">
                            <div style="font-size:2.5rem;margin-bottom:12px;">🏪</div>
                            <p style="color:#64748B;font-size:0.95rem;">No dealers currently stock this inverter in your area.</p>
                            <a href="<?= BASE_URL ?>stores.php" style="display:inline-block;margin-top:12px;padding:8px 20px;background:#F59E0B;color:#fff;border-radius:8px;font-weight:600;text-decoration:none;font-size:0.88rem;">Browse All Stores</a>
                        </div>
                    <?php else: ?>
                        <div style="text-align:center;padding:40px 20px;">
                            <div style="font-size:2.5rem;margin-bottom:12px;">📍</div>
                            <p style="color:#64748B;font-size:0.95rem;">Enable location services to find nearby dealers with this product.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Company Tab -->
            <div id="company" class="tab-content">
                <div class="company-content">
                    <h3>About <?php echo htmlspecialchars($inverter['company_name']); ?></h3>
                    <p><strong>Country:</strong> <?php echo $inverter['country']; ?></p>
                    <?php if ($inverter['company_description']): ?>
                    <p><?php echo htmlspecialchars($inverter['company_description']); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Similar Products -->
        <?php if (!empty($similar)): ?>
        <div class="similar-products">
            <h2>Similar Inverters</h2>
            <div class="products-grid">
                <?php foreach ($similar as $item): ?>
                    <div class="product-card">
                        <div class="product-badge <?php echo strtolower($item['type']); ?>">
                            <?php echo $item['type']; ?>
                        </div>
                        
                        <?php $sim_img = !empty($item['image_path']) ? get_image_url($item['image_path']) : ''; ?>
                        <div class="product-image-placeholder">
                            <?php if ($sim_img): ?>
                                <img src="<?= htmlspecialchars($sim_img) ?>" alt="<?= htmlspecialchars($item['model']) ?>" style="width:100%;height:100%;object-fit:contain;padding:10px;" loading="lazy">
                            <?php else: ?>
                                <span class="product-icon">⚡</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="product-company"><?php echo htmlspecialchars($item['company_name']); ?></div>
                        <h3 class="product-name"><?php echo htmlspecialchars($item['model']); ?></h3>
                        
                        <div class="product-specs">
                            <div class="spec-item">
                                <span class="spec-label">Power</span>
                                <span class="spec-value"><?php echo number_format($item['output_power_w']); ?>W</span>
                            </div>
                            <div class="spec-item">
                                <span class="spec-label">Efficiency</span>
                                <span class="spec-value"><?php echo $item['max_efficiency']; ?></span>
                            </div>
                        </div>
                        
                        <div class="product-price">
                            <?= formatLocalInv($item['unit_price_usd'], $exchange_rate, $currency_symbol) ?>
                        </div>
                        
                        <div class="product-actions">
                            <a href="inverter-detail.php?id=<?php echo $item['id']; ?>" class="btn btn-primary btn-sm">
                                View Details
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <?php renderAds('footer'); ?>

    <?php include 'includes/footer.php'; ?>
    
    <script src="assets/js/products.js"></script>
    
    <!-- Schema.org Product Data -->
    <?php $baseUrl = 'https://' . ($_SERVER['HTTP_HOST'] ?? (get_system_setting('site_domain', 'solarglobal.com') ?: 'solarglobal.com')) . BASE_URL; ?>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": "<?php echo htmlspecialchars($inverter['name']); ?>",
        "url": "<?= htmlspecialchars($baseUrl . 'inverter-detail.php?id=' . (int)$inverter['id']) ?>",
        "brand": {
            "@type": "Brand",
            "name": "<?php echo htmlspecialchars($inverter['company_name']); ?>"
        },
        "description": "<?php echo $page_description; ?>",
        "offers": {
            "@type": "Offer",
            "price": "<?= toLocalInv($inverter['price_usd'], $exchange_rate) ?>",
            "priceCurrency": "<?= htmlspecialchars($currency_code) ?>",
            "availability": "https://schema.org/InStock"
        }
    }
    </script>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "Home", "item": "<?= $baseUrl ?>"},
            {"@type": "ListItem", "position": 2, "name": "Inverters", "item": "<?= $baseUrl ?>inverters.php"},
            {"@type": "ListItem", "position": 3, "name": "<?= sanitize($inverter['name']) ?>"}
        ]
    }
    </script>
    
    <style>
        /* ── Breadcrumb ── */
        .breadcrumb { background:#F8FAFC; padding:15px 0; font-size:.9375rem; }
        .breadcrumb a { color:#1565C0; text-decoration:none; }
        .breadcrumb a:hover { text-decoration:underline; }
        .breadcrumb span { color:#64748B; }

        /* ── Features / Company ── */
        .features-list { list-style:none; padding:0; }
        .features-list li { padding:12px 0; border-bottom:1px solid #E2E8F0; font-size:1.0625rem; color:#475569; }
        .features-list li:last-child { border-bottom:none; }
        .company-content { line-height:1.8; color:#475569; }
        .company-content h3 { color:#0D3B6E; margin-bottom:20px; }

        /* ── Similar Products ── */
        .similar-products { margin-top:80px; }
        .similar-products h2 { font-size:2rem; color:#0D3B6E; margin-bottom:30px; }

        /* ── Main Product Image ── */
        .product-detail-image {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }

        /* The image container — overflow visible so the float box can peek outside */
        .img-zoom-wrapper {
            position: relative;
            width: 100%;
            max-width: 460px;
            aspect-ratio: 1 / 1;
            background: #F8FAFC;
            border-radius: 20px;
            border: 2px solid #E2E8F0;
            overflow: visible;          /* allow zoom float to overflow */
            box-shadow: 0 8px 32px rgba(13,59,110,0.10);
            cursor: crosshair;
            transition: box-shadow 0.3s, border-color 0.3s;
        }
        .img-zoom-wrapper:hover {
            box-shadow: 0 16px 48px rgba(13,59,110,0.18);
            border-color: #F59E0B;
        }

        /* Clip only the img itself */
        .img-zoom-wrapper::before {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: 18px;
            overflow: hidden;
            pointer-events: none;
        }

        .product-main-img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 24px;
            display: block;
            border-radius: 18px;
            user-select: none;
            -webkit-user-drag: none;
        }

        /*
         * FLOATING ZOOM BOX
         * Appears right at the cursor position on the image.
         * It is a square magnified preview that follows the mouse.
         * position: absolute inside .img-zoom-wrapper
         */
        .img-zoom-float {
            position: absolute;
            width: 200px;
            height: 200px;
            border-radius: 12px;
            border: 3px solid #F59E0B;
            background-color: #F8FAFC;
            background-repeat: no-repeat;
            box-shadow:
                0 0 0 1px rgba(245,158,11,0.4),
                0 12px 40px rgba(0,0,0,0.22),
                0 2px 8px rgba(245,158,11,0.18);
            pointer-events: none;
            display: none;            /* hidden until hover */
            z-index: 100;
            /* Glass shimmer header line */
            overflow: hidden;
        }
        .img-zoom-float::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, transparent, rgba(245,158,11,0.8), transparent);
            border-radius: 12px 12px 0 0;
        }
        .img-zoom-wrapper:hover .img-zoom-float {
            display: block;
        }

        /* Zoom crosshair indicator on the image */
        .img-zoom-crosshair {
            position: absolute;
            width: 40px;
            height: 40px;
            border: 2px solid rgba(245,158,11,0.7);
            border-radius: 50%;
            pointer-events: none;
            display: none;
            transform: translate(-50%, -50%);
            box-shadow: 0 0 0 1px rgba(255,255,255,0.5);
            background: rgba(245,158,11,0.08);
            z-index: 99;
        }
        .img-zoom-crosshair::before,
        .img-zoom-crosshair::after {
            content: '';
            position: absolute;
            background: rgba(245,158,11,0.7);
        }
        .img-zoom-crosshair::before { width:1px; height:16px; left:50%; top:50%; transform:translate(-50%,-50%); }
        .img-zoom-crosshair::after  { height:1px; width:16px; top:50%; left:50%; transform:translate(-50%,-50%); }
        .img-zoom-wrapper:hover .img-zoom-crosshair { display: block; }

        /* Placeholder when no image */
        .product-detail-image-placeholder {
            width: 100%;
            max-width: 460px;
            aspect-ratio: 1 / 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #F0F7FF 0%, #E8F0FE 100%);
            border-radius: 20px;
            border: 2px dashed #CBD5E1;
        }

        .zoom-hint {
            font-size: 0.78rem;
            color: #94A3B8;
            margin: 0;
            letter-spacing: 0.01em;
        }

        @media (max-width: 900px) {
            .img-zoom-float      { display: none !important; }
            .img-zoom-crosshair  { display: none !important; }
        }
    </style>

    <script>
    (function () {
        const wrapper    = document.getElementById('imgZoomWrapper');
        if (!wrapper) return;

        const img        = document.getElementById('mainProductImage');
        const floatBox   = document.getElementById('imgZoomFloat');
        if (!img || !floatBox) return;

        const ZOOM       = 3;      // zoom magnification
        const BOX        = 200;    // zoom box size in px
        const OFFSET     = 16;     // gap between cursor and box

        /* ── recompute background-size whenever image loads / resizes ── */
        function getBgSize() {
            const iw = wrapper.clientWidth;
            const ih = wrapper.clientHeight;
            return (iw * ZOOM) + 'px ' + (ih * ZOOM) + 'px';
        }

        img.addEventListener('load', () => {
            floatBox.style.backgroundSize = getBgSize();
        });
        if (img.complete) floatBox.style.backgroundSize = getBgSize();

        wrapper.addEventListener('mousemove', function (e) {
            const rect = wrapper.getBoundingClientRect();

            /* cursor position relative to the wrapper */
            const cx = e.clientX - rect.left;
            const cy = e.clientY - rect.top;

            /* clamp so we don't zoom outside the image */
            const clampedX = Math.max(0, Math.min(cx, rect.width));
            const clampedY = Math.max(0, Math.min(cy, rect.height));

            /* ── 1. Position the floating zoom box ──
               Try to place it to the RIGHT of cursor;
               if it would go outside the wrapper, flip to the LEFT.
               Same for vertical: prefer below, flip above.
            */
            let bx = cx + OFFSET;
            let by = cy + OFFSET;

            /* right overflow → place to the left */
            if (bx + BOX > rect.width) bx = cx - BOX - OFFSET;
            /* bottom overflow → place above */
            if (by + BOX > rect.height) by = cy - BOX - OFFSET;

            /* final clamp inside wrapper bounds */
            bx = Math.max(4, Math.min(bx, rect.width  - BOX - 4));
            by = Math.max(4, Math.min(by, rect.height - BOX - 4));

            floatBox.style.left = bx + 'px';
            floatBox.style.top  = by + 'px';

            /* ── 2. Background position for the zoomed portion ──
               We want the area under the cursor to appear centred in the box.
            */
            floatBox.style.backgroundSize = getBgSize();

            const bpX = (clampedX * ZOOM) - (BOX / 2);
            const bpY = (clampedY * ZOOM) - (BOX / 2);
            floatBox.style.backgroundPosition = '-' + bpX + 'px -' + bpY + 'px';

            floatBox.style.display = 'block';
        });

        wrapper.addEventListener('mouseleave', function () {
            floatBox.style.display = 'none';
        });
    })();
    </script>
</body>
</html>
