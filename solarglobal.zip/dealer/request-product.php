<?php
/**
 * Dealer Product Request Page
 * Dealers can request new products to be added to the platform
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

set_security_headers();
require_dealer_login();

$dealer = get_dealer_profile();
$db = getDB();
$dealer_id = $_SESSION['dealer_id'];
$errors = [];
$success = false;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please refresh and try again.';
    } else {
        $product_type = $_POST['product_type'] ?? '';
        $brand = trim($_POST['brand'] ?? '');
        $model_name = trim($_POST['model_name'] ?? '');
        $specifications = trim($_POST['specifications'] ?? '');
        $reason = trim($_POST['reason'] ?? '');
        $reference_url = trim($_POST['reference_url'] ?? '');

        // Validation
        if (!in_array($product_type, ['inverter', 'battery', 'panel', 'installation_appliance'])) {
            $errors[] = 'Please select a valid product type.';
        }
        if (empty($brand)) $errors[] = 'Brand name is required.';
        if (strlen($brand) > 100) $errors[] = 'Brand name too long (max 100 chars).';
        if (empty($model_name)) $errors[] = 'Model name is required.';
        if (strlen($model_name) > 200) $errors[] = 'Model name too long (max 200 chars).';
        if (!empty($reference_url) && !filter_var($reference_url, FILTER_VALIDATE_URL)) {
            $errors[] = 'Please enter a valid URL for the reference link.';
        }

        if (empty($errors)) {
            $stmt = $db->prepare("
                INSERT INTO dealer_product_requests
                    (dealer_id, product_type, brand, model_name, specifications, reason, reference_url, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
            ");
            $stmt->execute([$dealer_id, $product_type, $brand, $model_name, $specifications, $reason, $reference_url]);
            $success = true;
        }
    }
}

// Fetch existing requests
$stmt = $db->prepare("SELECT * FROM dealer_product_requests WHERE dealer_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$dealer_id]);
$my_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request a Product - <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }
    </style>
</head>
<body>
    <?php $current_dealer_page = 'request-product'; include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="dlr-main-content">
        <div class="dlr-page-header">
            <div class="dlr-page-header-left">
                <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
                <h1>&#128172; Request a Product</h1>
            </div>
            <div></div>
        </div>

        <div style="max-width:800px;">
            <p style="color:#6b7280;font-size:14px;margin-bottom:24px;">
                Can't find a product in our catalog? Request it here and our team will review and add it.
            </p>

            <?php if ($success): ?>
                <div style="background:#d1fae5;border:1px solid #6ee7b7;padding:16px;border-radius:8px;margin-bottom:24px;color:#065f46;">
                    Your product request has been submitted successfully! Our team will review it shortly.
                </div>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
                <div style="background:#fee2e2;border:1px solid #fca5a5;padding:16px;border-radius:8px;margin-bottom:24px;color:#991b1b;">
                    <?php foreach ($errors as $e): ?>
                        <div><?= htmlspecialchars($e) ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="POST" style="background:#fff;padding:24px;border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);margin-bottom:32px;">
                <?= csrf_field() ?>

                <div style="margin-bottom:16px;">
                    <label style="display:block;font-weight:600;font-size:13px;color:#374151;margin-bottom:6px;">Product Type *</label>
                    <select name="product_type" required style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;">
                        <option value="">-- Select --</option>
                        <option value="inverter">Inverter</option>
                        <option value="battery">Battery</option>
                        <option value="panel">Solar Panel</option>
                        <option value="installation_appliance">Installation Appliance</option>
                    </select>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
                    <div>
                        <label style="display:block;font-weight:600;font-size:13px;color:#374151;margin-bottom:6px;">Brand *</label>
                        <input type="text" name="brand" required maxlength="100" placeholder="e.g. Deye, Growatt, LONGi" style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;">
                    </div>
                    <div>
                        <label style="display:block;font-weight:600;font-size:13px;color:#374151;margin-bottom:6px;">Model Name *</label>
                        <input type="text" name="model_name" required maxlength="200" placeholder="e.g. SUN-10K-SG04LP1" style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;">
                    </div>
                </div>

                <div style="margin-bottom:16px;">
                    <label style="display:block;font-weight:600;font-size:13px;color:#374151;margin-bottom:6px;">Specifications</label>
                    <textarea name="specifications" rows="4" placeholder="Power rating, voltage, capacity, or any other specs you know..." style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;resize:vertical;"></textarea>
                </div>

                <div style="margin-bottom:16px;">
                    <label style="display:block;font-weight:600;font-size:13px;color:#374151;margin-bottom:6px;">Why do you need this product?</label>
                    <textarea name="reason" rows="2" placeholder="e.g. High demand from customers, commonly used in our market..." style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;resize:vertical;"></textarea>
                </div>

                <div style="margin-bottom:20px;">
                    <label style="display:block;font-weight:600;font-size:13px;color:#374151;margin-bottom:6px;">Reference URL (optional)</label>
                    <input type="url" name="reference_url" placeholder="https://manufacturer-website.com/product-page" style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;">
                </div>

                <button type="submit" style="background:#f59e0b;color:#fff;border:none;padding:12px 24px;border-radius:8px;font-weight:600;font-size:14px;cursor:pointer;">
                    Submit Request
                </button>
            </form>

            <!-- Existing Requests -->
            <?php if (!empty($my_requests)): ?>
            <div style="background:#fff;padding:24px;border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin:0 0 16px;font-size:16px;">My Requests</h3>
                <table style="width:100%;border-collapse:collapse;font-size:13px;">
                    <thead>
                        <tr style="border-bottom:1px solid #e5e7eb;">
                            <th style="text-align:left;padding:8px;color:#6b7280;">Date</th>
                            <th style="text-align:left;padding:8px;color:#6b7280;">Type</th>
                            <th style="text-align:left;padding:8px;color:#6b7280;">Brand / Model</th>
                            <th style="text-align:left;padding:8px;color:#6b7280;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($my_requests as $req): ?>
                        <tr style="border-bottom:1px solid #f3f4f6;">
                            <td style="padding:8px;"><?= date('M j, Y', strtotime($req['created_at'])) ?></td>
                            <td style="padding:8px;text-transform:capitalize;"><?= htmlspecialchars($req['product_type']) ?></td>
                            <td style="padding:8px;"><strong><?= htmlspecialchars($req['brand']) ?></strong> <?= htmlspecialchars($req['model_name']) ?></td>
                            <td style="padding:8px;">
                                <?php
                                $statusColors = ['pending' => '#f59e0b', 'approved' => '#10b981', 'rejected' => '#ef4444', 'added' => '#3b82f6'];
                                $color = $statusColors[$req['status']] ?? '#6b7280';
                                ?>
                                <span style="background:<?= $color ?>20;color:<?= $color ?>;padding:2px 8px;border-radius:4px;font-weight:600;font-size:11px;text-transform:uppercase;">
                                    <?= htmlspecialchars($req['status']) ?>
                                </span>
                                <?php if ($req['admin_notes']): ?>
                                    <div style="color:#6b7280;font-size:11px;margin-top:4px;"><?= htmlspecialchars($req['admin_notes']) ?></div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
