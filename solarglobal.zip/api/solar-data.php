<?php
/**
 * SolarGlobal API - Solar Data Endpoint
 * Fetches solar/weather data from OpenMeteo and caches in database
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

if (!rate_limit('api_solar_data', 20, 60)) { respond_rate_limited(); }

// Validate input
$lat = isset($_GET['lat']) ? floatval($_GET['lat']) : null;
$lng = isset($_GET['lng']) ? floatval($_GET['lng']) : null;

if ($lat === null || $lng === null || $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
    echo json_encode(['success' => false, 'error' => 'Invalid coordinates']);
    exit;
}

// Round to 2 decimal places for caching (about 1km accuracy)
$cacheLat = round($lat, 2);
$cacheLng = round($lng, 2);

// Check cache first (valid for 24 hours)
$cached = getCachedData($cacheLat, $cacheLng);
if ($cached) {
    // Supplement with today's sunrise/sunset (lightweight call)
    $sunTimes = fetchTodaySunTimes($lat, $lng);
    if ($sunTimes) {
        $cached = array_merge($cached, $sunTimes);
    }
    echo json_encode($cached);
    exit;
}

// Fetch from OpenMeteo (full data including sunrise/sunset)
$data = fetchOpenMeteoData($lat, $lng);
if ($data) {
    cacheData($cacheLat, $cacheLng, $data);
    echo json_encode($data);
} else {
    $fallback = estimateFromLatitude($lat, $lng);
    $sunTimes = fetchTodaySunTimes($lat, $lng);
    if ($sunTimes) $fallback = array_merge($fallback, $sunTimes);
    echo json_encode($fallback);
}

/**
 * Check database cache for solar data
 */
function getCachedData($lat, $lng) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("
            SELECT * FROM solar_irradiance_cache
            WHERE latitude = :lat AND longitude = :lng
            AND fetched_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
            LIMIT 1
        ");
        $stmt->execute(['lat' => $lat, 'lng' => $lng]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            return [
                'success' => true,
                'cached' => true,
                'latitude' => floatval($row['latitude']),
                'longitude' => floatval($row['longitude']),
                'avg_sun_hours' => floatval($row['avg_sun_hours']),
                'avg_irradiance' => floatval($row['avg_irradiance']),
                'avg_temperature' => floatval($row['avg_temperature']),
                'optimal_tilt' => floatval($row['optimal_tilt'])
            ];
        }
    } catch (PDOException $e) {
        // Cache table might not exist yet - continue without cache
    }

    return null;
}

/**
 * Store data in cache
 */
function cacheData($lat, $lng, $data) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("
            INSERT INTO solar_irradiance_cache
            (latitude, longitude, avg_sun_hours, avg_irradiance, avg_temperature, optimal_tilt, fetched_at)
            VALUES (:lat, :lng, :sun, :irr, :temp, :tilt, NOW())
            ON DUPLICATE KEY UPDATE
            avg_sun_hours = :sun2, avg_irradiance = :irr2, avg_temperature = :temp2,
            optimal_tilt = :tilt2, fetched_at = NOW()
        ");
        $stmt->execute([
            'lat' => $lat,
            'lng' => $lng,
            'sun' => $data['avg_sun_hours'],
            'irr' => $data['avg_irradiance'],
            'temp' => $data['avg_temperature'],
            'tilt' => $data['optimal_tilt'],
            'sun2' => $data['avg_sun_hours'],
            'irr2' => $data['avg_irradiance'],
            'temp2' => $data['avg_temperature'],
            'tilt2' => $data['optimal_tilt']
        ]);
    } catch (PDOException $e) {
        // Silently fail on cache write errors
    }
}

/**
 * Fetch solar data from OpenMeteo API
 */
function fetchOpenMeteoData($lat, $lng) {
    $url = 'https://api.open-meteo.com/v1/forecast?' . http_build_query([
        'latitude' => $lat,
        'longitude' => $lng,
        'daily' => 'sunshine_duration,shortwave_radiation_sum,temperature_2m_max,temperature_2m_min,sunrise,sunset',
        'timezone' => 'auto',
        'past_days' => 30,
        'forecast_days' => 7
    ]);

    $context = stream_context_create([
        'http' => [
            'timeout' => 10,
            'header' => "User-Agent: SolarGlobal/1.0\r\n"
        ]
    ]);

    $response = @file_get_contents($url, false, $context);
    if (!$response) return null;

    $json = json_decode($response, true);
    if (!$json || !isset($json['daily'])) return null;

    $daily = $json['daily'];
    $days = count($daily['time']);

    if ($days === 0) return null;

    $totalSunHours = 0;
    $totalRadiation = 0;
    $totalTemp = 0;
    $totalDaylightHours = 0;

    for ($i = 0; $i < $days; $i++) {
        $dailyIrradiance = ($daily['shortwave_radiation_sum'][$i] ?? 0) * 0.27778;
        $totalRadiation += $dailyIrradiance;
        $totalSunHours += $dailyIrradiance;

        $tMax = $daily['temperature_2m_max'][$i] ?? 25;
        $tMin = $daily['temperature_2m_min'][$i] ?? 15;
        $totalTemp += ($tMax + $tMin) / 2;

        // sunshine_duration is in seconds
        $totalDaylightHours += ($daily['sunshine_duration'][$i] ?? 0) / 3600;
    }

    // Get today's sunrise/sunset (last forecast day = today or nearest)
    $todayIdx = $days - 1;
    // Find today's date in the array
    $today = date('Y-m-d');
    for ($i = 0; $i < $days; $i++) {
        if (($daily['time'][$i] ?? '') === $today) {
            $todayIdx = $i;
            break;
        }
    }

    $sunrise = $daily['sunrise'][$todayIdx] ?? null;
    $sunset = $daily['sunset'][$todayIdx] ?? null;

    // Extract just time portion (format: "2024-01-15T06:45")
    $sunriseTime = $sunrise ? substr($sunrise, 11, 5) : null;
    $sunsetTime = $sunset ? substr($sunset, 11, 5) : null;

    // Calculate today's daylight hours from sunrise/sunset
    $todayDaylightHours = null;
    if ($sunrise && $sunset) {
        $riseTs = strtotime($sunrise);
        $setTs = strtotime($sunset);
        if ($riseTs && $setTs) {
            $todayDaylightHours = round(($setTs - $riseTs) / 3600, 1);
        }
    }

    return [
        'success' => true,
        'cached' => false,
        'latitude' => $lat,
        'longitude' => $lng,
        'avg_sun_hours' => round($totalRadiation / $days, 1),
        'avg_irradiance' => round($totalRadiation / $days, 2),
        'avg_temperature' => round($totalTemp / $days, 1),
        'avg_daylight_hours' => round($totalDaylightHours / $days, 1),
        'optimal_tilt' => round(abs($lat), 1),
        'sunrise' => $sunriseTime,
        'sunset' => $sunsetTime,
        'daylight_hours' => $todayDaylightHours,
        'data_days' => $days
    ];
}

/**
 * Fetch today's sunrise/sunset times (lightweight call)
 */
function fetchTodaySunTimes($lat, $lng) {
    $url = 'https://api.open-meteo.com/v1/forecast?' . http_build_query([
        'latitude' => $lat,
        'longitude' => $lng,
        'daily' => 'sunrise,sunset,sunshine_duration',
        'timezone' => 'auto',
        'forecast_days' => 1
    ]);

    $context = stream_context_create([
        'http' => ['timeout' => 5, 'header' => "User-Agent: SolarGlobal/1.0\r\n"]
    ]);

    $response = @file_get_contents($url, false, $context);
    if (!$response) return null;

    $json = json_decode($response, true);
    if (!$json || !isset($json['daily'])) return null;

    $sunrise = $json['daily']['sunrise'][0] ?? null;
    $sunset = $json['daily']['sunset'][0] ?? null;

    $sunriseTime = $sunrise ? substr($sunrise, 11, 5) : null;
    $sunsetTime = $sunset ? substr($sunset, 11, 5) : null;

    $daylightHours = null;
    if ($sunrise && $sunset) {
        $riseTs = strtotime($sunrise);
        $setTs = strtotime($sunset);
        if ($riseTs && $setTs) {
            $daylightHours = round(($setTs - $riseTs) / 3600, 1);
        }
    }

    $sunshineSec = $json['daily']['sunshine_duration'][0] ?? null;
    $avgDaylight = $sunshineSec !== null ? round($sunshineSec / 3600, 1) : null;

    return [
        'sunrise' => $sunriseTime,
        'sunset' => $sunsetTime,
        'daylight_hours' => $daylightHours,
        'avg_daylight_hours' => $avgDaylight,
    ];
}

/**
 * Fallback estimate based on latitude when API fails
 */
function estimateFromLatitude($lat, $lng) {
    $absLat = abs($lat);

    if ($absLat < 15) {
        $sunHours = 6.5; $irradiance = 5.5;
    } elseif ($absLat < 25) {
        $sunHours = 6.0; $irradiance = 5.2;
    } elseif ($absLat < 35) {
        $sunHours = 5.5; $irradiance = 4.8;
    } elseif ($absLat < 45) {
        $sunHours = 5.0; $irradiance = 4.2;
    } elseif ($absLat < 55) {
        $sunHours = 4.0; $irradiance = 3.5;
    } else {
        $sunHours = 3.5; $irradiance = 2.8;
    }

    return [
        'success' => true,
        'estimated' => true,
        'latitude' => $lat,
        'longitude' => $lng,
        'avg_sun_hours' => $sunHours,
        'avg_irradiance' => $irradiance,
        'avg_temperature' => 25,
        'optimal_tilt' => round(abs($lat), 1)
    ];
}
