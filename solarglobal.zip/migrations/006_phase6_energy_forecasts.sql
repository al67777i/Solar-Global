-- Phase 6: Update energy_forecasts table for SolarEngine
-- Drop and recreate with proper structure

DROP TABLE IF EXISTS energy_forecasts;

CREATE TABLE energy_forecasts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    city_id INT NOT NULL,
    forecast_date DATE NOT NULL,
    panel_watts INT NOT NULL DEFAULT 550,
    num_panels INT NOT NULL DEFAULT 4,
    gross_kwh DECIMAL(6,2) NOT NULL,
    net_kwh DECIMAL(6,2) NOT NULL,
    peak_sun_hours DECIMAL(4,2),
    temperature_c DECIMAL(4,1),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_forecast (city_id, forecast_date, panel_watts, num_panels),
    INDEX idx_city_date (city_id, forecast_date),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
