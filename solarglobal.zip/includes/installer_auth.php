<?php
/**
 * Installer Authentication Middleware
 * Include this at the top of any installer-protected page
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('INSTALLER_SESSION_TIMEOUT', 7200); // 2 hours

/**
 * Check if installer is logged in
 */
function is_installer_logged_in(): bool {
    return isset($_SESSION['installer_logged_in']) && $_SESSION['installer_logged_in'] === true;
}

/**
 * Get current installer ID
 */
function get_installer_id(): ?int {
    return $_SESSION['installer_id'] ?? null;
}

/**
 * Get current installer data from session
 */
function get_installer_session(): array {
    return [
        'id' => $_SESSION['installer_id'] ?? null,
        'email' => $_SESSION['installer_email'] ?? '',
        'business_name' => $_SESSION['installer_business_name'] ?? '',
        'owner_name' => $_SESSION['installer_owner_name'] ?? '',
        'status' => $_SESSION['installer_status'] ?? '',
        'logo_path' => $_SESSION['installer_logo'] ?? '',
    ];
}

/**
 * Require installer login - redirect if not authenticated
 */
function require_installer_login() {
    if (!is_installer_logged_in()) {
        $_SESSION['installer_redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: /solarglobal/installer/login.php');
        exit();
    }

    // Check session timeout
    if (isset($_SESSION['installer_last_activity'])) {
        if (time() - $_SESSION['installer_last_activity'] > INSTALLER_SESSION_TIMEOUT) {
            installer_logout();
            header('Location: /solarglobal/installer/login.php?timeout=1');
            exit();
        }
    }

    // Update activity
    $_SESSION['installer_last_activity'] = time();

    // Check if installer is still active
    if (($_SESSION['installer_status'] ?? '') === 'suspended') {
        installer_logout();
        header('Location: /solarglobal/installer/login.php?suspended=1');
        exit();
    }
}

/**
 * Login installer - set session variables
 */
function installer_login(array $installer): void {
    session_regenerate_id(true);
    $_SESSION['installer_logged_in'] = true;
    $_SESSION['installer_id'] = (int)$installer['id'];
    $_SESSION['installer_email'] = $installer['email'];
    $_SESSION['installer_business_name'] = $installer['business_name'];
    $_SESSION['installer_owner_name'] = $installer['owner_name'];
    $_SESSION['installer_status'] = $installer['status'];
    $_SESSION['installer_logo'] = $installer['logo_path'] ?? '';
    $_SESSION['installer_last_activity'] = time();

    // Update last login (non-critical — don't let this break login flow)
    try {
        $db = getDB();
        $stmt = $db->prepare("UPDATE installers SET last_login_at = NOW() WHERE id = ?");
        $stmt->execute([$installer['id']]);
    } catch (Exception $e) {
        error_log("installer_login: could not update last_login_at: " . $e->getMessage());
    }
}

/**
 * Logout installer - destroy installer session vars
 */
function installer_logout(): void {
    unset(
        $_SESSION['installer_logged_in'],
        $_SESSION['installer_id'],
        $_SESSION['installer_email'],
        $_SESSION['installer_business_name'],
        $_SESSION['installer_owner_name'],
        $_SESSION['installer_status'],
        $_SESSION['installer_logo'],
        $_SESSION['installer_last_activity'],
        $_SESSION['installer_redirect_after_login']
    );
}

/**
 * Get full installer profile from database
 */
function get_installer_profile(?int $installer_id = null): ?array {
    $id = $installer_id ?? get_installer_id();
    if (!$id) return null;

    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM installers WHERE id = ?");
    $stmt->execute([$id]);
    $installer = $stmt->fetch();

    if ($installer) {
        unset($installer['password_hash']); // Never expose password hash
    }

    return $installer ?: null;
}

/**
 * Count installer's portfolio items
 */
function get_installer_portfolio_count(?int $installer_id = null): int {
    $id = $installer_id ?? get_installer_id();
    if (!$id) return 0;

    $db = getDB();
    $stmt = $db->prepare("SELECT COUNT(*) FROM installer_portfolio WHERE installer_id = ?");
    $stmt->execute([$id]);
    return (int)$stmt->fetchColumn();
}

/**
 * Check if installer has an active subscription (paid, free trial, or grace period)
 * Mirrors check_dealer_subscription() in dealer_auth.php
 */
function check_installer_subscription(?int $installer_id = null): array {
    $id = $installer_id ?? get_installer_id();
    $base = ['active' => false, 'reason' => 'not_logged_in', 'trial' => false, 'trial_days_left' => 0, 'grace' => false, 'grace_days_left' => 0];

    if (!$id) return $base;

    $db = getDB();
    $installer = get_installer_profile($id);
    if (!$installer) return array_merge($base, ['reason' => 'not_found']);

    if (in_array($installer['status'], ['suspended', 'rejected'])) {
        return array_merge($base, ['reason' => 'suspended']);
    }

    $subStatus = $installer['subscription_status'] ?? 'none';
    $now = time();

    // 1. Paid active subscription
    if ($subStatus === 'active') {
        $expires = $installer['subscription_expires_at'] ?? null;
        if (!$expires || strtotime($expires) > $now) {
            return array_merge($base, ['active' => true, 'reason' => 'paid']);
        }
    }

    // 2. Grace period
    $graceEnd = $installer['grace_period_ends_at'] ?? null;
    if ($graceEnd && strtotime($graceEnd) > $now && in_array($subStatus, ['expired', 'past_due', 'canceled'])) {
        $graceDaysLeft = (int)ceil((strtotime($graceEnd) - $now) / 86400);
        return array_merge($base, [
            'active' => true,
            'reason' => 'grace_period',
            'grace' => true,
            'grace_days_left' => $graceDaysLeft
        ]);
    }

    // 3. Free trial
    if (!function_exists('get_system_setting')) {
        require_once __DIR__ . '/helpers.php';
    }
    $trialEnabled = get_system_setting('installer_free_trial_enabled', '0');
    if ($trialEnabled === '1') {
        $trialDays = (int)get_system_setting('installer_free_trial_days', '30');
        $createdAt = strtotime($installer['created_at']);
        $trialEnd = $createdAt + ($trialDays * 86400);

        if ($now < $trialEnd) {
            $daysLeft = (int)ceil(($trialEnd - $now) / 86400);

            if (!in_array($installer['status'], ['active', 'approved'])) {
                $db->prepare("UPDATE installers SET status = 'active' WHERE id = ? AND status = 'pending'")
                   ->execute([$id]);
            }

            return array_merge($base, ['active' => true, 'reason' => 'free_trial', 'trial' => true, 'trial_days_left' => $daysLeft]);
        }
    }

    // 4. No subscription
    return array_merge($base, ['reason' => 'no_subscription']);
}

/**
 * Require active subscription for protected installer pages
 */
function require_installer_subscription(): void {
    $sub = check_installer_subscription();
    if (!$sub['active']) {
        $_SESSION['installer_sub_message'] = 'You need an active subscription to access this feature. Please subscribe or renew your plan.';
        header('Location: /solarglobal/installer/subscription.php');
        exit();
    }
    if ($sub['grace']) {
        $_SESSION['installer_sub_warning'] = 'Your subscription has expired. You have ' . $sub['grace_days_left'] . ' day(s) left to renew before your profile is locked.';
    }
}

/**
 * Check if an installer is visible to customers
 */
function is_installer_visible(?int $installer_id = null): bool {
    $sub = check_installer_subscription($installer_id);
    return $sub['active'];
}
