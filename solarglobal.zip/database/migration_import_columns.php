<?php
/**
 * Migration: Add all columns needed for CSV import matching scraper output
 * Run once: http://localhost/solarglobal/database/migration_import_columns.php
 */
require_once __DIR__ . '/../includes/db.php';
$db = getDB();

$queries = [
    // ===== INVERTERS: Add missing columns =====
    'inverters: series_name' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS series_name VARCHAR(200) NULL AFTER name",
    'inverters: price_per_watt' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS price_per_watt DECIMAL(10,6) DEFAULT 0 AFTER price_usd",
    'inverters: price_usd' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS price_usd DECIMAL(10,2) DEFAULT 0 AFTER price_per_watt",
    'inverters: three_phase' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS three_phase TINYINT(1) DEFAULT 0",
    'inverters: battery_voltage_range' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS battery_voltage_range VARCHAR(100) NULL",
    'inverters: euro_efficiency' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS euro_efficiency DECIMAL(5,2) NULL",
    'inverters: noise_level' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS noise_level VARCHAR(50) NULL",
    'inverters: operating_temperature' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS operating_temperature VARCHAR(100) NULL",
    'inverters: power_factor' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS power_factor VARCHAR(20) NULL",
    'inverters: output_ac_voltage_range' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS output_ac_voltage_range VARCHAR(100) NULL",
    'inverters: dc_inputs' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS dc_inputs INT NULL",
    'inverters: connectors' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS connectors VARCHAR(100) NULL",
    'inverters: supports_parallel' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS supports_parallel TINYINT(1) DEFAULT 0",
    'inverters: max_parallel_units' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS max_parallel_units INT DEFAULT 1",
    'inverters: country_code' => "ALTER TABLE inverters ADD COLUMN IF NOT EXISTS country_code VARCHAR(3) DEFAULT 'global'",

    // ===== BATTERIES: Add missing columns =====
    'batteries: technology' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS technology VARCHAR(100) NULL AFTER battery_type",
    'batteries: nominal_energy_kwh' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS nominal_energy_kwh DECIMAL(10,2) NULL",
    'batteries: design_life' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS design_life VARCHAR(50) NULL",
    'batteries: round_trip_efficiency' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS round_trip_efficiency DECIMAL(5,2) NULL",
    'batteries: configuration' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS configuration VARCHAR(50) NULL",
    'batteries: mounting_options' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS mounting_options VARCHAR(100) NULL",
    'batteries: max_parallel_units' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS max_parallel_units INT DEFAULT 1",
    'batteries: ip_rating' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS ip_rating VARCHAR(50) NULL",
    'batteries: cooling_method' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS cooling_method VARCHAR(50) NULL",
    'batteries: monitoring' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS monitoring VARCHAR(100) NULL",
    'batteries: price_per_kwh' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS price_per_kwh DECIMAL(10,2) NULL",
    'batteries: price_usd' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS price_usd DECIMAL(10,2) DEFAULT 0",
    'batteries: charge_voltage' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS charge_voltage VARCHAR(50) NULL",
    'batteries: discharge_voltage' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS discharge_voltage VARCHAR(50) NULL",
    'batteries: max_discharge_current' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS max_discharge_current INT NULL",
    'batteries: self_discharge' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS self_discharge VARCHAR(50) NULL",
    'batteries: country_code' => "ALTER TABLE batteries ADD COLUMN IF NOT EXISTS country_code VARCHAR(3) DEFAULT 'global'",

    // ===== PANELS: Add missing columns =====
    'panels: technology' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS technology VARCHAR(200) NULL AFTER panel_type",
    'panels: power_range' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS power_range VARCHAR(50) NULL",
    'panels: cell_type' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS cell_type VARCHAR(50) NULL",
    'panels: cell_size' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS cell_size VARCHAR(50) NULL",
    'panels: price_per_watt' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS price_per_watt DECIMAL(10,6) DEFAULT 0",
    'panels: price_usd' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS price_usd DECIMAL(10,2) DEFAULT 0 AFTER price_pkr",
    'panels: glass_type' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS glass_type VARCHAR(200) NULL",
    'panels: glass_thickness' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS glass_thickness VARCHAR(20) NULL",
    'panels: frame_type' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS frame_type VARCHAR(100) NULL",
    'panels: junction_box' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS junction_box VARCHAR(50) NULL",
    'panels: connector' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS connector VARCHAR(50) NULL",
    'panels: cable_spec' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS cable_spec VARCHAR(50) NULL",
    'panels: warranty_product' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS warranty_product VARCHAR(50) NULL",
    'panels: country_code' => "ALTER TABLE panels ADD COLUMN IF NOT EXISTS country_code VARCHAR(3) DEFAULT 'global'",

    // ===== Update inverter_type ENUM to include all values =====
    'inverters: update type enum' => "ALTER TABLE inverters MODIFY COLUMN type ENUM('off-grid','on-grid','hybrid','microinverter') DEFAULT 'hybrid'",
];

echo "<h1>SolarGlobal Import Columns Migration</h1><pre>\n";

foreach ($queries as $label => $sql) {
    try {
        $db->exec($sql);
        echo "&#10004; $label\n";
    } catch (PDOException $e) {
        $msg = $e->getMessage();
        if (strpos($msg, 'Duplicate column') !== false || strpos($msg, 'already exists') !== false) {
            echo "&#9197; $label (already exists)\n";
        } else {
            echo "&#10060; $label: $msg\n";
        }
    }
}

echo "\nDone! All import columns added.\n</pre>";
