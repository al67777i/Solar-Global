<?php
/**
 * AJAX endpoint - Image Library Browse (admin image-library.php page)
 * Returns paginated images as JSON for the Load More feature.
 * GET params: folder, search, page (default 1), per_page (default 48)
 */
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/helpers.php';

header('Content-Type: application/json');

$db = getDB();

$folder   = trim($_GET['folder'] ?? 'all');
$search   = trim($_GET['search'] ?? '');
$page     = max(1, intval($_GET['page'] ?? 1));
$perPage  = 48;
$offset   = ($page - 1) * $perPage;

$folders  = ['inverters', 'batteries', 'panels', 'dealers', 'appliances', 'general'];

// Build WHERE
$where  = [];
$params = [];

if ($folder !== 'all' && in_array($folder, $folders)) {
    $where[] = 'folder = ?';
    $params[] = $folder;
}

if ($search !== '') {
    $where[] = '(original_filename LIKE ? OR alt_text LIKE ? OR tags LIKE ?)';
    $term     = '%' . $search . '%';
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Total count
$countStmt = $db->prepare("SELECT COUNT(*) FROM image_library $whereSQL");
$countStmt->execute($params);
$total = (int) $countStmt->fetchColumn();

// Images for this page
$stmt = $db->prepare(
    "SELECT id, filename, original_filename, file_path, thumbnail_path,
            alt_text, tags, folder, file_size, width, height, created_at
     FROM image_library
     $whereSQL
     ORDER BY created_at DESC
     LIMIT $perPage OFFSET $offset"
);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Build display URLs
$base = rtrim(BASE_URL, '/') . '/';
$images = array_map(function($img) use ($base) {
    $raw   = ltrim($img['file_path'], '/');
    $thumb = !empty($img['thumbnail_path']) ? ltrim($img['thumbnail_path'], '/') : $raw;
    $img['display_url'] = $base . $raw;
    $img['thumb_url']   = $base . $thumb;
    return $img;
}, $rows);

echo json_encode([
    'success'     => true,
    'images'      => $images,
    'total'       => $total,
    'page'        => $page,
    'per_page'    => $perPage,
    'total_pages' => ceil($total / $perPage),
]);
