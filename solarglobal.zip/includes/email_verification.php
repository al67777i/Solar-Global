<?php
/**
 * Email Verification System
 *
 * SQL Table Definition:
 *
 * CREATE TABLE IF NOT EXISTS email_verifications (
 *     id INT AUTO_INCREMENT PRIMARY KEY,
 *     email VARCHAR(255) NOT NULL,
 *     code VARCHAR(10) NOT NULL,
 *     type ENUM('registration', 'password_reset', 'email_change') DEFAULT 'registration',
 *     expires_at DATETIME NOT NULL,
 *     verified_at DATETIME NULL,
 *     created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 *     INDEX idx_email_type (email, type),
 *     INDEX idx_expires (expires_at)
 * ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/mailer.php';

/**
 * Check if email verification is required based on system settings.
 */
function is_email_verification_required(): bool
{
    return get_system_setting('require_email_verification', '0') === '1';
}

/**
 * Generate a random 6-digit numeric verification code.
 */
function generate_verification_code(): string
{
    return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

/**
 * Store a verification code in the database.
 * Deletes any existing codes for the same email and type before inserting.
 */
function store_verification_code(string $email, string $code, string $type = 'registration'): bool
{
    $db = getDB();

    try {
        // Delete existing codes for this email and type
        $stmt = $db->prepare("DELETE FROM email_verifications WHERE email = :email AND type = :type");
        $stmt->execute([':email' => $email, ':type' => $type]);

        // Insert new code with 15-minute expiry
        $stmt = $db->prepare(
            "INSERT INTO email_verifications (email, code, type, expires_at, created_at)
             VALUES (:email, :code, :type, DATE_ADD(NOW(), INTERVAL 15 MINUTE), NOW())"
        );

        return $stmt->execute([
            ':email' => $email,
            ':code'  => $code,
            ':type'  => $type,
        ]);
    } catch (PDOException $e) {
        error_log("store_verification_code error: " . $e->getMessage());
        return false;
    }
}

/**
 * Send a professional HTML verification email with the 6-digit code.
 * Uses the centralized sg_send_email() which routes through configured mail driver (SMTP or PHP mail).
 */
function send_verification_email(string $email, string $code, string $name = ''): bool
{
    $siteName = get_system_setting('site_name', 'SolarGlobal');
    $greeting = $name !== '' ? "Hello " . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . "," : "Hello,";

    $subject = "$siteName - Email Verification Code";

    $innerHtml = <<<HTML
<p style="font-size:16px;color:#1E293B;margin:0 0 16px;">{$greeting}</p>
<p style="font-size:16px;color:#334155;margin:0 0 24px;">Your email verification code is:</p>
<div style="text-align:center;margin:28px 0;">
    <span style="display:inline-block;font-size:36px;font-weight:bold;letter-spacing:10px;color:#F59E0B;background-color:#FFFBEB;padding:16px 32px;border-radius:12px;border:2px dashed #F59E0B;font-family:'Courier New',monospace;">{$code}</span>
</div>
<p style="font-size:14px;color:#64748B;margin:0 0 8px;">&#9203; This code will expire in <strong>15 minutes</strong>.</p>
<p style="font-size:14px;color:#64748B;margin:0;">If you did not request this code, you can safely ignore this email. No action is required.</p>
HTML;

    return sg_send_email($email, $subject, $innerHtml);
}

/**
 * Verify a code against the database.
 * Returns true if the code matches, hasn't expired, and hasn't been used.
 * On success, marks the record as verified.
 */
function verify_code(string $email, string $code, string $type = 'registration'): bool
{
    $db = getDB();

    try {
        $stmt = $db->prepare(
            "SELECT id FROM email_verifications
             WHERE email = :email
               AND code = :code
               AND type = :type
               AND expires_at > NOW()
               AND verified_at IS NULL
             LIMIT 1"
        );

        $stmt->execute([
            ':email' => $email,
            ':code'  => $code,
            ':type'  => $type,
        ]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            return false;
        }

        // Mark as verified
        $update = $db->prepare("UPDATE email_verifications SET verified_at = NOW() WHERE id = :id");
        $update->execute([':id' => $row['id']]);

        return true;
    } catch (PDOException $e) {
        error_log("verify_code error: " . $e->getMessage());
        return false;
    }
}

/**
 * Clean up expired verification codes older than 1 hour.
 */
function cleanup_expired_codes(): void
{
    $db = getDB();

    try {
        $stmt = $db->prepare("DELETE FROM email_verifications WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)");
        $stmt->execute();
    } catch (PDOException $e) {
        error_log("cleanup_expired_codes error: " . $e->getMessage());
    }
}
