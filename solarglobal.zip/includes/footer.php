    <!-- Footer -->
    <footer class="site-footer" style="background: #0F172A; color: #E2E8F0; margin-top: 80px; font-family: 'Inter', sans-serif;">
        <!-- Main Footer -->
        <div style="max-width: 1200px; margin: 0 auto; padding: 64px 24px 40px;">
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 48px;">

                <!-- Column 1: Brand -->
                <div>
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 16px;">
                        <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #F59E0B, #D97706); border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                        </div>
                        <div>
                            <div style="font-size: 1.2rem; font-weight: 700; color: #ffffff;"><?= sanitize($_site_name ?? 'SolarGlobal') ?></div>
                            <div style="font-size: 0.7rem; color: #94A3B8;"><?= sanitize($_site_tagline ?? 'Smart Solar Advisor') ?></div>
                        </div>
                    </div>
                    <p style="color: #94A3B8; font-size: 0.875rem; line-height: 1.7; margin: 0 0 20px 0;">
                        Empowering homes and businesses with intelligent solar solutions. Find, compare, and install the perfect solar system.
                    </p>
                    <div style="display: flex; gap: 10px;">
                        <a href="#" style="width: 36px; height: 36px; border-radius: 8px; background: #1E293B; display: flex; align-items: center; justify-content: center; text-decoration: none; color: #94A3B8; transition: background 0.2s, color 0.2s;" onmouseover="this.style.background='#F59E0B';this.style.color='#fff'" onmouseout="this.style.background='#1E293B';this.style.color='#94A3B8'">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                        </a>
                        <a href="#" style="width: 36px; height: 36px; border-radius: 8px; background: #1E293B; display: flex; align-items: center; justify-content: center; text-decoration: none; color: #94A3B8; transition: background 0.2s, color 0.2s;" onmouseover="this.style.background='#F59E0B';this.style.color='#fff'" onmouseout="this.style.background='#1E293B';this.style.color='#94A3B8'">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/></svg>
                        </a>
                        <a href="#" style="width: 36px; height: 36px; border-radius: 8px; background: #1E293B; display: flex; align-items: center; justify-content: center; text-decoration: none; color: #94A3B8; transition: background 0.2s, color 0.2s;" onmouseover="this.style.background='#F59E0B';this.style.color='#fff'" onmouseout="this.style.background='#1E293B';this.style.color='#94A3B8'">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                        </a>
                        <a href="#" style="width: 36px; height: 36px; border-radius: 8px; background: #1E293B; display: flex; align-items: center; justify-content: center; text-decoration: none; color: #94A3B8; transition: background 0.2s, color 0.2s;" onmouseover="this.style.background='#F59E0B';this.style.color='#fff'" onmouseout="this.style.background='#1E293B';this.style.color='#94A3B8'">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
                        </a>
                    </div>
                </div>

                <!-- Column 2: Products -->
                <div>
                    <h4 style="color: #ffffff; font-size: 0.85rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 20px 0;">Products</h4>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>inverters.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Inverters</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>batteries.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Batteries</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>panels.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Solar Panels</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>compare.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Compare Products</a>
                        </li>
                    </ul>
                </div>

                <!-- Column 3: Services -->
                <div>
                    <h4 style="color: #ffffff; font-size: 0.85rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 20px 0;">Services</h4>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>index.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Solar Calculator</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>store.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Solar Shop</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>find-installer.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Find Installer</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>become-dealer.php" style="color: #F59E0B; text-decoration: none; font-size: 0.875rem; font-weight: 500; transition: color 0.2s;" onmouseover="this.style.color='#FBBF24'" onmouseout="this.style.color='#F59E0B'">Open Your Store</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>become-installer.php" style="color: #F59E0B; text-decoration: none; font-size: 0.875rem; font-weight: 500; transition: color 0.2s;" onmouseover="this.style.color='#FBBF24'" onmouseout="this.style.color='#F59E0B'">Become an Installer</a>
                        </li>
                    </ul>
                </div>

                <!-- Column 4: Company -->
                <div>
                    <h4 style="color: #ffffff; font-size: 0.85rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 20px 0;">Company</h4>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>about.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">About Us</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>contact.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Contact</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>customer/login.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Customer Login</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>dealer/login.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Dealer Login</a>
                        </li>
                        <li style="margin-bottom: 14px;">
                            <a href="<?= BASE_URL ?>installer/login.php" style="color: #94A3B8; text-decoration: none; font-size: 0.875rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#94A3B8'">Installer Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Bottom Bar -->
        <div style="border-top: 1px solid #1E293B;">
            <div style="max-width: 1200px; margin: 0 auto; padding: 20px 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
                <p style="color: #64748B; margin: 0; font-size: 0.8125rem;">
                    &copy; <?php echo date('Y'); ?> <?= sanitize($_site_name ?? 'SolarGlobal') ?>. All rights reserved.
                </p>
                <p style="color: #64748B; margin: 0; font-size: 0.8125rem;">
                    Powered by <?= sanitize($_site_name ?? 'SolarGlobal') ?>
                </p>
                <div style="display: flex; gap: 24px;">
                    <a href="<?= BASE_URL ?>privacy-policy.php" style="color: #64748B; text-decoration: none; font-size: 0.8125rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#64748B'">Privacy Policy</a>
                    <a href="<?= BASE_URL ?>terms.php" style="color: #64748B; text-decoration: none; font-size: 0.8125rem; transition: color 0.2s;" onmouseover="this.style.color='#F59E0B'" onmouseout="this.style.color='#64748B'">Terms of Service</a>
                </div>
            </div>
        </div>

        <!-- Responsive footer -->
        <style>
            @media (max-width: 768px) {
                .site-footer > div:first-child > div {
                    grid-template-columns: 1fr !important;
                    gap: 32px !important;
                }
                .site-footer > div:last-child > div {
                    flex-direction: column !important;
                    align-items: center !important;
                    text-align: center;
                }
            }
            @media (min-width: 769px) and (max-width: 1024px) {
                .site-footer > div:first-child > div {
                    grid-template-columns: repeat(2, 1fr) !important;
                }
            }
        </style>
    </footer>

    <!-- Bottom nav spacer for mobile -->
    <div class="bottom-nav-spacer"></div>

    <!-- Cookie Consent Banner -->
    <script src="<?= BASE_URL ?>assets/js/cookie-consent.js"></script>

    <!-- Auto-detect country for currency if not set yet -->
    <script>
    (function(){
        try {
            // Only run if sg_location cookie is not already set
            if (document.cookie.indexOf('sg_location=') !== -1) return;
            // Try ipapi.co (free, no key, HTTPS)
            fetch('https://ipapi.co/json/', {signal: AbortSignal.timeout(3000)})
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (d && d.country_code) {
                        var loc = {lat: d.latitude||0, lng: d.longitude||0, city: d.city||'', country_code: d.country_code.toUpperCase()};
                        document.cookie = 'sg_location=' + encodeURIComponent(JSON.stringify(loc)) + ';path=/solarglobal/;max-age=' + (30*86400) + ';SameSite=Lax';
                        // Reload once so PHP picks up the country for currency
                        if (!sessionStorage.getItem('sg_geo_done')) {
                            sessionStorage.setItem('sg_geo_done', '1');
                            location.reload();
                        }
                    }
                }).catch(function(){});
        } catch(e){}
    })();
    </script>
</body>
</html>
