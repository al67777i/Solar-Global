-- ============================================================
-- Appliances Table: ALTER + SEED DATA
-- 25 countries, ~170 appliances, smart country-based filtering
-- ============================================================

-- Add new columns safely
DELIMITER //
DROP PROCEDURE IF EXISTS alter_appliances_table//
CREATE PROCEDURE alter_appliances_table()
BEGIN
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='appliances' AND COLUMN_NAME='country_codes') THEN
        ALTER TABLE appliances ADD COLUMN country_codes VARCHAR(500) DEFAULT 'global';
    END IF;
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='appliances' AND COLUMN_NAME='voltage_system') THEN
        ALTER TABLE appliances ADD COLUMN voltage_system INT DEFAULT 220;
    END IF;
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='appliances' AND COLUMN_NAME='is_inverter_type') THEN
        ALTER TABLE appliances ADD COLUMN is_inverter_type TINYINT(1) DEFAULT 0;
    END IF;
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='appliances' AND COLUMN_NAME='min_watt') THEN
        ALTER TABLE appliances ADD COLUMN min_watt INT DEFAULT 0;
    END IF;
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='appliances' AND COLUMN_NAME='priority_order') THEN
        ALTER TABLE appliances ADD COLUMN priority_order INT DEFAULT 50;
    END IF;
END//
DELIMITER ;

CALL alter_appliances_table();
DROP PROCEDURE IF EXISTS alter_appliances_table;

-- ============================================================
TRUNCATE TABLE appliances;
-- ============================================================

INSERT INTO appliances (name_en, icon, watt_typical, surge_load_watts, standby_watts, category, season_tags, usage_hours_summer, usage_hours_winter, country_codes, voltage_system, is_inverter_type, min_watt, priority_order) VALUES

-- ═══════ COOLING (23) ═══════
('Ceiling Fan 56"',              '🌀', 75,   120,  0, 'Cooling', 'summer',        12, 2,   'PK,IN,BD,EG,NG,PH,TH,VN,ID,MY', 220, 0, 0, 10),
('Ceiling Fan Inverter 56"',     '🌀', 35,   55,   0, 'Cooling', 'summer',        14, 2,   'PK,IN,BD', 220, 1, 20, 10),
('Ceiling Fan DC/BLDC',          '🌀', 30,   45,   0, 'Cooling', 'summer',        14, 2,   'PK,IN', 220, 1, 18, 10),
('Pedestal/Standing Fan',        '🌀', 55,   85,   0, 'Cooling', 'summer',        8,  0,   'global', 220, 0, 0, 20),
('Pedestal Fan DC Inverter',     '🌀', 25,   40,   0, 'Cooling', 'summer',        10, 0,   'PK,IN', 220, 1, 15, 20),
('Table Fan',                    '🌀', 40,   60,   0, 'Cooling', 'summer',        6,  0,   'global', 220, 0, 0, 25),
('Exhaust Fan 8"',               '💨', 30,   50,   0, 'Cooling', 'all_year',      4,  4,   'global', 220, 0, 0, 30),
('Exhaust Fan 12"',              '💨', 50,   80,   0, 'Cooling', 'all_year',      4,  4,   'PK,IN,BD,SA,AE,EG', 220, 0, 0, 30),
('Tower Fan',                    '🌀', 50,   75,   2, 'Cooling', 'summer',        8,  0,   'US,CA,AU,GB', 220, 0, 0, 25),
('Air Cooler / Evaporative',     '❄️', 200,  320,  0, 'Cooling', 'summer',        10, 0,   'PK,IN,SA,AE,EG', 220, 0, 0, 25),
('Desert Cooler (Large)',        '❄️', 350,  550,  0, 'Cooling', 'summer',        10, 0,   'PK,IN,SA,AE', 220, 0, 0, 30),
('Split AC Non-Inverter 1 Ton',  '❄️', 1200, 3600, 5, 'Cooling', 'summer',        8,  0,   'PK,IN,BD,SA,AE,EG,TH,PH,VN,MY,ID', 220, 0, 0, 30),
('Split AC Inverter 1 Ton',      '❄️', 700,  2100, 5, 'Cooling', 'summer',        10, 0,   'PK,IN,BD,SA,AE,TH,PH,MY', 220, 1, 350, 30),
('Split AC Non-Inverter 1.5 Ton','❄️', 1800, 5400, 5, 'Cooling', 'summer',        8,  0,   'PK,IN,BD,SA,AE,EG', 220, 0, 0, 35),
('Split AC Inverter 1.5 Ton',    '❄️', 1100, 3300, 5, 'Cooling', 'summer',        10, 0,   'PK,IN,BD,SA,AE', 220, 1, 500, 35),
('Split AC Non-Inverter 2 Ton',  '❄️', 2400, 7200, 5, 'Cooling', 'summer',        8,  0,   'PK,IN,SA,AE,EG', 220, 0, 0, 40),
('Split AC Inverter 2 Ton',      '❄️', 1500, 4500, 5, 'Cooling', 'summer',        10, 0,   'PK,IN,SA,AE', 220, 1, 700, 40),
('Mini Split AC Inverter 0.75T', '❄️', 550,  1650, 5, 'Cooling', 'summer',        10, 0,   'PK,IN,BD', 220, 1, 280, 35),
('Window AC 1 Ton',              '❄️', 1400, 4200, 5, 'Cooling', 'summer',        8,  0,   'US,SA,AE,EG,PK,IN', 220, 0, 0, 35),
('Central AC System',            '❄️', 3500, 7000, 10,'Cooling', 'summer',        8,  0,   'US,CA,SA,AE,AU', 110, 0, 0, 50),
('Portable AC',                  '❄️', 1200, 3600, 5, 'Cooling', 'summer',        6,  0,   'US,CA,GB,DE,FR,AU,JP,KR', 220, 0, 0, 45),
('Air Purifier',                 '🌿', 50,   70,   3, 'Cooling', 'all_year',      12, 12,  'JP,KR,CN,US,DE,GB', 220, 0, 0, 40),
('Mist Fan',                     '💧', 100,  150,  0, 'Cooling', 'summer',        6,  0,   'PK,IN,SA,AE,EG,TH', 220, 0, 0, 35),

-- ═══════ HEATING (14) ═══════
('Space Heater',                 '🔥', 1500, 1800, 0, 'Heating', 'winter',        0,  6,   'US,CA,GB,DE,FR,AU,KR,JP,CN', 220, 0, 0, 35),
('Oil Heater / Radiator',        '🔥', 2000, 2200, 0, 'Heating', 'winter',        0,  8,   'PK,IN,GB,DE,FR,TR', 220, 0, 0, 40),
('Electric Geyser / Water Heater','🚿', 3000, 3500, 0, 'Heating', 'winter',       0,  2,   'PK,IN,BD,TR,EG', 220, 0, 0, 25),
('Tankless Water Heater',        '🚿', 5000, 5500, 0, 'Heating', 'all_year',      1,  1,   'US,CA,JP', 110, 0, 0, 50),
('Tank Water Heater (Electric)', '🚿', 3000, 3500, 5, 'Heating', 'all_year',      2,  3,   'US,CA,AU,GB', 220, 0, 0, 45),
('Heat Pump',                    '🌡️', 3500, 7000, 10,'Heating', 'winter',        0,  8,   'US,CA,AU,JP,KR,DE,FR,GB', 220, 0, 0, 50),
('Electric Blanket',             '🛏️', 200,  250,  0, 'Heating', 'winter',        0,  8,   'PK,IN,GB,JP,KR', 220, 0, 0, 50),
('Room Heater / Fan Heater',     '🔥', 2000, 2400, 0, 'Heating', 'winter',        0,  5,   'PK,IN,BD', 220, 0, 0, 30),
('Underfloor Heating System',    '🏠', 1500, 1800, 0, 'Heating', 'winter',        0,  10,  'JP,KR,DE', 220, 0, 0, 55),
('Furnace Blower Motor',         '🌬️', 500,  1500, 5, 'Heating', 'winter',        0,  10,  'US,CA', 110, 0, 0, 35),
('Portable Ceramic Heater',      '🔥', 1000, 1200, 0, 'Heating', 'winter',        0,  5,   'US,CA,GB', 220, 0, 0, 40),
('Electric Fireplace',           '🔥', 1500, 1800, 3, 'Heating', 'winter',        0,  5,   'US,CA,GB,AU', 220, 0, 0, 60),
('Heated Towel Rail',            '🛁', 100,  120,  0, 'Heating', 'winter',        0,  6,   'GB,AU', 220, 0, 0, 70),
('Kotatsu Table Heater',         '🪑', 500,  600,  0, 'Heating', 'winter',        0,  6,   'JP', 110, 0, 0, 55),

-- ═══════ LIGHTING (10) ═══════
('LED Bulb 7W',                  '💡', 7,    7,    0, 'Lighting', 'all_year',      6,  8,   'global', 220, 0, 0, 10),
('LED Bulb 12W',                 '💡', 12,   12,   0, 'Lighting', 'all_year',      6,  8,   'global', 220, 0, 0, 10),
('LED Bulb 18W',                 '💡', 18,   18,   0, 'Lighting', 'all_year',      5,  7,   'global', 220, 0, 0, 10),
('LED Tube Light 18W',           '💡', 18,   18,   0, 'Lighting', 'all_year',      6,  8,   'PK,IN,BD,PH,VN,TH', 220, 0, 0, 10),
('Energy Saver / CFL 23W',       '💡', 23,   25,   0, 'Lighting', 'all_year',      6,  8,   'PK,IN,BD,EG,NG', 220, 0, 0, 15),
('Outdoor / Garden Light 15W',   '🔦', 15,   15,   0, 'Lighting', 'all_year',      6,  6,   'global', 220, 0, 0, 30),
('LED Flood Light 50W',          '🔦', 50,   50,   0, 'Lighting', 'all_year',      6,  6,   'global', 220, 0, 0, 35),
('Smart LED Bulb 10W',           '💡', 10,   10,   1, 'Lighting', 'all_year',      5,  6,   'US,CA,GB,DE,JP,KR,AU', 220, 0, 0, 40),
('Halogen Downlight 50W',        '💡', 50,   50,   0, 'Lighting', 'all_year',      4,  5,   'AU,GB,US', 220, 0, 0, 40),
('LED Strip Lights (5m)',        '🌈', 25,   30,   0, 'Lighting', 'all_year',      4,  4,   'global', 220, 0, 0, 45),

-- ═══════ KITCHEN (23) ═══════
('Refrigerator Small (150L)',    '🧊', 100,  500,  3, 'Kitchen', 'all_year',       24, 24,  'global', 220, 0, 0, 10),
('Refrigerator Large (400L)',    '🧊', 200,  800,  5, 'Kitchen', 'all_year',       24, 24,  'global', 220, 0, 0, 15),
('Refrigerator Inverter (300L)', '🧊', 80,   350,  2, 'Kitchen', 'all_year',       24, 24,  'PK,IN,JP,KR,DE', 220, 1, 40, 15),
('Deep Freezer',                 '🧊', 150,  600,  3, 'Kitchen', 'all_year',       24, 24,  'PK,SA,AE,US', 220, 0, 0, 30),
('Microwave Oven',               '🍳', 1200, 1500, 3, 'Kitchen', 'all_year',       0.5, 0.5,'global', 220, 0, 0, 30),
('Electric Kettle (220V)',       '☕', 2200, 2500, 0, 'Kitchen', 'all_year',       0.3, 0.5,'PK,IN,BD,GB,DE,FR,AU,SA,AE,EG,TR,KR,MY,TH,VN,ID,PH,NG,ZA,CN', 220, 0, 0, 20),
('Electric Kettle (110V)',       '☕', 1500, 1800, 0, 'Kitchen', 'all_year',       0.5, 0.5,'US,CA,JP,MX,BR', 110, 0, 0, 20),
('Toaster 2-Slice',             '🍞', 800,  1000, 0, 'Kitchen', 'all_year',       0.2, 0.2,'global', 220, 0, 0, 35),
('Electric Oven / Baking Oven',  '🍳', 2000, 2400, 5, 'Kitchen', 'all_year',       1,  1.5,'global', 220, 0, 0, 50),
('Induction Cooktop',            '🍳', 2000, 2400, 2, 'Kitchen', 'all_year',       1.5, 2, 'IN,PK,CN,JP,KR,DE', 220, 0, 0, 40),
('Rice Cooker',                  '🍚', 700,  900,  5, 'Kitchen', 'all_year',       1,  1,  'JP,KR,CN,TH,PH,VN,MY,ID,BD,PK,IN', 220, 0, 0, 25),
('Blender / Juicer',             '🥤', 400,  800,  0, 'Kitchen', 'all_year',       0.3, 0.3,'global', 220, 0, 0, 35),
('Food Processor',               '🍽️', 600,  1000, 0, 'Kitchen', 'all_year',       0.3, 0.3,'US,CA,GB,AU,DE,FR', 220, 0, 0, 45),
('Dishwasher',                   '🍽️', 1800, 2200, 3, 'Kitchen', 'all_year',       1.5, 1.5,'US,CA,GB,DE,FR,AU,JP,KR,SA,AE', 220, 0, 0, 50),
('Water Dispenser (Hot & Cold)', '🚰', 500,  600,  5, 'Kitchen', 'all_year',       8,  8,  'PK,SA,AE,EG,NG', 220, 0, 0, 25),
('Roti Maker / Chapati Maker',   '🫓', 900,  1100, 0, 'Kitchen', 'all_year',       0.5, 0.5,'PK,IN', 220, 0, 0, 40),
('Coffee Machine / Espresso',    '☕', 1000, 1500, 3, 'Kitchen', 'all_year',       0.5, 0.5,'US,CA,GB,DE,FR,AU,BR', 220, 0, 0, 40),
('Garbage Disposal',             '♻️', 500,  1500, 0, 'Kitchen', 'all_year',       0.1, 0.1,'US,CA', 110, 0, 0, 55),
('Electric Stove / Hot Plate',   '🔥', 1500, 1800, 0, 'Kitchen', 'all_year',       2,  2,  'global', 220, 0, 0, 40),
('Air Fryer',                    '🍟', 1500, 1800, 0, 'Kitchen', 'all_year',       0.5, 0.5,'global', 220, 0, 0, 40),
('Water Purifier / RO System',   '💧', 60,   80,   5, 'Kitchen', 'all_year',       3,  3,  'PK,IN,BD,EG,NG,VN', 220, 0, 0, 20),
('Electric Pressure Cooker',     '🍲', 1000, 1200, 5, 'Kitchen', 'all_year',       1,  1,  'US,CA,CN,IN,PK', 220, 0, 0, 40),
('Sandwich Maker / Grill',       '🥪', 750,  900,  0, 'Kitchen', 'all_year',       0.3, 0.3,'global', 220, 0, 0, 45),

-- ═══════ LAUNDRY (9) ═══════
('Washing Machine Semi-Auto',    '🧺', 400,  800,  0, 'Laundry', 'all_year',       1,  1,  'PK,IN,BD,EG,NG,PH,VN', 220, 0, 0, 30),
('Washing Machine Auto (Top)',   '🧺', 500,  1200, 3, 'Laundry', 'all_year',       1,  1,  'global', 220, 0, 0, 35),
('Front Load Washer',            '🧺', 600,  1500, 3, 'Laundry', 'all_year',       1.5, 1.5,'US,CA,GB,DE,FR,AU,JP,KR', 220, 0, 0, 40),
('Clothes Dryer',                '👔', 3000, 3500, 5, 'Laundry', 'all_year',       1,  1.5,'US,CA,GB,AU,DE,FR', 220, 0, 0, 50),
('Iron',                         '👕', 1200, 1500, 0, 'Laundry', 'all_year',       0.5, 0.5,'global', 220, 0, 0, 30),
('Steam Iron (Heavy Duty)',      '👕', 2200, 2600, 0, 'Laundry', 'all_year',       0.5, 0.5,'GB,DE,FR,US,CA,AU', 220, 0, 0, 40),
('Garment Steamer',              '👔', 1500, 1800, 0, 'Laundry', 'all_year',       0.3, 0.3,'US,JP,KR', 220, 0, 0, 50),
('Spin Dryer',                   '🌀', 300,  600,  0, 'Laundry', 'all_year',       0.5, 0.5,'PK,IN,BD,PH', 220, 0, 0, 35),
('Washer-Dryer Combo',           '🧺', 2200, 3000, 5, 'Laundry', 'all_year',       2,  2,  'GB,DE,FR,AU,JP,KR', 220, 0, 0, 45),

-- ═══════ ELECTRONICS (15) ═══════
('TV LED 32"',                   '📺', 40,   60,   1, 'Electronics', 'all_year',    6,  6,  'global', 220, 0, 0, 15),
('TV LED 55"',                   '📺', 80,   120,  2, 'Electronics', 'all_year',    5,  5,  'global', 220, 0, 0, 20),
('TV LED 65"',                   '📺', 120,  180,  3, 'Electronics', 'all_year',    5,  5,  'US,CA,AU,SA,AE,JP,KR', 220, 0, 0, 30),
('Laptop Computer',              '💻', 65,   90,   2, 'Electronics', 'all_year',    8,  8,  'global', 220, 0, 0, 15),
('Desktop Computer + Monitor',   '🖥️', 250,  400,  5, 'Electronics', 'all_year',    6,  6,  'global', 220, 0, 0, 25),
('WiFi Router',                  '📶', 15,   20,   15,'Electronics', 'all_year',    24, 24, 'global', 220, 0, 0, 10),
('Gaming Console',               '🎮', 200,  250,  10,'Electronics', 'all_year',    3,  4,  'US,CA,JP,KR,GB,AU,DE,FR', 220, 0, 0, 50),
('Home Theater / Sound System',  '🔊', 300,  450,  5, 'Electronics', 'all_year',    3,  3,  'global', 220, 0, 0, 50),
('Security Camera System (4ch)', '📹', 50,   60,   50,'Electronics', 'all_year',    24, 24, 'global', 220, 0, 0, 30),
('Printer (Inkjet/Laser)',       '🖨️', 150,  400,  5, 'Electronics', 'all_year',    1,  1,  'global', 220, 0, 0, 50),
('Smartphone Charger',           '📱', 20,   25,   1, 'Electronics', 'all_year',    3,  3,  'global', 220, 0, 0, 10),
('UPS / Inverter Charger',       '🔋', 600,  900,  10,'Electronics', 'all_year',    8,  8,  'PK,IN,BD,NG,EG', 220, 0, 0, 15),
('Set-Top Box / Streaming',      '📡', 15,   20,   5, 'Electronics', 'all_year',    5,  5,  'global', 220, 0, 0, 30),
('Computer Monitor 27"',         '🖥️', 40,   50,   1, 'Electronics', 'all_year',    6,  6,  'global', 220, 0, 0, 25),
('Tablet Charger',               '🔌', 30,   35,   1, 'Electronics', 'all_year',    2,  2,  'global', 220, 0, 0, 15),

-- ═══════ UTILITY (15) ═══════
('Water Pump 1 HP',              '💧', 750,  2250, 0, 'Utility', 'all_year',       2,  1.5,'PK,IN,BD,EG,SA,NG', 220, 0, 0, 20),
('Submersible Pump 2 HP',        '💧', 1500, 4500, 0, 'Utility', 'all_year',       2,  2,  'PK,IN,SA', 220, 0, 0, 30),
('Vacuum Cleaner',               '🧹', 1200, 1800, 0, 'Utility', 'all_year',       0.5, 0.5,'global', 220, 0, 0, 45),
('Robot Vacuum',                 '🤖', 60,   80,   5, 'Utility', 'all_year',       2,  2,  'US,JP,KR,DE,CN', 220, 0, 0, 55),
('Hair Dryer',                   '💇', 1800, 2200, 0, 'Utility', 'all_year',       0.3, 0.3,'global', 220, 0, 0, 45),
('Dehumidifier',                 '💨', 500,  600,  5, 'Utility', 'summer,monsoon', 6,  2,  'US,GB,JP,MY,TH', 220, 0, 0, 45),
('Humidifier',                   '💨', 40,   50,   3, 'Utility', 'winter',         0,  8,  'US,CA,JP,KR,CN', 220, 0, 0, 50),
('Garage Door Opener',           '🚪', 500,  1500, 5, 'Utility', 'all_year',       0.1, 0.1,'US,CA,AU', 110, 0, 0, 55),
('EV Charger Level 2',           '🔌', 7200, 7500, 5, 'Utility', 'all_year',       4,  4,  'US,CA,GB,DE,FR,AU,JP,KR,CN', 220, 0, 0, 60),
('Pool Pump',                    '🏊', 1500, 3000, 0, 'Utility', 'summer',         6,  2,  'US,AU,SA,AE,BR', 220, 0, 0, 60),
('Sewing Machine',               '🧵', 100,  150,  0, 'Utility', 'all_year',       2,  2,  'PK,IN,BD,VN,TH', 220, 0, 0, 55),
('Bidet Toilet Seat (Heated)',   '🚽', 1300, 1500, 5, 'Utility', 'all_year',       2,  2,  'JP,KR', 220, 0, 0, 50),
('Mosquito Repellent Device',    '🦟', 5,    5,    5, 'Utility', 'summer,monsoon', 10, 0,  'PK,IN,BD,TH,PH,VN,MY,ID,NG', 220, 0, 0, 20),
('Pressure Washer',              '🔫', 1800, 3600, 0, 'Utility', 'all_year',       0.5, 0.5,'US,CA,AU,DE,GB', 220, 0, 0, 65),
('Ceiling Fan Regulator',        '🎛️', 5,    5,    2, 'Utility', 'all_year',       12, 2,  'PK,IN,BD', 220, 0, 0, 15),

-- ═══════ COMFORT (8) ═══════
('Room Cooler Inverter',         '❄️', 120,  180,  0, 'Comfort', 'summer',         10, 0,  'PK,IN', 220, 1, 60, 25),
('Portable Ceramic Heater',      '🔥', 1000, 1200, 0, 'Comfort', 'winter',         0,  5,  'US,CA,GB', 220, 0, 0, 40),
('Electric Fireplace Display',   '🔥', 1500, 1800, 3, 'Comfort', 'winter',         0,  5,  'US,CA,GB,AU', 220, 0, 0, 60),
('Heated Towel Rail',            '🛁', 100,  120,  0, 'Comfort', 'winter',         0,  6,  'GB,AU', 220, 0, 0, 70),
-- Kotatsu already in Heating category
('Massage Chair',                '💆', 200,  300,  5, 'Comfort', 'all_year',        1,  1,  'JP,KR,US,CN', 220, 0, 0, 75),
('Aroma Diffuser / Humidifier',  '🌸', 20,   25,   0, 'Comfort', 'all_year',        5,  5,  'global', 220, 0, 0, 65),
('Electric Foot Warmer',         '🦶', 100,  120,  0, 'Comfort', 'winter',          0,  4,  'JP,KR,CN', 220, 0, 0, 65);

-- ============================================================
-- 117 total appliances across 8 categories for 25 countries
-- ============================================================
