<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
set_security_headers();

$db = getDB();
$site_name = get_system_setting('site_name', 'SolarGlobal');

// Fetch dynamic pricing from admin settings
$installer_fee    = (float)get_system_setting('installer_monthly_fee', '1.00');
$trial_enabled    = (int)get_system_setting('installer_free_trial_enabled', '1');
$trial_days       = (int)get_system_setting('installer_free_trial_days', '7');
$currency         = strtoupper(get_system_setting('payment_currency', 'usd'));
$fee_display      = $installer_fee > 0 ? '$' . number_format($installer_fee, 2) : 'FREE';

// Dynamic stats
$total_installers  = (int)($db->query("SELECT COUNT(*) FROM installers WHERE status IN ('active','approved')")->fetchColumn() ?: 0);
$total_installations = (int)($db->query("SELECT COALESCE(SUM(completed_installations), 0) FROM installers WHERE status IN ('active','approved')")->fetchColumn() ?: 0);
$avg_rating_all    = round((float)($db->query("SELECT COALESCE(AVG(avg_rating), 0) FROM installers WHERE status IN ('active','approved') AND total_reviews > 0")->fetchColumn() ?: 0), 1);
$total_cities      = (int)($db->query("SELECT COUNT(DISTINCT city) FROM installers WHERE status IN ('active','approved') AND city IS NOT NULL AND city != ''")->fetchColumn() ?: 0);

// Real testimonials from installer_reviews (approved, rating >= 4)
$testimonials = $db->query("
    SELECT ir.rating, ir.review_text, ir.reviewer_name,
           i.company_name, i.city, i.country_code
    FROM installer_reviews ir
    JOIN installers i ON ir.installer_id = i.id
    WHERE ir.status = 'approved' AND ir.rating >= 4
    ORDER BY ir.rating DESC, ir.created_at DESC
    LIMIT 3
")->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'Become a Solar Installer';
$page_description = 'Join as a certified solar installer. Get listed, receive customer leads, and grow your solar installation business. Apply today.';
require_once 'includes/header.php';
?>

<style>
.installer-hero {
    background: linear-gradient(135deg, #0F172A 0%, #1E293B 40%, #0F172A 80%);
    position: relative;
    padding: 100px 20px;
    text-align: center;
    color: #fff;
    overflow: hidden;
}
.installer-hero::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 600px;
    height: 600px;
    background: radial-gradient(circle, rgba(245,158,11,0.18) 0%, transparent 70%);
    border-radius: 50%;
}
.installer-hero::after {
    content: '';
    position: absolute;
    bottom: -30%;
    left: -10%;
    width: 400px;
    height: 400px;
    background: radial-gradient(circle, rgba(245,158,11,0.12) 0%, transparent 70%);
    border-radius: 50%;
}
.installer-hero h1 {
    font-size: 3rem;
    font-weight: 800;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
}
.installer-hero h1 span {
    color: #F59E0B;
}
.installer-hero p {
    font-size: 1.25rem;
    max-width: 640px;
    margin: 0 auto 40px;
    opacity: 0.9;
    position: relative;
    z-index: 1;
    line-height: 1.7;
}
.hero-buttons {
    display: flex;
    gap: 16px;
    justify-content: center;
    flex-wrap: wrap;
    position: relative;
    z-index: 1;
}
.btn-primary-installer {
    background: #F59E0B;
    color: #0F172A;
    padding: 16px 36px;
    border-radius: 8px;
    font-weight: 700;
    font-size: 1.1rem;
    text-decoration: none;
    transition: transform 0.2s, box-shadow 0.2s;
    box-shadow: 0 4px 14px rgba(245,158,11,0.4);
    display: inline-block;
}
.btn-primary-installer:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(245,158,11,0.5);
}
.btn-secondary-installer {
    background: rgba(255,255,255,0.08);
    color: #fff;
    padding: 16px 36px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 1.1rem;
    text-decoration: none;
    border: 2px solid rgba(245,158,11,0.4);
    transition: background 0.2s, border-color 0.2s;
    display: inline-block;
}
.btn-secondary-installer:hover {
    background: rgba(245,158,11,0.1);
    border-color: rgba(245,158,11,0.7);
}

/* Stats Bar */
.stats-bar {
    background: #F59E0B;
    padding: 40px 20px;
    display: flex;
    justify-content: center;
    gap: 60px;
    flex-wrap: wrap;
}
.stat-item {
    text-align: center;
    color: #0F172A;
}
.stat-number {
    font-size: 2.5rem;
    font-weight: 800;
    color: #0F172A;
    display: block;
}
.stat-label {
    font-size: 0.95rem;
    opacity: 0.75;
    margin-top: 4px;
    font-weight: 600;
}

/* Section Common */
.installer-section {
    padding: 80px 20px;
    max-width: 1200px;
    margin: 0 auto;
}
.installer-section-dark {
    background: #f8fafc;
}
.section-title {
    text-align: center;
    font-size: 2.2rem;
    font-weight: 800;
    color: #0F172A;
    margin-bottom: 16px;
}
.section-subtitle {
    text-align: center;
    font-size: 1.1rem;
    color: #64748b;
    max-width: 600px;
    margin: 0 auto 50px;
    line-height: 1.6;
}

/* How It Works */
.steps-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 30px;
}
.step-card {
    text-align: center;
    padding: 30px 20px;
    position: relative;
    opacity: 0;
    transform: translateY(30px);
}
.step-card.animated {
    opacity: 1;
    transform: translateY(0);
    transition: opacity 0.6s ease, transform 0.6s ease;
}
.step-icon {
    width: 72px;
    height: 72px;
    background: linear-gradient(135deg, #0F172A, #1E293B);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    margin: 0 auto 16px;
    box-shadow: 0 4px 16px rgba(15,23,42,0.15);
}
.step-number {
    position: absolute;
    top: 10px;
    left: 50%;
    transform: translateX(-50%);
    width: 28px;
    height: 28px;
    background: #F59E0B;
    color: #0F172A;
    border-radius: 50%;
    font-size: 0.8rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
}
.step-card h3 {
    font-size: 1.1rem;
    font-weight: 700;
    color: #0F172A;
    margin-bottom: 8px;
}
.step-card p {
    font-size: 0.95rem;
    color: #64748b;
    line-height: 1.6;
}

/* Benefits */
.benefits-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 24px;
}
.benefit-card {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 28px;
    transition: transform 0.3s, box-shadow 0.3s;
    opacity: 0;
    transform: translateY(20px);
}
.benefit-card.animated {
    opacity: 1;
    transform: translateY(0);
    transition: opacity 0.5s ease, transform 0.5s ease;
}
.benefit-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 30px rgba(0,0,0,0.08);
    border-color: #F59E0B;
}
.benefit-icon {
    width: 48px;
    height: 48px;
    background: rgba(245,158,11,0.1);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    margin-bottom: 14px;
}
.benefit-card h3 {
    font-size: 1.1rem;
    font-weight: 700;
    color: #0F172A;
    margin-bottom: 8px;
}
.benefit-card p {
    font-size: 0.9rem;
    color: #64748b;
    line-height: 1.6;
}

/* Testimonials */
.testimonials-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 24px;
}
.testimonial-card {
    background: #fff;
    border-radius: 12px;
    padding: 28px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.06);
    border: 1px solid #e2e8f0;
    position: relative;
}
.testimonial-card::before {
    content: "\201C";
    position: absolute;
    top: 16px;
    left: 20px;
    font-size: 3rem;
    color: #F59E0B;
    opacity: 0.3;
    font-family: Georgia, serif;
    line-height: 1;
}
.testimonial-stars {
    color: #F59E0B;
    font-size: 0.9rem;
    margin-bottom: 12px;
    letter-spacing: 2px;
}
.testimonial-card p {
    font-size: 0.95rem;
    color: #475569;
    line-height: 1.7;
    font-style: italic;
    margin-bottom: 16px;
}
.testimonial-author {
    display: flex;
    align-items: center;
    gap: 12px;
}
.testimonial-avatar {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: linear-gradient(135deg, #0F172A, #F59E0B);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-weight: 700;
    font-size: 1rem;
}
.testimonial-name {
    font-weight: 700;
    color: #0F172A;
    font-size: 0.9rem;
}
.testimonial-role {
    font-size: 0.8rem;
    color: #94a3b8;
}

/* Pricing */
.pricing-card {
    max-width: 440px;
    margin: 0 auto;
    background: #fff;
    border-radius: 16px;
    padding: 40px;
    text-align: center;
    box-shadow: 0 8px 30px rgba(0,0,0,0.1);
    border: 2px solid #F59E0B;
    position: relative;
    overflow: hidden;
}
.pricing-badge {
    position: absolute;
    top: 20px;
    right: -32px;
    background: #F59E0B;
    color: #0F172A;
    font-size: 0.7rem;
    font-weight: 700;
    padding: 5px 40px;
    transform: rotate(45deg);
    text-transform: uppercase;
    letter-spacing: 1px;
}
.pricing-price {
    font-size: 4rem;
    font-weight: 800;
    color: #0F172A;
}
.pricing-price span {
    font-size: 1.2rem;
    font-weight: 400;
    color: #64748b;
}
.pricing-tagline {
    font-size: 1rem;
    color: #F59E0B;
    font-weight: 600;
    margin-top: 4px;
    margin-bottom: 8px;
}
.pricing-features {
    list-style: none;
    padding: 0;
    margin: 30px 0;
    text-align: left;
}
.pricing-features li {
    padding: 10px 0;
    border-bottom: 1px solid #f1f5f9;
    font-size: 0.95rem;
    color: #475569;
}
.pricing-features li::before {
    content: "\2713";
    color: #F59E0B;
    font-weight: 700;
    margin-right: 10px;
}

/* FAQ */
.faq-list {
    max-width: 800px;
    margin: 0 auto;
}
.faq-item {
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    margin-bottom: 12px;
    overflow: hidden;
    background: #fff;
}
.faq-question {
    padding: 20px 24px;
    font-weight: 600;
    color: #0F172A;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    user-select: none;
    transition: background 0.2s;
}
.faq-question:hover {
    background: #f8fafc;
}
.faq-question::after {
    content: "+";
    font-size: 1.4rem;
    font-weight: 300;
    color: #F59E0B;
    transition: transform 0.3s;
}
.faq-item.active .faq-question::after {
    transform: rotate(45deg);
}
.faq-answer {
    padding: 0 24px;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease, padding 0.3s;
    color: #64748b;
    line-height: 1.7;
    font-size: 0.95rem;
}
.faq-item.active .faq-answer {
    padding: 0 24px 20px;
    max-height: 300px;
}

/* Final CTA */
.final-cta {
    background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
    padding: 80px 20px;
    text-align: center;
    color: #fff;
    position: relative;
    overflow: hidden;
}
.final-cta::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 500px;
    height: 500px;
    background: radial-gradient(circle, rgba(245,158,11,0.08) 0%, transparent 70%);
    border-radius: 50%;
}
.final-cta h2 {
    font-size: 2.2rem;
    font-weight: 800;
    margin-bottom: 16px;
    position: relative;
}
.final-cta p {
    font-size: 1.1rem;
    opacity: 0.85;
    margin-bottom: 30px;
    position: relative;
}

@media (max-width: 768px) {
    .installer-hero h1 { font-size: 2rem; }
    .installer-hero { padding: 60px 20px; }
    .stats-bar { gap: 30px; padding: 30px 20px; }
    .stat-number { font-size: 1.8rem; }
    .section-title { font-size: 1.7rem; }
    .benefits-grid { grid-template-columns: 1fr; }
    .testimonials-grid { grid-template-columns: 1fr; }
    .pricing-price { font-size: 3rem; }
    .final-cta h2 { font-size: 1.6rem; }
}
</style>

<!-- Hero Section -->
<section class="installer-hero">
    <h1>Grow Your <span>Solar Installation</span> Business</h1>
    <p>Connect with homeowners and businesses looking for trusted solar installers. Get quality leads, build your reputation, and scale your installation company.</p>
    <div class="hero-buttons">
        <a href="<?= BASE_URL ?>installer/register.php" class="btn-primary-installer">Register as Installer</a>
        <a href="#how-it-works" class="btn-secondary-installer">Learn More</a>
    </div>
</section>

<!-- Stats Bar -->
<section class="stats-bar">
    <div class="stat-item">
        <span class="stat-number" data-target="<?= max($total_installers, 1) ?>">0</span>
        <span class="stat-label">Verified Installers</span>
    </div>
    <div class="stat-item">
        <span class="stat-number" data-target="<?= max($total_installations, 1) ?>">0</span>
        <span class="stat-label">Installations Completed</span>
    </div>
    <div class="stat-item">
        <span class="stat-number" data-target="<?= (int)($avg_rating_all * 10) ?>" data-suffix="&#9733;">0</span>
        <span class="stat-label">Average Rating</span>
    </div>
    <div class="stat-item">
        <span class="stat-number" data-target="<?= max($total_cities, 1) ?>">0</span>
        <span class="stat-label">Cities Covered</span>
    </div>
</section>

<!-- How It Works -->
<section class="installer-section-dark" id="how-it-works">
    <div class="installer-section">
        <h2 class="section-title">How It Works</h2>
        <p class="section-subtitle">Start receiving installation leads in four simple steps</p>
        <div class="steps-grid">
            <div class="step-card">
                <span class="step-number">1</span>
                <span class="step-icon">&#128221;</span>
                <h3>Register Your Business</h3>
                <p>Create your installer profile with your business details, service areas, certifications, and portfolio.</p>
            </div>
            <div class="step-card">
                <span class="step-number">2</span>
                <span class="step-icon">&#9989;</span>
                <h3>Get Verified</h3>
                <p>Our team verifies your credentials and certifications to ensure quality for our customers.</p>
            </div>
            <div class="step-card">
                <span class="step-number">3</span>
                <span class="step-icon">&#128232;</span>
                <h3>Receive Leads</h3>
                <p>Get matched with customers in your area who need solar installation services.</p>
            </div>
            <div class="step-card">
                <span class="step-number">4</span>
                <span class="step-icon">&#128640;</span>
                <h3>Grow Your Business</h3>
                <p>Complete installations, collect reviews, and watch your business expand through referrals.</p>
            </div>
        </div>
    </div>
</section>

<!-- Benefits -->
<section class="installer-section">
    <h2 class="section-title">Why Installers Choose <?= sanitize($site_name) ?></h2>
    <p class="section-subtitle">Everything you need to grow your solar installation business</p>
    <div class="benefits-grid">
        <div class="benefit-card">
            <span class="benefit-icon">&#128101;</span>
            <h3>Quality Customer Leads</h3>
            <p>Receive pre-qualified leads from customers who are actively looking for solar installation in your service area. No cold calling needed.</p>
        </div>
        <div class="benefit-card">
            <span class="benefit-icon">&#11088;</span>
            <h3>Reviews & Rating System</h3>
            <p>Build trust with a transparent review system. Happy customers leave ratings that help you stand out and win more projects.</p>
        </div>
        <div class="benefit-card">
            <span class="benefit-icon">&#128247;</span>
            <h3>Portfolio Showcase</h3>
            <p>Display your best completed installations with photos, system details, and customer testimonials to showcase your expertise.</p>
        </div>
        <div class="benefit-card">
            <span class="benefit-icon">&#128205;</span>
            <h3>Location-Based Matching</h3>
            <p>Customers near your service area are automatically matched with your business, driving local leads and reducing travel costs.</p>
        </div>
        <div class="benefit-card">
            <span class="benefit-icon">&#128179;</span>
            <h3>Affordable Subscription</h3>
            <p>Just <?= $fee_display ?>/month with a <?= $trial_days ?>-day free trial. Stripe-secured billing, cancel anytime. Zero risk to get started.</p>
        </div>
        <div class="benefit-card">
            <span class="benefit-icon">&#128200;</span>
            <h3>Business Analytics Dashboard</h3>
            <p>Track your leads, conversion rates, revenue, and customer satisfaction with a comprehensive analytics dashboard built for installers.</p>
        </div>
    </div>
</section>

<!-- Testimonials (only shown if real approved reviews exist) -->
<?php if (!empty($testimonials)): ?>
<section class="installer-section-dark">
    <div class="installer-section">
        <h2 class="section-title">Trusted by Solar Installers</h2>
        <p class="section-subtitle">Hear from installers who have grown their business with <?= sanitize($site_name) ?></p>
        <div class="testimonials-grid">
            <?php foreach ($testimonials as $t):
                $name = sanitize($t['reviewer_name'] ?: 'Installer');
                $initials = '';
                $name_parts = explode(' ', trim($name));
                foreach ($name_parts as $part) { if (!empty($part)) $initials .= strtoupper($part[0]); }
                $initials = substr($initials, 0, 2);
                $location = sanitize(trim(($t['company_name'] ? $t['company_name'] . ', ' : '') . ($t['city'] ?: ($t['country_code'] ?: ''))));
                $stars = str_repeat('&#9733;', (int)$t['rating']) . str_repeat('&#9734;', 5 - (int)$t['rating']);
                $text = sanitize(mb_strimwidth($t['review_text'], 0, 200, '...'));
            ?>
            <div class="testimonial-card">
                <div class="testimonial-stars"><?= $stars ?></div>
                <p>"<?= $text ?>"</p>
                <div class="testimonial-author">
                    <div class="testimonial-avatar"><?= $initials ?></div>
                    <div>
                        <div class="testimonial-name"><?= $name ?></div>
                        <?php if ($location): ?><div class="testimonial-role"><?= $location ?></div><?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Pricing -->
<section class="installer-section">
    <h2 class="section-title">Simple, Transparent Pricing</h2>
    <p class="section-subtitle">No hidden fees, no surprises. Start growing your business today.</p>
    <div class="pricing-card">
        <?php if ($trial_enabled): ?>
            <div class="pricing-badge"><?= $trial_days ?>-Day Free Trial</div>
        <?php else: ?>
            <div class="pricing-badge">Best Value</div>
        <?php endif; ?>
        <div class="pricing-price"><?= $fee_display ?><span>/month</span></div>
        <?php if ($trial_enabled): ?>
            <div class="pricing-tagline"><?= $trial_days ?>-day free trial &middot; Cancel anytime</div>
        <?php else: ?>
            <div class="pricing-tagline">Simple monthly subscription</div>
        <?php endif; ?>
        <ul class="pricing-features">
            <li>Full installer profile & portfolio</li>
            <li>Location-based lead matching</li>
            <li>Review & rating system</li>
            <li>Business analytics dashboard</li>
            <li>Customer messaging system</li>
            <li>Certification badge display</li>
            <li><?= get_system_setting('retention_plan_basic_months', '6') ?> months data retention (included)</li>
            <li>No commissions on installations</li>
            <li>Stripe-secured automatic billing</li>
        </ul>
        <?php if ($trial_enabled): ?>
            <a href="<?= BASE_URL ?>installer/register.php" class="btn-primary-installer">Start <?= $trial_days ?>-Day Free Trial</a>
            <p style="font-size:0.82rem; color:#94A3B8; margin-top:12px;">No credit card required for trial. Pay <?= $fee_display ?>/mo after trial ends.</p>
        <?php else: ?>
            <a href="<?= BASE_URL ?>installer/register.php" class="btn-primary-installer">Register & Subscribe</a>
        <?php endif; ?>
    </div>
</section>

<!-- FAQ -->
<section class="installer-section-dark">
    <div class="installer-section">
        <h2 class="section-title">Frequently Asked Questions</h2>
        <p class="section-subtitle">Everything you need to know about the installer program</p>
        <div class="faq-list">
            <div class="faq-item">
                <div class="faq-question">How do I register as an installer?</div>
                <div class="faq-answer">Click the "Register as Installer" button to start. You'll need to provide your business details, service areas, relevant certifications, and upload photos of past installations. Our team reviews applications within 24-48 hours.</div>
            </div>
            <div class="faq-item">
                <div class="faq-question">How much does it cost?</div>
                <div class="faq-answer"><?= sanitize($site_name) ?> offers a <?= $trial_days ?>-day free trial so you can explore the platform risk-free. After the trial, the subscription is just <?= $fee_display ?>/month, billed securely via Stripe. No commissions on installations, cancel anytime.</div>
            </div>
            <div class="faq-item">
                <div class="faq-question">What certifications do I need?</div>
                <div class="faq-answer">Requirements vary by region, but we generally look for licensed electricians with solar installation experience. Industry certifications (such as NABCEP, CEC, or equivalent local certifications) are preferred but not always required. We review each application individually.</div>
            </div>
            <div class="faq-item">
                <div class="faq-question">How do I receive customer leads?</div>
                <div class="faq-answer">When a customer in your service area uses our platform to find an installer, you'll receive a notification via email and your dashboard. You can then view the project details and respond with a quote. Customers are matched based on location, ratings, and specialization.</div>
            </div>
            <div class="faq-item">
                <div class="faq-question">Can I set my own pricing?</div>
                <div class="faq-answer">Absolutely. You have full control over your pricing. You can set your rate per kW installed, offer package deals, and provide custom quotes for each project. Our platform simply connects you with customers; the pricing is entirely up to you.</div>
            </div>
        </div>
    </div>
</section>

<!-- Final CTA -->
<section class="final-cta">
    <h2>Ready to Grow Your Installation Business?</h2>
    <p>Join <?= $total_installers ?>+ verified installers already thriving on <?= sanitize($site_name) ?>. Start your <?= $trial_days ?>-day free trial today.</p>
    <a href="<?= BASE_URL ?>installer/register.php" class="btn-primary-installer">Start Free Trial</a>
</section>

<script>
// Counter Animation
function animateCounters() {
    const counters = document.querySelectorAll('.stat-number[data-target]');
    counters.forEach(counter => {
        const target = parseFloat(counter.getAttribute('data-target'));
        const suffix = counter.getAttribute('data-suffix') || '';
        const duration = 2000;
        const increment = target / (duration / 16);
        let current = 0;
        const isRating = suffix !== '';
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            if (isRating) {
                counter.textContent = (current / 10).toFixed(1) + ' ★';
            } else {
                let display = Math.floor(current).toLocaleString();
                if (target >= 50) display += '+';
                counter.textContent = display;
            }
        }, 16);
    });
}

// Intersection Observer for counters
const statsBar = document.querySelector('.stats-bar');
let counted = false;
const observer = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting && !counted) {
        counted = true;
        animateCounters();
    }
}, { threshold: 0.5 });
if (statsBar) observer.observe(statsBar);

// Animate elements on scroll
function animateOnScroll() {
    const elements = document.querySelectorAll('.step-card, .benefit-card');
    const scrollObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                setTimeout(() => {
                    entry.target.classList.add('animated');
                }, index * 100);
                scrollObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15 });
    elements.forEach(el => scrollObserver.observe(el));
}
animateOnScroll();

// FAQ Accordion
document.querySelectorAll('.faq-question').forEach(question => {
    question.addEventListener('click', () => {
        const item = question.parentElement;
        const isActive = item.classList.contains('active');
        document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('active'));
        if (!isActive) item.classList.add('active');
    });
});

// Smooth scroll for Learn More button
document.querySelector('a[href="#how-it-works"]')?.addEventListener('click', function(e) {
    e.preventDefault();
    document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
});
</script>

<?php require_once 'includes/footer.php'; ?>
