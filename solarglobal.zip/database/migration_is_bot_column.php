<?php
/**
 * Migration: Add is_bot column to visitor_stats
 * Run once: http://localhost/solarglobal/database/migration_is_bot_column.php
 */
require_once __DIR__ . '/../includes/db.php';

echo "<h2>Migration: Add is_bot column to visitor_stats</h2>";

try {
    $db = getDB();

    // Check if column exists
    $cols = $db->query("SHOW COLUMNS FROM visitor_stats LIKE 'is_bot'")->fetchAll();
    if (empty($cols)) {
        $db->exec("ALTER TABLE visitor_stats ADD COLUMN is_bot TINYINT(1) DEFAULT 0 AFTER session_id");
        $db->exec("CREATE INDEX idx_is_bot ON visitor_stats (is_bot)");
        echo "<p style='color:green;'>&#10004; Added is_bot column and index to visitor_stats</p>";

        // Backfill existing rows based on user_agent
        $db->exec("
            UPDATE visitor_stats SET is_bot = 1
            WHERE LOWER(user_agent) REGEXP 'bot|crawl|spider|slurp|google|bing|yahoo|baidu|yandex|semrush|ahrefs'
              OR device_type = 'bot'
        ");
        $count = $db->query("SELECT ROW_COUNT()")->fetchColumn();
        echo "<p style='color:green;'>&#10004; Backfilled $count rows as bot traffic</p>";
    } else {
        echo "<p style='color:blue;'>&#8505; is_bot column already exists</p>";
    }

    echo "<p style='color:green;font-weight:bold;'>Migration complete!</p>";
} catch (Exception $e) {
    echo "<p style='color:red;'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
