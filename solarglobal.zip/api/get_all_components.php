<?php
/**
 * API: Get All Components
 * Fetch all inverters, batteries, and panels for configurator
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

try {
    require_once '../includes/db.php';
    require_once '../includes/helpers.php';

    if (!rate_limit('api_components', 30, 60)) { respond_rate_limited(); }

    $db = getDB();
    
    // Fetch all active inverters
    $inverters_query = "
        SELECT 
            i.*,
            COALESCE(c.name, 'Unknown') as company_name,
            COALESCE(c.logo_path, '') as company_logo
        FROM inverters i
        LEFT JOIN companies c ON i.company_id = c.id
        WHERE i.is_active = 1
        ORDER BY i.output_power_w ASC
    ";
    $stmt = $db->query($inverters_query);
    $inverters = [];
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $pr = (int)($row['output_power_w'] ?? 0);
        $maxSolar = (int)($row['max_pv_input_w'] ?? 0);
        $inverters[] = [
            'id' => (int)$row['id'],
            'name' => $row['model'] ?? '',
            'model' => $row['model'] ?? '',
            'power_rating' => $pr,
            'output_power_w' => $pr,
            'max_load_watts' => $pr,
            'max_pv_input' => $maxSolar ?: (int)round($pr * 1.3),
            'max_pv_input_w' => $maxSolar,
            'max_solar_input' => $maxSolar,
            'min_pv_voltage' => (int)($row['min_pv_voltage'] ?? 0),
            'max_pv_voltage' => (int)($row['max_pv_voltage'] ?? 0),
            'input_voltage_min' => (int)($row['min_pv_voltage'] ?? 0),
            'input_voltage_max' => (int)($row['max_pv_voltage'] ?? 0),
            'battery_voltage_range' => $row['battery_voltage_range'] ?? '48V',
            'vdc_type' => $row['battery_voltage_range'] ?? '48V',
            'voltage_class' => $row['battery_voltage_range'] ?? '48V',
            'type' => $row['type'] ?? 'Hybrid',
            'has_bms' => ($row['bms'] === 'Yes') ? 1 : 0,
            'bms' => $row['bms'] ?? 'No',
            'mppt_count' => (int)($row['mppt_count'] ?? 1),
            'max_input_current' => (float)($row['max_input_current'] ?? 0),
            'efficiency' => (int)($row['max_efficiency'] ?? 90),
            'max_efficiency' => $row['max_efficiency'] ?? '90%',
            'price_usd' => (float)($row['unit_price_usd'] ?? 0),
            'unit_price_usd' => (float)($row['unit_price_usd'] ?? 0),
            'image_path' => get_image_url($row['image_path'] ?? ''),
            'company_id' => (int)($row['company_id'] ?? 0),
            'company_name' => $row['company_name'] ?? 'Unknown',
            'company' => $row['company'] ?? 'Unknown',
            'company_logo' => $row['company_logo'] ?? '',
            'warranty_years' => (int)($row['warranty_years'] ?? 2),
            'parallel_capable' => ($row['supports_parallel'] === 'Yes') ? 1 : 0,
            'supports_parallel' => $row['supports_parallel'] ?? 'No',
            'max_parallel_units' => (int)($row['max_parallel_units'] ?? 1),
        ];
    }
    
    // Fetch all active batteries
    $batteries_query = "
        SELECT 
            b.*,
            COALESCE(c.name, 'Unknown') as company_name,
            COALESCE(c.logo_path, '') as company_logo
        FROM batteries b
        LEFT JOIN companies c ON b.company_id = c.id
        WHERE b.is_active = 1
        ORDER BY b.capacity_ah ASC
    ";
    $stmt = $db->query($batteries_query);
    $batteries = [];
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $dodDecimal = (float)(($row['depth_of_discharge'] ?? 80) / 100);
        $batteries[] = [
            'id' => (int)$row['id'],
            'model' => $row['model'] ?? '',
            'name' => $row['model'] ?? '', // Backward compatibility
            'capacity_ah' => (int)($row['capacity_ah'] ?? 0),
            'capacity_wh' => (float)($row['capacity_wh'] ?? ($row['capacity_ah'] * ($row['nominal_voltage'] ?? 12))),
            'nominal_voltage' => (float)($row['nominal_voltage'] ?? 12),
            'voltage' => (float)($row['nominal_voltage'] ?? 12), // Backward compatibility
            'type' => $row['type'] ?? 'lithium',
            'battery_type' => $row['type'] ?? 'lithium', // Backward compatibility
            'is_bms' => ($row['is_bms'] === 'Yes') ? 1 : 0,
            'has_bms' => ($row['is_bms'] === 'Yes') ? 1 : 0, // Backward compatibility
            'dod' => $dodDecimal,
            'depth_of_discharge' => (int)round($dodDecimal * 100),
            'cycle_life' => (int)($row['cycle_life'] ?? 500),
            'price_unit_usd' => (float)($row['price_unit_usd'] ?? 0),
            'price_usd' => (float)($row['price_unit_usd'] ?? 0), // Backward compatibility
            'image_path' => get_image_url($row['image_path'] ?? ''),
            'company_id' => (int)($row['company_id'] ?? 0),
            'company_name' => $row['company_name'] ?? 'Unknown',
            'company_logo' => $row['company_logo'] ?? '',
            'country' => $row['country'] ?? '',
            'country_origin' => $row['country'] ?? '', // Backward compatibility
            'warranty_years' => (int)($row['warranty_years'] ?? 1)
        ];
    }
    
    // Fetch all active panels
    $panels_query = "
        SELECT 
            p.*,
            COALESCE(c.name, 'Unknown') as company_name,
            COALESCE(c.logo_path, '') as company_logo
        FROM panels p
        LEFT JOIN companies c ON p.company_id = c.id
        WHERE p.is_active = 1
        ORDER BY p.wattage ASC
    ";
    $stmt = $db->query($panels_query);
    $panels = [];
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $watt = (int)($row['wattage'] ?? 0);
        $panels[] = [
            'id' => (int)$row['id'],
            'name' => $row['name'] ?? '',
            'wattage' => $watt,
            'watt_peak' => $watt,
            'voc' => (float)($row['voc'] ?? 0),
            'vmp' => (float)($row['vmp'] ?? 0),
            'isc' => (float)($row['isc'] ?? 0),
            'imp' => (float)($row['imp'] ?? 0),
            'efficiency' => (float)($row['efficiency'] ?? 0),
            'type' => $row['type'] ?? 'mono',
            'panel_type' => $row['panel_type'] ?? $row['type'] ?? 'Mono',
            'price_usd' => (float)($row['price_usd'] ?? 0),
            'image_path' => get_image_url($row['image_path'] ?? ''),
            'company_id' => (int)($row['company_id'] ?? 0),
            'company_name' => $row['company_name'] ?? 'Unknown',
            'company_logo' => $row['company_logo'] ?? '',
            'warranty_years' => (int)($row['warranty_years'] ?? 10),
            'max_system_voltage' => (int)($row['max_system_voltage'] ?? 1000)
        ];
    }
    
    echo json_encode([
        'success' => true,
        'inverters' => $inverters,
        'batteries' => $batteries,
        'panels' => $panels,
        'counts' => [
            'inverters' => count($inverters),
            'batteries' => count($batteries),
            'panels' => count($panels)
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'fetch_failed',
        'message' => 'Failed to fetch components: ' . $e->getMessage()
    ]);
}
?>
