<?php
/**
 * Customer Authentication Middleware
 * Include at top of any customer-protected page
 * Supports: Google OAuth and Email OTP login
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('CUSTOMER_SESSION_TIMEOUT', 86400); // 24 hours

/**
 * Check if customer is logged in
 */
function is_customer_logged_in(): bool {
    return isset($_SESSION['customer_logged_in']) && $_SESSION['customer_logged_in'] === true;
}

/**
 * Get current customer ID
 */
function get_customer_id(): ?int {
    return $_SESSION['customer_id'] ?? null;
}

/**
 * Get current customer data from session
 */
function get_customer_session(): array {
    return [
        'id' => $_SESSION['customer_id'] ?? null,
        'name' => $_SESSION['customer_name'] ?? '',
        'email' => $_SESSION['customer_email'] ?? '',
        'avatar_url' => $_SESSION['customer_avatar'] ?? '',
        'country_code' => $_SESSION['customer_country'] ?? '',
    ];
}

/**
 * Require customer login - redirect if not authenticated
 */
function require_customer_login() {
    if (!is_customer_logged_in()) {
        $_SESSION['customer_redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: /solarglobal/customer/login.php');
        exit();
    }

    // Check session timeout
    if (isset($_SESSION['customer_last_activity'])) {
        if (time() - $_SESSION['customer_last_activity'] > CUSTOMER_SESSION_TIMEOUT) {
            customer_logout();
            header('Location: /solarglobal/customer/login.php?timeout=1');
            exit();
        }
    }

    $_SESSION['customer_last_activity'] = time();
}

/**
 * Login customer - set session variables
 */
function customer_login(array $customer): void {
    session_regenerate_id(true);
    $_SESSION['customer_logged_in'] = true;
    $_SESSION['customer_id'] = (int)$customer['id'];
    $_SESSION['customer_name'] = $customer['name'];
    $_SESSION['customer_email'] = $customer['email'];
    $_SESSION['customer_avatar'] = $customer['avatar_url'] ?? '';
    $_SESSION['customer_country'] = $customer['country_code'] ?? '';
    $_SESSION['customer_last_activity'] = time();

    // Update last login
    try {
        $db = getDB();
        $stmt = $db->prepare("UPDATE customers SET last_login_at = NOW() WHERE id = ?");
        $stmt->execute([$customer['id']]);
    } catch (Exception $e) {}
}

/**
 * Logout customer
 */
function customer_logout(): void {
    unset(
        $_SESSION['customer_logged_in'],
        $_SESSION['customer_id'],
        $_SESSION['customer_name'],
        $_SESSION['customer_email'],
        $_SESSION['customer_avatar'],
        $_SESSION['customer_country'],
        $_SESSION['customer_last_activity'],
        $_SESSION['customer_redirect_after_login']
    );
}

/**
 * Get full customer profile from database
 */
function get_customer_profile(?int $customer_id = null): ?array {
    $id = $customer_id ?? get_customer_id();
    if (!$id) return null;

    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM customers WHERE id = ? AND is_active = 1");
    $stmt->execute([$id]);
    $customer = $stmt->fetch();

    if ($customer) {
        unset($customer['password_hash'], $customer['otp_code'], $customer['otp_expires_at']);
    }

    return $customer ?: null;
}

/**
 * Generate a 6-digit OTP code
 */
function generate_otp(): string {
    return str_pad(random_int(100000, 999999), 6, '0', STR_PAD_LEFT);
}

/**
 * Send OTP email — uses centralized mailer with branded HTML template.
 */
function send_otp_email(string $email, string $otp, string $name = ''): bool {
    require_once __DIR__ . '/mailer.php';

    $siteName = get_system_setting('site_name', 'SolarGlobal');
    $greeting = $name ? "Hi " . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . "," : "Hi,";
    $subject  = "$siteName - Your Login Code";

    $innerHtml = <<<HTML
<p style="font-size:16px;color:#1E293B;margin:0 0 16px;">{$greeting}</p>
<p style="font-size:16px;color:#334155;margin:0 0 24px;">Your one-time login code is:</p>
<div style="text-align:center;margin:28px 0;">
    <span style="display:inline-block;font-size:36px;font-weight:bold;letter-spacing:10px;color:#F59E0B;background-color:#FFFBEB;padding:16px 32px;border-radius:12px;border:2px dashed #F59E0B;font-family:'Courier New',monospace;">{$otp}</span>
</div>
<p style="font-size:14px;color:#64748B;margin:0 0 8px;">&#9203; This code expires in <strong>10 minutes</strong>.</p>
<p style="font-size:14px;color:#64748B;margin:0;">If you didn't request this code, you can safely ignore this email. Someone may have entered your email address by mistake.</p>
HTML;

    return sg_send_email($email, $subject, $innerHtml);
}

/**
 * Verify Google ID token server-side
 * Returns user info array or null on failure
 */
function verify_google_token(string $id_token): ?array {
    $client_id = get_system_setting('google_oauth_client_id', '');
    if (empty($client_id)) return null;

    // Verify token via Google's tokeninfo endpoint
    $url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($id_token);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || !$response) return null;

    $data = json_decode($response, true);
    if (!$data || ($data['aud'] ?? '') !== $client_id) return null;

    return [
        'google_id' => $data['sub'] ?? '',
        'email' => $data['email'] ?? '',
        'name' => $data['name'] ?? '',
        'avatar_url' => $data['picture'] ?? '',
        'email_verified' => ($data['email_verified'] ?? 'false') === 'true' ? 1 : 0,
    ];
}
