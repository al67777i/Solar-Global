<?php
/**
 * Dealer Forgot Password Page
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

set_security_headers();

if (is_dealer_logged_in()) {
    header('Location: /solarglobal/dealer/dashboard.php');
    exit();
}

$error = '';
$success = false;
$show_reset_form = false;
$reset_token = $_GET['token'] ?? '';

// If token in URL, show reset form
if ($reset_token) {
    $db = getDB();
    $stmt = $db->prepare("
        SELECT dv.*, d.email FROM dealer_verification dv
        JOIN dealers d ON dv.dealer_id = d.id
        WHERE dv.token = ? AND dv.type = 'password_reset'
        AND dv.expires_at > NOW() AND dv.used_at IS NULL
    ");
    $stmt->execute([$reset_token]);
    $verification = $stmt->fetch();

    if ($verification) {
        $show_reset_form = true;

        // Handle new password submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_password'])) {
            if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
                $error = 'Invalid request.';
            } else {
                $new_pw = $_POST['new_password'] ?? '';
                $confirm_pw = $_POST['confirm_password'] ?? '';

                if (strlen($new_pw) < 8) {
                    $error = 'Password must be at least 8 characters.';
                } elseif (!preg_match('/[A-Z]/', $new_pw)) {
                    $error = 'Password must contain at least one uppercase letter.';
                } elseif (!preg_match('/[0-9]/', $new_pw)) {
                    $error = 'Password must contain at least one number.';
                } elseif ($new_pw !== $confirm_pw) {
                    $error = 'Passwords do not match.';
                } else {
                    $hash = password_hash($new_pw, PASSWORD_BCRYPT);
                    $db->prepare("UPDATE dealers SET password_hash = ? WHERE id = ?")->execute([$hash, $verification['dealer_id']]);
                    $db->prepare("UPDATE dealer_verification SET used_at = NOW() WHERE id = ?")->execute([$verification['id']]);
                    header('Location: /solarglobal/dealer/login.php?reset=1');
                    exit();
                }
            }
        }
    } else {
        $error = 'Invalid or expired reset link. Please request a new one.';
    }
}

// Handle email submission for reset request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$reset_token && !$show_reset_form) {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request.';
    } else {
        $email = strtolower(trim($_POST['email'] ?? ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email.';
        } else {
            $db = getDB();
            $stmt = $db->prepare("SELECT id, email FROM dealers WHERE email = ?");
            $stmt->execute([$email]);
            $dealer = $stmt->fetch();

            if ($dealer) {
                // Invalidate old tokens
                $db->prepare("UPDATE dealer_verification SET used_at = NOW() WHERE dealer_id = ? AND type = 'password_reset' AND used_at IS NULL")
                   ->execute([$dealer['id']]);

                // Create new token
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
                $db->prepare("INSERT INTO dealer_verification (dealer_id, token, type, expires_at) VALUES (?, ?, 'password_reset', ?)")
                   ->execute([$dealer['id'], $token, $expires]);

                // In production: send email with link
                // For development: show the link
                $reset_link = '/solarglobal/dealer/forgot-password.php?token=' . $token;

                $success = true;
                // Store for dev display
                $_SESSION['dev_reset_link'] = $reset_link;
            } else {
                // Don't reveal if email exists or not (security)
                $success = true;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0D3B6E 0%, #1565C0 100%);
            min-height: 100vh; display: flex; align-items: center;
            justify-content: center; padding: 20px;
        }
        .card {
            background: white; border-radius: 20px; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 48px 40px; max-width: 440px; width: 100%;
        }
        .card h1 { font-size: 1.5rem; color: #0D3B6E; margin-bottom: 8px; text-align: center; }
        .card p.sub { color: #64748B; font-size: 0.9375rem; text-align: center; margin-bottom: 28px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 0.875rem; font-weight: 600; color: #334155; margin-bottom: 8px; }
        .form-group input {
            width: 100%; padding: 13px 16px; border: 2px solid #E2E8F0;
            border-radius: 10px; font-size: 0.9375rem; font-family: inherit; background: #F8FAFC;
        }
        .form-group input:focus { outline: none; border-color: #1565C0; box-shadow: 0 0 0 3px rgba(21,101,192,0.1); background: white; }
        .btn {
            width: 100%; padding: 14px; border: none; border-radius: 10px;
            font-size: 1rem; font-weight: 600; cursor: pointer;
            background: linear-gradient(135deg, #1565C0, #0D3B6E); color: white;
        }
        .btn:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(21,101,192,0.3); }
        .error-msg { background: #FEF2F2; border-left: 4px solid #DC2626; color: #991B1B; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 0.875rem; }
        .success-msg { background: #F0FDF4; border-left: 4px solid #16A34A; color: #166534; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 0.875rem; }
        .back-link { display: block; text-align: center; margin-top: 20px; color: #1565C0; text-decoration: none; font-size: 0.875rem; }
        .dev-link { background: #FEF3C7; border: 1px solid #FDE68A; padding: 12px; border-radius: 8px; margin-top: 16px; font-size: 0.8125rem; word-break: break-all; }
        .dev-link strong { color: #92400E; }
    </style>
</head>
<body>
    <div class="card">
        <?php if ($show_reset_form): ?>
            <h1>Set New Password</h1>
            <p class="sub">Enter your new password below.</p>

            <?php if ($error): ?>
                <div class="error-msg"><?= sanitize($error) ?></div>
            <?php endif; ?>

            <form method="POST">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label>New Password</label>
                    <input type="password" name="new_password" required minlength="8" placeholder="Min 8 chars, 1 uppercase, 1 number">
                </div>
                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="confirm_password" required minlength="8" placeholder="Re-enter password">
                </div>
                <button type="submit" class="btn">Reset Password</button>
            </form>

        <?php elseif ($success): ?>
            <h1>Check Your Email</h1>
            <div class="success-msg">
                If an account with that email exists, we've sent a password reset link. Check your inbox.
            </div>
            <?php if (isset($_SESSION['dev_reset_link'])): ?>
                <div class="dev-link">
                    <strong>DEV MODE:</strong> Reset link:<br>
                    <a href="<?= $_SESSION['dev_reset_link'] ?>"><?= $_SESSION['dev_reset_link'] ?></a>
                </div>
                <?php unset($_SESSION['dev_reset_link']); ?>
            <?php endif; ?>
            <a href="login.php" class="back-link">&larr; Back to Login</a>

        <?php else: ?>
            <h1>Forgot Password?</h1>
            <p class="sub">Enter your email and we'll send you a reset link.</p>

            <?php if ($error): ?>
                <div class="error-msg"><?= sanitize($error) ?></div>
            <?php endif; ?>

            <form method="POST">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" required placeholder="your@email.com">
                </div>
                <button type="submit" class="btn">Send Reset Link</button>
            </form>
            <a href="login.php" class="back-link">&larr; Back to Login</a>
        <?php endif; ?>
    </div>
</body>
</html>
