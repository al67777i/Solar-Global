<?php
/**
 * Solar Recommendation Engine v10.0 (World's Most Intelligent Algorithm)
 * =====================================================================
 * v10.0 Changes (June 4, 2026):
 *  - FIXED: Decimal voltage parsing (38.4V was truncated to 38V)
 *  - FIXED: Inverter cap changed from unlimited 99999999 to smart 2.5× rule
 *  - FIXED: BMS matching now reads from INVERTER, not system type
 *  - NEW: Universal battery config (12V/24V/48V with series/parallel)
 *  - NEW: Correct wiring diagram numbering (B1-B2-B3... per string)
 *  - NEW: Battery type priority by system + BMS (gel/dry/lead-acid support)
 *  - NEW: Series safety limit (max 16) with penalty scoring
 *  - NEW: PV string optimization (maximize voltage within MPPT range)
 *  - IMPROVED: Night-load-factor battery sizing
 *  - IMPROVED: Per-inverter BMS check instead of global flag
 *
 * Previous versions: v9.5 multi-option, v8 tiered display
 */

// ── Configuration ─────────────────────────────────────────────────────────────
define('MAX_BACKUP_HOURS',       48);  // Increased to 48 hours for heavy loads
define('DEFAULT_PEAK_SUN_HOURS', 5.0);
define('SAFETY_FACTOR',          1.25);
define('MIN_INVERTER_WATTS',     300);
define('BATTERY_LIMIT_SMALL',    16);  // <5kW systems: up to 16 batteries
define('BATTERY_LIMIT_MEDIUM',   24);  // 5-15kW systems: up to 24 batteries
define('BATTERY_LIMIT_LARGE',    40);  // >15kW systems: up to 40 batteries
define('MAX_PARALLEL_STRINGS',   12);
define('COO_YEARS',              10);
define('SHOP_DEFAULT_RADIUS_KM', 25);
define('MAX_OPTIONS_PER_TIER',   4);   // v9.5: Generate 4 options per tier (was 3)
define('MAX_INVERTERS_TO_TEST',  30);  // v9.5: Test 30 inverters to build 12 options (was 150)
define('MAX_SAFE_SERIES',        16);  // v10: Max batteries in series (voltage balancing safety)
define('INVERTER_CAP_FACTOR',    2.5); // v10: Max inverter size = required × this factor

// ── Init ──────────────────────────────────────────────────────────────────────
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors',     1);
set_time_limit(120);                    // Allow up to 2 min for heavy calculations
ini_set('memory_limit', '256M');        // Ensure enough memory for large recommendation sets
header('Content-Type: application/json; charset=utf-8');
session_start();


try {
    require_once '../includes/db.php';
    require_once '../includes/csrf.php';
    require_once '../includes/helpers.php';
    require_once '../includes/CurrencyHelper.php';
    require_once '../includes/RecommendationEnhancer.php';
    set_security_headers();

    if (!rate_limit('api_recommend_v8', 15, 60)) { respond_rate_limited(); }
} catch (Exception $e) {
    http_response_code(500);
    respond_json(['success' => false, 'error' => 'init_failed', 'message' => $e->getMessage()]);
    exit;
}

// ── Rate Limiting ─────────────────────────────────────────────────────────────
$rate_key = 'rl_' . md5(($_SERVER['REMOTE_ADDR'] ?? '') . session_id());
if (!isset($_SESSION[$rate_key])) $_SESSION[$rate_key] = [];
$_SESSION[$rate_key] = array_filter($_SESSION[$rate_key], fn($t) => (time() - $t) < 60);
if (count($_SESSION[$rate_key]) >= 30) {
    respond_json(['success' => false, 'message' => 'Too many requests. Please wait a minute.'], 429);
    exit;
}
$_SESSION[$rate_key][] = time();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond_json(['success' => false, 'message' => 'Method not allowed'], 405);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!validate_csrf_token($input['csrf_token'] ?? '')) {
    respond_json(['success' => false, 'error' => 'csrf_invalid'], 403);
    exit;
}
if (empty($input['appliances']) && empty($input['manual_load'])) {
    respond_json(['success' => false, 'message' => 'No appliances selected'], 400);
    exit;
}
// Ensure appliances array exists (may be empty if only manual_load provided)
if (!isset($input['appliances'])) $input['appliances'] = [];

// ══════════════════════════════════════════════════════════════════════════════
// ALL HELPER FUNCTIONS
// ══════════════════════════════════════════════════════════════════════════════

function getInverterBatteryVoltageRange(array $inverter): array {
    $min_v = null;
    $max_v = null;
    $nominal_v = null;

    // ═══════════════════════════════════════════════════════════════════════════
    // DYNAMIC VOLTAGE PARSING - Supports 12V to 1000V+ systems
    // ═══════════════════════════════════════════════════════════════════════════

    if (!empty($inverter['battery_voltage_range'])) {
        $clean = str_replace(['V', 'v', 'DC', 'dc', ','], '', $inverter['battery_voltage_range']);
        $clean = trim($clean);

        // v10 FIX: Pattern 1: Range format "48-60", "200-600", "38.4 - 60" (with decimals)
        if (preg_match('/^(\d+\.?\d*)\s*[-–~]\s*(\d+\.?\d*)$/', $clean, $m)) {
            $min_v = floatval($m[1]);  // v10: floatval instead of intval (fixes 38.4→38 bug)
            $max_v = floatval($m[2]);
            $nominal_v = round(($min_v + $max_v) / 2, 1);
        }
        // Pattern 2: Single voltage "48" or "400"
        elseif (preg_match('/^(\d+\.?\d*)$/', $clean, $m)) {
            $val = floatval($m[1]);

            // For any voltage, calculate tolerance
            if ($val <= 100) {
                // Low voltage (12V, 24V, 48V, 96V): ±15%
                $min_v = round($val * 0.85, 1);
                $max_v = round($val * 1.15, 1);
                $nominal_v = round($val, 1);
            } else {
                // High voltage (200V, 400V, 600V+): ±20% for more flexibility
                $min_v = round($val * 0.80, 1);
                $max_v = round($val * 1.20, 1);
                $nominal_v = round($val, 1);
            }
        }
    }

    // If still null, try battery_voltage_range field as fallback
    if ($min_v === null || $max_v === null) {
        $bvr = $inverter['battery_voltage_range'] ?? '';
        $vdc = parseVoltage($bvr);

        if ($vdc > 0) {
            // Calculate range based on detected voltage
            if ($vdc <= 100) {
                $min_v = (int)round($vdc * 0.85);
                $max_v = (int)round($vdc * 1.15);
                $nominal_v = $vdc;
            } else {
                $min_v = (int)round($vdc * 0.80);
                $max_v = (int)round($vdc * 1.20);
                $nominal_v = $vdc;
            }
        } else {
            // Last resort: Use inverter power rating to estimate voltage class
            $power = intval($inverter['power_rating'] ?? $inverter['output_power_w'] ?? 0);

            if ($power >= 50000) {
                // 50kW+ → Usually high voltage (400V-800V)
                $min_v = 300;
                $max_v = 800;
                $nominal_v = 400;
            } elseif ($power >= 10000) {
                // 10-50kW → Medium-high voltage (96V-400V)
                $min_v = 96;
                $max_v = 400;
                $nominal_v = 200;
            } else {
                // <10kW → Standard voltage (12V-96V)
                $min_v = 12;
                $max_v = 96;
                $nominal_v = 48;
            }

            $model = $inverter['model'] ?? $inverter['name'] ?? 'unknown';
            error_log("WARNING: Inverter {$inverter['id']} ({$model}) has no voltage range data. Estimated {$nominal_v}V based on {$power}W power rating.");
        }
    }

    return [$min_v, $max_v, $nominal_v];
}

// ══════════════════════════════════════════════════════════════════════════════
// v10: UNIVERSAL BATTERY INTELLIGENCE FUNCTIONS
// Supports 12V/24V/48V batteries, gel/dry/lead-acid/LFP, BMS & non-BMS
// ══════════════════════════════════════════════════════════════════════════════

/**
 * v10: Get actual voltage range of a battery unit
 * Uses min_voltage/max_voltage fields, falls back to charge/discharge voltage,
 * then derives from nominal voltage based on chemistry type
 */
function getActualBatteryVoltageRange(array $battery): array {
    $nominal = floatval($battery['nominal_voltage'] ?? 0);
    if ($nominal <= 0) return [0, 0, 0];

    // Try min/max voltage fields first
    $min_v = floatval($battery['min_voltage'] ?? 0);
    $max_v = floatval($battery['max_voltage'] ?? 0);

    // Try discharge/charge voltage as fallback
    if ($min_v <= 0 && !empty($battery['discharge_voltage'])) {
        $dv = preg_replace('/[^0-9.]/', '', $battery['discharge_voltage']);
        if (is_numeric($dv)) $min_v = floatval($dv);
    }
    if ($max_v <= 0 && !empty($battery['charge_voltage'])) {
        $cv = preg_replace('/[^0-9.]/', '', $battery['charge_voltage']);
        if (is_numeric($cv)) $max_v = floatval($cv);
    }

    // Final fallback: derive from nominal based on chemistry
    if ($min_v <= 0 || $max_v <= 0) {
        $type = strtolower($battery['type'] ?? '');
        if (str_contains($type, 'lfp') || str_contains($type, 'lithium')) {
            // LFP: 2.5V-3.65V per cell. 16-cell = 48V nominal → 40V-58.4V
            if ($min_v <= 0) $min_v = round($nominal * 0.833, 1);  // ~40V for 48V
            if ($max_v <= 0) $max_v = round($nominal * 1.217, 1);  // ~58.4V for 48V
        } elseif (str_contains($type, 'gel') || str_contains($type, 'agm')) {
            // Gel/AGM: 1.75V-2.40V per cell. 6-cell = 12V nominal → 10.5V-14.4V
            if ($min_v <= 0) $min_v = round($nominal * 0.875, 1);  // ~10.5V for 12V
            if ($max_v <= 0) $max_v = round($nominal * 1.200, 1);  // ~14.4V for 12V
        } else {
            // Lead-acid / dry: 1.75V-2.45V per cell
            if ($min_v <= 0) $min_v = round($nominal * 0.875, 1);
            if ($max_v <= 0) $max_v = round($nominal * 1.225, 1);
        }
    }

    return [$min_v, $max_v, $nominal];
}

/**
 * v10: Universal battery configuration calculator
 * Handles ANY battery voltage (12V, 24V, 48V) with series/parallel
 * to match ANY inverter voltage range
 */
function calculateBatteryConfiguration(
    array $battery,
    float $inv_min_v,
    float $inv_max_v,
    float $required_kwh,
    int   $max_total_batteries,
    int   $ambient_temp_c = 25
): ?array {
    $bat_nominal_v = floatval($battery['nominal_voltage'] ?? 0);
    $bat_ah = floatval($battery['capacity_ah'] ?? 0);
    if ($bat_nominal_v <= 0 || $bat_ah <= 0) return null;

    // Get actual voltage range of this battery
    list($bat_min_v, $bat_max_v, ) = getActualBatteryVoltageRange($battery);
    if ($bat_min_v <= 0 || $bat_max_v <= 0) return null;

    // DOD: use depth_of_discharge field (stored as percentage, e.g., 90 = 90%)
    $dod_pct = floatval($battery['depth_of_discharge'] ?? 50);
    $dod = ($dod_pct > 1) ? $dod_pct / 100 : $dod_pct;
    $dod = max(0.10, min(1.0, $dod));

    // Temperature derating
    $derated_ah = batteryTempDerate($bat_ah, $battery, $ambient_temp_c);

    // ── STEP 1: Find valid series counts ──
    // String voltage must fall within inverter's battery voltage range
    $min_series = max(1, (int)ceil($inv_min_v / $bat_max_v));
    $max_series = (int)floor($inv_max_v / $bat_min_v);

    // v10 safety: cap series at MAX_SAFE_SERIES
    $max_series = min($max_series, MAX_SAFE_SERIES);

    if ($min_series > $max_series) return null; // Incompatible voltage

    // ── STEP 2: Find optimal series count ──
    // Pick series whose string voltage is closest to the sweet spot
    // (middle of inverter range = optimal operating point)
    $inv_sweet_spot = ($inv_min_v + $inv_max_v) / 2;
    $best_series = $min_series;
    $best_distance = PHP_FLOAT_MAX;

    for ($s = $min_series; $s <= $max_series; $s++) {
        $string_v = $bat_nominal_v * $s;
        $distance = abs($string_v - $inv_sweet_spot);
        // Prefer FEWER series (simpler, safer installation)
        $distance += ($s - 1) * 2; // Small penalty per extra series
        if ($distance < $best_distance) {
            $best_distance = $distance;
            $best_series = $s;
        }
    }

    $series = $best_series;
    $string_voltage = $bat_nominal_v * $series;

    // Verify string voltage range actually overlaps with inverter range
    $string_min_v = $bat_min_v * $series;
    $string_max_v = $bat_max_v * $series;
    if ($string_max_v < $inv_min_v || $string_min_v > $inv_max_v) {
        return null; // No overlap
    }

    // ── STEP 3: Calculate parallel strings for capacity ──
    $usable_ah_per_unit = $derated_ah * $dod;
    if ($usable_ah_per_unit <= 0.1) return null;

    $required_wh = $required_kwh * 1000;
    $required_ah = ($string_voltage > 0) ? ($required_wh / $string_voltage) : $required_wh;
    $parallel = max(1, (int)ceil($required_ah / $usable_ah_per_unit));

    // ── STEP 4: Total count and safety check ──
    $total_batteries = $series * $parallel;
    if ($total_batteries > $max_total_batteries || $total_batteries <= 0) return null;

    // ── STEP 5: Calculate actual delivered specs ──
    $total_ah = $parallel * $bat_ah;
    $usable_ah_total = $parallel * $usable_ah_per_unit;
    $total_kwh = ($total_ah * $string_voltage) / 1000;
    $usable_kwh = ($usable_ah_total * $string_voltage) / 1000;

    // ── STEP 6: Generate wiring description ──
    $wiring = generateWiringDescription(
        $series, $parallel, $bat_nominal_v, $bat_ah, $string_voltage, $total_ah
    );

    return [
        'series'          => $series,
        'parallel'        => $parallel,
        'total_batteries' => $total_batteries,
        'string_voltage'  => round($string_voltage, 1),
        'string_v_range'  => [round($string_min_v, 1), round($string_max_v, 1)],
        'total_ah'        => round($total_ah, 1),
        'usable_ah'       => round($usable_ah_total, 1),
        'total_kwh'       => round($total_kwh, 2),
        'usable_kwh'      => round($usable_kwh, 2),
        'dod_percent'     => intval(round($dod * 100)),
        'config_code'     => "{$series}S{$parallel}P",
        'wiring'          => $wiring,
    ];
}

/**
 * v10: Generate proper wiring description with CORRECT sequential numbering
 * Each battery gets a unique number (B1, B2, B3...) across all strings
 */
function generateWiringDescription(
    int $series, int $parallel,
    float $bat_v, float $bat_ah,
    float $string_v, float $total_ah
): array {
    $total = $series * $parallel;

    // Text description
    if ($series === 1 && $parallel === 1) {
        $text = "Single battery — {$bat_v}V {$bat_ah}Ah";
    } elseif ($series === 1) {
        $text = "{$parallel} batteries in parallel = {$bat_v}V {$total_ah}Ah";
    } elseif ($parallel === 1) {
        $text = "{$series} batteries in series = {$string_v}V {$bat_ah}Ah";
    } else {
        $text = "{$series}S{$parallel}P — {$total} batteries "
              . "({$bat_v}V × {$series} = {$string_v}V, "
              . "{$bat_ah}Ah × {$parallel} = {$total_ah}Ah)";
    }

    // Connection diagram with CORRECT sequential numbering
    $diagram = [];
    $battery_num = 1;
    for ($p = 0; $p < $parallel; $p++) {
        $string_label = ($parallel > 1) ? "String " . ($p + 1) : "String";
        $string_batteries = [];
        for ($s = 0; $s < $series; $s++) {
            $string_batteries[] = "B{$battery_num}";
            $battery_num++;
        }
        $diagram[] = [
            'label'      => $string_label,
            'batteries'  => $string_batteries,
            'connection' => implode(' ─[+/-]─ ', $string_batteries),
            'voltage'    => ($series > 1) ? "{$bat_v}V × {$series} = {$string_v}V" : "{$bat_v}V",
            'capacity'   => "{$bat_ah}Ah",
        ];
    }

    return [
        'text'           => $text,
        'config_code'    => "{$series}S{$parallel}P",
        'total_batteries'=> $total,
        'diagram'        => $diagram,
        'series_note'    => ($series > 1) ? "Connect {$series} batteries in series (+) to (-) in each string" : null,
        'parallel_note'  => ($parallel > 1) ? "Connect all {$parallel} string (+) terminals together, all (-) terminals together" : null,
    ];
}

/**
 * v10: Determine battery search order based on system type + inverter BMS
 * Pakistan market: lead-acid/dry batteries are common for non-BMS off-grid
 */
function getBatterySearchOrder(string $system_type, bool $inv_has_bms): array {
    if ($system_type === 'on-grid') return []; // No battery needed

    if ($inv_has_bms) {
        // Inverter has BMS port → MUST use BMS-capable batteries only
        // LFP/lithium always have BMS communication
        return ['lfp', 'lithium'];
    }

    // Inverter has NO BMS → ALL battery types work
    if ($system_type === 'off-grid') {
        // Off-grid non-BMS: lead-acid is cheapest, most available in Pakistan
        return ['lead-acid', 'gel', 'agm', 'dry', 'lfp', 'lithium'];
    }

    // Hybrid non-BMS (rare: only 3 such inverters): prefer lithium but allow all
    return ['lfp', 'lithium', 'gel', 'agm', 'lead-acid', 'dry'];
}

function matchesCountryPreference(?string $origin, array $preferred_countries, array $country_map): bool {
    if (empty($preferred_countries)) return true;
    if (empty($origin)) return false;

    $origin_lower = strtolower(trim($origin));
    $preferred_lowers = array_map('strtolower', array_map('trim', $preferred_countries));

    if (in_array($origin_lower, $preferred_lowers)) return true;

    if (isset($country_map[$origin_lower])) {
        if (in_array($country_map[$origin_lower], $preferred_lowers)) return true;
    }

    foreach ($country_map as $code => $name) {
        if ($origin_lower === $name && in_array($code, $preferred_lowers)) return true;
    }

    return false;
}

function parseVoltage(string $s): int {
    if (empty($s)) return 0;

    $upper = strtoupper(trim($s));

    // Handle common abbreviations
    if ($upper === 'HV' || $upper === 'HIGH')  return 400;  // High voltage default
    if ($upper === 'MV' || $upper === 'MEDIUM') return 200;  // Medium voltage default
    if ($upper === 'LV' || $upper === 'LOW')   return 48;   // Low voltage default

    // Extract numeric value
    $v = intval(preg_replace('/[^0-9]/', '', $s));

    // Return 0 if invalid (caller will handle)
    return $v > 0 ? $v : 0;
}

function batteryTempDerate(float $ah, array $bat, int $temp_c): float {
    if ($temp_c <= 25) return $ah;
    $type  = strtolower($bat['type'] ?? '');
    $is_li = str_contains($type, 'lithium') || str_contains($type, 'lfp');
    $pct   = $is_li ? min(15, ($temp_c - 25)) : min(30, ($temp_c - 25) * 2);
    return $ah * (1 - $pct / 100);
}

function panelTempDerate(float $wp, array $panel, int $ambient_c): float {
    $coeff  = -0.35;
    $cell_c = $ambient_c + 25;
    $delta  = $cell_c - 25;
    if ($delta <= 0) return $wp;
    $derate = max(0.65, 1.0 + ($coeff / 100) * $delta);
    return $wp * $derate;
}

function panelTypeScore(string $type): float {
    $t = strtolower($type);
    if (str_contains($t, 'topcon') || str_contains($t, 'n-type')) return 1.00;
    if (str_contains($t, 'hjt') || str_contains($t, 'heterojunction'))   return 0.95;
    if (str_contains($t, 'perc') || str_contains($t, 'mono'))             return 0.85;
    if (str_contains($t, 'poly') || str_contains($t, 'multicrystal'))     return 0.65;
    return 0.55;
}

function warrantyScore(int $years, int $max_years = 10): float {
    return min(1.0, $years / max(1, $max_years));
}

function costOfOwnership(float $cost, int $warranty_years): float {
    $life = max(1, min(COO_YEARS, $warranty_years + 2));
    return $cost / $life;
}

/**
 * Haversine distance in km between two lat/lng points
 */
function haversineDistance(float $lat1, float $lng1, float $lat2, float $lng2): float {
    $R = 6371; // Earth radius in km
    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLng/2) * sin($dLng/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $R * $c;
}

/**
 * SMART PHASE DETECTION - Automatically determine if 3-phase is needed
 * Based on electrical engineering best practices
 */
function determineOptimalPhase(
    int $peak_load_watts,
    string $usage_type,
    bool $user_selected_three_phase
): array {
    // Threshold Auto-Switch: If peak load exceeds 15,000W, upgrade to 3-phase regardless of user input
    if ($peak_load_watts > 15000) {
        return [
            'phase' => 3,
            'reason' => 'Peak load exceeds 15,000W. 3-phase system is required for safety and electrical balance.',
            'recommended' => true,
            'warning' => 'Peak load exceeds 15kW. System automatically upgraded to 3-Phase.',
            'auto_switched' => true
        ];
    }

    // If user explicitly selected 3-phase, respect it
    if ($user_selected_three_phase) {
        return [
            'phase' => 3,
            'reason' => 'User selected',
            'recommended' => true
        ];
    }

    // Electrical Engineering Rules:
    // Single-phase max practical load: 7-8kW (30-35A @ 230V)
    // Above this, 3-phase is more efficient and safer

    $single_phase_limit = 7000; // 7kW practical limit for single-phase residential
    $three_phase_threshold = 10000; // 10kW+ definitely needs 3-phase

    if ($usage_type === 'industrial') {
        // Industrial: Always 3-phase above 5kW
        return [
            'phase' => 3,
            'reason' => 'Industrial loads require 3-phase for efficiency',
            'recommended' => true
        ];
    }

    if ($usage_type === 'commercial') {
        // Commercial: 3-phase if > 8kW
        if ($peak_load_watts > 8000) {
            return [
                'phase' => 3,
                'reason' => 'Commercial load above 8kW - 3-phase more efficient',
                'recommended' => true
            ];
        }
        return [
            'phase' => 1,
            'reason' => 'Commercial load under 8kW suitable for single-phase',
            'recommended' => false
        ];
    }

    // Residential: Smart detection
    if ($peak_load_watts >= $three_phase_threshold) {
        return [
            'phase' => 3,
            'reason' => "High residential load ({$peak_load_watts}W) - 3-phase recommended for safety and efficiency",
            'recommended' => true
        ];
    } else if ($peak_load_watts > $single_phase_limit) {
        return [
            'phase' => 3,
            'reason' => "Load ({$peak_load_watts}W) exceeds single-phase practical limit - 3-phase strongly recommended",
            'recommended' => true,
            'warning' => 'Single-phase possible but may trip breakers frequently'
        ];
    }

    // Low load: Single-phase is perfect
    return [
        'phase' => 1,
        'reason' => "Residential load ({$peak_load_watts}W) suitable for single-phase",
        'recommended' => false
    ];
}

/**
 * CALCULATE COMPREHENSIVE QUALITY SCORE (0-100)
 * Factors: Brand reputation, warranties, efficiency, battery chemistry, cycle life
 */
function calculateQualityScore(array $inverter, ?array $battery_config, array $panel_config): float {
    $score = 0;

    // ═══ INVERTER QUALITY (40 points max) ═══
    $inv_warranty = intval($inverter['warranty_years'] ?? 2);
    $score += min(20, $inv_warranty * 4); // Up to 5 years = 20 points

    // Premium brand bonus
    $company = strtolower($inverter['company_name'] ?? $inverter['company'] ?? '');
    $premium_brands = ['victron', 'sma', 'fronius', 'solaredge', 'huawei', 'growatt', 'goodwe', 'deye'];
    $mid_brands = ['must', 'voltronic', 'easun', 'mppsolar', 'sol-ark'];

    if (str_contains($company, 'victron') || str_contains($company, 'sma') || str_contains($company, 'fronius')) {
        $score += 20; // Top tier
    } elseif (array_filter($premium_brands, fn($b) => str_contains($company, $b))) {
        $score += 15; // Premium tier
    } elseif (array_filter($mid_brands, fn($b) => str_contains($company, $b))) {
        $score += 10; // Mid tier
    } else {
        $score += 5; // Budget tier
    }

    // ═══ BATTERY QUALITY (40 points max) ═══
    if ($battery_config && isset($battery_config['battery'])) {
        $bat = $battery_config['battery'];
        $bat_type = strtolower($bat['type'] ?? '');

        // Chemistry bonus (0-25 pts)
        if (str_contains($bat_type, 'lfp') || str_contains($bat_type, 'lifepo4')) {
            $score += 25; // LFP: best chemistry, safest, longest life
        } elseif (str_contains($bat_type, 'lithium') || str_contains($bat_type, 'li-ion')) {
            $score += 20; // Lithium-ion
        } elseif (str_contains($bat_type, 'agm')) {
            $score += 12; // AGM: maintenance-free, better than Gel
        } elseif (str_contains($bat_type, 'gel')) {
            $score += 10; // Gel: sealed, good
        } elseif (str_contains($bat_type, 'dry')) {
            $score += 6;  // Dry cell
        } else {
            $score += 3;  // Lead-acid / flooded
        }

        // Cycle life score (0-15 pts)
        $cycles = intval($bat['cycle_life'] ?? 500);
        $score += min(15, (int)($cycles / 200)); // 3000 cycles = 15 points

        // Battery warranty (0-10 pts)
        $bat_warranty = intval($bat['warranty_years'] ?? 1);
        $score += min(10, $bat_warranty * 2); // 5 years = 10 points

        // BMS bonus (5 pts)
        if (strtolower($bat['is_bms'] ?? 'No') === 'yes') {
            $score += 5;
        }
    }

    // ═══ PANEL QUALITY (20 points max) ═══
    $panel = $panel_config['panel'] ?? [];
    $panel_efficiency = floatval($panel['efficiency'] ?? 18);
    $score += min(15, ($panel_efficiency - 15) * 3); // 18-20% = good score

    $panel_warranty = intval($panel['warranty_years'] ?? 10);
    if ($panel_warranty >= 25) {
        $score += 5; // 25+ year warranty
    } elseif ($panel_warranty >= 15) {
        $score += 3;
    }

    return min(100, max(0, $score));
}

/**
 * GENERATE MULTIPLE OPTIONS PER TIER (v9.5 Multi-Option Engine)
 * Returns 3-4 options per tier instead of just 1
 */
function generateMultiTierOptions(
    PDO    $db,
    array  $inverters,
    array  $battery_types,
    bool   $bms_required,
    float  $backup_hours,
    float  $avg_night_load_w,
    float  $daily_energy_kwh,
    float  $battery_recharge_kwh,
    float  $peak_sun_hours,
    int    $ambient_temp_c,
    array  $available_panels,
    string $system_type,
    array  $preferred_countries,
    array  $country_map,
    array  $country_scores
): array {
    if (empty($inverters)) {
        error_log("generateMultiTierOptions: No inverters provided!");
        return [
            'budget' => [],
            'balanced' => [],
            'premium' => [],
            'all_options' => []
        ];
    }

    error_log("generateMultiTierOptions: Starting with " . count($inverters) . " inverters");
    error_log("generateMultiTierOptions: Battery types: " . implode(', ', $battery_types));
    error_log("generateMultiTierOptions: BMS required: " . ($bms_required ? 'YES' : 'NO'));
    error_log("generateMultiTierOptions: Backup hours: {$backup_hours}h, Night load: {$avg_night_load_w}W");
    error_log("generateMultiTierOptions: Available panels: " . count($available_panels));

    // ═══ STEP 1: Generate ALL possible system configurations ═══
    $all_options = buildSystemOptions(
        $db, $inverters, $battery_types, $bms_required,
        $backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
        $peak_sun_hours, $ambient_temp_c, $available_panels, $system_type,
        $preferred_countries, $country_map, $country_scores
    );

    error_log("generateMultiTierOptions: buildSystemOptions returned " . count($all_options) . " options");

    if (empty($all_options)) {
        error_log("generateMultiTierOptions: No options generated - battery/panel compatibility issue?");
        return [
            'budget' => [],
            'balanced' => [],
            'premium' => [],
            'all_options' => []
        ];
    }

    // ═══ STEP 2: Calculate quality scores for ALL options ═══
    foreach ($all_options as &$opt) {
        // Enhanced quality calculation
        $opt['quality_score'] = calculateQualityScore(
            $opt['inverter'],
            $opt['battery_config'],
            $opt['panel_config']
        );

        // Calculate metrics for sorting
        $total_system_watts = intval($opt['inverter']['power_rating'] ?? 1);
        $opt['cost_per_watt'] = $opt['total_cost'] / max(1, $total_system_watts);
        $opt['value_score'] = $opt['quality_score'] / max(0.01, $opt['cost_per_watt']);
    }
    unset($opt);

    // ═══ STEP 3: Classify into tiers based on quality ═══
    $budget_tier = [];
    $balanced_tier = [];
    $premium_tier = [];

    foreach ($all_options as $opt) {
        if ($opt['quality_score'] < 45) {
            $budget_tier[] = $opt;
        } elseif ($opt['quality_score'] < 70) {
            $balanced_tier[] = $opt;
        } else {
            $premium_tier[] = $opt;
        }
    }

    // ═══ SMART TIER REDISTRIBUTION ═══════════════════════════════════════════
    // Guarantee 3 tiers regardless of how quality scores distribute.
    // Most common real-world case: ALL LFP+hybrid systems score ≥70 → all premium,
    // leaving budget & balanced empty. Old code never handled this case.
    // New: ALWAYS split by price when any tier is empty.
    $total_count = count($all_options);
    $has_budget   = !empty($budget_tier);
    $has_balanced = !empty($balanced_tier);
    $has_premium  = !empty($premium_tier);

    if (!$has_budget || !$has_balanced || !$has_premium) {
        // At least one tier is empty — rebuild all three tiers by price split.
        // This ensures the user always sees Cheapest / Best-Value / Top-Quality.
        $all_sorted_price = $all_options;
        usort($all_sorted_price, fn($a, $b) => $a['total_cost'] <=> $b['total_cost']);

        if ($total_count === 1) {
            $budget_tier   = [];
            $balanced_tier = $all_sorted_price;
            $premium_tier  = [];
        } elseif ($total_count === 2) {
            $budget_tier   = [$all_sorted_price[0]];
            $balanced_tier = [];
            $premium_tier  = [$all_sorted_price[1]];
        } else {
            // 3+ options — split into thirds by price ascending
            // Budget  = cheapest third  (lowest upfront cost)
            // Balanced = mid third      (best value)
            // Premium  = most expensive (best quality/warranty)
            $third = max(1, (int)ceil($total_count / 3));
            $budget_tier   = array_slice($all_sorted_price, 0, $third);
            $balanced_tier = array_slice($all_sorted_price, $third, $third);
            $premium_tier  = array_slice($all_sorted_price, $third * 2);
        }
    }

    // ═══ STEP 4: Sort each tier appropriately ═══

    // BUDGET: Sort by price (cheapest first)
    usort($budget_tier, fn($a, $b) => $a['total_cost'] <=> $b['total_cost']);

    // BALANCED: Sort by value score (best quality per dollar)
    usort($balanced_tier, fn($a, $b) => $b['value_score'] <=> $a['value_score']);

    // PREMIUM: Sort by quality DESC, then price ASC (best quality, then cheapest premium)
    usort($premium_tier, function($a, $b) {
        // Primary: Higher quality first
        if (abs($a['quality_score'] - $b['quality_score']) > 2) {
            return $b['quality_score'] <=> $a['quality_score'];
        }
        // Secondary: Lower price first (within same quality range)
        return $a['total_cost'] <=> $b['total_cost'];
    });

    // ═══ STEP 5: Take top 4 from each tier ═══
    $budget_final = array_slice($budget_tier, 0, 4);
    $balanced_final = array_slice($balanced_tier, 0, 4);
    $premium_final = array_slice($premium_tier, 0, 4);

    // ═══ STEP 6: Add tier labels and ranks ═══
    foreach ($budget_final as $idx => &$opt) {
        $opt['tier'] = 'budget';
        $opt['tier_rank'] = $idx + 1;
        $opt['tier_label'] = '💰 Budget';
        if ($idx === 0) $opt['badge'] = 'Lowest Price';
    }
    foreach ($balanced_final as $idx => &$opt) {
        $opt['tier'] = 'balanced';
        $opt['tier_rank'] = $idx + 1;
        $opt['tier_label'] = '⚖️ Balanced';
        if ($idx === 0) $opt['badge'] = 'Best Value';
    }
    foreach ($premium_final as $idx => &$opt) {
        $opt['tier'] = 'premium';
        $opt['tier_rank'] = $idx + 1;
        $opt['tier_label'] = '👑 Premium';
        if ($idx === 0) $opt['badge'] = 'Top Quality';
    }
    unset($opt);

    return [
        'budget' => $budget_final,
        'balanced' => $balanced_final,
        'premium' => $premium_final,
        'all_options' => $all_options,
        'total_generated' => count($all_options),
        'budget_count' => count($budget_final),
        'balanced_count' => count($balanced_final),
        'premium_count' => count($premium_final)
    ];
}

/**
 * LEGACY: Keep for backward compatibility
 * Returns single best option per tier (v8 behavior)
 */
function generateThreeTierOptions(
    PDO    $db,
    array  $inverters,
    array  $battery_types,
    bool   $bms_required,
    float  $backup_hours,
    float  $avg_night_load_w,
    float  $daily_energy_kwh,
    float  $battery_recharge_kwh,
    float  $peak_sun_hours,
    int    $ambient_temp_c,
    array  $available_panels,
    string $system_type,
    array  $preferred_countries,
    array  $country_map,
    array  $country_scores
): array {
    // Call new multi-option function and extract first from each tier
    $multi_result = generateMultiTierOptions(
        $db, $inverters, $battery_types, $bms_required,
        $backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
        $peak_sun_hours, $ambient_temp_c, $available_panels, $system_type,
        $preferred_countries, $country_map, $country_scores
    );

    return [
        'budget' => $multi_result['budget'][0] ?? null,
        'balanced' => $multi_result['balanced'][0] ?? null,
        'premium' => $multi_result['premium'][0] ?? null,
        'all_options' => $multi_result['all_options'] ?? []
    ];
}

function getCountryPopularityScores(PDO $db, string $user_country_code = '', array $preferred_countries = []): array {
    $scores = [];

    try {
        // Count products by country
        $stmt = $db->query("
            SELECT country, COUNT(*) as product_count
            FROM (
                SELECT country FROM inverters WHERE is_active = 1
                UNION ALL
                SELECT country_origin FROM panels WHERE is_active = 1
                UNION ALL
                SELECT country FROM batteries WHERE is_active = 1
            ) AS all_products
            WHERE country IS NOT NULL AND country != ''
            GROUP BY country
        ");
        $product_counts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        // Count companies by country
        $stmt = $db->query("
            SELECT country, COUNT(*) as company_count
            FROM companies
            WHERE country IS NOT NULL AND country != ''
            GROUP BY country
        ");
        $company_counts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        // Build normalized scores (0-100)
        $max_products = max(array_values($product_counts) ?: [1]);
        $max_companies = max(array_values($company_counts) ?: [1]);

        $all_countries = array_unique(array_merge(array_keys($product_counts), array_keys($company_counts)));

        foreach ($all_countries as $country) {
            $product_score = (($product_counts[$country] ?? 0) / $max_products) * 60; // 60% weight
            $company_score = (($company_counts[$country] ?? 0) / $max_companies) * 40; // 40% weight

            $base_score = $product_score + $company_score;

            // Boost: User's own country gets +50 points
            if ($user_country_code && (strcasecmp($country, $user_country_code) === 0)) {
                $base_score += 50;
            }

            // Boost: Preferred countries get +30 points
            foreach ($preferred_countries as $pref) {
                if (strcasecmp($country, $pref) === 0) {
                    $base_score += 30;
                    break;
                }
            }

            $scores[strtolower($country)] = min(200, $base_score); // Cap at 200
        }

    } catch (Exception $e) {
        error_log("Country popularity scoring error: " . $e->getMessage());
    }

    return $scores;
}

/**
 * Fetch inverters filtered by type (on-grid/off-grid/hybrid) with intelligent country ranking
 */
function fetchInvertersByType(
    PDO    $db,
    int    $min_watts,
    string $inverter_type,
    int    $limit = 20,
    string $usage_type = '',
    bool   $three_phase = false,
    array  $country_scores = [],
    int    $offset = 0
): array {
    $floor = max($min_watts, MIN_INVERTER_WATTS);
    // v10.1: Smarter cap — tighter for small loads, generous for large
    // Small loads (<2kW): cap at 2× to avoid recommending 5kW for 500W loads
    // Medium loads: 2.5× factor
    // Large loads: standard factor
    if ($min_watts < 2000) {
        $cap_factor = 2.0;  // Tight: 500W → max 1000W, 1500W → max 3000W
    } else {
        $cap_factor = INVERTER_CAP_FACTOR; // 2.5× for larger loads
    }
    $cap = (int)ceil($min_watts * $cap_factor);
    // Ensure minimum window of 2 standard sizes above floor (was 4 = too aggressive for small loads)
    $standard_sizes = [1000,1500,2000,3000,3500,4000,5000,6000,8000,10000,
        12000,15000,20000,25000,30000,50000,100000,200000,500000,1000000];
    $next_sizes = array_values(array_filter($standard_sizes, fn($s) => $s >= $floor));
    $window = ($min_watts < 2000) ? 2 : 3; // Smaller window for small loads
    if (count($next_sizes) >= $window) {
        $cap = max($cap, $next_sizes[$window - 1]);
    }

    $type_filter = '';
    $params = [$floor, $cap];

    // Case-insensitive type matching (DB may store 'On-Grid', 'Hybrid', 'Off-Grid')
    if ($inverter_type === 'on-grid') {
        $type_filter = "AND LOWER(i.type) IN ('on-grid', 'grid-tie')";
    } elseif ($inverter_type === 'off-grid') {
        $type_filter = "AND LOWER(i.type) IN ('off-grid')";
    } elseif ($inverter_type === 'hybrid') {
        $type_filter = "AND LOWER(i.type) IN ('hybrid', 'hybrid-inverter')";
    }
    // 'all' type: no filter applied - returns all types

    // Smart usage filter: Use power rating + three_phase to determine suitability
    // since primary_application data may not be properly categorized
    $usage_filter = '';
    if ($usage_type === 'industrial') {
        // Industrial: prefer 3-phase inverters >= 5kW, but don't exclude others
        // Only filter by primary_application if data exists for it
        $usage_filter = "AND (i.primary_application IN ('industrial', 'commercial') OR i.output_power_w >= 5000)";
    } elseif ($usage_type === 'commercial') {
        // Commercial: any inverter works, prefer larger ones
        $usage_filter = "AND (i.primary_application IN ('commercial', 'residential') OR i.output_power_w >= 3000)";
    }
    // Residential: no filter needed - all inverters can serve residential

    // 3-phase filter (using new Yes/No format)
    if ($three_phase) {
        $phase_filter = "AND LOWER(i.three_phase) = 'yes'";
    } else {
        $phase_filter = "AND (LOWER(i.three_phase) = 'no' OR i.three_phase IS NULL)";
    }

    $stmt = $db->prepare("
        SELECT
            i.*,
            i.unit_price_usd                 AS price_usd,
            i.output_power_w                 AS max_load_watts,
            i.output_power_w                 AS power_rating,
            COALESCE(i.max_pv_input_w, 0)    AS max_pv_input,
            CASE
                WHEN i.battery_voltage_range IS NOT NULL THEN i.battery_voltage_range
                ELSE '48V'
            END AS voltage_class,
            CASE
                WHEN i.max_efficiency LIKE '%\%%' THEN CAST(REPLACE(i.max_efficiency, '%', '') AS DECIMAL(5,2))
                ELSE COALESCE(CAST(i.max_efficiency AS DECIMAL(5,2)), 90)
            END AS efficiency,
            COALESCE(i.warranty_years, 1)    AS warranty_years,
            CASE
                WHEN i.supports_parallel = 'Yes' THEN 1
                ELSE 0
            END AS parallel_capable,
            COALESCE(i.max_parallel_units, 1) AS max_parallel_units,
            '' AS parallel_phase_config,
            COALESCE(c.name, 'Unknown')      AS company_name,
            COALESCE(c.logo_path, '')        AS company_logo,
            COALESCE(i.country, '')          AS country,
            COALESCE(i.country, '')          AS country_origin,
            COALESCE(ct.flag_emoji, '')      AS country_flag,
            i.model                          AS name,
            1 AS mppt_channels
        FROM inverters i
        LEFT JOIN companies c ON i.company_id = c.id
        LEFT JOIN countries ct ON LOWER(ct.name COLLATE utf8mb4_general_ci) = LOWER(i.country COLLATE utf8mb4_general_ci) OR ct.code COLLATE utf8mb4_general_ci = i.country COLLATE utf8mb4_general_ci
        WHERE i.output_power_w >= ?
          AND i.output_power_w <= ?
          AND i.is_active = 1
          $type_filter
          $usage_filter
          $phase_filter
        ORDER BY i.output_power_w ASC, i.unit_price_usd ASC
        LIMIT " . ($limit * 3) . "
    ");
    $stmt->execute($params);
    $inverters = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Apply country-based ranking if scores provided
    if (!empty($country_scores) && !empty($inverters)) {
        usort($inverters, function($a, $b) use ($country_scores) {
            $country_a = strtolower($a['country_origin'] ?? '');
            $country_b = strtolower($b['country_origin'] ?? '');

            $score_a = $country_scores[$country_a] ?? 0;
            $score_b = $country_scores[$country_b] ?? 0;

            // Primary: country score (higher is better)
            if ($score_a != $score_b) {
                return $score_b <=> $score_a;
            }

            // Secondary: power rating (ascending - match load better)
            $power_diff = $a['power_rating'] <=> $b['power_rating'];
            if ($power_diff != 0) return $power_diff;

            // Tertiary: price (ascending - cheaper is better)
            return floatval($a['unit_price_usd'] ?? 0) <=> floatval($b['unit_price_usd'] ?? 0);
        });

        // Apply offset and limit after sorting
        $inverters = array_slice($inverters, $offset, $limit);
    }

    return $inverters;
}

/**
 * Build parallel inverter options.
 * For example, if user needs 11kW and we have 6kW parallel-capable inverters,
 * suggest 2×6kW = 12kW as an alternative to 1×12kW.
 */
function buildParallelOptions(
    PDO    $db,
    int    $required_watts,
    string $inverter_type,
    int    $limit = 5
): array {
    // Find parallel-capable inverters smaller than required
    $min_unit = (int)ceil($required_watts / 12); // At least 1/12 of required (12 max parallel)
    $max_unit = (int)ceil($required_watts / 2);  // At most half (need at least 2 units)

    $type_filter = '';
    if ($inverter_type === 'hybrid') {
        $type_filter = "AND (i.type = 'hybrid' OR i.type = 'hybrid-inverter')";
    } elseif ($inverter_type === 'off-grid') {
        $type_filter = "AND i.type = 'off-grid'";
    }

    $stmt = $db->prepare("
        SELECT
            i.*,
            i.unit_price_usd AS price_usd,
            i.output_power_w AS power_rating,
            CASE
                WHEN i.max_efficiency LIKE '%\%%' THEN CAST(REPLACE(i.max_efficiency, '%', '') AS DECIMAL(5,2))
                ELSE COALESCE(CAST(i.max_efficiency AS DECIMAL(5,2)), 90)
            END AS efficiency,
            1 AS mppt_channels,
            COALESCE(i.warranty_years, 1)    AS warranty_years,
            CASE
                WHEN i.supports_parallel = 'Yes' THEN 1
                ELSE 0
            END AS parallel_capable,
            COALESCE(i.max_parallel_units, 1) AS max_parallel_units,
            '' AS parallel_phase_config,
            COALESCE(c.name, 'Unknown')      AS company_name,
            COALESCE(c.logo_path, '')        AS company_logo,
            i.model AS name
        FROM inverters i
        LEFT JOIN companies c ON i.company_id = c.id
        WHERE i.output_power_w >= ?
          AND i.output_power_w <= ?
          AND i.supports_parallel = 'Yes'
          AND i.is_active = 1
          $type_filter
        ORDER BY i.output_power_w DESC, i.unit_price_usd ASC
        LIMIT ?
    ");
    $stmt->execute([$min_unit, $max_unit, $limit]);
    $candidates = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $parallel_options = [];
    foreach ($candidates as $inv) {
        $unit_watts = intval($inv['power_rating']);
        $max_parallel = intval($inv['max_parallel_units']);
        $units_needed = (int)ceil($required_watts / $unit_watts);

        if ($units_needed < 2) continue; // Need at least 2 for parallel
        if ($units_needed > $max_parallel) continue; // Can't exceed max parallel

        $total_watts = $unit_watts * $units_needed;
        $total_cost  = floatval($inv['unit_price_usd'] ?? 0) * $units_needed;

        $parallel_options[] = [
            'inverter'         => $inv,
            'units_needed'     => $units_needed,
            'total_watts'      => $total_watts,
            'total_cost'       => $total_cost,
            'cost_per_watt'    => round($total_cost / $total_watts, 2),
            'max_parallel'     => $max_parallel,
            'phase_config'     => $inv['parallel_phase_config'],
            'headroom_pct'     => round((($total_watts - $required_watts) / $required_watts) * 100, 1),
            'description'      => "{$units_needed}× {$inv['company_name']} {$inv['name']} ({$unit_watts}W each) = {$total_watts}W",
        ];
    }

    // Sort by total cost
    usort($parallel_options, fn($a, $b) => $a['total_cost'] <=> $b['total_cost']);

    return array_slice($parallel_options, 0, 3);
}

/**
 * Calculate net metering savings with separate buy/sell rates
 * and before/after bill comparison
 */
function calculateNetMetering(
    float $daily_gen_kwh,
    float $daily_consumption_kwh,
    float $sellback_rate_pct,
    float $electricity_rate_kwh,
    float $sell_rate_kwh = 0
): array {
    // If no explicit sell rate, derive from buy rate × sellback percentage
    if ($sell_rate_kwh <= 0) {
        $sell_rate_kwh = $electricity_rate_kwh * ($sellback_rate_pct / 100);
    }

    $surplus_kwh = max(0, $daily_gen_kwh - $daily_consumption_kwh);
    $self_consumed_kwh = min($daily_gen_kwh, $daily_consumption_kwh);
    $grid_import_kwh = max(0, $daily_consumption_kwh - $daily_gen_kwh);

    // Daily financials
    $daily_self_use_savings = $self_consumed_kwh * $electricity_rate_kwh; // avoided purchase
    $daily_export_credit = $surplus_kwh * $sell_rate_kwh; // sold to grid
    $daily_grid_cost = $grid_import_kwh * $electricity_rate_kwh; // still bought from grid

    // Before solar: entire consumption from grid
    $daily_bill_before = $daily_consumption_kwh * $electricity_rate_kwh;
    // After solar: only grid import cost minus export credit
    $daily_bill_after = max(0, $daily_grid_cost - $daily_export_credit);

    $monthly_bill_before = round($daily_bill_before * 30, 0);
    $monthly_bill_after = round($daily_bill_after * 30, 0);
    $monthly_savings = $monthly_bill_before - $monthly_bill_after;
    $annual_savings = $monthly_savings * 12;

    // 12-month projection (seasonal variation: ±15%)
    $monthly_projection = [];
    $month_names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    // Solar seasonal factors (Northern hemisphere assumption; adjustable)
    $seasonal = [0.70, 0.75, 0.90, 1.00, 1.10, 1.15, 1.15, 1.10, 1.00, 0.85, 0.72, 0.65];
    $total_annual_savings = 0;
    $total_annual_generation = 0;

    for ($m = 0; $m < 12; $m++) {
        $month_gen = $daily_gen_kwh * $seasonal[$m] * 30;
        $month_use = $daily_consumption_kwh * 30;
        $month_self = min($month_gen, $month_use);
        $month_surplus = max(0, $month_gen - $month_use);
        $month_import = max(0, $month_use - $month_gen);

        $m_bill_before = $month_use * $electricity_rate_kwh;
        $m_grid_cost = $month_import * $electricity_rate_kwh;
        $m_export_credit = $month_surplus * $sell_rate_kwh;
        $m_bill_after = max(0, $m_grid_cost - $m_export_credit);
        $m_savings = $m_bill_before - $m_bill_after;

        $total_annual_savings += $m_savings;
        $total_annual_generation += $month_gen;

        $monthly_projection[] = [
            'month'           => $month_names[$m],
            'generation_kwh'  => round($month_gen, 0),
            'consumption_kwh' => round($month_use, 0),
            'self_consumed'   => round($month_self, 0),
            'exported_kwh'    => round($month_surplus, 0),
            'imported_kwh'    => round($month_import, 0),
            'bill_before'     => round($m_bill_before, 0),
            'bill_after'      => round($m_bill_after, 0),
            'savings'         => round($m_savings, 0),
        ];
    }

    return [
        'daily_generation_kwh'    => round($daily_gen_kwh, 2),
        'daily_consumption_kwh'   => round($daily_consumption_kwh, 2),
        'daily_surplus_kwh'       => round($surplus_kwh, 2),
        'daily_import_kwh'        => round($grid_import_kwh, 2),
        'self_consumed_kwh'       => round($self_consumed_kwh, 2),
        'buy_rate_kwh'            => $electricity_rate_kwh,
        'sell_rate_kwh'           => $sell_rate_kwh,
        'sellback_rate_pct'       => $sellback_rate_pct,
        'monthly_bill_before'     => $monthly_bill_before,
        'monthly_bill_after'      => $monthly_bill_after,
        'monthly_savings'         => round($monthly_savings, 0),
        'annual_savings'          => round($total_annual_savings, 0),
        'annual_generation_kwh'   => round($total_annual_generation, 0),
        'monthly_projection'      => $monthly_projection,
        'payback_factor'          => $total_annual_savings,
    ];
}

/**
 * Score inverter quality (0-100)
 */
function scoreInverter(array $inv, float $min_price, float $max_price, string $system_type): float {
    $eff_sc   = min(1.0, intval($inv['efficiency'] ?? 90) / 98.0);
    $warr_sc  = warrantyScore(intval($inv['warranty_years'] ?? 1), 10);
    $mppt    = intval($inv['mppt_channels'] ?? 1);
    $mppt_sc = min(1.0, $mppt / 4.0);

    $price       = floatval($inv['unit_price_usd'] ?? 0);
    $price_range = max(1.0, $max_price - $min_price);
    $price_sc    = 1.0 - (($price - $min_price) / $price_range) * 0.7;

    $parallel_sc = (!empty($inv['parallel_capable'])) ? 1.0 : 0.0;

    // Weight adjustments based on system type
    if ($system_type === 'on-grid') {
        // On-grid: efficiency and warranty matter most
        return ($eff_sc * 35) + ($warr_sc * 30) + ($mppt_sc * 20) + ($price_sc * 15);
    } elseif ($system_type === 'off-grid') {
        // Off-grid: reliability, parallel capability, price matter
        return ($eff_sc * 25) + ($warr_sc * 25) + ($mppt_sc * 15) + ($price_sc * 20) + ($parallel_sc * 15);
    } else {
        // Hybrid: balanced scoring
        return ($eff_sc * 28) + ($warr_sc * 25) + ($mppt_sc * 17) + ($price_sc * 18) + ($parallel_sc * 12);
    }
}

/**
 * Select best panel for inverter with intelligent wattage and country ranking
 */
function selectBestPanel(
    array $panels,
    array $inverter,
    int $ambient_temp_c,
    array $country_scores = []
): ?array {
    $inv_watts  = intval($inverter['power_rating'] ?? 0);
    $max_pv_w   = intval($inverter['max_solar_input'] ?? intval($inverter['max_pv_input'] ?? 0));
    $mppt_count = max(1, intval($inverter['mppt_channels'] ?? 1));

    $target_pv_w = ($max_pv_w > 0) ? $max_pv_w : ($inv_watts * 1.3);

    // Smart ideal panel wattage based on system size and typical installation
    // Larger panels = fewer mounting points, faster installation, lower labor cost
    $ideal_panel_wp = ($inv_watts < 1000) ? 300   // Small systems: 300W panels
                    : (($inv_watts < 3000) ? 400   // Medium residential: 400W
                    : (($inv_watts < 5000) ? 450   // Large residential: 450W
                    : (($inv_watts < 10000) ? 500  // Small commercial: 500W
                    : 550)));                      // Large commercial: 550W+

    $best_panel = null;
    $best_score = -1.0;

    foreach ($panels as $p) {
        $wp  = intval($p['wattage'] ?? 0);
        if ($wp <= 0) continue;
        $price = floatval($p['price_usd'] ?? 0);
        if ($price <= 0) continue;

        $panels_needed = max(1, (int)ceil($target_pv_w / $wp));
        $total_wp      = $panels_needed * $wp;
        $total_cost    = $panels_needed * $price;

        // Size matching: prefer panels close to ideal wattage (±20% is perfect)
        $wp_diff_ratio = abs($wp - $ideal_panel_wp) / max(1, $ideal_panel_wp);
        if ($wp_diff_ratio <= 0.20) {
            $size_match = 1.0; // Perfect match
        } else if ($wp_diff_ratio <= 0.40) {
            $size_match = 0.85; // Good match
        } else {
            $size_match = max(0.50, 1.0 - $wp_diff_ratio * 0.6); // Acceptable
        }

        // Cost efficiency: more watts per dollar is better
        $cost_per_watt = $price / $wp;
        $cost_eff = 1.0 / max(0.10, $cost_per_watt); // Normalize

        // Technical quality factors
        $eff    = floatval($p['efficiency'] ?? 15);
        $eff_b  = max(0.85, 1.0 + ($eff - 18) / 50); // Bonus for high efficiency

        $type_b = panelTypeScore($p['panel_type'] ?? $p['type'] ?? '');
        $warr_b = 1.0 + warrantyScore(intval($p['warranty_years'] ?? 10), 25) * 0.05;

        // Country popularity bonus
        $country_bonus = 1.0;
        if (!empty($country_scores)) {
            $panel_country = strtolower($p['country_origin'] ?? '');
            $country_score = $country_scores[$panel_country] ?? 0;
            // Convert 0-200 score to 1.0-1.5 multiplier
            $country_bonus = 1.0 + min(0.5, $country_score / 400);
        }

        // Final weighted score
        // Priority: size match (35%) > cost efficiency (25%) > country (20%) > quality (20%)
        $score = ($size_match * 35)
               + ($cost_eff * 0.5 * 25)      // Normalize cost_eff to 0-1 range
               + ($country_bonus - 1) * 100  // Convert 1.0-1.5 to 0-50 score
               + ($eff_b * 10)
               + ($type_b * 8)
               + (($warr_b - 1) * 20);

        if ($score > $best_score) {
            $best_score = $score;
            $best_panel = $p;
        }
    }

    return $best_panel;
}

/**
 * Calculate panel configuration
 */
function calcPanelConfig(
    array $panel,
    array $inverter,
    float $daily_energy_kwh,
    float $battery_recharge_kwh,
    float $peak_sun_hours,
    int   $ambient_temp_c
): ?array {
    $wp         = intval($panel['wattage'] ?? 0);
    $max_pv_w   = intval($inverter['max_solar_input'] ?? intval($inverter['max_pv_input'] ?? 0));
    $mppt_count = max(1, intval($inverter['mppt_channels'] ?? 1));

    if ($wp <= 0) return null;

    $wp_derated = panelTempDerate($wp, $panel, $ambient_temp_c);

    $total_daily_kwh = $daily_energy_kwh + $battery_recharge_kwh;
    $req_kwp = ($total_daily_kwh / max(0.1, $peak_sun_hours)) * SAFETY_FACTOR;
    if ($req_kwp < 0.2) $req_kwp = 0.2;
    if ($max_pv_w > 0)  $req_kwp = min($req_kwp, $max_pv_w / 1000);

    $total = max(1, (int)ceil(($req_kwp * 1000) / max(1, $wp_derated)));

    if ($max_pv_w > 0 && ($total * $wp) > $max_pv_w) {
        $total = max(1, (int)floor($max_pv_w / $wp));
    }
    $total = min($total, MAX_PARALLEL_STRINGS * $mppt_count);

    $total_wp         = $total * $wp;
    $total_wp_derated = $total * $wp_derated;
    $daily_gen_kwh    = round(($total_wp_derated / 1000) * $peak_sun_hours, 2);

    // ═══════════════════════════════════════════════════════════════════════════
    // v10: OPTIMIZED PV STRING CALCULATION
    // Goal: Maximize string voltage within inverter's PV range for best MPPT performance
    // ═══════════════════════════════════════════════════════════════════════════

    $panel_vmp = floatval($panel['vmp'] ?? 0);
    if ($panel_vmp <= 0) {
        // Realistic VMP estimation based on panel wattage
        if ($wp <= 200) {
            $panel_vmp = 24; // Low wattage panels (~100-200W)
        } elseif ($wp <= 400) {
            $panel_vmp = 32; // Standard residential panels (250-400W)
        } else {
            $panel_vmp = 40; // High wattage commercial panels (400W+)
        }
    }

    // Get inverter's PV voltage window
    $min_pv_v  = floatval($inverter['min_pv_voltage'] ?? 0);
    $max_pv_v  = floatval($inverter['max_pv_voltage'] ?? $inverter['max_pv_input_voltage'] ?? 450);

    // CRITICAL: Account for cold weather VOC increase
    // VOC is typically ~1.22x VMP, and increases ~15% in cold weather (-10°C)
    $vmp_to_voc_cold = 1.40; // Conservative safety factor (1.22 × 1.15)
    $max_series_safe = max(1, (int)floor($max_pv_v / ($panel_vmp * $vmp_to_voc_cold)));

    // v10: Calculate MINIMUM series count to meet inverter's min PV voltage
    // String voltage must be >= inverter's min_pv_voltage for MPPT to start
    $min_series_for_mppt = 1;
    if ($min_pv_v > 0 && $panel_vmp > 0) {
        $min_series_for_mppt = max(1, (int)ceil($min_pv_v / $panel_vmp));
    }

    // v10: Optimal panels per string = maximize within safe range
    // Higher string voltage = better MPPT efficiency, lower cable losses
    $panels_per_string = min($max_series_safe, $total);
    $panels_per_string = max($panels_per_string, $min_series_for_mppt);

    // Don't exceed total panels
    $panels_per_string = min($panels_per_string, $total);

    $total_strings = max(1, (int)ceil($total / max(1, $panels_per_string)));
    $strings_per_mppt = max(1, (int)ceil($total_strings / $mppt_count));
    $string_voltage = round($panel_vmp * $panels_per_string, 0);

    // v10: Generate wiring description with CORRECT panel numbering
    $panel_diagram = [];
    $panel_num = 1;
    for ($str = 0; $str < $total_strings; $str++) {
        $panels_in_this_string = ($str < $total_strings - 1)
            ? $panels_per_string
            : ($total - $str * $panels_per_string); // Last string may have fewer
        $panels_in_this_string = max(1, $panels_in_this_string);

        $string_panels = [];
        for ($p = 0; $p < $panels_in_this_string; $p++) {
            $string_panels[] = "P{$panel_num}";
            $panel_num++;
        }
        $panel_diagram[] = [
            'label'   => ($total_strings > 1) ? "String " . ($str + 1) : "String",
            'panels'  => $string_panels,
            'connection' => implode(' ─[+/-]─ ', $string_panels),
            'voltage' => round($panel_vmp * $panels_in_this_string) . "V",
        ];
    }

    // Wiring text description
    if ($mppt_count > 1 && $total > $panels_per_string) {
        $wiring = "{$total_strings} strings × {$panels_per_string} series ({$mppt_count} MPPT, {$string_voltage}V/string)";
    } elseif ($total_strings > 1) {
        $wiring = "{$total_strings} strings × {$panels_per_string} in series ({$string_voltage}V/string)";
    } elseif ($total > 1) {
        $wiring = "{$total} panels in series ({$string_voltage}V)";
    } else {
        $wiring = "1 panel ({$panel_vmp}V)";
    }

    return [
        'panel'               => $panel,
        'quantity'            => $total,
        'total_wattage'       => $total_wp,
        'total_wattage_stc'   => $total_wp,
        'total_wattage_real'  => (int)$total_wp_derated,
        'total_kwp'           => round($total_wp / 1000, 2),
        'daily_gen_kwh'       => $daily_gen_kwh,
        'daily_generation_kwh'=> $daily_gen_kwh,
        'daily_need_kwh'      => round($total_daily_kwh, 2),
        'total_cost'          => round($total * floatval($panel['price_usd'] ?? 0)),
        'panel_efficiency'    => floatval($panel['efficiency'] ?? 0),
        'panel_type'          => $panel['panel_type'] ?? $panel['type'] ?? '',
        'wiring'              => $wiring,
        'string_voltage'      => $string_voltage,
        'panels_per_string'   => $panels_per_string,
        'total_strings'       => $total_strings,
        'strings_per_mppt'    => $strings_per_mppt,
        'mppt_count'          => $mppt_count,
        'temp_derate_applied' => ($ambient_temp_c > 25),
        'pv_voltage_range'    => ['min' => $min_pv_v, 'max' => $max_pv_v],  // v10
        'panel_diagram'       => $panel_diagram,  // v10: Sequential P1,P2,P3... numbering
    ];
}

/**
 * Find top batteries for inverter + category
 * v10: Per-inverter BMS check, supports 12V/24V/48V with series/parallel
 */
function findTopBatteries(
    PDO    $db,
    array  $inverter,
    array  $battery_types,
    float  $backup_hours,
    float  $avg_night_load_w,
    int    $ambient_temp_c,
    bool   $bms_required,
    int    $max_results = 3,
    array  $preferred_countries = [],
    array  $country_map = []
): array {
    list($min_v, $max_v, $nominal_v) = getInverterBatteryVoltageRange($inverter);
    $inv_watts = intval($inverter['power_rating']);
    $inv_eff   = max(50, min(99, intval($inverter['efficiency'] ?? 90))) / 100;
    $max_bats  = $inv_watts < 5000 ? BATTERY_LIMIT_SMALL
               : (($inv_watts <= 15000) ? BATTERY_LIMIT_MEDIUM : BATTERY_LIMIT_LARGE);

    if (empty($battery_types)) return [];
    $type_ph = implode(',', array_fill(0, count($battery_types), '?'));

    // v10: BMS filter reads from INVERTER, not just the $bms_required parameter
    // If inverter has BMS port → only BMS batteries can communicate
    // If inverter has no BMS → all batteries work (gel, dry, lead-acid, LFP)
    $inv_has_bms = strtolower($inverter['bms'] ?? 'No') === 'yes';
    $bms_sql = '';
    if ($inv_has_bms || $bms_required) {
        // Inverter requires BMS communication → only BMS-capable batteries
        // LFP/lithium packs almost always have integrated BMS
        $has_lithium_types = array_intersect($battery_types, ['lithium', 'lfp']);
        if (!empty($has_lithium_types)) {
            $bms_sql = "AND (b.is_bms = 'Yes' OR LOWER(b.type) IN ('lithium', 'lfp'))";
        } else {
            $bms_sql = "AND b.is_bms = 'Yes'";
        }
    }
    // If inverter has NO BMS → $bms_sql stays empty → all batteries allowed

    // v10: Fetch ALL active batteries of matching types (don't filter by voltage here)
    // The series/parallel calculator will determine voltage compatibility
    // This allows 12V batteries to match 48V inverters via 4-series stacking
    $stmt = $db->prepare("
        SELECT
            b.*,
            b.type                             AS battery_type,
            COALESCE(b.is_bms, 'No')          AS has_bms,
            COALESCE(b.depth_of_discharge, 50) / 100 AS dod_decimal,
            COALESCE(b.depth_of_discharge, 50) AS depth_of_discharge,
            COALESCE(b.cycle_life, 500)        AS cycle_life,
            COALESCE(b.warranty_years, 1)      AS warranty_years,
            COALESCE(c.name, 'Unknown')        AS company_name,
            COALESCE(c.logo_path, '')          AS company_logo,
            COALESCE(b.country, '')            AS country_origin,
            COALESCE(ct.flag_emoji, '')        AS country_flag
        FROM batteries b
        LEFT JOIN companies c ON b.company_id = c.id
        LEFT JOIN countries ct ON LOWER(ct.name COLLATE utf8mb4_general_ci) = LOWER(b.country COLLATE utf8mb4_general_ci) OR ct.code COLLATE utf8mb4_general_ci = b.country COLLATE utf8mb4_general_ci
        WHERE b.type IN ($type_ph)
          $bms_sql
          AND b.is_active = 1
        ORDER BY b.price_unit_usd ASC
        LIMIT 100
    ");
    $stmt->execute($battery_types);
    $batteries = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $all_candidates = [];

    foreach ($batteries as $bat) {
        // Filter by preferred country if provided
        if (!empty($preferred_countries)) {
            if (!matchesCountryPreference($bat['country_origin'] ?? '', $preferred_countries, $country_map)) {
                continue;
            }
        }

        $batt_v = floatval($bat['nominal_voltage']);
        if ($batt_v <= 0) continue;

        // v10: Use universal battery configuration calculator
        // Handles 12V, 24V, 48V batteries with series/parallel to match ANY inverter voltage
        $required_kwh = ($avg_night_load_w * $backup_hours) / 1000;
        $bat_config = calculateBatteryConfiguration(
            $bat, $min_v, $max_v, $required_kwh, $max_bats, $ambient_temp_c
        );

        if ($bat_config === null) continue; // Incompatible voltage or exceeds battery limit

        $series      = $bat_config['series'];
        $parallel    = $bat_config['parallel'];
        $total_bats  = $bat_config['total_batteries'];
        $string_v    = $bat_config['string_voltage'];
        $total_ah    = $bat_config['total_ah'];
        $usable_kwh  = $bat_config['usable_kwh'];
        $raw_kwh     = $bat_config['total_kwh'];
        $dod_pct     = $bat_config['dod_percent'];
        $wiring_data = $bat_config['wiring'];

        $raw_ah = floatval($bat['capacity_ah'] ?? 0);
        $total_cost = $total_bats * floatval($bat['price_unit_usd'] ?? 0);

        $backup_time = ($avg_night_load_w > 0 && $usable_kwh > 0)
            ? ($usable_kwh * 1000 * $inv_eff) / $avg_night_load_w
            : 0;

        $warranty = intval($bat['warranty_years']);
        $cycles   = intval($bat['cycle_life']);

        $accuracy    = ($backup_time >= $backup_hours)
            ? 1.0 : max(0.0, $backup_time / max(1, $backup_hours));
        $cost_per_kwh = ($usable_kwh > 0) ? ($total_cost / $usable_kwh) : 999999;
        $cost_eff     = max(0, 1 - ($cost_per_kwh / 120000));
        $coo_per_yr   = costOfOwnership($total_cost, $warranty);
        $coo_sc       = max(0, 1 - ($coo_per_yr / 60000));
        $warranty_sc  = warrantyScore($warranty, 10);
        $cycle_sc     = min(1.0, $cycles / 3000);
        $fewer_sc     = max(0.0, 1 - ($total_bats / max(1, $max_bats)));

        $score = ($accuracy * 38) + ($cost_eff * 18) + ($coo_sc * 8)
               + ($warranty_sc * 14) + ($cycle_sc * 12) + ($fewer_sc * 6) + 4;

        // v10: Penalize high series count (simpler = safer installation)
        if ($series > 4) {
            $series_penalty = ($series - 4) * 1.5; // 1.5 points per extra series above 4
            $score -= $series_penalty;
        }

        // ═══════════════════════════════════════════════════════════════════════════
        // DEEP BATTERY VALIDATION (Phase 3 - Safety Check)
        // ═══════════════════════════════════════════════════════════════════════════
        $battery_validation = validateBatteryDeep(
            $bat,
            $inverter,
            $backup_hours,
            $avg_night_load_w,
            $ambient_temp_c,
            $series
        );

        // Skip incompatible batteries
        if (!$battery_validation['compatible']) {
            error_log("Battery {$bat['id']} incompatible: " . implode(', ', $battery_validation['issues']));
            continue;
        }

        // Store validation info for later display
        $validation_info = [
            'c_rate' => $battery_validation['c_rate'],
            'expected_life_years' => $battery_validation['expected_life_years'],
            'warnings' => $battery_validation['warnings']
        ];

        $all_candidates[] = [
            'score'  => $score,
            'config' => [
                'battery'          => $bat,
                'quantity'         => $total_bats,
                'series'           => $series,
                'parallel'         => $parallel,
                'total_ah'         => round($total_ah),
                'usable_kwh'       => round($usable_kwh, 2),
                'total_kwh'        => round($raw_kwh, 2),
                'total_cost'       => round($total_cost),
                'backup_hours'     => round($backup_time, 1),
                'wiring'           => $wiring_data['text'],           // v10: Text from wiring generator
                'wiring_diagram'   => $wiring_data['diagram'],        // v10: Full diagram with B1,B2,B3...
                'wiring_notes'     => array_filter([                  // v10: Connection instructions
                    $wiring_data['series_note'],
                    $wiring_data['parallel_note'],
                ]),
                'config_code'      => $wiring_data['config_code'],    // v10: e.g., "4S2P"
                'string_voltage'   => $string_v,                      // v10: Actual string voltage
                'string_v_range'   => $bat_config['string_v_range'],  // v10: [min, max] string voltage
                'dod_percent'      => $dod_pct,
                'warranty_years'   => $warranty,
                'cycle_life'       => $cycles,
                'score_debug'      => round($score, 2),
                'validation'       => $validation_info,
            ],
        ];
    }

    if (empty($all_candidates)) return [];

    usort($all_candidates, fn($a, $b) => $b['score'] <=> $a['score']);

    $results = [];
    foreach ($all_candidates as $cand) {
        $results[] = $cand['config'];
        if (count($results) >= $max_results) break;
    }

    return $results;
}

/**
 * Find nearby dealers/shops with matching inventory
 */
function findNearbyShops(
    PDO   $db,
    float $lat,
    float $lng,
    float $radius_km,
    ?int  $inverter_id = null,
    ?int  $panel_id = null,
    ?int  $battery_id = null
): array {
    // Get all active dealers with coordinates AND active subscription
    $stmt = $db->prepare("
        SELECT d.*,
               d.business_name, d.latitude, d.longitude,
               d.address, d.city, d.phone
        FROM dealers d
        WHERE d.status = 'active'
          AND d.subscription_status = 'active'
          AND (d.subscription_expires_at IS NULL OR d.subscription_expires_at > NOW())
          AND d.latitude IS NOT NULL
          AND d.longitude IS NOT NULL
    ");
    $stmt->execute();
    $dealers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $nearby = [];
    foreach ($dealers as $dealer) {
        $d_lat = floatval($dealer['latitude']);
        $d_lng = floatval($dealer['longitude']);
        $distance = haversineDistance($lat, $lng, $d_lat, $d_lng);

        if ($distance <= $radius_km) {
            $dealer['distance_km'] = round($distance, 1);

            // Check inventory if product IDs provided
            try {
                if ($inverter_id || $panel_id || $battery_id) {
                    $has_products = checkDealerInventory($db, intval($dealer['id']), $inverter_id, $panel_id, $battery_id);
                    $dealer['has_matching_products'] = $has_products;
                    $dealer['matching_products'] = $has_products;
                } else {
                    $dealer['has_matching_products'] = true;
                }
            } catch (Exception $e) {
                $dealer['has_matching_products'] = true;
            }

            $nearby[] = $dealer;
        }
    }

    // Sort by distance
    usort($nearby, fn($a, $b) => $a['distance_km'] <=> $b['distance_km']);

    return $nearby;
}

/**
 * Check if a dealer has specific products in inventory
 */
function checkDealerInventory(PDO $db, int $dealer_id, ?int $inverter_id, ?int $panel_id, ?int $battery_id): array {
    $products = [];

    try {
        if ($inverter_id) {
            $stmt = $db->prepare("SELECT dp.*, dp.dealer_price, dp.stock_quantity
                                  FROM dealer_products dp
                                  WHERE dp.dealer_id = ? AND dp.product_type = 'inverter' AND dp.product_id = ? AND dp.is_active = 1");
            $stmt->execute([$dealer_id, $inverter_id]);
            $inv = $stmt->fetch();
            if ($inv) $products['inverter'] = $inv;
        }
        if ($panel_id) {
            $stmt = $db->prepare("SELECT dp.*, dp.dealer_price, dp.stock_quantity
                                  FROM dealer_products dp
                                  WHERE dp.dealer_id = ? AND dp.product_type = 'panel' AND dp.product_id = ? AND dp.is_active = 1");
            $stmt->execute([$dealer_id, $panel_id]);
            $pan = $stmt->fetch();
            if ($pan) $products['panel'] = $pan;
        }
        if ($battery_id) {
            $stmt = $db->prepare("SELECT dp.*, dp.dealer_price, dp.stock_quantity
                                  FROM dealer_products dp
                                  WHERE dp.dealer_id = ? AND dp.product_type = 'battery' AND dp.product_id = ? AND dp.is_active = 1");
            $stmt->execute([$dealer_id, $battery_id]);
            $bat = $stmt->fetch();
            if ($bat) $products['battery'] = $bat;
        }
    } catch (Exception $e) {
        // Table might not exist yet
    }

    return $products;
}

/**
 * Build recommendation options for a given inverter type (OPTIMIZED FOR SPEED)
 */
function buildSystemOptions(
    PDO    $db,
    array  $inverters,
    array  $battery_types,
    bool   $bms_required,
    float  $backup_hours,
    float  $avg_night_load_w,
    float  $daily_energy_kwh,
    float  $battery_recharge_kwh,
    float  $peak_sun_hours,
    int    $ambient_temp_c,
    array  $available_panels,
    string $system_type,
    array  $preferred_countries = [],
    array  $country_map = [],
    array  $country_scores = []
): array {
    if (empty($inverters)) return [];

    // SPEED OPTIMIZATION: Limit inverters to test
    $inverters = array_slice($inverters, 0, MAX_INVERTERS_TO_TEST);

    $prices = array_column($inverters, 'unit_price_usd');
    $min_p  = !empty($prices) ? (float)min($prices) : 0.0;
    $max_p  = !empty($prices) ? (float)max($prices) : 1.0;

    $options = [];

    foreach ($inverters as $inverter) {
        $best_panel = selectBestPanel($available_panels, $inverter, $ambient_temp_c, $country_scores);
        if (!$best_panel) continue;

        // For on-grid: no battery recharge needed
        $bat_recharge = ($system_type === 'on-grid') ? 0 : $battery_recharge_kwh;

        $panel_cfg = calcPanelConfig(
            $best_panel, $inverter,
            $daily_energy_kwh, $bat_recharge,
            $peak_sun_hours, $ambient_temp_c
        );
        if (!$panel_cfg) continue;

        // ═══════════════════════════════════════════════════════════════════════════
        // VALIDATE PANEL CONFIGURATION (Safety Check - Phase 3)
        // ═══════════════════════════════════════════════════════════════════════════
        $panel_validation = validatePanelConfiguration(
            $best_panel,
            $inverter,
            intval($panel_cfg['panels_per_string'] ?? 1),
            intval($panel_cfg['parallel_strings'] ?? 1),
            $ambient_temp_c
        );

        // Skip this configuration if it has critical issues
        if (!$panel_validation['valid']) {
            error_log("Panel config invalid for inverter {$inverter['id']}: " . implode(', ', $panel_validation['issues']));
            continue; // Skip to next inverter
        }

        // Add warnings to the panel config if any
        if (!empty($panel_validation['warnings'])) {
            $panel_cfg['validation_warnings'] = $panel_validation['warnings'];
        }

        $inv_score = scoreInverter($inverter, $min_p, $max_p, $system_type);

        if ($system_type === 'on-grid') {
            // On-grid: NO battery needed
            $total_cost = floatval($inverter['unit_price_usd'] ?? 0) + floatval($panel_cfg['total_cost'] ?? 0);

            $options[] = [
                'inverter'            => $inverter,
                'battery_config'      => null,
                'panel_config'        => $panel_cfg,
                'total_cost'          => round($total_cost),
                'inverter_score'      => round($inv_score, 1),
                'system_type'         => 'on-grid',
                'needs_battery'       => false,
                'has_net_metering'    => true,
                'has_battery_backup'  => false,
                'parallel_capable'    => !empty($inverter['parallel_capable']),
                'max_parallel_units'  => intval($inverter['max_parallel_units'] ?? 1),
            ];
        } else {
            // Off-grid or Hybrid: needs batteries - FIND BEST BATTERY WITH PROGRESSIVE FALLBACK
            // v10: Per-inverter BMS check — read from THIS inverter, not global flag
            $inv_has_bms = strtolower($inverter['bms'] ?? 'No') === 'yes';
            $inv_bms_required = $inv_has_bms || $bms_required;

            $top_batteries = findTopBatteries(
                $db, $inverter, $battery_types,
                $backup_hours, $avg_night_load_w,
                $ambient_temp_c, $inv_bms_required, 1,
                $preferred_countries, $country_map
            );

            // v10: Progressive fallback using getBatterySearchOrder
            if (empty($top_batteries)) {
                // Fallback 1: Try the v10 smart battery order for this inverter
                $smart_types = getBatterySearchOrder($system_type, $inv_has_bms);
                if (!empty($smart_types)) {
                    $top_batteries = findTopBatteries(
                        $db, $inverter, $smart_types,
                        $backup_hours, $avg_night_load_w,
                        $ambient_temp_c, $inv_has_bms, 1,
                        [], $country_map
                    );
                }
            }
            if (empty($top_batteries)) {
                // Fallback 2: Try ALL battery types (if inverter has no BMS, all types work)
                $all_bat_types = ['lithium', 'lfp', 'gel', 'agm', 'lead-acid', 'dry'];
                $top_batteries = findTopBatteries(
                    $db, $inverter, $all_bat_types,
                    $backup_hours, $avg_night_load_w,
                    $ambient_temp_c, $inv_has_bms, 1,
                    [], $country_map
                );
            }
            if (empty($top_batteries)) {
                // Fallback 3: Reduced backup (50%) as absolute last resort
                $reduced_backup = max(1, $backup_hours * 0.5);
                $top_batteries = findTopBatteries(
                    $db, $inverter, ['lithium', 'lfp', 'gel', 'agm', 'lead-acid', 'dry'],
                    $reduced_backup, $avg_night_load_w,
                    $ambient_temp_c, false, 1,
                    [], $country_map
                );
            }
            if (empty($top_batteries)) continue;

            // Use only the single best battery
            $bat_cfg = $top_batteries[0];
            $total_cost = floatval($inverter['unit_price_usd'] ?? 0)
                        + floatval($bat_cfg['total_cost'] ?? 0)
                        + floatval($panel_cfg['total_cost'] ?? 0);

            $options[] = [
                'inverter'            => $inverter,
                'battery_config'      => $bat_cfg,
                'panel_config'        => $panel_cfg,
                'total_cost'          => round($total_cost),
                'inverter_score'      => round($inv_score, 1),
                'system_type'         => $system_type,
                'needs_battery'       => true,
                'has_net_metering'    => ($system_type === 'hybrid'),
                'has_battery_backup'  => true,
                'parallel_capable'    => !empty($inverter['parallel_capable']),
                'max_parallel_units'  => intval($inverter['max_parallel_units'] ?? 1),
            ];
        }
    }

    usort($options, function($a, $b) {
        $d = $b['inverter_score'] <=> $a['inverter_score'];
        return $d !== 0 ? $d : ($a['total_cost'] <=> $b['total_cost']);
    });

    return $options;
}

// ══════════════════════════════════════════════════════════════════════════════
// PHASE 2 & 3: ADVANCED OPTIMIZATION FUNCTIONS
// Performance + Electrical Engineering Improvements (June 2, 2026)
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Cache query results to avoid repeated database hits
 * Uses APCu if available, falls back to non-cached execution
 */
function cachedQuery(PDO $db, string $sql, array $params = [], int $ttl = 300): array {
    $cache_key = 'query_' . md5($sql . serialize($params));

    // Try APCu first
    if (function_exists('apcu_fetch')) {
        $result = apcu_fetch($cache_key);
        if ($result !== false) return $result;
    }

    // Execute query
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Cache result
    if (function_exists('apcu_store')) {
        apcu_store($cache_key, $result, $ttl);
    }

    return $result;
}

/**
 * PROFESSIONAL INVERTER SIZING - Electrical Engineering Grade
 * Accounts for: Surge, Power Factor, Temperature, Future Expansion
 */
function calculateOptimalInverterSize(
    float $peak_load_watts,
    array $appliances,
    int $ambient_temp_c = 25,
    string $usage_type = 'residential'
): array {
    // ── STEP 1: Calculate Total Surge Load ───────────────────────
    $surge_loads = [];
    foreach ($appliances as $app) {
        $typical_watts = floatval($app['watt_typical'] ?? $app['total_watts'] ?? 0);
        $surge_watts = floatval($app['surge_load_watts'] ?? $typical_watts * 2);
        $surge_loads[] = $surge_watts;
    }

    // Not all appliances surge at the same time
    // Residential: 60% simultaneous, Commercial: 80%, Industrial: 90%
    $simultaneous_factor = match($usage_type) {
        'residential' => 0.60,
        'commercial' => 0.80,
        'industrial' => 0.90,
        default => 0.60
    };

    $total_surge = array_sum($surge_loads) * $simultaneous_factor;

    // ── STEP 2: Temperature Derating ─────────────────────────────
    // Inverters lose capacity in hot weather
    // Standard: 100% at 25°C, -1% per °C above 25°C
    $temp_derate = 1.0;
    if ($ambient_temp_c > 25) {
        $temp_derate = max(0.70, 1.0 - (($ambient_temp_c - 25) * 0.01));
    }

    // ── STEP 3: Power Factor Correction ──────────────────────────
    // Most loads have power factor 0.8-0.95
    // Inverter must supply apparent power (VA), not just real power (W)
    $power_factor = 0.92; // Typical mixed load

    // ── STEP 4: Future Expansion Allowance ───────────────────────
    // Allow 15% growth headroom
    $expansion_factor = 1.15;

    // ── STEP 5: Calculate Required Capacity ──────────────────────
    $required_for_normal = $peak_load_watts * 1.25; // 25% safety margin
    $required_for_surge = $total_surge;
    $required_for_pf = $peak_load_watts / $power_factor;

    $base_requirement = max(
        $required_for_normal,
        $required_for_surge,
        $required_for_pf
    );

    // Apply derating and expansion
    $final_requirement = ($base_requirement / $temp_derate) * $expansion_factor;

    return [
        'required_watts' => (int)ceil($final_requirement),
        'base_load' => $peak_load_watts,
        'surge_capacity' => (int)ceil($total_surge),
        'temp_derate_factor' => round($temp_derate, 2),
        'safety_margin_pct' => round((($final_requirement - $peak_load_watts) / $peak_load_watts) * 100, 1),
        'notes' => [
            "Base load: {$peak_load_watts}W",
            "Surge capacity: " . ceil($total_surge) . "W",
            "Temperature derating: " . round($temp_derate * 100, 0) . "%",
            "Power factor correction applied",
            "15% expansion allowance included"
        ]
    ];
}

/**
 * VALIDATE PANEL STRING CONFIGURATION
 * Checks: VOC in cold weather, VMP range, Current limits
 */
function validatePanelConfiguration(
    array $panel,
    array $inverter,
    int $series_panels,
    int $parallel_strings,
    int $ambient_temp_c = 25
): array {
    $issues = [];
    $warnings = [];

    // Panel specs
    $panel_voc = floatval($panel['voc'] ?? 0);
    $panel_vmp = floatval($panel['vmp'] ?? 0);
    $panel_imp = floatval($panel['imp'] ?? 0);

    // Inverter specs
    $inv_max_v = floatval($inverter['max_pv_input_voltage'] ?? 500);
    $inv_min_v = floatval($inverter['min_pv_voltage'] ?? 100);
    $inv_max_i = floatval($inverter['max_input_current'] ?? 15);

    if ($panel_voc <= 0 || $panel_vmp <= 0) {
        // Estimate from wattage instead of rejecting — most panels lack these specs in bulk imports
        $panel_wp = floatval($panel['wattage'] ?? 0);
        if ($panel_wp > 0) {
            // IMPROVED ESTIMATION: Use more realistic voltage factors
            // Modern panels: 40-45V Voc, 32-37V Vmp for 300-400W range
            // Formula: Voc ≈ 0.073 × wattage^0.5 + 20 (empirical fit)
            if ($panel_voc <= 0) {
                if ($panel_wp <= 200) {
                    $panel_voc = 30; // Low wattage panels
                } elseif ($panel_wp <= 400) {
                    $panel_voc = 40; // Standard residential panels
                } else {
                    $panel_voc = 48; // High wattage commercial panels
                }
            }
            if ($panel_vmp <= 0) {
                $panel_vmp = $panel_voc * 0.82; // Vmp typically 80-85% of Voc
            }
            if ($panel_imp <= 0) $panel_imp = $panel_wp / max(1, $panel_vmp);
            $warnings[] = "Panel Voc/Vmp estimated from wattage — verify actual specs for production";
        } else {
            // No specs at all — skip electrical validation, just pass with warning
            return ['valid' => true, 'issues' => [], 'warnings' => ['Panel specs incomplete — electrical validation skipped'], 'voc_cold' => 0, 'vmp_operating' => 0, 'total_current' => 0];
        }
    }

    // ── CHECK 1: VOC in Cold Weather ─────────────────────────────
    // VOC increases by ~0.33% per °C below 25°C
    // At -10°C, VOC can be 15% higher
    $cold_temp = -10; // Assume worst case
    $voc_cold_factor = 1.0 + (abs($cold_temp - 25) * 0.0033);
    $string_voc_cold = $panel_voc * $series_panels * $voc_cold_factor;

    if ($string_voc_cold > $inv_max_v) {
        $issues[] = "CRITICAL: String VOC ({$string_voc_cold}V at -10°C) exceeds inverter max ({$inv_max_v}V)";
    } elseif ($string_voc_cold > $inv_max_v * 0.95) {
        $warnings[] = "String VOC ({$string_voc_cold}V) close to inverter limit";
    }

    // ── CHECK 2: VMP Operating Range ─────────────────────────────
    $string_vmp = $panel_vmp * $series_panels;

    if ($string_vmp < $inv_min_v) {
        $issues[] = "String VMP ({$string_vmp}V) below inverter minimum ({$inv_min_v}V)";
    }

    // ── CHECK 3: Current Limits ──────────────────────────────────
    $total_current = $panel_imp * $parallel_strings;

    if ($total_current > $inv_max_i) {
        $issues[] = "CRITICAL: Total current ({$total_current}A) exceeds inverter max ({$inv_max_i}A)";
    }

    return [
        'valid' => empty($issues),
        'issues' => $issues,
        'warnings' => $warnings,
        'voc_cold' => round($string_voc_cold, 1),
        'vmp_operating' => round($string_vmp, 1),
        'total_current' => round($total_current, 2)
    ];
}

/**
 * DEEP BATTERY VALIDATION
 * Tests: Voltage, Discharge rate, Charge rate, Temperature, Cycle life
 */
function validateBatteryDeep(
    array $battery,
    array $inverter,
    float $backup_hours,
    float $avg_load_w,
    int $ambient_temp_c = 25,
    int $series_count = 1
): array {
    $issues = [];
    $warnings = [];

    // ── CHECK 1: Voltage Compatibility (STRING voltage, not individual battery) ──
    list($min_v, $max_v, $nominal_v) = getInverterBatteryVoltageRange($inverter);
    // FIX: Use nominal_voltage (actual DB column), fallback to voltage for backward compat
    $bat_voltage = floatval($battery['nominal_voltage'] ?? $battery['voltage'] ?? 0);
    if ($bat_voltage <= 0) {
        // Cannot validate without voltage - pass with warning
        return [
            'compatible' => true,
            'issues' => [],
            'warnings' => ['Battery voltage unknown — skipping voltage validation'],
            'c_rate' => 0,
            'expected_life_years' => 10
        ];
    }
    $string_voltage = $bat_voltage * max(1, $series_count);

    // Check series string voltage against inverter range (with 20% tolerance for flexibility)
    if ($string_voltage < $min_v * 0.80 || $string_voltage > $max_v * 1.20) {
        $issues[] = "String voltage {$string_voltage}V ({$series_count}×{$bat_voltage}V) outside inverter range {$min_v}-{$max_v}V";
    }

    // ── CHECK 2: Discharge Rate (C-Rating) ───────────────────────
    $battery_ah = floatval($battery['capacity_ah'] ?? 0);
    $c_rate = 0;
    if ($battery_ah > 0 && $string_voltage > 0) {
        $discharge_current = $avg_load_w / max(1, $string_voltage);
        $c_rate = $discharge_current / $battery_ah;
        $max_c_rate = floatval($battery['max_discharge_rate'] ?? 1.0); // Default 1C for lithium

        // Only flag as issue if C-rate is extremely high (>2C for lithium, >0.5C for lead-acid)
        $bat_type = strtolower($battery['type'] ?? '');
        $is_lithium = str_contains($bat_type, 'lithium') || str_contains($bat_type, 'lfp');
        $critical_c_rate = $is_lithium ? 2.0 : 0.5;

        if ($c_rate > $critical_c_rate) {
            $issues[] = "Discharge rate {$c_rate}C exceeds safe limit for {$bat_type} battery";
        } elseif ($c_rate > 1.0) {
            $warnings[] = "High discharge rate " . round($c_rate, 2) . "C may reduce battery life";
        }
    }

    // ── CHECK 3: Charge Rate Compatibility ───────────────────────
    $inverter_charge_a = floatval($inverter['max_charge_current'] ?? 0);
    $battery_max_charge_a = floatval($battery['charging_current_max'] ?? 0);

    if ($inverter_charge_a > 0 && $battery_max_charge_a > 0 && $inverter_charge_a > $battery_max_charge_a * 1.2) {
        $warnings[] = "Inverter charge current ({$inverter_charge_a}A) exceeds battery max ({$battery_max_charge_a}A) - configure charge limit in inverter settings";
    }

    // ── CHECK 4: Temperature Range ───────────────────────────────
    $temp_range = $battery['operating_temp'] ?? $battery['temperature_range'] ?? '';
    if ($temp_range && preg_match('/(-?\d+).*?(\d+)/', $temp_range, $m)) {
        $min_temp = intval($m[1]);
        $max_temp = intval($m[2]);

        if ($ambient_temp_c < $min_temp || $ambient_temp_c > $max_temp) {
            $warnings[] = "Ambient temperature {$ambient_temp_c}°C outside battery operating range {$min_temp}-{$max_temp}°C";
        }
    }

    // ── CHECK 5: Cycle Life for Daily Use ────────────────────────
    $cycles = intval($battery['cycle_life'] ?? 3000);
    $expected_years = $cycles / 365;

    if ($expected_years < 2) {
        $warnings[] = "Battery lifespan only " . round($expected_years, 1) . " years with daily cycling";
    }

    // ── CHECK 6: DOD Validation ──────────────────────────────────
    // FIX: Use depth_of_discharge (actual DB column) or dod_decimal from query alias
    $dod_pct = floatval($battery['depth_of_discharge'] ?? $battery['dod_percent'] ?? 80);
    // depth_of_discharge is stored as percentage (e.g. 90 = 90%)
    $dod = ($dod_pct > 1) ? $dod_pct / 100 : $dod_pct; // Normalize to 0-1
    if ($dod < 0.3) {
        $warnings[] = "Low DOD (" . round($dod * 100, 0) . "%) means only " . round($dod * 100, 0) . "% of capacity usable";
    }

    return [
        'compatible' => empty($issues),
        'issues' => $issues,
        'warnings' => $warnings,
        'c_rate' => round($c_rate, 2),
        'expected_life_years' => round($expected_years, 1)
    ];
}

// ══════════════════════════════════════════════════════════════════════════════
// MAIN EXECUTION
// ══════════════════════════════════════════════════════════════════════════════
try {
    $db = getDB();

    // Expose country lookup map
    $country_map = [];
    try {
        $stmt = $db->query("SELECT LOWER(code) as code, LOWER(name) as name FROM countries");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $country_map[$row['code']] = $row['name'];
        }
    } catch (Exception $e) {
        // ignore
    }

    $preferred_countries = [];
    if (isset($input['preferred_countries']) && is_array($input['preferred_countries'])) {
        $preferred_countries = array_filter(array_map('strval', $input['preferred_countries']));
    }

    // ── Request Parameters ────────────────────────────────────────────────────
    $city_id_input    = intval($input['city_id'] ?? 0);
    $backup_hours     = max(1, min(MAX_BACKUP_HOURS, floatval($input['backup_hours'] ?? 8)));
    $three_phase_user = (bool)($input['three_phase'] ?? false);

    // Usage type: residential, commercial, industrial
    $usage_type = $input['usage_type'] ?? 'residential';
    if (!in_array($usage_type, ['residential', 'commercial', 'industrial'])) {
        $usage_type = 'residential';
    }

    // SMART PHASE DETECTION will be done after load calculation
    $three_phase = $three_phase_user;
    if ($usage_type === 'industrial') {
        $three_phase = true; // Industrial always 3-phase
    }

    // Smart backup hours defaults by usage type (if user didn't explicitly set it)
    if (!isset($input['backup_hours']) || $input['backup_hours'] == 4) {
        // User hasn't explicitly chosen - use smart defaults
        $backup_hours = match($usage_type) {
            'industrial'  => 2.0,
            'commercial'  => 4.0,
            default       => 8.0, // residential default
        };
    }

    // NEW v8: Inverter type selection
    $system_type      = $input['system_type'] ?? 'hybrid'; // on-grid, off-grid, hybrid
    if (!in_array($system_type, ['on-grid', 'off-grid', 'hybrid'])) {
        $system_type = 'hybrid';
    }

    // NEW v9: Recommendation mode (informative = general, shop = dealer-specific)
    $rec_mode = $input['recommendation_mode'] ?? 'informative';
    if (!in_array($rec_mode, ['informative', 'shop'])) {
        $rec_mode = 'informative';
    }

    // NEW v9: Country detection & currency
    $country_code = strtoupper(trim($input['country_code'] ?? ''));
    $currencyHelper = new CurrencyHelper($country_code ?: null);
    $pricingContext = $currencyHelper->getPricingContext();
    $gridInfo = $currencyHelper->getGridInfo();

    // NEW v8: Net metering parameters (on-grid and hybrid only)
    $net_metering_enabled = (bool)($input['net_metering'] ?? false);
    $sellback_rate_pct    = max(0, min(100, floatval($input['sellback_rate'] ?? 80)));
    $electricity_rate_kwh = floatval($input['electricity_rate'] ?? 0);
    $sell_rate_kwh        = floatval($input['sell_rate'] ?? 0);

    // NEW v8: Location for shop search
    $user_lat    = floatval($input['latitude'] ?? 0);
    $user_lng    = floatval($input['longitude'] ?? 0);
    $shop_radius = max(5, min(200, floatval($input['shop_radius_km'] ?? SHOP_DEFAULT_RADIUS_KM)));

    // Weather/solar data from location
    $enhancer = new RecommendationEnhancer($city_id_input ?: null);
    $enhanced_params = $enhancer->getEnhancedParams();

    $ambient_temp_c = intval($input['ambient_temp_c'] ?? 0) ?: intval($enhanced_params['ambient_temp_c'] ?? 30);
    $ambient_temp_c = max(15, min(55, $ambient_temp_c));
    $peak_sun_hours = floatval($input['peak_sun_hours'] ?? 0) ?: floatval($enhanced_params['peak_sun_hours'] ?? 5.0);
    $peak_sun_hours = max(3.0, min(8.0, $peak_sun_hours));

    // If electricity rate not provided, use detected country rate
    if ($electricity_rate_kwh <= 0) {
        $electricity_rate_kwh = $gridInfo['electricity_rate_kwh'] > 0
            ? $gridInfo['electricity_rate_kwh']
            : 15; // Default fallback
    }
    // If sell rate not provided, use country sell rate or derive from buy rate
    if ($sell_rate_kwh <= 0) {
        $sell_rate_kwh = $gridInfo['sell_rate_kwh'] > 0
            ? $gridInfo['sell_rate_kwh']
            : $electricity_rate_kwh * ($sellback_rate_pct / 100);
    }

    // ── STEP 1: Build Load Profile ────────────────────────────────────────────
    error_log("v8.0 STEP1: Building load profile, system_type={$system_type}");

    $total_load_watts  = 0;
    $appliance_details = [];
    $total_daily_wh    = 0;
    $hourly_load       = array_fill(0, 24, 0);
    $peak_surge_load   = 0;

    error_log("v8.0 STEP1: Appliances count=" . count($input['appliances']) . ", usage_type=" . ($input['usage_type'] ?? 'unknown'));

    foreach ($input['appliances'] as $idx => $item) {
        $id       = intval($item['id'] ?? 0);
        $quantity = max(1, intval($item['quantity'] ?? 1));
        $load_factor_pct = floatval($item['loadFactor'] ?? 100);
        $load_factor     = max(10, min(100, $load_factor_pct)) / 100;

        error_log("v8.0 Appliance[$idx]: id=$id, is_manual=" . (!empty($item['is_manual_load']) ? 'Y' : 'N') . ", watt_typical=" . ($item['watt_typical'] ?? 'NULL') . ", keys=" . implode(',', array_keys($item)));

        $hourlyUsage = (isset($item['hourlyUsage']) && is_array($item['hourlyUsage']))
            ? $item['hourlyUsage'] : null;

        if (!$hourlyUsage) {
            $st = intval($item['startTime'] ?? 0);
            $et = intval($item['endTime']   ?? 24);
            $hourlyUsage = array_fill(0, 24, 0);
            for ($h = $st; $h < $et; $h++) $hourlyUsage[$h] = 1;
        }

        $hours = max(0.25, array_sum($hourlyUsage));

        // Manual/commercial/industrial load — watt data provided directly
        $is_manual = !empty($item['is_manual_load']) || intval($item['watt_typical'] ?? 0) > 0;
        if ($is_manual && intval($item['watt_typical'] ?? 0) > 0) {
            $watt_typical = intval($item['watt_typical']);
            $watts_per_unit = (int)round($watt_typical * $load_factor);
            $watts          = $watts_per_unit * $quantity;
            $surge_watts    = intval($item['surge_load_watts'] ?? round($watts * 1.5));
            $app_name       = trim($item['name_en'] ?? 'Manual Load');
            $app_icon       = $item['icon'] ?? '⚡';

            // If hourly load in watts is provided, use it for more accurate profiling
            if (!empty($item['hourlyLoad']) && is_array($item['hourlyLoad'])) {
                $hourly_load_w = array_map('intval', $item['hourlyLoad']);
                for ($h = 0; $h < 24; $h++) {
                    $hourly_load[$h] += $hourly_load_w[$h] ?? 0;
                }
                $total_load_watts += max($hourly_load_w); // peak load
                $total_daily_wh  += array_sum($hourly_load_w); // each entry = Wh for that hour
                $peak_surge_load += $surge_watts;
            } else {
                $total_load_watts += $watts;
                $total_daily_wh  += $watts * $hours;
                $peak_surge_load += $surge_watts;
                for ($h = 0; $h < 24; $h++) {
                    if (!empty($hourlyUsage[$h])) $hourly_load[$h] += $watts;
                }
            }

            $appliance_details[] = [
                'name_en'           => $app_name,
                'icon'              => $app_icon,
                'quantity'          => $quantity,
                'load_factor'       => $load_factor_pct,
                'hours'             => $hours,
                'hourlyUsage'       => $hourlyUsage,
                'watt_per_unit'     => $watts_per_unit,
                'total_watts'       => $watts,
                'surge_watts'       => $surge_watts,
                'daily_wh'          => $watts * $hours,
            ];
            continue;
        }

        // Standard appliance — look up from database
        $stmt = $db->prepare("SELECT id, name_en, watt_typical, surge_load_watts, icon, image_path
                               FROM appliances WHERE id = ? AND is_active = 1");
        $stmt->execute([$id]);
        $app = $stmt->fetch();
        if (!$app) continue;

        $watts_per_unit = (int)round($app['watt_typical'] * $load_factor);
        $watts          = $watts_per_unit * $quantity;
        $surge_watts    = intval($app['surge_load_watts'] ?? 0) * $quantity;

        $total_load_watts += $watts;
        $total_daily_wh  += $watts * $hours;
        $peak_surge_load  += $surge_watts;

        for ($h = 0; $h < 24; $h++) {
            if (!empty($hourlyUsage[$h])) $hourly_load[$h] += $watts;
        }

        $appliance_details[] = [
            'name_en'           => $app['name_en'],
            'icon'              => $app['icon'],
            'quantity'          => $quantity,
            'load_factor'       => $load_factor_pct,
            'hours'             => $hours,
            'hourlyUsage'       => $hourlyUsage,
            'watt_per_unit'     => $watts_per_unit,
            'total_watts'       => $watts,
            'surge_watts'       => $surge_watts,
            'daily_wh'          => $watts * $hours,
        ];
    }

    // ── FALLBACK: Use top-level manual_load if appliance loop produced 0 watts ──
    if ($total_load_watts <= 0 && !empty($input['manual_load'])) {
        $ml = $input['manual_load'];
        $ml_peak = intval($ml['peak_watts'] ?? 0);
        error_log("v8.0 STEP1-FALLBACK: Using manual_load, peak_watts={$ml_peak}");

        if ($ml_peak > 0) {
            $ml_hours_arr = (isset($ml['hourly_load']) && is_array($ml['hourly_load'])) ? $ml['hourly_load'] : [];
            $ml_op_hours  = max(1, intval($ml['operating_hours'] ?? 10));
            $ml_surge     = intval(round($ml_peak * 1.5));
            $ml_name      = ($input['usage_type'] ?? '') === 'industrial' ? 'Industrial Load' : 'Commercial Load';

            if (count($ml_hours_arr) === 24 && max($ml_hours_arr) > 0) {
                // Use detailed hourly load (watts per hour)
                $ml_hours_w = array_map('intval', $ml_hours_arr);
                for ($h = 0; $h < 24; $h++) {
                    $hourly_load[$h] += $ml_hours_w[$h];
                }
                $total_load_watts = max($ml_hours_w);
                $total_daily_wh   = array_sum($ml_hours_w); // each entry = Wh for that hour
            } else {
                // Simple: distribute peak over operating hours
                $total_load_watts = $ml_peak;
                $total_daily_wh   = $ml_peak * $ml_op_hours;
                // Distribute evenly starting from 7am
                for ($i = 0; $i < $ml_op_hours && $i < 24; $i++) {
                    $hourly_load[(7 + $i) % 24] += $ml_peak;
                }
            }
            $peak_surge_load = $ml_surge;

            $hourlyUsage = array_map(function($w) { return $w > 0 ? 1 : 0; }, $hourly_load);
            $hours = max(1, count(array_filter($hourlyUsage)));

            $appliance_details[] = [
                'name_en'       => $ml_name,
                'icon'          => ($input['usage_type'] ?? '') === 'industrial' ? '🏭' : '🏢',
                'quantity'      => 1,
                'load_factor'   => 100,
                'hours'         => $hours,
                'hourlyUsage'   => $hourlyUsage,
                'watt_per_unit' => $total_load_watts,
                'total_watts'   => $total_load_watts,
                'surge_watts'   => $ml_surge,
                'daily_wh'      => $total_daily_wh,
            ];

            error_log("v8.0 STEP1-FALLBACK: total_load_watts={$total_load_watts}, daily_wh={$total_daily_wh}");
        }
    }

    if ($total_load_watts <= 0) {
        $usage = $input['usage_type'] ?? 'residential';
        $hint = in_array($usage, ['commercial', 'industrial'])
            ? 'Please set your peak load using the load graph before generating recommendations.'
            : 'No valid appliances found. Please select at least one appliance.';
        respond_json(['success' => false, 'message' => $hint], 400);
        exit;
    }

    $peak_load_watts  = max($hourly_load) ?: $total_load_watts;
    $daily_energy_kwh = $total_daily_wh / 1000;

    // ── STEP 2: Load Shape Analysis (Enhanced Night Analysis) ───────────────
    // Night hours: 18:00–05:59 (no solar generation)
    $night_hours = array_merge(range(18, 23), range(0, 5));
    $night_wh = 0;
    $night_active_count = 0;
    $night_peak_w = 0;
    $total_night_kwh = 0;

    foreach ($night_hours as $h) {
        $hw = $hourly_load[$h];
        $total_night_kwh += $hw / 1000; // Each hour's wattage = Wh for that hour
        if ($hw > 0) {
            $night_wh += $hw;
            $night_active_count++;
            $night_peak_w = max($night_peak_w, $hw);
        }
    }

    $avg_night_load_w = ($night_wh > 0 && $night_active_count > 0)
        ? $night_wh / $night_active_count
        : $peak_load_watts * 0.30;

    // Day hours: 06:00–17:59 (solar generation window)
    $day_hours = range(6, 17);
    $total_day_kwh = 0;
    $day_peak_w = 0;
    foreach ($day_hours as $h) {
        $total_day_kwh += $hourly_load[$h] / 1000;
        $day_peak_w = max($day_peak_w, $hourly_load[$h]);
    }

    // Day vs. Night Load Ratio & System Type Auto-Selection
    $r_night = ($total_daily_wh > 0) ? ($night_wh / $total_daily_wh) : 0;

    if ($r_night < 0.15 || $night_wh < 1000) {
        // Auto-select On-Grid
        $system_type = 'on-grid';
        $backup_hours = 0;
        $algorithm_notes[] = [
            'type' => 'hybrid_sizing_note',
            'message' => 'Based on your load profile, nighttime consumption is very low (<15% of daily usage or <1kWh). We have automatically selected an On-Grid system (without batteries) to maximize savings and prevent battery waste.'
        ];
    } else {
        // Significant night consumption. Default to Hybrid (or keep off-grid if specified)
        if ($system_type === 'on-grid') {
            $system_type = 'hybrid';
        }

        $p_night_avg = $night_wh / 12;
        if ($p_night_avg <= 300) {
            $default_backup_hours = 6.0;
        } elseif ($p_night_avg <= 1000) {
            $default_backup_hours = 5.0;
        } elseif ($p_night_avg <= 3000) {
            $default_backup_hours = 4.0;
        } elseif ($p_night_avg <= 8000) {
            $default_backup_hours = 3.0;
        } elseif ($p_night_avg <= 20000) {
            $default_backup_hours = 2.0;
        } else {
            $default_backup_hours = 1.5;
        }

        // Use the calculated default backup hours if not explicitly set by the user (or default value of 4 is passed)
        if (!isset($input['backup_hours']) || floatval($input['backup_hours']) == 4.0) {
            $backup_hours = $default_backup_hours;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PROFESSIONAL INVERTER SIZING - Electrical Engineering Grade
    // ═══════════════════════════════════════════════════════════════════════════
    $sizing_result = calculateOptimalInverterSize(
        $peak_load_watts,
        $appliance_details,
        $ambient_temp_c,
        $usage_type
    );

    $required_inverter_watts = $sizing_result['required_watts'];

    // Add sizing notes for transparency
    $algorithm_notes[] = [
        'type' => 'inverter_sizing',
        'message' => "Inverter sized for {$sizing_result['base_load']}W base load + {$sizing_result['surge_capacity']}W surge capacity",
        'safety_margin' => $sizing_result['safety_margin_pct'] . '%',
        'details' => $sizing_result['notes']
    ];

    // ═══════════════════════════════════════════════════════════════════════════
    // SMART PHASE DETECTION - Automatically recommend 3-phase if load is high
    // ═══════════════════════════════════════════════════════════════════════════
    $phase_recommendation = determineOptimalPhase($peak_load_watts, $usage_type, $three_phase_user);
    $three_phase = $phase_recommendation['phase'] === 3;
    $phase_detection_note = null;

    if ($phase_recommendation['recommended'] && !$three_phase_user) {
        // Algorithm recommends 3-phase but user didn't select it
        $phase_detection_note = [
            'type' => 'phase_recommendation',
            'message' => $phase_recommendation['reason'],
            'warning' => $phase_recommendation['warning'] ?? null,
            'recommended_phase' => 3,
            'auto_switched' => true
        ];
    }

    error_log("v8.0 PHASE: User={$three_phase_user}, Detected={$three_phase}, Load={$peak_load_watts}W, Type={$usage_type}, Reason: {$phase_recommendation['reason']}");

    // Battery sizing based on actual night consumption analysis
    // For on-grid: no battery recharge needed
    // For hybrid: grid serves as backup fallback, so battery bank can be smaller (70% of full backup)
    // For off-grid: full night load must be covered by batteries
    $effective_backup_hours = $backup_hours;
    if ($system_type === 'on-grid') {
        $battery_recharge_kwh = 0;
    } elseif ($system_type === 'hybrid') {
        $effective_backup_hours = $backup_hours * 0.7;
        // Use actual night consumption if available, otherwise estimate
        $battery_recharge_kwh = ($total_night_kwh > 0)
            ? $total_night_kwh * ($effective_backup_hours / count($night_hours))
            : ($avg_night_load_w * $effective_backup_hours) / 1000;
    } else {
        // Off-grid: batteries must cover full night load
        $battery_recharge_kwh = ($total_night_kwh > 0)
            ? $total_night_kwh * ($backup_hours / count($night_hours))
            : ($avg_night_load_w * $backup_hours) / 1000;
    }

    error_log("v8.0 STEP2: peak={$peak_load_watts}W (×1.3={$required_inverter_watts}W), night={$total_night_kwh}kWh, day={$total_day_kwh}kWh, type={$system_type}, backup_h={$effective_backup_hours}");

    // ── STEP 3: Fetch Panels ──────────────────────────────────────────────────
    $stmt = $db->prepare("
        SELECT p.*,
            p.wattage AS watt_peak,
            COALESCE(c.name, 'Unknown') AS company_name,
            COALESCE(c.logo_path, '')   AS company_logo,
            COALESCE(p.country_origin, '') AS country_origin,
            COALESCE(ct.flag_emoji, '')    AS country_flag
        FROM panels p
        LEFT JOIN companies c ON p.company_id = c.id
        LEFT JOIN countries ct ON LOWER(ct.name COLLATE utf8mb4_general_ci) = LOWER(p.country_origin COLLATE utf8mb4_general_ci) OR ct.code COLLATE utf8mb4_general_ci = p.country_origin COLLATE utf8mb4_general_ci
        WHERE p.is_active = 1 AND p.wattage > 0
        ORDER BY p.wattage ASC, p.price_usd ASC
        LIMIT 80
    ");
    $stmt->execute();
    $available_panels = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($available_panels)) {
        respond_json(['success' => false, 'error' => 'no_panels', 'message' => 'No solar panels in database.']);
        exit;
    }

    // Shop mode: boost dealer-available panels to top
    if ($has_dealer_filter && !empty($dealer_product_ids['panel'])) {
        $local_p = [];
        $global_p = [];
        foreach ($available_panels as $p) {
            if (in_array((int)$p['id'], $dealer_product_ids['panel'])) {
                $p['_dealer_available'] = true;
                $local_p[] = $p;
            } else {
                $p['_dealer_available'] = false;
                $global_p[] = $p;
            }
        }
        $available_panels = array_merge($local_p, $global_p);
    }

    // ── STEP 4: Fetch Inverters by Type ──────────────────────────────────────
    error_log("v8.0 STEP4: Fetching {$system_type} inverters");

    // NEW: Get country popularity scores with caching (Performance Optimization)
    $cache_key = 'country_scores_' . md5($country_code . implode(',', $preferred_countries));
    $country_scores = null;

    // Try to get from cache (if APCu is available)
    if (function_exists('apcu_fetch')) {
        $country_scores = apcu_fetch($cache_key);
    }

    // If not in cache, calculate and store
    if ($country_scores === false || $country_scores === null) {
        $country_scores = getCountryPopularityScores($db, $country_code, $preferred_countries);

        // Store in cache for 1 hour
        if (function_exists('apcu_store') && is_array($country_scores)) {
            apcu_store($cache_key, $country_scores, 3600);
        }
    }

    error_log("v8.0 Country scores calculated: " . count($country_scores) . " countries");

    // Shop mode with location: prioritize products available at nearby dealers
    $dealer_product_ids = ['inverter' => [], 'panel' => [], 'battery' => []];
    $has_dealer_filter = false;

    if ($rec_mode === 'shop' && $user_lat != 0 && $user_lng != 0) {
        try {
            $dealer_stmt = $db->prepare("
                SELECT DISTINCT di.product_type, di.product_id
                FROM dealer_inventory di
                JOIN dealers d ON di.dealer_id = d.id
                WHERE d.status = 'active'
                  AND d.latitude IS NOT NULL AND d.longitude IS NOT NULL
                  AND di.is_active = 1 AND di.quantity > 0
                  AND (
                    6371 * acos(
                      cos(radians(?)) * cos(radians(d.latitude)) *
                      cos(radians(d.longitude) - radians(?)) +
                      sin(radians(?)) * sin(radians(d.latitude))
                    )
                  ) <= ?
            ");
            $dealer_stmt->execute([$user_lat, $user_lng, $user_lat, $shop_radius]);
            $dealer_rows = $dealer_stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dealer_rows as $dr) {
                $dealer_product_ids[$dr['product_type']][] = (int)$dr['product_id'];
            }
            $has_dealer_filter = !empty($dealer_product_ids['inverter']);
        } catch (Exception $e) {
            error_log("v8.0 Dealer filter error: " . $e->getMessage());
        }
    }

    $inverters = fetchInvertersByType($db, $required_inverter_watts, $system_type, MAX_INVERTERS_TO_TEST, $usage_type, $three_phase, $country_scores, 0);

    // If shop mode, boost dealer-available inverters to top
    if ($has_dealer_filter && !empty($inverters)) {
        $local = [];
        $global = [];
        foreach ($inverters as $inv) {
            if (in_array((int)$inv['id'], $dealer_product_ids['inverter'])) {
                $inv['_dealer_available'] = true;
                $local[] = $inv;
            } else {
                $inv['_dealer_available'] = false;
                $global[] = $inv;
            }
        }
        // Local first, then global as fallback
        $inverters = array_merge($local, $global);
        $inverters = array_slice($inverters, 0, MAX_INVERTERS_TO_TEST); // Keep only top ones
    }

    // Also try hybrid inverters as fallback for off-grid (many hybrid work off-grid too)
    if (empty($inverters) && $system_type === 'off-grid') {
        $inverters = fetchInvertersByType($db, $required_inverter_watts, 'hybrid', MAX_INVERTERS_TO_TEST, $usage_type, $three_phase, $country_scores, 0);
    }

    // Fallback: any type, relax usage filter
    if (empty($inverters)) {
        $inverters = fetchInvertersByType($db, $required_inverter_watts, 'all', MAX_INVERTERS_TO_TEST, '', false, $country_scores, 0);
    }

    if (empty($inverters)) {
        respond_json(['success' => false, 'error' => 'no_inverters',
            'message' => "No {$system_type} inverters found for {$required_inverter_watts}W load."]);
        exit;
    }

    // ── STEP 5: Build Parallel Options & Integrate Into Recommendations ─────
    $parallel_options = [];
    if ($system_type !== 'on-grid') {
        $parallel_options = buildParallelOptions($db, $required_inverter_watts, $system_type);

        // Smart parallel integration: if parallel combo is cheaper than any single inverter
        // of equivalent power, inject those inverters into the main inverter pool
        if (!empty($parallel_options)) {
            foreach ($parallel_options as $po) {
                $single_equiv_cost = null;
                // Find single inverter of equivalent or higher power
                foreach ($inverters as $si) {
                    if (intval($si['power_rating']) >= $po['total_watts']) {
                        $single_equiv_cost = floatval($si['unit_price_usd']);
                        break;
                    }
                }
                // If parallel is cheaper than single equivalent, mark as cost-effective
                if ($single_equiv_cost !== null && $po['total_cost'] < $single_equiv_cost) {
                    $po['cost_saving_vs_single'] = round($single_equiv_cost - $po['total_cost'], 2);
                    $po['is_budget_winner'] = true;
                }
            }
        }
    }

    // ── STEP 6: Build Recommendations — System-Type-Aware Tiered Display ────
    // D1: Hybrid → only lithium/LFP with BMS
    //     Off-grid → all battery types allowed
    //     On-grid → no battery at all
    $categories = [];

    // Define battery types based on system type
    if ($system_type === 'hybrid') {
        $battery_types = ['lithium', 'lfp'];
        $bms_required = true;
    } elseif ($system_type === 'off-grid') {
        $battery_types = ['lithium', 'lfp', 'lead-acid', 'gel', 'agm'];
        $bms_required = false;
    } else {
        // On-grid: no battery needed
        $battery_types = [];
        $bms_required = false;
    }

    // Store unfiltered arrays for country preference fallback
    $unfiltered_inverters = $inverters;
    $unfiltered_panels    = $available_panels;
    $was_country_preference_applied = false;

    if (!empty($preferred_countries)) {
        $filtered_inverters = [];
        foreach ($inverters as $inv) {
            if (matchesCountryPreference($inv['country_origin'] ?? '', $preferred_countries, $country_map)) {
                $filtered_inverters[] = $inv;
            }
        }

        $filtered_panels = [];
        foreach ($available_panels as $p) {
            if (matchesCountryPreference($p['country_origin'] ?? '', $preferred_countries, $country_map)) {
                $filtered_panels[] = $p;
            }
        }

        // Only apply if we have candidates for BOTH inverters and panels
        if (!empty($filtered_inverters) && !empty($filtered_panels)) {
            $inverters = $filtered_inverters;
            $available_panels = $filtered_panels;
            $was_country_preference_applied = true;
        } else {
            // Log fallback immediately if initial pre-filtering yields nothing
            $algorithm_notes[] = [
                'type' => 'country_preference_fallback',
                'message' => 'No active components found matching your country preferences. Showing all available options instead.'
            ];
            $preferred_countries = []; // Clear country filters to avoid filtering batteries too
        }
    }

    $all_options = [];
    $on_grid_options = [];

    if ($system_type === 'on-grid') {
        // On-grid: No batteries, just inverter + panels
        $on_grid_options = buildSystemOptions(
            $db, $inverters, [], false,
            0, 0, $daily_energy_kwh, 0,
            $peak_sun_hours, $ambient_temp_c, $available_panels, 'on-grid',
            $preferred_countries, $country_map, $country_scores
        );

        if (empty($on_grid_options) && $was_country_preference_applied) {
            $algorithm_notes[] = [
                'type' => 'country_preference_fallback',
                'message' => 'No compatible On-Grid systems found matching your country preferences. Showing all available options instead.'
            ];
            $on_grid_options = buildSystemOptions(
                $db, $unfiltered_inverters, [], false,
                0, 0, $daily_energy_kwh, 0,
                $peak_sun_hours, $ambient_temp_c, $unfiltered_panels, 'on-grid',
                [], [], $country_scores
            );
        }

        $categories[] = [
            'category_id'   => 'on_grid',
            'category_name' => '⚡ On-Grid System',
            'category_description' => 'Grid-Tied Inverter + Solar Panels (No Battery)',
            'battery_types' => 'None required',
            'best_for'      => 'Maximum savings via net metering, lowest upfront cost, ideal for areas with stable grid',
            'trade_offs'    => 'No backup during power outage, depends on grid availability',
            'options'       => $on_grid_options,
            'has_options'   => !empty($on_grid_options),
        ];
    } else {
        // Hybrid or Off-grid: Build recommendations then sort into price tiers
        $sizing_backup_hours = $effective_backup_hours;

        // D1: System-type-aware battery filtering
        if ($system_type === 'hybrid') {
            // Hybrid: ONLY lithium/LFP with BMS — best technology for hybrid systems
            $all_options = buildSystemOptions(
                $db, $inverters, ['lithium', 'lfp'], true,
                $sizing_backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
                $peak_sun_hours, $ambient_temp_c, $available_panels, $system_type,
                $preferred_countries, $country_map, $country_scores
            );
        } else {
            // Off-grid: ALL battery types allowed (lithium, lfp, lead-acid, gel, agm)
            $all_options = buildSystemOptions(
                $db, $inverters, ['lithium', 'lfp', 'lead-acid', 'gel', 'agm'], false,
                $sizing_backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
                $peak_sun_hours, $ambient_temp_c, $available_panels, $system_type,
                $preferred_countries, $country_map, $country_scores
            );
        }

        if (empty($all_options) && $was_country_preference_applied) {
            $algorithm_notes[] = [
                'type' => 'country_preference_fallback',
                'message' => 'No compatible battery systems found matching your country preferences. Showing all available options instead.'
            ];
            if ($system_type === 'hybrid') {
                $all_options = buildSystemOptions(
                    $db, $unfiltered_inverters, ['lithium', 'lfp'], true,
                    $sizing_backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
                    $peak_sun_hours, $ambient_temp_c, $unfiltered_panels, $system_type,
                    [], [], $country_scores
                );
            } else {
                $all_options = buildSystemOptions(
                    $db, $unfiltered_inverters, ['lithium', 'lfp', 'lead-acid', 'gel', 'agm'], false,
                    $sizing_backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
                    $peak_sun_hours, $ambient_temp_c, $unfiltered_panels, $system_type,
                    [], [], $country_scores
                );
            }
        }

    // ══════════════════════════════════════════════════════════════════════════
    // v9.5: Generate MULTIPLE OPTIONS PER TIER (Budget, Balanced, Premium)
    // Returns 3-4 options per tier (total 9-12 options) for better choice
    // ══════════════════════════════════════════════════════════════════════════
    $multi_tier_result = generateMultiTierOptions(
        $db, $inverters, $battery_types, $bms_required,
        $sizing_backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
        $peak_sun_hours, $ambient_temp_c, $available_panels, $system_type,
        $preferred_countries, $country_map, $country_scores
    );

    // Check if we got any options
    $has_budget = !empty($multi_tier_result['budget']);
    $has_balanced = !empty($multi_tier_result['balanced']);
    $has_premium = !empty($multi_tier_result['premium']);

    if (!$has_budget && !$has_balanced && !$has_premium) {
        // Try fallback if country preference was applied
        if ($was_country_preference_applied) {
            $algorithm_notes[] = [
                'type' => 'country_preference_fallback',
                'message' => 'No compatible systems found matching your country preferences. Showing all available options instead.'
            ];

            if ($system_type === 'hybrid') {
                $multi_tier_result = generateMultiTierOptions(
                    $db, $unfiltered_inverters, ['lithium', 'lfp'], true,
                    $sizing_backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
                    $peak_sun_hours, $ambient_temp_c, $unfiltered_panels, $system_type,
                    [], [], $country_scores
                );
            } else {
                $multi_tier_result = generateMultiTierOptions(
                    $db, $unfiltered_inverters, ['lithium', 'lfp', 'lead-acid', 'gel', 'agm'], false,
                    $sizing_backup_hours, $avg_night_load_w, $daily_energy_kwh, $battery_recharge_kwh,
                    $peak_sun_hours, $ambient_temp_c, $unfiltered_panels, $system_type,
                    [], [], $country_scores
                );
            }

            // Re-check after fallback
            $has_budget = !empty($multi_tier_result['budget']);
            $has_balanced = !empty($multi_tier_result['balanced']);
            $has_premium = !empty($multi_tier_result['premium']);
        }
    }

    $battery_label = ($system_type === 'hybrid') ? 'Lithium/LFP with BMS' : 'All Types (Lithium, Gel, AGM, Lead-Acid)';

    // Build response with 3 tiers (each containing multiple options)
    $categories = [
        [
            'category_id'   => 'budget',
            'category_name' => '💰 Budget',
            'category_description' => 'Lowest cost while meeting requirements',
            'battery_types' => $battery_label,
            'best_for'      => 'Lowest upfront investment',
            'trade_offs'    => 'May have shorter warranty',
            'options'       => $multi_tier_result['budget'] ?? [],  // Array of options
            'has_options'   => $has_budget,
            'all_options'   => $multi_tier_result['budget'] ?? [],  // For "load more"
        ],
        [
            'category_id'   => 'balanced',
            'category_name' => '⚖️ Balanced',
            'category_description' => 'Best value - optimal quality per dollar',
            'battery_types' => $battery_label,
            'best_for'      => 'Best long-term value',
            'trade_offs'    => 'Mid-range pricing',
            'options'       => $multi_tier_result['balanced'] ?? [],  // Array of options
            'has_options'   => $has_balanced,
            'all_options'   => $multi_tier_result['balanced'] ?? [],
        ],
        [
            'category_id'   => 'premium',
            'category_name' => '👑 Premium',
            'category_description' => 'Top quality brands and longest warranties',
            'battery_types' => $battery_label,
            'best_for'      => 'Longest lifespan, best warranties',
            'trade_offs'    => 'Higher upfront cost',
            'options'       => $multi_tier_result['premium'] ?? [],  // Array of options
            'has_options'   => $has_premium,
            'all_options'   => $multi_tier_result['premium'] ?? [],
        ],
    ];

    // Add meta information about the generation
    $generation_meta = [
        'total_options_generated' => $multi_tier_result['total_generated'] ?? 0,
        'budget_count' => $multi_tier_result['budget_count'] ?? 0,
        'balanced_count' => $multi_tier_result['balanced_count'] ?? 0,
        'premium_count' => $multi_tier_result['premium_count'] ?? 0,
        'algorithm_version' => 'v9.5-multi-option'
    ];

    // ── STEP 6.5: Algorithm Validation & Fallback Suggestions ─────────────────
    $algorithm_notes = $algorithm_notes ?? [];

    // Add phase detection note if applicable
    if ($phase_detection_note) {
        array_unshift($algorithm_notes, $phase_detection_note);
    }

    $has_any_options = $has_budget || $has_balanced || $has_premium;

    if (!$has_any_options && $system_type !== 'on-grid') {
        // No battery configurations worked — provide diagnostic info
        $algorithm_notes[] = [
            'type' => 'no_battery_configs',
            'message' => "No compatible battery configurations found for {$backup_hours}h backup at {$avg_night_load_w}W night load.",
            'suggestions' => [],
        ];

        if ($system_type === 'off-grid') {
            $algorithm_notes[0]['suggestions'][] = 'Try reducing backup hours (current: ' . $backup_hours . 'h)';
            $algorithm_notes[0]['suggestions'][] = 'Consider switching to Hybrid — grid provides backup, smaller battery bank needed';
            $algorithm_notes[0]['suggestions'][] = 'Reduce nighttime load by removing high-wattage appliances running at night';
        } elseif ($system_type === 'hybrid') {
            $algorithm_notes[0]['suggestions'][] = 'Try reducing backup hours (current: ' . $backup_hours . 'h)';
            $algorithm_notes[0]['suggestions'][] = 'Consider On-Grid if backup power is not critical';
            $algorithm_notes[0]['suggestions'][] = 'No lithium/LFP batteries available for this configuration';

            // Hybrid fallback: try gel/agm if no lithium available
            $hybrid_fallback = buildSystemOptions(
                $db, $inverters, ['gel', 'agm'], false,
                $sizing_backup_hours ?? $effective_backup_hours, $avg_night_load_w,
                $daily_energy_kwh, $battery_recharge_kwh,
                $peak_sun_hours, $ambient_temp_c, $available_panels, $system_type,
                [], [], $country_scores
            );
            if (!empty($hybrid_fallback)) {
                usort($hybrid_fallback, fn($a, $b) => $a['total_cost'] <=> $b['total_cost']);
                $categories[] = [
                    'category_id'   => 'balanced',
                    'category_name' => '⚖️ Alternative (Gel/AGM)',
                    'category_description' => 'Hybrid System with Gel/AGM batteries (Lithium unavailable)',
                    'battery_types' => 'Gel / AGM (sealed)',
                    'best_for'      => 'Good alternative when lithium/LFP batteries are not available in your capacity range',
                    'trade_offs'    => 'Shorter cycle life than lithium, but zero maintenance',
                    'options'       => array_slice($hybrid_fallback, 0, 6),
                    'has_options'   => true,
                    'is_fallback'   => true,
                ];
                $has_any_options = true;
            }
        }

        // Attempt reduced backup as automatic fallback for off-grid
        if ($system_type === 'off-grid' && $backup_hours > 2) {
            $reduced_hours = max(2, floor($backup_hours * 0.5));
            $reduced_recharge = ($avg_night_load_w * $reduced_hours) / 1000;

            $fallback_options = buildSystemOptions(
                $db, $inverters, ['lithium', 'lfp', 'gel', 'agm', 'lead-acid'], false,
                $reduced_hours, $avg_night_load_w, $daily_energy_kwh, $reduced_recharge,
                $peak_sun_hours, $ambient_temp_c, $available_panels, $system_type,
                [], [], $country_scores
            );

            if (!empty($fallback_options)) {
                $algorithm_notes[] = [
                    'type' => 'reduced_backup_available',
                    'message' => "Systems available with reduced backup ({$reduced_hours}h instead of {$backup_hours}h)",
                    'reduced_backup_hours' => $reduced_hours,
                    'options_count' => count($fallback_options),
                ];
                $categories[] = [
                    'category_id'   => 'reduced_backup',
                    'category_name' => '⚠️ Reduced Backup (' . $reduced_hours . 'h)',
                    'category_description' => 'Systems with reduced backup time (fewer batteries needed)',
                    'battery_types' => 'All types',
                    'best_for'      => "Best match for your load when full {$backup_hours}h backup exceeds battery limits",
                    'trade_offs'    => "Only {$reduced_hours}h backup instead of requested {$backup_hours}h",
                    'options'       => array_slice($fallback_options, 0, 6),
                    'has_options'   => true,
                    'is_fallback'   => true,
                ];
            }
        }
    }

    if ($system_type === 'hybrid') {
        $algorithm_notes[] = [
            'type' => 'hybrid_sizing_note',
            'message' => 'Battery sized for ' . round($effective_backup_hours, 1) . 'h backup (70% of requested ' . $backup_hours . 'h) — grid provides additional fallback.',
        ];
    }

    // ── STEP 7: Net Metering Calculations ────────────────────────────────────
    $net_metering_data = null;
    if ($net_metering_enabled && ($system_type === 'on-grid' || $system_type === 'hybrid')) {
        // Use the first available panel config for generation estimate
        $gen_kwh = 0;
        foreach ($categories as $cat) {
            if (!empty($cat['options'])) {
                $gen_kwh = $cat['options'][0]['panel_config']['daily_gen_kwh'] ?? 0;
                break;
            } elseif (!empty($cat['option'])) {
                $gen_kwh = $cat['option']['panel_config']['daily_gen_kwh'] ?? 0;
                break;
            }
        }
        if ($gen_kwh > 0) {
            $net_metering_data = calculateNetMetering(
                $gen_kwh,
                $daily_energy_kwh,
                $sellback_rate_pct,
                $electricity_rate_kwh,
                $sell_rate_kwh
            );
        }
    }

    // ── STEP 8: Nearby Shops ─────────────────────────────────────────────────
    $nearby_shops = [];
    if ($user_lat != 0 && $user_lng != 0) {
        try {
            $nearby_shops = findNearbyShops($db, $user_lat, $user_lng, $shop_radius);
        } catch (Exception $e) {
            error_log("v8.0 Shop search error: " . $e->getMessage());
        }
    }

    // ── STEP 9: Build Response ───────────────────────────────────────────────
    $total_options = 0;
    foreach ($categories as $cat) {
        // Handle both 'options' (array) and 'option' (single) keys from tiered display
        if (!empty($cat['options'])) {
            $total_options += count($cat['options']);
        } elseif (!empty($cat['option'])) {
            $total_options += 1;
        }
    }

    // ── STEP 9.5: Shop Mode — Dealer inventory enrichment ────────────────────
    $dealers_available = !empty($nearby_shops);
    $dealer_inventory = [];

    if ($rec_mode === 'shop' && $dealers_available) {
        // Enrich each option with dealer availability
        // Handle both 'options' (array) and 'option' (single) keys
        foreach ($categories as &$cat_ref) {
            $opts_to_process = [];
            if (!empty($cat_ref['options'])) {
                foreach ($cat_ref['options'] as &$opt_ref) {
                    $opts_to_process[] = &$opt_ref;
                }
                unset($opt_ref);
            } elseif (!empty($cat_ref['option'])) {
                $opts_to_process[] = &$cat_ref['option'];
            }
            foreach ($opts_to_process as &$opt_ref) {
                $inv_id = intval($opt_ref['inverter']['id'] ?? 0);
                $pan_id = intval($opt_ref['panel_config']['panel']['id'] ?? 0);
                $bat_id = $opt_ref['battery_config'] ? intval($opt_ref['battery_config']['battery']['id'] ?? 0) : 0;

                $opt_ref['dealer_availability'] = [];
                foreach ($nearby_shops as $shop) {
                    $shop_id = intval($shop['id']);
                    try {
                        $inv_stock = checkDealerInventory($db, $shop_id, $inv_id, null, null);
                        $pan_stock = checkDealerInventory($db, $shop_id, null, $pan_id, null);
                        $bat_stock = $bat_id ? checkDealerInventory($db, $shop_id, null, null, $bat_id) : [];

                        $has_inv = !empty($inv_stock['inverter']);
                        $has_pan = !empty($pan_stock['panel']);
                        $has_bat = $bat_id ? !empty($bat_stock['battery']) : true;

                        if ($has_inv || $has_pan || $has_bat) {
                            $dealer_entry = [
                                'dealer_id'     => $shop_id,
                                'business_name' => $shop['business_name'] ?? '',
                                'distance_km'   => $shop['distance_km'] ?? 0,
                                'city'          => $shop['city'] ?? '',
                                'phone'         => $shop['phone'] ?? '',
                                'has_inverter'  => $has_inv,
                                'has_panel'     => $has_pan,
                                'has_battery'   => $has_bat,
                            ];
                            if ($has_inv && isset($inv_stock['inverter']['dealer_price'])) {
                                $dealer_entry['inverter_price'] = floatval($inv_stock['inverter']['dealer_price']);
                                $dealer_entry['inverter_stock'] = intval($inv_stock['inverter']['stock_quantity'] ?? 0);
                            }
                            if ($has_pan && isset($pan_stock['panel']['dealer_price'])) {
                                $dealer_entry['panel_price'] = floatval($pan_stock['panel']['dealer_price']);
                                $dealer_entry['panel_stock'] = intval($pan_stock['panel']['stock_quantity'] ?? 0);
                            }
                            if ($has_bat && isset($bat_stock['battery']['dealer_price'])) {
                                $dealer_entry['battery_price'] = floatval($bat_stock['battery']['dealer_price']);
                                $dealer_entry['battery_stock'] = intval($bat_stock['battery']['stock_quantity'] ?? 0);
                            }
                            $opt_ref['dealer_availability'][] = $dealer_entry;
                        }
                    } catch (Exception $e) {
                        // Skip dealer on error
                    }
                }
            }
            unset($opt_ref);
        }
        unset($cat_ref);
    }

    // Apply country price adjustments to all options
    $priceAdjustmentInfo = $currencyHelper->getPriceAdjustmentBreakdown('inverter');
    if ($priceAdjustmentInfo['has_adjustments'] ?? false) {
        foreach ($categories as &$cat_ref) {
            // Collect references to all options (handle both 'options' array and 'option' single)
            $opts_to_adjust = [];
            if (!empty($cat_ref['options'])) {
                foreach ($cat_ref['options'] as &$opt_ref) {
                    $opts_to_adjust[] = &$opt_ref;
                }
                unset($opt_ref);
            } elseif (!empty($cat_ref['option'])) {
                $opts_to_adjust[] = &$cat_ref['option'];
            }
            foreach ($opts_to_adjust as &$opt_ref) {
                if (isset($opt_ref['inverter']['price_usd'])) {
                    $opt_ref['inverter']['price_adjusted'] = $currencyHelper->applyPriceAdjustment(
                        floatval($opt_ref['inverter']['price_usd']), 'inverter'
                    );
                }
                if (isset($opt_ref['panel_config']['panel']['price_usd'])) {
                    $opt_ref['panel_config']['panel']['price_adjusted'] = $currencyHelper->applyPriceAdjustment(
                        floatval($opt_ref['panel_config']['panel']['price_usd']), 'panel'
                    );
                }
                if (isset($opt_ref['battery_config']['battery']['price_usd'])) {
                    $opt_ref['battery_config']['battery']['price_adjusted'] = $currencyHelper->applyPriceAdjustment(
                        floatval($opt_ref['battery_config']['battery']['price_usd']), 'battery'
                    );
                }
                $adj_total = 0;
                if (isset($opt_ref['inverter']['price_adjusted'])) {
                    $adj_total += $opt_ref['inverter']['price_adjusted'];
                }
                if (isset($opt_ref['panel_config']['total_cost'])) {
                    $panelAdj = $currencyHelper->applyPriceAdjustment(floatval($opt_ref['panel_config']['total_cost']), 'panel');
                    $opt_ref['panel_config']['total_cost_adjusted'] = $panelAdj;
                    $adj_total += $panelAdj;
                }
                if (isset($opt_ref['battery_config']['total_cost'])) {
                    $batAdj = $currencyHelper->applyPriceAdjustment(floatval($opt_ref['battery_config']['total_cost']), 'battery');
                    $opt_ref['battery_config']['total_cost_adjusted'] = $batAdj;
                    $adj_total += $batAdj;
                }
                if ($adj_total > 0) {
                    $opt_ref['total_cost_adjusted'] = round($adj_total, 2);
                    $opt_ref['total_cost_local'] = $currencyHelper->convertFromUSD($adj_total);
                }
            }
            unset($opt_ref);
        }
        unset($cat_ref);
    }

    // ── STEP 9.7: Before/After Bill Comparison (always calculated) ──────────
    $bill_comparison = null;
    $gen_kwh_for_bill = 0;
    foreach ($categories as $cat) {
        if (!empty($cat['options'])) {
            $gen_kwh_for_bill = $cat['options'][0]['panel_config']['daily_gen_kwh'] ?? 0;
            break;
        } elseif (!empty($cat['option'])) {
            $gen_kwh_for_bill = $cat['option']['panel_config']['daily_gen_kwh'] ?? 0;
            break;
        }
    }
    if ($gen_kwh_for_bill > 0) {
        $self_consumed = min($gen_kwh_for_bill, $daily_energy_kwh);
        $surplus = max(0, $gen_kwh_for_bill - $daily_energy_kwh);
        $still_import = max(0, $daily_energy_kwh - $gen_kwh_for_bill);

        $daily_before = $daily_energy_kwh * $electricity_rate_kwh;
        $daily_after = ($still_import * $electricity_rate_kwh) - ($surplus * $sell_rate_kwh);
        $daily_after = max(0, $daily_after);

        $bill_comparison = [
            'daily_bill_before'   => round($daily_before, 2),
            'daily_bill_after'    => round($daily_after, 2),
            'monthly_bill_before' => round($daily_before * 30, 0),
            'monthly_bill_after'  => round($daily_after * 30, 0),
            'monthly_savings'     => round(($daily_before - $daily_after) * 30, 0),
            'annual_savings'      => round(($daily_before - $daily_after) * 365, 0),
            'savings_percent'     => $daily_before > 0 ? round((1 - $daily_after / $daily_before) * 100, 0) : 0,
            'buy_rate'            => $electricity_rate_kwh,
            'sell_rate'           => $sell_rate_kwh,
        ];
    }

    $response = [
        'success'       => true,
        'version'       => 'v9.5',  // Updated version
        'mode'          => $rec_mode,
        'tiered_display' => ($system_type !== 'on-grid'), // D2: frontend uses tiered rendering
        'system_type'   => $system_type,
        'usage_type'    => $usage_type,
        'three_phase'   => $three_phase,
        'currency'      => $pricingContext,
        'price_adjustments' => $priceAdjustmentInfo,
        'grid_info'     => $gridInfo,
        'load_analysis' => [
            'total_load_watts'        => $total_load_watts,
            'peak_load_watts'         => $peak_load_watts,
            'peak_surge_load_watts'   => $peak_surge_load,
            'daily_energy_kwh'        => round($daily_energy_kwh, 2),
            'required_inverter_watts' => $required_inverter_watts,
            'backup_hours_requested'  => ($system_type === 'on-grid') ? 0 : $backup_hours,
            'effective_backup_hours'  => ($system_type === 'on-grid') ? 0 : round($effective_backup_hours, 1),
            'avg_night_load_w'        => round($avg_night_load_w, 1),
            'night_peak_w'            => round($night_peak_w, 1),
            'total_night_kwh'         => round($total_night_kwh, 2),
            'total_day_kwh'           => round($total_day_kwh, 2),
            'day_peak_w'              => round($day_peak_w, 1),
            'battery_recharge_kwh'    => round($battery_recharge_kwh, 2),
            'peak_sun_hours_used'     => $peak_sun_hours,
            'ambient_temp_c'          => $ambient_temp_c,
            'hourly_load'             => $hourly_load,
            'appliance_details'       => $appliance_details,
        ],
        'categories'        => $categories,
        'total_options'     => $total_options,
        'parallel_options'  => $parallel_options,
        'algorithm_notes'   => $algorithm_notes,
        'generation_meta'   => $generation_meta ?? [],  // v9.5: Add generation metadata
        'net_metering'      => $net_metering_data,
        'bill_comparison'   => $bill_comparison,
        'nearby_shops'      => ($rec_mode === 'shop') ? array_slice($nearby_shops, 0, 10) : [],
        'shop_search'       => [
            'radius_km'        => $shop_radius,
            'total_found'      => count($nearby_shops),
            'has_location'     => ($user_lat != 0 && $user_lng != 0),
            'dealers_available' => $dealers_available,
            'mode'             => $rec_mode,
        ],
    ];

    // Enhance with solar intelligence if city available
    if ($city_id_input > 0) {
        $response = $enhancer->enhanceRecommendation($response);
    }

    respond_json($response);

} // End of main try block

} catch (PDOException $e) {
    error_log("v8.0 PDOException: " . $e->getMessage());
    respond_json(['success' => false, 'error' => 'db_error', 'message' => 'Database error: ' . $e->getMessage()], 500);
} catch (Exception $e) {
    error_log("v8.0 Exception: " . $e->getMessage());
    respond_json(['success' => false, 'error' => 'server_error', 'message' => 'Server error: ' . $e->getMessage()], 500);
}
