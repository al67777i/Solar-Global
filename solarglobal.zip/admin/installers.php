<?php
/**
 * Admin - Installer Management
 * View, approve, reject, suspend, and manage solar installers
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

$pageTitle = 'Installers';
$db = getDB();
$success = '';
$error = '';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';
    $installer_id = (int)($_POST['installer_id'] ?? 0);

    if ($installer_id && $action) {
        if ($action === 'approve') {
            $db->prepare("UPDATE installers SET status = 'approved', approved_by = ?, approved_at = NOW() WHERE id = ?")
               ->execute([$_SESSION['admin_id'], $installer_id]);
            $success = 'Installer approved successfully!';
        } elseif ($action === 'activate') {
            $db->prepare("UPDATE installers SET status = 'active' WHERE id = ?")->execute([$installer_id]);
            $success = 'Installer activated!';
        } elseif ($action === 'suspend') {
            $reason = trim($_POST['reason'] ?? 'Account suspended by admin.');
            $db->prepare("UPDATE installers SET status = 'suspended', suspension_reason = ? WHERE id = ?")
               ->execute([$reason, $installer_id]);
            $success = 'Installer suspended.';
        } elseif ($action === 'reject') {
            $reason = trim($_POST['reason'] ?? 'Application did not meet our requirements.');
            $db->prepare("UPDATE installers SET status = 'rejected', rejection_reason = ? WHERE id = ?")
               ->execute([$reason, $installer_id]);
            $success = 'Installer rejected.';
        } elseif ($action === 'delete') {
            $db->prepare("DELETE FROM installers WHERE id = ?")->execute([$installer_id]);
            $success = 'Installer deleted permanently.';
        } elseif ($action === 'toggle_featured') {
            $db->prepare("UPDATE installers SET is_featured = NOT is_featured WHERE id = ?")->execute([$installer_id]);
            $success = 'Featured status toggled.';
        } elseif ($action === 'toggle_live') {
            $db->prepare("UPDATE installers SET is_live = NOT is_live WHERE id = ?")->execute([$installer_id]);
            $success = 'Installer visibility updated.';
        } elseif ($action === 'approve_review') {
            $review_id = (int)($_POST['review_id'] ?? 0);
            if ($review_id) {
                $db->prepare("UPDATE installer_reviews SET status = 'approved' WHERE id = ?")->execute([$review_id]);
                $success = 'Review approved.';
            }
        } elseif ($action === 'reject_review') {
            $review_id = (int)($_POST['review_id'] ?? 0);
            if ($review_id) {
                $db->prepare("UPDATE installer_reviews SET status = 'rejected' WHERE id = ?")->execute([$review_id]);
                $success = 'Review rejected.';
            }
        }
    }
}

// Filters
$status_filter = $_GET['status'] ?? 'all';
$search = trim($_GET['search'] ?? '');
$where_parts = [];
$params = [];

if ($status_filter !== 'all') {
    $where_parts[] = 'i.status = ?';
    $params[] = $status_filter;
}
$sub_filter_q = $_GET['sub'] ?? 'all';
if ($sub_filter_q !== 'all') {
    $where_parts[] = 'i.subscription_status = ?';
    $params[] = $sub_filter_q;
}
if ($search) {
    $where_parts[] = '(i.business_name LIKE ? OR i.owner_name LIKE ? OR i.email LIKE ?)';
    $search_param = "%{$search}%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

$where = $where_parts ? 'WHERE ' . implode(' AND ', $where_parts) : '';

// Fetch installers
$installers = $db->prepare("
    SELECT i.*,
        (SELECT COUNT(*) FROM installer_reviews r WHERE r.installer_id = i.id AND r.status = 'approved') AS review_count,
        (SELECT AVG(r.rating) FROM installer_reviews r WHERE r.installer_id = i.id AND r.status = 'approved') AS avg_rating
    FROM installers i
    $where
    ORDER BY
        CASE i.status
            WHEN 'pending' THEN 1
            WHEN 'approved' THEN 2
            WHEN 'active' THEN 3
            WHEN 'suspended' THEN 4
            WHEN 'rejected' THEN 5
        END,
        i.created_at DESC
");
$installers->execute($params);
$installers = $installers->fetchAll();

// Count by status
$counts = $db->query("
    SELECT status, COUNT(*) as cnt FROM installers GROUP BY status
")->fetchAll(PDO::FETCH_KEY_PAIR);
$total = array_sum($counts);

// Count by subscription status
$sub_counts = $db->query("
    SELECT subscription_status, COUNT(*) as cnt FROM installers GROUP BY subscription_status
")->fetchAll(PDO::FETCH_KEY_PAIR);

$sub_filter = $_GET['sub'] ?? 'all';

// Overall stats
$stats = $db->query("
    SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
        AVG((SELECT AVG(r.rating) FROM installer_reviews r WHERE r.installer_id = installers.id AND r.status = 'approved')) as overall_rating
    FROM installers
")->fetch();

include __DIR__ . '/includes/header.php';
?>

<style>
.stats-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}
.stat-card {
    background: white;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    border: 1px solid #E2E8F0;
}
.stat-card-value {
    font-size: 1.75rem;
    font-weight: 800;
    color: #0F172A;
}
.stat-card-label {
    font-size: 0.8125rem;
    color: #64748B;
    margin-top: 4px;
}
.stat-card-value.amber { color: #F59E0B; }
.stat-card-value.green { color: #16A34A; }
.stat-card-value.blue { color: #1565C0; }

.search-row {
    display: flex;
    gap: 12px;
    align-items: center;
    margin-bottom: 16px;
}
.search-input {
    padding: 8px 14px;
    border: 2px solid #E2E8F0;
    border-radius: 8px;
    font-size: 0.875rem;
    width: 280px;
    outline: none;
    transition: border-color 0.2s;
}
.search-input:focus {
    border-color: #F59E0B;
}
.search-btn {
    padding: 8px 18px;
    background: #0F172A;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
}
.search-btn:hover {
    background: #1E293B;
}

.installer-logo {
    width: 38px;
    height: 38px;
    border-radius: 8px;
    object-fit: cover;
    background: #F1F5F9;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    color: #94A3B8;
}
.installer-logo img {
    width: 100%;
    height: 100%;
    border-radius: 8px;
    object-fit: cover;
}

.rating-stars {
    color: #F59E0B;
    font-size: 0.8rem;
    letter-spacing: 1px;
}
.rating-value {
    font-size: 0.75rem;
    color: #64748B;
    margin-left: 4px;
}

.featured-badge {
    display: inline-block;
    padding: 2px 8px;
    background: #FEF3C7;
    color: #92400E;
    font-size: 0.65rem;
    font-weight: 700;
    border-radius: 4px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.action-btn {
    padding: 5px 12px;
    border: none;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
    cursor: pointer;
    transition: opacity 0.2s;
}
.action-btn:hover { opacity: 0.85; }
.action-btn-approve { background: #16A34A; color: white; }
.action-btn-activate { background: #1565C0; color: white; }
.action-btn-suspend { background: #F59E0B; color: white; }
.action-btn-reject { background: #DC2626; color: white; }
.action-btn-delete { background: #1E293B; color: white; }
.action-btn-featured { background: #7C3AED; color: white; }
.action-btn-reviews { background: #0EA5E9; color: white; }

/* Modal */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.5);
    z-index: 9999;
    align-items: center;
    justify-content: center;
}
.modal-overlay.active { display: flex; }
.modal-content {
    background: white;
    border-radius: 12px;
    width: 90%;
    max-width: 600px;
    max-height: 80vh;
    overflow-y: auto;
    box-shadow: 0 20px 60px rgba(0,0,0,0.2);
}
.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #E2E8F0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.modal-header h3 {
    font-size: 1.1rem;
    font-weight: 700;
    color: #0F172A;
}
.modal-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #94A3B8;
    padding: 4px;
}
.modal-close:hover { color: #475569; }
.modal-body { padding: 24px; }

.reason-input {
    width: 100%;
    padding: 10px 14px;
    border: 2px solid #E2E8F0;
    border-radius: 8px;
    font-size: 0.875rem;
    margin-top: 8px;
    resize: vertical;
    min-height: 80px;
    outline: none;
}
.reason-input:focus { border-color: #F59E0B; }

.review-item {
    border: 1px solid #E2E8F0;
    border-radius: 8px;
    padding: 14px;
    margin-bottom: 12px;
}
.review-item-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
}
.review-author {
    font-weight: 600;
    font-size: 0.875rem;
    color: #0F172A;
}
.review-date {
    font-size: 0.75rem;
    color: #94A3B8;
}
.review-text {
    font-size: 0.85rem;
    color: #475569;
    line-height: 1.5;
    margin-bottom: 8px;
}
.review-actions {
    display: flex;
    gap: 8px;
}
.review-status-badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.7rem;
    font-weight: 600;
}
</style>

<div class="content-wrapper" style="padding: 24px;">
    <!-- Page Header -->
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap; gap:12px;">
        <h2 style="font-size:1.5rem; color:#1E293B;">Installer Management</h2>
        <span style="font-size:0.875rem; color:#64748B;"><?= $total ?> total installers</span>
    </div>

    <?php if ($success): ?>
        <div style="background:#DCFCE7; color:#166534; padding:12px 16px; border-radius:8px; margin-bottom:16px; font-size:0.875rem;">
            <?= sanitize($success) ?>
        </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="stats-cards">
        <div class="stat-card">
            <div class="stat-card-value"><?= $stats['total'] ?? 0 ?></div>
            <div class="stat-card-label">Total Installers</div>
        </div>
        <div class="stat-card">
            <div class="stat-card-value amber"><?= $stats['pending'] ?? 0 ?></div>
            <div class="stat-card-label">Pending Approval</div>
        </div>
        <div class="stat-card">
            <div class="stat-card-value green"><?= $stats['active'] ?? 0 ?></div>
            <div class="stat-card-label">Active Installers</div>
        </div>
        <div class="stat-card">
            <div class="stat-card-value blue"><?= $stats['overall_rating'] ? number_format($stats['overall_rating'], 1) : 'N/A' ?></div>
            <div class="stat-card-label">Average Rating</div>
        </div>
    </div>

    <!-- Search -->
    <form method="GET" class="search-row">
        <?php if ($status_filter !== 'all'): ?>
            <input type="hidden" name="status" value="<?= sanitize($status_filter) ?>">
        <?php endif; ?>
        <input type="text" name="search" class="search-input" placeholder="Search by name or email..." value="<?= sanitize($search) ?>">
        <button type="submit" class="search-btn">Search</button>
        <?php if ($search): ?>
            <a href="?status=<?= sanitize($status_filter) ?>" style="font-size:0.8rem; color:#DC2626; text-decoration:none;">Clear</a>
        <?php endif; ?>
    </form>

    <!-- Status Filters -->
    <div style="margin-bottom:8px; font-size:0.75rem; font-weight:600; color:#64748B; text-transform:uppercase; letter-spacing:0.5px;">Account Status</div>
    <div style="display:flex; gap:8px; margin-bottom:16px; flex-wrap:wrap;">
        <a href="?status=all<?= $search ? '&search=' . urlencode($search) : '' ?><?= $sub_filter !== 'all' ? '&sub=' . urlencode($sub_filter) : '' ?>" style="padding:8px 18px; border:2px solid <?= $status_filter==='all' ? '#F59E0B' : '#E2E8F0' ?>; border-radius:8px; text-decoration:none; font-size:0.875rem; font-weight:500; color:<?= $status_filter==='all' ? '#92400E' : '#475569' ?>; background:<?= $status_filter==='all' ? '#FEF3C7' : 'white' ?>;">
            All (<?= $total ?>)
        </a>
        <?php foreach (['pending'=>'Pending', 'approved'=>'Approved', 'active'=>'Active', 'suspended'=>'Suspended'] as $k => $v): ?>
            <a href="?status=<?= $k ?><?= $search ? '&search=' . urlencode($search) : '' ?><?= $sub_filter !== 'all' ? '&sub=' . urlencode($sub_filter) : '' ?>" style="padding:8px 18px; border:2px solid <?= $status_filter===$k ? '#F59E0B' : '#E2E8F0' ?>; border-radius:8px; text-decoration:none; font-size:0.875rem; font-weight:500; color:<?= $status_filter===$k ? '#92400E' : '#475569' ?>; background:<?= $status_filter===$k ? '#FEF3C7' : 'white' ?>;">
                <?= $v ?> (<?= $counts[$k] ?? 0 ?>)
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Subscription Filters -->
    <div style="margin-bottom:8px; font-size:0.75rem; font-weight:600; color:#64748B; text-transform:uppercase; letter-spacing:0.5px;">Subscription Status</div>
    <div style="display:flex; gap:8px; margin-bottom:20px; flex-wrap:wrap;">
        <a href="?sub=all<?= $status_filter !== 'all' ? '&status=' . urlencode($status_filter) : '' ?><?= $search ? '&search=' . urlencode($search) : '' ?>" style="padding:6px 14px; border:2px solid <?= $sub_filter==='all' ? '#16A34A' : '#E2E8F0' ?>; border-radius:8px; text-decoration:none; font-size:0.8125rem; font-weight:500; color:<?= $sub_filter==='all' ? '#166534' : '#475569' ?>; background:<?= $sub_filter==='all' ? '#DCFCE7' : 'white' ?>;">
            All
        </a>
        <?php foreach (['active'=>'Subscribed', 'trial'=>'Trial', 'expired'=>'Expired', 'canceled'=>'Canceled', 'none'=>'None'] as $sk => $sv): ?>
            <a href="?sub=<?= $sk ?><?= $status_filter !== 'all' ? '&status=' . urlencode($status_filter) : '' ?><?= $search ? '&search=' . urlencode($search) : '' ?>" style="padding:6px 14px; border:2px solid <?= $sub_filter===$sk ? '#16A34A' : '#E2E8F0' ?>; border-radius:8px; text-decoration:none; font-size:0.8125rem; font-weight:500; color:<?= $sub_filter===$sk ? '#166534' : '#475569' ?>; background:<?= $sub_filter===$sk ? '#DCFCE7' : 'white' ?>;">
                <?= $sv ?> (<?= $sub_counts[$sk] ?? 0 ?>)
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Installers Table -->
    <div style="background:white; border-radius:12px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.04); overflow-x:auto;">
        <table style="width:100%; border-collapse:collapse; min-width:900px;">
            <thead>
                <tr style="background:#F8FAFC;">
                    <th style="padding:12px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Logo</th>
                    <th style="padding:12px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Business Name</th>
                    <th style="padding:12px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Owner</th>
                    <th style="padding:12px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Email</th>
                    <th style="padding:12px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Location</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Rating</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Price/kW</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Status</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Subscription</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Live</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($installers)): ?>
                    <tr><td colspan="11" style="padding:40px; text-align:center; color:#94A3B8;">No installers found.</td></tr>
                <?php endif; ?>
                <?php foreach ($installers as $inst): ?>
                    <?php
                    $status_colors = [
                        'pending' => ['bg'=>'#FEF3C7','color'=>'#92400E'],
                        'approved' => ['bg'=>'#DBEAFE','color'=>'#1E40AF'],
                        'active' => ['bg'=>'#DCFCE7','color'=>'#166534'],
                        'suspended' => ['bg'=>'#FEE2E2','color'=>'#991B1B'],
                        'rejected' => ['bg'=>'#F1F5F9','color'=>'#475569'],
                    ];
                    $sc = $status_colors[$inst['status']] ?? $status_colors['pending'];
                    $rating = $inst['avg_rating'] ? number_format($inst['avg_rating'], 1) : null;
                    $stars = '';
                    if ($rating) {
                        $full = floor($rating);
                        for ($i = 0; $i < $full; $i++) $stars .= '&#9733;';
                        for ($i = $full; $i < 5; $i++) $stars .= '&#9734;';
                    }
                    ?>
                    <tr style="border-bottom:1px solid #F1F5F9;">
                        <td style="padding:14px 16px;">
                            <div class="installer-logo">
                                <?php if (!empty($inst['logo'])): ?>
                                    <img src="../uploads/installers/<?= sanitize($inst['logo']) ?>" alt="">
                                <?php else: ?>
                                    &#9888;
                                <?php endif; ?>
                            </div>
                        </td>
                        <td style="padding:14px 16px;">
                            <div style="font-weight:600; color:#1E293B;">
                                <?= sanitize($inst['business_name']) ?>
                                <?php if (!empty($inst['is_featured'])): ?>
                                    <span class="featured-badge">Featured</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td style="padding:14px 16px; font-size:0.875rem; color:#475569;">
                            <?= sanitize($inst['owner_name'] ?? '') ?>
                        </td>
                        <td style="padding:14px 16px; font-size:0.8125rem; color:#475569;">
                            <?= sanitize($inst['email'] ?? '') ?>
                        </td>
                        <td style="padding:14px 16px; font-size:0.875rem; color:#475569;">
                            <?= sanitize($inst['city'] ?? '') ?><?= ($inst['city'] ?? '') && ($inst['country_code'] ?? '') ? ', ' : '' ?><?= sanitize($inst['country_code'] ?? '') ?>
                        </td>
                        <td style="padding:14px 16px; text-align:center;">
                            <?php if ($rating): ?>
                                <span class="rating-stars"><?= $stars ?></span>
                                <span class="rating-value"><?= $rating ?> (<?= $inst['review_count'] ?>)</span>
                            <?php else: ?>
                                <span style="font-size:0.75rem; color:#94A3B8;">No reviews</span>
                            <?php endif; ?>
                        </td>
                        <td style="padding:14px 16px; text-align:center; font-size:0.875rem; font-weight:600; color:#0F172A;">
                            <?= isset($inst['price_per_kw']) && $inst['price_per_kw'] ? '$' . number_format($inst['price_per_kw'], 2) : '-' ?>
                        </td>
                        <td style="padding:14px 16px; text-align:center;">
                            <span style="display:inline-block; padding:3px 12px; border-radius:6px; font-size:0.75rem; font-weight:600; background:<?= $sc['bg'] ?>; color:<?= $sc['color'] ?>;">
                                <?= ucfirst($inst['status']) ?>
                            </span>
                        </td>
                        <?php
                        $sub_status_colors = [
                            'active' => ['bg'=>'#DCFCE7','color'=>'#166534'],
                            'trial' => ['bg'=>'#DBEAFE','color'=>'#1E40AF'],
                            'expired' => ['bg'=>'#FEE2E2','color'=>'#991B1B'],
                            'canceled' => ['bg'=>'#FEF3C7','color'=>'#92400E'],
                            'past_due' => ['bg'=>'#FEF3C7','color'=>'#92400E'],
                            'none' => ['bg'=>'#F1F5F9','color'=>'#64748B'],
                        ];
                        $ssc = $sub_status_colors[$inst['subscription_status'] ?? 'none'] ?? $sub_status_colors['none'];
                        ?>
                        <td style="padding:14px 16px; text-align:center;">
                            <span style="display:inline-block; padding:3px 10px; border-radius:6px; font-size:0.7rem; font-weight:600; background:<?= $ssc['bg'] ?>; color:<?= $ssc['color'] ?>;">
                                <?= ucfirst($inst['subscription_status'] ?? 'None') ?>
                            </span>
                            <?php if (!empty($inst['subscription_expires_at'])): ?>
                                <div style="font-size:0.7rem; color:#94A3B8; margin-top:2px;"><?= date('M d, Y', strtotime($inst['subscription_expires_at'])) ?></div>
                            <?php endif; ?>
                            <?php if (!empty($inst['grace_period_ends_at']) && strtotime($inst['grace_period_ends_at']) > time()): ?>
                                <div style="font-size:0.65rem; color:#DC2626; margin-top:1px;">Grace: <?= date('M d', strtotime($inst['grace_period_ends_at'])) ?></div>
                            <?php endif; ?>
                        </td>
                        <td style="padding:14px 16px; text-align:center;">
                            <form method="POST" style="display:inline">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="toggle_live">
                                <input type="hidden" name="installer_id" value="<?= $inst['id'] ?>">
                                <button type="submit" title="<?= ($inst['is_live'] ?? 1) ? 'Click to take offline' : 'Click to go live' ?>"
                                    style="background:none; border:none; cursor:pointer; font-size:1.4rem; line-height:1;"
                                ><?= ($inst['is_live'] ?? 1) ? '🟢' : '🔴' ?></button>
                            </form>
                        </td>
                        <td style="padding:14px 16px; text-align:center;">
                            <div style="display:flex; gap:4px; justify-content:center; flex-wrap:wrap;">
                                <a href="installer-detail.php?id=<?= $inst['id'] ?>" class="action-btn" style="background:#3B82F6; color:white; text-decoration:none;">View</a>
                                <?php if ($inst['status'] === 'pending'): ?>
                                    <form method="POST" style="display:inline">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="approve">
                                        <input type="hidden" name="installer_id" value="<?= $inst['id'] ?>">
                                        <button type="submit" class="action-btn action-btn-approve">Approve</button>
                                    </form>
                                    <button type="button" class="action-btn action-btn-reject" onclick="openReasonModal(<?= $inst['id'] ?>, 'reject')">Reject</button>
                                <?php elseif ($inst['status'] === 'approved'): ?>
                                    <form method="POST" style="display:inline">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="activate">
                                        <input type="hidden" name="installer_id" value="<?= $inst['id'] ?>">
                                        <button type="submit" class="action-btn action-btn-activate">Activate</button>
                                    </form>
                                    <button type="button" class="action-btn action-btn-suspend" onclick="openReasonModal(<?= $inst['id'] ?>, 'suspend')">Suspend</button>
                                <?php elseif ($inst['status'] === 'active'): ?>
                                    <button type="button" class="action-btn action-btn-suspend" onclick="openReasonModal(<?= $inst['id'] ?>, 'suspend')">Suspend</button>
                                <?php elseif ($inst['status'] === 'suspended'): ?>
                                    <form method="POST" style="display:inline">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="activate">
                                        <input type="hidden" name="installer_id" value="<?= $inst['id'] ?>">
                                        <button type="submit" class="action-btn action-btn-activate">Reactivate</button>
                                    </form>
                                <?php endif; ?>
                                <form method="POST" style="display:inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="toggle_featured">
                                    <input type="hidden" name="installer_id" value="<?= $inst['id'] ?>">
                                    <button type="submit" class="action-btn action-btn-featured" title="Toggle Featured">&#9733;</button>
                                </form>
                                <button type="button" class="action-btn action-btn-reviews" onclick="openReviewsModal(<?= $inst['id'] ?>, '<?= sanitize(addslashes($inst['business_name'])) ?>')" title="Manage Reviews">Reviews</button>
                                <form method="POST" style="display:inline" onsubmit="return confirm('DELETE this installer permanently? This cannot be undone.')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="installer_id" value="<?= $inst['id'] ?>">
                                    <button type="submit" class="action-btn action-btn-delete">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Reason Modal (Suspend/Reject) -->
<div class="modal-overlay" id="reasonModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="reasonModalTitle">Provide Reason</h3>
            <button class="modal-close" onclick="closeReasonModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST" id="reasonForm">
                <?= csrf_field() ?>
                <input type="hidden" name="action" id="reasonAction">
                <input type="hidden" name="installer_id" id="reasonInstallerId">
                <label style="font-size:0.875rem; font-weight:600; color:#1E293B;">Reason:</label>
                <textarea name="reason" class="reason-input" placeholder="Enter reason for this action..." required></textarea>
                <div style="margin-top:16px; text-align:right;">
                    <button type="button" onclick="closeReasonModal()" style="padding:8px 18px; background:#F1F5F9; border:none; border-radius:6px; font-size:0.875rem; cursor:pointer; margin-right:8px;">Cancel</button>
                    <button type="submit" id="reasonSubmitBtn" style="padding:8px 18px; background:#DC2626; color:white; border:none; border-radius:6px; font-size:0.875rem; font-weight:600; cursor:pointer;">Confirm</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reviews Modal -->
<div class="modal-overlay" id="reviewsModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="reviewsModalTitle">Reviews</h3>
            <button class="modal-close" onclick="closeReviewsModal()">&times;</button>
        </div>
        <div class="modal-body" id="reviewsModalBody">
            <p style="color:#64748B; text-align:center;">Loading reviews...</p>
        </div>
    </div>
</div>

<script>
// Reason Modal
function openReasonModal(installerId, action) {
    document.getElementById('reasonInstallerId').value = installerId;
    document.getElementById('reasonAction').value = action;
    document.getElementById('reasonModalTitle').textContent = action === 'suspend' ? 'Suspend Installer' : 'Reject Installer';
    document.getElementById('reasonSubmitBtn').textContent = action === 'suspend' ? 'Suspend' : 'Reject';
    document.getElementById('reasonSubmitBtn').style.background = action === 'suspend' ? '#F59E0B' : '#DC2626';
    document.getElementById('reasonModal').classList.add('active');
}
function closeReasonModal() {
    document.getElementById('reasonModal').classList.remove('active');
    document.getElementById('reasonForm').reset();
}

// Reviews Modal
function openReviewsModal(installerId, businessName) {
    document.getElementById('reviewsModalTitle').textContent = 'Reviews - ' + businessName;
    document.getElementById('reviewsModal').classList.add('active');

    // Fetch reviews via AJAX
    fetch('ajax/get_installer_reviews.php?installer_id=' + installerId)
        .then(r => r.json())
        .then(data => {
            const body = document.getElementById('reviewsModalBody');
            if (!data.reviews || data.reviews.length === 0) {
                body.innerHTML = '<p style="color:#94A3B8; text-align:center; padding:20px;">No reviews found for this installer.</p>';
                return;
            }
            let html = '';
            data.reviews.forEach(review => {
                const statusColors = {
                    'pending': 'background:#FEF3C7; color:#92400E;',
                    'approved': 'background:#DCFCE7; color:#166534;',
                    'rejected': 'background:#FEE2E2; color:#991B1B;'
                };
                const statusStyle = statusColors[review.status] || statusColors['pending'];
                let stars = '';
                for (let i = 0; i < 5; i++) stars += i < review.rating ? '&#9733;' : '&#9734;';

                html += `<div class="review-item">
                    <div class="review-item-header">
                        <div>
                            <span class="review-author">${review.reviewer_name}</span>
                            <span class="rating-stars" style="margin-left:8px;">${stars}</span>
                        </div>
                        <div>
                            <span class="review-status-badge" style="${statusStyle}">${review.status}</span>
                            <span class="review-date">${review.created_at}</span>
                        </div>
                    </div>
                    <div class="review-text">${review.comment}</div>
                    ${review.status === 'pending' ? `
                    <div class="review-actions">
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="csrf_token" value="${document.querySelector('[name=csrf_token]')?.value || ''}">
                            <input type="hidden" name="action" value="approve_review">
                            <input type="hidden" name="installer_id" value="${installerId}">
                            <input type="hidden" name="review_id" value="${review.id}">
                            <button type="submit" class="action-btn action-btn-approve">Approve</button>
                        </form>
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="csrf_token" value="${document.querySelector('[name=csrf_token]')?.value || ''}">
                            <input type="hidden" name="action" value="reject_review">
                            <input type="hidden" name="installer_id" value="${installerId}">
                            <input type="hidden" name="review_id" value="${review.id}">
                            <button type="submit" class="action-btn action-btn-reject">Reject</button>
                        </form>
                    </div>` : ''}
                </div>`;
            });
            body.innerHTML = html;
        })
        .catch(() => {
            document.getElementById('reviewsModalBody').innerHTML = '<p style="color:#DC2626; text-align:center;">Failed to load reviews. Make sure ajax/get_installer_reviews.php exists.</p>';
        });
}
function closeReviewsModal() {
    document.getElementById('reviewsModal').classList.remove('active');
}

// Close modals on overlay click
document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
        }
    });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
