<?php
/**
 * City & Weather Helper Functions
 * Provides city data, sun data, and seasonal calculations
 */

require_once __DIR__ . '/db.php';

function getAllCities() {
    $db = getDB();
    $stmt = $db->query("SELECT id, name, name as name_en, province, lat as latitude, lng as longitude, 0 as elevation_m FROM cities WHERE is_active = 1 ORDER BY province, name");
    return $stmt->fetchAll();
}

function getCitiesByProvince() {
    $cities = getAllCities();
    $grouped = [];
    foreach ($cities as $city) {
        $grouped[$city['province']][] = $city;
    }
    return $grouped;
}

function getCityById($cityId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM cities WHERE id = ? AND is_active = 1");
    $stmt->execute([$cityId]);
    return $stmt->fetch();
}

function getCityByName($name) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM cities WHERE name_en = ? AND is_active = 1");
    $stmt->execute([$name]);
    return $stmt->fetch();
}

function getSunDataForCity($cityId, $month = null) {
    try {
        $db = getDB();
        if ($month) {
            $stmt = $db->prepare("SELECT * FROM sun_data WHERE city_id = ? AND month = ?");
            $stmt->execute([$cityId, $month]);
            return $stmt->fetch();
        }
        $stmt = $db->prepare("SELECT * FROM sun_data WHERE city_id = ? ORDER BY month");
        $stmt->execute([$cityId]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        // sun_data table may not exist yet — return null gracefully
        return $month ? null : [];
    }
}

function getCurrentSeason() {
    $month = (int)date('n');
    if ($month >= 4 && $month <= 6) return 'summer';
    if ($month >= 7 && $month <= 9) return 'monsoon';
    if ($month >= 10 && $month <= 11) return 'spring';
    return 'winter'; // Dec, Jan, Feb, Mar
}

function getSeasonFromMonth($month) {
    if ($month >= 4 && $month <= 6) return 'summer';
    if ($month >= 7 && $month <= 9) return 'monsoon';
    if ($month >= 10 && $month <= 11) return 'spring';
    return 'winter';
}

function getSeasonalAppliances($season) {
    try {
        $db = getDB();
        $stmt = $db->prepare("
            SELECT a.*, sam.usage_probability, sam.priority_rank, sam.recommended_hours, sam.notes as season_notes
            FROM appliances a
            JOIN seasonal_appliance_mapping sam ON a.id = sam.appliance_id
            WHERE sam.season IN (?, 'all_year') AND a.is_active = 1
            ORDER BY sam.priority_rank ASC, sam.usage_probability DESC
        ");
        $stmt->execute([$season]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        // seasonal_appliance_mapping table may not exist yet
        return [];
    }
}

function getRecommendedAppliances($cityId) {
    $season = getCurrentSeason();
    $sunData = getSunDataForCity($cityId, (int)date('n'));

    $appliances = getSeasonalAppliances($season);

    // Enhance with weather context
    foreach ($appliances as &$app) {
        $app['current_season'] = $season;
        $app['season_appropriate'] = true;

        // Adjust hours based on actual temperature
        if ($sunData) {
            $temp = $sunData['avg_temperature_c'];
            if (strpos($app['season_tags'], 'summer') !== false && $temp < 20) {
                $app['season_appropriate'] = false;
            }
            if ($app['name_en'] === 'Electric Geyser' && $temp > 30) {
                $app['season_appropriate'] = false;
            }
        }
    }

    return $appliances;
}

function calculateDailyGeneration($cityId, $panelWattPeak, $numPanels, $month = null) {
    if (!$month) $month = (int)date('n');

    $sunData = getSunDataForCity($cityId, $month);
    if (!$sunData) return null;

    $totalPanelWatts = $panelWattPeak * $numPanels;
    $psh = $sunData['peak_sun_hours'];
    $efficiencyFactor = $sunData['panel_efficiency_factor'];

    // Gross generation (kWh)
    $grossGen = ($totalPanelWatts / 1000) * $psh;

    // Apply weather efficiency factor
    $weatherAdjusted = $grossGen * $efficiencyFactor;

    // System losses (wiring, inverter, dust) = ~20%
    $systemLoss = 0.20;
    $netGen = $weatherAdjusted * (1 - $systemLoss);

    return [
        'gross_kwh' => round($grossGen, 2),
        'weather_adjusted_kwh' => round($weatherAdjusted, 2),
        'net_kwh' => round($netGen, 2),
        'peak_sun_hours' => $psh,
        'efficiency_factor' => $efficiencyFactor,
        'temperature_c' => $sunData['avg_temperature_c'],
        'cloud_cover' => $sunData['avg_cloud_cover_percent']
    ];
}

function getMonthlyGenerationForecast($cityId, $panelWattPeak, $numPanels) {
    $forecast = [];
    for ($month = 1; $month <= 12; $month++) {
        $daily = calculateDailyGeneration($cityId, $panelWattPeak, $numPanels, $month);
        if ($daily) {
            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, (int)date('Y'));
            $forecast[$month] = [
                'month' => $month,
                'month_name' => date('F', mktime(0, 0, 0, $month, 1)),
                'daily_kwh' => $daily['net_kwh'],
                'monthly_kwh' => round($daily['net_kwh'] * $daysInMonth, 2),
                'peak_sun_hours' => $daily['peak_sun_hours'],
                'efficiency' => $daily['efficiency_factor'],
                'avg_temp' => $daily['temperature_c']
            ];
        }
    }
    return $forecast;
}

function getWeatherCache($cityId, $date = null) {
    try {
        $db = getDB();
        if ($date) {
            $stmt = $db->prepare("SELECT * FROM weather_cache WHERE city_id = ? AND forecast_date = ? AND (expires_at IS NULL OR expires_at > NOW())");
            $stmt->execute([$cityId, $date]);
            return $stmt->fetch();
        }
        $stmt = $db->prepare("SELECT * FROM weather_cache WHERE city_id = ? AND forecast_date >= CURDATE() AND (expires_at IS NULL OR expires_at > NOW()) ORDER BY forecast_date LIMIT 30");
        $stmt->execute([$cityId]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        // weather_cache table may not exist yet
        return $date ? null : [];
    }
}

function getSetting($key, $default = null) {
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        return $result ? $result['setting_value'] : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

function getElectricityRate() {
    return (float)getSetting('electricity_rate_usd', 45);
}

function getNetMeteringRate() {
    return (float)getSetting('net_metering_rate_usd', 20);
}
