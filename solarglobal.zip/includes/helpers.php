<?php
/**
 * Helper Functions
 * Utility functions used throughout the application
 */

// Load environment config if available
$_env_file = dirname(__DIR__) . '/config.env';
if (file_exists($_env_file)) {
    foreach (file($_env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $_line) {
        if (str_starts_with(trim($_line), '#') || !str_contains($_line, '=')) continue;
        [$_key, $_val] = explode('=', $_line, 2);
        $_key = trim($_key); $_val = trim($_val);
        if (!getenv($_key)) putenv("$_key=$_val");
    }
    unset($_env_file, $_line, $_key, $_val);
}

// Define base URL — from env or default to /solarglobal/ (local dev)
define('BASE_URL', getenv('BASE_URL') ?: '/solarglobal/');

/**
 * Get full URL for an image path
 * @param string $path - Path from database (e.g., "uploads/inverters/image.jpg")
 * @return string - Full URL path
 */
function get_image_url($path) {
    if (empty($path)) {
        return '';
    }
    
    // Remove any ../ prefix
    $path = str_replace('../', '', $path);
    
    // If path already starts with BASE_URL, return as-is
    if (strpos($path, BASE_URL) === 0) {
        return $path;
    }
    
    // If path starts with /, remove it
    $path = ltrim($path, '/');
    
    // Return full URL
    return BASE_URL . $path;
}

/**
 * Sanitize user input
 * @param string $input
 * @return string
 */
function sanitize($input) {
    return htmlspecialchars(trim($input ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Format price (currency-agnostic, just formats the number)
 * @param float $amount
 * @return string
 */
function format_price($amount) {
    return number_format($amount, 0, '.', ',');
}

/**
 * Legacy alias — kept for backward compatibility
 * @deprecated Use format_price() instead
 */
function format_usd($amount) {
    return number_format($amount, 0, '.', ',');
}

/**
 * Send JSON response and exit
 * @param mixed $data
 * @param int $status
 */
function respond_json($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

/**
 * Redirect to URL
 * @param string $url
 */
function redirect($url) {
    header('Location: ' . $url);
    exit();
}

/**
 * Validate file upload
 * @param array $file $_FILES array element
 * @param array $allowed_types Allowed MIME types
 * @param int $max_size Maximum file size in bytes
 * @return array ['success' => bool, 'message' => string, 'path' => string]
 */
function validate_upload($file, $allowed_types = ['image/jpeg', 'image/png', 'image/webp'], $max_size = 2097152) {
    // Check if file was uploaded
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return ['success' => false, 'message' => 'No file uploaded'];
    }
    
    // Check file size
    if ($file['size'] > $max_size) {
        return ['success' => false, 'message' => 'File too large. Maximum size: ' . ($max_size / 1048576) . 'MB'];
    }
    
    // Validate MIME type using finfo
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mime_type, $allowed_types)) {
        return ['success' => false, 'message' => 'Invalid file type. Allowed: JPG, PNG, WEBP'];
    }
    
    return ['success' => true, 'mime' => $mime_type];
}

/**
 * Generate unique filename
 * @param string $extension
 * @return string
 */
function generate_filename($extension) {
    return uniqid('', true) . '_' . time() . '.' . $extension;
}

/**
 * Get file extension from MIME type
 * @param string $mime
 * @return string
 */
function get_extension_from_mime($mime) {
    $map = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif'
    ];

    return $map[$mime] ?? 'jpg';
}

/**
 * Set security headers
 */
function set_security_headers() {
    header("X-Content-Type-Options: nosniff");
    header("X-Frame-Options: SAMEORIGIN");
    // Updated CSP for cPanel compatibility - allow inline scripts/styles and self connections
    // Note: 'unsafe-inline' is required for onclick handlers in dialog buttons
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdnjs.cloudflare.com https://fonts.googleapis.com https://maps.googleapis.com https://www.googletagmanager.com https://accounts.google.com https://apis.google.com https://www.google.com https://www.gstatic.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://accounts.google.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob: https: http:; connect-src 'self' https://api.open-meteo.com https://maps.googleapis.com https://www.google-analytics.com https://accounts.google.com https://oauth2.googleapis.com https://www.google.com; frame-src https://accounts.google.com https://www.google.com;");
}

/**
 * Handle image upload with validation
 * @param array $file $_FILES element
 * @param string $upload_dir Target directory
 * @return array ['success' => bool, 'path' => string, 'error' => string]
 */
function handle_image_upload($file, $upload_dir, $allowed_types = null, $max_size = 2097152) {
    // Validate upload
    $validation = $allowed_types
        ? validate_upload($file, $allowed_types, $max_size)
        : validate_upload($file, ['image/jpeg', 'image/png', 'image/webp'], $max_size);
    if (!$validation['success']) {
        return ['success' => false, 'error' => $validation['message']];
    }
    
    // Create directory if not exists
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    // Generate filename
    $ext = get_extension_from_mime($validation['mime']);
    $filename = generate_filename($ext);
    $filepath = $upload_dir . $filename;
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        // Remove ../ prefix for frontend compatibility
        $clean_path = str_replace('../', '', $filepath);
        return ['success' => true, 'path' => $clean_path];
    } else {
        return ['success' => false, 'error' => 'Failed to save file'];
    }
}

/**
 * Get current full URL
 * @return string
 */
function getCurrentUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $uri = $_SERVER['REQUEST_URI'];
    return $protocol . '://' . $host . $uri;
}

/**
 * Get base URL of the application
 * @return string
 */
function getBaseUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'];
    $path = dirname($script);
    
    // Remove trailing slash if present
    $path = rtrim($path, '/');
    
    return $protocol . '://' . $host . $path;
}

/**
 * Track visitor statistics with device/browser detection
 * @param PDO $pdo Database connection
 */
function trackVisitor($pdo) {
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $page = $_SERVER['REQUEST_URI'] ?? '/';
        $referer = $_SERVER['HTTP_REFERER'] ?? '';

        // Detect device type
        $device = 'desktop';
        $ua_lower = strtolower($user_agent);
        $is_bot = false;
        if (preg_match('/bot|crawl|spider|slurp|google|bing|yahoo|baidu|yandex|semrush|ahrefs|mj12|dotbot|petalbot|bytespider|gptbot|claudebot|facebookexternalhit/i', $ua_lower)) {
            $device = 'bot';
            $is_bot = true;
        } elseif (preg_match('/mobile|android.*mobile|iphone|ipod|blackberry|opera mini|iemobile/i', $ua_lower)) {
            $device = 'mobile';
        } elseif (preg_match('/tablet|ipad|android(?!.*mobile)/i', $ua_lower)) {
            $device = 'tablet';
        }

        // Detect browser
        $browser = 'Other';
        if (strpos($ua_lower, 'edg/') !== false) $browser = 'Edge';
        elseif (strpos($ua_lower, 'opr/') !== false || strpos($ua_lower, 'opera') !== false) $browser = 'Opera';
        elseif (strpos($ua_lower, 'chrome') !== false) $browser = 'Chrome';
        elseif (strpos($ua_lower, 'firefox') !== false) $browser = 'Firefox';
        elseif (strpos($ua_lower, 'safari') !== false) $browser = 'Safari';
        elseif (strpos($ua_lower, 'msie') !== false || strpos($ua_lower, 'trident') !== false) $browser = 'IE';

        // Detect OS
        $os = 'Other';
        if (strpos($ua_lower, 'windows') !== false) $os = 'Windows';
        elseif (strpos($ua_lower, 'macintosh') !== false || strpos($ua_lower, 'mac os') !== false) $os = 'macOS';
        elseif (strpos($ua_lower, 'linux') !== false) $os = 'Linux';
        elseif (strpos($ua_lower, 'android') !== false) $os = 'Android';
        elseif (strpos($ua_lower, 'iphone') !== false || strpos($ua_lower, 'ipad') !== false) $os = 'iOS';

        // Session tracking
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $session_id = session_id();

        $stmt = $pdo->prepare("
            INSERT INTO visitor_stats (ip_address, user_agent, page_url, referer, device_type, browser, os, session_id, is_bot, visit_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$ip, $user_agent, $page, $referer, $device, $browser, $os, $session_id, $is_bot ? 1 : 0]);
    } catch (Exception $e) {
        // Silently fail - don't break the page
        error_log("Visitor tracking error: " . $e->getMessage());
    }
}

/**
 * Get active ads for a given position
 * @param PDO $pdo
 * @param string $position
 * @return array
 */
function getActiveAds($pdo, $position = 'sidebar') {
    try {
        $user_cc = '';
        if (function_exists('get_user_country_code')) {
            $user_cc = strtoupper(get_user_country_code());
        }

        if (!empty($user_cc)) {
            // Fetch country-targeted + universal, prefer country-specific
            $stmt = $pdo->prepare("
                SELECT * FROM custom_ads
                WHERE is_active = 1 AND position = ?
                AND (country_code = ? OR country_code IS NULL OR country_code = '')
                AND (start_date IS NULL OR start_date <= CURDATE())
                AND (end_date IS NULL OR end_date >= CURDATE())
                ORDER BY CASE WHEN country_code = ? THEN 0 ELSE 1 END, priority DESC
            ");
            $stmt->execute([$position, $user_cc, $user_cc]);
        } else {
            $stmt = $pdo->prepare("
                SELECT * FROM custom_ads
                WHERE is_active = 1 AND position = ?
                AND (country_code IS NULL OR country_code = '')
                AND (start_date IS NULL OR start_date <= CURDATE())
                AND (end_date IS NULL OR end_date >= CURDATE())
                ORDER BY priority DESC
            ");
            $stmt->execute([$position]);
        }

        $all = $stmt->fetchAll();
        // If country-specific exist, use those; else universal
        $country = array_filter($all, fn($a) => !empty($a['country_code']) && strtoupper($a['country_code']) === $user_cc);
        $universal = array_filter($all, fn($a) => empty($a['country_code']));
        return !empty($country) ? array_values($country) : array_values($universal);
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Track ad impression
 */
function trackAdImpression($pdo, $adId) {
    try {
        $pdo->prepare("UPDATE custom_ads SET impressions = impressions + 1 WHERE id = ?")->execute([$adId]);
    } catch (Exception $e) {}
}

/**
 * Track ad click (called via AJAX)
 */
function trackAdClick($pdo, $adId) {
    try {
        $pdo->prepare("UPDATE custom_ads SET clicks = clicks + 1 WHERE id = ?")->execute([$adId]);
    } catch (Exception $e) {}
}

/**
 * Rate limit requests using session-based counters
 * @param string $key Identifier for the rate limit bucket (e.g., 'api_products', 'page_view')
 * @param int $max Maximum requests allowed in window
 * @param int $window Time window in seconds
 * @return bool True if request is allowed, false if rate limited
 */
function rate_limit($key, $max = 30, $window = 60) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $now = time();
    $bucket_key = 'rate_limit_' . $key;

    if (!isset($_SESSION[$bucket_key])) {
        $_SESSION[$bucket_key] = ['count' => 0, 'window_start' => $now];
    }

    $bucket = &$_SESSION[$bucket_key];

    // Reset window if expired
    if ($now - $bucket['window_start'] >= $window) {
        $bucket['count'] = 0;
        $bucket['window_start'] = $now;
    }

    $bucket['count']++;

    if ($bucket['count'] > $max) {
        return false; // Rate limited
    }

    return true; // Allowed
}

/**
 * Send a 429 Too Many Requests response and exit
 * @param string $message Optional custom message
 */
function respond_rate_limited($message = 'Too many requests. Please try again later.') {
    http_response_code(429);
    header('Retry-After: 60');
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => $message]);
    exit();
}

/**
 * Detect user's country from various sources
 * Priority: Cloudflare header > session cache > GeoIP > default
 * @return string ISO 2-letter country code (uppercase), e.g., 'US', 'PK'
 */
function detect_user_country() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Check session cache first
    if (!empty($_SESSION['user_country'])) {
        return $_SESSION['user_country'];
    }

    $country = '';

    // 1. Cloudflare header (most reliable in production)
    if (!empty($_SERVER['HTTP_CF_IPCOUNTRY'])) {
        $country = strtoupper(trim($_SERVER['HTTP_CF_IPCOUNTRY']));
    }

    // 2. Check X-Country header (some CDNs/proxies set this)
    if (empty($country) && !empty($_SERVER['HTTP_X_COUNTRY'])) {
        $country = strtoupper(trim($_SERVER['HTTP_X_COUNTRY']));
    }

    // 3. PHP GeoIP extension (if available)
    if (empty($country) && function_exists('geoip_country_code_by_name')) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        if ($ip !== '127.0.0.1' && $ip !== '::1') {
            $code = @geoip_country_code_by_name($ip);
            if ($code) {
                $country = strtoupper($code);
            }
        }
    }

    // 4. Free IP geolocation API fallback (ip-api.com — no key needed)
    if (empty($country)) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        if ($ip !== '127.0.0.1' && $ip !== '::1' && $ip !== '0.0.0.0') {
            try {
                $ctx = stream_context_create(['http' => ['timeout' => 2, 'header' => "User-Agent: SolarGlobal/1.0\r\n"]]);
                $response = @file_get_contents("http://ip-api.com/json/{$ip}?fields=countryCode", false, $ctx);
                if ($response) {
                    $data = json_decode($response, true);
                    if (!empty($data['countryCode'])) {
                        $country = strtoupper($data['countryCode']);
                    }
                }
            } catch (Exception $e) {
                // Silently fail — not critical
            }
        }
    }

    // 5. Default — leave empty (will show global content)
    // On localhost, we don't force a country
    if ($country === 'XX' || $country === 'T1') {
        $country = ''; // Cloudflare returns XX for unknown
    }

    // Validate: must be exactly 2 uppercase letters
    if (!empty($country) && preg_match('/^[A-Z]{2}$/', $country)) {
        $_SESSION['user_country'] = $country;
    } else {
        $country = '';
    }

    return $country;
}

/**
 * Get user's country code with consistent fallback chain.
 * Priority: 1. sg_location cookie  2. IP detection  3. 'US' fallback
 *
 * @return string ISO 2-letter country code
 */
function get_user_country_code(): string {
    $loc = json_decode($_COOKIE['sg_location'] ?? '{}', true);
    if (!empty($loc['country_code']) && preg_match('/^[A-Z]{2}$/', $loc['country_code'])) {
        return $loc['country_code'];
    }
    $cc = detect_user_country();
    if (!empty($cc)) return $cc;
    return 'US';
}

/**
 * Check if the current request is from a known bot
 * @return bool
 */
function is_bot_request() {
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    if (empty($ua)) return true;

    return (bool)preg_match('/bot|crawl|spider|slurp|google|bing|yahoo|baidu|yandex|semrush|ahrefs|mj12|dotbot|petalbot|bytespider|gptbot|claudebot|facebookexternalhit/i', $ua);
}

/**
 * Get visitor count
 * @param PDO $pdo Database connection
 * @param string $period 'today', 'week', 'month', 'all'
 * @return int
 */
function getVisitorCount($pdo, $period = 'all', $exclude_bots = true) {
    try {
        $conditions = [];
        if ($exclude_bots) {
            $conditions[] = "(is_bot = 0 OR is_bot IS NULL)";
        }
        switch ($period) {
            case 'today':
                $conditions[] = "DATE(visit_date) = CURDATE()";
                break;
            case 'week':
                $conditions[] = "visit_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
                break;
            case 'month':
                $conditions[] = "visit_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
                break;
        }
        $where = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

        $stmt = $pdo->query("SELECT COUNT(DISTINCT ip_address) as count FROM visitor_stats $where");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    } catch (Exception $e) {
        return 0;
    }
}

/**
 * Get a system setting value from the system_settings table
 * @param string $key Setting key
 * @param string $default Default value if not found
 * @return string Setting value
 */
if (!function_exists('get_system_setting')) {
function get_system_setting(string $key, string $default = ''): string {
    static $cache = [];
    if (isset($cache[$key])) return $cache[$key];

    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $cache[$key] = $row ? ($row['setting_value'] ?? $default) : $default;
    } catch (Exception $e) {
        $cache[$key] = $default;
    }
    return $cache[$key];
}
} // end function_exists('get_system_setting')

// ─── Currency & Country Helpers ─────────────────────────────────────────────

if (!function_exists('get_country_currency_info')) {
/**
 * Get currency info for a country code
 * @param string $country_code  2 or 3 letter country code
 * @return array ['currency_code'=>'PKR', 'currency_symbol'=>'Rs', 'exchange_rate'=>280.5, 'name'=>'Pakistan']
 */
function get_country_currency_info(string $country_code): array {
    static $cache = [];
    if (isset($cache[$country_code])) return $cache[$country_code];

    $default = ['currency_code' => 'USD', 'currency_symbol' => '$', 'exchange_rate' => 1.0, 'name' => 'Unknown', 'flag_emoji' => '', 'flag_icon' => '', 'code' => ''];
    if (empty($country_code)) return $default;

    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT name, currency_code, currency_symbol, exchange_rate_to_usd, flag_emoji, flag_icon, code FROM countries WHERE code = ? LIMIT 1");
        $stmt->execute([$country_code]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $cache[$country_code] = [
                'currency_code' => $row['currency_code'] ?: 'USD',
                'currency_symbol' => $row['currency_symbol'] ?: '$',
                'exchange_rate' => floatval($row['exchange_rate_to_usd']) ?: 1.0,
                'name' => $row['name'] ?: 'Unknown',
                'flag_emoji' => $row['flag_emoji'] ?: '',
                'flag_icon' => $row['flag_icon'] ?? '',
                'code' => $row['code'] ?? '',
            ];
            return $cache[$country_code];
        }
    } catch (Exception $e) {}

    return $default;
}
}

if (!function_exists('convert_usd_to_local')) {
/**
 * Convert USD amount to local currency
 * @param float $usd_amount
 * @param string $country_code
 * @return float
 */
function convert_usd_to_local(float $usd_amount, string $country_code): float {
    $info = get_country_currency_info($country_code);
    return round($usd_amount * $info['exchange_rate'], 2);
}
}

if (!function_exists('format_local_price')) {
/**
 * Format price in local currency with symbol
 * @param float $usd_amount  Amount in USD
 * @param string $country_code
 * @param bool $show_code  Also show currency code (e.g. "Rs 45,000 PKR")
 * @return string
 */
function format_local_price(float $usd_amount, string $country_code, bool $show_code = false): string {
    $info = get_country_currency_info($country_code);
    $local = round($usd_amount * $info['exchange_rate'], 2);
    $formatted = $info['currency_symbol'] . ' ' . number_format($local, 2);
    if ($show_code && $info['currency_code'] !== 'USD') {
        $formatted .= ' ' . $info['currency_code'];
    }
    return $formatted;
}
}

if (!function_exists('convert_local_to_usd')) {
/**
 * Convert local currency amount back to USD for storage
 * @param float $local_amount
 * @param string $country_code
 * @return float
 */
function convert_local_to_usd(float $local_amount, string $country_code): float {
    $info = get_country_currency_info($country_code);
    if ($info['exchange_rate'] <= 0) return $local_amount;
    return round($local_amount / $info['exchange_rate'], 2);
}
}

/**
 * Verify Google reCAPTCHA v3 token
 * @param string $token The reCAPTCHA response token from frontend
 * @param float $minScore Minimum score threshold (0.0 = bot, 1.0 = human). Default 0.5
 * @param string $expectedAction Expected action name for verification
 * @return array ['success' => bool, 'score' => float, 'error' => string]
 */
function verify_recaptcha($token, $minScore = 0.5, $expectedAction = '') {
    // Get secret key from system settings
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'recaptcha_secret_key' LIMIT 1");
        $stmt->execute();
        $secret = $stmt->fetchColumn();
    } catch (Exception $e) {
        error_log("reCAPTCHA: Failed to get secret key: " . $e->getMessage());
        return ['success' => true, 'score' => 1.0, 'error' => '']; // Fail open if no key configured
    }

    if (empty($secret)) {
        // reCAPTCHA not configured — allow through (fail open)
        return ['success' => true, 'score' => 1.0, 'error' => 'not_configured'];
    }

    if (empty($token)) {
        return ['success' => false, 'score' => 0.0, 'error' => 'missing_token'];
    }

    $url = 'https://www.google.com/recaptcha/api/siteverify';
    $data = [
        'secret' => $secret,
        'response' => $token,
        'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
    ];

    $options = [
        'http' => [
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
            'timeout' => 5
        ]
    ];

    $context = stream_context_create($options);
    $response = @file_get_contents($url, false, $context);

    if ($response === false) {
        error_log("reCAPTCHA: API request failed");
        return ['success' => true, 'score' => 1.0, 'error' => 'api_error']; // Fail open
    }

    $result = json_decode($response, true);
    if (!$result) {
        return ['success' => true, 'score' => 1.0, 'error' => 'parse_error'];
    }

    $score = floatval($result['score'] ?? 0);
    $success = !empty($result['success']) && $score >= $minScore;

    // Verify action if specified
    if ($success && !empty($expectedAction) && ($result['action'] ?? '') !== $expectedAction) {
        $success = false;
    }

    return [
        'success' => $success,
        'score' => $score,
        'error' => $success ? '' : ('score_' . $score)
    ];
}

/**
 * Get reCAPTCHA site key for frontend rendering
 * @return string Site key or empty string if not configured
 */
function get_recaptcha_site_key() {
    static $key = null;
    if ($key !== null) return $key;

    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'recaptcha_site_key' LIMIT 1");
        $stmt->execute();
        $key = $stmt->fetchColumn() ?: '';
    } catch (Exception $e) {
        $key = '';
    }
    return $key;
}

/**
 * Render reCAPTCHA v3 script tag (include once per page)
 * @return string HTML script tag or empty string
 */
function render_recaptcha_script() {
    $siteKey = get_recaptcha_site_key();
    if (empty($siteKey)) return '';
    return '<script src="https://www.google.com/recaptcha/api.js?render=' . htmlspecialchars($siteKey) . '"></script>';
}

/**
 * Validate honeypot field — returns true if the submission is human (field empty)
 * @param string $fieldName Name of the honeypot field
 * @return bool True if human (field is empty), false if bot (field is filled)
 */
function validate_honeypot($fieldName = 'website_url') {
    $value = $_POST[$fieldName] ?? $_GET[$fieldName] ?? '';
    return empty($value);
}

/**
 * Render a honeypot input field (hidden from humans via CSS)
 * @param string $fieldName
 * @return string HTML
 */
function render_honeypot_field($fieldName = 'website_url') {
    return '<div style="position:absolute;left:-9999px;top:-9999px;" aria-hidden="true">'
         . '<input type="text" name="' . htmlspecialchars($fieldName) . '" tabindex="-1" autocomplete="off" value="">'
         . '</div>';
}

/**
 * Get country flag HTML — uploaded icon preferred, emoji fallback, then country code
 *
 * @param array|string $country  Country row array (with flag_icon, flag_emoji, code) OR a country_code string
 * @param int          $size     Icon size in pixels (default 24)
 * @return string                HTML for the flag
 */
function get_country_flag($country, int $size = 24): string {
    // If string passed, look up the country
    if (is_string($country)) {
        static $flag_cache = [];
        $cc = strtoupper($country);
        if (!isset($flag_cache[$cc])) {
            try {
                $db = getDB();
                $stmt = $db->prepare("SELECT flag_icon, flag_emoji, code FROM countries WHERE code = ? LIMIT 1");
                $stmt->execute([$cc]);
                $flag_cache[$cc] = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['flag_icon' => null, 'flag_emoji' => null, 'code' => $cc];
            } catch (Exception $e) {
                $flag_cache[$cc] = ['flag_icon' => null, 'flag_emoji' => null, 'code' => $cc];
            }
        }
        $country = $flag_cache[$cc];
    }

    // 1. Uploaded icon image (preferred)
    $icon = $country['flag_icon'] ?? '';
    if (!empty($icon)) {
        $url = BASE_URL . htmlspecialchars($icon);
        return '<img src="' . $url . '" alt="' . htmlspecialchars($country['code'] ?? '') . ' flag" '
             . 'width="' . $size . '" height="' . (int)round($size * 0.67) . '" '
             . 'style="object-fit:contain;vertical-align:middle;border-radius:2px;" loading="lazy">';
    }

    // 2. Emoji flag fallback
    $emoji = $country['flag_emoji'] ?? '';
    if (!empty($emoji)) {
        return '<span style="font-size:' . $size . 'px;line-height:1;vertical-align:middle;" title="' . htmlspecialchars($country['code'] ?? '') . '">' . $emoji . '</span>';
    }

    // 3. Country code badge fallback
    $code = htmlspecialchars($country['code'] ?? '??');
    return '<span style="display:inline-flex;align-items:center;justify-content:center;width:' . $size . 'px;height:' . (int)round($size * 0.67) . 'px;'
         . 'background:#E2E8F0;color:#475569;font-size:' . max(9, (int)round($size * 0.4)) . 'px;font-weight:700;border-radius:3px;vertical-align:middle;">'
         . $code . '</span>';
}
