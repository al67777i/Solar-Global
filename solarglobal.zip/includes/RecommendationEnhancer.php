<?php
/**
 * RecommendationEnhancer - Adds weather/city intelligence to recommendations
 *
 * Integrates SolarEngine data with the recommendation algorithm to provide:
 * - City-specific peak sun hours (not user-guessed)
 * - Actual temperature derating from historical data
 * - Seasonal load adjustments
 * - Weather-risk factors (monsoon, dust storms)
 * - Performance predictions with confidence intervals
 * - Smart system sizing recommendations
 */

require_once __DIR__ . '/SolarEngine.php';
require_once __DIR__ . '/WeatherService.php';

class RecommendationEnhancer {

    private SolarEngine $solar;
    private ?WeatherService $weather;
    private ?int $cityId;
    private ?array $cityData;
    private ?array $sunData;

    public function __construct(?int $cityId = null) {
        $this->solar = new SolarEngine();
        $this->cityId = $cityId;
        $this->cityData = null;
        $this->sunData = null;

        try {
            $this->weather = new WeatherService();
        } catch (Exception $e) {
            $this->weather = null;
        }

        if ($cityId) {
            $result = getCityById($cityId);
            $this->cityData = $result ?: null;
            $sunResult = getSunDataForCity($cityId);
            $this->sunData = $sunResult ?: null;
        }
    }

    /**
     * Get enhanced input parameters for recommend_v7 based on city data
     * Replaces user-guessed values with actual calculated ones
     */
    public function getEnhancedParams(): array {
        if (!$this->cityId || !$this->cityData) {
            return $this->getDefaultParams();
        }

        $month = (int)date('n');
        $monthSunData = getSunDataForCity($this->cityId, $month);

        // Calculate real PSH for this city/month using SolarEngine
        $lat = (float)$this->cityData['latitude'];
        $tiltData = $this->solar->getOptimalTilt($lat, $month);
        $tiltAngle = $tiltData['tilt'];

        $dayOfYear = (int)date('z') + 1;
        $horizontalIrr = $monthSunData ? (float)$monthSunData['avg_irradiance_kwh_m2'] : 5.0;
        $psh = $monthSunData ? (float)$monthSunData['peak_sun_hours'] : 5.0;

        // Get tilted PSH
        $tiltedIrr = $this->solar->getIrradianceOnTilt($horizontalIrr, $tiltAngle, $lat, $dayOfYear);
        $effectivePSH = $psh * ($tiltedIrr / max(0.1, $horizontalIrr));

        // Real ambient temperature
        $ambientTemp = $monthSunData ? (int)$monthSunData['avg_temperature_c'] : 35;

        // Try to get live weather for more accuracy
        if ($this->weather) {
            try {
                $summary = $this->weather->getWeatherSummary($this->cityId);
                if ($summary && isset($summary['avg_temperature'])) {
                    $ambientTemp = (int)$summary['avg_temperature'];
                }
            } catch (Exception $e) {
                // Fall back to sun_data
            }
        }

        return [
            'peak_sun_hours' => round(min(8.0, max(3.0, $effectivePSH)), 1),
            'ambient_temp_c' => max(15, min(55, $ambientTemp)),
            'city_id' => $this->cityId,
            'city_name' => $this->cityData['name_en'],
            'latitude' => $lat,
            'longitude' => (float)$this->cityData['longitude'],
            'optimal_tilt' => $tiltAngle,
            'season' => getCurrentSeason(),
            'source' => 'city_solar_data'
        ];
    }

    /**
     * Get weather-adjusted generation prediction for a system configuration
     */
    public function predictGeneration(int $panelWatts, int $numPanels, float $pshUsed): array {
        if (!$this->cityId) {
            return ['success' => false, 'error' => 'No city selected'];
        }

        // Get annual yield from SolarEngine
        $annualYield = $this->solar->getAnnualYield($this->cityId, $panelWatts, $numPanels);
        if (!$annualYield['success']) {
            return ['success' => false, 'error' => 'Could not calculate yield'];
        }

        // Weather risk assessment
        $weatherRisk = $this->getWeatherRiskFactors();

        // Monthly generation with confidence intervals
        $monthly = [];
        foreach ($annualYield['monthly'] as $m) {
            $riskFactor = $weatherRisk['monthly_risk'][$m['month']] ?? 1.0;
            $monthly[] = [
                'month' => $m['month'],
                'month_name' => $m['month_name'],
                'expected_kwh' => $m['monthly_kwh'],
                'pessimistic_kwh' => round($m['monthly_kwh'] * $riskFactor * 0.85, 1),
                'optimistic_kwh' => round($m['monthly_kwh'] * 1.05, 1),
                'confidence' => round((1 - abs(1 - $riskFactor)) * 100, 0)
            ];
        }

        return [
            'success' => true,
            'city' => $this->cityData['name_en'],
            'system_kwp' => $annualYield['system_kwp'],
            'annual_expected_kwh' => $annualYield['annual_kwh'],
            'annual_pessimistic_kwh' => round($annualYield['annual_kwh'] * 0.85, 0),
            'annual_optimistic_kwh' => round($annualYield['annual_kwh'] * 1.05, 0),
            'specific_yield' => $annualYield['specific_yield_kwh_kwp'],
            'capacity_factor_pct' => $annualYield['capacity_factor_pct'],
            'weather_risk' => $weatherRisk,
            'monthly' => $monthly
        ];
    }

    /**
     * Assess weather risk factors for the city
     */
    public function getWeatherRiskFactors(): array {
        $risks = [];
        $monthlyRisk = [];

        if (!$this->sunData) {
            return ['overall_risk' => 'unknown', 'factors' => [], 'monthly_risk' => array_fill(1, 12, 1.0)];
        }

        // Analyze each month for risk factors
        $totalRisk = 0;
        foreach ($this->sunData as $sd) {
            $month = (int)$sd['month'];
            $cloud = (float)$sd['avg_cloud_cover_percent'];
            $temp = (float)$sd['avg_temperature_c'];
            $risk = 1.0;

            // Monsoon risk (Jul-Sep in the region)
            if ($month >= 7 && $month <= 9) {
                $risk *= 0.90; // 10% reduction due to heavy cloud/rain
                if ($cloud > 50) {
                    $risks['monsoon_impact'] = 'High cloud cover during monsoon reduces output by 10-20%';
                }
            }

            // Extreme heat penalty (>40°C)
            if ($temp > 40) {
                $risk *= 0.95;
                $risks['extreme_heat'] = 'Very high temperatures (>40°C) cause additional panel degradation';
            }

            // Dust storm season (May-June in Punjab/Sindh)
            if ($month >= 5 && $month <= 6 && (float)($this->cityData['latitude'] ?? 30) < 33) {
                $risk *= 0.95;
                $risks['dust_storms'] = 'May-June dust storms require frequent panel cleaning';
            }

            // Winter fog (Dec-Jan in Punjab)
            if ($month >= 12 || $month <= 1) {
                $province = $this->cityData['province'] ?? '';
                if (in_array($province, ['Punjab', 'Sindh'])) {
                    $risk *= 0.93;
                    $risks['winter_fog'] = 'December-January fog significantly reduces morning generation';
                }
            }

            $monthlyRisk[$month] = round($risk, 3);
            $totalRisk += $risk;
        }

        $avgRisk = $totalRisk / 12;
        $overallRisk = $avgRisk >= 0.95 ? 'low' : ($avgRisk >= 0.90 ? 'moderate' : 'high');

        return [
            'overall_risk' => $overallRisk,
            'avg_factor' => round($avgRisk, 3),
            'factors' => $risks,
            'monthly_risk' => $monthlyRisk
        ];
    }

    /**
     * Get seasonal load multiplier
     * In summer, cooling loads increase; in winter, heating loads increase
     */
    public function getSeasonalLoadMultiplier(): array {
        $season = getCurrentSeason();
        $month = (int)date('n');
        $temp = 30;

        if ($this->sunData) {
            foreach ($this->sunData as $sd) {
                if ((int)$sd['month'] === $month) {
                    $temp = (float)$sd['avg_temperature_c'];
                    break;
                }
            }
        }

        // Load multiplier based on temperature
        // Above 35°C: AC/cooling adds significant load
        // Below 15°C: Heating adds load
        $multiplier = 1.0;
        $reason = 'Normal seasonal load';

        if ($temp > 40) {
            $multiplier = 1.35;
            $reason = 'Extreme heat: heavy AC/cooling usage expected (+35%)';
        } elseif ($temp > 35) {
            $multiplier = 1.25;
            $reason = 'High heat: significant cooling load expected (+25%)';
        } elseif ($temp > 30) {
            $multiplier = 1.10;
            $reason = 'Warm weather: moderate cooling load (+10%)';
        } elseif ($temp < 10) {
            $multiplier = 1.30;
            $reason = 'Cold weather: heating load expected (+30%)';
        } elseif ($temp < 15) {
            $multiplier = 1.15;
            $reason = 'Cool weather: some heating load (+15%)';
        }

        return [
            'season' => $season,
            'temperature_c' => $temp,
            'multiplier' => $multiplier,
            'reason' => $reason,
            'recommendation' => $multiplier > 1.2
                ? 'Consider sizing system 20-30% larger for seasonal peaks'
                : 'Standard system sizing is adequate'
        ];
    }

    /**
     * Enhanced recommendation summary
     * Called after recommend_v7 produces results, adds city intelligence
     */
    public function enhanceRecommendation(array $recommendation): array {
        if (!$this->cityId || !$recommendation['success']) {
            return $recommendation;
        }

        $loadAnalysis = $recommendation['load_analysis'] ?? [];
        $dailyKwh = $loadAnalysis['daily_energy_kwh'] ?? 0;

        // Add solar context
        $recommendation['solar_context'] = [
            'city' => $this->cityData['name_en'] ?? 'Unknown',
            'province' => $this->cityData['province'] ?? '',
            'latitude' => (float)($this->cityData['latitude'] ?? 0),
            'season' => getCurrentSeason(),
            'enhanced_params' => $this->getEnhancedParams(),
            'seasonal_load' => $this->getSeasonalLoadMultiplier(),
            'weather_risk' => $this->getWeatherRiskFactors(),
        ];

        // Add generation predictions for each category option
        if (isset($recommendation['categories'])) {
            foreach ($recommendation['categories'] as &$cat) {
                if (!empty($cat['options'])) {
                    foreach ($cat['options'] as &$opt) {
                        $panelCfg = $opt['panel_config'] ?? [];
                        if (!empty($panelCfg)) {
                            $panelWp = (int)($panelCfg['panel']['wattage'] ?? 550);
                            $numPanels = (int)($panelCfg['quantity'] ?? 4);
                            $prediction = $this->predictGeneration($panelWp, $numPanels, $loadAnalysis['peak_sun_hours_used'] ?? 5.0);
                            if ($prediction['success']) {
                                $opt['generation_prediction'] = [
                                    'annual_kwh' => $prediction['annual_expected_kwh'],
                                    'daily_avg_kwh' => round($prediction['annual_expected_kwh'] / 365, 1),
                                    'meets_demand' => $prediction['annual_expected_kwh'] >= ($dailyKwh * 365 * 0.9),
                                    'surplus_pct' => $dailyKwh > 0
                                        ? round((($prediction['annual_expected_kwh'] / ($dailyKwh * 365)) - 1) * 100, 0)
                                        : 0,
                                    'specific_yield' => $prediction['specific_yield'],
                                    'best_months' => $this->getBestMonths($prediction['monthly'] ?? []),
                                    'worst_months' => $this->getWorstMonths($prediction['monthly'] ?? [])
                                ];
                            }
                        }
                    }
                    unset($opt);
                }
            }
            unset($cat);
        }

        // Add system sizing recommendation from SolarEngine
        if ($dailyKwh > 0) {
            $optimize = $this->solar->optimizeSystemSize($this->cityId, $dailyKwh);
            if ($optimize['success']) {
                $recommendation['solar_context']['optimal_sizing'] = [
                    'recommended_panels' => $optimize['recommended_panels'],
                    'system_kwp' => $optimize['system_kwp'],
                    'panel_watts' => $optimize['panel_watts'],
                    'worst_month' => $optimize['worst_month'],
                    'self_sufficiency_pct' => $optimize['self_sufficiency_pct']
                ];
            }
        }

        // Version bump
        $recommendation['version'] = ($recommendation['version'] ?? 'v10.2') . '+solar';

        return $recommendation;
    }

    /**
     * Get the 3 best performing months
     */
    private function getBestMonths(array $monthly): array {
        usort($monthly, fn($a, $b) => ($b['expected_kwh'] ?? 0) <=> ($a['expected_kwh'] ?? 0));
        return array_map(fn($m) => $m['month_name'], array_slice($monthly, 0, 3));
    }

    /**
     * Get the 3 worst performing months
     */
    private function getWorstMonths(array $monthly): array {
        usort($monthly, fn($a, $b) => ($a['expected_kwh'] ?? 0) <=> ($b['expected_kwh'] ?? 0));
        return array_map(fn($m) => $m['month_name'], array_slice($monthly, 0, 3));
    }

    private function getDefaultParams(): array {
        return [
            'peak_sun_hours' => DEFAULT_PEAK_SUN_HOURS,
            'ambient_temp_c' => 35,
            'city_id' => null,
            'city_name' => 'Not selected',
            'latitude' => 30.0,
            'longitude' => 70.0,
            'optimal_tilt' => 25.0,
            'season' => getCurrentSeason(),
            'source' => 'defaults'
        ];
    }
}
