<?php
/**
 * Data Retention Engine — Per-Plan Auto-Cleanup
 *
 * Each dealer/installer has a `subscription_plan` (basic|standard|premium|enterprise).
 * Admin configures retention months per plan in system_settings.
 * This engine deletes transactional data older than the plan's retention period.
 *
 * Plans (defaults):
 *   basic      =  6 months (free, included)
 *   standard   = 24 months ($2/mo add-on)
 *   premium    = 60 months ($5/mo add-on)
 *   enterprise =120 months ($10/mo add-on)
 *
 * Example: Dealer on Basic plan → 6 months = ~180 days.
 *   On day 181, all completed/cancelled orders from day 1 are auto-deleted.
 *
 * Tables purged per dealer:
 *   - orders (completed, picked_up, cancelled, refunded)
 *   - order_items (CASCADE from orders)
 *   - dealer_reviews
 *   - sale_returns (completed/cancelled)
 *   - sale_return_items (CASCADE from sale_returns)
 *
 * Tables purged per installer:
 *   - installer_orders (completed, cancelled)
 *   - installer_reviews
 *
 * NOT purged (profile/catalog data):
 *   - dealer_products, installer_service_areas, installer_portfolio
 */

if (!function_exists('get_system_setting')) {
    require_once __DIR__ . '/helpers.php';
}
if (!function_exists('getPaymentSetting')) {
    require_once __DIR__ . '/stripe_config.php';
}

/**
 * Get retention months for a given plan name.
 * Falls back to basic if plan is NULL/empty/unknown.
 */
function get_retention_months_for_plan(?string $plan): int
{
    $plan = strtolower(trim($plan ?? ''));

    // Map plan name → setting key
    $plan_keys = [
        'basic'      => 'retention_plan_basic_months',
        'standard'   => 'retention_plan_standard_months',
        'premium'    => 'retention_plan_premium_months',
        'enterprise' => 'retention_plan_enterprise_months',
    ];

    // Defaults per plan
    $defaults = [
        'basic'      => 6,
        'standard'   => 24,
        'premium'    => 60,
        'enterprise' => 120,
    ];

    // Unknown/empty plan → basic
    if (empty($plan) || !isset($plan_keys[$plan])) {
        $plan = 'basic';
    }

    $months = (int) get_system_setting($plan_keys[$plan], (string)$defaults[$plan]);
    return max(1, $months); // Minimum 1 month
}

/**
 * Run full per-plan data retention cleanup for all dealers and installers.
 * Returns array of log messages describing what was deleted.
 */
function run_data_retention_cleanup(PDO $db): array
{
    $log = [];

    // ─── DEALERS ─────────────────────────────────────────────────
    $log = array_merge($log, _purge_dealer_data($db));

    // ─── INSTALLERS ──────────────────────────────────────────────
    $log = array_merge($log, _purge_installer_data($db));

    // ─── GLOBAL CLEANUP (shared tables) ──────────────────────────
    $log = array_merge($log, _purge_global_data($db));

    if (empty($log)) {
        $log[] = "Retention: No data exceeded retention limits.";
    }

    return $log;
}

/**
 * Purge dealer transactional data per each dealer's retention plan.
 */
function _purge_dealer_data(PDO $db): array
{
    $log = [];

    // Get all dealers with their plan
    try {
        $stmt = $db->query("SELECT id, business_name, subscription_plan FROM dealers");
        $dealers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return ["Retention ERROR: Cannot read dealers table: " . $e->getMessage()];
    }

    // Group dealers by plan for batch operations
    $plan_groups = []; // plan_name => [dealer_ids]
    foreach ($dealers as $d) {
        $plan = strtolower(trim($d['subscription_plan'] ?? '')) ?: 'basic';
        $plan_groups[$plan][] = $d['id'];
    }

    foreach ($plan_groups as $plan => $dealer_ids) {
        $months = get_retention_months_for_plan($plan);
        $placeholders = implode(',', array_fill(0, count($dealer_ids), '?'));

        // 1. Delete old orders (order_items CASCADE automatically)
        try {
            $sql = "DELETE FROM orders
                    WHERE dealer_id IN ($placeholders)
                      AND status IN ('completed','picked_up','cancelled','refunded')
                      AND created_at < DATE_SUB(NOW(), INTERVAL ? MONTH)";
            $params = array_merge($dealer_ids, [$months]);
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $deleted = $stmt->rowCount();
            if ($deleted > 0) {
                $log[] = "Retention [{$plan}/{$months}mo]: Purged {$deleted} dealer orders (" . count($dealer_ids) . " dealers)";
            }
        } catch (PDOException $e) {
            $log[] = "Retention ERROR [orders/{$plan}]: " . $e->getMessage();
        }

        // 2. Delete old dealer reviews
        try {
            $sql = "DELETE FROM dealer_reviews
                    WHERE dealer_id IN ($placeholders)
                      AND created_at < DATE_SUB(NOW(), INTERVAL ? MONTH)";
            $params = array_merge($dealer_ids, [$months]);
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $deleted = $stmt->rowCount();
            if ($deleted > 0) {
                $log[] = "Retention [{$plan}/{$months}mo]: Purged {$deleted} dealer reviews";
            }
        } catch (PDOException $e) {
            // Table might not exist yet — skip silently
            if (strpos($e->getMessage(), "doesn't exist") === false) {
                $log[] = "Retention ERROR [dealer_reviews/{$plan}]: " . $e->getMessage();
            }
        }

        // 3. Delete old sale returns (sale_return_items CASCADE automatically)
        try {
            $sql = "DELETE FROM sale_returns
                    WHERE dealer_id IN ($placeholders)
                      AND status IN ('completed','cancelled','approved')
                      AND created_at < DATE_SUB(NOW(), INTERVAL ? MONTH)";
            $params = array_merge($dealer_ids, [$months]);
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $deleted = $stmt->rowCount();
            if ($deleted > 0) {
                $log[] = "Retention [{$plan}/{$months}mo]: Purged {$deleted} sale returns";
            }
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), "doesn't exist") === false) {
                $log[] = "Retention ERROR [sale_returns/{$plan}]: " . $e->getMessage();
            }
        }
    }

    return $log;
}

/**
 * Purge installer transactional data per each installer's retention plan.
 */
function _purge_installer_data(PDO $db): array
{
    $log = [];

    try {
        $stmt = $db->query("SELECT id, business_name, subscription_plan FROM installers");
        $installers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return ["Retention ERROR: Cannot read installers table: " . $e->getMessage()];
    }

    $plan_groups = [];
    foreach ($installers as $i) {
        $plan = strtolower(trim($i['subscription_plan'] ?? '')) ?: 'basic';
        $plan_groups[$plan][] = $i['id'];
    }

    foreach ($plan_groups as $plan => $installer_ids) {
        $months = get_retention_months_for_plan($plan);
        $placeholders = implode(',', array_fill(0, count($installer_ids), '?'));

        // 1. Delete old installer orders
        try {
            $sql = "DELETE FROM installer_orders
                    WHERE installer_id IN ($placeholders)
                      AND status IN ('completed','cancelled')
                      AND created_at < DATE_SUB(NOW(), INTERVAL ? MONTH)";
            $params = array_merge($installer_ids, [$months]);
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $deleted = $stmt->rowCount();
            if ($deleted > 0) {
                $log[] = "Retention [{$plan}/{$months}mo]: Purged {$deleted} installer orders (" . count($installer_ids) . " installers)";
            }
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), "doesn't exist") === false) {
                $log[] = "Retention ERROR [installer_orders/{$plan}]: " . $e->getMessage();
            }
        }

        // 2. Delete old installer reviews
        try {
            $sql = "DELETE FROM installer_reviews
                    WHERE installer_id IN ($placeholders)
                      AND created_at < DATE_SUB(NOW(), INTERVAL ? MONTH)";
            $params = array_merge($installer_ids, [$months]);
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $deleted = $stmt->rowCount();
            if ($deleted > 0) {
                $log[] = "Retention [{$plan}/{$months}mo]: Purged {$deleted} installer reviews";
            }
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), "doesn't exist") === false) {
                $log[] = "Retention ERROR [installer_reviews/{$plan}]: " . $e->getMessage();
            }
        }
    }

    return $log;
}

/**
 * Purge global/shared data not tied to a specific plan.
 * Uses the global "retention_order_history_months" as absolute max.
 */
function _purge_global_data(PDO $db): array
{
    $log = [];
    $max_months = (int) get_system_setting('retention_order_history_months', '120');
    if ($max_months <= 0) return $log;

    // Old email verification codes (always purge after 30 days)
    try {
        $stmt = $db->prepare("DELETE FROM email_verifications WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $stmt->execute();
        $d = $stmt->rowCount();
        if ($d > 0) $log[] = "Retention [global]: Purged {$d} old email verification codes";
    } catch (PDOException $e) { /* table might not exist */ }

    // Old visitor stats beyond max retention
    try {
        $stmt = $db->prepare("DELETE FROM visitor_stats WHERE date < DATE_SUB(NOW(), INTERVAL ? MONTH)");
        $stmt->execute([$max_months]);
        $d = $stmt->rowCount();
        if ($d > 0) $log[] = "Retention [global/{$max_months}mo]: Purged {$d} old visitor stats";
    } catch (PDOException $e) { /* table might not exist */ }

    // Old sessions beyond 6 months
    try {
        $stmt = $db->prepare("DELETE FROM customer_sessions WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH)");
        $stmt->execute();
        $d = $stmt->rowCount();
        if ($d > 0) $log[] = "Retention [global]: Purged {$d} old customer sessions";
    } catch (PDOException $e) { /* table might not exist */ }

    try {
        $stmt = $db->prepare("DELETE FROM dealer_sessions WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH)");
        $stmt->execute();
        $d = $stmt->rowCount();
        if ($d > 0) $log[] = "Retention [global]: Purged {$d} old dealer sessions";
    } catch (PDOException $e) { /* table might not exist */ }

    // Old import logs beyond max retention
    try {
        $stmt = $db->prepare("DELETE FROM import_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? MONTH)");
        $stmt->execute([$max_months]);
        $d = $stmt->rowCount();
        if ($d > 0) $log[] = "Retention [global/{$max_months}mo]: Purged {$d} old import logs";
    } catch (PDOException $e) { /* table might not exist */ }

    return $log;
}

/**
 * Get retention info for a specific dealer/installer (for display in dashboard).
 * Returns: ['plan' => 'basic', 'months' => 6, 'label' => 'Basic (6 months)', 'days' => 180]
 */
function get_retention_info(?string $plan): array
{
    $plan = strtolower(trim($plan ?? '')) ?: 'basic';
    $months = get_retention_months_for_plan($plan);

    $labels = [
        'basic'      => 'Basic',
        'standard'   => 'Standard',
        'premium'    => 'Premium',
        'enterprise' => 'Enterprise',
    ];

    $label = ($labels[$plan] ?? 'Basic') . " ({$months} months)";

    // Get fee
    $fee_keys = [
        'basic'      => 'retention_plan_basic_fee',
        'standard'   => 'retention_plan_standard_fee',
        'premium'    => 'retention_plan_premium_fee',
        'enterprise' => 'retention_plan_enterprise_fee',
    ];
    $fee = (float) get_system_setting($fee_keys[$plan] ?? 'retention_plan_basic_fee', '0.00');

    return [
        'plan'   => $plan,
        'months' => $months,
        'days'   => $months * 30,
        'label'  => $label,
        'fee'    => $fee,
    ];
}

/**
 * Get all available retention plans (for plan selection UI).
 */
function get_all_retention_plans(): array
{
    $plans = ['basic', 'standard', 'premium', 'enterprise'];
    $result = [];

    foreach ($plans as $p) {
        $result[] = get_retention_info($p);
    }

    return $result;
}

/**
 * Update a dealer's or installer's retention plan.
 */
function update_retention_plan(PDO $db, string $table, int $id, string $new_plan): bool
{
    $valid = ['basic', 'standard', 'premium', 'enterprise'];
    $new_plan = strtolower(trim($new_plan));
    if (!in_array($new_plan, $valid)) return false;

    if (!in_array($table, ['dealers', 'installers'])) return false;

    $stmt = $db->prepare("UPDATE {$table} SET subscription_plan = ? WHERE id = ?");
    $stmt->execute([$new_plan, $id]);

    $months = get_retention_months_for_plan($new_plan);
    error_log("Retention: Updated {$table} #{$id} to plan '{$new_plan}' ({$months} months)");

    return true;
}
