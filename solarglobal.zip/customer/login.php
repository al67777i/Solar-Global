<?php
/**
 * Customer Login Page
 * Two methods: Google OAuth + Email OTP
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/customer_auth.php';

set_security_headers();

// Already logged in?
if (is_customer_logged_in()) {
    header('Location: /solarglobal/customer/orders.php');
    exit();
}

$db = getDB();
$error = '';
$success = '';
$step = $_POST['step'] ?? 'login'; // login, otp_sent, verify_otp
$otp_email = $_SESSION['otp_email'] ?? '';

// Get Google OAuth client ID
$google_client_id = '';
try {
    $google_client_id = get_system_setting('google_oauth_client_id', '');
} catch (Exception $e) {}

// Handle OTP request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';

    if ($action === 'send_otp') {
        $email = strtolower(trim($_POST['email'] ?? ''));
        $name = trim($_POST['name'] ?? '');

        // Honeypot check
        if (!validate_honeypot('website_url')) {
            $error = 'Submission rejected.';
        // reCAPTCHA v3 check
        } elseif (!empty($_POST['g-recaptcha-response'])) {
            $captcha = verify_recaptcha($_POST['g-recaptcha-response'], 0.5, 'customer_login');
            if (!$captcha['success']) {
                $error = 'Bot verification failed. Please try again.';
            }
        }

        if (empty($error) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        }

        if (empty($error)) {
            // Find or create customer
            $stmt = $db->prepare("SELECT id, name, email, is_active FROM customers WHERE email = ?");
            $stmt->execute([$email]);
            $customer = $stmt->fetch();

            if ($customer && !$customer['is_active']) {
                $error = 'This account has been deactivated. Please contact support.';
            } else {
                $otp = generate_otp();
                $expires = date('Y-m-d H:i:s', time() + 600); // 10 minutes

                if ($customer) {
                    // Update OTP
                    $stmt = $db->prepare("UPDATE customers SET otp_code = ?, otp_expires_at = ? WHERE id = ?");
                    $stmt->execute([$otp, $expires, $customer['id']]);
                } else {
                    // Create new customer
                    $stmt = $db->prepare("INSERT INTO customers (name, email, otp_code, otp_expires_at, email_verified, is_active) VALUES (?, ?, ?, ?, 0, 1)");
                    $stmt->execute([$name ?: explode('@', $email)[0], $email, $otp, $expires]);
                }

                // Send OTP
                $sent = send_otp_email($email, $otp, $name ?: ($customer['name'] ?? ''));
                $_SESSION['otp_email'] = $email;
                $otp_email = $email;
                $step = 'otp_sent';
                $success = 'A 6-digit code has been sent to your email.';

                // Dev OTP display — only when SOLARGLOBAL_DEV env is explicitly set
                if (getenv('SOLARGLOBAL_DEV') === 'true') {
                    $_SESSION['dev_otp'] = $otp;
                }
            }
        }
    } elseif ($action === 'verify_otp') {
        $email = $_SESSION['otp_email'] ?? '';
        $code = trim($_POST['otp_code'] ?? '');

        if (empty($email) || empty($code)) {
            $error = 'Please enter the verification code.';
            $step = 'otp_sent';
        } else {
            $stmt = $db->prepare("SELECT * FROM customers WHERE email = ? AND otp_code = ? AND otp_expires_at > NOW() AND is_active = 1");
            $stmt->execute([$email, $code]);
            $customer = $stmt->fetch();

            if ($customer) {
                // Clear OTP and mark email verified
                $db->prepare("UPDATE customers SET otp_code = NULL, otp_expires_at = NULL, email_verified = 1 WHERE id = ?")
                   ->execute([$customer['id']]);

                customer_login($customer);

                // Redirect
                $redirect = $_SESSION['customer_redirect_after_login'] ?? '/solarglobal/customer/orders.php';
                unset($_SESSION['otp_email'], $_SESSION['dev_otp'], $_SESSION['customer_redirect_after_login']);
                header("Location: $redirect");
                exit();
            } else {
                $error = 'Invalid or expired code. Please try again.';
                $step = 'otp_sent';
            }
        }
    } elseif ($action === 'password_login') {
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } elseif (empty($password)) {
            $error = 'Please enter your password.';
        } else {
            $stmt = $db->prepare("SELECT * FROM customers WHERE email = ? AND is_active = 1");
            $stmt->execute([$email]);
            $customer = $stmt->fetch();

            if ($customer && !empty($customer['password_hash']) && password_verify($password, $customer['password_hash'])) {
                customer_login($customer);
                $redirect = $_SESSION['customer_redirect_after_login'] ?? '/solarglobal/customer/orders.php';
                unset($_SESSION['customer_redirect_after_login']);
                header("Location: $redirect");
                exit();
            } else {
                $error = 'Invalid email or password.';
            }
        }
    } elseif ($action === 'google_login') {
        $id_token = $_POST['google_token'] ?? '';
        $google_user = verify_google_token($id_token);

        if (!$google_user || empty($google_user['email'])) {
            $error = 'Google login failed. Please try again.';
        } else {
            // Find by google_id or email
            $stmt = $db->prepare("SELECT * FROM customers WHERE google_id = ? OR email = ? LIMIT 1");
            $stmt->execute([$google_user['google_id'], $google_user['email']]);
            $customer = $stmt->fetch();

            if ($customer && !$customer['is_active']) {
                $error = 'This account has been deactivated.';
            } elseif ($customer) {
                // Update google_id and avatar if needed
                $db->prepare("UPDATE customers SET google_id = ?, avatar_url = ?, email_verified = 1, name = COALESCE(NULLIF(name, ''), ?) WHERE id = ?")
                   ->execute([$google_user['google_id'], $google_user['avatar_url'], $google_user['name'], $customer['id']]);
                $customer['avatar_url'] = $google_user['avatar_url'];
                customer_login($customer);

                $redirect = $_SESSION['customer_redirect_after_login'] ?? '/solarglobal/customer/orders.php';
                unset($_SESSION['customer_redirect_after_login']);
                header("Location: $redirect");
                exit();
            } else {
                // Create new customer from Google
                $stmt = $db->prepare("INSERT INTO customers (name, email, google_id, avatar_url, email_verified, is_active) VALUES (?, ?, ?, ?, 1, 1)");
                $stmt->execute([$google_user['name'], $google_user['email'], $google_user['google_id'], $google_user['avatar_url']]);
                $newId = $db->lastInsertId();

                $stmt = $db->prepare("SELECT * FROM customers WHERE id = ?");
                $stmt->execute([$newId]);
                $customer = $stmt->fetch();
                customer_login($customer);

                $redirect = $_SESSION['customer_redirect_after_login'] ?? '/solarglobal/customer/orders.php';
                unset($_SESSION['customer_redirect_after_login']);
                header("Location: $redirect");
                exit();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= sanitize(get_system_setting('site_name', 'SolarGlobal')) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php if ($google_client_id): ?>
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <?php endif; ?>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: linear-gradient(135deg, #0F172A 0%, #1E3A5F 50%, #0F172A 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }

        .login-card {
            background: white; border-radius: 20px; padding: 40px; width: 100%; max-width: 420px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3); margin: 20px;
        }

        .logo { text-align: center; margin-bottom: 32px; }
        .logo h1 { font-size: 1.75rem; font-weight: 800; color: #0F172A; }
        .logo h1 span { color: #F59E0B; }
        .logo p { color: #64748B; font-size: 0.875rem; margin-top: 4px; }

        .alert { padding: 12px 16px; border-radius: 10px; font-size: 0.875rem; margin-bottom: 20px; }
        .alert-error { background: #FEF2F2; color: #991B1B; border: 1px solid #FECACA; }
        .alert-success { background: #F0FDF4; color: #166534; border: 1px solid #BBF7D0; }

        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.8125rem; font-weight: 600; color: #374151; margin-bottom: 6px; }
        .form-group input {
            width: 100%; padding: 12px 16px; border: 2px solid #E2E8F0; border-radius: 10px;
            font-size: 0.9375rem; font-family: inherit; transition: border-color 0.2s;
        }
        .form-group input:focus { outline: none; border-color: #F59E0B; }

        .otp-inputs { display: flex; gap: 8px; justify-content: center; margin: 16px 0; }
        .otp-inputs input {
            width: 48px; height: 56px; text-align: center; font-size: 1.5rem; font-weight: 700;
            border: 2px solid #E2E8F0; border-radius: 10px; font-family: inherit;
        }
        .otp-inputs input:focus { outline: none; border-color: #F59E0B; }

        .btn {
            width: 100%; padding: 14px; border: none; border-radius: 10px; font-size: 0.9375rem;
            font-weight: 700; cursor: pointer; font-family: inherit; transition: all 0.2s;
        }
        .btn-primary { background: #F59E0B; color: #1E293B; }
        .btn-primary:hover { background: #D97706; transform: translateY(-1px); }

        .divider {
            display: flex; align-items: center; gap: 12px; margin: 24px 0;
            color: #94A3B8; font-size: 0.8125rem;
        }
        .divider::before, .divider::after { content: ''; flex: 1; height: 1px; background: #E2E8F0; }

        .google-btn-wrapper { display: flex; justify-content: center; margin-bottom: 16px; }

        .back-link { text-align: center; margin-top: 20px; }
        .back-link a { color: #64748B; text-decoration: none; font-size: 0.8125rem; }
        .back-link a:hover { color: #F59E0B; }

        .resend-link { text-align: center; margin-top: 12px; font-size: 0.8125rem; color: #64748B; }
        .resend-link a { color: #1565C0; text-decoration: none; font-weight: 600; }

        .dev-otp { background: #FFFBEB; border: 1px solid #FCD34D; border-radius: 8px; padding: 10px; text-align: center; font-size: 0.8125rem; color: #92400E; margin-bottom: 16px; }
        .dev-otp strong { font-size: 1.25rem; }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="logo">
            <?php $sn = get_system_setting('site_name', 'SolarGlobal'); ?>
            <h1><?= sanitize($sn) ?></h1>
            <p>Customer Login</p>
        </div>

        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>

        <?php if ($step === 'otp_sent'): ?>
            <!-- OTP Verification Step -->
            <?php if (isset($_SESSION['dev_otp'])): ?>
                <div class="dev-otp">DEV MODE — Your OTP: <strong><?= $_SESSION['dev_otp'] ?></strong></div>
            <?php endif; ?>

            <p style="text-align:center;color:#475569;font-size:0.875rem;margin-bottom:16px;">
                Enter the 6-digit code sent to<br><strong><?= sanitize($otp_email) ?></strong>
            </p>

            <form method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="verify_otp">
                <input type="hidden" name="step" value="verify_otp">
                <div class="otp-inputs" id="otp-container">
                    <input type="text" maxlength="1" class="otp-digit" autofocus>
                    <input type="text" maxlength="1" class="otp-digit">
                    <input type="text" maxlength="1" class="otp-digit">
                    <input type="text" maxlength="1" class="otp-digit">
                    <input type="text" maxlength="1" class="otp-digit">
                    <input type="text" maxlength="1" class="otp-digit">
                </div>
                <input type="hidden" name="otp_code" id="otp-hidden">
                <button type="submit" class="btn btn-primary" id="verify-btn">Verify & Login</button>
            </form>

            <div class="resend-link">
                Didn't receive it? <a href="login.php">Try again</a>
            </div>

        <?php else: ?>
            <!-- Login Step -->
            <?php if ($google_client_id): ?>
                <div class="google-btn-wrapper">
                    <div id="g_id_onload"
                         data-client_id="<?= sanitize($google_client_id) ?>"
                         data-callback="handleGoogleLogin"
                         data-auto_prompt="false">
                    </div>
                    <div class="g_id_signin"
                         data-type="standard"
                         data-shape="rectangular"
                         data-theme="outline"
                         data-text="continue_with"
                         data-size="large"
                         data-logo_alignment="left"
                         data-width="340">
                    </div>
                </div>
                <div class="divider">or login with email</div>
            <?php endif; ?>

            <!-- Tab Toggle: Password / OTP -->
            <div style="display:flex; gap:0; margin-bottom:20px; border:2px solid #E2E8F0; border-radius:10px; overflow:hidden;">
                <button type="button" class="login-tab active" data-tab="password" style="flex:1; padding:10px; border:none; font-size:0.8125rem; font-weight:600; cursor:pointer; font-family:inherit; transition:all 0.2s; background:#F59E0B; color:#1E293B;">Password</button>
                <button type="button" class="login-tab" data-tab="otp" style="flex:1; padding:10px; border:none; font-size:0.8125rem; font-weight:600; cursor:pointer; font-family:inherit; transition:all 0.2s; background:white; color:#64748B;">Email OTP</button>
            </div>

            <!-- Password Login Form -->
            <form method="POST" id="password-form" class="login-form-tab">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="password_login">
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" placeholder="you@example.com" required autofocus>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter your password" required>
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
            </form>

            <!-- OTP Login Form -->
            <form method="POST" id="otp-form" class="login-form-tab" style="display:none;">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="send_otp">
                <input type="hidden" name="step" value="login">
                <input type="hidden" name="g-recaptcha-response" id="recaptcha-token">
                <?= render_honeypot_field('website_url') ?>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" placeholder="you@example.com" required>
                </div>
                <div class="form-group">
                    <label>Your Name <span style="color:#94A3B8;font-weight:400;">(for new accounts)</span></label>
                    <input type="text" name="name" placeholder="John Doe">
                </div>
                <button type="submit" class="btn btn-primary">Send Login Code</button>
            </form>

            <div style="text-align:center; margin-top:16px;">
                <a href="/solarglobal/customer/register.php" style="color:#F59E0B; text-decoration:none; font-size:0.875rem; font-weight:600;">Don't have an account? Register</a>
            </div>
        <?php endif; ?>

        <div class="back-link">
            <a href="/solarglobal/">&larr; Back to <?= sanitize(get_system_setting('site_name', 'SolarGlobal')) ?></a>
        </div>
    </div>

    <!-- Google login form (hidden) -->
    <form id="google-form" method="POST" style="display:none;">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="google_login">
        <input type="hidden" name="google_token" id="google-token">
    </form>

    <script>
    // Tab switching
    document.querySelectorAll('.login-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.login-tab').forEach(t => { t.style.background = 'white'; t.style.color = '#64748B'; t.classList.remove('active'); });
            tab.style.background = '#F59E0B'; tab.style.color = '#1E293B'; tab.classList.add('active');
            const target = tab.dataset.tab;
            document.getElementById('password-form').style.display = target === 'password' ? 'block' : 'none';
            document.getElementById('otp-form').style.display = target === 'otp' ? 'block' : 'none';
        });
    });

    // OTP input auto-advance
    document.querySelectorAll('.otp-digit').forEach((input, idx, inputs) => {
        input.addEventListener('input', e => {
            const val = e.target.value.replace(/\D/g, '');
            e.target.value = val.slice(0, 1);
            if (val && idx < inputs.length - 1) inputs[idx + 1].focus();
            updateHiddenOTP();
        });
        input.addEventListener('keydown', e => {
            if (e.key === 'Backspace' && !e.target.value && idx > 0) {
                inputs[idx - 1].focus();
            }
        });
        input.addEventListener('paste', e => {
            e.preventDefault();
            const pasted = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6);
            pasted.split('').forEach((ch, i) => { if (inputs[i]) inputs[i].value = ch; });
            if (inputs[Math.min(pasted.length, inputs.length - 1)]) inputs[Math.min(pasted.length, inputs.length - 1)].focus();
            updateHiddenOTP();
        });
    });

    function updateHiddenOTP() {
        const digits = Array.from(document.querySelectorAll('.otp-digit')).map(i => i.value).join('');
        document.getElementById('otp-hidden').value = digits;
    }

    // Auto-submit when 6 digits entered
    document.getElementById('otp-container')?.addEventListener('input', () => {
        const digits = Array.from(document.querySelectorAll('.otp-digit')).map(i => i.value).join('');
        if (digits.length === 6) {
            document.getElementById('otp-hidden').value = digits;
            document.getElementById('verify-btn').click();
        }
    });

    // Google OAuth callback
    function handleGoogleLogin(response) {
        document.getElementById('google-token').value = response.credential;
        document.getElementById('google-form').submit();
    }

    // reCAPTCHA v3 — get token before OTP form submit
    <?php $rcKey = get_recaptcha_site_key(); if (!empty($rcKey)): ?>
    const otpForm = document.getElementById('otp-form');
    if (otpForm) {
        otpForm.addEventListener('submit', function(e) {
            e.preventDefault();
            grecaptcha.ready(function() {
                grecaptcha.execute('<?= htmlspecialchars($rcKey) ?>', {action: 'customer_login'}).then(function(token) {
                    document.getElementById('recaptcha-token').value = token;
                    otpForm.submit();
                });
            });
        });
    }
    <?php endif; ?>
    </script>
    <?= render_recaptcha_script() ?>
</body>
</html>
