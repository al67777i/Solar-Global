/**
 * Weather-Based Dynamic Background v3
 * ====================================
 * Animated weather shown INSIDE the main content area (gray zone)
 * NOT behind nav/hero - only behind the wizard/map content
 * 8 weather types with beautiful animations
 */

(function() {
    'use strict';

    const WeatherBackground = {
        container: null,
        currentWeather: null,
        currentCode: null,

        init() {
            // Insert weather-bg inside .main-content so it's behind the content area only
            const mainContent = document.querySelector('.main-content');
            if (!mainContent) return;

            this.container = document.createElement('div');
            this.container.id = 'weather-bg';
            this.container.className = 'weather-bg';
            mainContent.style.position = 'relative';
            mainContent.prepend(this.container);
        },

        /**
         * Fetch weather for coordinates and update background
         */
        async fetchAndUpdate(lat, lng) {
            if (!lat || !lng) return;

            try {
                const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=weather_code,is_day,temperature_2m,cloud_cover,wind_speed_10m&timezone=auto`;
                const res = await fetch(url);
                const data = await res.json();

                if (data?.current) {
                    const code = data.current.weather_code;
                    const isDay = data.current.is_day === 1;
                    const temp = data.current.temperature_2m;
                    const cloud = data.current.cloud_cover;

                    this.update(code, isDay);

                    window.dispatchEvent(new CustomEvent('weatherUpdated', {
                        detail: { code, isDay, temp, cloud, type: this.currentWeather, lat, lng }
                    }));

                }
            } catch (err) {
                console.warn('Weather fetch failed:', err);
            }
        },

        /**
         * Update background based on WMO Weather Code
         */
        update(weatherCode, isDay = true) {
            if (!this.container) this.init();
            if (!this.container) return;
            if (weatherCode === this.currentCode) return;
            this.currentCode = weatherCode;

            // Clear previous
            this.container.innerHTML = '';
            this.container.className = 'weather-bg';

            if (weatherCode === null || weatherCode === undefined) return;

            let weatherType = 'clear';
            if (weatherCode === 0) weatherType = 'clear';
            else if (weatherCode <= 3) weatherType = 'cloudy';
            else if (weatherCode <= 48) weatherType = 'foggy';
            else if (weatherCode <= 55) weatherType = 'drizzle';
            else if (weatherCode <= 65) weatherType = 'rainy';
            else if (weatherCode <= 75) weatherType = 'snowy';
            else if (weatherCode <= 82) weatherType = 'rainy';
            else if (weatherCode >= 95) weatherType = 'stormy';

            this.container.classList.add(`weather-${weatherType}`);
            if (!isDay) this.container.classList.add('weather-night');

            // Toggle night class on the main content wrapper
            const mainContent = document.querySelector('.main-content');
            if (mainContent) {
                mainContent.classList.toggle('weather-night', !isDay);
            }

            this.currentWeather = weatherType;
            this.renderEffects(weatherType, isDay);
        },

        renderEffects(type, isDay) {
            switch(type) {
                case 'clear':
                    if (isDay) {
                        this.renderSun();
                        this.renderSolarParticles();
                    } else {
                        this.renderMoon();
                        this.renderStars(50);
                    }
                    break;
                case 'cloudy':
                    this.renderClouds(5, isDay);
                    if (isDay) this.renderSun(true);
                    else { this.renderMoon(); this.renderStars(20); }
                    break;
                case 'foggy':
                    this.renderFogLayers();
                    if (!isDay) this.renderStars(10);
                    break;
                case 'drizzle':
                    this.renderRain(30);
                    this.renderClouds(3, isDay);
                    if (!isDay) this.renderStars(8);
                    break;
                case 'rainy':
                    this.renderRain(60);
                    this.renderClouds(5, isDay);
                    this.renderRipples(8);
                    break;
                case 'stormy':
                    this.renderRain(80);
                    this.renderClouds(7, isDay);
                    this.renderLightning();
                    this.renderRipples(12);
                    break;
                case 'snowy':
                    this.renderSnow(40);
                    this.renderClouds(3, isDay);
                    if (!isDay) this.renderStars(15);
                    break;
            }
        },

        // ── Sun ──
        renderSun(partial = false) {
            const sun = document.createElement('div');
            sun.className = 'wb-sun' + (partial ? ' wb-sun-partial' : '');
            sun.innerHTML = `
                <div class="wb-sun-core"></div>
                <div class="wb-sun-glow"></div>
                ${!partial ? Array.from({length: 8}, (_, i) =>
                    `<div class="wb-sun-ray" style="transform:rotate(${i * 45}deg)"></div>`
                ).join('') : ''}
            `;
            this.container.appendChild(sun);
        },

        // ── Moon ──
        renderMoon() {
            const glow = document.createElement('div');
            glow.className = 'wb-moon-glow';
            const moon = document.createElement('div');
            moon.className = 'wb-moon';
            this.container.appendChild(glow);
            this.container.appendChild(moon);
        },

        // ── Stars ──
        renderStars(count) {
            const frag = document.createDocumentFragment();
            for (let i = 0; i < count; i++) {
                const star = document.createElement('div');
                star.className = 'wb-star';
                const size = 1 + Math.random() * 2.5;
                star.style.cssText = `
                    left:${Math.random()*100}%;
                    top:${Math.random()*65}%;
                    width:${size}px;
                    height:${size}px;
                    animation-delay:${Math.random()*5}s;
                    animation-duration:${2+Math.random()*3}s;
                `;
                frag.appendChild(star);
            }
            this.container.appendChild(frag);
        },

        // ── Solar particles ──
        renderSolarParticles() {
            const frag = document.createDocumentFragment();
            for (let i = 0; i < 15; i++) {
                const p = document.createElement('div');
                p.className = 'wb-solar-particle';
                p.style.cssText = `
                    left:${5+Math.random()*90}%;
                    top:${5+Math.random()*70}%;
                    animation-delay:${Math.random()*8}s;
                    animation-duration:${5+Math.random()*5}s;
                    width:${2+Math.random()*4}px;
                    height:${2+Math.random()*4}px;
                `;
                frag.appendChild(p);
            }
            this.container.appendChild(frag);
        },

        // ── Clouds ──
        renderClouds(count, isDay) {
            const frag = document.createDocumentFragment();
            for (let i = 0; i < count; i++) {
                const cloud = document.createElement('div');
                cloud.className = 'wb-cloud' + (!isDay ? ' wb-cloud-night' : '');
                const scale = 0.4 + Math.random() * 0.8;
                cloud.style.cssText = `
                    top:${2+Math.random()*25}%;
                    left:${-15+Math.random()*10}%;
                    animation-delay:${i * -(6+Math.random()*4)}s;
                    animation-duration:${25+Math.random()*20}s;
                    opacity:${0.3+Math.random()*0.5};
                    transform:scale(${scale});
                `;
                frag.appendChild(cloud);
            }
            this.container.appendChild(frag);
        },

        // ── Rain ──
        renderRain(drops) {
            const frag = document.createDocumentFragment();
            for (let i = 0; i < drops; i++) {
                const drop = document.createElement('div');
                drop.className = 'wb-raindrop';
                drop.style.cssText = `
                    left:${Math.random()*100}%;
                    animation-delay:${Math.random()*2.5}s;
                    animation-duration:${0.35+Math.random()*0.4}s;
                    opacity:${0.2+Math.random()*0.45};
                    height:${14+Math.random()*12}px;
                `;
                frag.appendChild(drop);
            }
            this.container.appendChild(frag);
        },

        // ── Ripples ──
        renderRipples(count) {
            const frag = document.createDocumentFragment();
            for (let i = 0; i < count; i++) {
                const ripple = document.createElement('div');
                ripple.className = 'wb-ripple';
                ripple.style.cssText = `
                    left:${5+Math.random()*90}%;
                    bottom:${2+Math.random()*20}%;
                    animation-delay:${Math.random()*3}s;
                `;
                frag.appendChild(ripple);
            }
            this.container.appendChild(frag);
        },

        // ── Fog ──
        renderFogLayers() {
            const frag = document.createDocumentFragment();
            for (let i = 0; i < 5; i++) {
                const fog = document.createElement('div');
                fog.className = 'wb-fog';
                fog.style.cssText = `
                    top:${10+i*16}%;
                    animation-delay:${i*-3.5}s;
                    opacity:${0.08+i*0.04};
                    animation-duration:${16+Math.random()*8}s;
                `;
                frag.appendChild(fog);
            }
            this.container.appendChild(frag);
        },

        // ── Lightning ──
        renderLightning() {
            const bolt = document.createElement('div');
            bolt.className = 'wb-lightning';
            this.container.appendChild(bolt);
        },

        // ── Snow ──
        renderSnow(count) {
            const frag = document.createDocumentFragment();
            for (let i = 0; i < count; i++) {
                const flake = document.createElement('div');
                flake.className = 'wb-snowflake';
                const size = 4 + Math.random() * 8;
                flake.style.cssText = `
                    left:${Math.random()*100}%;
                    animation-delay:${Math.random()*6}s;
                    animation-duration:${4+Math.random()*5}s;
                    width:${size}px;
                    height:${size}px;
                    opacity:${0.3+Math.random()*0.5};
                `;
                frag.appendChild(flake);
            }
            this.container.appendChild(frag);
        },

        clear() {
            if (this.container) {
                this.container.innerHTML = '';
                this.container.className = 'weather-bg';
                this.currentCode = null;
                this.currentWeather = null;
            }
        }
    };

    // Expose globally
    window.WeatherBackground = WeatherBackground;

    // Auto-initialize
    document.addEventListener('DOMContentLoaded', () => {
        WeatherBackground.init();

        if (window.SolarLocation?.onLocationChange) {
            window.SolarLocation.onLocationChange((loc) => {
                if (loc?.lat && loc?.lng) {
                    WeatherBackground.fetchAndUpdate(loc.lat, loc.lng);
                }
            });
        }

        let checks = 0;
        const checkInterval = setInterval(() => {
            checks++;
            if (WeatherBackground.currentCode || checks > 10) {
                clearInterval(checkInterval);
                return;
            }
            const loc = window.SolarLocation?.getLocation?.();
            if (loc?.lat && loc?.lng) {
                WeatherBackground.fetchAndUpdate(loc.lat, loc.lng);
                clearInterval(checkInterval);
            }
        }, 800);
    });

    window.addEventListener('locationSelected', (e) => {
        const { lat, lng } = e.detail || {};
        if (lat && lng) WeatherBackground.fetchAndUpdate(lat, lng);
    });
})();
