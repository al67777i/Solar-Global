﻿<?php
/**
 * Store Detail Page — Public
 * View a dealer's store: products, reviews, installation request
 * URL: store-detail.php?id=1
 */
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/csrf.php';

set_security_headers();

$db = getDB();

// ─── Ensure installation_requests table exists ───
try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS installation_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            dealer_id INT NOT NULL,
            customer_name VARCHAR(150) NOT NULL,
            customer_phone VARCHAR(30) NOT NULL,
            customer_email VARCHAR(255) NULL,
            system_size VARCHAR(20) NULL,
            message TEXT NULL,
            status ENUM('pending','contacted','completed','cancelled') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_dealer (dealer_id),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
} catch (Exception $e) {
    // Table may already exist — silently continue
}

// ─── AJAX: Installation Request Submission ───
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_installation_request') {
    header('Content-Type: application/json; charset=utf-8');

    if (!rate_limit('install_req_' . ($_SERVER['REMOTE_ADDR'] ?? ''), 5, 300)) {
        echo json_encode(['success' => false, 'message' => 'Too many requests. Please try again later.']);
        exit;
    }

    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid security token. Please refresh and try again.']);
        exit;
    }

    $req_dealer_id = filter_var($_POST['dealer_id'] ?? 0, FILTER_VALIDATE_INT);
    $req_name      = trim($_POST['customer_name'] ?? '');
    $req_phone     = trim($_POST['customer_phone'] ?? '');
    $req_email     = trim($_POST['customer_email'] ?? '');
    $req_size      = trim($_POST['system_size'] ?? '');
    $req_message   = trim($_POST['message'] ?? '');

    $errors = [];
    if (!$req_dealer_id || $req_dealer_id < 1) $errors[] = 'Invalid dealer.';
    if ($req_name === '' || mb_strlen($req_name) > 150) $errors[] = 'Name is required (max 150 chars).';
    if ($req_phone === '' || mb_strlen($req_phone) > 30) $errors[] = 'Phone is required (max 30 chars).';
    if ($req_email !== '' && !filter_var($req_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email address.';
    if (mb_strlen($req_message) > 2000) $errors[] = 'Message is too long (max 2000 chars).';

    $allowed_sizes = ['3kW', '5kW', '10kW', '15kW', '20kW', 'Custom', ''];
    if (!in_array($req_size, $allowed_sizes)) $req_size = '';

    if (!empty($errors)) {
        echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
        exit;
    }

    // Verify dealer exists
    $chk = $db->prepare("SELECT id FROM dealers WHERE id = ? AND status IN ('active','approved')");
    $chk->execute([$req_dealer_id]);
    if (!$chk->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Dealer not found.']);
        exit;
    }

    $ins = $db->prepare("
        INSERT INTO installation_requests (dealer_id, customer_name, customer_phone, customer_email, system_size, message)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $ins->execute([
        $req_dealer_id,
        $req_name,
        $req_phone,
        $req_email ?: null,
        $req_size ?: null,
        $req_message ?: null
    ]);

    echo json_encode(['success' => true, 'message' => 'Your installation request has been submitted! The dealer will contact you soon.']);
    exit;
}

// ─── AJAX: Load Products ───
if (isset($_GET['ajax']) && $_GET['ajax'] === 'products') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $ajax_dealer_id = filter_var($_GET['dealer_id'] ?? 0, FILTER_VALIDATE_INT);
        if (!$ajax_dealer_id) {
            echo json_encode(['products' => []]);
            exit;
        }

        $type_filter = $_GET['type'] ?? 'all';
        $allowed_types = ['all', 'inverter', 'battery', 'panel', 'installation_appliance'];
        if (!in_array($type_filter, $allowed_types)) $type_filter = 'all';

        $where_type = '';
        $params = [$ajax_dealer_id];
        if ($type_filter !== 'all') {
            $where_type = 'AND dp.product_type = ?';
            $params[] = $type_filter;
        }

        $sql = "
            SELECT dp.id AS dp_id, dp.product_type, dp.dealer_price, dp.stock_quantity,
                   dp.product_id
            FROM dealer_products dp
            WHERE dp.dealer_id = ? AND dp.is_active = 1
            $where_type
            ORDER BY dp.product_type, dp.dealer_price ASC
        ";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Group product IDs by type to batch-fetch details
        $grouped = [];
        foreach ($rows as $r) {
            $grouped[$r['product_type']][] = $r;
        }

        // Fetch dealer country for currency
        $d_stmt = $db->prepare("SELECT country_code FROM dealers WHERE id = ?");
        $d_stmt->execute([$ajax_dealer_id]);
        $d_cc = $d_stmt->fetchColumn() ?: 'US';
        $currency_info = get_country_currency_info($d_cc);

        $type_table_map = [
            'inverter' => ['table' => 'inverters', 'fields' => 'id, name, brand, power_rating AS spec, type, image_path'],
            'battery'  => ['table' => 'batteries', 'fields' => 'id, name, brand, CONCAT(capacity_ah, "Ah / ", voltage, "V") AS spec, type, image_path'],
            'panel'    => ['table' => 'panels', 'fields' => 'id, name, brand, CONCAT(wattage, "W") AS spec, type, image_path'],
            'installation_appliance' => ['table' => 'installation_appliances', 'fields' => 'id, name, brand, category AS spec, "" AS type, image_path'],
        ];

        $products = [];
        foreach ($grouped as $ptype => $items) {
            if (!isset($type_table_map[$ptype])) continue;
            $tinfo = $type_table_map[$ptype];
            $pids = array_column($items, 'product_id');
            if (empty($pids)) continue;

            $ph = implode(',', array_fill(0, count($pids), '?'));
            $detail_stmt = $db->prepare("SELECT {$tinfo['fields']} FROM {$tinfo['table']} WHERE id IN ($ph)");
            $detail_stmt->execute($pids);
            $details = [];
            foreach ($detail_stmt->fetchAll(PDO::FETCH_ASSOC) as $d) {
                $details[$d['id']] = $d;
            }

            foreach ($items as $item) {
                $detail = $details[$item['product_id']] ?? null;
                if (!$detail) continue;

                $local_price = convert_usd_to_local((float)$item['dealer_price'], $d_cc);
                $products[] = [
                    'dp_id'        => (int)$item['dp_id'],
                    'product_id'   => (int)$item['product_id'],
                    'type'         => $ptype,
                    'name'         => $detail['name'] ?? '',
                    'brand'        => $detail['brand'] ?? '',
                    'spec'         => $detail['spec'] ?? '',
                    'sub_type'     => $detail['type'] ?? '',
                    'image'        => !empty($detail['image_path']) ? get_image_url($detail['image_path']) : '',
                    'price'        => $currency_info['currency_symbol'] . ' ' . number_format($local_price, 0, '.', ','),
                    'price_raw'    => $local_price,
                    'stock_status' => (int)$item['stock_quantity'] > 0 ? 'in_stock' : 'out_of_stock',
                    'stock_qty'    => (int)$item['stock_quantity'],
                ];
            }
        }

        echo json_encode(['products' => $products, 'currency' => $currency_info]);
    } catch (Exception $e) {
        echo json_encode(['products' => [], 'error' => $e->getMessage()]);
    }
    exit;
}

// ─── Track visitor (only for page loads, not AJAX) ───
trackVisitor($db);

// ─── Validate dealer ID ───
$dealer_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$dealer_id || $dealer_id < 1) {
    http_response_code(404);
    $show_404 = true;
    $dealer = null;
} else {
    $stmt = $db->prepare("
        SELECT d.*, COALESCE(d.store_description, '') AS bio
        FROM dealers d
        WHERE d.id = ? AND d.status IN ('active','approved') AND d.is_live = 1
        LIMIT 1
    ");
    $stmt->execute([$dealer_id]);
    $dealer = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$dealer) {
        http_response_code(404);
        $show_404 = true;
    } else {
        $show_404 = false;
    }
}

// ─── Page Data (only if not 404) ───
$products_count = [];
$reviews = [];
$avg_rating = 0;
$total_reviews = 0;
$maps_key = '';

if (!empty($dealer)) {
    $storeName = sanitize($dealer['business_name']);
    $page_title = $storeName . ' — Solar Store';
    $page_description = "$storeName - Buy solar products. " . ($dealer['city'] ?? '') . ", " . ($dealer['country'] ?? '') . ". Authorized solar dealer.";
    $maps_key = get_system_setting('google_maps_api_key', '');
    $dealer_currency = get_country_currency_info($dealer['country_code'] ?? 'US');

    // Product counts by type
    $cnt_stmt = $db->prepare("
        SELECT dp.product_type, COUNT(*) AS cnt
        FROM dealer_products dp
        WHERE dp.dealer_id = ? AND dp.is_active = 1
        AND (
            (dp.product_type = 'inverter' AND EXISTS (SELECT 1 FROM inverters WHERE id = dp.product_id)) OR
            (dp.product_type = 'battery' AND EXISTS (SELECT 1 FROM batteries WHERE id = dp.product_id)) OR
            (dp.product_type = 'panel' AND EXISTS (SELECT 1 FROM panels WHERE id = dp.product_id)) OR
            (dp.product_type = 'installation_appliance' AND EXISTS (SELECT 1 FROM installation_appliances WHERE id = dp.product_id))
        )
        GROUP BY dp.product_type
    ");
    $cnt_stmt->execute([$dealer_id]);
    foreach ($cnt_stmt->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $products_count[$c['product_type']] = (int)$c['cnt'];
    }
    $total_products = array_sum($products_count);

    // Reviews (approved only)
    try {
        $rev_stmt = $db->prepare("
            SELECT dr.rating, dr.review_text, dr.created_at,
                   COALESCE(c.name, 'Customer') AS customer_name,
                   c.avatar_url
            FROM dealer_reviews dr
            LEFT JOIN customers c ON c.id = dr.customer_id
            WHERE dr.dealer_id = ? AND dr.status = 'approved'
            ORDER BY dr.created_at DESC
            LIMIT 50
        ");
        $rev_stmt->execute([$dealer_id]);
        $reviews = $rev_stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $reviews = [];
    }

    $avg_rating = round(floatval($dealer['avg_rating'] ?? 0), 1);
    $total_reviews = (int)($dealer['total_reviews'] ?? 0);
} else {
    $page_title = 'Store Not Found';
}

// CSRF token for the installation form
$csrf_token = generate_csrf_token();
$current_page = 'store-detail';

$page_extra_head = '<link rel="stylesheet" href="' . BASE_URL . 'assets/vendor/leaflet/leaflet.css"/>';
require_once 'includes/header.php';
?>
<style>
/* ═══════════════════════════════════════════════
   Store Detail — Page-Specific Styles
   ═══════════════════════════════════════════════ */

/* ─── 404 Page ─── */
.sd-404 {
    text-align: center; padding: 120px 24px;
    max-width: 500px; margin: 0 auto;
}
.sd-404 h1 { font-size: 4rem; font-weight: 800; color: #CBD5E1; margin-bottom: 8px; }
.sd-404 h2 { font-size: 1.4rem; font-weight: 700; color: #0F172A; margin-bottom: 12px; }
.sd-404 p { color: #64748B; margin-bottom: 24px; }
.sd-btn {
    display: inline-flex; align-items: center; gap: 8px;
    padding: 12px 24px; border-radius: 10px;
    font-size: 0.9rem; font-weight: 600; font-family: inherit;
    cursor: pointer; border: none; transition: all 0.2s;
    text-decoration: none;
}
.sd-btn-primary { background: #1565C0; color: #fff; }
.sd-btn-primary:hover { background: #0D47A1; text-decoration: none; }
.sd-btn-amber { background: #F59E0B; color: #fff; }
.sd-btn-amber:hover { background: #D97706; text-decoration: none; }
.sd-btn-outline {
    background: #fff; color: #0F172A; border: 1.5px solid #E2E8F0;
}
.sd-btn-outline:hover { border-color: #1565C0; color: #1565C0; text-decoration: none; }

/* ─── Hero Section ─── */
.sd-hero {
    background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
    padding: 48px 24px 40px;
}
.sd-hero-inner {
    max-width: 1200px; margin: 0 auto;
    display: grid; grid-template-columns: 1fr 320px; gap: 40px;
    align-items: start;
}
.sd-hero-left { display: flex; flex-direction: column; gap: 16px; }
.sd-hero-top { display: flex; align-items: center; gap: 20px; }
.sd-dealer-logo {
    width: 80px; height: 80px; border-radius: 16px; object-fit: cover;
    border: 3px solid rgba(255,255,255,0.15); background: #1E293B;
    flex-shrink: 0;
}
.sd-dealer-initials {
    width: 80px; height: 80px; border-radius: 16px;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    display: flex; align-items: center; justify-content: center;
    font-size: 2rem; font-weight: 800; color: #fff;
    flex-shrink: 0;
}
.sd-hero-info h1 {
    font-size: 1.8rem; font-weight: 800; color: #fff;
    margin-bottom: 4px; letter-spacing: -0.02em;
}
.sd-hero-location {
    display: flex; align-items: center; gap: 6px;
    color: #94A3B8; font-size: 0.9rem;
}
.sd-hero-location svg { flex-shrink: 0; }
.sd-hero-rating {
    display: flex; align-items: center; gap: 8px; margin-top: 6px;
}
.sd-stars { display: flex; gap: 2px; }
.sd-star { color: #F59E0B; }
.sd-star-empty { color: #475569; }
.sd-rating-text { color: #94A3B8; font-size: 0.85rem; }
.sd-hero-meta {
    display: flex; flex-wrap: wrap; gap: 20px; margin-top: 4px;
}
.sd-meta-item {
    display: flex; align-items: center; gap: 8px;
    color: #CBD5E1; font-size: 0.875rem;
}
.sd-meta-item svg { color: #F59E0B; flex-shrink: 0; }
.sd-meta-item a { color: #CBD5E1; }
.sd-meta-item a:hover { color: #F59E0B; text-decoration: none; }
.sd-hero-desc {
    color: #94A3B8; font-size: 0.9rem; line-height: 1.7;
    max-width: 650px;
}

/* Map embed */
.sd-hero-map {
    border-radius: 14px; overflow: hidden;
    border: 2px solid rgba(255,255,255,0.1);
    height: 220px; background: #1E293B;
}
.sd-hero-map iframe, .sd-hero-map img {
    width: 100%; height: 100%; border: 0; display: block;
}
.sd-hero-map-placeholder {
    width: 100%; height: 100%; display: flex; align-items: center; justify-content: center;
    color: #475569; font-size: 0.85rem; flex-direction: column; gap: 8px;
}

/* ─── Content Area ─── */
.sd-content { max-width: 1200px; margin: 0 auto; padding: 32px 24px 64px; }

/* ─── Tabs ─── */
.sd-section {
    background: #fff; border-radius: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
    margin-bottom: 28px; overflow: hidden;
}
.sd-section-header {
    padding: 24px 28px 0; border-bottom: 1px solid #E2E8F0;
}
.sd-section-title {
    font-size: 1.2rem; font-weight: 700; color: #0F172A;
    margin-bottom: 16px;
}
.sd-tabs {
    display: flex; gap: 0; overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}
.sd-tab {
    padding: 10px 18px; font-size: 0.85rem; font-weight: 500;
    color: #64748B; background: none; border: none;
    border-bottom: 2.5px solid transparent;
    cursor: pointer; white-space: nowrap; font-family: inherit;
    transition: all 0.2s;
}
.sd-tab:hover { color: #0F172A; }
.sd-tab.active {
    color: #1565C0; border-bottom-color: #1565C0; font-weight: 600;
}
.sd-tab .sd-tab-count {
    display: inline-flex; align-items: center; justify-content: center;
    min-width: 20px; height: 20px; padding: 0 6px;
    background: #F1F5F9; border-radius: 10px;
    font-size: 0.75rem; font-weight: 600; margin-left: 6px; color: #64748B;
}
.sd-tab.active .sd-tab-count {
    background: #E3F2FD; color: #1565C0;
}

/* ─── Product Grid ─── */
.sd-products-wrap { padding: 24px 28px; }
.sd-products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    gap: 18px;
}
.sd-product-card {
    background: #fff; border: 1.5px solid #E2E8F0; border-radius: 14px;
    padding: 16px; transition: all 0.2s;
    display: flex; flex-direction: column; gap: 12px;
}
.sd-product-card:hover { border-color: #1565C0; box-shadow: 0 4px 12px rgba(21,101,192,0.08); }
.sd-product-img-wrap {
    height: 140px; background: #F8FAFC; border-radius: 10px;
    display: flex; align-items: center; justify-content: center; overflow: hidden;
}
.sd-product-img-wrap img { max-height: 130px; object-fit: contain; }
.sd-product-placeholder-icon { color: #CBD5E1; }
.sd-product-name { font-size: 0.95rem; font-weight: 600; color: #0F172A; line-height: 1.4; }
.sd-product-brand { font-size: 0.8rem; color: #64748B; }
.sd-product-bottom { display: flex; align-items: center; justify-content: space-between; margin-top: auto; }
.sd-product-price { font-size: 1.05rem; font-weight: 700; color: #1565C0; }
.sd-badge {
    display: inline-flex; padding: 3px 10px; border-radius: 6px;
    font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em;
}
.sd-badge-type { background: #EDE9FE; color: #7C3AED; }
.sd-badge-stock-in { background: #DCFCE7; color: #16A34A; }
.sd-badge-stock-low { background: #FEF3C7; color: #D97706; }
.sd-badge-stock-out { background: #FEE2E2; color: #DC2626; }
.sd-product-actions { margin-top: 8px; }
.sd-add-cart-btn {
    display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px;
    background: #F59E0B; color: white; border: none; border-radius: 8px;
    font-size: 0.8rem; font-weight: 600; cursor: pointer; transition: background 0.2s;
    width: 100%; justify-content: center;
}
.sd-add-cart-btn:hover { background: #D97706; }
.sd-add-cart-btn:disabled { opacity: 0.6; cursor: not-allowed; }
.sd-out-of-stock-label {
    display: block; text-align: center; padding: 8px; font-size: 0.8rem;
    color: #94A3B8; font-weight: 500;
}
.sd-empty-state {
    text-align: center; padding: 48px 24px; color: #94A3B8;
}
.sd-empty-state svg { margin-bottom: 12px; color: #CBD5E1; }
.sd-empty-state p { font-size: 0.95rem; }

/* ─── Loading ─── */
.sd-loading {
    display: flex; align-items: center; justify-content: center;
    padding: 48px; gap: 10px; color: #94A3B8;
}
.sd-spinner {
    width: 24px; height: 24px; border: 3px solid #E2E8F0;
    border-top-color: #1565C0; border-radius: 50%;
    animation: sd-spin 0.7s linear infinite;
}
@keyframes sd-spin { to { transform: rotate(360deg); } }

/* ─── Reviews ─── */
.sd-reviews-wrap { padding: 24px 28px; }
.sd-reviews-summary {
    display: flex; align-items: center; gap: 20px;
    padding-bottom: 20px; border-bottom: 1px solid #F1F5F9;
    margin-bottom: 20px;
}
.sd-reviews-big-rating {
    font-size: 3rem; font-weight: 800; color: #0F172A; line-height: 1;
}
.sd-reviews-big-stars { display: flex; gap: 2px; margin-top: 4px; }
.sd-reviews-count-text { font-size: 0.85rem; color: #64748B; margin-top: 2px; }
.sd-review-card {
    padding: 18px 0; border-bottom: 1px solid #F1F5F9;
}
.sd-review-card:last-child { border-bottom: none; }
.sd-review-header { display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }
.sd-review-avatar {
    width: 38px; height: 38px; border-radius: 50%;
    background: #E3F2FD; color: #1565C0; display: flex;
    align-items: center; justify-content: center;
    font-weight: 700; font-size: 0.9rem; flex-shrink: 0; overflow: hidden;
}
.sd-review-avatar img { width: 100%; height: 100%; object-fit: cover; }
.sd-review-name { font-weight: 600; font-size: 0.9rem; color: #0F172A; }
.sd-review-date { font-size: 0.8rem; color: #94A3B8; }
.sd-review-stars { display: flex; gap: 1px; margin-bottom: 6px; }
.sd-review-text { font-size: 0.9rem; color: #475569; line-height: 1.7; }

/* ─── Installation Request ─── */
.sd-install-section {
    background: linear-gradient(135deg, #0F172A, #1E293B);
    border-radius: 16px; padding: 40px 36px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.12);
    margin-bottom: 28px; color: #fff;
}
.sd-install-section h2 {
    font-size: 1.4rem; font-weight: 800; margin-bottom: 8px;
    display: flex; align-items: center; gap: 10px;
}
.sd-install-section h2 svg { color: #F59E0B; }
.sd-install-desc { color: #94A3B8; font-size: 0.9rem; margin-bottom: 24px; line-height: 1.6; }
.sd-install-form { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.sd-form-group { display: flex; flex-direction: column; gap: 6px; }
.sd-form-group.full { grid-column: 1 / -1; }
.sd-form-label { font-size: 0.8rem; font-weight: 600; color: #CBD5E1; }
.sd-form-input, .sd-form-select, .sd-form-textarea {
    padding: 12px 14px; border-radius: 10px;
    border: 1.5px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.07);
    color: #fff; font-size: 0.9rem; font-family: inherit;
    transition: border-color 0.2s, background 0.2s;
}
.sd-form-input::placeholder, .sd-form-textarea::placeholder { color: #64748B; }
.sd-form-input:focus, .sd-form-select:focus, .sd-form-textarea:focus {
    outline: none; border-color: #F59E0B; background: rgba(255,255,255,0.1);
}
.sd-form-select option { background: #1E293B; color: #fff; }
.sd-form-textarea { resize: vertical; min-height: 90px; }
.sd-install-submit {
    grid-column: 1 / -1; margin-top: 4px;
    display: flex; justify-content: flex-start;
}

/* ─── Toast ─── */
.sd-toast {
    position: fixed; bottom: 24px; right: 24px; z-index: 9999;
    max-width: 380px; padding: 16px 20px;
    border-radius: 12px; font-size: 0.9rem; font-weight: 500;
    box-shadow: 0 8px 30px rgba(0,0,0,0.15);
    transform: translateY(120%); opacity: 0;
    transition: all 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
    font-family: 'Inter', sans-serif;
}
.sd-toast.show { transform: translateY(0); opacity: 1; }
.sd-toast-success { background: #059669; color: #fff; }
.sd-toast-error { background: #DC2626; color: #fff; }

/* ─── Responsive ─── */
@media (max-width: 900px) {
    .sd-hero-inner { grid-template-columns: 1fr; }
    .sd-hero-map { height: 180px; }
}
@media (max-width: 640px) {
    .sd-hero { padding: 28px 16px 24px; }
    .sd-hero-info h1 { font-size: 1.35rem; }
    .sd-dealer-logo, .sd-dealer-initials { width: 60px; height: 60px; font-size: 1.5rem; border-radius: 12px; }
    .sd-hero-meta { gap: 12px; }
    .sd-products-grid { grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 12px; }
    .sd-section-header { padding: 18px 18px 0; }
    .sd-products-wrap, .sd-reviews-wrap { padding: 18px; }
    .sd-install-section { padding: 28px 20px; }
    .sd-install-form { grid-template-columns: 1fr; }
    .sd-content { padding: 20px 16px 48px; }
}
</style>

<?php if (!empty($show_404)): ?>
<!-- ═══ 404 ═══ -->
<div class="sd-404">
    <h1>404</h1>
    <h2>Store Not Found</h2>
    <p>The store you are looking for does not exist, has been deactivated, or the link is incorrect.</p>
    <a href="<?= BASE_URL ?>stores.php" class="sd-btn sd-btn-primary">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
        Browse Stores
    </a>
</div>

<?php else: ?>
<!-- ═══ Hero ═══ -->
<section class="sd-hero">
    <div class="sd-hero-inner">
        <div class="sd-hero-left">
            <div class="sd-hero-top">
                <?php if (!empty($dealer['logo_path'])): ?>
                    <img class="sd-dealer-logo" src="<?= sanitize(get_image_url($dealer['logo_path'])) ?>" alt="<?= sanitize($dealer['business_name']) ?>">
                <?php else: ?>
                    <div class="sd-dealer-initials"><?= strtoupper(mb_substr($dealer['business_name'], 0, 1)) ?></div>
                <?php endif; ?>
                <div class="sd-hero-info">
                    <h1><?= sanitize($dealer['business_name']) ?></h1>
                    <div class="sd-hero-location">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <?= sanitize(trim(($dealer['city'] ?? '') . ', ' . ($dealer['country_code'] ?? ''), ', ')) ?>
                    </div>
                    <div class="sd-hero-rating">
                        <div class="sd-stars">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <?php if ($i <= round($avg_rating)): ?>
                                    <svg class="sd-star" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                <?php else: ?>
                                    <svg class="sd-star-empty" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                        <span class="sd-rating-text"><?= $avg_rating ?> (<?= $total_reviews ?> review<?= $total_reviews !== 1 ? 's' : '' ?>)</span>
                    </div>
                </div>
            </div>

            <!-- Meta info -->
            <div class="sd-hero-meta">
                <?php if (!empty($dealer['phone'])): ?>
                <div class="sd-meta-item">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                    <a href="tel:<?= sanitize($dealer['phone']) ?>"><?= sanitize($dealer['phone']) ?></a>
                </div>
                <?php endif; ?>
                <?php if (!empty($dealer['address'])): ?>
                <div class="sd-meta-item">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                    <?= sanitize($dealer['address']) ?>
                </div>
                <?php endif; ?>
                <?php if (!empty($dealer['email'])): ?>
                <div class="sd-meta-item">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    <a href="mailto:<?= sanitize($dealer['email']) ?>"><?= sanitize($dealer['email']) ?></a>
                </div>
                <?php endif; ?>
                <div class="sd-meta-item">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    Joined <?= date('M Y', strtotime($dealer['created_at'] ?? 'now')) ?>
                </div>
            </div>

            <?php if (!empty($dealer['bio'])): ?>
            <p class="sd-hero-desc"><?= nl2br(sanitize($dealer['bio'])) ?></p>
            <?php endif; ?>
        </div>

        <!-- Map -->
        <div class="sd-hero-map" id="sd-map-container">
            <?php
            $lat = floatval($dealer['latitude'] ?? 0);
            $lng = floatval($dealer['longitude'] ?? 0);
            if ($lat && $lng):
            ?>
                <div id="sd-leaflet-map" style="width:100%;height:100%;min-height:220px;"></div>
            <?php else: ?>
                <div class="sd-hero-map-placeholder">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <span>Location not available</span>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- ═══ Main Content ═══ -->
<div class="sd-content">

    <!-- ─── Products Section ─── -->
    <div class="sd-section" id="products-section">
        <div class="sd-section-header">
            <h2 class="sd-section-title">Products</h2>
            <div class="sd-tabs" id="product-tabs">
                <button class="sd-tab active" data-type="all">
                    All Products<span class="sd-tab-count"><?= $total_products ?></span>
                </button>
                <button class="sd-tab" data-type="inverter">
                    Inverters<span class="sd-tab-count"><?= $products_count['inverter'] ?? 0 ?></span>
                </button>
                <button class="sd-tab" data-type="battery">
                    Batteries<span class="sd-tab-count"><?= $products_count['battery'] ?? 0 ?></span>
                </button>
                <button class="sd-tab" data-type="panel">
                    Panels<span class="sd-tab-count"><?= $products_count['panel'] ?? 0 ?></span>
                </button>
                <button class="sd-tab" data-type="installation_appliance">
                    Installation Items<span class="sd-tab-count"><?= $products_count['installation_appliance'] ?? 0 ?></span>
                </button>
            </div>
        </div>
        <div class="sd-products-wrap" id="products-container">
            <div class="sd-loading" id="products-loading">
                <div class="sd-spinner"></div>
                <span>Loading products...</span>
            </div>
        </div>
    </div>

    <!-- ─── Reviews Section ─── -->
    <div class="sd-section" id="reviews-section">
        <div class="sd-section-header" style="border-bottom: none;">
            <h2 class="sd-section-title">Customer Reviews</h2>
        </div>
        <div class="sd-reviews-wrap">
            <?php if (!empty($reviews)): ?>
                <!-- Summary -->
                <div class="sd-reviews-summary">
                    <div>
                        <div class="sd-reviews-big-rating"><?= $avg_rating ?></div>
                        <div class="sd-reviews-big-stars">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <?php if ($i <= round($avg_rating)): ?>
                                    <svg class="sd-star" width="18" height="18" viewBox="0 0 24 24" fill="#F59E0B"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                <?php else: ?>
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="#CBD5E1"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                        <div class="sd-reviews-count-text"><?= $total_reviews ?> review<?= $total_reviews !== 1 ? 's' : '' ?></div>
                    </div>
                </div>

                <!-- Review Cards -->
                <?php foreach ($reviews as $rev): ?>
                <div class="sd-review-card">
                    <div class="sd-review-header">
                        <div class="sd-review-avatar">
                            <?php if (!empty($rev['avatar_url'])): ?>
                                <img src="<?= sanitize($rev['avatar_url']) ?>" alt="">
                            <?php else: ?>
                                <?= strtoupper(mb_substr($rev['customer_name'], 0, 1)) ?>
                            <?php endif; ?>
                        </div>
                        <div>
                            <div class="sd-review-name"><?= sanitize($rev['customer_name']) ?></div>
                            <div class="sd-review-date"><?= date('M j, Y', strtotime($rev['created_at'])) ?></div>
                        </div>
                    </div>
                    <div class="sd-review-stars">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <?php if ($i <= (int)$rev['rating']): ?>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="#F59E0B"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                            <?php else: ?>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="#CBD5E1"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <?php if (!empty($rev['review_text'])): ?>
                    <p class="sd-review-text"><?= nl2br(sanitize($rev['review_text'])) ?></p>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="sd-empty-state">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                    <p>No reviews yet. Be the first to share your experience!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ─── Installation Request ─── -->
    <div class="sd-install-section" id="request-installation">
        <h2>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
            Need Solar Installation?
        </h2>
        <p class="sd-install-desc">
            Submit your installation request and <?= sanitize($dealer['business_name']) ?> will get back to you with a customized quote.
            Fill in the form below and the dealer will contact you directly.
        </p>
        <form id="install-form" class="sd-install-form" novalidate>
            <input type="hidden" name="csrf_token" value="<?= sanitize($csrf_token) ?>">
            <input type="hidden" name="action" value="submit_installation_request">
            <input type="hidden" name="dealer_id" value="<?= (int)$dealer_id ?>">

            <div class="sd-form-group">
                <label class="sd-form-label">Full Name *</label>
                <input type="text" name="customer_name" class="sd-form-input" placeholder="Your name" required maxlength="150">
            </div>
            <div class="sd-form-group">
                <label class="sd-form-label">Phone Number *</label>
                <input type="tel" name="customer_phone" class="sd-form-input" placeholder="+1 234 567 8900" required maxlength="30">
            </div>
            <div class="sd-form-group">
                <label class="sd-form-label">Email (optional)</label>
                <input type="email" name="customer_email" class="sd-form-input" placeholder="you@example.com" maxlength="255">
            </div>
            <div class="sd-form-group">
                <label class="sd-form-label">System Size</label>
                <select name="system_size" class="sd-form-select">
                    <option value="">Select size...</option>
                    <option value="3kW">3 kW</option>
                    <option value="5kW">5 kW</option>
                    <option value="10kW">10 kW</option>
                    <option value="15kW">15 kW</option>
                    <option value="20kW">20 kW</option>
                    <option value="Custom">Custom</option>
                </select>
            </div>
            <div class="sd-form-group full">
                <label class="sd-form-label">Message / Details</label>
                <textarea name="message" class="sd-form-textarea" placeholder="Describe your solar needs, roof type, monthly electricity bill, etc." maxlength="2000"></textarea>
            </div>
            <div class="sd-install-submit">
                <button type="submit" class="sd-btn sd-btn-amber" id="install-submit-btn">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                    Submit Request
                </button>
            </div>
        </form>
    </div>

</div><!-- .sd-content -->

<!-- Toast container -->
<div id="sd-toast" class="sd-toast"></div>

<?php endif; ?>

<script>
(function() {
    'use strict';

    <?php if (empty($show_404)): ?>

    var dealerId = <?= (int)$dealer_id ?>;
    var currentType = 'all';

    // ─── Product type labels ───
    var typeLabels = {
        'inverter': 'Inverter',
        'battery': 'Battery',
        'panel': 'Panel',
        'installation_appliance': 'Appliance'
    };

    // ─── Toast ───
    function showToast(msg, type) {
        var t = document.getElementById('sd-toast');
        t.textContent = msg;
        t.className = 'sd-toast sd-toast-' + (type || 'success');
        // Force reflow
        void t.offsetWidth;
        t.classList.add('show');
        setTimeout(function() { t.classList.remove('show'); }, 4500);
    }

    // ─── Stock badge ───
    function stockBadge(status, qty) {
        if (status === 'out_of_stock' || qty <= 0) {
            return '<span class="sd-badge sd-badge-stock-out">Out of Stock</span>';
        }
        if (status === 'low_stock' || (qty > 0 && qty <= 5)) {
            return '<span class="sd-badge sd-badge-stock-low">Low Stock</span>';
        }
        return '<span class="sd-badge sd-badge-stock-in">In Stock</span>';
    }

    // ─── Product placeholder SVG ───
    var placeholderSVG = '<svg class="sd-product-placeholder-icon" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>';

    // ─── Load products via AJAX ───
    function loadProducts(type) {
        var container = document.getElementById('products-container');
        container.innerHTML = '<div class="sd-loading"><div class="sd-spinner"></div><span>Loading products...</span></div>';

        var url = '/solarglobal/store-detail.php?ajax=products&dealer_id=' + dealerId + '&type=' + encodeURIComponent(type);
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== 4) return;
            if (xhr.status !== 200) {
                container.innerHTML = '<div class="sd-empty-state"><p>Failed to load products. Please try again.</p></div>';
                return;
            }
            try {
                var data = JSON.parse(xhr.responseText);
                renderProducts(data.products || []);
            } catch(e) {
                container.innerHTML = '<div class="sd-empty-state"><p>Error loading products.</p></div>';
            }
        };
        xhr.send();
    }

    function renderProducts(products) {
        var container = document.getElementById('products-container');
        if (!products.length) {
            container.innerHTML = '<div class="sd-empty-state">' +
                '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>' +
                '<p>No products available in this category.</p></div>';
            return;
        }

        var html = '<div class="sd-products-grid">';
        for (var i = 0; i < products.length; i++) {
            var p = products[i];
            var imgHtml = p.image
                ? '<img src="' + escHtml(p.image) + '" alt="' + escHtml(p.name) + '" loading="lazy">'
                : placeholderSVG;
            var typeBadge = p.sub_type
                ? '<span class="sd-badge sd-badge-type">' + escHtml(p.sub_type) + '</span>'
                : (typeLabels[p.type] ? '<span class="sd-badge sd-badge-type">' + escHtml(typeLabels[p.type]) + '</span>' : '');

            var cartBtn = '';
            if (p.stock_status !== 'out_of_stock' && p.stock_qty > 0) {
                cartBtn = '<button type="button" class="sd-add-cart-btn" onclick="addToCart(' + p.product_id + ',\'' + escHtml(p.type) + '\',' + dealerId + ',this)" title="Add to Cart">' +
                    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>' +
                    ' Add to Cart</button>';
            } else {
                cartBtn = '<span class="sd-out-of-stock-label">Unavailable</span>';
            }

            html += '<div class="sd-product-card">' +
                '<div class="sd-product-img-wrap">' + imgHtml + '</div>' +
                '<div>' +
                    '<div class="sd-product-name">' + escHtml(p.name) + '</div>' +
                    '<div class="sd-product-brand">' + escHtml(p.brand) + (p.spec ? ' &middot; ' + escHtml(p.spec) : '') + '</div>' +
                '</div>' +
                '<div class="sd-product-bottom">' +
                    '<div class="sd-product-price">' + escHtml(p.price) + '</div>' +
                    '<div>' + typeBadge + ' ' + stockBadge(p.stock_status, p.stock_qty) + '</div>' +
                '</div>' +
                '<div class="sd-product-actions">' + cartBtn + '</div>' +
            '</div>';
        }
        html += '</div>';
        container.innerHTML = html;
    }

    function escHtml(s) {
        if (!s) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(s));
        return div.innerHTML;
    }

    // ─── Add to Cart ───
    window.addToCart = function(productId, productType, dealerId, btn) {
        if (btn.disabled) return;
        var origHtml = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<div class="sd-spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;vertical-align:middle;"></div> Adding...';

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'api/cart.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== 4) return;
            btn.disabled = false;
            btn.innerHTML = origHtml;
            try {
                var resp = JSON.parse(xhr.responseText);
                if (resp.success) {
                    showToast(resp.product_name + ' added to cart!', 'success');
                    // Update cart count in header if exists
                    var cartBadge = document.querySelector('.sg-cart-count, .cart-count-badge');
                    if (cartBadge && resp.cart_count !== undefined) {
                        cartBadge.textContent = resp.cart_count;
                        cartBadge.style.display = resp.cart_count > 0 ? '' : 'none';
                    }
                } else {
                    showToast(resp.error || 'Could not add to cart.', 'error');
                }
            } catch(e) {
                showToast('Error adding to cart.', 'error');
            }
        };
        xhr.send(JSON.stringify({
            action: 'add',
            product_type: productType,
            product_id: productId,
            dealer_id: dealerId,
            quantity: 1
        }));
    };

    // ─── Tab switching ───
    var tabs = document.querySelectorAll('#product-tabs .sd-tab');
    for (var i = 0; i < tabs.length; i++) {
        tabs[i].addEventListener('click', function() {
            for (var j = 0; j < tabs.length; j++) tabs[j].classList.remove('active');
            this.classList.add('active');
            currentType = this.getAttribute('data-type');
            loadProducts(currentType);
        });
    }

    // Initial load
    loadProducts('all');

    // ─── Installation Form AJAX Submit ───
    var form = document.getElementById('install-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            var btn = document.getElementById('install-submit-btn');
            var origText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<div class="sd-spinner" style="width:18px;height:18px;border-width:2px"></div> Submitting...';

            var formData = new FormData(form);
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/solarglobal/store-detail.php?id=' + dealerId, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState !== 4) return;
                btn.disabled = false;
                btn.innerHTML = origText;
                try {
                    var resp = JSON.parse(xhr.responseText);
                    if (resp.success) {
                        showToast(resp.message, 'success');
                        form.reset();
                        // Keep hidden fields
                        form.querySelector('[name="dealer_id"]').value = dealerId;
                    } else {
                        showToast(resp.message || 'Something went wrong.', 'error');
                    }
                } catch(err) {
                    showToast('An error occurred. Please try again.', 'error');
                }
            };
            xhr.send(formData);
        });
    }

    <?php endif; ?>
})();
</script>

<?php
// ─── Leaflet Map Initialization ───
$lat = floatval($dealer['latitude'] ?? 0);
$lng = floatval($dealer['longitude'] ?? 0);
if ($lat && $lng):
?>
<script src="<?= BASE_URL ?>assets/vendor/leaflet/leaflet.js"></script>
<script>
(function(){
    var mapEl = document.getElementById('sd-leaflet-map');
    if (!mapEl) { console.error('Map element #sd-leaflet-map not found'); return; }

    var lat = <?= $lat ?>, lng = <?= $lng ?>;

    function initLeafletMap() {
        if (typeof L === 'undefined') {

            setTimeout(initLeafletMap, 200);
            return;
        }

        try {
            // Ensure container has explicit dimensions
            mapEl.style.height = '100%';
            mapEl.style.minHeight = '220px';
            mapEl.style.width = '100%';

            var map = L.map(mapEl, {
                scrollWheelZoom: false,
                zoomControl: true,
                attributionControl: true
            }).setView([lat, lng], 14);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors',
                maxZoom: 18
            }).addTo(map);

            var marker = L.marker([lat, lng]).addTo(map);
            marker.bindPopup('<strong><?= addslashes(sanitize($dealer['business_name'])) ?></strong><?= !empty($dealer['city']) ? '<br>' . addslashes(sanitize($dealer['city'])) : '' ?>').openPopup();

            // Aggressively fix map size
            map.invalidateSize();
            setTimeout(function(){ map.invalidateSize(); }, 100);
            setTimeout(function(){ map.invalidateSize(); }, 300);
            setTimeout(function(){ map.invalidateSize(); }, 600);
            setTimeout(function(){ map.invalidateSize(); }, 1500);

        } catch(e) {
            console.error('🗺️ Map init error:', e);
            mapEl.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#94A3B8;font-size:0.85rem;">Map could not be loaded</div>';
        }
    }

    if (document.readyState === 'complete') {
        initLeafletMap();
    } else {
        window.addEventListener('load', initLeafletMap);
    }
})();
</script>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
