<?php
/**
 * Installer Logout
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/installer_auth.php';

installer_logout();
header('Location: /solarglobal/installer/login.php?logout=1');
exit();
