<?php
/**
 * Dealer Orders - Order management page
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';
require_once __DIR__ . '/../includes/notification_helpers.php';

set_security_headers();
require_dealer_login();
require_dealer_subscription();

$dealer    = get_dealer_profile();
$db        = getDB();
$dealer_id = (int)$dealer['id'];

$pageTitle = 'Orders';
$success   = '';
$error     = '';

/* ──────────────────────────────────────────────
   POST ACTIONS  (CSRF-protected)
────────────────────────────────────────────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Security token invalid. Please refresh and try again.';
    } else {
        $action   = $_POST['action']   ?? '';
        $order_id = (int)($_POST['order_id'] ?? 0);

        // Helper: verify this order belongs to dealer and has expected status
        $get_order = function(int $oid, string $expected_status = '') use ($db, $dealer_id): ?array {
            $stmt = $db->prepare(
                "SELECT * FROM orders WHERE id = ? AND dealer_id = ?" .
                ($expected_status !== '' ? " AND status = ?" : "")
            );
            $params = [$oid, $dealer_id];
            if ($expected_status !== '') $params[] = $expected_status;
            $stmt->execute($params);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        };

        if ($action === 'confirm_order' && $order_id) {
            $order = $get_order($order_id, 'pending');
            if ($order) {
                $pickup_deadline = date('Y-m-d H:i:s', strtotime('+24 hours'));
                $db->prepare("UPDATE orders SET status = 'confirmed', confirmed_at = NOW(), pickup_deadline = ? WHERE id = ? AND dealer_id = ?")
                   ->execute([$pickup_deadline, $order_id, $dealer_id]);
                $success = 'Order #' . htmlspecialchars($order['order_number']) . ' confirmed. Customer has 24 hours to pick up.';
                create_notification('customer', (int)$order['customer_id'], 'order_confirmed',
                    'Order Confirmed: ' . $order['order_number'],
                    'Your order has been confirmed by the dealer. Please pick up within 24 hours.',
                    '/solarglobal/customer/orders.php');
            } else {
                $error = 'Order not found or cannot be confirmed.';
            }

        } elseif ($action === 'ready_order' && $order_id) {
            $order = $get_order($order_id, 'confirmed');
            if ($order) {
                $db->prepare("UPDATE orders SET status = 'ready', ready_at = NOW() WHERE id = ? AND dealer_id = ?")
                   ->execute([$order_id, $dealer_id]);
                $success = 'Order #' . htmlspecialchars($order['order_number']) . ' marked as ready for pickup.';
                create_notification('customer', (int)$order['customer_id'], 'order_ready',
                    'Order Ready: ' . $order['order_number'],
                    'Your order is ready for pickup! Visit the dealer to collect your items.',
                    '/solarglobal/customer/orders.php');
            } else {
                $error = 'Order not found or cannot be marked ready.';
            }

        } elseif ($action === 'pickup_order' && $order_id) {
            $order = $get_order($order_id, 'ready');
            if ($order) {
                $db->prepare("UPDATE orders SET status = 'picked_up', picked_up_at = NOW() WHERE id = ? AND dealer_id = ?")
                   ->execute([$order_id, $dealer_id]);
                $success = 'Order #' . htmlspecialchars($order['order_number']) . ' marked as picked up. Order complete!';
                create_notification('customer', (int)$order['customer_id'], 'order_picked_up',
                    'Order Complete: ' . $order['order_number'],
                    'Your order has been marked as picked up. Thank you for your purchase!',
                    '/solarglobal/customer/orders.php');
            } else {
                $error = 'Order not found or cannot be marked as picked up.';
            }

        } elseif ($action === 'cancel_order' && $order_id) {
            $cancel_reason = trim($_POST['cancel_reason'] ?? '');
            $order = $get_order($order_id);
            if ($order && !in_array($order['status'], ['picked_up', 'cancelled'])) {
                // Restore stock for each order item
                $items_stmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
                $items_stmt->execute([$order_id]);
                $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($items as $item) {
                    $db->prepare(
                        "UPDATE dealer_products
                         SET stock_quantity = stock_quantity + ?,
                             stock_status   = CASE
                                 WHEN stock_quantity + ? > 5 THEN 'in_stock'
                                 WHEN stock_quantity + ? > 0 THEN 'low_stock'
                                 ELSE 'out_of_stock'
                             END,
                             updated_at = NOW()
                         WHERE dealer_id = ? AND product_type = ? AND product_id = ?"
                    )->execute([
                        $item['quantity'],
                        $item['quantity'],
                        $item['quantity'],
                        $dealer_id,
                        $item['product_type'],
                        $item['product_id'],
                    ]);
                }

                $db->prepare(
                    "UPDATE orders SET status = 'cancelled', cancelled_at = NOW(), cancel_reason = ? WHERE id = ? AND dealer_id = ?"
                )->execute([$cancel_reason ?: null, $order_id, $dealer_id]);

                $success = 'Order #' . htmlspecialchars($order['order_number']) . ' cancelled and stock restored.';
                create_notification('customer', (int)$order['customer_id'], 'order_cancelled',
                    'Order Cancelled: ' . $order['order_number'],
                    'Your order has been cancelled by the dealer.' . ($cancel_reason ? ' Reason: ' . $cancel_reason : ''),
                    '/solarglobal/customer/orders.php');
            } else {
                $error = 'Order not found or cannot be cancelled.';
            }
        }
    }
}

/* ──────────────────────────────────────────────
   FILTERS & PAGINATION
────────────────────────────────────────────── */
$valid_statuses = ['all', 'pending', 'confirmed', 'ready', 'picked_up', 'cancelled'];
$status_filter  = $_GET['status'] ?? 'all';
if (!in_array($status_filter, $valid_statuses)) $status_filter = 'all';

$search    = trim($_GET['search'] ?? '');
$page      = max(1, (int)($_GET['page'] ?? 1));
$per_page  = 20;
$offset    = ($page - 1) * $per_page;

/* ──────────────────────────────────────────────
   STATUS COUNTS
────────────────────────────────────────────── */
$count_stmt = $db->prepare(
    "SELECT status, COUNT(*) AS cnt FROM orders WHERE dealer_id = ? GROUP BY status"
);
$count_stmt->execute([$dealer_id]);
$counts_raw = $count_stmt->fetchAll(PDO::FETCH_ASSOC);
$counts     = ['all' => 0, 'pending' => 0, 'confirmed' => 0, 'ready' => 0, 'picked_up' => 0, 'cancelled' => 0];
foreach ($counts_raw as $row) {
    if (isset($counts[$row['status']])) {
        $counts[$row['status']] += (int)$row['cnt'];
    }
    $counts['all'] += (int)$row['cnt'];
}

/* ──────────────────────────────────────────────
   BUILD QUERY
────────────────────────────────────────────── */
$where_parts  = ["o.dealer_id = :dealer_id"];
$query_params = [':dealer_id' => $dealer_id];

if ($status_filter !== 'all') {
    $where_parts[]             = "o.status = :status";
    $query_params[':status']   = $status_filter;
}

if ($search !== '') {
    $where_parts[]             = "(o.order_number LIKE :search OR c.name LIKE :search2)";
    $query_params[':search']   = '%' . $search . '%';
    $query_params[':search2']  = '%' . $search . '%';
}

$where_sql = implode(' AND ', $where_parts);

// Total count for pagination
$count_q = $db->prepare(
    "SELECT COUNT(*) FROM orders o
     LEFT JOIN customers c ON c.id = o.customer_id
     WHERE $where_sql"
);
$count_q->execute($query_params);
$total_rows  = (int)$count_q->fetchColumn();
$total_pages = max(1, (int)ceil($total_rows / $per_page));
if ($page > $total_pages) $page = $total_pages;

// Orders list
$orders_stmt = $db->prepare(
    "SELECT o.*,
            c.name  AS customer_name,
            c.email AS customer_email,
            c.phone AS customer_phone
     FROM orders o
     LEFT JOIN customers c ON c.id = o.customer_id
     WHERE $where_sql
     ORDER BY o.created_at DESC
     LIMIT :limit OFFSET :offset"
);
foreach ($query_params as $k => $v) {
    $orders_stmt->bindValue($k, $v);
}
$orders_stmt->bindValue(':limit',  $per_page, PDO::PARAM_INT);
$orders_stmt->bindValue(':offset', $offset,   PDO::PARAM_INT);
$orders_stmt->execute();
$orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);

/* ──────────────────────────────────────────────
   HELPERS
────────────────────────────────────────────── */
function order_status_badge(string $status): string {
    $map = [
        'pending'   => ['label' => 'Pending',   'bg' => '#FEF3C7', 'color' => '#92400E', 'dot' => '#F59E0B'],
        'confirmed' => ['label' => 'Confirmed',  'bg' => '#DBEAFE', 'color' => '#1E40AF', 'dot' => '#3B82F6'],
        'ready'     => ['label' => 'Ready',      'bg' => '#DCFCE7', 'color' => '#166534', 'dot' => '#16A34A'],
        'picked_up' => ['label' => 'Picked Up',  'bg' => '#F1F5F9', 'color' => '#475569', 'dot' => '#94A3B8'],
        'cancelled' => ['label' => 'Cancelled',  'bg' => '#FEE2E2', 'color' => '#991B1B', 'dot' => '#EF4444'],
    ];
    $s = $map[$status] ?? ['label' => ucfirst($status), 'bg' => '#F1F5F9', 'color' => '#475569', 'dot' => '#94A3B8'];
    return '<span class="status-badge" style="background:' . $s['bg'] . ';color:' . $s['color'] . '">'
         . '<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:' . $s['dot'] . ';margin-right:5px;vertical-align:middle"></span>'
         . htmlspecialchars($s['label']) . '</span>';
}

function deadline_urgency(?string $deadline, string $status): string {
    if (!$deadline || !in_array($status, ['confirmed', 'ready'])) return '';
    $diff = strtotime($deadline) - time();
    if ($diff < 0)      return 'overdue';
    if ($diff < 7200)   return 'urgent';
    return '';
}

$csrf_token = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - <?= sanitize($dealer['business_name']) ?> | <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        /* ── Layout ── */
        .orders-page-sub { font-size: 0.875rem; color: #64748B; }

        /* ── Alerts ── */
        .alert {
            padding: 14px 18px; border-radius: 10px; margin-bottom: 20px;
            font-size: 0.9rem; font-weight: 500; display: flex; align-items: center; gap: 10px;
        }
        .alert-success { background: #DCFCE7; color: #166534; border: 1px solid #BBF7D0; }
        .alert-error   { background: #FEE2E2; color: #991B1B; border: 1px solid #FECACA; }

        /* ── Search & Filter bar ── */
        .controls-bar {
            display: flex; gap: 14px; align-items: center; margin-bottom: 20px; flex-wrap: wrap;
        }
        .search-wrap { position: relative; flex: 1; min-width: 220px; }
        .search-wrap input {
            width: 100%; padding: 10px 16px 10px 40px; border: 1.5px solid #E2E8F0;
            border-radius: 10px; font-size: 0.875rem; background: white;
            font-family: inherit; outline: none; transition: border-color 0.2s;
        }
        .search-wrap input:focus { border-color: #F59E0B; }
        .search-wrap .s-icon {
            position: absolute; left: 13px; top: 50%; transform: translateY(-50%);
            color: #94A3B8; font-size: 1rem; pointer-events: none;
        }
        .btn-search {
            padding: 10px 20px; background: #F59E0B; color: white; border: none;
            border-radius: 10px; font-weight: 600; font-size: 0.875rem;
            cursor: pointer; font-family: inherit; transition: background 0.2s;
        }
        .btn-search:hover { background: #D97706; }
        .btn-clear {
            padding: 10px 16px; background: #F1F5F9; color: #64748B; border: 1.5px solid #E2E8F0;
            border-radius: 10px; font-size: 0.875rem; cursor: pointer; font-family: inherit;
            text-decoration: none; display: inline-flex; align-items: center;
        }
        .btn-clear:hover { background: #E2E8F0; }

        /* ── Status tabs ── */
        .status-tabs {
            display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 20px;
        }
        .tab-btn {
            padding: 8px 16px; border-radius: 8px; border: 1.5px solid #E2E8F0;
            font-size: 0.8125rem; font-weight: 600; cursor: pointer; background: white;
            color: #64748B; text-decoration: none; transition: all 0.2s; display: inline-flex;
            align-items: center; gap: 6px; font-family: inherit;
        }
        .tab-btn:hover  { border-color: #F59E0B; color: #92400E; background: #FFFBEB; }
        .tab-btn.active { border-color: #F59E0B; background: #FEF3C7; color: #92400E; }
        .tab-count {
            background: #E2E8F0; color: #475569; border-radius: 10px;
            padding: 1px 7px; font-size: 0.6875rem; font-weight: 700;
        }
        .tab-btn.active .tab-count { background: #FDE68A; color: #92400E; }

        /* ── Table ── */
        .card {
            background: white; border-radius: 14px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0; overflow: hidden;
        }
        .card-header {
            padding: 18px 24px; border-bottom: 1px solid #F1F5F9;
            display: flex; align-items: center; justify-content: space-between;
        }
        .card-header h3 { font-size: 1rem; font-weight: 700; color: #1E293B; }
        .card-header .total-label { font-size: 0.8125rem; color: #64748B; }

        .orders-table { width: 100%; border-collapse: collapse; }
        .orders-table th {
            padding: 12px 16px; text-align: left; font-size: 0.75rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.5px; color: #64748B;
            background: #F8FAFC; border-bottom: 1px solid #E2E8F0;
        }
        .orders-table td {
            padding: 14px 16px; font-size: 0.875rem; color: #1E293B;
            border-bottom: 1px solid #F1F5F9; vertical-align: middle;
        }
        .orders-table tbody tr:last-child td { border-bottom: none; }
        .orders-table tbody tr:hover { background: #F8FAFC; }
        .orders-table tbody tr.row-overdue { background: #FEF2F2; }
        .orders-table tbody tr.row-overdue:hover { background: #FEE2E2; }
        .orders-table tbody tr.row-urgent { background: #FFFBEB; }
        .orders-table tbody tr.row-urgent:hover { background: #FEF3C7; }

        .order-number { font-weight: 700; color: #1E293B; }
        .customer-name { font-weight: 500; }
        .customer-email { font-size: 0.8125rem; color: #64748B; }
        .amount { font-weight: 700; color: #1E293B; }
        .date-cell { font-size: 0.8125rem; color: #64748B; white-space: nowrap; }

        .status-badge {
            display: inline-flex; align-items: center; padding: 4px 10px;
            border-radius: 20px; font-size: 0.75rem; font-weight: 600; white-space: nowrap;
        }

        .deadline-warn {
            display: inline-block; font-size: 0.75rem; margin-top: 3px;
            padding: 2px 8px; border-radius: 4px; font-weight: 600;
        }
        .deadline-warn.overdue { background: #FEE2E2; color: #991B1B; }
        .deadline-warn.urgent  { background: #FEF3C7; color: #92400E; }

        /* ── Action buttons ── */
        .actions-cell { white-space: nowrap; }
        .btn-action {
            padding: 6px 12px; border-radius: 7px; border: none; font-size: 0.75rem;
            font-weight: 600; cursor: pointer; font-family: inherit; transition: all 0.2s;
            margin-right: 4px; text-decoration: none; display: inline-block;
        }
        .btn-confirm { background: #DBEAFE; color: #1E40AF; }
        .btn-confirm:hover { background: #BFDBFE; }
        .btn-ready   { background: #D1FAE5; color: #065F46; }
        .btn-ready:hover { background: #A7F3D0; }
        .btn-pickup  { background: #E0E7FF; color: #3730A3; }
        .btn-pickup:hover { background: #C7D2FE; }
        .btn-cancel  { background: #FEE2E2; color: #991B1B; }
        .btn-cancel:hover { background: #FECACA; }
        .btn-detail  { background: #F1F5F9; color: #475569; }
        .btn-detail:hover { background: #E2E8F0; }

        /* ── Empty state ── */
        .empty-state {
            text-align: center; padding: 60px 20px;
        }
        .empty-state .es-icon { font-size: 3rem; margin-bottom: 12px; }
        .empty-state h4 { font-size: 1.125rem; font-weight: 700; color: #1E293B; margin-bottom: 6px; }
        .empty-state p  { font-size: 0.875rem; color: #64748B; }

        /* ── Pagination ── */
        .pagination {
            display: flex; justify-content: center; align-items: center; gap: 6px;
            padding: 20px;
        }
        .pg-btn {
            padding: 8px 14px; border-radius: 8px; border: 1.5px solid #E2E8F0;
            background: white; color: #475569; font-size: 0.875rem; font-weight: 500;
            text-decoration: none; display: inline-block; transition: all 0.2s;
        }
        .pg-btn:hover   { border-color: #F59E0B; color: #92400E; background: #FFFBEB; }
        .pg-btn.active  { background: #F59E0B; border-color: #F59E0B; color: white; }
        .pg-btn.disabled { opacity: 0.4; pointer-events: none; }
        .pg-info { font-size: 0.875rem; color: #64748B; padding: 0 10px; }

        /* ── Modal ── */
        .modal-backdrop {
            display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55);
            z-index: 200; justify-content: center; align-items: flex-start;
            padding: 40px 16px; overflow-y: auto;
        }
        .modal-backdrop.open { display: flex; }
        .modal {
            background: white; border-radius: 16px; width: 100%; max-width: 680px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.2); animation: slideUp 0.25s ease;
            flex-shrink: 0;
        }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .modal-header {
            display: flex; justify-content: space-between; align-items: center;
            padding: 20px 24px; border-bottom: 1px solid #E2E8F0;
        }
        .modal-header h3 { font-size: 1.125rem; font-weight: 700; color: #1E293B; }
        .modal-close {
            background: #F1F5F9; border: none; width: 32px; height: 32px; border-radius: 8px;
            cursor: pointer; font-size: 1.125rem; color: #64748B; display: flex;
            align-items: center; justify-content: center; transition: background 0.2s;
        }
        .modal-close:hover { background: #E2E8F0; }
        .modal-body  { padding: 24px; }
        .modal-footer { padding: 16px 24px; border-top: 1px solid #E2E8F0; display: flex; justify-content: flex-end; }

        .modal-section { margin-bottom: 24px; }
        .modal-section h4 {
            font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px;
            color: #94A3B8; font-weight: 600; margin-bottom: 12px;
        }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .info-item .label { font-size: 0.8125rem; color: #64748B; margin-bottom: 2px; }
        .info-item .value { font-size: 0.9375rem; font-weight: 600; color: #1E293B; }

        .items-table { width: 100%; border-collapse: collapse; }
        .items-table th {
            font-size: 0.75rem; font-weight: 600; text-transform: uppercase;
            color: #94A3B8; padding: 8px 12px; text-align: left;
            background: #F8FAFC; border-bottom: 1px solid #E2E8F0;
        }
        .items-table td { padding: 10px 12px; font-size: 0.875rem; border-bottom: 1px solid #F1F5F9; }
        .items-table tr:last-child td { border-bottom: none; }
        .items-table .total-row td { font-weight: 700; color: #1E293B; background: #F8FAFC; }

        .timeline { list-style: none; }
        .timeline li {
            display: flex; gap: 12px; padding-bottom: 16px; position: relative;
        }
        .timeline li:last-child { padding-bottom: 0; }
        .timeline li:not(:last-child)::before {
            content: ''; position: absolute; left: 11px; top: 24px; bottom: 0;
            width: 2px; background: #E2E8F0;
        }
        .tl-dot {
            width: 24px; height: 24px; border-radius: 50%; flex-shrink: 0;
            display: flex; align-items: center; justify-content: center; font-size: 0.75rem;
        }
        .tl-dot.done    { background: #DCFCE7; color: #16A34A; }
        .tl-dot.pending { background: #F1F5F9; color: #94A3B8; border: 2px dashed #CBD5E1; }
        .tl-dot.cancel  { background: #FEE2E2; color: #EF4444; }
        .tl-text .tl-label { font-size: 0.875rem; font-weight: 600; color: #1E293B; }
        .tl-text .tl-time  { font-size: 0.8125rem; color: #94A3B8; margin-top: 1px; }

        /* ── Cancel modal ── */
        .cancel-modal textarea {
            width: 100%; padding: 12px; border: 1.5px solid #E2E8F0; border-radius: 8px;
            font-family: inherit; font-size: 0.875rem; resize: vertical; min-height: 90px;
            outline: none; transition: border-color 0.2s; margin-top: 10px;
        }
        .cancel-modal textarea:focus { border-color: #F59E0B; }
        .cancel-modal p { font-size: 0.875rem; color: #374151; }

        .btn-primary {
            padding: 10px 22px; background: #F59E0B; color: white; border: none;
            border-radius: 9px; font-weight: 600; font-size: 0.875rem; cursor: pointer;
            font-family: inherit; transition: background 0.2s;
        }
        .btn-primary:hover { background: #D97706; }
        .btn-secondary {
            padding: 10px 18px; background: #F1F5F9; color: #475569; border: 1.5px solid #E2E8F0;
            border-radius: 9px; font-weight: 600; font-size: 0.875rem; cursor: pointer;
            font-family: inherit; margin-right: 8px; transition: background 0.2s;
        }
        .btn-secondary:hover { background: #E2E8F0; }
        .btn-danger {
            padding: 10px 22px; background: #EF4444; color: white; border: none;
            border-radius: 9px; font-weight: 600; font-size: 0.875rem; cursor: pointer;
            font-family: inherit; transition: background 0.2s;
        }
        .btn-danger:hover { background: #DC2626; }

        /* ── Responsive ── */
        @media (max-width: 960px) {
            th.hide-sm, td.hide-sm { display: none; }
        }
        @media (max-width: 600px) {
            .info-grid { grid-template-columns: 1fr; }
            .controls-bar { flex-direction: column; align-items: stretch; }
        }
    </style>
</head>
<body>
<?php $current_dealer_page = 'orders'; $pending_orders_count = $counts['pending']; include __DIR__ . '/includes/sidebar.php'; ?>

<main class="dlr-main-content">
    <div class="dlr-page-header">
        <div class="dlr-page-header-left">
            <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
            <div>
                <h1>&#128203; Orders</h1>
                <div class="orders-page-sub">Manage and process customer orders</div>
            </div>
        </div>
        <div></div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success">&#10003; <?= $success ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error">&#9888; <?= sanitize($error) ?></div>
    <?php endif; ?>

    <!-- Status Tabs -->
    <div class="status-tabs">
        <?php
        $tab_labels = [
            'all'       => 'All Orders',
            'pending'   => 'Pending',
            'confirmed' => 'Confirmed',
            'ready'     => 'Ready',
            'picked_up' => 'Picked Up',
            'cancelled' => 'Cancelled',
        ];
        foreach ($tab_labels as $st => $lbl):
            $is_active = ($status_filter === $st);
            $url_params = http_build_query(array_filter([
                'status' => $st === 'all' ? '' : $st,
                'search' => $search,
            ]));
            $href = 'orders.php' . ($url_params ? '?' . $url_params : '');
        ?>
        <a href="<?= $href ?>" class="tab-btn <?= $is_active ? 'active' : '' ?>">
            <?= $lbl ?>
            <span class="tab-count"><?= $counts[$st] ?></span>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- Search bar -->
    <form method="GET" action="orders.php">
        <?php if ($status_filter !== 'all'): ?>
            <input type="hidden" name="status" value="<?= sanitize($status_filter) ?>">
        <?php endif; ?>
        <div class="controls-bar">
            <div class="search-wrap">
                <span class="s-icon">&#128269;</span>
                <input type="text" name="search" placeholder="Search by order number or customer name..."
                       value="<?= sanitize($search) ?>">
            </div>
            <button type="submit" class="btn-search">Search</button>
            <?php if ($search): ?>
                <a href="orders.php<?= $status_filter !== 'all' ? '?status=' . urlencode($status_filter) : '' ?>"
                   class="btn-clear">&#10005; Clear</a>
            <?php endif; ?>
        </div>
    </form>

    <!-- Orders Table -->
    <div class="card">
        <div class="card-header">
            <h3>Orders</h3>
            <span class="total-label"><?= $total_rows ?> order<?= $total_rows !== 1 ? 's' : '' ?> found</span>
        </div>

        <?php if (empty($orders)): ?>
            <div class="empty-state">
                <div class="es-icon">&#128203;</div>
                <h4>No orders found</h4>
                <p><?= $search ? 'Try adjusting your search query.' : 'Orders placed by customers will appear here.' ?></p>
            </div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="orders-table">
            <thead>
                <tr>
                    <th>Order #</th>
                    <th>Customer</th>
                    <th class="hide-sm">Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th class="hide-sm">Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($orders as $order):
                $urgency = deadline_urgency($order['pickup_deadline'] ?? null, $order['status']);
                $row_class = $urgency === 'overdue' ? 'row-overdue' : ($urgency === 'urgent' ? 'row-urgent' : '');
            ?>
                <tr class="<?= $row_class ?>" data-order-id="<?= (int)$order['id'] ?>">
                    <td>
                        <div class="order-number"><?= sanitize($order['order_number']) ?></div>
                    </td>
                    <td>
                        <div class="customer-name"><?= sanitize($order['customer_name'] ?? 'N/A') ?></div>
                        <div class="customer-email"><?= sanitize($order['customer_email'] ?? '') ?></div>
                    </td>
                    <td class="hide-sm"><?= (int)$order['item_count'] ?> item<?= (int)$order['item_count'] !== 1 ? 's' : '' ?></td>
                    <td>
                        <span class="amount"><?= sanitize($order['currency'] ?? 'USD') ?> <?= format_price($order['total_amount']) ?></span>
                    </td>
                    <td>
                        <?= order_status_badge($order['status']) ?>
                        <?php if ($urgency && !empty($order['pickup_deadline'])): ?>
                            <br>
                            <?php
                            $diff = strtotime($order['pickup_deadline']) - time();
                            if ($diff < 0) {
                                echo '<span class="deadline-warn overdue">Overdue</span>';
                            } else {
                                $hrs = floor($diff / 3600);
                                $mins = floor(($diff % 3600) / 60);
                                echo '<span class="deadline-warn urgent">' . $hrs . 'h ' . $mins . 'm left</span>';
                            }
                            ?>
                        <?php endif; ?>
                    </td>
                    <td class="date-cell hide-sm"><?= date('M d, Y', strtotime($order['created_at'])) ?><br><?= date('H:i', strtotime($order['created_at'])) ?></td>
                    <td class="actions-cell">
                        <!-- Detail button always shown -->
                        <button type="button" class="btn-action btn-detail"
                                onclick="openDetail(<?= (int)$order['id'] ?>)">View</button>

                        <?php if ($order['status'] === 'pending'): ?>
                            <button type="button" class="btn-action btn-confirm"
                                    onclick="submitAction('confirm_order', <?= (int)$order['id'] ?>, '<?= addslashes($order['order_number']) ?>')">
                                Confirm
                            </button>
                        <?php elseif ($order['status'] === 'confirmed'): ?>
                            <button type="button" class="btn-action btn-ready"
                                    onclick="submitAction('ready_order', <?= (int)$order['id'] ?>, '<?= addslashes($order['order_number']) ?>')">
                                Mark Ready
                            </button>
                        <?php elseif ($order['status'] === 'ready'): ?>
                            <button type="button" class="btn-action btn-pickup"
                                    onclick="submitAction('pickup_order', <?= (int)$order['id'] ?>, '<?= addslashes($order['order_number']) ?>')">
                                Picked Up
                            </button>
                        <?php endif; ?>

                        <?php if (!in_array($order['status'], ['picked_up', 'cancelled'])): ?>
                            <button type="button" class="btn-action btn-cancel"
                                    onclick="openCancel(<?= (int)$order['id'] ?>, '<?= addslashes($order['order_number']) ?>')">
                                Cancel
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php
            $pg_base = 'orders.php?' . http_build_query(array_filter([
                'status' => $status_filter !== 'all' ? $status_filter : '',
                'search' => $search,
            ]));
            ?>
            <a href="<?= $pg_base ?>&page=<?= max(1, $page - 1) ?>"
               class="pg-btn <?= $page <= 1 ? 'disabled' : '' ?>">&#8592; Prev</a>

            <?php
            $range_start = max(1, $page - 2);
            $range_end   = min($total_pages, $page + 2);
            if ($range_start > 1): ?>
                <a href="<?= $pg_base ?>&page=1" class="pg-btn">1</a>
                <?php if ($range_start > 2): ?><span class="pg-info">…</span><?php endif; ?>
            <?php endif; ?>

            <?php for ($i = $range_start; $i <= $range_end; $i++): ?>
                <a href="<?= $pg_base ?>&page=<?= $i ?>" class="pg-btn <?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>

            <?php if ($range_end < $total_pages): ?>
                <?php if ($range_end < $total_pages - 1): ?><span class="pg-info">…</span><?php endif; ?>
                <a href="<?= $pg_base ?>&page=<?= $total_pages ?>" class="pg-btn"><?= $total_pages ?></a>
            <?php endif; ?>

            <a href="<?= $pg_base ?>&page=<?= min($total_pages, $page + 1) ?>"
               class="pg-btn <?= $page >= $total_pages ? 'disabled' : '' ?>">Next &#8594;</a>

            <span class="pg-info">Page <?= $page ?> of <?= $total_pages ?></span>
        </div>
        <?php endif; ?>

        <?php endif; /* end if empty($orders) */ ?>
    </div>
</main>

<!-- ╔══════════════════════════════╗
     ║      ORDER DETAIL MODAL     ║
     ╚══════════════════════════════╝ -->
<div class="modal-backdrop" id="detailModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="detailTitle">Order Details</h3>
            <button class="modal-close" onclick="closeDetail()">&#10005;</button>
        </div>
        <div class="modal-body" id="detailBody">
            <p style="text-align:center;color:#94A3B8;padding:30px 0">Loading…</p>
        </div>
        <div class="modal-footer">
            <button class="btn-secondary" onclick="closeDetail()">Close</button>
        </div>
    </div>
</div>

<!-- ╔══════════════════════════════╗
     ║      CANCEL ORDER MODAL     ║
     ╚══════════════════════════════╝ -->
<div class="modal-backdrop cancel-modal" id="cancelModal">
    <div class="modal" style="max-width:440px">
        <div class="modal-header">
            <h3>Cancel Order</h3>
            <button class="modal-close" onclick="closeCancel()">&#10005;</button>
        </div>
        <div class="modal-body">
            <p>You are about to cancel order <strong id="cancelOrderNum"></strong>.
               This will restore stock for all items.</p>
            <textarea id="cancelReason" placeholder="Reason for cancellation (optional)…"></textarea>
        </div>
        <div class="modal-footer" style="justify-content:space-between">
            <button class="btn-secondary" onclick="closeCancel()">Go Back</button>
            <button class="btn-danger" onclick="submitCancel()">Cancel Order</button>
        </div>
    </div>
</div>

<!-- Hidden form for POST actions -->
<form method="POST" id="actionForm" style="display:none">
    <?= csrf_field() ?>
    <input type="hidden" name="action"   id="formAction">
    <input type="hidden" name="order_id" id="formOrderId">
    <input type="hidden" name="cancel_reason" id="formCancelReason">
</form>

<!-- Order data for JS (current page orders) -->
<script>
const ORDERS_DATA = <?= json_encode(array_column($orders, null, 'id'), JSON_HEX_TAG) ?>;
const CSRF_TOKEN  = <?= json_encode($csrf_token) ?>;

/* ── POST action (confirm / ready / pickup) ── */
function submitAction(action, orderId, orderNum) {
    const labels = {
        confirm_order: 'confirm',
        ready_order:   'mark as ready',
        pickup_order:  'mark as picked up',
    };
    if (!confirm('Are you sure you want to ' + (labels[action] || action) + ' order #' + orderNum + '?')) return;
    document.getElementById('formAction').value   = action;
    document.getElementById('formOrderId').value  = orderId;
    document.getElementById('formCancelReason').value = '';
    document.getElementById('actionForm').submit();
}

/* ── Cancel modal ── */
let cancelOrderId = null;
function openCancel(orderId, orderNum) {
    cancelOrderId = orderId;
    document.getElementById('cancelOrderNum').textContent = '#' + orderNum;
    document.getElementById('cancelReason').value = '';
    document.getElementById('cancelModal').classList.add('open');
}
function closeCancel() {
    document.getElementById('cancelModal').classList.remove('open');
    cancelOrderId = null;
}
function submitCancel() {
    if (!cancelOrderId) return;
    document.getElementById('formAction').value        = 'cancel_order';
    document.getElementById('formOrderId').value       = cancelOrderId;
    document.getElementById('formCancelReason').value  = document.getElementById('cancelReason').value.trim();
    document.getElementById('actionForm').submit();
}

/* ── Detail modal ── */
function openDetail(orderId) {
    document.getElementById('detailModal').classList.add('open');
    document.getElementById('detailTitle').textContent = 'Loading…';
    document.getElementById('detailBody').innerHTML = '<p style="text-align:center;color:#94A3B8;padding:40px 0">Loading order details…</p>';

    fetch('orders_detail.php?id=' + orderId + '&csrf=' + encodeURIComponent(CSRF_TOKEN))
        .then(r => r.json())
        .then(data => {
            if (data.error) {
                document.getElementById('detailBody').innerHTML = '<p style="color:#EF4444">' + escHtml(data.error) + '</p>';
                return;
            }
            renderDetail(data);
        })
        .catch(() => {
            // Fallback: render from in-page data if available
            const o = ORDERS_DATA[orderId];
            if (o) renderDetailFallback(o);
            else document.getElementById('detailBody').innerHTML = '<p style="color:#EF4444">Could not load order details.</p>';
        });
}
function closeDetail() {
    document.getElementById('detailModal').classList.remove('open');
}
document.getElementById('detailModal').addEventListener('click', function(e) {
    if (e.target === this) closeDetail();
});
document.getElementById('cancelModal').addEventListener('click', function(e) {
    if (e.target === this) closeCancel();
});

function escHtml(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
}

function statusBadgeHtml(status) {
    const map = {
        pending:   {label:'Pending',   bg:'#FEF3C7', color:'#92400E', dot:'#F59E0B'},
        confirmed: {label:'Confirmed',  bg:'#DBEAFE', color:'#1E40AF', dot:'#3B82F6'},
        ready:     {label:'Ready',      bg:'#DCFCE7', color:'#166534', dot:'#16A34A'},
        picked_up: {label:'Picked Up',  bg:'#F1F5F9', color:'#475569', dot:'#94A3B8'},
        cancelled: {label:'Cancelled',  bg:'#FEE2E2', color:'#991B1B', dot:'#EF4444'},
    };
    const s = map[status] || {label:status, bg:'#F1F5F9', color:'#475569', dot:'#94A3B8'};
    return `<span class="status-badge" style="background:${s.bg};color:${s.color}"><span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${s.dot};margin-right:5px;vertical-align:middle"></span>${s.label}</span>`;
}

function fmtDate(d) {
    if (!d) return '—';
    const dt = new Date(d.replace(' ','T'));
    return dt.toLocaleDateString('en-GB', {day:'2-digit', month:'short', year:'numeric'}) + ' ' +
           dt.toLocaleTimeString('en-GB', {hour:'2-digit', minute:'2-digit'});
}

function renderDetail(data) {
    const o = data.order;
    document.getElementById('detailTitle').textContent = 'Order #' + o.order_number;

    // Timeline
    const steps = [
        {key:'created_at',  label:'Order Placed',   done: !!o.created_at,   cancel: false},
        {key:'confirmed_at',label:'Confirmed',       done: !!o.confirmed_at, cancel: false},
        {key:'ready_at',    label:'Ready for Pickup',done: !!o.ready_at,     cancel: false},
        {key:'picked_up_at',label:'Picked Up',       done: !!o.picked_up_at, cancel: false},
    ];
    if (o.cancelled_at) {
        steps.push({key:'cancelled_at', label:'Cancelled', done: true, cancel: true});
    }

    let tlHtml = '<ul class="timeline">';
    steps.forEach(s => {
        const dotClass = s.cancel ? 'cancel' : (s.done ? 'done' : 'pending');
        const icon = s.cancel ? '✕' : (s.done ? '✓' : '○');
        tlHtml += `<li>
            <div class="tl-dot ${dotClass}">${icon}</div>
            <div class="tl-text">
                <div class="tl-label">${escHtml(s.label)}</div>
                <div class="tl-time">${s.done ? fmtDate(o[s.key]) : 'Pending'}</div>
            </div>
        </li>`;
    });
    tlHtml += '</ul>';

    // Items
    let itemsHtml = '<table class="items-table"><thead><tr><th>Product</th><th>Type</th><th style="text-align:right">Qty</th><th style="text-align:right">Unit Price</th><th style="text-align:right">Total</th></tr></thead><tbody>';
    let grandTotal = 0;
    (data.items || []).forEach(item => {
        grandTotal += parseFloat(item.total_price) || 0;
        itemsHtml += `<tr>
            <td>${escHtml(item.product_name || 'Unknown')}</td>
            <td><span style="text-transform:capitalize">${escHtml(item.product_type || '')}</span></td>
            <td style="text-align:right">${parseInt(item.quantity)}</td>
            <td style="text-align:right">${escHtml(o.currency || 'USD')} ${Number(item.unit_price).toLocaleString()}</td>
            <td style="text-align:right">${escHtml(o.currency || 'USD')} ${Number(item.total_price).toLocaleString()}</td>
        </tr>`;
    });
    itemsHtml += `<tr class="total-row"><td colspan="4" style="text-align:right;padding-right:16px">Order Total</td><td style="text-align:right">${escHtml(o.currency || 'USD')} ${Number(o.total_amount).toLocaleString()}</td></tr>`;
    itemsHtml += '</tbody></table>';

    // Deadline
    let deadlineHtml = '';
    if (o.pickup_deadline && ['confirmed','ready'].includes(o.status)) {
        const diff = new Date(o.pickup_deadline.replace(' ','T')) - new Date();
        if (diff < 0) {
            deadlineHtml = `<span class="deadline-warn overdue" style="font-size:0.85rem">Pickup overdue</span>`;
        } else {
            const hrs  = Math.floor(diff/3600000);
            const mins = Math.floor((diff%3600000)/60000);
            const cls  = diff < 7200000 ? 'urgent' : '';
            deadlineHtml = cls ? `<span class="deadline-warn urgent" style="font-size:0.85rem">${hrs}h ${mins}m until deadline</span>` : '';
        }
    }

    document.getElementById('detailBody').innerHTML = `
        <div class="modal-section">
            <h4>Order Information</h4>
            <div class="info-grid">
                <div class="info-item"><div class="label">Order Number</div><div class="value">${escHtml(o.order_number)}</div></div>
                <div class="info-item"><div class="label">Status</div><div class="value">${statusBadgeHtml(o.status)} ${deadlineHtml}</div></div>
                <div class="info-item"><div class="label">Order Date</div><div class="value">${fmtDate(o.created_at)}</div></div>
                <div class="info-item"><div class="label">Currency</div><div class="value">${escHtml(o.currency || 'USD')}</div></div>
                ${o.pickup_deadline ? `<div class="info-item"><div class="label">Pickup Deadline</div><div class="value">${fmtDate(o.pickup_deadline)}</div></div>` : ''}
                ${o.notes ? `<div class="info-item" style="grid-column:1/-1"><div class="label">Notes</div><div class="value" style="font-weight:400;color:#374151">${escHtml(o.notes)}</div></div>` : ''}
                ${o.cancel_reason ? `<div class="info-item" style="grid-column:1/-1"><div class="label">Cancel Reason</div><div class="value" style="font-weight:400;color:#991B1B">${escHtml(o.cancel_reason)}</div></div>` : ''}
            </div>
        </div>

        <div class="modal-section">
            <h4>Customer Information</h4>
            <div class="info-grid">
                <div class="info-item"><div class="label">Name</div><div class="value">${escHtml(data.customer?.name || 'N/A')}</div></div>
                <div class="info-item"><div class="label">Phone</div><div class="value">${escHtml(data.customer?.phone || '—')}</div></div>
                <div class="info-item" style="grid-column:1/-1"><div class="label">Email</div><div class="value">${escHtml(data.customer?.email || '—')}</div></div>
            </div>
        </div>

        <div class="modal-section">
            <h4>Items (${(data.items||[]).length})</h4>
            ${itemsHtml}
        </div>

        <div class="modal-section">
            <h4>Order Timeline</h4>
            ${tlHtml}
        </div>
    `;
}

function renderDetailFallback(o) {
    document.getElementById('detailTitle').textContent = 'Order #' + o.order_number;
    document.getElementById('detailBody').innerHTML = `
        <div class="modal-section">
            <div class="info-grid">
                <div class="info-item"><div class="label">Order Number</div><div class="value">${escHtml(o.order_number)}</div></div>
                <div class="info-item"><div class="label">Status</div><div class="value">${statusBadgeHtml(o.status)}</div></div>
                <div class="info-item"><div class="label">Customer</div><div class="value">${escHtml(o.customer_name||'N/A')}</div></div>
                <div class="info-item"><div class="label">Total</div><div class="value">${escHtml(o.currency||'USD')} ${Number(o.total_amount).toLocaleString()}</div></div>
            </div>
            <p style="margin-top:16px;font-size:0.85rem;color:#94A3B8">Full details unavailable. Please refresh the page.</p>
        </div>
    `;
}

/* Close modals on Escape */
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeDetail();
        closeCancel();
    }
});
</script>
</body>
</html>
