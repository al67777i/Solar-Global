﻿// ============================================================
// NOTE: Main implementation of battery wiring diagram is at line ~1460
// This duplicate has been removed to avoid confusion
// ============================================================
//     return `
//         <div class="animated-sun-container">
//             <div class="sun-core"></div>
//             <div class="sun-rays">
//                 <div class="sun-ray"></div>
//                 <div class="sun-ray"></div>
//                 <div class="sun-ray"></div>
//                 <div class="sun-ray"></div>
//                 <div class="sun-ray"></div>
//                 <div class="sun-ray"></div>
//                 <div class="sun-ray"></div>
//                 <div class="sun-ray"></div>
//             </div>
//         </div>
//         <div class="energy-particles-container">
//             <div class="energy-particle"></div>
//             <div class="energy-particle"></div>
//             <div class="energy-particle"></div>
//             <div class="energy-particle"></div>
//             <div class="energy-particle"></div>
//             <div class="energy-particle"></div>
//             <div class="energy-particle"></div>
//             <div class="energy-particle"></div>
//         </div>
//     `;
// }

// /**
//  * Render animated system layout
//  */
// function renderAnimatedSystemLayout(selectedSystem) {
//     const { inverter, battery_config, panel_config } = selectedSystem;
//     const loadAnalysis = window.appState.recommendations.load_analysis;
    
//     return `
//         <div class="animated-installation-guide">
//             <!-- Animated Sun -->
//             ${renderAnimatedSun()}
            
//             <!-- System Layout -->
//             <div class="system-layout">
//                 <!-- Top Row: Solar Panels with Actual Connections -->
//                 <div class="layout-row top" style="margin-top: 200px;">
//                     <div style="max-width: 900px; margin: 0 auto;">
//                         <h3 style="text-align: center; color: #0D3B6E; margin-bottom: 20px;">
//                             ☀️ Solar Panel Array: ${panel_config.quantity}× ${panel_config.panel.watt_peak}W (${panel_config.wiring})
//                         </h3>
                        
//                         <!-- Actual Panel Layout with Connections -->
//                         <div style="background: white; padding: 30px; border-radius: 12px; border: 3px solid #1565C0; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
//                             ${renderActualPanelLayout(panel_config)}
                            
//                             <div style="margin-top: 20px; padding: 12px; background: #E0F2FE; border-radius: 8px; text-align: center;">
//                                 <div style="font-size: 13px; color: #0D3B6E;">
//                                     <strong>String Voltage:</strong> ${panel_config.string_voltage}V DC • 
//                                     <strong>Total Power:</strong> ${panel_config.total_wattage}W • 
//                                     <strong>Daily Generation:</strong> ${(panel_config.total_wattage * 5 / 1000).toFixed(1)} kWh
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
                
//                 <!-- Animated DC Wires (Panels to Inverter) -->
//                 <svg class="animated-wire" style="position: absolute; top: 450px; left: 50%; transform: translateX(-50%); width: 200px; height: 150px;">
//                     <defs>
//                         <marker id="arrowblue" markerWidth="10" markerHeight="10" refX="5" refY="3" orient="auto" markerUnits="strokeWidth">
//                             <path d="M0,0 L0,6 L9,3 z" fill="#3B82F6" />
//                         </marker>
//                         <marker id="arrowred" markerWidth="10" markerHeight="10" refX="5" refY="3" orient="auto" markerUnits="strokeWidth">
//                             <path d="M0,0 L0,6 L9,3 z" fill="#EF4444" />
//                         </marker>
//                     </defs>
//                     <!-- DC+ (Blue) -->
//                     <path d="M 100 10 L 100 140" class="wire-path dc-positive" marker-end="url(#arrowblue)" />
//                     <text x="110" y="70" class="wire-label" fill="#3B82F6">DC+</text>
//                     <!-- DC- (Red) -->
//                     <path d="M 120 10 L 120 140" class="wire-path dc-negative" marker-end="url(#arrowred)" />
//                     <text x="130" y="70" class="wire-label" fill="#EF4444">DC-</text>
//                 </svg>
                
//                 <!-- Middle Row: Inverter -->
//                 <div class="layout-row middle" style="margin-top: 150px;">
//                     <div class="component-box inverter" style="max-width: 500px;">
//                         <div style="text-align: center;">
//                             <div style="font-size: 64px; margin-bottom: 16px;">⚡</div>
//                             <h3 style="color: #0D3B6E; margin-bottom: 8px;">Inverter</h3>
//                             <p style="font-size: 20px; font-weight: 700; color: #10B981; margin-bottom: 4px;">
//                                 ${inverter.company_name || inverter.name}
//                             </p>
//                             <p style="font-size: 16px; font-weight: 600; color: #059669; margin-bottom: 8px;">
//                                 ${inverter.name}
//                             </p>
//                             <p style="font-size: 14px; color: #64748B; margin-bottom: 16px;">
//                                 ${inverter.max_load_watts}W • ${inverter.voltage_class} • ${inverter.inverter_type || 'Hybrid'}
//                             </p>
//                             ${inverter.image_path ? `
//                                 <img src="${inverter.image_path}" 
//                                      style="width: 250px; height: 250px; object-fit: contain; border-radius: 8px;" 
//                                      alt="${inverter.name}">
//                             ` : ''}
//                             <div style="margin-top: 16px; padding: 12px; background: #D1FAE5; border-radius: 8px;">
//                                 <div style="font-size: 13px; color: #065F46;">
//                                     <strong>Function:</strong> DC → AC Conversion<br>
//                                     <strong>Efficiency:</strong> ${inverter.efficiency_percent || 90}%<br>
//                                     <strong>BMS:</strong> ${inverter.has_bms ? 'Yes ✓' : 'No'}<br>
//                                     <strong>Max DC Input:</strong> ${inverter.max_dc_voltage || 'N/A'}V
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
                
//                 <!-- Animated Wires (Inverter to Home & Battery) -->
//                 <svg class="animated-wire" style="position: absolute; top: 850px; left: 30%; width: 300px; height: 150px;">
//                     <defs>
//                         <marker id="arroworange" markerWidth="10" markerHeight="10" refX="5" refY="3" orient="auto" markerUnits="strokeWidth">
//                             <path d="M0,0 L0,6 L9,3 z" fill="#F97316" />
//                         </marker>
//                     </defs>
//                     <!-- AC to Home (Orange) -->
//                     <path d="M 50 10 L 50 140" class="wire-path ac" marker-end="url(#arroworange)" />
//                     <text x="60" y="70" class="wire-label" fill="#F97316">AC 230V</text>
//                 </svg>
                
//                 <svg class="animated-wire" style="position: absolute; top: 850px; right: 30%; width: 300px; height: 150px;">
//                     <!-- Battery Wires -->
//                     <path d="M 250 10 L 250 140" class="wire-path battery-positive" marker-end="url(#arrowred)" />
//                     <text x="260" y="70" class="wire-label" fill="#EF4444">BAT+</text>
//                     <path d="M 270 10 L 270 140" class="wire-path battery-negative" />
//                     <text x="280" y="70" class="wire-label" fill="#1F2937">BAT-</text>
//                 </svg>
                
//                 <!-- Bottom Row: Home & Battery -->
//                 <div class="layout-row bottom" style="margin-top: 150px;">
//                     <!-- Home Appliances -->
//                     <div class="component-box home" style="max-width: 350px;">
//                         <div style="text-align: center;">
//                             <div style="font-size: 48px; margin-bottom: 12px;">🏠</div>
//                             <h3 style="color: #0D3B6E; margin-bottom: 16px;">Home Appliances</h3>
//                             <div class="appliances-grid">
//                                 ${loadAnalysis.appliance_details.slice(0, 6).map(app => `
//                                     <div class="appliance-item">
//                                         <span class="appliance-icon">${app.icon || '⚡'}</span>
//                                         <div class="appliance-name">${app.name_en}</div>
//                                         <div class="appliance-power">${app.total_watts}W</div>
//                                     </div>
//                                 `).join('')}
//                             </div>
//                             <div style="margin-top: 16px; padding: 12px; background: #EDE9FE; border-radius: 8px;">
//                                 <div style="font-size: 13px; color: #5B21B6;">
//                                     <strong>Total Load:</strong> ${loadAnalysis.total_load_watts}W<br>
//                                     <strong>Daily Usage:</strong> ${loadAnalysis.daily_energy_kwh} kWh
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
                    
//                     <!-- Battery Bank -->
//                     <div class="component-box batteries" style="max-width: 350px;">
//                         <div style="text-align: center;">
//                             <div style="font-size: 48px; margin-bottom: 12px;">🔋</div>
//                             <h3 style="color: #0D3B6E; margin-bottom: 16px;">Battery Bank</h3>
//                             <p style="font-size: 16px; font-weight: 600; color: #F59E0B; margin-bottom: 16px;">
//                                 ${battery_config.quantity}× ${battery_config.battery.capacity_ah}Ah
//                             </p>
//                             ${battery_config.battery.image_path ? `
//                                 <img src="${battery_config.battery.image_path}" 
//                                      style="width: 150px; height: 150px; object-fit: contain; border-radius: 8px; margin-bottom: 16px;" 
//                                      alt="Battery">
//                             ` : ''}
//                             <!-- Animated Battery Visual -->
//                             <div class="battery-visual">
//                                 <div class="battery-terminal"></div>
//                                 <div class="battery-body">
//                                     <div class="battery-fill"></div>
//                                     <div class="battery-percentage">85%</div>
//                                     <div class="charging-indicator">⚡</div>
//                                 </div>
//                             </div>
//                             <div style="margin-top: 16px; padding: 12px; background: #FEF3C7; border-radius: 8px;">
//                                 <div style="font-size: 13px; color: #92400E;">
//                                     <strong>Total Capacity:</strong> ${battery_config.total_ah}Ah<br>
//                                     <strong>Energy:</strong> ${battery_config.total_kwh} kWh<br>
//                                     <strong>Backup Time:</strong> ${selectedSystem.backup_hours}h<br>
//                                     <strong>Type:</strong> ${battery_config.battery.battery_type}
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
                
//                 <!-- Grid Connection (Bottom Center) -->
//                 <div style="position: absolute; bottom: -80px; left: 50%; transform: translateX(-50%);">
//                     <div class="component-box grid" style="max-width: 250px;">
//                         <div style="text-align: center;">
//                             <div class="grid-icon-animated" style="font-size: 48px; margin-bottom: 8px;">🔌</div>
//                             <h4 style="color: #0D3B6E; margin-bottom: 4px;">Grid / WAPDA</h4>
//                             <p style="font-size: 12px; color: #64748B;">230V AC • 50Hz</p>
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     `;
// }

// /**
//  * Render series/parallel panel wiring diagram
//  */
// function renderPanelWiringDiagram(panelConfig) {
//     const { series, parallel, panel } = panelConfig;
//     const panelWidth = 100;
//     const panelHeight = 140;
//     const gapX = 40;
//     const gapY = 40;
//     const startX = 50;
//     const startY = 80;
    
//     let panelsSVG = '';
//     let seriesWires = '';
//     let parallelWires = '';
    
//     // Draw panels and connections
//     for (let p = 0; p < parallel; p++) {
//         for (let s = 0; s < series; s++) {
//             const x = startX + s * (panelWidth + gapX);
//             const y = startY + p * (panelHeight + gapY);
            
//             // Panel rectangle
//             panelsSVG += `
//                 <rect x="${x}" y="${y}" width="${panelWidth}" height="${panelHeight}" 
//                       class="panel-rect" rx="8"/>
//                 <text x="${x + panelWidth/2}" y="${y + panelHeight/2}" 
//                       text-anchor="middle" font-size="48">☀️</text>
//                 <text x="${x + panelWidth/2}" y="${y + panelHeight - 20}" 
//                       text-anchor="middle" font-size="12" fill="#0D3B6E" font-weight="600">
//                       ${panel.watt_peak}W
//                 </text>
//             `;
            
//             // Terminals
//             panelsSVG += `
//                 <circle cx="${x + panelWidth - 15}" cy="${y + 20}" r="8" class="terminal-positive"/>
//                 <circle cx="${x + panelWidth - 15}" cy="${y + panelHeight - 20}" r="8" class="terminal-negative"/>
//                 <text x="${x + panelWidth - 15}" y="${y + 25}" text-anchor="middle" 
//                       font-size="12" fill="white" font-weight="bold">+</text>
//                 <text x="${x + panelWidth - 15}" y="${y + panelHeight - 15}" text-anchor="middle" 
//                       font-size="12" fill="white" font-weight="bold">-</text>
//             `;
            
//             // Series connections (within string)
//             if (s < series - 1) {
//                 const x1 = x + panelWidth - 15;
//                 const y1 = y + panelHeight - 20;
//                 const x2 = x + panelWidth + gapX + 15;
//                 const y2 = y + 20;
                
//                 seriesWires += `
//                     <path d="M ${x1} ${y1} L ${x1 + 20} ${y1} L ${x1 + 20} ${y2} L ${x2} ${y2}" 
//                           class="series-wire" fill="none"/>
//                 `;
//             }
//         }
        
//         // Parallel connections (between strings)
//         if (p < parallel - 1) {
//             const x1 = startX + (series - 1) * (panelWidth + gapX) + panelWidth - 15;
//             const y1 = startY + p * (panelHeight + gapY) + 20;
//             const y2 = startY + (p + 1) * (panelHeight + gapY) + 20;
            
//             parallelWires += `
//                 <line x1="${x1 + 50}" y1="${y1}" x2="${x1 + 50}" y2="${y2}" 
//                       class="parallel-wire"/>
//             `;
//         }
//     }
    
//     const svgWidth = startX + series * (panelWidth + gapX) + 100;
//     const svgHeight = startY + parallel * (panelHeight + gapY) + 100;
    
//     return `
//         <svg class="wiring-diagram-svg" viewBox="0 0 ${svgWidth} ${svgHeight}">
//             <text x="${svgWidth/2}" y="40" text-anchor="middle" 
//                   font-size="20" font-weight="bold" fill="#0D3B6E">
//                 Solar Panel Configuration: ${series}S${parallel}P
//             </text>
            
//             ${panelsSVG}
//             ${seriesWires}
//             ${parallelWires}
            
//             <text x="${svgWidth/2}" y="${svgHeight - 20}" text-anchor="middle" 
//                   font-size="14" fill="#64748B">
//                 String Voltage: ${panelConfig.string_voltage}V DC • 
//                 Total Power: ${panelConfig.total_wattage}W
//             </text>
//         </svg>
//     `;
// }

// /**
//  * Render complete animated installation guide
//  */
// function renderInstallationGuide(selectedSystem) {
//     const container = document.getElementById('installation-guide');
//     if (!container) return;
    
//     const { inverter, battery_config, panel_config } = selectedSystem;
    
//     container.innerHTML = `
//         ${renderAnimatedSystemLayout(selectedSystem)}
        
//         <!-- Detailed Wiring Diagrams -->
//         <div style="margin-top: 60px; padding: 40px; background: white; border-radius: 16px;">
//             <h2 style="text-align: center; color: #0D3B6E; margin-bottom: 40px;">
//                 📐 Detailed Wiring Diagrams
//             </h2>
            
//             <!-- Panel Wiring -->
//             <div style="margin-bottom: 60px;">
//                 <h3 style="color: #1565C0; margin-bottom: 20px;">
//                     ☀️ Solar Panel Series/Parallel Connection
//                 </h3>
//                 ${renderPanelWiringDiagram(panel_config)}
//             </div>
            
//             <!-- Installation Steps -->
//             <div style="margin-top: 60px;">
//                 <h2 style="text-align: center; color: #0D3B6E; margin-bottom: 40px;">
//                     📖 Installation Steps
//                 </h2>
                
//                 ${renderInstallationSteps(selectedSystem)}
//             </div>
            
//             <!-- Safety Warning -->
//             <div class="safety-warning">
//                 <div class="safety-warning-header">
//                     <span class="safety-icon">⚠️</span>
//                     <h3 class="safety-title">IMPORTANT SAFETY WARNING</h3>
//                 </div>
//                 <div class="safety-content">
//                     <p><strong>This installation must be performed by a qualified electrician.</strong></p>
//                     <ul>
//                         <li>High voltage DC and AC present - risk of electric shock</li>
//                         <li>Batteries contain corrosive acid - wear protective gear</li>
//                         <li>Solar panels generate voltage in daylight - cover during installation</li>
//                         <li>Improper wiring can cause fire - use correct cable sizes</li>
//                         <li>Always connect earth ground properly</li>
//                     </ul>
//                 </div>
//             </div>
            
//             <!-- Action Buttons -->
//             <div style="margin-top: 40px; text-align: center; display: flex; gap: 16px; justify-content: center;">
//                 <button onclick="window.print()" class="btn btn-secondary" style="padding: 12px 24px; border-radius: 8px; font-weight: 600;">
//                     🖨️ Print Guide
//                 </button>
//                 <button onclick="downloadSystemPDF()" class="btn btn-primary" style="padding: 12px 24px; border-radius: 8px; font-weight: 600;">
//                     📄 Download PDF
//                 </button>
//             </div>
//         </div>
//     `;
// }

// /**
//  * Render installation steps
//  */
// function renderInstallationSteps(selectedSystem) {
//     const { inverter, battery_config, panel_config } = selectedSystem;
//     const loadAnalysis = window.appState.recommendations.load_analysis;
    
//     return `
//         <div class="installation-steps">
//             ${renderInstallationStep(1, '☀️ Mount Solar Panels', `
//                 <div class="step-content-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
//                     <div class="step-instructions">
//                         <h4 style="color: #0D3B6E; margin-bottom: 12px;">Panel Mounting:</h4>
//                         <ul style="line-height: 1.8; color: #475569;">
//                             <li>Install mounting structure on roof at 30° angle</li>
//                             <li>Face panels towards south for Pakistan</li>
//                             <li>Ensure proper spacing between panels (5-10cm)</li>
//                             <li>Secure all bolts and use anti-rust coating</li>
//                             <li>Leave space for maintenance access</li>
//                         </ul>
                        
//                         <h4 style="color: #0D3B6E; margin: 16px 0 12px;">Configuration: ${panel_config.wiring}</h4>
//                         <ul style="line-height: 1.8; color: #475569;">
//                             <li><strong>Series:</strong> ${panel_config.series} panels connected positive to negative</li>
//                             <li><strong>Parallel:</strong> ${panel_config.parallel} strings connected together</li>
//                             <li><strong>String Voltage:</strong> ${panel_config.string_voltage}V DC</li>
//                             <li><strong>Total Power:</strong> ${panel_config.total_wattage}W</li>
//                         </ul>
//                     </div>
//                     <div class="step-diagram">
//                         ${panel_config.panel.image_path ? `
//                             <div style="text-align: center;">
//                                 <img src="${panel_config.panel.image_path}" 
//                                      style="width: 100%; max-width: 300px; height: auto; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" 
//                                      alt="Solar Panel">
//                                 <p style="margin-top: 12px; font-size: 14px; color: #64748B;">Your Solar Panel: ${panel_config.panel.watt_peak}W</p>
//                             </div>
//                         ` : ''}
//                     </div>
//                 </div>
//             `)}
            
//             ${renderInstallationStep(2, '🔌 Wire Solar Panels', `
//                 <div class="step-content-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
//                     <div class="step-instructions">
//                         <h4 style="color: #0D3B6E; margin-bottom: 12px;">Wiring Instructions:</h4>
//                         <ul style="line-height: 1.8; color: #475569;">
//                             <li>Use proper gauge DC cables (4mm² or 6mm²)</li>
//                             <li>Connect panels using MC4 connectors</li>
//                             <li>Series: Connect + of panel 1 to - of panel 2</li>
//                             <li>Parallel: Connect all + together, all - together</li>
//                             <li>Install DC isolator switch near panels</li>
//                             <li>Run cables in conduit to inverter location</li>
//                         </ul>
                        
//                         <div style="background: #FEF2F2; border-left: 4px solid #EF4444; padding: 12px; margin-top: 16px; border-radius: 4px;">
//                             <strong style="color: #991B1B;">⚠️ SAFETY WARNING:</strong>
//                             <p style="color: #7F1D1D; margin-top: 8px; line-height: 1.6;">Solar panels generate voltage in daylight. Cover panels or work in low light. Always use insulated tools.</p>
//                         </div>
//                     </div>
//                     <div class="step-diagram">
//                         <div style="background: #F8FAFC; padding: 16px; border-radius: 8px;">
//                             <h4 style="color: #0D3B6E; margin-bottom: 12px;">Cable Specifications:</h4>
//                             <table style="width: 100%; border-collapse: collapse;">
//                                 <tr style="border-bottom: 1px solid #E2E8F0;">
//                                     <td style="padding: 8px; color: #64748B;">DC Cable Size:</td>
//                                     <td style="padding: 8px; font-weight: 600; color: #0D3B6E;">6mm² (for ${panel_config.total_wattage}W)</td>
//                                 </tr>
//                                 <tr style="border-bottom: 1px solid #E2E8F0;">
//                                     <td style="padding: 8px; color: #64748B;">String Voltage:</td>
//                                     <td style="padding: 8px; font-weight: 600; color: #0D3B6E;">${panel_config.string_voltage}V DC</td>
//                                 </tr>
//                                 <tr style="border-bottom: 1px solid #E2E8F0;">
//                                     <td style="padding: 8px; color: #64748B;">Max Current:</td>
//                                     <td style="padding: 8px; font-weight: 600; color: #0D3B6E;">${Math.ceil(panel_config.total_wattage / panel_config.string_voltage)}A</td>
//                                 </tr>
//                                 <tr>
//                                     <td style="padding: 8px; color: #64748B;">Fuse Rating:</td>
//                                     <td style="padding: 8px; font-weight: 600; color: #0D3B6E;">${Math.ceil(panel_config.total_wattage / panel_config.string_voltage * 1.25)}A DC</td>
//                                 </tr>
//                             </table>
//                         </div>
//                     </div>
//                 </div>
//             `)}
            
//             ${renderInstallationStep(3, '⚡ Install Inverter', `
//                 <div class="step-content-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
//                     <div class="step-instructions">
//                         <h4 style="color: #0D3B6E; margin-bottom: 12px;">Inverter Installation:</h4>
//                         <ul style="line-height: 1.8; color: #475569;">
//                             <li>Mount on solid wall in ventilated area</li>
//                             <li>Keep 30cm clearance on all sides for cooling</li>
//                             <li>Install at eye level for easy monitoring</li>
//                             <li>Protect from direct sunlight and rain</li>
//                             <li>Connect to proper earth ground (essential!)</li>
//                             <li>Install AC and DC circuit breakers</li>
//                         </ul>
                        
//                         <h4 style="color: #0D3B6E; margin: 16px 0 12px;">Inverter Specifications:</h4>
//                         <ul style="line-height: 1.8; color: #475569;">
//                             <li><strong>Model:</strong> ${inverter.name}</li>
//                             <li><strong>Voltage Class:</strong> ${inverter.voltage_class}</li>
//                             <li><strong>Max Load:</strong> ${inverter.max_load_watts}W</li>
//                             <li><strong>Type:</strong> ${inverter.inverter_type || 'Hybrid'}</li>
//                             <li><strong>BMS:</strong> ${inverter.has_bms ? 'Yes ✓' : 'No'}</li>
//                         </ul>
//                     </div>
//                     <div class="step-diagram">
//                         ${inverter.image_path ? `
//                             <div style="text-align: center;">
//                                 <img src="${inverter.image_path}" 
//                                      style="width: 100%; max-width: 300px; height: auto; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" 
//                                      alt="${inverter.name}">
//                                 <p style="margin-top: 12px; font-size: 14px; color: #64748B;">Your Inverter: ${inverter.name}</p>
//                             </div>
//                         ` : ''}
//                     </div>
//                 </div>
//             `)}
            
//             ${renderInstallationStep(4, '🔋 Connect Batteries', `
//                 <div class="step-content-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
//                     <div class="step-instructions">
//                         <h4 style="color: #0D3B6E; margin-bottom: 12px;">Battery Bank Setup:</h4>
//                         <ul style="line-height: 1.8; color: #475569;">
//                             <li>Place batteries in well-ventilated area</li>
//                             <li>Keep batteries on insulated platform</li>
//                             <li>Connect ${battery_config.quantity} batteries in ${battery_config.wiring.toLowerCase()}</li>
//                             <li>Use proper gauge cables (10mm² or 16mm²)</li>
//                             <li>Install fuses on positive terminals</li>
//                             <li>Ensure all connections are tight</li>
//                         </ul>
                        
//                         <h4 style="color: #0D3B6E; margin: 16px 0 12px;">Battery Configuration:</h4>
//                         <ul style="line-height: 1.8; color: #475569;">
//                             <li><strong>Quantity:</strong> ${battery_config.quantity}× ${battery_config.battery.capacity_ah}Ah</li>
//                             <li><strong>Wiring:</strong> ${battery_config.wiring}</li>
//                             <li><strong>Total Capacity:</strong> ${battery_config.total_ah}Ah</li>
//                             <li><strong>Energy:</strong> ${battery_config.total_kwh} kWh</li>
//                             <li><strong>Backup Time:</strong> ${selectedSystem.backup_hours} hours</li>
//                         </ul>
                        
//                         <div style="background: #FEF2F2; border-left: 4px solid #EF4444; padding: 12px; margin-top: 16px; border-radius: 4px;">
//                             <strong style="color: #991B1B;">⚠️ BATTERY SAFETY:</strong>
//                             <p style="color: #7F1D1D; margin-top: 8px; line-height: 1.6;">Batteries contain acid and produce explosive gases. Ensure proper ventilation. Wear safety gear. No sparks or flames nearby.</p>
//                         </div>
//                     </div>
//                     <div class="step-diagram">
//                         ${battery_config.battery.image_path ? `
//                             <div style="text-align: center;">
//                                 <img src="${battery_config.battery.image_path}" 
//                                      style="width: 100%; max-width: 250px; height: auto; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" 
//                                      alt="Battery">
//                                 <p style="margin-top: 12px; font-size: 14px; color: #64748B;">Your Battery: ${battery_config.battery.capacity_ah}Ah</p>
//                             </div>
//                         ` : ''}
//                     </div>
//                 </div>
//             `)}
            
//             ${renderInstallationStep(5, '🔌 Final Connections & Testing', `
//                 <div class="step-content-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
//                     <div class="step-instructions">
//                         <h4 style="color: #0D3B6E; margin-bottom: 12px;">System Integration:</h4>
//                         <ol style="line-height: 1.8; color: #475569;">
//                             <li><strong>Solar to Inverter:</strong> Connect solar DC cables to inverter solar input terminals</li>
//                             <li><strong>Batteries to Inverter:</strong> Connect battery bank to inverter battery terminals (+ to +, - to -)</li>
//                             <li><strong>Load Connections:</strong> Connect your home loads to inverter AC output</li>
//                             <li><strong>Grid Connection:</strong> If hybrid, connect grid input (by certified electrician)</li>
//                             <li><strong>Earth Ground:</strong> Connect all equipment to proper earth ground</li>
//                         </ol>
                        
//                         <h4 style="color: #0D3B6E; margin: 16px 0 12px;">Testing Procedure:</h4>
//                         <ol style="line-height: 1.8; color: #475569;">
//                             <li>Check all connections are tight</li>
//                             <li>Verify polarity (+ and - correct)</li>
//                             <li>Turn on DC isolators</li>
//                             <li>Power on inverter</li>
//                             <li>Check display for system status</li>
//                             <li>Test with small load first</li>
//                             <li>Monitor for 24 hours</li>
//                         </ol>
//                     </div>
//                     <div class="step-diagram">
//                         <div style="background: #F0FDF4; padding: 16px; border-radius: 8px; border: 2px solid #10B981;">
//                             <h4 style="color: #065F46; margin-bottom: 12px;">✅ Final Checklist:</h4>
//                             <ul style="list-style: none; padding: 0; line-height: 2;">
//                                 <li style="color: #047857;">☐ All cables properly sized</li>
//                                 <li style="color: #047857;">☐ All connections tight</li>
//                                 <li style="color: #047857;">☐ Fuses installed</li>
//                                 <li style="color: #047857;">☐ Earth ground connected</li>
//                                 <li style="color: #047857;">☐ Ventilation adequate</li>
//                                 <li style="color: #047857;">☐ No exposed wires</li>
//                                 <li style="color: #047857;">☐ Circuit breakers installed</li>
//                                 <li style="color: #047857;">☐ System tested</li>
//                             </ul>
//                         </div>
//                     </div>
//                 </div>
//             `)}
//         </div>
//     `;
// }

// /**
//  * Render installation step
//  */
// function renderInstallationStep(number, title, content) {
//     return `
//         <div class="installation-step" style="background: white; border-radius: 12px; padding: 24px; margin-bottom: 24px; border-left: 6px solid #3B82F6; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
//             <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 16px;">
//                 <div style="width: 48px; height: 48px; background: linear-gradient(135deg, #3B82F6, #1D4ED8); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 24px; font-weight: 800; flex-shrink: 0;">
//                     ${number}
//                 </div>
//                 <h3 style="font-size: 20px; font-weight: 700; color: #0D3B6E; margin: 0;">${title}</h3>
//             </div>
//             <div style="padding-left: 64px;">
//                 ${content}
//             </div>
//         </div>
//     `;
// }

// /**
//  * Download system as PDF (placeholder)
//  */
// function downloadSystemPDF() {
//     alert('PDF download feature coming soon! For now, please use Print to save as PDF.');
//     window.print();
// }

// // Export functions to global scope
// window.renderInstallationGuide = renderInstallationGuide;
// window.renderAnimatedSun = renderAnimatedSun;
// window.renderAnimatedSystemLayout = renderAnimatedSystemLayout;
// window.renderActualPanelLayout = renderActualPanelLayout;
// window.renderPanelWiringDiagram = renderPanelWiringDiagram;
// window.renderInstallationSteps = renderInstallationSteps;
// window.renderInstallationStep = renderInstallationStep;
// window.downloadSystemPDF = downloadSystemPDF;





/**
 * PERFECT SOLAR PANEL WIRING DIAGRAM
 * - Terminals: + on TOP-RIGHT, - on BOTTOM-RIGHT of each panel
 * - Series: - of panel connects to + of next panel (left to right)
 * - Parallel: All string + outputs meet at RIGHT BUS, all - outputs meet at RIGHT BUS
 * - Clean orthogonal wire routing - NO overlapping wires
 * - Color coded: RED=positive, BLACK=negative, ORANGE=series link, GREEN=to inverter
 */
// function renderActualPanelLayout(panelConfig) {
//     const { series, parallel, panel } = panelConfig;
//     const totalPanels = series * parallel;

//     // ── Panel dimensions ──────────────────────────────────────────
//     let PW = 100, PH = 130;
//     if (totalPanels > 6)  { PW = 82;  PH = 108; }
//     if (totalPanels > 10) { PW = 66;  PH = 88;  }
//     if (totalPanels > 16) { PW = 54;  PH = 72;  }

//     const GAP_X = 50;   // horizontal gap between panels (series)
//     const GAP_Y = 48;   // vertical gap between strings (parallel)
//     const MARGIN_L = 60;  // left margin
//     const MARGIN_T = 80;  // top margin (for title)

//     // Terminal positions WITHIN panel
//     const T_PLUS_X  = PW - 14;  const T_PLUS_Y  = 20;   // + terminal: top-right
//     const T_MINUS_X = PW - 14;  const T_MINUS_Y = PH - 20; // - terminal: bottom-right

//     // Terminal radius
//     const TR = totalPanels > 10 ? 7 : 9;

//     // ── SVG canvas size ───────────────────────────────────────────
//     // Right bus x position
//     const BUS_X = MARGIN_L + series * (PW + GAP_X) - GAP_X/2 + 40;
//     // Inverter position
//     const INV_X = BUS_X + 90;
//     const INV_SIZE = 56;

//     const SVG_W = INV_X + INV_SIZE + 60;
//     const SVG_H = MARGIN_T + parallel * (PH + GAP_Y) - GAP_Y + 60;
//     const INV_Y = MARGIN_T + (parallel * (PH + GAP_Y) - GAP_Y) / 2 - INV_SIZE/2;

//     // ── Helper: panel top-left ────────────────────────────────────
//     const px = s => MARGIN_L + s * (PW + GAP_X);
//     const py = p => MARGIN_T + p * (PH + GAP_Y);

//     // ── Collect terminal world positions ──────────────────────────
//     // plus[p][s]  = { x, y }
//     // minus[p][s] = { x, y }
//     const plus  = Array.from({length: parallel}, (_, p) =>
//         Array.from({length: series},   (_, s) => ({
//             x: px(s) + T_PLUS_X,
//             y: py(p) + T_PLUS_Y
//         }))
//     );
//     const minus = Array.from({length: parallel}, (_, p) =>
//         Array.from({length: series},   (_, s) => ({
//             x: px(s) + T_MINUS_X,
//             y: py(p) + T_MINUS_Y
//         }))
//     );

//     // ── Wire routing offsets to avoid overlaps ────────────────────
//     // Series wires route OUTSIDE the panel rows using unique Y lanes
//     // Parallel bus wires route along the right side

//     // For each string p, the series wires route below that string
//     // using a dedicated Y lane = py(p) + PH + 12 + p * 4  (small stagger)
//     const seriesLaneY = p => py(p) + PH + 14;

//     // For parallel bus, we use vertical lines at BUS_X
//     // Positive bus: BUS_X - 10
//     // Negative bus: BUS_X + 10
//     const BUS_PLUS_X  = BUS_X - 12;
//     const BUS_MINUS_X = BUS_X + 12;

//     // ─────────────────────────────────────────────────────────────
//     // BUILD SVG PARTS
//     // ─────────────────────────────────────────────────────────────
//     let defs = buildDefs(parallel, series, PW, PH, totalPanels);
//     let panels_svg   = '';
//     let series_wires = '';
//     let parallel_wires = '';
//     let output_wires = '';

//     // ── 1. Draw Panels ────────────────────────────────────────────
//     for (let p = 0; p < parallel; p++) {
//         for (let s = 0; s < series; s++) {
//             const X = px(s), Y = py(p);
//             const delay = (p * series + s) * 0.06;

//             panels_svg += `
//             <g style="animation:panelIn 0.5s ${delay.toFixed(2)}s ease-out both;">
//                 <!-- Panel body -->
//                 <rect x="${X}" y="${Y}" width="${PW}" height="${PH}"
//                       rx="6" fill="url(#pg${p}_${s})"
//                       stroke="#1E40AF" stroke-width="2.5"/>
//                 <!-- Cell grid -->
//                 <rect x="${X+6}" y="${Y+6}" width="${PW-12}" height="${PH-30}"
//                       fill="url(#cells)" stroke="#1E40AF" stroke-width="1" rx="2"/>
//                 <!-- Label bar -->
//                 <rect x="${X+4}" y="${Y+PH-22}" width="${PW-8}" height="18"
//                       fill="#1E40AF" rx="3"/>
//                 <text x="${X+PW/2}" y="${Y+PH-8}"
//                       text-anchor="middle" font-size="${totalPanels>12?9:11}"
//                       fill="white" font-weight="800">${panel.watt_peak}W</text>
//                 <!-- String label -->
//                 ${s===0 && parallel>1 ? `
//                     <text x="${X-8}" y="${Y+PH/2+4}"
//                           text-anchor="end" font-size="10"
//                           fill="#1E40AF" font-weight="700">S${p+1}</text>` : ''}
//             </g>`;

//             // + terminal
//             panels_svg += `
//             <circle cx="${X+T_PLUS_X}" cy="${Y+T_PLUS_Y}" r="${TR}"
//                     fill="#DC2626" stroke="white" stroke-width="2"
//                     style="animation:panelIn 0.5s ${(delay+0.1).toFixed(2)}s both;"/>
//             <text x="${X+T_PLUS_X}" y="${Y+T_PLUS_Y+4}"
//                   text-anchor="middle" font-size="${TR+2}"
//                   fill="white" font-weight="900">+</text>`;

//             // − terminal
//             panels_svg += `
//             <circle cx="${X+T_MINUS_X}" cy="${Y+T_MINUS_Y}" r="${TR}"
//                     fill="#111827" stroke="white" stroke-width="2"
//                     style="animation:panelIn 0.5s ${(delay+0.1).toFixed(2)}s both;"/>
//             <text x="${X+T_MINUS_X}" y="${Y+T_MINUS_Y+4}"
//                   text-anchor="middle" font-size="${TR+2}"
//                   fill="white" font-weight="900">−</text>`;
//         }
//     }

//     // ── 2. Series Wires ───────────────────────────────────────────
//     // Connect MINUS of panel[p][s] to PLUS of panel[p][s+1]
//     // Route: go RIGHT from minus → corner below → go UP to plus of next
//     // Each string uses its own horizontal lane BELOW the panels
//     for (let p = 0; p < parallel; p++) {
//         const laneY = seriesLaneY(p);

//         for (let s = 0; s < series - 1; s++) {
//             const from = minus[p][s];   // bottom-right of current panel
//             const to   = plus[p][s+1];  // top-right of next panel

//             // Route: from → go down to laneY → go right to to.x → go up to to.y
//             const path = `M ${from.x} ${from.y}
//                           L ${from.x} ${laneY}
//                           L ${to.x}   ${laneY}
//                           L ${to.x}   ${to.y}`;

//             series_wires += `
//             <!-- Series wire: P${p+1} S${s+1}→S${s+2} -->
//             <path d="${path}" fill="none"
//                   stroke="#F59E0B" stroke-width="3"
//                   stroke-linejoin="round" stroke-linecap="round"
//                   stroke-dasharray="8 4"
//                   style="animation:flowDash 1.4s linear infinite;
//                          filter:drop-shadow(0 0 3px #F59E0B88);">
//             </path>
//             <!-- Flow dot -->
//             <circle r="4" fill="#FCD34D">
//                 <animateMotion dur="1.6s" repeatCount="indefinite"
//                     begin="${(s*0.5).toFixed(1)}s"
//                     path="${path}"/>
//             </circle>
//             <circle r="4" fill="#FCD34D" opacity="0.6">
//                 <animateMotion dur="1.6s" repeatCount="indefinite"
//                     begin="${(s*0.5+0.8).toFixed(1)}s"
//                     path="${path}"/>
//             </circle>`;

//             // Corner dots
//             series_wires += `
//             <circle cx="${from.x}" cy="${laneY}" r="4" fill="#F59E0B"/>
//             <circle cx="${to.x}"   cy="${laneY}" r="4" fill="#F59E0B"/>`;
//         }
//     }

//     // ── 3. Parallel Bus Wires ─────────────────────────────────────
//     // Each string has:
//     //   - String POSITIVE = plus[p][0]  (top-right of FIRST panel)
//     //   - String NEGATIVE = minus[p][series-1] (bottom-right of LAST panel)
//     //
//     // We connect all string positives to BUS_PLUS_X vertical bus
//     // We connect all string negatives to BUS_MINUS_X vertical bus

//     // For 1S case: only one panel per string, terminals are already accessible
//     const stringPlusTerminal  = p => plus[p][0];          // first panel + terminal
//     const stringMinusTerminal = p => minus[p][series-1];  // last panel  − terminal

//     // Collect bus points
//     const busPlus  = [];  // {y} for each string
//     const busMinus = [];

//     for (let p = 0; p < parallel; p++) {
//         const PT = stringPlusTerminal(p);
//         const MT = stringMinusTerminal(p);

//         busPlus.push(PT.y);
//         busMinus.push(MT.y);

//         if (parallel === 1) {
//             // Single string → direct wire to inverter, no bus needed
//         } else {
//             // Horizontal wire: + terminal → BUS_PLUS_X
//             const plusPath = `M ${PT.x} ${PT.y} L ${BUS_PLUS_X} ${PT.y}`;
//             parallel_wires += `
//             <path d="${plusPath}" fill="none"
//                   stroke="#DC2626" stroke-width="3.5" stroke-linecap="round"
//                   style="filter:drop-shadow(0 0 4px #DC262688);"/>
//             <circle r="4" fill="#F87171">
//                 <animateMotion dur="1.8s" repeatCount="indefinite"
//                     begin="${(p*0.4).toFixed(1)}s" path="${plusPath}"/>
//             </circle>
//             <!-- Junction dot on bus -->
//             <circle cx="${BUS_PLUS_X}" cy="${PT.y}" r="5"
//                     fill="#DC2626" stroke="white" stroke-width="1.5"/>`;

//             // Horizontal wire: − terminal → BUS_MINUS_X
//             const minusPath = `M ${MT.x} ${MT.y} L ${BUS_MINUS_X} ${MT.y}`;
//             parallel_wires += `
//             <path d="${minusPath}" fill="none"
//                   stroke="#111827" stroke-width="3.5" stroke-linecap="round"
//                   style="filter:drop-shadow(0 0 4px #11182788);"/>
//             <circle r="4" fill="#6B7280">
//                 <animateMotion dur="1.8s" repeatCount="indefinite"
//                     begin="${(p*0.4+0.2).toFixed(1)}s" path="${minusPath}"/>
//             </circle>
//             <!-- Junction dot on bus -->
//             <circle cx="${BUS_MINUS_X}" cy="${MT.y}" r="5"
//                     fill="#111827" stroke="white" stroke-width="1.5"/>`;
//         }
//     }

//     // Draw vertical bus bars (parallel > 1 only)
//     if (parallel > 1) {
//         const plusTopY    = Math.min(...busPlus);
//         const plusBotY    = Math.max(...busPlus);
//         const minusTopY   = Math.min(...busMinus);
//         const minusBotY   = Math.max(...busMinus);

//         parallel_wires += `
//         <!-- Positive vertical bus bar -->
//         <line x1="${BUS_PLUS_X}" y1="${plusTopY}"
//               x2="${BUS_PLUS_X}" y2="${plusBotY}"
//               stroke="#DC2626" stroke-width="5" stroke-linecap="round"/>
//         <text x="${BUS_PLUS_X-8}" y="${(plusTopY+plusBotY)/2+4}"
//               text-anchor="end" font-size="9" fill="#DC2626" font-weight="800">BUS+</text>

//         <!-- Negative vertical bus bar -->
//         <line x1="${BUS_MINUS_X}" y1="${minusTopY}"
//               x2="${BUS_MINUS_X}" y2="${minusBotY}"
//               stroke="#111827" stroke-width="5" stroke-linecap="round"/>
//         <text x="${BUS_MINUS_X+8}" y="${(minusTopY+minusBotY)/2+4}"
//               text-anchor="start" font-size="9" fill="#374151" font-weight="800">BUS−</text>`;
//     }

//     // ── 4. Output Wires to Inverter ───────────────────────────────
//     const INV_CX = INV_X + INV_SIZE/2;
//     const INV_CY = INV_Y + INV_SIZE/2;

//     let outPlusX, outPlusY, outMinusX, outMinusY;

//     if (parallel === 1) {
//         // Single string: take + from first panel, − from last panel
//         outPlusX  = plus[0][0].x;
//         outPlusY  = plus[0][0].y;
//         outMinusX = minus[0][series-1].x;
//         outMinusY = minus[0][series-1].y;
//     } else {
//         // Multi-string: take from bus bars (midpoint)
//         outPlusX  = BUS_PLUS_X;
//         outPlusY  = busPlus[Math.floor(parallel/2)];
//         outMinusX = BUS_MINUS_X;
//         outMinusY = busMinus[Math.floor(parallel/2)];
//     }

//     // Route positive wire to inverter top-left terminal
//     const INV_IN_PLUS_Y  = INV_Y + INV_SIZE * 0.35;
//     const INV_IN_MINUS_Y = INV_Y + INV_SIZE * 0.65;

//     const plusOutPath  = `M ${outPlusX}  ${outPlusY}
//                           C ${outPlusX+50}  ${outPlusY},
//                             ${INV_X-30} ${INV_IN_PLUS_Y},
//                             ${INV_X}    ${INV_IN_PLUS_Y}`;
//     const minusOutPath = `M ${outMinusX} ${outMinusY}
//                           C ${outMinusX+50} ${outMinusY},
//                             ${INV_X-30} ${INV_IN_MINUS_Y},
//                             ${INV_X}    ${INV_IN_MINUS_Y}`;

//     const vLabel = panelConfig.string_voltage
//         ? panelConfig.string_voltage + 'V DC'
//         : `${series * (panel.vmp || 40)}V DC`;

//     output_wires = `
//     <!-- DC+ to inverter -->
//     <path d="${plusOutPath}" fill="none"
//           stroke="#DC2626" stroke-width="4" stroke-linecap="round"
//           style="filter:drop-shadow(0 0 5px #DC262699);"/>
//     ${[0, 0.45, 0.9].map(b => `
//     <circle r="5" fill="#F87171">
//         <animateMotion dur="1.4s" repeatCount="indefinite"
//             begin="${b}s" path="${plusOutPath}"/>
//     </circle>`).join('')}

//     <!-- DC− to inverter -->
//     <path d="${minusOutPath}" fill="none"
//           stroke="#111827" stroke-width="4" stroke-linecap="round"
//           style="filter:drop-shadow(0 0 5px #11182766);"/>
//     ${[0, 0.5].map(b => `
//     <circle r="5" fill="#6B7280">
//         <animateMotion dur="1.4s" repeatCount="indefinite"
//             begin="${b}s" path="${minusOutPath}"/>
//     </circle>`).join('')}

//     <!-- DC+ label -->
//     <rect x="${outPlusX+8}" y="${outPlusY-22}" width="38" height="16"
//           fill="#DC2626" rx="4"/>
//     <text x="${outPlusX+27}" y="${outPlusY-10}"
//           text-anchor="middle" font-size="9" fill="white" font-weight="800">DC+</text>

//     <!-- DC− label -->
//     <rect x="${outMinusX+8}" y="${outMinusY+6}" width="38" height="16"
//           fill="#111827" rx="4"/>
//     <text x="${outMinusX+27}" y="${outMinusY+18}"
//           text-anchor="middle" font-size="9" fill="white" font-weight="800">DC−</text>

//     <!-- Voltage label -->
//     <rect x="${(outPlusX+INV_X)/2-32}" y="${(INV_IN_PLUS_Y+INV_IN_MINUS_Y)/2-11}"
//           width="64" height="22" rx="5"
//           fill="white" stroke="#1E40AF" stroke-width="1.5"/>
//     <text x="${(outPlusX+INV_X)/2}" y="${(INV_IN_PLUS_Y+INV_IN_MINUS_Y)/2+4}"
//           text-anchor="middle" font-size="10" fill="#1E40AF" font-weight="800">
//         ${vLabel}
//     </text>

//     <!-- Inverter box -->
//     <rect x="${INV_X}" y="${INV_Y}" width="${INV_SIZE}" height="${INV_SIZE}"
//           rx="10" fill="#065F46" stroke="#10B981" stroke-width="2.5"
//           style="animation:invPulse 3s ease-in-out infinite;"/>
//     <!-- Inverter terminal marks -->
//     <rect x="${INV_X}" y="${INV_IN_PLUS_Y-4}"  width="6" height="8" fill="#DC2626"/>
//     <rect x="${INV_X}" y="${INV_IN_MINUS_Y-4}" width="6" height="8" fill="#374151"/>
//     <text x="${INV_CX}" y="${INV_CY+6}"
//           text-anchor="middle" font-size="24">⚡</text>
//     <text x="${INV_CX}" y="${INV_Y+INV_SIZE+14}"
//           text-anchor="middle" font-size="9"
//           fill="#065F46" font-weight="800" letter-spacing="0.06em">INVERTER</text>`;

//     // ── 5. Legend & title ─────────────────────────────────────────
//     const legend = `
//     <rect x="8" y="8" width="120" height="72" rx="6"
//           fill="white" fill-opacity="0.9" stroke="#E2E8F0" stroke-width="1"/>
//     <line x1="16" y1="24" x2="36" y2="24" stroke="#F59E0B" stroke-width="3"
//           stroke-dasharray="5 3"/>
//     <circle cx="44" cy="24" r="4" fill="#FCD34D"/>
//     <text x="52" y="28" font-size="10" fill="#78350F" font-weight="700">Series link</text>

//     <line x1="16" y1="44" x2="44" y2="44" stroke="#DC2626" stroke-width="3"/>
//     <circle cx="44" cy="44" r="4" fill="#DC2626"/>
//     <text x="52" y="48" font-size="10" fill="#7F1D1D" font-weight="700">Positive (+)</text>

//     <line x1="16" y1="64" x2="44" y2="64" stroke="#111827" stroke-width="3"/>
//     <circle cx="44" cy="64" r="4" fill="#374151"/>
//     <text x="52" y="68" font-size="10" fill="#111827" font-weight="700">Negative (−)</text>`;

//     // ── ASSEMBLE ──────────────────────────────────────────────────
//     return `
//     <svg viewBox="0 0 ${SVG_W} ${SVG_H}"
//          xmlns="http://www.w3.org/2000/svg"
//          style="width:100%; height:auto; min-height:200px; overflow:visible; background:#F8FAFF;">
//         <defs>
//             ${defs}
//             <style>
//                 @keyframes panelIn {
//                     from { opacity:0; transform:scale(0.88); }
//                     to   { opacity:1; transform:scale(1);    }
//                 }
//                 @keyframes flowDash {
//                     from { stroke-dashoffset: 24; }
//                     to   { stroke-dashoffset:  0; }
//                 }
//                 @keyframes invPulse {
//                     0%,100% { filter:drop-shadow(0 0 4px #10B981); }
//                     50%     { filter:drop-shadow(0 0 12px #10B981); }
//                 }
//             </style>
//         </defs>

//         <!-- Background grid -->
//         <defs>
//             <pattern id="bgGrid" width="20" height="20" patternUnits="userSpaceOnUse">
//                 <path d="M 20 0 L 0 0 0 20" fill="none"
//                       stroke="#E2E8F0" stroke-width="0.5"/>
//             </pattern>
//         </defs>
//         <rect width="${SVG_W}" height="${SVG_H}" fill="url(#bgGrid)"/>

//         <!-- Title -->
//         <text x="${SVG_W/2}" y="28" text-anchor="middle"
//               font-size="17" font-weight="900" fill="#0F172A" letter-spacing="0.03em">
//             ${series}S × ${parallel}P = ${totalPanels} Panels
//         </text>
//         <text x="${SVG_W/2}" y="48" text-anchor="middle"
//               font-size="12" fill="#64748B">
//             Each string: ${series} × ${panel.vmp||40}V = ${vLabel}
//         </text>

//         <!-- Draw order: wires first, panels on top -->
//         ${series_wires}
//         ${parallel_wires}
//         ${output_wires}
//         ${panels_svg}
//         ${legend}
//     </svg>`;
// }

function renderActualPanelLayout(panelConfig) {
    const { series, parallel, panel } = panelConfig;
    const totalPanels = series * parallel;

    // Panel dimensions
    let PW = 110, PH = 140;
    if (totalPanels > 6)  { PW = 90;  PH = 118; }
    if (totalPanels > 10) { PW = 72;  PH = 96;  }
    if (totalPanels > 16) { PW = 58;  PH = 78;  }

    const GAP_X = 60;    // gap between panels in series
    const GAP_Y = 80;    // gap between parallel strings
    const MARGIN_L = 80;
    const MARGIN_T = 90;

    // Terminal offsets within panel
    // + terminal: TOP-LEFT corner area
    // - terminal: BOTTOM-RIGHT corner area
    // This makes series wiring natural: - (bottom-right) connects to + (top-left) of next
    const T_PLUS_X  = 18;       // left side
    const T_PLUS_Y  = 18;       // top
    const T_MINUS_X = PW - 18;  // right side
    const T_MINUS_Y = PH - 18;  // bottom

    const TR = totalPanels > 10 ? 7 : 9;

    // Panel top-left origin
    const px = s => MARGIN_L + s * (PW + GAP_X);
    const py = p => MARGIN_T + p * (PH + GAP_Y);

    // World coordinates of each terminal
    const tPlus = (p, s) => ({
        x: px(s) + T_PLUS_X,
        y: py(p) + T_PLUS_Y
    });
    const tMinus = (p, s) => ({
        x: px(s) + T_MINUS_X,
        y: py(p) + T_MINUS_Y
    });

    // Canvas sizing
    // Right bus is to the right of last panel column
    const LAST_PANEL_RIGHT = px(series - 1) + PW;
    const BUS_PLUS_X  = LAST_PANEL_RIGHT + 36;
    const BUS_MINUS_X = LAST_PANEL_RIGHT + 60;
    const INV_X       = LAST_PANEL_RIGHT + 130;
    const INV_SIZE    = 60;

    const SVG_W = INV_X + INV_SIZE + 70;
    const SVG_H = MARGIN_T + parallel * (PH + GAP_Y) - GAP_Y + 80;
    const INV_Y = (SVG_H - INV_SIZE) / 2;

    const vLabel = panelConfig.string_voltage
        ? panelConfig.string_voltage + 'V DC'
        : `${(series * (panel.vmp || 40)).toFixed(1)}V DC`;

    // ── Build SVG pieces ─────────────────────────────────────────
    let svgPanels = '';
    let svgSeries = '';
    let svgParallel = '';
    let svgOutput = '';

    // ── 1. Panels ────────────────────────────────────────────────
    const wattFontSize = totalPanels > 12 ? 11 : 14;
    const badgeW = totalPanels > 12 ? 44 : 54;
    const badgeH = totalPanels > 12 ? 18 : 22;

    for (let p = 0; p < parallel; p++) {
        for (let s = 0; s < series; s++) {
            const X = px(s), Y = py(p);
            const delay = (p * series + s) * 0.07;
            const tp = tPlus(p, s);
            const tm = tMinus(p, s);

            svgPanels += `
            <g style="animation:panelIn 0.5s ${delay.toFixed(2)}s ease-out both;">
                <!-- Panel frame with shadow -->
                <rect x="${X+2}" y="${Y+3}" width="${PW}" height="${PH}"
                      rx="6" fill="rgba(0,0,0,0.15)"/>
                <rect x="${X}" y="${Y}" width="${PW}" height="${PH}"
                      rx="6" fill="url(#pg${p}_${s})"
                      stroke="#1E40AF" stroke-width="2.5"/>
                <!-- Panel frame border (aluminum effect) -->
                <rect x="${X+2}" y="${Y+2}" width="${PW-4}" height="${PH-4}"
                      rx="4" fill="none" stroke="#93C5FD" stroke-width="0.8" opacity="0.5"/>
                <!-- Solar cells grid -->
                <rect x="${X+8}" y="${Y+8}" width="${PW-16}" height="${PH-38}"
                      fill="url(#cells)" stroke="#1E40AF" stroke-width="1" rx="3"/>
                <!-- Center busbar line -->
                <line x1="${X+PW/2}" y1="${Y+10}" x2="${X+PW/2}" y2="${Y+PH-32}"
                      stroke="#60A5FA" stroke-width="1.5" opacity="0.6"/>
                <!-- Glass reflection -->
                <rect x="${X}" y="${Y}" width="${PW}" height="${PH}"
                      rx="6" fill="url(#panelGloss)" pointer-events="none"/>
                <!-- Junction box at bottom -->
                <rect x="${X+PW/2-14}" y="${Y+PH-8}" width="28" height="10"
                      fill="#374151" rx="3" stroke="#1F2937" stroke-width="1"/>
                <circle cx="${X+PW/2-5}" cy="${Y+PH-3}" r="2" fill="#6B7280"/>
                <circle cx="${X+PW/2+5}" cy="${Y+PH-3}" r="2" fill="#6B7280"/>
                <!-- Panel label: Prow,Col -->
                <text x="${X+PW/2}" y="${Y+PH/2}"
                      text-anchor="middle" font-size="9" fill="#1E40AF88"
                      font-weight="700">P${p+1},${s+1}</text>
                ${s===0 && parallel>1 ? `
                <text x="${X-10}" y="${Y+PH/2+5}"
                      text-anchor="end" font-size="11"
                      fill="#1E40AF" font-weight="700">STR${p+1}</text>` : ''}
            </g>
            <!-- Watt badge (prominent, above panel) -->
            <rect x="${X+PW/2-badgeW/2}" y="${Y-badgeH/2-2}" width="${badgeW}" height="${badgeH}"
                  rx="${badgeH/2}" fill="#1E40AF" stroke="#BFDBFE" stroke-width="1.5"
                  style="filter:drop-shadow(0 2px 4px rgba(30,64,175,0.4));"/>
            <text x="${X+PW/2}" y="${Y-2+badgeH/4}"
                  text-anchor="middle" font-size="${wattFontSize}"
                  fill="white" font-weight="900" letter-spacing="0.03em">${panel.watt_peak}W</text>
            <!-- + terminal (top-left) -->
            <circle cx="${tp.x}" cy="${tp.y}" r="${TR}"
                    fill="#DC2626" stroke="white" stroke-width="2"
                    style="filter:drop-shadow(0 1px 3px rgba(220,38,38,0.5));"/>
            <text x="${tp.x}" y="${tp.y+4}" text-anchor="middle"
                  font-size="${TR+2}" fill="white" font-weight="900">+</text>
            <!-- − terminal (bottom-right) -->
            <circle cx="${tm.x}" cy="${tm.y}" r="${TR}"
                    fill="#111827" stroke="white" stroke-width="2"
                    style="filter:drop-shadow(0 1px 3px rgba(17,24,39,0.5));"/>
            <text x="${tm.x}" y="${tm.y+4}" text-anchor="middle"
                  font-size="${TR+2}" fill="white" font-weight="900">−</text>`;
        }
    }

    // ── 2. Series wires ──────────────────────────────────────────
    for (let p = 0; p < parallel; p++) {
        for (let s = 0; s < series - 1; s++) {
            const from = tMinus(p, s);
            const to   = tPlus(p, s + 1);
            const midX = px(s) + PW + GAP_X / 2;

            const path = [
                `M ${from.x} ${from.y}`,
                `C ${from.x+12} ${from.y}, ${midX} ${from.y}, ${midX} ${from.y}`,
                `L ${midX}   ${to.y}`,
                `C ${midX} ${to.y}, ${to.x-12} ${to.y}, ${to.x} ${to.y}`
            ].join(' ');

            svgSeries += `
            <!-- Cable conduit background -->
            <path d="${path}" fill="none"
                  stroke="#78350F" stroke-width="7" stroke-linecap="round"
                  stroke-linejoin="round" opacity="0.25"/>
            <!-- Main cable -->
            <path d="${path}" fill="none"
                  stroke="#F59E0B" stroke-width="4.5" stroke-linecap="round"
                  stroke-linejoin="round"
                  style="filter:drop-shadow(0 1px 3px #F59E0B88);"/>
            <!-- Inner highlight -->
            <path d="${path}" fill="none"
                  stroke="#FDE68A" stroke-width="1.5" stroke-linecap="round"
                  opacity="0.5"/>
            <!-- Animated flow particles -->
            <circle r="4.5" fill="#FCD34D" opacity="0.95"
                    style="filter:drop-shadow(0 0 4px #FCD34D);">
                <animateMotion dur="1.3s" repeatCount="indefinite"
                    begin="${(s * 0.4).toFixed(1)}s" path="${path}"/>
            </circle>
            <circle r="3" fill="#FEF3C7" opacity="0.7">
                <animateMotion dur="1.3s" repeatCount="indefinite"
                    begin="${(s * 0.4 + 0.65).toFixed(1)}s" path="${path}"/>
            </circle>
            <!-- Cable clips at corners -->
            <rect x="${midX-5}" y="${from.y-3}" width="10" height="6"
                  rx="2" fill="#78350F" opacity="0.7"/>
            <rect x="${midX-5}" y="${to.y-3}" width="10" height="6"
                  rx="2" fill="#78350F" opacity="0.7"/>`;
        }
    }

    // ── 3. Parallel bus wires ────────────────────────────────────
    // String positive output = plus[p][0]   (top-left of FIRST panel)
    // String negative output = minus[p][last] (bottom-right of LAST panel)
    //
    // Each string's + goes RIGHT to BUS_PLUS_X  (red vertical bus)
    // Each string's − goes RIGHT to BUS_MINUS_X (black vertical bus)

    const busYPlus  = [];
    const busYMinus = [];

    for (let p = 0; p < parallel; p++) {
        const strPlusT  = tPlus(p, 0);            // first panel + of string p
        const strMinusT = tMinus(p, series - 1);  // last panel  − of string p

        if (parallel === 1) {
            // No bus needed for single string
            busYPlus.push(strPlusT.y);
            busYMinus.push(strMinusT.y);
            continue;
        }

        busYPlus.push(strPlusT.y);
        busYMinus.push(strMinusT.y);

        const laneAbove = py(p) - 20;

        const plusPath = [
            `M ${strPlusT.x}  ${strPlusT.y}`,
            `L ${strPlusT.x}  ${laneAbove}`,
            `L ${BUS_PLUS_X}  ${laneAbove}`,
            `L ${BUS_PLUS_X}  ${strPlusT.y}`
        ].join(' ');

        svgParallel += `
        <!-- String ${p+1} + cable conduit -->
        <path d="${plusPath}" fill="none"
              stroke="#7F1D1D" stroke-width="7" stroke-linecap="round"
              stroke-linejoin="round" opacity="0.2"/>
        <path d="${plusPath}" fill="none"
              stroke="#DC2626" stroke-width="4.5" stroke-linecap="round"
              stroke-linejoin="round"
              style="filter:drop-shadow(0 1px 4px #DC262677);"/>
        <path d="${plusPath}" fill="none"
              stroke="#FCA5A5" stroke-width="1.5" stroke-linecap="round"
              opacity="0.4"/>
        <circle r="4.5" fill="#F87171"
                style="filter:drop-shadow(0 0 3px #F87171);">
            <animateMotion dur="1.8s" repeatCount="indefinite"
                begin="${(p * 0.45).toFixed(1)}s" path="${plusPath}"/>
        </circle>
        <!-- Junction connector at bus -->
        <rect x="${BUS_PLUS_X-7}" y="${strPlusT.y-7}" width="14" height="14"
              rx="3" fill="#DC2626" stroke="white" stroke-width="1.5"
              style="filter:drop-shadow(0 1px 3px rgba(220,38,38,0.4));"/>
        <text x="${BUS_PLUS_X}" y="${strPlusT.y+4}" text-anchor="middle"
              font-size="9" fill="white" font-weight="900">+</text>`;

        const minusPath = [
            `M ${strMinusT.x}  ${strMinusT.y}`,
            `L ${BUS_MINUS_X}  ${strMinusT.y}`
        ].join(' ');

        svgParallel += `
        <!-- String ${p+1} − cable conduit -->
        <path d="${minusPath}" fill="none"
              stroke="#111827" stroke-width="7" stroke-linecap="round"
              opacity="0.2"/>
        <path d="${minusPath}" fill="none"
              stroke="#374151" stroke-width="4.5" stroke-linecap="round"
              style="filter:drop-shadow(0 1px 4px #11182755);"/>
        <path d="${minusPath}" fill="none"
              stroke="#9CA3AF" stroke-width="1.5" stroke-linecap="round"
              opacity="0.3"/>
        <circle r="4.5" fill="#9CA3AF"
                style="filter:drop-shadow(0 0 3px #6B7280);">
            <animateMotion dur="1.8s" repeatCount="indefinite"
                begin="${(p * 0.45 + 0.25).toFixed(1)}s" path="${minusPath}"/>
        </circle>
        <!-- Junction connector at bus -->
        <rect x="${BUS_MINUS_X-7}" y="${strMinusT.y-7}" width="14" height="14"
              rx="3" fill="#1F2937" stroke="white" stroke-width="1.5"
              style="filter:drop-shadow(0 1px 3px rgba(31,41,55,0.4));"/>
        <text x="${BUS_MINUS_X}" y="${strMinusT.y+4}" text-anchor="middle"
              font-size="9" fill="white" font-weight="900">−</text>`;
    }

    // Draw vertical bus bars
    if (parallel > 1) {
        const plusTopY  = Math.min(...busYPlus);
        const plusBotY  = Math.max(...busYPlus);
        const minusTopY = Math.min(...busYMinus);
        const minusBotY = Math.max(...busYMinus);

        svgParallel += `
        <!-- BUS+ vertical bar -->
        <line x1="${BUS_PLUS_X}" y1="${plusTopY}"
              x2="${BUS_PLUS_X}" y2="${plusBotY}"
              stroke="#DC2626" stroke-width="6" stroke-linecap="round"
              style="filter:drop-shadow(0 0 4px #DC262688);"/>
        <rect x="${BUS_PLUS_X-22}" y="${(plusTopY+plusBotY)/2-9}"
              width="20" height="18" rx="4" fill="#DC2626"/>
        <text x="${BUS_PLUS_X-12}" y="${(plusTopY+plusBotY)/2+5}"
              text-anchor="middle" font-size="9" fill="white" font-weight="800">BUS+</text>

        <!-- BUS− vertical bar -->
        <line x1="${BUS_MINUS_X}" y1="${minusTopY}"
              x2="${BUS_MINUS_X}" y2="${minusBotY}"
              stroke="#1F2937" stroke-width="6" stroke-linecap="round"/>
        <rect x="${BUS_MINUS_X+2}" y="${(minusTopY+minusBotY)/2-9}"
              width="22" height="18" rx="4" fill="#1F2937"/>
        <text x="${BUS_MINUS_X+13}" y="${(minusTopY+minusBotY)/2+5}"
              text-anchor="middle" font-size="9" fill="white" font-weight="800">BUS−</text>`;
    }

    // ── 4. Output wires to inverter ──────────────────────────────
    let outPX, outPY, outMX, outMY;

    if (parallel === 1) {
        const spt = tPlus(0, 0);
        const smt = tMinus(0, series - 1);
        outPX = spt.x; outPY = spt.y;
        outMX = smt.x; outMY = smt.y;
    } else {
        // Take mid-string from bus
        const mid = Math.floor(parallel / 2);
        outPX = BUS_PLUS_X;  outPY = busYPlus[mid]  ?? busYPlus[0];
        outMX = BUS_MINUS_X; outMY = busYMinus[mid] ?? busYMinus[0];
    }

    const INV_CX = INV_X + INV_SIZE / 2;
    const INV_CY = INV_Y + INV_SIZE / 2;
    const INV_IN_PY = INV_Y + INV_SIZE * 0.33;
    const INV_IN_MY = INV_Y + INV_SIZE * 0.67;

    const plusOutPath  = `M ${outPX} ${outPY} C ${outPX+50} ${outPY}, ${INV_X-40} ${INV_IN_PY}, ${INV_X} ${INV_IN_PY}`;
    const minusOutPath = `M ${outMX} ${outMY} C ${outMX+50} ${outMY}, ${INV_X-40} ${INV_IN_MY}, ${INV_X} ${INV_IN_MY}`;

    svgOutput = `
    <!-- DC+ cable conduit to inverter -->
    <path d="${plusOutPath}" fill="none"
          stroke="#7F1D1D" stroke-width="9" stroke-linecap="round" opacity="0.2"/>
    <path d="${plusOutPath}" fill="none"
          stroke="#DC2626" stroke-width="5.5" stroke-linecap="round"
          style="filter:drop-shadow(0 2px 6px #DC262699);"/>
    <path d="${plusOutPath}" fill="none"
          stroke="#FCA5A5" stroke-width="2" stroke-linecap="round" opacity="0.4"/>
    ${[0, 0.47, 0.94].map(b => `
    <circle r="5.5" fill="#FCD34D" opacity="0.9"
            style="filter:drop-shadow(0 0 5px #FCD34D);">
        <animateMotion dur="1.4s" repeatCount="indefinite"
            begin="${b}s" path="${plusOutPath}"/>
    </circle>`).join('')}

    <!-- DC− cable conduit to inverter -->
    <path d="${minusOutPath}" fill="none"
          stroke="#111827" stroke-width="9" stroke-linecap="round" opacity="0.2"/>
    <path d="${minusOutPath}" fill="none"
          stroke="#374151" stroke-width="5.5" stroke-linecap="round"
          style="filter:drop-shadow(0 2px 5px #11182766);"/>
    <path d="${minusOutPath}" fill="none"
          stroke="#9CA3AF" stroke-width="2" stroke-linecap="round" opacity="0.3"/>
    ${[0, 0.7].map(b => `
    <circle r="5" fill="#9CA3AF" opacity="0.85"
            style="filter:drop-shadow(0 0 4px #6B7280);">
        <animateMotion dur="1.4s" repeatCount="indefinite"
            begin="${b}s" path="${minusOutPath}"/>
    </circle>`).join('')}

    <!-- DC+/DC− labels near output -->
    <rect x="${outPX + (parallel===1?-50:8)}" y="${outPY - 22}"
          width="38" height="17" fill="#DC2626" rx="4"/>
    <text x="${outPX + (parallel===1?-31:27)}" y="${outPY - 9}"
          text-anchor="middle" font-size="10" fill="white" font-weight="800">DC+</text>

    <rect x="${outMX + (parallel===1?-50:8)}" y="${outMY + 6}"
          width="38" height="17" fill="#111827" rx="4"/>
    <text x="${outMX + (parallel===1?-31:27)}" y="${outMY + 18}"
          text-anchor="middle" font-size="10" fill="white" font-weight="800">DC−</text>

    <!-- Voltage label -->
    <rect x="${(outPX + INV_X)/2 - 36}" y="${(INV_IN_PY + INV_IN_MY)/2 - 12}"
          width="72" height="24" rx="6"
          fill="white" stroke="#1E40AF" stroke-width="1.8"/>
    <text x="${(outPX + INV_X)/2}" y="${(INV_IN_PY + INV_IN_MY)/2 + 5}"
          text-anchor="middle" font-size="11" fill="#1E40AF" font-weight="800">
        ${vLabel}
    </text>

    <!-- Inverter -->
    <rect x="${INV_X}" y="${INV_Y}" width="${INV_SIZE}" height="${INV_SIZE}"
          rx="10" fill="#065F46" stroke="#10B981" stroke-width="2.5"
          style="animation:invPulse 3s ease-in-out infinite;"/>
    <rect x="${INV_X}" y="${INV_IN_PY - 4}" width="7" height="8" fill="#DC2626"/>
    <rect x="${INV_X}" y="${INV_IN_MY - 4}" width="7" height="8" fill="#374151"/>
    <text x="${INV_CX}" y="${INV_CY + 8}" text-anchor="middle" font-size="26">⚡</text>
    <text x="${INV_CX}" y="${INV_Y + INV_SIZE + 16}"
          text-anchor="middle" font-size="10"
          fill="#065F46" font-weight="900" letter-spacing="0.05em">INVERTER</text>`;

    // ── Legend ───────────────────────────────────────────────────
    const legend = `
    <rect x="6" y="6" width="148" height="96" rx="8"
          fill="white" fill-opacity="0.97" stroke="#CBD5E1" stroke-width="1.5"
          style="filter:drop-shadow(0 2px 6px rgba(0,0,0,0.08));"/>
    <text x="14" y="22" font-size="11" fill="#0F172A" font-weight="900">LEGEND</text>
    <line x1="14" y1="38" x2="38" y2="38" stroke="#F59E0B" stroke-width="4.5"
          stroke-linecap="round"/>
    <circle cx="44" cy="38" r="4" fill="#FCD34D"
            style="filter:drop-shadow(0 0 3px #FCD34D);"/>
    <text x="54" y="42" font-size="10" fill="#78350F" font-weight="700">Series cable</text>
    <line x1="14" y1="58" x2="38" y2="58" stroke="#DC2626" stroke-width="4.5"
          stroke-linecap="round"/>
    <circle cx="44" cy="58" r="4" fill="#F87171"
            style="filter:drop-shadow(0 0 3px #F87171);"/>
    <text x="54" y="62" font-size="10" fill="#7F1D1D" font-weight="700">Positive (+)</text>
    <line x1="14" y1="78" x2="38" y2="78" stroke="#374151" stroke-width="4.5"
          stroke-linecap="round"/>
    <circle cx="44" cy="78" r="4" fill="#9CA3AF"
            style="filter:drop-shadow(0 0 3px #6B7280);"/>
    <text x="54" y="82" font-size="10" fill="#111827" font-weight="700">Negative (−)</text>`;

    // ── Defs ─────────────────────────────────────────────────────
    const defs = buildDefs(parallel, series, PW, PH, totalPanels);

    return `
    <svg viewBox="0 0 ${SVG_W} ${SVG_H}"
         xmlns="http://www.w3.org/2000/svg"
         style="width:100%; height:auto; min-height:220px;
                overflow:visible; background:#F8FAFF;">
        <defs>
            ${defs}
            <pattern id="bgGrid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none"
                      stroke="#E2E8F0" stroke-width="0.5"/>
            </pattern>
            <style>
                @keyframes panelIn {
                    from { opacity:0; transform:scale(0.85); }
                    to   { opacity:1; transform:scale(1); }
                }
                @keyframes flowDash {
                    from { stroke-dashoffset:26; }
                    to   { stroke-dashoffset:0; }
                }
                @keyframes invPulse {
                    0%,100% { filter:drop-shadow(0 0 4px #10B981); }
                    50%     { filter:drop-shadow(0 0 14px #10B981); }
                }
                @keyframes cableGlow {
                    0%,100% { opacity:0.4; }
                    50%     { opacity:0.7; }
                }
            </style>
        </defs>

        <rect width="${SVG_W}" height="${SVG_H}" fill="url(#bgGrid)"/>

        <!-- Title -->
        <text x="${SVG_W/2}" y="30" text-anchor="middle"
              font-size="18" font-weight="900" fill="#0F172A" letter-spacing="0.02em">
            ${series}S × ${parallel}P = ${totalPanels} Panels
        </text>
        <text x="${SVG_W/2}" y="52" text-anchor="middle"
              font-size="12" fill="#64748B">
            ${series} panels in series per string •
            ${parallel} string${parallel>1?'s':''} in parallel •
            String voltage: ${vLabel}
        </text>

        <!-- Wires behind panels -->
        ${svgSeries}
        ${svgParallel}
        ${svgOutput}

        <!-- Panels on top -->
        ${svgPanels}

        ${legend}
    </svg>`;
}


// ─── Defs builder ────────────────────────────────────────────────────────────
function buildDefs(parallel, series, PW, PH, totalPanels) {
    const cellSize = totalPanels > 12 ? 9 : 12;
    const cellInner = totalPanels > 12 ? 7 : 10;
    let d = `
    <!-- Cell pattern (realistic grid) -->
    <pattern id="cells" x="0" y="0"
        width="${cellSize}" height="${cellSize}"
        patternUnits="userSpaceOnUse">
        <rect width="${cellInner}" height="${cellInner}"
              fill="#1E3A8A" stroke="#2563EB" stroke-width="0.4" rx="0.5"/>
        <line x1="0" y1="${cellInner/2}" x2="${cellInner}" y2="${cellInner/2}"
              stroke="#3B82F6" stroke-width="0.3" opacity="0.5"/>
    </pattern>
    <!-- Glass reflection overlay -->
    <linearGradient id="panelGloss" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%"   stop-color="white" stop-opacity="0.2"/>
        <stop offset="40%"  stop-color="white" stop-opacity="0"/>
        <stop offset="60%"  stop-color="white" stop-opacity="0"/>
        <stop offset="100%" stop-color="white" stop-opacity="0.08"/>
    </linearGradient>`;

    for (let p = 0; p < parallel; p++) {
        for (let s = 0; s < series; s++) {
            const hue1 = 210 + p * 6 + s * 2;
            d += `
            <linearGradient id="pg${p}_${s}" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%"   stop-color="hsl(${hue1},75%,82%)"/>
                <stop offset="50%"  stop-color="hsl(${hue1},80%,70%)"/>
                <stop offset="100%" stop-color="hsl(${hue1},85%,60%)"/>
            </linearGradient>`;
        }
    }
    return d;
}


// ============================================================
// BATTERY WIRING DIAGRAM
// ============================================================
/**
 * Render battery bank wiring with correct series/parallel connections
 * Shows actual battery cells connected with colored wires
 */
/**
 * Render the battery bank wiring diagram
 * Shows realistic series/parallel connections with animated current flow
 */


function renderBatteryWiringDiagram(batteryConfig, inverterVoltage) {
    const { quantity, battery, wiring, total_ah } = batteryConfig;
    const batV = battery.voltage || 12;

    // ── Parse Series / Parallel ─────────────────────────────────
    let batSeries   = 1;
    let batParallel = quantity;

    // Prefer explicit series/parallel fields from configurator
    if (batteryConfig.series && batteryConfig.parallel) {
        batSeries = batteryConfig.series;
        batParallel = batteryConfig.parallel;
    } else {
        const spMatch = (wiring || '').match(/(\d+)\s*S\s*(\d+)\s*P/i);
        if (spMatch) {
            batSeries   = parseInt(spMatch[1]);
            batParallel = parseInt(spMatch[2]);
        } else if (/series/i.test(wiring)) {
            const m = (wiring || '').match(/(\d+)/);
            batSeries   = m ? parseInt(m[1]) : quantity;
            batParallel = Math.max(1, Math.floor(quantity / batSeries));
        } else if (/parallel/i.test(wiring)) {
            const m = (wiring || '').match(/(\d+)/);
            batParallel = m ? parseInt(m[1]) : quantity;
            batSeries   = Math.max(1, Math.floor(quantity / batParallel));
        } else {
            const invV = parseInt(String(inverterVoltage).replace(/[^0-9]/g, '')) || 48;
            batSeries   = Math.max(1, Math.round(invV / batV));
            batParallel = Math.max(1, Math.floor(quantity / batSeries));
        }
    }

    const usedBatteries = batSeries * batParallel;
    const totalVolts    = batSeries * batV;

    // ── Layout ──────────────────────────────────────────────────
    const BW    = 100;
    const BH    =  52;
    const GAP_X =  44;
    const GAP_Y =  90;
    const ML    = 120;
    const MT    = 110;   // extra top margin for title

    const NEG_TX = 10;
    const POS_TX = BW - 10;
    const TY     = BH / 2;
    const TR     = 9;

    const bx = s => ML + s * (BW + GAP_X);
    const by = p => MT + p * (BH + GAP_Y);

    const tPos = (p, s) => ({ x: bx(s) + POS_TX, y: by(p) + TY });
    const tNeg = (p, s) => ({ x: bx(s) + NEG_TX, y: by(p) + TY });

    // ── Bus positions ────────────────────────────────────────────
    const BUS_P_X = bx(batSeries - 1) + BW + 36;
    const BUS_N_X = ML - 36;

    // ── Inverter ─────────────────────────────────────────────────
    const INV_W     = 68;
    const INV_H     = 68;
    const INV_X     = BUS_P_X + 60;

    // ── Legend dimensions (fixed) ────────────────────────────────
    const LEG_W  = 188;
    const LEG_H  = 112;
    const LEG_PAD = 16;   // padding from edges

    // ── SVG sizing ───────────────────────────────────────────────
    // DIAGRAM content height (batteries + gaps)
    const DIAGRAM_H = MT + batParallel * (BH + GAP_Y) - GAP_Y;

    // Extra bottom space: room for − wire routing + legend row
    const BOTTOM_WIRE_SPACE = 60;
    const LEGEND_ROW_H      = LEG_H + 24;   // legend + gap above it

    const SVG_W = Math.max(
        INV_X + INV_W + 60,
        ML + batSeries * (BW + GAP_X) + 200
    );
    // Total height = diagram + bottom wire channel + legend strip
    const SVG_H = DIAGRAM_H + BOTTOM_WIRE_SPACE + LEGEND_ROW_H + 20;

    const INV_Y     = (DIAGRAM_H - INV_H) / 2 + MT / 2;
    const INV_CX    = INV_X + INV_W / 2;
    const INV_CY    = INV_Y + INV_H / 2;
    const INV_IN_PY = INV_Y + INV_H * 0.28;
    const INV_IN_NY = INV_Y + INV_H * 0.72;

    // ── Legend position — BOTTOM of SVG, left-aligned, clear of all wires ──
    const LEG_X = LEG_PAD;
    const LEG_Y = SVG_H - LEG_H - LEG_PAD;

    // ── Layers ───────────────────────────────────────────────────
    let svgWiresSeries   = '';
    let svgWiresParallel = '';
    let svgBusBars       = '';
    let svgOutput        = '';
    let svgBatteries     = '';

    // ════════════════════════════════════════════════════════════
    // LAYER 1 — SERIES WIRES
    // ════════════════════════════════════════════════════════════
    for (let p = 0; p < batParallel; p++) {
        for (let s = 0; s < batSeries - 1; s++) {
            const from     = tPos(p, s);
            const to       = tNeg(p, s + 1);
            const midX     = (from.x + to.x) / 2;
            const animPath = `M ${from.x} ${from.y} L ${to.x} ${to.y}`;

            svgWiresSeries += `
            <!-- Series STR${p+1}: B${s+1}(+) → B${s+2}(−) -->
            <line x1="${from.x}" y1="${from.y}"
                  x2="${to.x}"   y2="${to.y}"
                  stroke="#F59E0B" stroke-width="4"
                  stroke-linecap="round"
                  style="filter:drop-shadow(0 0 3px #F59E0B99);"/>
            <polygon
                points="${midX-6},${from.y-6} ${midX+8},${from.y} ${midX-6},${from.y+6}"
                fill="#F59E0B"/>
            <circle r="5" fill="#FDE68A" opacity="0.9">
                <animateMotion dur="1s" repeatCount="indefinite"
                    begin="${(p * 0.25 + s * 0.12).toFixed(2)}s"
                    path="${animPath}"/>
            </circle>`;
        }
    }

    // ════════════════════════════════════════════════════════════
    // LAYER 2 — PARALLEL WIRES TO BUS BARS
    // ════════════════════════════════════════════════════════════
    const busPY = [];
    const busNY = [];

    for (let p = 0; p < batParallel; p++) {
        const strPlusTerm  = tPos(p, batSeries - 1);
        const strMinusTerm = tNeg(p, 0);

        busPY.push(strPlusTerm.y);
        busNY.push(strMinusTerm.y);

        if (batParallel > 1) {
            const pPath = `M ${strPlusTerm.x} ${strPlusTerm.y} L ${BUS_P_X} ${strPlusTerm.y}`;
            svgWiresParallel += `
            <!-- STR${p+1} (+) → BUS+ -->
            <line x1="${strPlusTerm.x}" y1="${strPlusTerm.y}"
                  x2="${BUS_P_X}"       y2="${strPlusTerm.y}"
                  stroke="#DC2626" stroke-width="3.5" stroke-linecap="round"
                  style="filter:drop-shadow(0 0 4px #DC262666);"/>
            <circle r="4" fill="#F87171">
                <animateMotion dur="1.4s" repeatCount="indefinite"
                    begin="${(p * 0.35).toFixed(2)}s" path="${pPath}"/>
            </circle>
            <circle cx="${BUS_P_X}" cy="${strPlusTerm.y}"
                    r="7" fill="#DC2626" stroke="white" stroke-width="2"/>`;

            const nPath = `M ${strMinusTerm.x} ${strMinusTerm.y} L ${BUS_N_X} ${strMinusTerm.y}`;
            svgWiresParallel += `
            <!-- STR${p+1} (−) → BUS− -->
            <line x1="${strMinusTerm.x}" y1="${strMinusTerm.y}"
                  x2="${BUS_N_X}"        y2="${strMinusTerm.y}"
                  stroke="#1F2937" stroke-width="3.5" stroke-linecap="round"
                  style="filter:drop-shadow(0 0 3px #11182744);"/>
            <circle r="4" fill="#6B7280">
                <animateMotion dur="1.4s" repeatCount="indefinite"
                    begin="${(p * 0.35 + 0.2).toFixed(2)}s" path="${nPath}"/>
            </circle>
            <circle cx="${BUS_N_X}" cy="${strMinusTerm.y}"
                    r="7" fill="#1F2937" stroke="white" stroke-width="2"/>`;
        }
    }

    // ── Vertical bus bars ────────────────────────────────────────
    if (batParallel > 1) {
        const pTop  = Math.min(...busPY) - 14;
        const pBot  = Math.max(...busPY) + 14;
        const nTop  = Math.min(...busNY) - 14;
        const nBot  = Math.max(...busNY) + 14;
        const pMidY = (pTop + pBot) / 2;
        const nMidY = (nTop + nBot) / 2;

        svgBusBars += `
        <!-- POSITIVE BUS -->
        <line x1="${BUS_P_X}" y1="${pTop}" x2="${BUS_P_X}" y2="${pBot}"
              stroke="#DC2626" stroke-width="9" stroke-linecap="round"
              style="filter:drop-shadow(0 0 6px #DC262688);"/>
        <rect x="${BUS_P_X+10}" y="${pMidY-12}" width="40" height="24" rx="6" fill="#DC2626"/>
        <text x="${BUS_P_X+30}" y="${pMidY+5}"
              text-anchor="middle" font-size="10" fill="white" font-weight="900">BUS+</text>

        <!-- NEGATIVE BUS -->
        <line x1="${BUS_N_X}" y1="${nTop}" x2="${BUS_N_X}" y2="${nBot}"
              stroke="#1F2937" stroke-width="9" stroke-linecap="round"
              style="filter:drop-shadow(0 0 5px #11182766);"/>
        <rect x="${BUS_N_X-50}" y="${nMidY-12}" width="40" height="24" rx="6" fill="#1F2937"/>
        <text x="${BUS_N_X-30}" y="${nMidY+5}"
              text-anchor="middle" font-size="10" fill="white" font-weight="900">BUS−</text>`;
    }

    // ════════════════════════════════════════════════════════════
    // LAYER 3 — OUTPUT TO INVERTER
    // ════════════════════════════════════════════════════════════
    let outPX, outPY, outNX, outNY;

    if (batParallel === 1) {
        outPX = tPos(0, batSeries - 1).x;
        outPY = tPos(0, batSeries - 1).y;
        outNX = tNeg(0, 0).x;
        outNY = tNeg(0, 0).y;
    } else {
        const mid = Math.floor(batParallel / 2);
        outPX = BUS_P_X;  outPY = busPY[mid] ?? busPY[0];
        outNX = BUS_N_X;  outNY = busNY[mid] ?? busNY[0];
    }

    // + wire: straight right from bus/terminal to inverter + tab
    const pOutPath = [
        `M ${outPX} ${outPY}`,
        `C ${outPX+40} ${outPY},`,
        `  ${INV_X-40} ${INV_IN_PY},`,
        `  ${INV_X} ${INV_IN_PY}`
    ].join(' ');

    // − wire: go left → drop below all batteries → go right under → up to inverter
    const nBotY    = DIAGRAM_H + 40;   // wire channel BELOW all batteries
    const nOutPath = [
        `M ${outNX} ${outNY}`,
        `L ${BUS_N_X - 28} ${outNY}`,
        `L ${BUS_N_X - 28} ${nBotY}`,
        `L ${INV_X + INV_W/2} ${nBotY}`,
        `L ${INV_X + INV_W/2} ${INV_IN_NY}`,
        `L ${INV_X} ${INV_IN_NY}`
    ].join(' ');

    svgOutput = `
    <!-- DC+ wire -->
    <path d="${pOutPath}" fill="none" stroke="#DC2626" stroke-width="4.5"
          stroke-linecap="round"
          style="filter:drop-shadow(0 0 6px #DC262688);"/>
    ${[0, 0.4, 0.8].map(b => `
    <circle r="5" fill="#F87171" opacity="0.9">
        <animateMotion dur="1.2s" repeatCount="indefinite"
            begin="${b}s" path="${pOutPath}"/>
    </circle>`).join('')}

    <!-- DC− wire -->
    <path d="${nOutPath}" fill="none" stroke="#1F2937" stroke-width="4.5"
          stroke-linecap="round"
          style="filter:drop-shadow(0 0 4px #11182766);"/>
    ${[0, 0.6].map(b => `
    <circle r="5" fill="#6B7280" opacity="0.9">
        <animateMotion dur="1.5s" repeatCount="indefinite"
            begin="${b}s" path="${nOutPath}"/>
    </circle>`).join('')}

    <!-- DC+ label -->
    <rect x="${outPX+10}" y="${outPY-16}" width="36" height="18" rx="4" fill="#DC2626"/>
    <text x="${outPX+28}" y="${outPY-4}"
          text-anchor="middle" font-size="10" fill="white" font-weight="900">DC+</text>

    <!-- DC− label -->
    <rect x="${BUS_N_X-68}" y="${nBotY-9}" width="36" height="18" rx="4" fill="#1F2937"/>
    <text x="${BUS_N_X-50}" y="${nBotY+4}"
          text-anchor="middle" font-size="10" fill="white" font-weight="900">DC−</text>

    <!-- Voltage badge -->
    <rect x="${(outPX+INV_X)/2-42}" y="${(INV_IN_PY+INV_IN_NY)/2-15}"
          width="84" height="30" rx="8"
          fill="white" stroke="#F59E0B" stroke-width="2.5"/>
    <text x="${(outPX+INV_X)/2}" y="${(INV_IN_PY+INV_IN_NY)/2+7}"
          text-anchor="middle" font-size="13" fill="#92400E" font-weight="900">
        ${totalVolts}V DC
    </text>

    <!-- Inverter box -->
    <rect x="${INV_X}" y="${INV_Y}" width="${INV_W}" height="${INV_H}" rx="12"
          fill="#065F46" stroke="#10B981" stroke-width="2.5"
          style="animation:invPulse 3s ease-in-out infinite;"/>
    <rect x="${INV_X-7}" y="${INV_IN_PY-5}" width="9" height="10" rx="2" fill="#DC2626"/>
    <rect x="${INV_X-7}" y="${INV_IN_NY-5}" width="9" height="10" rx="2" fill="#374151"/>
    <text x="${INV_CX}" y="${INV_CY+10}"
          text-anchor="middle" font-size="30">⚡</text>
    <text x="${INV_CX}" y="${INV_Y+INV_H+18}"
          text-anchor="middle" font-size="10"
          fill="#065F46" font-weight="900" letter-spacing="0.05em">INVERTER</text>`;

    // ════════════════════════════════════════════════════════════
    // LAYER 4 — BATTERIES (on top)
    // ════════════════════════════════════════════════════════════
    for (let p = 0; p < batParallel; p++) {
        for (let s = 0; s < batSeries; s++) {
            const X      = bx(s);
            const Y      = by(p);
            const delay  = (p * batSeries + s) * 0.07;
            const batNum = p * batSeries + s + 1;
            const tP     = tPos(p, s);
            const tN     = tNeg(p, s);

            svgBatteries += `
            <g style="animation:panelIn 0.5s ${delay.toFixed(2)}s ease-out both;">
                <!-- Body -->
                <rect x="${X}" y="${Y}" width="${BW}" height="${BH}" rx="7"
                      fill="#1F2937" stroke="#4B5563" stroke-width="2"/>
                <!-- Negative cap LEFT -->
                <rect x="${X}" y="${Y}" width="22" height="${BH}" rx="7" fill="#374151"/>
                <rect x="${X+14}" y="${Y}" width="8" height="${BH}" fill="#374151"/>
                <!-- Positive cap RIGHT -->
                <rect x="${X+BW-22}" y="${Y}" width="22" height="${BH}" rx="7"
                      fill="#7F1D1D" opacity="0.65"/>
                <rect x="${X+BW-22}" y="${Y}" width="8" height="${BH}"
                      fill="#7F1D1D" opacity="0.65"/>
                <!-- Charge indicator -->
                <rect x="${X+26}" y="${Y+8}" width="${BW-52}" height="${BH-16}"
                      rx="4" fill="#111827"/>
                <rect x="${X+28}" y="${Y+10}" width="${BW-56}" height="${BH-20}"
                      rx="3" fill="#10B981" opacity="0.85"
                      style="animation:batPulse 3s ${delay.toFixed(2)}s ease-in-out infinite alternate;"/>
                <!-- Labels -->
                <text x="${X+BW/2}" y="${Y+BH/2-4}"
                      text-anchor="middle" font-size="11"
                      fill="white" font-weight="900">B${batNum}</text>
                <text x="${X+BW/2}" y="${Y+BH/2+10}"
                      text-anchor="middle" font-size="9" fill="#D1FAE5">
                    ${batV}V ${battery.capacity_ah}Ah
                </text>
                ${s === 0 ? `
                <text x="${X-14}" y="${Y-10}"
                      text-anchor="end" font-size="11"
                      fill="#F59E0B" font-weight="800">STR${p+1}</text>` : ''}
            </g>
            <!-- − terminal LEFT -->
            <circle cx="${tN.x}" cy="${tN.y}" r="${TR+2}" fill="white"/>
            <circle cx="${tN.x}" cy="${tN.y}" r="${TR}"
                    fill="#374151" stroke="#111827" stroke-width="2"/>
            <text x="${tN.x}" y="${tN.y+4}"
                  text-anchor="middle" font-size="12" fill="white" font-weight="900">−</text>
            <!-- + terminal RIGHT -->
            <circle cx="${tP.x}" cy="${tP.y}" r="${TR+2}" fill="white"/>
            <circle cx="${tP.x}" cy="${tP.y}" r="${TR}"
                    fill="#DC2626" stroke="#7F1D1D" stroke-width="2"/>
            <text x="${tP.x}" y="${tP.y+4}"
                  text-anchor="middle" font-size="12" fill="white" font-weight="900">+</text>`;
        }
    }

    // ════════════════════════════════════════════════════════════
    // LEGEND — pinned to bottom-left, BELOW all diagram content
    // Safe zone: SVG_H - LEG_H - LEG_PAD .. always below nBotY wire
    // ════════════════════════════════════════════════════════════
    const legend = `
    <!-- ══ LEGEND (bottom-left, outside diagram area) ══ -->
    <g transform="translate(${LEG_X}, ${LEG_Y})">
        <!-- Shadow -->
        <rect x="3" y="3" width="${LEG_W}" height="${LEG_H}" rx="10"
              fill="#00000018"/>
        <!-- Box -->
        <rect x="0" y="0" width="${LEG_W}" height="${LEG_H}" rx="10"
              fill="white" fill-opacity="0.98"
              stroke="#CBD5E1" stroke-width="1.8"/>
        <!-- Header bar -->
        <rect x="0" y="0" width="${LEG_W}" height="28" rx="10" fill="#F1F5F9"/>
        <rect x="0" y="18" width="${LEG_W}" height="10" fill="#F1F5F9"/>
        <text x="14" y="19"
              font-size="12" fill="#0F172A" font-weight="900"
              letter-spacing="0.06em">WIRING LEGEND</text>

        <!-- Row 1: Series wire -->
        <line x1="14" y1="46" x2="50" y2="46" stroke="#F59E0B" stroke-width="4"/>
        <polygon points="50,41 62,46 50,51" fill="#F59E0B"/>
        <text x="70" y="50" font-size="10" fill="#92400E" font-weight="700">
            Series link (+) → (−)
        </text>

        <!-- Row 2: Positive -->
        <line x1="14" y1="70" x2="56" y2="70" stroke="#DC2626" stroke-width="4"/>
        <circle cx="58" cy="70" r="6" fill="#DC2626"/>
        <text x="70" y="74" font-size="10" fill="#7F1D1D" font-weight="700">
            Positive (+) wire
        </text>

        <!-- Row 3: Negative -->
        <line x1="14" y1="94" x2="56" y2="94" stroke="#1F2937" stroke-width="4"/>
        <circle cx="58" cy="94" r="6" fill="#1F2937"/>
        <text x="70" y="98" font-size="10" fill="#1F2937" font-weight="700">
            Negative (−) wire
        </text>
    </g>`;

    // ════════════════════════════════════════════════════════════
    // DEFS
    // ════════════════════════════════════════════════════════════
    const defs = `
    <style>
        @keyframes panelIn {
            from { opacity:0; transform:scale(0.88); }
            to   { opacity:1; transform:scale(1); }
        }
        @keyframes batPulse {
            from { opacity:0.55; }
            to   { opacity:1.00; }
        }
        @keyframes invPulse {
            0%,100% { filter:drop-shadow(0 0 4px #10B981); }
            50%     { filter:drop-shadow(0 0 18px #10B981); }
        }
    </style>`;

    // ════════════════════════════════════════════════════════════
    // FINAL SVG
    // ════════════════════════════════════════════════════════════
    return `
    <svg viewBox="0 0 ${SVG_W} ${SVG_H}"
         xmlns="http://www.w3.org/2000/svg"
         style="width:100%; height:auto; min-height:260px;
                overflow:visible; background:#F0F4FF;">

        <defs>
            ${defs}
            <pattern id="bgGridBat" width="24" height="24"
                     patternUnits="userSpaceOnUse">
                <path d="M 24 0 L 0 0 0 24"
                      fill="none" stroke="#DDE4F0" stroke-width="0.6"/>
            </pattern>
        </defs>

        <!-- Background -->
        <rect width="${SVG_W}" height="${SVG_H}" fill="url(#bgGridBat)"/>

        <!-- Diagram border -->
        <rect x="4" y="4" width="${SVG_W-8}" height="${SVG_H-8}" rx="16"
              fill="none" stroke="#CBD5E1" stroke-width="1.5"
              stroke-dasharray="6 4"/>

        <!-- Title -->
        <text x="${SVG_W/2}" y="34"
              text-anchor="middle" font-size="20" font-weight="900"
              fill="#0F172A" letter-spacing="0.02em">
            Battery Bank: ${batSeries}S × ${batParallel}P = ${usedBatteries} × ${battery.capacity_ah}Ah
        </text>
        <text x="${SVG_W/2}" y="58"
              text-anchor="middle" font-size="13" fill="#64748B">
            ${batSeries} series × ${batV}V = ${totalVolts}V
            •  ${batParallel} parallel × ${battery.capacity_ah}Ah = ${total_ah}Ah total
        </text>

        <!-- Divider line under title -->
        <line x1="40" y1="68" x2="${SVG_W-40}" y2="68"
              stroke="#E2E8F0" stroke-width="1.5"/>

        <!-- Wires first (behind batteries) -->
        ${svgWiresSeries}
        ${svgWiresParallel}
        ${svgBusBars}
        ${svgOutput}

        <!-- Batteries on top -->
        ${svgBatteries}

        <!-- Legend last (on top, bottom-left, never overlaps batteries) -->
        ${legend}
    </svg>`;
}
// function renderBatteryWiringDiagram(batteryConfig, inverterVoltage) {
//     const { quantity, battery, wiring, total_ah } = batteryConfig;
//     const batV = battery.voltage || 12;

//     // ── Determine series / parallel count ──────────────────────
//     let batSeries   = 1;
//     let batParallel = quantity;

//     const spMatch = (wiring || '').match(/(\d+)\s*S\s*(\d+)\s*P/i);
//     if (spMatch) {
//         batSeries   = parseInt(spMatch[1]);
//         batParallel = parseInt(spMatch[2]);
//     } else if (/series/i.test(wiring)) {
//         // e.g., "4 in series" → 4S1P
//         const numMatch = (wiring).match(/(\d+)\s*in\s*series/i);
//         if (numMatch) batSeries = parseInt(numMatch[1]);
//         else batSeries = quantity;
//         batParallel = Math.round(quantity / batSeries);
//     } else if (/parallel/i.test(wiring)) {
//         const numMatch = (wiring).match(/(\d+)\s*in\s*parallel/i);
//         if (numMatch) batParallel = parseInt(numMatch[1]);
//         else batParallel = quantity;
//         batSeries = Math.round(quantity / batParallel);
//     } else {
//         // All parallel by default
//         batSeries   = 1;
//         batParallel = quantity;
//     }

//     const totalVolts = batSeries * batV;

//     // ── Layout constants ───────────────────────────────────────
//     const BW = 78, BH = 108;          // battery cell size
//     const GAP_X = 42, GAP_Y = 48;     // spacing
//     const ML = 70, MT = 90;           // margins

//     const TR = 8;                     // terminal radius
//     const T_PLUS_X  = BW / 2,  T_PLUS_Y  = 14;   // top center
//     const T_MINUS_X = BW / 2,  T_MINUS_Y = BH - 14; // bottom center

//     // helper functions for grid position
//     const bx = s => ML + s * (BW + GAP_X);
//     const by = p => MT + p * (BH + GAP_Y);

//     const SVG_W = ML + batSeries * (BW + GAP_X) + 180;
//     const SVG_H = MT + batParallel * (BH + GAP_Y) + 80;

//     // Inverter symbol on the right
//     const INV_X = SVG_W - 100;
//     const INV_Y = SVG_H / 2 - 28;
//     const INV_CX = INV_X + 28;
//     const INV_CY = INV_Y + 28;
//     const INV_IN_PY = INV_Y + 12;
//     const INV_IN_MY = INV_Y + 44;

//     let batSVG = '', seriesWires = '', parallelWires = '', outputWires = '';

//     // Build terminal coordinates for every cell
//     const plus  = Array.from({ length: batParallel }, (_, p) =>
//         Array.from({ length: batSeries }, (_, s) => ({
//             x: bx(s) + T_PLUS_X,
//             y: by(p) + T_PLUS_Y
//         }))
//     );
//     const minus = Array.from({ length: batParallel }, (_, p) =>
//         Array.from({ length: batSeries }, (_, s) => ({
//             x: bx(s) + T_MINUS_X,
//             y: by(p) + T_MINUS_Y
//         }))
//     );

//     // ── Draw each battery cell ─────────────────────────────────
//     for (let p = 0; p < batParallel; p++) {
//         for (let s = 0; s < batSeries; s++) {
//             const X = bx(s), Y = by(p);
//             const delay = (p * batSeries + s) * 0.07;
//             batSVG += `
//             <g style="animation:panelIn 0.5s ${delay.toFixed(2)}s ease-out both;">
//                 <rect x="${X}" y="${Y}" width="${BW}" height="${BH}" rx="6"
//                       fill="#1F2937" stroke="#374151" stroke-width="2.5"/>
//                 <rect x="${X+4}" y="${Y+20}" width="${BW-8}" height="${BH-36}" rx="4" fill="#111827"/>
//                 <!-- Charge level animation -->
//                 <rect x="${X+8}" y="${Y+28}" width="${BW-16}" height="${BH-52}" rx="3" fill="#374151"/>
//                 <rect x="${X+8}" y="${Y+28}" width="${BW-16}" height="${BH-52}" rx="3"
//                       fill="url(#batCharge${p}_${s})"
//                       style="animation:batFill 3s ease-in-out infinite alternate;"/>
//                 <!-- Label -->
//                 <rect x="${X+4}" y="${Y+BH-18}" width="${BW-8}" height="14" fill="#F59E0B" rx="3"/>
//                 <text x="${X+BW/2}" y="${Y+BH-7}" text-anchor="middle" font-size="9"
//                       fill="#1F2937" font-weight="900">${batV}V ${battery.capacity_ah}Ah</text>
//                 <!-- String ID -->
//                 ${s === 0 && batParallel > 1 ? `
//                 <text x="${X-10}" y="${Y+BH/2+4}" text-anchor="end" font-size="9"
//                       fill="#F59E0B" font-weight="700">STR${p+1}</text>` : ''}
//             </g>
//             <!-- Terminals with white background to separate from wires -->
//             <circle cx="${X+T_PLUS_X}" cy="${Y+T_PLUS_Y}" r="${TR+2}" fill="white"/>
//             <circle cx="${X+T_PLUS_X}" cy="${Y+T_PLUS_Y}" r="${TR}" fill="#DC2626" stroke="#7F1D1D" stroke-width="2"/>
//             <text x="${X+T_PLUS_X}" y="${Y+T_PLUS_Y+4}" text-anchor="middle" font-size="10" fill="white" font-weight="900">+</text>
            
//             <circle cx="${X+T_MINUS_X}" cy="${Y+T_MINUS_Y}" r="${TR+2}" fill="white"/>
//             <circle cx="${X+T_MINUS_X}" cy="${Y+T_MINUS_Y}" r="${TR}" fill="#6B7280" stroke="#1F2937" stroke-width="2"/>
//             <text x="${X+T_MINUS_X}" y="${Y+T_MINUS_Y+4}" text-anchor="middle" font-size="10" fill="white" font-weight="900">−</text>`;
//         }
//     }

//     // ── Series connections (within each string) ─────────────────
//     // connect minus of battery s to plus of battery s+1
//     for (let p = 0; p < batParallel; p++) {
//         for (let s = 0; s < batSeries - 1; s++) {
//             const from = minus[p][s];
//             const to   = plus[p][s + 1];
//             const laneY = by(p) + BH + 18;  // horizontal channel below the current row

//             const path = [
//                 `M ${from.x} ${from.y}`,
//                 `L ${from.x} ${laneY}`,
//                 `L ${to.x}   ${laneY}`,
//                 `L ${to.x}   ${to.y}`
//             ].join(' ');

//             seriesWires += `
//             <path d="${path}" fill="none" stroke="#F59E0B" stroke-width="3.2"
//                   stroke-dasharray="8 4" stroke-linecap="round"
//                   style="animation:flowDash 1.4s linear infinite; filter:drop-shadow(0 0 4px #F59E0BCC);"/>
//             <circle r="4" fill="#FCD34D" opacity="0.9">
//                 <animateMotion dur="1.5s" repeatCount="indefinite"
//                     begin="${(s * 0.4).toFixed(1)}s" path="${path}"/>
//             </circle>
//             <circle cx="${from.x}" cy="${laneY}" r="3.5" fill="#F59E0B" opacity="0.8"/>
//             <circle cx="${to.x}"   cy="${laneY}" r="3.5" fill="#F59E0B" opacity="0.8"/>`;
//         }
//     }

//     // ── Parallel connections (buses) ───────────────────────────
//     // CRITICAL FIX: Only draw parallel buses when batParallel > 1
//     // For pure series (e.g., 4S1P), NO parallel wires should be drawn
//     const BUS_X = bx(batSeries - 1) + BW + 32;
//     const BUS_PLUS_X  = BUS_X - 10;
//     const BUS_MINUS_X = BUS_X + 10;

//     const busPlusY  = [];
//     const busMinusY = [];

//     if (batParallel > 1) {
//         // Multiple parallel strings - need bus bars
//         for (let p = 0; p < batParallel; p++) {
//             // String positive = first battery's + (top center)
//             const strPlus  = plus[p][0];
//             // String negative = last battery's – (bottom center)
//             const strMinus = minus[p][batSeries - 1];

//             busPlusY.push(strPlus.y);
//             busMinusY.push(strMinus.y);

//             // Route from string positive to positive bus (red)
//             const plusPath = `M ${strPlus.x} ${strPlus.y} L ${BUS_PLUS_X} ${strPlus.y}`;
//             parallelWires += `
//             <path d="${plusPath}" fill="none" stroke="#DC2626" stroke-width="3.5" stroke-linecap="round"/>
//             <circle r="4" fill="#F87171">
//                 <animateMotion dur="1.6s" repeatCount="indefinite" begin="${(p*0.35).toFixed(1)}s" path="${plusPath}"/>
//             </circle>
//             <circle cx="${BUS_PLUS_X}" cy="${strPlus.y}" r="5" fill="#DC2626" stroke="white" stroke-width="1.5"/>`;

//             // Route from string negative to negative bus (dark)
//             const minusPath = `M ${strMinus.x} ${strMinus.y} L ${BUS_MINUS_X} ${strMinus.y}`;
//             parallelWires += `
//             <path d="${minusPath}" fill="none" stroke="#374151" stroke-width="3.5" stroke-linecap="round"/>
//             <circle r="4" fill="#9CA3AF">
//                 <animateMotion dur="1.6s" repeatCount="indefinite" begin="${(p*0.35+0.2).toFixed(1)}s" path="${minusPath}"/>
//             </circle>
//             <circle cx="${BUS_MINUS_X}" cy="${strMinus.y}" r="5" fill="#374151" stroke="white" stroke-width="1.5"/>`;
//         }

//         // Vertical bus bars connecting all parallel strings
//         const plusTopY  = Math.min(...busPlusY);
//         const plusBotY  = Math.max(...busPlusY);
//         const minusTopY = Math.min(...busMinusY);
//         const minusBotY = Math.max(...busMinusY);

//         parallelWires += `
//         <line x1="${BUS_PLUS_X}" y1="${plusTopY}" x2="${BUS_PLUS_X}" y2="${plusBotY}"
//               stroke="#DC2626" stroke-width="6" stroke-linecap="round"/>
//         <rect x="${BUS_PLUS_X-22}" y="${(plusTopY+plusBotY)/2-10}" width="20" height="20" rx="4" fill="#DC2626"/>
//         <text x="${BUS_PLUS_X-12}" y="${(plusTopY+plusBotY)/2+5}" text-anchor="middle" font-size="9" fill="white" font-weight="800">BUS+</text>

//         <line x1="${BUS_MINUS_X}" y1="${minusTopY}" x2="${BUS_MINUS_X}" y2="${minusBotY}"
//               stroke="#1F2937" stroke-width="6" stroke-linecap="round"/>
//         <rect x="${BUS_MINUS_X+2}" y="${(minusTopY+minusBotY)/2-10}" width="22" height="20" rx="4" fill="#1F2937"/>
//         <text x="${BUS_MINUS_X+13}" y="${(minusTopY+minusBotY)/2+5}" text-anchor="middle" font-size="9" fill="white" font-weight="800">BUS−</text>`;
//     }

//     // ── Output wires to inverter ───────────────────────────────
//     let outPX, outPY, outMX, outMY;
//     if (batParallel === 1) {
//         // Single string: take directly from the string terminals
//         outPX = plus[0][0].x;         outPY = plus[0][0].y;
//         outMX = minus[0][batSeries-1].x; outMY = minus[0][batSeries-1].y;
//     } else {
//         const mid = Math.floor(batParallel / 2);
//         outPX = BUS_PLUS_X;  outPY = busPlusY[mid]  ?? busPlusY[0];
//         outMX = BUS_MINUS_X; outMY = busMinusY[mid] ?? busMinusY[0];
//     }

//     // Smooth bezier curves to inverter input points
//     const pPath = `M ${outPX} ${outPY} C ${outPX+45} ${outPY}, ${INV_X-32} ${INV_IN_PY}, ${INV_X} ${INV_IN_PY}`;
//     const mPath = `M ${outMX} ${outMY} C ${outMX+45} ${outMY}, ${INV_X-32} ${INV_IN_MY}, ${INV_X} ${INV_IN_MY}`;

//     outputWires = `
//     <path d="${pPath}" fill="none" stroke="#DC2626" stroke-width="4" stroke-linecap="round"
//           style="filter:drop-shadow(0 0 5px #DC262699);"/>
//     ${[0, 0.5, 1].map(b => `
//     <circle r="5" fill="#F87171">
//         <animateMotion dur="1.3s" repeatCount="indefinite" begin="${b}s" path="${pPath}"/>
//     </circle>`).join('')}

//     <path d="${mPath}" fill="none" stroke="#374151" stroke-width="4" stroke-linecap="round"
//           style="filter:drop-shadow(0 0 4px #11182755);"/>
//     ${[0, 0.6].map(b => `
//     <circle r="5" fill="#9CA3AF">
//         <animateMotion dur="1.3s" repeatCount="indefinite" begin="${b}s" path="${mPath}"/>
//     </circle>`).join('')}

//     <!-- Output labels -->
//     <rect x="${outPX + (outPX > INV_X ? -40 : 8)}" y="${outPY - 20}" width="32" height="14" fill="#DC2626" rx="3"/>
//     <text x="${outPX + (outPX > INV_X ? -24 : 24)}" y="${outPY - 9}" text-anchor="middle" font-size="9" fill="white" font-weight="800">DC+</text>

//     <rect x="${outMX + (outMX > INV_X ? -40 : 8)}" y="${outMY + 6}" width="32" height="14" fill="#374151" rx="3"/>
//     <text x="${outMX + (outMX > INV_X ? -24 : 24)}" y="${outMY + 17}" text-anchor="middle" font-size="9" fill="white" font-weight="800">DC−</text>

//     <!-- Voltage tag in the middle -->
//     <rect x="${(outPX + INV_X) / 2 - 32}" y="${(INV_IN_PY + INV_IN_MY) / 2 - 11}"
//           width="64" height="22" rx="5" fill="white" stroke="#F59E0B" stroke-width="1.8"/>
//     <text x="${(outPX + INV_X) / 2}" y="${(INV_IN_PY + INV_IN_MY) / 2 + 5}"
//           text-anchor="middle" font-size="11" fill="#92400E" font-weight="800">
//         ${totalVolts}V DC
//     </text>

//     <!-- Inverter symbol -->
//     <rect x="${INV_X}" y="${INV_Y}" width="56" height="56" rx="10"
//           fill="#065F46" stroke="#10B981" stroke-width="2.5"
//           style="animation:invPulse 3s ease-in-out infinite;"/>
//     <rect x="${INV_X}" y="${INV_IN_PY-4}" width="6" height="8" fill="#DC2626"/>
//     <rect x="${INV_X}" y="${INV_IN_MY-4}" width="6" height="8" fill="#374151"/>
//     <text x="${INV_CX}" y="${INV_CY+8}" text-anchor="middle" font-size="22">⚡</text>
//     <text x="${INV_CX}" y="${INV_Y+70}" text-anchor="middle" font-size="9"
//           fill="#065F46" font-weight="800">INVERTER</text>`;

//     // ── Defs & styles ──────────────────────────────────────────
//     let batDefs = `
//     <style>
//         @keyframes panelIn {
//             from { opacity:0; transform:scale(0.88); }
//             to   { opacity:1; transform:scale(1); }
//         }
//         @keyframes flowDash {
//             from { stroke-dashoffset:22; }
//             to   { stroke-dashoffset:0; }
//         }
//         @keyframes batFill {
//             0%   { height:${BH-52}px; fill:#EF4444; }
//             50%  { height:${BH-52}px; fill:#F59E0B; }
//             100% { height:${BH-52}px; fill:#10B981; }
//         }
//         @keyframes invPulse {
//             0%,100% { filter:drop-shadow(0 0 4px #10B981); }
//             50%     { filter:drop-shadow(0 0 14px #10B981); }
//         }
//     </style>`;

//     for (let p = 0; p < batParallel; p++) {
//         for (let s = 0; s < batSeries; s++) {
//             batDefs += `
//             <linearGradient id="batCharge${p}_${s}" x1="0%" y1="0%" x2="0%" y2="100%">
//                 <stop offset="0%"   stop-color="#10B981"/>
//                 <stop offset="100%" stop-color="#059669"/>
//             </linearGradient>`;
//         }
//     }

//     // Legend
//     const legend = `
//     <rect x="8" y="8" width="140" height="86" rx="6" fill="white" fill-opacity="0.95" stroke="#CBD5E1" stroke-width="1.5"/>
//     <text x="16" y="22" font-size="11" fill="#0F172A" font-weight="900">LEGEND</text>
//     <line x1="16" y1="36" x2="42" y2="36" stroke="#F59E0B" stroke-width="3" stroke-dasharray="6 3"/>
//     <circle cx="42" cy="36" r="4" fill="#FCD34D"/>
//     <text x="50" y="40" font-size="10" fill="#92400E" font-weight="700">Series link (− → +)</text>
//     <line x1="16" y1="56" x2="42" y2="56" stroke="#DC2626" stroke-width="3"/>
//     <circle cx="42" cy="56" r="4" fill="#DC2626"/>
//     <text x="50" y="60" font-size="10" fill="#7F1D1D" font-weight="700">Positive (+)</text>
//     <line x1="16" y1="76" x2="42" y2="76" stroke="#374151" stroke-width="3"/>
//     <circle cx="42" cy="76" r="4" fill="#374151"/>
//     <text x="50" y="80" font-size="10" fill="##1F2937" font-weight="700">Negative (−)</text>`;

//     return `
//     <svg viewBox="0 0 ${SVG_W} ${SVG_H}"
//          xmlns="http://www.w3.org/2000/svg"
//          style="width:100%; height:auto; min-height:220px; overflow:visible; background:#F8FAFF;">
//         <defs>${batDefs}</defs>
//         <defs>
//             <pattern id="bgGrid2" width="20" height="20" patternUnits="userSpaceOnUse">
//                 <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#E2E8F0" stroke-width="0.5"/>
//             </pattern>
//         </defs>
//         <rect width="${SVG_W}" height="${SVG_H}" fill="url(#bgGrid2)"/>

//         <!-- Title -->
//         <text x="${SVG_W/2}" y="28" text-anchor="middle" font-size="18" font-weight="900" fill="#0F172A">
//             Battery Bank: ${batSeries}S${batParallel}P = ${quantity} × ${battery.capacity_ah}Ah
//         </text>
//         <text x="${SVG_W/2}" y="48" text-anchor="middle" font-size="12" fill="#64748B">
//             ${batSeries} series × ${batV}V = ${totalVolts}V • ${batParallel} parallel × ${battery.capacity_ah}Ah = ${total_ah}Ah total
//         </text>

//         ${seriesWires}
//         ${parallelWires}
//         ${outputWires}
//         ${batSVG}
//         ${legend}
//     </svg>`;
// }

// ============================================================
// UPDATED renderInstallationGuide — adds battery diagram
// ============================================================
function renderInstallationGuide(selectedSystem) {
    const container = document.getElementById('installation-guide');
    if (!container) return;

    if (typeof injectAnimationStyles === 'function') injectAnimationStyles();

    const { inverter, battery_config, panel_config } = selectedSystem;

    container.innerHTML = `
        <!-- 3D System Connection Overview -->
        <div id="connection-diagram-3d-container"></div>

        <div style="margin-top:32px; background:white; border-radius:20px;
                    padding:clamp(20px,4vw,44px);
                    box-shadow:0 4px 24px rgba(0,0,0,0.08);">

            <!-- Solar Panel Wiring -->
            <h2 style="text-align:center; color:#0D3B6E; font-size:clamp(16px,3vw,22px);
                       font-weight:900; margin:0 0 6px;">
                ☀️ Solar Panel Wiring Diagram
            </h2>
            <p style="text-align:center; color:#64748B; margin:0 0 24px; font-size:13px;">
                ${panel_config.series}S × ${panel_config.parallel}P •
                Amber = series link • Red = positive • Black = negative
            </p>
            <div style="background:#F8FAFF; border-radius:12px;
                        border:2px solid #E2E8F0; padding:16px; overflow-x:auto;">
                ${renderActualPanelLayout(panel_config)}
            </div>

            <!-- Battery Wiring -->
            <h2 style="text-align:center; color:#0D3B6E; font-size:clamp(16px,3vw,22px);
                       font-weight:900; margin:40px 0 6px;">
                🔋 Battery Bank Wiring Diagram
            </h2>
            <p style="text-align:center; color:#64748B; margin:0 0 24px; font-size:13px;">
                ${battery_config.wiring} •
                Red = positive • Black = negative • Amber = series link
            </p>
            <div style="background:#F8FAFF; border-radius:12px;
                        border:2px solid #E2E8F0; padding:16px; overflow-x:auto;">
                ${renderBatteryWiringDiagram(battery_config, inverter.voltage_class)}
            </div>

            <!-- Installation Steps -->
            <h2 style="text-align:center; color:#0D3B6E; font-size:clamp(16px,3vw,22px);
                       font-weight:900; margin:40px 0 6px;">
                📖 Step-by-Step Installation
            </h2>
            <p style="text-align:center; color:#64748B; margin:0 0 24px; font-size:13px;">
                Follow every step for a safe professional installation
            </p>
            ${typeof renderInstallationSteps === 'function'
                ? renderInstallationSteps(selectedSystem) : ''}

            <!-- Safety -->
            <div style="background:linear-gradient(135deg,#FEF2F2,#FFF5F5);
                        border:2px solid #FCA5A5; border-radius:14px;
                        padding:24px; margin-top:32px; position:relative; overflow:hidden;">
                <div style="position:absolute; right:20px; top:16px; font-size:72px; opacity:0.07;">⚠</div>
                <div style="display:flex; gap:12px; align-items:flex-start;">
                    <div style="font-size:32px;">⚠️</div>
                    <div>
                        <h3 style="color:#991B1B; margin:0 0 8px; font-size:15px;
                                   font-weight:900; text-transform:uppercase; letter-spacing:0.06em;">
                            Important Safety Warning
                        </h3>
                        <ul style="color:#7F1D1D; font-size:13px; line-height:1.9; margin:0; padding-left:18px;">
                            <li>Must be installed by a qualified electrician</li>
                            <li>High-voltage DC & AC present — electrocution risk</li>
                            <li>Batteries contain corrosive acid — wear full PPE</li>
                            <li>Solar panels generate voltage even in low light — cover panels during work</li>
                            <li>Always connect earth ground first</li>
                            <li>Never work alone</li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Buttons -->
            <div style="margin-top:28px; display:flex; gap:14px;
                        justify-content:center; flex-wrap:wrap;">
                <button onclick="goBackToConfigurator()"
                        style="padding:13px 26px; border-radius:10px;
                               border:2px solid #3B82F6; background:white;
                               color:#3B82F6; font-weight:700; font-size:14px;
                               cursor:pointer; transition:all 0.2s;"
                        onmouseover="this.style.borderColor='#2563EB';this.style.background='#EFF6FF';this.style.color='#2563EB'"
                        onmouseout="this.style.borderColor='#3B82F6';this.style.background='white';this.style.color='#3B82F6'">
                    ← Back to Configurator
                </button>
                <button onclick="window.print()"
                        style="padding:13px 26px; border-radius:10px;
                               border:2px solid #94A3B8; background:white;
                               color:#374151; font-weight:700; font-size:14px;
                               cursor:pointer; transition:all 0.2s;"
                        onmouseover="this.style.borderColor='#374151';this.style.background='#F8FAFC'"
                        onmouseout="this.style.borderColor='#94A3B8';this.style.background='white'">
                    🖨️ Print Guide
                </button>
                <button onclick="downloadSystemPDF()"
                        style="padding:13px 26px; border-radius:10px; border:none;
                               background:linear-gradient(135deg,#1D4ED8,#0D3B6E);
                               color:white; font-weight:700; font-size:14px;
                               cursor:pointer; box-shadow:0 4px 14px rgba(29,78,216,0.35);
                               transition:all 0.2s;"
                        onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 8px 22px rgba(29,78,216,0.45)'"
                        onmouseout="this.style.transform='';this.style.boxShadow='0 4px 14px rgba(29,78,216,0.35)'">
                    📄 Download PDF
                </button>
            </div>
        </div>
    `;

    // Render 3D connection diagram
    if (window.connectionDiagram3D) {
        window.connectionDiagram3D.render('connection-diagram-3d-container', selectedSystem);
    }
}

// ─── Exports ────────────────────────────────────────────────────────────────
window.renderInstallationGuide    = renderInstallationGuide;
window.renderActualPanelLayout    = renderActualPanelLayout;
window.renderBatteryWiringDiagram = renderBatteryWiringDiagram;

/**
 * Go back to configurator from installation guide
 */
window.goBackToConfigurator = function() {

    // Hide installation guide
    const guideContainer = document.getElementById('installation-guide');
    if (guideContainer) {
        guideContainer.style.display = 'none';
    }
    
    // Show configurator
    const configuratorContainer = document.getElementById('configurator-container');
    if (configuratorContainer) {
        configuratorContainer.style.display = 'block';
        
        // Scroll to configurator
        configuratorContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
        // Fallback: if configurator container doesn't exist, go back to recommendations
        console.warn('Configurator container not found, going back to recommendations');
        if (typeof window.goBackToRecommendations === 'function') {
            window.goBackToRecommendations();
        }
    }
};
window.buildDefs                  = buildDefs;
window.downloadSystemPDF = function() {
    alert('Use Print → Save as PDF for now. Full PDF export coming soon!');
    window.print();
};