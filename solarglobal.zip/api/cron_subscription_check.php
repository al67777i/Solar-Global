<?php
/**
 * Subscription Auto-Management Cron Job
 * Run via cron every hour: php /path/to/cron_subscription_check.php
 *
 * Handles:
 * 1. Mark expired subscriptions as 'expired'
 * 2. Set grace period end dates
 * 3. Hide stores/installers past grace period
 * 4. Send expiry warning notifications (3 days before, 1 day before, expired)
 * 5. Data retention cleanup (purge old records per retention plan)
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/stripe_config.php';

// ── Security: Only allow CLI or authenticated admin via secret token ──
$is_cli = (php_sapi_name() === 'cli');
$is_authorized_http = false;

if (!$is_cli) {
    // HTTP access requires a secret token matching the one in system_settings
    $cron_secret = get_system_setting('cron_secret_token', '');
    $provided_token = $_GET['token'] ?? $_SERVER['HTTP_X_CRON_TOKEN'] ?? '';

    if (empty($cron_secret) || empty($provided_token) || !hash_equals($cron_secret, $provided_token)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Unauthorized. Provide valid cron token.']);
        exit;
    }
    $is_authorized_http = true;
}

$db = getDB();
$now = date('Y-m-d H:i:s');
$log = [];

function clog($msg) {
    global $log;
    $log[] = '[' . date('H:i:s') . '] ' . $msg;
}

// ──────────────────────────────────────────────────────────────
// 1. Mark expired subscriptions (both dealers and installers)
// ──────────────────────────────────────────────────────────────
$grace_days = (int)getPaymentSetting('subscription_grace_period_days', '3');

foreach (['dealers', 'installers'] as $table) {
    // Active subscriptions that have expired
    $stmt = $db->prepare("
        UPDATE {$table} SET
            subscription_status = 'expired',
            grace_period_ends_at = DATE_ADD(subscription_expires_at, INTERVAL ? DAY)
        WHERE subscription_status = 'active'
          AND subscription_expires_at IS NOT NULL
          AND subscription_expires_at < NOW()
    ");
    $stmt->execute([$grace_days]);
    $count = $stmt->rowCount();
    if ($count > 0) clog("Marked $count {$table} subscriptions as expired (grace: {$grace_days} days)");

    // Past grace period — deactivate (hide from public)
    $stmt2 = $db->prepare("
        UPDATE {$table} SET
            subscription_status = 'canceled'
        WHERE subscription_status = 'expired'
          AND grace_period_ends_at IS NOT NULL
          AND grace_period_ends_at < NOW()
    ");
    $stmt2->execute();
    $count2 = $stmt2->rowCount();
    if ($count2 > 0) clog("Deactivated $count2 {$table} past grace period");

    // Trial expiry: check dealers/installers on trial whose trial period ended
    $trial_enabled_key = ($table === 'dealers') ? 'dealer_free_trial_enabled' : 'installer_free_trial_enabled';
    $trial_days_key    = ($table === 'dealers') ? 'dealer_free_trial_days' : 'installer_free_trial_days';
    $trial_enabled = (int)getPaymentSetting($trial_enabled_key, '1');
    $trial_days    = (int)getPaymentSetting($trial_days_key, '7');

    if ($trial_enabled && $trial_days > 0) {
        $stmt3 = $db->prepare("
            UPDATE {$table} SET
                subscription_status = 'expired',
                grace_period_ends_at = DATE_ADD(NOW(), INTERVAL ? DAY)
            WHERE subscription_status IN ('none','trial')
              AND status IN ('active','approved')
              AND stripe_customer_id IS NULL
              AND stripe_subscription_id IS NULL
              AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
              AND (subscription_expires_at IS NULL OR subscription_expires_at < NOW())
        ");
        $stmt3->execute([$grace_days, $trial_days]);
        $count3 = $stmt3->rowCount();
        if ($count3 > 0) clog("Expired $count3 {$table} free trials (>{$trial_days} days)");
    }
}

// ──────────────────────────────────────────────────────────────
// 2. Send expiry warning notifications (email-ready)
// ──────────────────────────────────────────────────────────────
foreach (['dealers', 'installers'] as $table) {
    // 3 days before expiry
    $stmt = $db->prepare("
        SELECT id, email, business_name, subscription_expires_at
        FROM {$table}
        WHERE subscription_status = 'active'
          AND subscription_expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 3 DAY)
    ");
    $stmt->execute();
    $expiring_soon = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($expiring_soon as $row) {
        // Check if we already notified (prevent duplicate notifications)
        $checkNotif = $db->prepare("
            SELECT COUNT(*) FROM system_settings
            WHERE setting_key = ?
        ");
        $notif_key = "notif_expiry_{$table}_{$row['id']}_" . date('Y-m-d', strtotime($row['subscription_expires_at']));
        $checkNotif->execute([$notif_key]);
        if ((int)$checkNotif->fetchColumn() > 0) continue;

        // Mark notification as sent
        $markNotif = $db->prepare("
            INSERT INTO system_settings (setting_key, setting_value, updated_at)
            VALUES (?, 'sent', NOW())
            ON DUPLICATE KEY UPDATE setting_value = 'sent', updated_at = NOW()
        ");
        $markNotif->execute([$notif_key]);

        $expires = date('M j, Y', strtotime($row['subscription_expires_at']));
        clog("NOTIFY: {$table} #{$row['id']} ({$row['business_name']}) expires on {$expires}");

        // TODO: Integrate with email system when available
        // send_email($row['email'], 'Subscription Expiring', "Your subscription expires on $expires. Renew to stay visible.");
    }
}

// ──────────────────────────────────────────────────────────────
// 3. Per-Plan Data Retention Auto-Cleanup
//    Each dealer/installer has a retention plan (basic/standard/premium/enterprise).
//    When data passes their plan's retention period → auto-delete.
//    Example: Basic plan = 6 months → on day 181, day-1 data is gone.
// ──────────────────────────────────────────────────────────────
require_once __DIR__ . '/../includes/data_retention.php';

try {
    $retention_stats = run_data_retention_cleanup($db);
    foreach ($retention_stats as $stat) {
        clog($stat);
    }
} catch (Exception $e) {
    clog("Data retention error: " . $e->getMessage());
    error_log("CRON data_retention error: " . $e->getMessage());
}

// ──────────────────────────────────────────────────────────────
// 4. Output log
// ──────────────────────────────────────────────────────────────
if (php_sapi_name() === 'cli') {
    echo "=== Subscription Check " . date('Y-m-d H:i:s') . " ===\n";
    foreach ($log as $l) echo "  $l\n";
    if (empty($log)) echo "  No actions needed.\n";
    echo "Done.\n";
} else {
    // Called via HTTP (e.g., admin trigger) — return JSON
    header('Content-Type: application/json');
    echo json_encode(['timestamp' => $now, 'actions' => $log]);
}
