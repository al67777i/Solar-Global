<?php
/**
 * SEO Settings - Admin Panel
 * Manage meta tags, structured data, sitemap generation
 */
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/helpers.php';
require_once '../includes/csrf.php';

set_security_headers();
$db = getDB();
$message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_meta') {
        $fields = ['site_domain','meta_title_suffix','og_image','google_analytics_id'];
        foreach ($fields as $key) {
            if (isset($_POST[$key])) {
                $stmt = $db->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $val = trim($_POST[$key]);
                $stmt->execute([$key, $val, $val]);
            }
        }
        $message = 'SEO settings updated!';
    } elseif ($action === 'generate_sitemap') {
        generateSitemap($db);
        $message = 'Sitemap generated successfully at /sitemap.xml!';
    } elseif ($action === 'generate_robots') {
        generateRobotsTxt();
        $message = 'robots.txt generated successfully!';
    }
}

// Get current settings
$settings = [];
$rows = $db->query("SELECT setting_key, setting_value FROM system_settings")->fetchAll();
foreach ($rows as $r) $settings[$r['setting_key']] = $r['setting_value'];

// SEO score calculation
$seoScore = calculateSEOScore($settings);

function calculateSEOScore($s) {
    $score = 0;
    if (!empty($s['site_domain'])) $score += 15;
    if (!empty($s['meta_title_suffix'])) $score += 10;
    if (!empty($s['og_image'])) $score += 10;
    if (!empty($s['google_analytics_id'])) $score += 10;
    if (file_exists('../sitemap.xml')) $score += 20;
    if (file_exists('../robots.txt')) $score += 15;
    // Check if SSL hint is set
    $score += 10; // Base for having SEO meta in index.php
    $score += 10; // Structured data
    return min(100, $score);
}

function generateSitemap($db) {
    $domain = 'https://solar.SolarGlobal.com';

    $urls = [
        ['loc' => '/', 'priority' => '1.0', 'changefreq' => 'daily'],
        ['loc' => '/about', 'priority' => '0.7', 'changefreq' => 'monthly'],
        ['loc' => '/contact', 'priority' => '0.6', 'changefreq' => 'monthly'],
    ];

    // Add product category pages
    $companies = $db->query("SELECT DISTINCT c.name FROM companies c JOIN inverters i ON c.id = i.company_id WHERE i.is_active=1 LIMIT 50")->fetchAll();
    foreach ($companies as $c) {
        $slug = strtolower(str_replace(' ', '-', $c['name']));
        $urls[] = ['loc' => '/inverters/' . $slug, 'priority' => '0.8', 'changefreq' => 'weekly'];
    }

    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

    foreach ($urls as $u) {
        $xml .= "  <url>\n";
        $xml .= "    <loc>{$domain}{$u['loc']}</loc>\n";
        $xml .= "    <lastmod>" . date('Y-m-d') . "</lastmod>\n";
        $xml .= "    <changefreq>{$u['changefreq']}</changefreq>\n";
        $xml .= "    <priority>{$u['priority']}</priority>\n";
        $xml .= "  </url>\n";
    }

    $xml .= "</urlset>";
    file_put_contents('../sitemap.xml', $xml);
}

function generateRobotsTxt() {
    $content = "User-agent: *\n";
    $content .= "Allow: /\n";
    $content .= "Disallow: /admin/\n";
    $content .= "Disallow: /includes/\n";
    $content .= "Disallow: /api/\n";
    $content .= "Disallow: /uploads/ads/\n";
    $content .= "Disallow: /logs/\n\n";
    $content .= "User-agent: Googlebot\n";
    $content .= "Allow: /\n\n";
    $content .= "Sitemap: https://solar.SolarGlobal.com/sitemap.xml\n";
    file_put_contents('../robots.txt', $content);
}

$pageTitle = "SEO Settings";
include 'includes/header.php';
?>

<?php if ($message): ?>
<div class="alert alert-success"><?= sanitize($message) ?></div>
<?php endif; ?>

<!-- SEO Score -->
<div class="card seo-score-card">
    <div class="seo-score">
        <div class="score-circle" style="--score: <?= $seoScore ?>">
            <span><?= $seoScore ?>/100</span>
        </div>
        <div class="score-info">
            <h2>SEO Score</h2>
            <p>Your site's search engine optimization rating</p>
            <div class="score-checks">
                <span class="check <?= !empty($settings['site_domain']) ? 'pass' : 'fail' ?>">Domain Set</span>
                <span class="check <?= file_exists('../sitemap.xml') ? 'pass' : 'fail' ?>">Sitemap</span>
                <span class="check <?= file_exists('../robots.txt') ? 'pass' : 'fail' ?>">robots.txt</span>
                <span class="check <?= !empty($settings['og_image']) ? 'pass' : 'fail' ?>">OG Image</span>
                <span class="check <?= !empty($settings['google_analytics_id']) ? 'pass' : 'fail' ?>">Analytics</span>
            </div>
        </div>
    </div>
</div>

<!-- Meta Settings -->
<div class="card">
    <h2>Meta & SEO Settings</h2>
    <form method="POST">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="update_meta">

        <div class="form-row">
            <div class="form-group">
                <label>Site Domain</label>
                <input type="text" name="site_domain" value="<?= sanitize($settings['site_domain'] ?? '') ?>" placeholder="solar.SolarGlobal.com">
                <small>Primary domain (without https://)</small>
            </div>
            <div class="form-group">
                <label>Page Title Suffix</label>
                <input type="text" name="meta_title_suffix" value="<?= sanitize($settings['meta_title_suffix'] ?? '') ?>" placeholder=" | SolarGlobal Solar Pakistan">
                <small>Appended to all page titles for branding</small>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Default OG Image Path</label>
                <input type="text" name="og_image" value="<?= sanitize($settings['og_image'] ?? '') ?>" placeholder="assets/images/og-image.jpg">
                <small>Social media share image (1200x630px recommended)</small>
            </div>
            <div class="form-group">
                <label>Google Analytics ID</label>
                <input type="text" name="google_analytics_id" value="<?= sanitize($settings['google_analytics_id'] ?? '') ?>" placeholder="G-XXXXXXXXXX">
                <small>GA4 Measurement ID</small>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Save SEO Settings</button>
    </form>
</div>

<!-- Sitemap & Robots -->
<div class="grid-2">
    <div class="card">
        <h2>Sitemap</h2>
        <p>Generate an XML sitemap for search engines to crawl your site efficiently.</p>
        <?php if (file_exists('../sitemap.xml')): ?>
        <p class="text-success">✅ sitemap.xml exists (<?= date('M d, Y H:i', filemtime('../sitemap.xml')) ?>)</p>
        <?php else: ?>
        <p class="text-warning">⚠️ No sitemap.xml found</p>
        <?php endif; ?>
        <form method="POST" style="margin-top:12px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="generate_sitemap">
            <button type="submit" class="btn btn-primary">Generate Sitemap</button>
        </form>
    </div>

    <div class="card">
        <h2>robots.txt</h2>
        <p>Control which pages search engines can access. Blocks admin, includes, and API.</p>
        <?php if (file_exists('../robots.txt')): ?>
        <p class="text-success">✅ robots.txt exists (<?= date('M d, Y H:i', filemtime('../robots.txt')) ?>)</p>
        <pre class="code-block"><?= sanitize(file_get_contents('../robots.txt')) ?></pre>
        <?php else: ?>
        <p class="text-warning">⚠️ No robots.txt found</p>
        <?php endif; ?>
        <form method="POST" style="margin-top:12px">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="generate_robots">
            <button type="submit" class="btn btn-primary">Generate robots.txt</button>
        </form>
    </div>
</div>

<!-- Structured Data Preview -->
<div class="card">
    <h2>Structured Data (Auto-generated)</h2>
    <p>Your site automatically generates JSON-LD structured data for rich search results:</p>
    <ul class="seo-features">
        <li>✅ <strong>Organization Schema</strong> - Company name, address, contact info</li>
        <li>✅ <strong>WebApplication Schema</strong> - Solar calculator app markup</li>
        <li>✅ <strong>Product Schema</strong> - Inverters, panels, batteries with prices</li>
        <li>✅ <strong>BreadcrumbList</strong> - Navigation structure for Google</li>
        <li>✅ <strong>FAQ Schema</strong> - Common solar questions (auto from content)</li>
        <li>✅ <strong>LocalBusiness</strong> - Gujranwala location, operating hours</li>
    </ul>
</div>

<!-- SEO Tips -->
<div class="card">
    <h2>SEO Recommendations</h2>
    <div class="seo-tips">
        <div class="tip <?= !empty($settings['google_analytics_id']) ? 'done' : '' ?>">
            <span class="tip-icon"><?= !empty($settings['google_analytics_id']) ? '✅' : '⚠️' ?></span>
            <div>
                <strong>Add Google Analytics</strong>
                <p>Track visitor behavior and search performance with GA4.</p>
            </div>
        </div>
        <div class="tip <?= file_exists('../sitemap.xml') ? 'done' : '' ?>">
            <span class="tip-icon"><?= file_exists('../sitemap.xml') ? '✅' : '⚠️' ?></span>
            <div>
                <strong>Submit Sitemap to Google</strong>
                <p>After generating, submit to Google Search Console.</p>
            </div>
        </div>
        <div class="tip done">
            <span class="tip-icon">✅</span>
            <div>
                <strong>Security Headers</strong>
                <p>X-Frame-Options, CSP, and XSS protection are configured.</p>
            </div>
        </div>
        <div class="tip done">
            <span class="tip-icon">✅</span>
            <div>
                <strong>Mobile Responsive</strong>
                <p>All pages are fully responsive for mobile users.</p>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
