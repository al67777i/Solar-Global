<?php
/**
 * Authentication Handler
 * Checks admin session and enforces timeout
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Session timeout: 2 hours (7200 seconds)
define('SESSION_TIMEOUT', 7200);

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Save current URL for redirect after login
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    // Determine base path dynamically
    $basePath = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');
    header('Location: ' . $basePath . '/login.php');
    exit();
}

// Check session timeout
if (isset($_SESSION['last_activity'])) {
    $elapsed = time() - $_SESSION['last_activity'];

    if ($elapsed > SESSION_TIMEOUT) {
        // Session expired
        session_unset();
        session_destroy();
        $basePath = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');
        header('Location: ' . $basePath . '/login.php?timeout=1');
        exit();
    }
}

// Update last activity timestamp
$_SESSION['last_activity'] = time();
