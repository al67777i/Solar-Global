<?php
/**
 * Customer Registration Page
 * Password-based registration with optional email verification
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/customer_auth.php';
require_once __DIR__ . '/../includes/email_verification.php';

set_security_headers();

// Already logged in?
if (is_customer_logged_in()) {
    header('Location: /solarglobal/customer/orders.php');
    exit();
}

$db = getDB();
$error = '';
$success = '';
$site_name = get_system_setting('site_name', 'SolarGlobal');
$detected_country = get_user_country_code();

// Preserve form values on error
$old = [
    'name'    => '',
    'email'   => '',
    'country' => $detected_country,
];

// Handle registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {

    $name     = trim($_POST['name'] ?? '');
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['password_confirm'] ?? '';
    $country  = strtoupper(trim($_POST['country_code'] ?? ''));

    // Preserve input
    $old['name']    = $name;
    $old['email']   = $email;
    $old['country'] = $country;

    // Honeypot check
    if (!validate_honeypot('website_url')) {
        $error = 'Submission rejected.';
    }

    // Validate name
    if (empty($error) && empty($name)) {
        $error = 'Full name is required.';
    }

    // Validate email format
    if (empty($error) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    }

    // Validate email uniqueness
    if (empty($error)) {
        $stmt = $db->prepare("SELECT id FROM customers WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'An account with this email already exists. <a href="login.php" style="color:#1565C0;font-weight:600;">Login instead</a>';
        }
    }

    // Validate password
    if (empty($error) && strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    }

    // Validate password match
    if (empty($error) && $password !== $confirm) {
        $error = 'Passwords do not match.';
    }

    // Validate country code
    if (empty($error) && (strlen($country) !== 2 || !ctype_alpha($country))) {
        $error = 'Please select a valid country.';
    }

    // All good — create account
    if (empty($error)) {
        $password_hash = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $db->prepare(
            "INSERT INTO customers (name, email, password_hash, country_code, email_verified, is_active, created_at)
             VALUES (?, ?, ?, ?, 0, 1, NOW())"
        );
        $stmt->execute([$name, $email, $password_hash, $country]);
        $new_id = $db->lastInsertId();

        if (is_email_verification_required()) {
            // Generate and send verification code
            $code = generate_verification_code();
            store_verification_code($email, $code, 'registration');
            send_verification_email($email, $code, $name);

            header('Location: /solarglobal/customer/verify-email.php?email=' . urlencode($email));
            exit();
        } else {
            // Auto-login
            $stmt = $db->prepare("SELECT * FROM customers WHERE id = ?");
            $stmt->execute([$new_id]);
            $customer = $stmt->fetch();

            $db->prepare("UPDATE customers SET email_verified = 1 WHERE id = ?")->execute([$new_id]);

            customer_login($customer);
            header('Location: /solarglobal/customer/orders.php');
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - <?= sanitize($site_name) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0F172A 0%, #1E3A5F 50%, #0F172A 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .register-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 440px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
            margin: 20px;
        }

        .logo { text-align: center; margin-bottom: 28px; }
        .logo h1 { font-size: 1.75rem; font-weight: 800; color: #0F172A; }
        .logo h1 span { color: #F59E0B; }
        .logo p { color: #64748B; font-size: 0.875rem; margin-top: 4px; }

        .alert { padding: 12px 16px; border-radius: 10px; font-size: 0.875rem; margin-bottom: 20px; line-height: 1.5; }
        .alert-error { background: #FEF2F2; color: #991B1B; border: 1px solid #FECACA; }
        .alert a { color: #1565C0; font-weight: 600; text-decoration: none; }
        .alert a:hover { text-decoration: underline; }

        .form-group { margin-bottom: 16px; }
        .form-group label {
            display: block;
            font-size: 0.8125rem;
            font-weight: 600;
            color: #374151;
            margin-bottom: 6px;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #E2E8F0;
            border-radius: 10px;
            font-size: 0.9375rem;
            font-family: inherit;
            transition: border-color 0.2s;
            background: #fff;
        }
        .form-group input:focus,
        .form-group select:focus { outline: none; border-color: #F59E0B; }
        .form-group .field-hint {
            font-size: 0.75rem;
            color: #94A3B8;
            margin-top: 4px;
        }
        .form-group .field-error {
            font-size: 0.75rem;
            color: #DC2626;
            margin-top: 4px;
            display: none;
        }

        .password-wrapper { position: relative; }
        .password-wrapper input { padding-right: 48px; }
        .password-toggle {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: #94A3B8;
            font-size: 1.1rem;
            padding: 4px;
            line-height: 1;
        }
        .password-toggle:hover { color: #64748B; }

        .btn {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 10px;
            font-size: 0.9375rem;
            font-weight: 700;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.2s;
            margin-top: 4px;
        }
        .btn-primary { background: #F59E0B; color: #1E293B; }
        .btn-primary:hover { background: #D97706; transform: translateY(-1px); }
        .btn-primary:disabled { background: #E2E8F0; color: #94A3B8; cursor: not-allowed; transform: none; }

        .login-link {
            text-align: center;
            margin-top: 24px;
            font-size: 0.875rem;
            color: #64748B;
        }
        .login-link a { color: #F59E0B; text-decoration: none; font-weight: 600; }
        .login-link a:hover { text-decoration: underline; }

        .back-link { text-align: center; margin-top: 12px; }
        .back-link a { color: #64748B; text-decoration: none; font-size: 0.8125rem; }
        .back-link a:hover { color: #F59E0B; }

        .hp-field { position: absolute; left: -9999px; opacity: 0; height: 0; width: 0; overflow: hidden; }

        .password-strength {
            height: 4px;
            border-radius: 2px;
            background: #E2E8F0;
            margin-top: 8px;
            overflow: hidden;
        }
        .password-strength-bar {
            height: 100%;
            border-radius: 2px;
            width: 0;
            transition: width 0.3s, background 0.3s;
        }

        @media (max-width: 480px) {
            .register-card { padding: 28px 24px; margin: 12px; }
            .logo h1 { font-size: 1.5rem; }
        }
    </style>
</head>
<body>
    <div class="register-card">
        <div class="logo">
            <h1><?php
                $parts = preg_split('/(?=[A-Z])/', $site_name, -1, PREG_SPLIT_NO_EMPTY);
                if (count($parts) >= 2) {
                    echo sanitize($parts[0]) . '<span>' . sanitize(implode('', array_slice($parts, 1))) . '</span>';
                } else {
                    echo sanitize($site_name);
                }
            ?></h1>
            <p>Create your account</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST" id="register-form" novalidate>
            <?= csrf_field() ?>
            <!-- Honeypot -->
            <div class="hp-field" aria-hidden="true">
                <label for="website_url">Website</label>
                <input type="text" name="website_url" id="website_url" tabindex="-1" autocomplete="off">
            </div>

            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" placeholder="John Doe" required
                       value="<?= sanitize($old['name']) ?>" autocomplete="name">
                <div class="field-error" id="name-error">Please enter your full name.</div>
            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" placeholder="you@example.com" required
                       value="<?= sanitize($old['email']) ?>" autocomplete="email">
                <div class="field-error" id="email-error">Please enter a valid email address.</div>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password" placeholder="Min. 8 characters" required
                           minlength="8" autocomplete="new-password">
                    <button type="button" class="password-toggle" onclick="togglePassword('password', this)" aria-label="Toggle password visibility">&#128065;</button>
                </div>
                <div class="password-strength"><div class="password-strength-bar" id="pw-strength-bar"></div></div>
                <div class="field-hint" id="pw-hint">At least 8 characters</div>
                <div class="field-error" id="password-error">Password must be at least 8 characters.</div>
            </div>

            <div class="form-group">
                <label for="password_confirm">Confirm Password</label>
                <div class="password-wrapper">
                    <input type="password" id="password_confirm" name="password_confirm" placeholder="Re-enter password" required
                           minlength="8" autocomplete="new-password">
                    <button type="button" class="password-toggle" onclick="togglePassword('password_confirm', this)" aria-label="Toggle password visibility">&#128065;</button>
                </div>
                <div class="field-error" id="confirm-error">Passwords do not match.</div>
            </div>

            <div class="form-group">
                <label for="country_code">Country</label>
                <select id="country_code" name="country_code" required>
                    <option value="">Select your country</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary" id="submit-btn">Create Account</button>
        </form>

        <div class="login-link">
            Already have an account? <a href="login.php">Login</a>
        </div>

        <div class="back-link">
            <a href="/solarglobal/">&larr; Back to <?= sanitize($site_name) ?></a>
        </div>
    </div>

    <script>
    // Country list
    const countries = [
        {code:'AF',name:'Afghanistan'},{code:'AL',name:'Albania'},{code:'DZ',name:'Algeria'},{code:'AD',name:'Andorra'},
        {code:'AO',name:'Angola'},{code:'AG',name:'Antigua and Barbuda'},{code:'AR',name:'Argentina'},{code:'AM',name:'Armenia'},
        {code:'AU',name:'Australia'},{code:'AT',name:'Austria'},{code:'AZ',name:'Azerbaijan'},{code:'BS',name:'Bahamas'},
        {code:'BH',name:'Bahrain'},{code:'BD',name:'Bangladesh'},{code:'BB',name:'Barbados'},{code:'BY',name:'Belarus'},
        {code:'BE',name:'Belgium'},{code:'BZ',name:'Belize'},{code:'BJ',name:'Benin'},{code:'BT',name:'Bhutan'},
        {code:'BO',name:'Bolivia'},{code:'BA',name:'Bosnia and Herzegovina'},{code:'BW',name:'Botswana'},{code:'BR',name:'Brazil'},
        {code:'BN',name:'Brunei'},{code:'BG',name:'Bulgaria'},{code:'BF',name:'Burkina Faso'},{code:'BI',name:'Burundi'},
        {code:'CV',name:'Cabo Verde'},{code:'KH',name:'Cambodia'},{code:'CM',name:'Cameroon'},{code:'CA',name:'Canada'},
        {code:'CF',name:'Central African Republic'},{code:'TD',name:'Chad'},{code:'CL',name:'Chile'},{code:'CN',name:'China'},
        {code:'CO',name:'Colombia'},{code:'KM',name:'Comoros'},{code:'CG',name:'Congo'},{code:'CD',name:'Congo (DRC)'},
        {code:'CR',name:'Costa Rica'},{code:'CI',name:"Cote d'Ivoire"},{code:'HR',name:'Croatia'},{code:'CU',name:'Cuba'},
        {code:'CY',name:'Cyprus'},{code:'CZ',name:'Czech Republic'},{code:'DK',name:'Denmark'},{code:'DJ',name:'Djibouti'},
        {code:'DM',name:'Dominica'},{code:'DO',name:'Dominican Republic'},{code:'EC',name:'Ecuador'},{code:'EG',name:'Egypt'},
        {code:'SV',name:'El Salvador'},{code:'GQ',name:'Equatorial Guinea'},{code:'ER',name:'Eritrea'},{code:'EE',name:'Estonia'},
        {code:'SZ',name:'Eswatini'},{code:'ET',name:'Ethiopia'},{code:'FJ',name:'Fiji'},{code:'FI',name:'Finland'},
        {code:'FR',name:'France'},{code:'GA',name:'Gabon'},{code:'GM',name:'Gambia'},{code:'GE',name:'Georgia'},
        {code:'DE',name:'Germany'},{code:'GH',name:'Ghana'},{code:'GR',name:'Greece'},{code:'GD',name:'Grenada'},
        {code:'GT',name:'Guatemala'},{code:'GN',name:'Guinea'},{code:'GW',name:'Guinea-Bissau'},{code:'GY',name:'Guyana'},
        {code:'HT',name:'Haiti'},{code:'HN',name:'Honduras'},{code:'HU',name:'Hungary'},{code:'IS',name:'Iceland'},
        {code:'IN',name:'India'},{code:'ID',name:'Indonesia'},{code:'IR',name:'Iran'},{code:'IQ',name:'Iraq'},
        {code:'IE',name:'Ireland'},{code:'IL',name:'Israel'},{code:'IT',name:'Italy'},{code:'JM',name:'Jamaica'},
        {code:'JP',name:'Japan'},{code:'JO',name:'Jordan'},{code:'KZ',name:'Kazakhstan'},{code:'KE',name:'Kenya'},
        {code:'KI',name:'Kiribati'},{code:'KP',name:'North Korea'},{code:'KR',name:'South Korea'},{code:'KW',name:'Kuwait'},
        {code:'KG',name:'Kyrgyzstan'},{code:'LA',name:'Laos'},{code:'LV',name:'Latvia'},{code:'LB',name:'Lebanon'},
        {code:'LS',name:'Lesotho'},{code:'LR',name:'Liberia'},{code:'LY',name:'Libya'},{code:'LI',name:'Liechtenstein'},
        {code:'LT',name:'Lithuania'},{code:'LU',name:'Luxembourg'},{code:'MG',name:'Madagascar'},{code:'MW',name:'Malawi'},
        {code:'MY',name:'Malaysia'},{code:'MV',name:'Maldives'},{code:'ML',name:'Mali'},{code:'MT',name:'Malta'},
        {code:'MH',name:'Marshall Islands'},{code:'MR',name:'Mauritania'},{code:'MU',name:'Mauritius'},{code:'MX',name:'Mexico'},
        {code:'FM',name:'Micronesia'},{code:'MD',name:'Moldova'},{code:'MC',name:'Monaco'},{code:'MN',name:'Mongolia'},
        {code:'ME',name:'Montenegro'},{code:'MA',name:'Morocco'},{code:'MZ',name:'Mozambique'},{code:'MM',name:'Myanmar'},
        {code:'NA',name:'Namibia'},{code:'NR',name:'Nauru'},{code:'NP',name:'Nepal'},{code:'NL',name:'Netherlands'},
        {code:'NZ',name:'New Zealand'},{code:'NI',name:'Nicaragua'},{code:'NE',name:'Niger'},{code:'NG',name:'Nigeria'},
        {code:'MK',name:'North Macedonia'},{code:'NO',name:'Norway'},{code:'OM',name:'Oman'},{code:'PK',name:'Pakistan'},
        {code:'PW',name:'Palau'},{code:'PS',name:'Palestine'},{code:'PA',name:'Panama'},{code:'PG',name:'Papua New Guinea'},
        {code:'PY',name:'Paraguay'},{code:'PE',name:'Peru'},{code:'PH',name:'Philippines'},{code:'PL',name:'Poland'},
        {code:'PT',name:'Portugal'},{code:'QA',name:'Qatar'},{code:'RO',name:'Romania'},{code:'RU',name:'Russia'},
        {code:'RW',name:'Rwanda'},{code:'KN',name:'Saint Kitts and Nevis'},{code:'LC',name:'Saint Lucia'},
        {code:'VC',name:'Saint Vincent and the Grenadines'},{code:'WS',name:'Samoa'},{code:'SM',name:'San Marino'},
        {code:'ST',name:'Sao Tome and Principe'},{code:'SA',name:'Saudi Arabia'},{code:'SN',name:'Senegal'},
        {code:'RS',name:'Serbia'},{code:'SC',name:'Seychelles'},{code:'SL',name:'Sierra Leone'},{code:'SG',name:'Singapore'},
        {code:'SK',name:'Slovakia'},{code:'SI',name:'Slovenia'},{code:'SB',name:'Solomon Islands'},{code:'SO',name:'Somalia'},
        {code:'ZA',name:'South Africa'},{code:'SS',name:'South Sudan'},{code:'ES',name:'Spain'},{code:'LK',name:'Sri Lanka'},
        {code:'SD',name:'Sudan'},{code:'SR',name:'Suriname'},{code:'SE',name:'Sweden'},{code:'CH',name:'Switzerland'},
        {code:'SY',name:'Syria'},{code:'TW',name:'Taiwan'},{code:'TJ',name:'Tajikistan'},{code:'TZ',name:'Tanzania'},
        {code:'TH',name:'Thailand'},{code:'TL',name:'Timor-Leste'},{code:'TG',name:'Togo'},{code:'TO',name:'Tonga'},
        {code:'TT',name:'Trinidad and Tobago'},{code:'TN',name:'Tunisia'},{code:'TR',name:'Turkey'},{code:'TM',name:'Turkmenistan'},
        {code:'TV',name:'Tuvalu'},{code:'UG',name:'Uganda'},{code:'UA',name:'Ukraine'},{code:'AE',name:'United Arab Emirates'},
        {code:'GB',name:'United Kingdom'},{code:'US',name:'United States'},{code:'UY',name:'Uruguay'},{code:'UZ',name:'Uzbekistan'},
        {code:'VU',name:'Vanuatu'},{code:'VA',name:'Vatican City'},{code:'VE',name:'Venezuela'},{code:'VN',name:'Vietnam'},
        {code:'YE',name:'Yemen'},{code:'ZM',name:'Zambia'},{code:'ZW',name:'Zimbabwe'}
    ];

    // Populate country select
    const countrySelect = document.getElementById('country_code');
    const selectedCountry = <?= json_encode($old['country']) ?>;
    countries.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.code;
        opt.textContent = c.name;
        if (c.code === selectedCountry) opt.selected = true;
        countrySelect.appendChild(opt);
    });

    // Toggle password visibility
    function togglePassword(fieldId, btn) {
        const input = document.getElementById(fieldId);
        if (input.type === 'password') {
            input.type = 'text';
            btn.innerHTML = '&#128064;';
        } else {
            input.type = 'password';
            btn.innerHTML = '&#128065;';
        }
    }

    // Password strength indicator
    const pwInput = document.getElementById('password');
    const strengthBar = document.getElementById('pw-strength-bar');

    pwInput.addEventListener('input', function() {
        const val = this.value;
        let score = 0;
        if (val.length >= 8) score++;
        if (val.length >= 12) score++;
        if (/[A-Z]/.test(val) && /[a-z]/.test(val)) score++;
        if (/\d/.test(val)) score++;
        if (/[^A-Za-z0-9]/.test(val)) score++;

        const pct = Math.min(score / 5 * 100, 100);
        const colors = ['#EF4444', '#F97316', '#EAB308', '#84CC16', '#22C55E'];
        strengthBar.style.width = pct + '%';
        strengthBar.style.background = colors[Math.min(score, colors.length) - 1] || '#E2E8F0';
    });

    // Client-side validation
    const form = document.getElementById('register-form');
    form.addEventListener('submit', function(e) {
        let valid = true;

        // Reset errors
        document.querySelectorAll('.field-error').forEach(el => el.style.display = 'none');

        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        const confirm = document.getElementById('password_confirm').value;

        if (!name) {
            document.getElementById('name-error').style.display = 'block';
            valid = false;
        }

        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            document.getElementById('email-error').style.display = 'block';
            valid = false;
        }

        if (password.length < 8) {
            document.getElementById('password-error').style.display = 'block';
            valid = false;
        }

        if (password !== confirm) {
            document.getElementById('confirm-error').style.display = 'block';
            valid = false;
        }

        if (!valid) {
            e.preventDefault();
        }
    });
    </script>
</body>
</html>
