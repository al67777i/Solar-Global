# SolarGlobal - Smart Solar Energy Platform

**The Intelligent Solar System Recommender & Marketplace**

[![Version](https://img.shields.io/badge/version-8.0-blue.svg)](https://solarglobal.com)
[![PHP](https://img.shields.io/badge/PHP-8.0%2B-777BB4.svg)](https://www.php.net/)
[![MySQL](https://img.shields.io/badge/MySQL-8.0%2B-4479A1.svg)](https://www.mysql.com/)
[![License](https://img.shields.io/badge/license-Proprietary-red.svg)](LICENSE)

---

## 🌟 Overview

SolarGlobal is a sophisticated web application that helps homeowners and businesses find the perfect solar power system based on their actual electricity needs. Using advanced algorithms and real-time calculations, it provides accurate recommendations for inverters, batteries, and solar panels with complete installation guides and an integrated marketplace for verified dealers and installers.

### Key Features

- **🤖 AI-Powered Recommendations** - Smart algorithm analyzes your load and suggests optimal systems
- **⚡ Real-Time Calculations** - Instant system sizing with 24-hour energy flow simulation
- **🔋 BMS vs Non-BMS Support** - Intelligent battery selection based on system requirements
- **☀️ Visual Panel Selector** - Modern card-based interface with category tabs
- **📊 Interactive Configurator** - Customize any component and see live performance graphs
- **🔌 Professional Wiring Diagrams** - Animated installation guides with series/parallel configurations
- **💰 Cost Analysis** - Detailed pricing with multi-currency support
- **📱 Fully Responsive** - Works perfectly on desktop, tablet, and mobile devices
- **🌐 International Support** - Multi-currency and location detection
- **🔒 Secure Admin Panel** - Complete CRUD operations for products and settings

---

## 🚀 Live Platform

**Frontend:** [https://solarglobal.com](https://solarglobal.com)  
**Admin Panel:** [https://solarglobal.com/admin](https://solarglobal.com/admin)

---

## 📋 Table of Contents

- [System Requirements](#system-requirements)
- [Installation](#installation)
- [Database Setup](#database-setup)
- [Configuration](#configuration)
- [Features](#features)
- [Technology Stack](#technology-stack)
- [Project Structure](#project-structure)
- [API Documentation](#api-documentation)
- [SEO Optimization](#seo-optimization)
- [Admin Panel](#admin-panel)
- [Troubleshooting](#troubleshooting)
- [Credits](#credits)
- [License](#license)

---

## 💻 System Requirements

### Server Requirements
- **PHP:** 8.0 or higher
- **MySQL:** 8.0 or higher (or MariaDB 10.5+)
- **Apache:** 2.4+ with mod_rewrite enabled
- **Memory:** Minimum 256MB PHP memory limit
- **Storage:** Minimum 100MB free space

### PHP Extensions Required
- `mysqli` - MySQL database connectivity
- `pdo_mysql` - PDO MySQL driver
- `json` - JSON encoding/decoding
- `mbstring` - Multibyte string support
- `session` - Session management

### Browser Support
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

---

## 📦 Installation

### Step 1: Clone or Download

```bash
# Clone the repository
git clone https://github.com/solarglobal/solarglobal.git

# Or download and extract ZIP file
cd solarglobal
```

### Step 2: Configure Web Server

#### Apache Configuration

Create or edit `.htaccess` in the root directory:

```apache
# Enable Rewrite Engine
RewriteEngine On
RewriteBase /solarglobal/

# Remove .php extension
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME}\.php -f
RewriteRule ^(.*)$ $1.php [L]

# Security Headers
Header set X-Content-Type-Options "nosniff"
Header set X-Frame-Options "SAMEORIGIN"
Header set X-XSS-Protection "1; mode=block"
Header set Referrer-Policy "strict-origin-when-cross-origin"

# Disable directory browsing
Options -Indexes

# Protect sensitive files
<FilesMatch "\.(sql|md|json|log)$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

#### Nginx Configuration (Alternative)

```nginx
location /solar-recommender {
    try_files $uri $uri/ $uri.php?$query_string;
    
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.0-fpm.sock;
        fastcgi_index index.php;
        include fastcgi_params;
    }
}
```

### Step 3: Set Permissions

```bash
# Make uploads directory writable
chmod 755 uploads/
chmod 755 uploads/appliances/
chmod 755 uploads/inverters/
chmod 755 uploads/batteries/
chmod 755 uploads/panels/

# Secure includes directory
chmod 644 includes/*.php
```

---

## 🗄️ Database Setup

### Step 1: Create Database

```sql
CREATE DATABASE solar_recommender CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### Step 2: Import Schema

```bash
mysql -u your_username -p solar_recommender < solar_recommender.sql
```

Or use phpMyAdmin:
1. Open phpMyAdmin
2. Create database `solar_recommender`
3. Import `solar_recommender.sql` file

### Step 3: Configure Database Connection

Edit `includes/db.php`:

```php
<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'solar_recommender');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_CHARSET', 'utf8mb4');
```

### Step 4: Verify Connection

Visit: `http://localhost/solar-recommender/`

If you see the homepage, database is connected successfully!

---

## ⚙️ Configuration

### Base URL Configuration

Edit `includes/helpers.php`:

```php
function getBaseUrl() {
    return 'http://localhost/solar-recommender';
}
```

For production:

```php
function getBaseUrl() {
    return 'https://yourdomain.com/solar-recommender';
}
```

### Admin Account Setup

Default admin credentials:
- **Username:** `admin`
- **Password:** `admin123`

**⚠️ IMPORTANT:** Change the default password immediately after first login!

To create a new admin account:

```sql
INSERT INTO admin_users (username, password, email, full_name) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@solarglobal.com', 'Administrator');
```

---

## ✨ Features

### 1. Smart Appliance Selector

- **Visual Interface:** Click-to-select appliance cards with icons
- **Category Filters:** Cooling, Lighting, Kitchen, Laundry, Utility, Electronics
- **Real-Time Calculations:** Instant load and energy consumption updates
- **Surge Load Support:** Automatic detection of motor-based appliances
- **Home Visualization:** Interactive house diagram showing selected appliances

### 2. Intelligent Recommendation Engine (V7)

**Algorithm Features:**
- Multi-tier inverter selection (Budget, Standard, Premium)
- BMS vs Non-BMS battery optimization
- Voltage class matching (12V, 24V, 48V, 96V)
- Panel series/parallel calculation with VDC validation
- 24-hour energy flow simulation
- Grid usage optimization
- Battery depth-of-discharge (DoD) calculations
- Round-trip efficiency modeling

**Recommendation Criteria:**
- Peak load capacity with 20% safety margin
- Backup hours requirement (1-24 hours)
- Daily energy consumption
- Solar generation potential
- Battery storage capacity
- Cost optimization

### 3. Interactive System Configurator

**Real-Time Customization:**
- Change inverter (dropdown with specs)
- Adjust battery quantity (series/parallel auto-calculation)
- Select panel type (visual card selector with categories)
- Modify panel quantity (min/max validation)

**Live Updates:**
- 24-hour energy flow graph (Chart.js)
- System performance metrics
- Cost analysis with savings
- Wiring configurations
- VDC compatibility checks

### 4. Professional Installation Guide

**Animated Diagrams:**
- Battery wiring (series/parallel with voltage labels)
- Panel layout (roof placement with dimensions)
- Complete system circuit diagram
- Step-by-step installation instructions

**Features:**
- Anime.js powered animations
- Interactive component highlighting
- Downloadable PDF guides
- Print-friendly layouts

### 5. Product Catalog Pages

**Dedicated Pages:**
- Inverters (`inverters.php`)
- Batteries (`batteries.php`)
- Solar Panels (`panels.php`)

**Features:**
- Filterable by company, voltage, capacity
- Sortable by price, rating, popularity
- Detailed specifications
- Comparison tool
- Direct inquiry forms

### 6. Comparison Widget

- Compare up to 3 systems side-by-side
- Floating widget accessible from any page
- Detailed spec comparison
- Cost analysis
- Performance metrics

### 7. SEO Optimization

**On-Page SEO:**
- Semantic HTML5 structure
- Meta tags (title, description, keywords)
- Open Graph tags (Facebook)
- Twitter Card tags
- Schema.org structured data
- Canonical URLs
- XML sitemap
- Robots.txt

**Technical SEO:**
- Clean URLs (no .php extensions)
- Fast page load (<2s)
- Mobile-first responsive design
- Optimized images
- Minified CSS/JS
- GZIP compression

---

## 🛠️ Technology Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with Flexbox/Grid
- **JavaScript (ES6+)** - Vanilla JS, no jQuery
- **Chart.js 4.4** - Energy flow graphs
- **Anime.js 3.2** - Installation guide animations

### Backend
- **PHP 8.0+** - Server-side logic
- **MySQL 8.0+** - Database management
- **PDO** - Secure database queries
- **Sessions** - State management

### Security
- **CSRF Protection** - Token-based validation
- **SQL Injection Prevention** - Prepared statements
- **XSS Protection** - Input sanitization
- **Password Hashing** - bcrypt (PASSWORD_DEFAULT)
- **Session Security** - Secure cookies, regeneration

### Development Tools
- **Git** - Version control
- **Composer** - Dependency management (optional)
- **phpMyAdmin** - Database administration

---

## 📁 Project Structure

```
solar-recommender/
├── admin/                      # Admin panel
│   ├── appliances.php         # Manage appliances
│   ├── batteries.php          # Manage batteries
│   ├── inverters.php          # Manage inverters
│   ├── panels.php             # Manage solar panels
│   ├── companies.php          # Manage companies
│   ├── settings.php           # System settings
│   └── includes/              # Admin headers/footers
├── api/                        # API endpoints
│   ├── recommend_v7.php       # Main recommendation API
│   ├── recalculate_system.php # System recalculation
│   ├── get_all_components.php # Fetch components
│   ├── appliances.php         # Appliance data
│   └── get_csrf_token.php     # CSRF token generation
├── assets/                     # Static assets
│   ├── css/                   # Stylesheets
│   │   ├── main.css           # Global styles
│   │   ├── frontend.css       # Frontend styles
│   │   ├── configurator.css   # Configurator styles
│   │   ├── installation-guide.css
│   │   ├── installation-animated.css
│   │   ├── recommendations.css
│   │   ├── products.css
│   │   ├── compare.css
│   │   ├── animations.css
│   │   └── admin.css          # Admin panel styles
│   ├── js/                    # JavaScript files
│   │   ├── app.js             # Main application
│   │   ├── lang.js            # Language switcher
│   │   ├── appliance-selector.js
│   │   ├── recommender-v2.js  # Recommendation handler
│   │   ├── system-configurator.js
│   │   ├── installation-guide.js
│   │   ├── circuit-diagram.js
│   │   ├── circuit-diagram-professional.js
│   │   ├── products.js        # Product catalog
│   │   ├── comparison-widget.js
│   │   ├── chart.min.js       # Chart.js library
│   │   └── anime.min.js       # Anime.js library
│   └── images/                # Images and icons
├── includes/                   # PHP includes
│   ├── db.php                 # Database connection
│   ├── helpers.php            # Helper functions
│   ├── csrf.php               # CSRF protection
│   ├── header.php             # Site header
│   └── footer.php             # Site footer
├── uploads/                    # User uploads
│   ├── appliances/            # Appliance images
│   ├── inverters/             # Inverter images
│   ├── batteries/             # Battery images
│   └── panels/                # Panel images
├── index.php                   # Homepage
├── about.php                   # About page
├── contact.php                 # Contact page
├── inverters.php               # Inverter catalog
├── batteries.php               # Battery catalog
├── panels.php                  # Panel catalog
├── compare.php                 # Comparison page
├── login.php                   # Admin login
├── logout.php                  # Admin logout
├── solar_recommender.sql       # Database schema
├── .htaccess                   # Apache configuration
├── robots.txt                  # Search engine rules
├── sitemap.xml                 # XML sitemap
└── README.md                   # This file
```

---

## 🔌 API Documentation

### Recommendation API (V7)

**Endpoint:** `POST /api/recommend_v7.php`

**Request:**
```json
{
  "appliances": [
    {
      "id": 1,
      "name": "LED Bulb 15W",
      "quantity": 5,
      "watts": 15,
      "hours": 6,
      "surge_load_watts": 0
    }
  ],
  "backup_hours": 4
}
```

**Response:**
```json
{
  "success": true,
  "load_analysis": {
    "total_load_watts": 1500,
    "peak_load_watts": 1800,
    "daily_kwh": 12.5,
    "system_voltage": 48,
    "backup_hours_requested": 4
  },
  "recommendations": [
    {
      "tier": "standard",
      "inverter": { /* inverter object */ },
      "battery_config": { /* battery configuration */ },
      "panel_config": { /* panel configuration */ },
      "total_cost": 450000,
      "monthly_savings": 15000,
      "payback_months": 30
    }
  ]
}
```

### Recalculate System API

**Endpoint:** `POST /api/recalculate_system.php`

**Request:**
```json
{
  "inverter_id": 5,
  "battery_id": 3,
  "battery_quantity": 8,
  "panel_id": 2,
  "panel_quantity": 12,
  "load_analysis": { /* load analysis object */ }
}
```

**Response:**
```json
{
  "success": true,
  "system": {
    "battery_config": { /* updated battery config */ },
    "panel_config": { /* updated panel config */ },
    "hourly_simulation": [ /* 24-hour data */ ],
    "performance_metrics": { /* metrics */ }
  }
}
```

---

## 🔍 SEO Optimization

### Meta Tags Implementation

Every page includes:
- **Title Tag:** Unique, keyword-rich (50-60 characters)
- **Meta Description:** Compelling, actionable (150-160 characters)
- **Meta Keywords:** Relevant Pakistani solar terms
- **Canonical URL:** Prevents duplicate content
- **Open Graph Tags:** Social media optimization
- **Twitter Cards:** Twitter sharing optimization

### Structured Data (Schema.org)

```json
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "SolarGlobal",
  "description": "Intelligent solar system recommendation and marketplace platform",
  "applicationCategory": "UtilityApplication",
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "PKR"
  }
}
```

### XML Sitemap

Located at `/sitemap.xml`:
- All public pages listed
- Priority and change frequency set
- Last modification dates
- Submitted to Google Search Console

### Robots.txt

```
User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/
Disallow: /includes/
Sitemap: https://yourdomain.com/solar-recommender/sitemap.xml
```

---

## 🔐 Admin Panel

### Access

**URL:** `/admin/dashboard.php`  
**Default Login:** admin / admin123

### Features

1. **Dashboard**
   - System statistics
   - Recent activity
   - Quick actions

2. **Appliance Management**
   - Add/Edit/Delete appliances
   - Image upload
   - Category assignment
   - Surge load configuration

3. **Inverter Management**
   - CRUD operations
   - Voltage class settings
   - BMS/Non-BMS configuration
   - Price management

4. **Battery Management**
   - Battery types (Lithium, Lead-Acid, Tubular, Gel)
   - Voltage and capacity settings
   - Company assignment
   - Pricing

5. **Solar Panel Management**
   - Panel specifications (Voc, Vmp, Wattage)
   - Efficiency ratings
   - Panel types (Monocrystalline, Polycrystalline)
   - Company management

6. **Company Management**
   - Add/Edit companies
   - Logo upload
   - Contact information
   - Product associations

7. **Settings**
   - System configuration
   - SEO settings
   - Email configuration
   - Maintenance mode

### Security Features

- Session-based authentication
- CSRF protection on all forms
- Password hashing (bcrypt)
- SQL injection prevention
- XSS protection
- Role-based access control

---

## 🐛 Troubleshooting

### Common Issues

#### 1. Blank Page / White Screen

**Cause:** PHP errors not displayed

**Solution:**
```php
// Add to top of index.php temporarily
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

Check PHP error log: `/var/log/apache2/error.log`

#### 2. Database Connection Failed

**Symptoms:** "Could not connect to database" error

**Solutions:**
- Verify database credentials in `includes/db.php`
- Check MySQL service is running: `sudo service mysql status`
- Verify database exists: `SHOW DATABASES;`
- Check user permissions: `GRANT ALL ON solar_recommender.* TO 'user'@'localhost';`

#### 3. Chart Not Displaying

**Symptoms:** "Chart.js failed to load" error

**Solutions:**
- Verify `assets/js/chart.min.js` exists
- Check browser console for errors (F12)
- Clear browser cache
- Verify file permissions: `chmod 644 assets/js/chart.min.js`

#### 4. Images Not Loading

**Symptoms:** Broken image icons

**Solutions:**
- Check file paths in database
- Verify uploads directory permissions: `chmod 755 uploads/`
- Check `.htaccess` allows image access
- Verify image files exist in correct directories

#### 5. Admin Login Not Working

**Symptoms:** "Invalid credentials" or redirect loop

**Solutions:**
- Verify admin account exists in database
- Check session configuration in `php.ini`
- Clear browser cookies
- Verify `session_start()` is called
- Check session directory permissions

#### 6. Recommendation API Returns Empty

**Symptoms:** No recommendations shown

**Solutions:**
- Check database has products (inverters, batteries, panels)
- Verify API endpoint URL is correct
- Check browser console for JavaScript errors
- Verify `api/recommend_v7.php` file exists
- Check PHP error log for API errors

### Debug Mode

Enable debug mode in `includes/helpers.php`:

```php
define('DEBUG_MODE', true);

if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}
```

### Performance Optimization

1. **Enable OPcache** (php.ini):
```ini
opcache.enable=1
opcache.memory_consumption=128
opcache.max_accelerated_files=10000
```

2. **Enable GZIP Compression** (.htaccess):
```apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript
</IfModule>
```

3. **Browser Caching** (.htaccess):
```apache
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

---

## 👨‍💻 Credits

### Development Team

**Lead Developer:** Bilal Ansar  
**Company:** SolarGlobal  
**Location:** Gujranwala, Punjab, Pakistan  
**Email:** info@solarglobal.com  
**Phone:** +92 305 4957063  
**Website:** [solarglobal.com](https://solarglobal.com)

### Technologies Used

- **Chart.js** - MIT License - [chartjs.org](https://www.chartjs.org/)
- **Anime.js** - MIT License - [animejs.com](https://animejs.com/)
- **PHP** - PHP License - [php.net](https://www.php.net/)
- **MySQL** - GPL License - [mysql.com](https://www.mysql.com/)

---

## 📄 License

**Proprietary Software**

Copyright © 2026 SolarGlobal. All rights reserved.

This software is proprietary and confidential. Unauthorized copying, distribution, modification, or use of this software, via any medium, is strictly prohibited without explicit written permission from SolarGlobal.

For licensing inquiries, contact: info@solarglobal.com

---

## 📞 Support

### Technical Support

**Email:** info@solarglobal.com  
**Phone:** +92 305 4957063  
**Hours:** Monday-Saturday, 9 AM - 6 PM PKT

---

## 🌟 Why Choose SolarGlobal?

✅ **Accurate Calculations** - Advanced algorithms ensure precise system sizing  
✅ **Multi-Market Focus** - International currency and localized energy profiles  
✅ **User-Friendly** - Intuitive interface anyone can use  
✅ **Comprehensive** - From appliance selection to installation guide  
✅ **Professional** - Enterprise-grade code quality and security  
✅ **Customizable** - Easy to modify and extend  
✅ **SEO Optimized** - Built for search engine visibility  
✅ **Mobile Ready** - Responsive design works on all devices  

---

**Made with ❤️ by SolarGlobal**

*Empowering Pakistan with clean, affordable solar energy solutions.*

---

**Last Updated:** May 10, 2026  
**Version:** 7.0  
**Status:** Production Ready ✅
