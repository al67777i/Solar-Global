<?php
/**
 * Installer Dashboard - Main installer control panel
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/installer_auth.php';

set_security_headers();
require_installer_login();

$installer = get_installer_profile();
$db = getDB();

// Stats
$portfolio_count = get_installer_portfolio_count();

// Reviews count and average
$stmt = $db->prepare("SELECT COUNT(*) as cnt, COALESCE(AVG(rating), 0) as avg_rating FROM installer_reviews WHERE installer_id = ?");
$stmt->execute([$installer['id']]);
$review_stats = $stmt->fetch();
$review_count = (int)$review_stats['cnt'];
$avg_rating = round((float)$review_stats['avg_rating'], 1);

// Completed installations (from portfolio)
$completed_installations = $portfolio_count;

// Profile views
$profile_views = (int)($installer['profile_views'] ?? 0);

// Installation orders stats
$pending_requests = 0;
$active_orders = 0;
$completed_orders = 0;
$total_revenue = 0;
try {
    $stmt = $db->prepare("SELECT status, COUNT(*) as cnt FROM installer_orders WHERE installer_id = ? GROUP BY status");
    $stmt->execute([$installer['id']]);
    foreach ($stmt->fetchAll() as $r) {
        if ($r['status'] === 'requested') $pending_requests = (int)$r['cnt'];
        if (in_array($r['status'], ['accepted', 'in_progress'])) $active_orders += (int)$r['cnt'];
        if ($r['status'] === 'completed') $completed_orders = (int)$r['cnt'];
    }
    $stmt = $db->prepare("SELECT COALESCE(SUM(total_amount), 0) FROM installer_orders WHERE installer_id = ? AND status = 'completed'");
    $stmt->execute([$installer['id']]);
    $total_revenue = (float)$stmt->fetchColumn();
} catch (Exception $e) {}

// Recent reviews
$stmt = $db->prepare("SELECT * FROM installer_reviews WHERE installer_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->execute([$installer['id']]);
$recent_reviews = $stmt->fetchAll();

// Status info
$status_config = [
    'pending'   => ['label' => 'Pending Review',    'color' => '#F59E0B', 'bg' => '#FEF3C7', 'icon' => '&#9203;'],
    'approved'  => ['label' => 'Approved & Active',  'color' => '#16A34A', 'bg' => '#DCFCE7', 'icon' => '&#10004;'],
    'active'    => ['label' => 'Active & Live',      'color' => '#16A34A', 'bg' => '#DCFCE7', 'icon' => '&#10004;'],
    'suspended' => ['label' => 'Suspended',          'color' => '#DC2626', 'bg' => '#FEE2E2', 'icon' => '&#9888;'],
    'rejected'  => ['label' => 'Rejected',           'color' => '#DC2626', 'bg' => '#FEE2E2', 'icon' => '&#10060;'],
];
$status = $status_config[$installer['status']] ?? $status_config['pending'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?= sanitize($installer['business_name']) ?> | <?= get_system_setting('site_name', 'SolarGlobal') ?> Installer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        /* Sidebar */
        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 260px;
            background: #0F172A; color: white; z-index: 100;
            display: flex; flex-direction: column; transition: transform 0.3s;
        }
        .sidebar-header {
            padding: 24px 20px; border-bottom: 1px solid #1E293B;
        }
        .sidebar-header h2 { font-size: 1.25rem; font-weight: 800; color: #F59E0B; }
        .sidebar-header p { font-size: 0.75rem; color: #94A3B8; margin-top: 2px; }

        .sidebar-nav { flex: 1; padding: 16px 12px; overflow-y: auto; }
        .nav-section { margin-bottom: 24px; }
        .nav-section-title {
            font-size: 0.6875rem; text-transform: uppercase; letter-spacing: 1px;
            color: #475569; padding: 0 12px; margin-bottom: 8px; font-weight: 600;
        }
        .nav-item {
            display: flex; align-items: center; gap: 12px; padding: 10px 12px;
            border-radius: 8px; color: #CBD5E1; text-decoration: none;
            font-size: 0.875rem; font-weight: 500; transition: all 0.2s; cursor: pointer;
        }
        .nav-item:hover { background: #1E293B; color: white; }
        .nav-item.active { background: #D97706; color: white; }
        .nav-item .icon { font-size: 1.125rem; width: 24px; text-align: center; }
        .nav-item .badge {
            margin-left: auto; background: #DC2626; color: white;
            font-size: 0.6875rem; padding: 2px 7px; border-radius: 10px; font-weight: 700;
        }

        .sidebar-footer {
            padding: 16px 12px; border-top: 1px solid #1E293B;
        }
        .installer-info {
            display: flex; align-items: center; gap: 10px; padding: 8px;
        }
        .installer-avatar {
            width: 36px; height: 36px; border-radius: 8px; background: #334155;
            display: flex; align-items: center; justify-content: center;
            font-size: 1rem; overflow: hidden;
        }
        .installer-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .installer-meta .d-name { font-size: 0.8125rem; font-weight: 600; color: #E2E8F0; }
        .installer-meta .d-email { font-size: 0.6875rem; color: #64748B; }

        /* Main content */
        .main-content {
            margin-left: 260px; padding: 24px 32px; min-height: 100vh;
        }

        .top-bar {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 32px;
        }
        .top-bar h1 { font-size: 1.5rem; font-weight: 700; color: #1E293B; }
        .top-bar .greeting { font-size: 0.875rem; color: #64748B; }

        .mobile-menu-btn {
            display: none; background: #0F172A; color: white; border: none;
            width: 40px; height: 40px; border-radius: 8px; font-size: 1.25rem;
            cursor: pointer;
        }

        /* Status banner */
        .status-banner {
            display: flex; align-items: center; gap: 16px;
            padding: 16px 24px; border-radius: 12px; margin-bottom: 28px;
            font-size: 0.9375rem; font-weight: 600;
        }
        .status-banner .s-icon { font-size: 1.5rem; }
        .status-banner .s-text { flex: 1; }

        /* Stat cards */
        .stat-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px; margin-bottom: 32px;
        }
        .stat-card {
            background: white; border-radius: 14px; padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
        }
        .stat-card .sc-label { font-size: 0.8125rem; color: #64748B; font-weight: 500; margin-bottom: 8px; }
        .stat-card .sc-value { font-size: 2rem; font-weight: 800; color: #1E293B; }
        .stat-card .sc-sub { font-size: 0.8125rem; color: #94A3B8; margin-top: 4px; }
        .stat-card .sc-icon { font-size: 2rem; float: right; margin-top: -4px; }

        .stars { color: #F59E0B; }

        /* Content cards */
        .content-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        .content-card {
            background: white; border-radius: 14px; padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
        }
        .content-card h3 {
            font-size: 1rem; font-weight: 700; color: #1E293B; margin-bottom: 16px;
            padding-bottom: 12px; border-bottom: 1px solid #F1F5F9;
        }
        .quick-action {
            display: flex; align-items: center; gap: 12px; padding: 12px;
            border-radius: 10px; text-decoration: none; color: #334155;
            transition: all 0.2s; font-size: 0.875rem; font-weight: 500;
        }
        .quick-action:hover { background: #F1F5F9; }
        .quick-action .qa-icon {
            width: 40px; height: 40px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.125rem;
        }

        .review-item {
            padding: 12px 0; border-bottom: 1px solid #F1F5F9;
        }
        .review-item:last-child { border-bottom: none; }
        .review-item .r-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
        .review-item .r-name { font-weight: 600; font-size: 0.875rem; color: #1E293B; }
        .review-item .r-date { font-size: 0.75rem; color: #94A3B8; }
        .review-item .r-text { font-size: 0.8125rem; color: #64748B; line-height: 1.4; }
        .review-item .r-stars { color: #F59E0B; font-size: 0.8125rem; margin-bottom: 4px; }

        .empty-state { text-align: center; padding: 24px; color: #94A3B8; font-size: 0.875rem; }

        /* Responsive */
        @media (max-width: 900px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .mobile-menu-btn { display: block; }
            .content-grid { grid-template-columns: 1fr; }
            .stat-grid { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 500px) {
            .stat-grid { grid-template-columns: 1fr; }
        }

        .overlay {
            display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5);
            z-index: 90;
        }
        .overlay.active { display: block; }
    </style>
</head>
<body>
<?php $current_installer_page = 'dashboard'; include __DIR__ . '/includes/sidebar.php'; ?>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-bar">
            <div>
                <button class="mobile-menu-btn" onclick="toggleSidebar()">&#9776;</button>
                <h1>Dashboard</h1>
                <div class="greeting">Welcome back, <?= sanitize($installer['owner_name']) ?>!</div>
            </div>
        </div>

        <!-- Status Banner -->
        <div class="status-banner" style="background:<?= $status['bg'] ?>; color:<?= $status['color'] ?>">
            <span class="s-icon"><?= $status['icon'] ?></span>
            <span class="s-text">
                Account Status: <strong><?= $status['label'] ?></strong>
                <?php if ($installer['status'] === 'pending'): ?>
                    <br><small style="font-weight:400">Your application is being reviewed. You can set up your profile and portfolio in the meantime.</small>
                <?php elseif ($installer['status'] === 'approved'): ?>
                    <br><small style="font-weight:400">Your profile is live! Customers can now find and contact you.</small>
                <?php endif; ?>
            </span>
        </div>

        <!-- Stats -->
        <div class="stat-grid">
            <div class="stat-card">
                <span class="sc-icon">&#128276;</span>
                <div class="sc-label">Pending Requests</div>
                <div class="sc-value"><?= $pending_requests ?></div>
                <div class="sc-sub">Awaiting your response</div>
            </div>
            <div class="stat-card">
                <span class="sc-icon">&#128296;</span>
                <div class="sc-label">Active Orders</div>
                <div class="sc-value"><?= $active_orders ?></div>
                <div class="sc-sub">Accepted / In Progress</div>
            </div>
            <div class="stat-card">
                <span class="sc-icon">&#10004;</span>
                <div class="sc-label">Completed</div>
                <div class="sc-value"><?= $completed_orders ?></div>
                <div class="sc-sub">$<?= number_format($total_revenue, 0) ?> total revenue</div>
            </div>
            <div class="stat-card">
                <span class="sc-icon">&#11088;</span>
                <div class="sc-label">Average Rating</div>
                <div class="sc-value">
                    <?php if ($avg_rating > 0): ?>
                        <span class="stars"><?= str_repeat('&#9733;', round($avg_rating)) ?><?= str_repeat('&#9734;', 5 - round($avg_rating)) ?></span>
                        <span style="font-size:1rem;color:#64748B">(<?= $avg_rating ?>)</span>
                    <?php else: ?>
                        --
                    <?php endif; ?>
                </div>
                <div class="sc-sub"><?= $review_count ?> reviews</div>
            </div>
        </div>

        <!-- Content -->
        <div class="content-grid">
            <div class="content-card">
                <h3>&#9889; Quick Actions</h3>
                <a href="orders.php" class="quick-action">
                    <span class="qa-icon" style="background:#FEF3C7">&#128203;</span>
                    <span>Manage Orders<?php if ($pending_requests > 0): ?> <strong style="color:#DC2626">(<?= $pending_requests ?> new)</strong><?php endif; ?></span>
                </a>
                <a href="profile.php" class="quick-action">
                    <span class="qa-icon" style="background:#F3E8FF">&#128100;</span>
                    <span>Edit Profile</span>
                </a>
                <a href="portfolio.php" class="quick-action">
                    <span class="qa-icon" style="background:#DBEAFE">&#128247;</span>
                    <span>Manage Portfolio</span>
                </a>
                <a href="reviews.php" class="quick-action">
                    <span class="qa-icon" style="background:#DCFCE7">&#11088;</span>
                    <span>View Reviews</span>
                </a>
            </div>

            <div class="content-card">
                <h3>&#11088; Recent Reviews</h3>
                <?php if (empty($recent_reviews)): ?>
                    <div class="empty-state">No reviews yet. They'll appear here once customers rate your service.</div>
                <?php else: ?>
                    <?php foreach ($recent_reviews as $review): ?>
                        <div class="review-item">
                            <div class="r-header">
                                <span class="r-name"><?= sanitize($review['reviewer_name'] ?? 'Anonymous') ?></span>
                                <span class="r-date"><?= date('M d, Y', strtotime($review['created_at'])) ?></span>
                            </div>
                            <div class="r-stars"><?= str_repeat('&#9733;', (int)$review['rating']) ?><?= str_repeat('&#9734;', 5 - (int)$review['rating']) ?></div>
                            <div class="r-text"><?= sanitize(substr($review['comment'] ?? '', 0, 120)) ?><?= strlen($review['comment'] ?? '') > 120 ? '...' : '' ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </main>

</body>
</html>
