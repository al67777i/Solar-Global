<?php
/**
 * Stripe Payment Integration (cURL-based, no Composer required)
 * Provides functions to interact with Stripe API for subscriptions
 */

/**
 * Get Stripe API keys from system_settings based on current mode
 * @return array ['secret_key' => '...', 'publishable_key' => '...', 'mode' => 'test|live', 'webhook_secret' => '...']
 */
function getStripeKeys(): array {
    $db = getDB();

    $keys = [
        'stripe_mode', 'stripe_test_secret_key', 'stripe_test_publishable_key',
        'stripe_live_secret_key', 'stripe_live_publishable_key', 'stripe_webhook_secret'
    ];

    $placeholders = implode(',', array_fill(0, count($keys), '?'));
    $stmt = $db->prepare("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ($placeholders)");
    $stmt->execute($keys);

    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    $mode = $settings['stripe_mode'] ?? 'test';

    return [
        'mode' => $mode,
        'secret_key' => $mode === 'live'
            ? ($settings['stripe_live_secret_key'] ?? '')
            : ($settings['stripe_test_secret_key'] ?? ''),
        'publishable_key' => $mode === 'live'
            ? ($settings['stripe_live_publishable_key'] ?? '')
            : ($settings['stripe_test_publishable_key'] ?? ''),
        'webhook_secret' => $settings['stripe_webhook_secret'] ?? '',
    ];
}

/**
 * Get a specific payment setting from system_settings
 * @param string $key Setting key name
 * @param mixed $default Default value if not found
 * @return mixed
 */
function getPaymentSetting(string $key, $default = null) {
    $db = getDB();
    $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ? $row['setting_value'] : $default;
}

/**
 * Make a cURL request to Stripe API
 * @param string $endpoint API endpoint (e.g., '/v1/checkout/sessions')
 * @param string $method HTTP method
 * @param array $data POST data
 * @param string $secret_key Stripe secret key
 * @return array ['success' => bool, 'data' => array, 'error' => string]
 */
function stripeRequest(string $endpoint, string $method, array $data, string $secret_key): array {
    $url = 'https://api.stripe.com' . $endpoint;

    $ch = curl_init();
    $opts = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_USERPWD => $secret_key . ':',
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-www-form-urlencoded',
        ],
    ];

    // Fix SSL — use bundled CA certificate (project root or system)
    $caFile = dirname(__DIR__) . '/cacert.pem';
    if (!$caFile || !file_exists($caFile)) {
        // Try common system locations
        $systemCaPaths = [
            ini_get('curl.cainfo') ?: '',
            ini_get('openssl.cafile') ?: '',
            '/etc/ssl/certs/ca-certificates.crt',
            '/etc/pki/tls/certs/ca-bundle.crt',
        ];
        foreach ($systemCaPaths as $path) {
            if ($path && file_exists($path)) { $caFile = $path; break; }
        }
    }
    if ($caFile && file_exists($caFile)) {
        $opts[CURLOPT_CAINFO] = $caFile;
    }

    curl_setopt_array($ch, $opts);

    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    } elseif ($method === 'DELETE') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    }

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        return ['success' => false, 'data' => [], 'error' => 'cURL error: ' . $curlError];
    }

    $decoded = json_decode($response, true);

    if ($httpCode >= 400 || isset($decoded['error'])) {
        $errorMsg = $decoded['error']['message'] ?? ('HTTP ' . $httpCode . ' error');
        return ['success' => false, 'data' => $decoded, 'error' => $errorMsg];
    }

    return ['success' => true, 'data' => $decoded, 'error' => ''];
}

/**
 * Create a Stripe Checkout Session for subscription
 * @param array $params [
 *   'customer_email' => string,
 *   'price_amount' => int (cents),
 *   'currency' => string,
 *   'product_name' => string,
 *   'success_url' => string,
 *   'cancel_url' => string,
 *   'metadata' => array (optional),
 *   'customer_id' => string (optional, use existing customer)
 * ]
 * @return array Stripe API response
 */
function createStripeCheckoutSession(array $params): array {
    $keys = getStripeKeys();
    if (empty($keys['secret_key'])) {
        return ['success' => false, 'data' => [], 'error' => 'Stripe API key not configured'];
    }

    $data = [
        'mode' => 'subscription',
        'success_url' => $params['success_url'],
        'cancel_url' => $params['cancel_url'],
        'line_items' => [
            [
                'price_data' => [
                    'currency' => $params['currency'] ?? 'usd',
                    'product_data' => [
                        'name' => $params['product_name'] ?? 'Subscription',
                    ],
                    'unit_amount' => (int)$params['price_amount'],
                    'recurring' => [
                        'interval' => 'month',
                    ],
                ],
                'quantity' => 1,
            ],
        ],
    ];

    if (!empty($params['customer_id'])) {
        $data['customer'] = $params['customer_id'];
    } else {
        $data['customer_email'] = $params['customer_email'] ?? '';
    }

    if (!empty($params['metadata'])) {
        $data['metadata'] = $params['metadata'];
    }

    // Flatten nested arrays for Stripe's form encoding
    $flat = flattenForStripe($data);

    return stripeRequest('/v1/checkout/sessions', 'POST', $flat, $keys['secret_key']);
}

/**
 * Retrieve a Stripe Checkout Session
 * @param string $session_id
 * @return array
 */
function getStripeCheckoutSession(string $session_id): array {
    $keys = getStripeKeys();
    if (empty($keys['secret_key'])) {
        return ['success' => false, 'data' => [], 'error' => 'Stripe API key not configured'];
    }

    return stripeRequest('/v1/checkout/sessions/' . urlencode($session_id), 'GET', [], $keys['secret_key']);
}

/**
 * Create a Stripe Customer
 * @param string $email
 * @param string $name
 * @return array
 */
function createStripeCustomer(string $email, string $name): array {
    $keys = getStripeKeys();
    if (empty($keys['secret_key'])) {
        return ['success' => false, 'data' => [], 'error' => 'Stripe API key not configured'];
    }

    return stripeRequest('/v1/customers', 'POST', [
        'email' => $email,
        'name' => $name,
    ], $keys['secret_key']);
}

/**
 * Cancel a Stripe Subscription
 * @param string $subscription_id
 * @return array
 */
function cancelStripeSubscription(string $subscription_id): array {
    $keys = getStripeKeys();
    if (empty($keys['secret_key'])) {
        return ['success' => false, 'data' => [], 'error' => 'Stripe API key not configured'];
    }

    return stripeRequest('/v1/subscriptions/' . urlencode($subscription_id), 'DELETE', [], $keys['secret_key']);
}

/**
 * Get Stripe Subscription details
 * @param string $subscription_id
 * @return array
 */
function getStripeSubscription(string $subscription_id): array {
    $keys = getStripeKeys();
    if (empty($keys['secret_key'])) {
        return ['success' => false, 'data' => [], 'error' => 'Stripe API key not configured'];
    }

    return stripeRequest('/v1/subscriptions/' . urlencode($subscription_id), 'GET', [], $keys['secret_key']);
}

/**
 * Flatten nested array for Stripe's form-encoded format
 * e.g., ['line_items' => [['price_data' => ['currency' => 'usd']]]]
 * becomes 'line_items[0][price_data][currency]' => 'usd'
 *
 * @param array $data
 * @param string $prefix
 * @return array
 */
function flattenForStripe(array $data, string $prefix = ''): array {
    $result = [];

    foreach ($data as $key => $value) {
        $newKey = $prefix === '' ? $key : $prefix . '[' . $key . ']';

        if (is_array($value)) {
            $result = array_merge($result, flattenForStripe($value, $newKey));
        } else {
            $result[$newKey] = $value;
        }
    }

    return $result;
}

/**
 * Verify Stripe webhook signature
 * @param string $payload Raw request body
 * @param string $sigHeader Stripe-Signature header
 * @param string $secret Webhook signing secret
 * @return bool
 */
function verifyStripeWebhookSignature(string $payload, string $sigHeader, string $secret): bool {
    if (empty($sigHeader) || empty($secret)) {
        return false;
    }

    // Parse the signature header
    $parts = explode(',', $sigHeader);
    $timestamp = null;
    $signatures = [];

    foreach ($parts as $part) {
        $kv = explode('=', trim($part), 2);
        if (count($kv) !== 2) continue;

        if ($kv[0] === 't') {
            $timestamp = $kv[1];
        } elseif ($kv[0] === 'v1') {
            $signatures[] = $kv[1];
        }
    }

    if ($timestamp === null || empty($signatures)) {
        return false;
    }

    // Check timestamp tolerance (5 minutes)
    if (abs(time() - (int)$timestamp) > 300) {
        return false;
    }

    // Compute expected signature
    $signedPayload = $timestamp . '.' . $payload;
    $expectedSig = hash_hmac('sha256', $signedPayload, $secret);

    foreach ($signatures as $sig) {
        if (hash_equals($expectedSig, $sig)) {
            return true;
        }
    }

    return false;
}
