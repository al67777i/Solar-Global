<?php
/**
 * Migration 031 — Notifications Table
 *
 * Creates the notifications table for in-app notifications:
 * - Order notifications (placed, status changed, auto-cancelled)
 * - Subscription notifications (expiring, expired, renewed)
 * - System notifications (admin messages)
 */

require_once __DIR__ . '/../includes/db.php';
$db = getDB();

$results = [];

// ════════════════════════════════════════════════════════════════
// NOTIFICATIONS TABLE
// ════════════════════════════════════════════════════════════════

try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_type ENUM('customer','dealer','installer','admin') NOT NULL,
            user_id INT NOT NULL,
            type VARCHAR(50) NOT NULL COMMENT 'e.g. order_placed, order_status, subscription_expiring, subscription_expired',
            title VARCHAR(255) NOT NULL,
            message TEXT NOT NULL,
            link VARCHAR(500) NULL COMMENT 'URL to navigate to when clicked',
            is_read TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_unread (user_type, user_id, is_read),
            INDEX idx_user_recent (user_type, user_id, created_at DESC),
            INDEX idx_type (type),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    $results[] = "✅ notifications table created";
} catch (PDOException $e) {
    $results[] = "❌ notifications: " . $e->getMessage();
}

// ════════════════════════════════════════════════════════════════
// OUTPUT
// ════════════════════════════════════════════════════════════════
echo "<!DOCTYPE html><html><head><title>Migration 031</title></head><body>";
echo "<h1>Migration 031 — Notifications Table</h1><pre>\n";
foreach ($results as $r) echo "$r\n";

// Verify
$tables = $db->query("SHOW TABLES LIKE 'notifications'")->fetchAll();
echo "\nnotifications table exists: " . (count($tables) > 0 ? '✅ YES' : '❌ NO') . "\n";

if (count($tables) > 0) {
    $cols = $db->query("SHOW COLUMNS FROM notifications")->fetchAll(PDO::FETCH_ASSOC);
    echo "\nColumns:\n";
    foreach ($cols as $c) {
        echo "  {$c['Field']} — {$c['Type']} " . ($c['Null'] === 'NO' ? 'NOT NULL' : 'NULL') . " {$c['Default']}\n";
    }
}

echo "</pre></body></html>";
