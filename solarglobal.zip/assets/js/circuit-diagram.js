﻿/**
 * Circuit Diagram Generator
 * Step 4: Installation guide with animated SVG circuit diagram
 * NOTE: This file is DEPRECATED - use installation-guide.js instead
 */

/**
 * DEPRECATED: Old basic installation guide
 * Replaced by animated version in installation-guide.js
 */
function renderInstallationGuideOLD_DEPRECATED(inverter, panelConfig) {
    const container = document.getElementById('installation-guide');
    if (!container) return;
    
    const battery = inverter.compatible_batteries?.[0];
    
    container.innerHTML = `
        <div class="installation-card card">
            <h2>${t('installation_guide_title')}</h2>
            
            <div class="system-summary">
                <h3>${t('system_components')}</h3>
                <div class="components-grid">
                    <div class="component-item">
                        <div class="component-label">${t('recommended_inverter')}</div>
                        <div class="component-value">${inverter.name}</div>
                        <div class="component-price">${formatUSD(inverter.price_usd)}</div>
                    </div>
                    ${battery ? `
                        <div class="component-item">
                            <div class="component-label">${t('recommended_battery')}</div>
                            <div class="component-value">${battery.name}</div>
                            <div class="component-price">${formatUSD(battery.price_usd)}</div>
                        </div>
                    ` : ''}
                    ${panelConfig ? `
                        <div class="component-item">
                            <div class="component-label">${t('recommended_panels')}</div>
                            <div class="component-value">${panelConfig.panel.name} × ${panelConfig.count}</div>
                            <div class="component-price">${formatUSD(panelConfig.panel.price_usd * panelConfig.count)}</div>
                        </div>
                    ` : ''}
                </div>
                
                <div class="total-cost">
                    <span>${t('total_system_cost')}:</span>
                    <strong>${formatUSD(window.appState.recommendations.total_system_cost_usd)}</strong>
                </div>
            </div>
            
            <div class="circuit-diagram-container">
                <h3>Circuit Diagram</h3>
                <div id="circuit-svg-container"></div>
            </div>
            
            <div class="installation-note">
                <p>${t('installation_note')}</p>
            </div>
        </div>
    `;
    
    // Generate and animate circuit diagram
    setTimeout(() => {
        generateCircuitDiagram(inverter, battery, panelConfig);
    }, 100);
}

/**
 * Generate SVG circuit diagram
 */
function generateCircuitDiagram(inverter, battery, panelConfig) {
    const container = document.getElementById('circuit-svg-container');
    if (!container) return;
    
    const width = container.offsetWidth || 800;
    const height = 500;
    
    // Create SVG
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
    svg.setAttribute('width', '100%');
    svg.setAttribute('height', height);
    svg.style.background = '#F4F6F9';
    svg.style.borderRadius = '12px';
    
    // Component positions
    const panelX = 50;
    const panelY = 100;
    const batteryX = 300;
    const batteryY = 100;
    const inverterX = 550;
    const inverterY = 100;
    const loadX = 550;
    const loadY = 350;
    
    const boxWidth = 180;
    const boxHeight = 120;
    
    // Draw components
    const components = [];
    
    // Solar Panel
    if (panelConfig) {
        components.push({
            x: panelX,
            y: panelY,
            width: boxWidth,
            height: boxHeight,
            label: 'Solar Panels',
            specs: `${panelConfig.count}× ${panelConfig.panel.watt_peak}W\n${panelConfig.wiring}`,
            color: '#F59E0B'
        });
    }
    
    // Battery
    if (battery) {
        components.push({
            x: batteryX,
            y: batteryY,
            width: boxWidth,
            height: boxHeight,
            label: 'Battery Bank',
            specs: `${battery.name}\n${battery.voltage}V ${battery.capacity_ah}Ah`,
            color: '#10B981'
        });
    }
    
    // Inverter
    components.push({
        x: inverterX,
        y: inverterY,
        width: boxWidth,
        height: boxHeight,
        label: 'Inverter',
        specs: `${inverter.name}\n${inverter.voltage_class} ${inverter.max_load_watts}W`,
        color: '#1565C0'
    });
    
    // Load
    components.push({
        x: loadX,
        y: loadY,
        width: boxWidth,
        height: boxHeight,
        label: 'Home Load',
        specs: `${window.appState.totalWatts}W\n${window.appState.dailyKwh.toFixed(1)} kWh/day`,
        color: '#DC2626'
    });
    
    // Draw wires first (so they appear behind components)
    const wires = [];
    
    if (panelConfig) {
        // Panel to Battery
        wires.push(createWire(
            panelX + boxWidth, panelY + boxHeight/2,
            batteryX, batteryY + boxHeight/2,
            `${panelConfig.string_voltage}V DC`
        ));
    }
    
    if (battery) {
        // Battery to Inverter
        wires.push(createWire(
            batteryX + boxWidth, batteryY + boxHeight/2,
            inverterX, inverterY + boxHeight/2,
            `${battery.voltage}V DC`
        ));
    }
    
    // Inverter to Load
    wires.push(createWire(
        inverterX + boxWidth/2, inverterY + boxHeight,
        loadX + boxWidth/2, loadY,
        '220V AC'
    ));
    
    // Add wires to SVG
    wires.forEach(wire => {
        svg.appendChild(wire.path);
        svg.appendChild(wire.label);
    });
    
    // Add components to SVG
    components.forEach(comp => {
        const g = createComponent(comp);
        svg.appendChild(g);
    });
    
    container.appendChild(svg);
    
    // Animate diagram
    animateCircuitDiagram(svg, wires, components);
}

/**
 * Create wire path
 */
function createWire(x1, y1, x2, y2, label) {
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    
    // Create path with control points for curves
    const midX = (x1 + x2) / 2;
    const d = `M ${x1} ${y1} L ${x2} ${y2}`;
    
    path.setAttribute('d', d);
    path.setAttribute('stroke', '#0D3B6E');
    path.setAttribute('stroke-width', '3');
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke-dasharray', '8,4');
    
    // Calculate path length for animation
    const length = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    path.setAttribute('stroke-dashoffset', length);
    path.style.strokeDasharray = length;
    path.style.strokeDashoffset = length;
    
    // Label
    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', (x1 + x2) / 2);
    text.setAttribute('y', (y1 + y2) / 2 - 10);
    text.setAttribute('text-anchor', 'middle');
    text.setAttribute('fill', '#0D3B6E');
    text.setAttribute('font-size', '14');
    text.setAttribute('font-weight', '600');
    text.textContent = label;
    text.style.opacity = '0';
    
    return { path, label: text, length };
}

/**
 * Create component box
 */
function createComponent(comp) {
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.style.opacity = '0';
    
    // Box
    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('x', comp.x);
    rect.setAttribute('y', comp.y);
    rect.setAttribute('width', comp.width);
    rect.setAttribute('height', comp.height);
    rect.setAttribute('fill', 'white');
    rect.setAttribute('stroke', comp.color);
    rect.setAttribute('stroke-width', '3');
    rect.setAttribute('rx', '8');
    
    // Label
    const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    label.setAttribute('x', comp.x + comp.width/2);
    label.setAttribute('y', comp.y + 30);
    label.setAttribute('text-anchor', 'middle');
    label.setAttribute('fill', comp.color);
    label.setAttribute('font-size', '16');
    label.setAttribute('font-weight', '700');
    label.textContent = comp.label;
    
    // Specs (multi-line)
    const specs = comp.specs.split('\n');
    specs.forEach((line, i) => {
        const specText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        specText.setAttribute('x', comp.x + comp.width/2);
        specText.setAttribute('y', comp.y + 55 + (i * 20));
        specText.setAttribute('text-anchor', 'middle');
        specText.setAttribute('fill', '#334155');
        specText.setAttribute('font-size', '13');
        specText.textContent = line;
        g.appendChild(specText);
    });
    
    g.appendChild(rect);
    g.appendChild(label);
    
    return g;
}

/**
 * Animate circuit diagram drawing
 */
function animateCircuitDiagram(svg, wires, components) {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        // No animation - just show everything
        wires.forEach(w => {
            w.path.style.strokeDashoffset = '0';
            w.label.style.opacity = '1';
        });
        svg.querySelectorAll('g').forEach(g => {
            g.style.opacity = '1';
        });
        return;
    }
    
    // Animate wires drawing
    wires.forEach((wire, index) => {
        anime({
            targets: wire.path,
            strokeDashoffset: [wire.length, 0],
            duration: 500,
            delay: index * 200,
            easing: 'easeInOutQuad'
        });
        
        anime({
            targets: wire.label,
            opacity: [0, 1],
            duration: 300,
            delay: index * 200 + 400,
            easing: 'easeOutQuad'
        });
    });
    
    // Animate components appearing
    const componentElements = svg.querySelectorAll('g');
    anime({
        targets: componentElements,
        opacity: [0, 1],
        scale: [0.8, 1],
        duration: 400,
        delay: anime.stagger(200, {start: 600}),
        easing: 'easeOutBack'
    });
}
