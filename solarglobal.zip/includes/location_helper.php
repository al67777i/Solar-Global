<?php
/**
 * Location Helper — User location detection and radius management
 *
 * Used by: store.php (unified shop), stores.php, find-dealer.php, find-installer.php
 *
 * Priority: 1. URL params  2. Cookie  3. IP geolocation fallback
 * Stores user lat/lng/radius in sg_location cookie (30 days).
 */

/**
 * Detect user location from cookie or provide defaults.
 * IP-based geolocation is done client-side via ip-api.com for better UX.
 *
 * @return array ['lat' => float, 'lng' => float, 'city' => string, 'country_code' => string, 'detected' => bool]
 */
function detect_user_location(): array {
    $default = ['lat' => 0, 'lng' => 0, 'city' => '', 'country_code' => '', 'detected' => false];

    // Check cookie
    if (!empty($_COOKIE['sg_location'])) {
        $loc = json_decode($_COOKIE['sg_location'], true);
        if ($loc && !empty($loc['lat']) && !empty($loc['lng'])) {
            return [
                'lat'          => (float)$loc['lat'],
                'lng'          => (float)$loc['lng'],
                'city'         => $loc['city'] ?? '',
                'country_code' => $loc['country_code'] ?? '',
                'detected'     => true,
            ];
        }
    }

    return $default;
}

/**
 * Get the user's search radius from cookie.
 *
 * @param int $default Default radius in km
 * @return int Radius in km (clamped 5–500)
 */
function get_user_radius(int $default = 50): int {
    if (!empty($_COOKIE['sg_radius'])) {
        $r = (int)$_COOKIE['sg_radius'];
        return max(5, min(500, $r));
    }
    return $default;
}

/**
 * Save location to cookie (called via AJAX or embedded JS).
 * This is a PHP helper; client-side JS sets cookies directly for instant UX.
 *
 * @param float  $lat
 * @param float  $lng
 * @param string $city
 * @param string $country_code
 */
function save_location_cookie(float $lat, float $lng, string $city = '', string $country_code = ''): void {
    $data = json_encode([
        'lat'          => round($lat, 6),
        'lng'          => round($lng, 6),
        'city'         => $city,
        'country_code' => $country_code,
    ]);
    setcookie('sg_location', $data, time() + (30 * 86400), '/solarglobal/', '', false, false);
}

/**
 * Save radius to cookie.
 *
 * @param int $radius Radius in km
 */
function save_radius_cookie(int $radius): void {
    $radius = max(5, min(500, $radius));
    setcookie('sg_radius', (string)$radius, time() + (30 * 86400), '/solarglobal/', '', false, false);
}

/**
 * Get Haversine distance SQL fragment.
 * Returns distance in km between a point and table columns.
 *
 * @param string $lat_col  Column name for latitude (e.g., 'd.latitude')
 * @param string $lng_col  Column name for longitude (e.g., 'd.longitude')
 * @param string $lat_param Placeholder for user lat (use ? in prepared statement)
 * @param string $lng_param Placeholder for user lng
 * @return string SQL expression that calculates distance in km
 */
function haversine_sql(string $lat_col, string $lng_col, string $lat_param = '?', string $lng_param = '?'): string {
    return "(6371 * ACOS(
        LEAST(1, GREATEST(-1,
            COS(RADIANS({$lat_param})) * COS(RADIANS({$lat_col})) *
            COS(RADIANS({$lng_col}) - RADIANS({$lng_param})) +
            SIN(RADIANS({$lat_param})) * SIN(RADIANS({$lat_col}))
        ))
    ))";
}
