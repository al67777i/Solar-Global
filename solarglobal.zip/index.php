<?php
/**
 * SolarGlobal Solar System Recommender
 * User Frontend - Main Entry Point
 */
require_once 'includes/db.php';
require_once 'includes/helpers.php';
set_security_headers();

// Track visitor (skip bots for cleaner analytics)
if (!is_bot_request()) {
    trackVisitor($pdo);
}

// Detect user country for localized content
$user_country = detect_user_country();

// Get nearby dealers for the user's country
$nearby_dealers = [];
$dealer_count = 0;
try {
    if (!empty($user_country)) {
        $stmt = $pdo->prepare("
            SELECT d.id, d.business_name, d.city, d.logo_path, d.avg_rating, d.total_reviews,
                   (SELECT COUNT(*) FROM dealer_inventory di WHERE di.dealer_id = d.id AND di.is_active = 1) as product_count
            FROM dealers d
            WHERE d.status = 'active' AND d.country_code = ?
            ORDER BY d.avg_rating DESC, d.total_reviews DESC
            LIMIT 6
        ");
        $stmt->execute([$user_country]);
        $nearby_dealers = $stmt->fetchAll();
        $dealer_count = count($nearby_dealers);
    }
    if ($dealer_count === 0) {
        // Fallback: show top-rated dealers globally
        $stmt = $pdo->query("
            SELECT d.id, d.business_name, d.city, d.country_code, d.logo_path, d.avg_rating, d.total_reviews,
                   (SELECT COUNT(*) FROM dealer_inventory di WHERE di.dealer_id = d.id AND di.is_active = 1) as product_count
            FROM dealers d
            WHERE d.status = 'active'
            ORDER BY d.avg_rating DESC, d.total_reviews DESC
            LIMIT 6
        ");
        $nearby_dealers = $stmt->fetchAll();
        $dealer_count = count($nearby_dealers);
    }
} catch (Exception $e) {
    // Silently fail
}

$_sn = get_system_setting('site_name', 'SolarGlobal');
$contact_email = get_system_setting('contact_email', 'info@solarglobal.com');
$contact_phone = get_system_setting('contact_phone', '+923054957063');
$whatsapp_number = get_system_setting('whatsapp_number', '923054957063');
$phone_clean = preg_replace('/[^+0-9]/', '', $contact_phone);
$whatsapp_clean = preg_replace('/[^0-9]/', '', $whatsapp_number);
$page_title = "$_sn - Best Solar System Recommender | Free Solar Calculator";
$page_description = "Find the perfect solar system for your home. Smart AI-powered recommendations based on your appliances. Compare BMS vs Non-BMS systems, calculate savings, and get installation guides.";
$page_keywords = "solar system calculator, solar recommendation, best solar inverter, solar panels, battery backup, BMS battery, solar price, $_sn, international solar";
$current_page = 'index';
?>
<!DOCTYPE html>
<html lang="en" id="html-root">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- SEO Meta Tags -->
    <title><?php echo $page_title; ?></title>
    <meta name="description" content="<?php echo $page_description; ?>">
    <meta name="keywords" content="<?php echo $page_keywords; ?>">
    <meta name="author" content="Bilal Ansar - SolarGlobal">
    <meta name="robots" content="index, follow">
    <meta name="language" content="English">
    <meta name="revisit-after" content="3 days">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo getCurrentUrl(); ?>">
    <meta property="og:title" content="<?php echo $page_title; ?>">
    <meta property="og:description" content="<?php echo $page_description; ?>">
    <meta property="og:image" content="<?php echo getBaseUrl(); ?>/assets/images/og-image.jpg">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo getCurrentUrl(); ?>">
    <meta property="twitter:title" content="<?php echo $page_title; ?>">
    <meta property="twitter:description" content="<?php echo $page_description; ?>">
    <meta property="twitter:image" content="<?php echo getBaseUrl(); ?>/assets/images/og-image.jpg">

    <!-- Canonical URL -->
    <link rel="canonical" href="<?php echo getCurrentUrl(); ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Google Maps API - load in head -->
    <script>
    // Google Maps ready flag
    window.__gmapsReady = false;
    function onGoogleMapsReady() { window.__gmapsReady = true; }
    </script>
    <script async src="https://maps.googleapis.com/maps/api/js?key=<?= sanitize(get_system_setting('google_maps_api_key', '')) ?>&libraries=places&callback=onGoogleMapsReady"></script>

    <!-- Stylesheets -->
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/frontend.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link rel="stylesheet" href="assets/css/recommendations.css">
    <link rel="stylesheet" href="assets/css/installation-guide.css">
    <link rel="stylesheet" href="assets/css/installation-animated.css">
    <link rel="stylesheet" href="assets/css/configurator.css?v=3.2">
    <link rel="stylesheet" href="assets/css/city-selector.css">
    <link rel="stylesheet" href="assets/css/location-selector.css">
    <link rel="stylesheet" href="assets/css/energy-forecast.css?v=3.2">
    <link rel="stylesheet" href="assets/css/connection-diagram-3d.css">
    <link rel="stylesheet" href="assets/css/weather-background.css">
    <link rel="stylesheet" href="assets/css/recommender-v8.css">
    <link rel="stylesheet" href="assets/css/recommender-v10.css?v=1.0">
    <link rel="stylesheet" href="assets/css/mobile-app.css">

    <!-- PWA Meta -->
    <meta name="theme-color" content="#0D3B6E">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="mobile-web-app-capable" content="yes">

    <!-- Anime.js (LOCAL - No internet required) -->
    <script src="assets/js/anime.min.js"></script>

    <!-- Chart.js for 24-hour energy graphs (LOCAL - No internet required) -->
    <script src="assets/js/chart.min.js"></script>

</head>
<body>
    <?php include 'includes/header-nav.php'; ?>
    <?php include_once 'includes/ad_display.php'; ?>

    <?php renderAds('header'); ?>

    <!-- Start Over Confirmation Dialog -->
    <div id="startover-dialog" class="so-dialog-overlay" style="display:none;">
        <div class="so-dialog">
            <div class="so-dialog-icon">🔄</div>
            <h3 class="so-dialog-title">Start Over?</h3>
            <p class="so-dialog-msg">This will reset all your selections and take you back to the beginning.</p>
            <div class="so-dialog-actions">
                <button type="button" class="so-btn-cancel" onclick="closeStartOverDialog()">Cancel</button>
                <button type="button" class="so-btn-confirm" onclick="confirmStartOver()">Yes, Start Over</button>
            </div>
        </div>
    </div>

    <!-- Hero Section -->
    <section class="hero" id="heroSection">
        <!-- CSS-only animated sun -->
        <div class="hero-sun-orb"></div>
        <div class="hero-sun-glow"></div>
        <div class="hero-energy-beam beam-1"></div>
        <div class="hero-energy-beam beam-2"></div>
        <div class="hero-energy-beam beam-3"></div>
        <!-- Solar panel silhouettes -->
        <div class="hero-panels">
            <div class="hero-panel"></div>
            <div class="hero-panel"></div>
            <div class="hero-panel"></div>
            <div class="hero-panel"></div>
        </div>
        <!-- Appliance icons -->
        <div class="hero-appliance-icons">
            <span class="hero-app-icon app-1">💡</span>
            <span class="hero-app-icon app-2">❄️</span>
            <span class="hero-app-icon app-3">📺</span>
            <span class="hero-app-icon app-4">🏠</span>
        </div>
        <div class="container">
            <h2 class="hero-title" data-lang-key="hero_title">Find the Perfect Solar System for Your Home</h2>
            <p class="hero-subtitle" data-lang-key="hero_subtitle">Smart recommendations based on your actual power needs</p>

            <div class="feature-pills">
                <div class="feature-pill">
                    <span class="feature-icon">⚡</span>
                    <span data-lang-key="feature_smart">Smart Recommendation</span>
                </div>
                <div class="feature-pill">
                    <span class="feature-icon">💰</span>
                    <span data-lang-key="feature_price">Best Price</span>
                </div>
                <div class="feature-pill">
                    <span class="feature-icon">📋</span>
                    <span data-lang-key="feature_guide">Installation Guide</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Step Indicator -->
    <div class="step-indicator">
        <div class="container">
            <div class="steps">
                <div class="step active" data-step="0">
                    <div class="step-circle">📍</div>
                    <div class="step-label" data-lang-key="step0">Select Location</div>
                </div>
                <div class="step-line"></div>
                <div class="step" data-step="1">
                    <div class="step-circle">1</div>
                    <div class="step-label" data-lang-key="step1">Define Load</div>
                </div>
                <div class="step-line"></div>
                <div class="step" data-step="2">
                    <div class="step-circle">2</div>
                    <div class="step-label" data-lang-key="step2">Review Load</div>
                </div>
                <div class="step-line"></div>
                <div class="step" data-step="3">
                    <div class="step-circle">3</div>
                    <div class="step-label" data-lang-key="step3">Recommendations</div>
                </div>
                <div class="step-line"></div>
                <div class="step" data-step="4">
                    <div class="step-circle">4</div>
                    <div class="step-label" data-lang-key="step4">Energy Forecast</div>
                </div>
            </div>
            <!-- Start Over Button -->
            <button type="button" class="nav-start-over" id="btnStartOver" onclick="handleStartOver()" title="Start Over">
                <span class="nav-start-icon">🔄</span>
                <span class="nav-start-text">Start Over</span>
            </button>
        </div>
    </div>

    <!-- Main Content Area -->
    <main class="main-content">
        <div class="container">
            <!-- Step 0: Location Selection (Map-based) -->
            <div id="step-0" class="step-content active">
                <div class="city-selector-wrapper">
                    <div class="city-selector-header">
                        <div class="city-header-badge">📍 Select Your Location</div>
                        <h2 data-lang-key="city_title">Where will you install your solar system?</h2>
                        <p data-lang-key="city_subtitle">Click on the map, search for your address, or allow location access for accurate solar estimates</p>
                    </div>

                    <!-- Map-based Location Picker -->
                    <div id="locationPickerContainer"></div>

                    <!-- Continue Button -->
                    <div class="city-continue-section">
                        <button type="button" id="btn-city-continue" class="btn-city-continue" disabled>
                            <span>Continue to Appliance Selection</span>
                            <span class="btn-arrow">→</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Step 1: Appliance Selector -->
            <div id="step-1" class="step-content">
                <div class="appliance-selector-wrapper">
                    <!-- Usage Type Selector -->
                    <div class="usage-type-selector" id="usage-type-selector">
                        <h3 class="usage-type-title">What type of installation is this?</h3>
                        <div class="usage-type-cards">
                            <div class="usage-type-card active" data-type="residential" onclick="selectUsageType('residential')">
                                <div class="utc-icon">🏠</div>
                                <div class="utc-name">Residential</div>
                                <div class="utc-desc">Home, apartment, villa</div>
                            </div>
                            <div class="usage-type-card" data-type="commercial" onclick="selectUsageType('commercial')">
                                <div class="utc-icon">🏢</div>
                                <div class="utc-name">Commercial</div>
                                <div class="utc-desc">Office, shop, restaurant</div>
                            </div>
                            <div class="usage-type-card" data-type="industrial" onclick="selectUsageType('industrial')">
                                <div class="utc-icon">🏭</div>
                                <div class="utc-name">Industrial</div>
                                <div class="utc-desc">Factory, warehouse, plant</div>
                            </div>
                        </div>
                    </div>

                    <!-- Commercial/Industrial: Interactive 24-Hour Load Graph -->
                    <div class="manual-load-input" id="manual-load-section" style="display:none;">
                        <div class="mli-card">
                            <h3 class="mli-title">Define Your Hourly Load Profile</h3>
                            <p class="mli-desc">Drag the bars up/down to set your load for each hour. This gives the most accurate system recommendation.</p>

                            <!-- Quick Setup Row -->
                            <div class="mli-quick-setup">
                                <div class="mli-field mli-field-inline">
                                    <label for="mli-peak-load">Peak Load (kW)</label>
                                    <input type="number" id="mli-peak-load" min="1" max="5000" step="0.5" placeholder="e.g. 25" oninput="updateGraphFromPeak()">
                                </div>
                                <div class="mli-field mli-field-inline">
                                    <label for="mli-operating-hours">Operating Hours</label>
                                    <input type="number" id="mli-operating-hours" min="1" max="24" step="1" value="10" oninput="updateGraphFromHours()">
                                </div>
                                <div class="mli-field" id="mli-phase-field">
                                    <label>Phase</label>
                                    <div class="mli-phase-toggle">
                                        <button type="button" class="phase-btn active" data-phase="1" onclick="selectPhase(1)">1Φ</button>
                                        <button type="button" class="phase-btn" data-phase="3" onclick="selectPhase(3)">3Φ</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Interactive 24-Hour Graph -->
                            <div class="mli-graph-container">
                                <div class="mli-graph-header">
                                    <div class="mli-graph-stats">
                                        <span class="mli-stat"><strong id="mli-total-kwh">0</strong> kWh/day</span>
                                        <span class="mli-stat"><strong id="mli-peak-display">0</strong> kW peak</span>
                                    </div>
                                    <div class="mli-graph-actions">
                                        <button type="button" class="mli-graph-btn" onclick="resetLoadGraph()" title="Reset">↺ Reset</button>
                                        <button type="button" class="mli-graph-btn" onclick="flattenLoadGraph()" title="Even out load">≡ Flatten</button>
                                    </div>
                                </div>
                                <div class="mli-graph" id="mli-hourly-graph">
                                    <!-- 24 draggable bars rendered by JS -->
                                </div>
                                <div class="mli-graph-xaxis">
                                    <span>12am</span><span>3am</span><span>6am</span><span>9am</span>
                                    <span>12pm</span><span>3pm</span><span>6pm</span><span>9pm</span>
                                </div>
                                <p class="mli-graph-help">💡 Click & drag bars up/down to adjust hourly load. Night hours (6pm-6am) shown in dark.</p>
                            </div>

                            <button type="button" id="btn-manual-calculate" class="btn btn-primary btn-lg" onclick="submitManualLoad()">
                                Calculate My System →
                            </button>
                        </div>
                    </div>

                    <!-- Residential: Appliance Selection (existing) -->
                    <div id="residential-appliance-section">
                    <!-- Season Quick Presets -->
                    <div class="quick-presets" id="quick-presets" style="display:none;">
                        <button type="button" class="preset-btn" id="preset-essential" title="Add all essential appliances">
                            ⚡ Essential Package
                        </button>
                        <button type="button" class="preset-btn" id="preset-comfort" title="Add comfort appliances for current season">
                            🏠 Comfort Package
                        </button>
                        <button type="button" class="preset-btn" id="preset-full" title="Add all recommended appliances">
                            ✨ Full Home Package
                        </button>
                    </div>

                    <!-- Category Filters -->
                    <div class="category-filters">
                        <button type="button" class="category-btn active" data-category="all" data-lang-key="cat_all">All</button>
                        <button type="button" class="category-btn" data-category="Cooling" data-lang-key="cat_cooling">Cooling</button>
                        <button type="button" class="category-btn" data-category="Heating" data-lang-key="cat_heating">Heating</button>
                        <button type="button" class="category-btn" data-category="Lighting" data-lang-key="cat_lighting">Lighting</button>
                        <button type="button" class="category-btn" data-category="Kitchen" data-lang-key="cat_kitchen">Kitchen</button>
                        <button type="button" class="category-btn" data-category="Laundry" data-lang-key="cat_laundry">Laundry</button>
                        <button type="button" class="category-btn" data-category="Electronics" data-lang-key="cat_electronics">Electronics</button>
                        <button type="button" class="category-btn" data-category="Utility" data-lang-key="cat_utility">Utility</button>
                        <button type="button" class="category-btn" data-category="Comfort" data-lang-key="cat_comfort">Comfort</button>
                    </div>

                    <!-- Appliance Grid (Full Width) -->
                    <div class="appliance-grid" id="appliance-grid">
                        <!-- Populated by JavaScript -->
                    </div>

                    <!-- Your Home Panel (Below Grid) -->
                    <div class="home-panel" id="home-panel">
                        <div class="home-panel-header">
                            <div class="home-panel-title">
                                <span class="home-panel-icon">🏠</span>
                                <div>
                                    <h3 data-lang-key="your_home">Your Home</h3>
                                    <p class="home-panel-subtitle" id="home-panel-count">No appliances added yet</p>
                                </div>
                            </div>
                            <button type="button" id="clear-all-appliances" class="clear-all-btn" style="display:none" title="Clear all appliances">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                                Clear All
                            </button>
                            <div class="home-panel-stats">
                                <div class="hp-stat">
                                    <span class="hp-stat-icon">⚡</span>
                                    <div class="hp-stat-data">
                                        <span class="hp-stat-value" id="total-watts">0 W</span>
                                        <span class="hp-stat-label" data-lang-key="total_load">Total Load</span>
                                    </div>
                                </div>
                                <div class="hp-stat">
                                    <span class="hp-stat-icon">🔋</span>
                                    <div class="hp-stat-data">
                                        <span class="hp-stat-value" id="daily-kwh">0 kWh</span>
                                        <span class="hp-stat-label" data-lang-key="daily_usage">Daily Usage</span>
                                    </div>
                                </div>
                                <div class="hp-stat">
                                    <span class="hp-stat-icon">📊</span>
                                    <div class="hp-stat-data">
                                        <span class="hp-stat-value" id="daily-units">0 Units</span>
                                        <span class="hp-stat-label" data-lang-key="daily_units">Daily Units</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Selected Appliances Display -->
                        <div id="selected-appliances" class="selected-appliances"></div>

                        <button type="button" id="btn-calculate" class="btn btn-primary btn-lg" disabled data-lang-key="btn_calculate">
                            Calculate My Load
                        </button>
                    </div>
                    </div><!-- /residential-appliance-section -->
                </div>
            </div>

            <!-- Step 2: Load Review & System Configuration -->
            <div id="step-2" class="step-content">
                <div class="load-review-card card">
                    <h2 data-lang-key="load_summary_title">Your Load Summary</h2>
                    <div id="load-review-content"></div>
                </div>

                <!-- V8: System Type + Net Metering + Backup + Shop Radius -->
                <div id="system-type-container"></div>

                <div class="action-buttons" style="text-align:center;padding:20px 0 40px;">
                    <button type="button" id="btn-back-to-step1" class="btn btn-secondary" data-lang-key="btn_back">Back</button>
                    <button type="button" id="btn-find-system" class="btn btn-primary btn-lg" data-lang-key="btn_find_system">
                        Find Best Solar System →
                    </button>
                </div>
            </div>

            <!-- Step 3: Recommendations -->
            <div id="step-3" class="step-content">
                <div id="recommendations-container"></div>
                <!-- System Overview shown after selecting a recommendation -->
                <div id="system-overview-container" style="display:none;"></div>
            </div>

            <!-- Step 4: Interactive Configurator (24h chart, adjust components) -->
            <div id="step-4" class="step-content">
                <div id="configurator-container"></div>

                <!-- Energy Production Forecast (dynamic, updates with panel selection) -->
                <div id="energy-forecast-section" class="energy-forecast-section" style="display:none;">
                    <div class="forecast-header">
                        <h3>📊 Energy Production Forecast</h3>
                        <p class="forecast-subtitle">Based on weather data &amp; your selected solar system</p>
                    </div>

                    <div class="forecast-stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon">☀️</div>
                            <div class="stat-value" id="stat-daily-gen">--</div>
                            <div class="stat-label">Daily Generation</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">🏠</div>
                            <div class="stat-value" id="stat-daily-use">--</div>
                            <div class="stat-label">Daily Usage</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">⚡</div>
                            <div class="stat-value" id="stat-surplus">--</div>
                            <div class="stat-label">Surplus / Deficit</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">💰</div>
                            <div class="stat-value" id="stat-monthly-savings">--</div>
                            <div class="stat-label">Monthly Savings</div>
                        </div>
                    </div>

                    <!-- Energy Flow Stats (shown based on system type) -->
                    <div class="forecast-stats-grid forecast-flow-stats" id="energy-flow-stats" style="display:none;">
                        <div class="stat-card stat-export">
                            <div class="stat-icon">📤</div>
                            <div class="stat-value" id="stat-grid-export">--</div>
                            <div class="stat-label">Grid Export /mo</div>
                        </div>
                        <div class="stat-card stat-import">
                            <div class="stat-icon">📥</div>
                            <div class="stat-value" id="stat-grid-import">--</div>
                            <div class="stat-label">Grid Import /mo</div>
                        </div>
                        <div class="stat-card stat-self-use">
                            <div class="stat-icon">🔄</div>
                            <div class="stat-value" id="stat-self-consumption">--</div>
                            <div class="stat-label">Self-Consumption</div>
                        </div>
                        <div class="stat-card stat-battery">
                            <div class="stat-icon">🔋</div>
                            <div class="stat-value" id="stat-battery-cycles">--</div>
                            <div class="stat-label">Battery Cycles /mo</div>
                        </div>
                    </div>

                    <div class="forecast-tabs">
                        <button class="forecast-tab active" data-view="daily">Today (24h)</button>
                        <button class="forecast-tab" data-view="monthly">This Month</button>
                        <button class="forecast-tab" data-view="annual">Annual Savings</button>
                    </div>

                    <div class="forecast-chart-container">
                        <canvas id="forecast-chart"></canvas>
                    </div>

                    <div class="forecast-info-row">
                        <span class="forecast-info-item">🔆 System: <strong id="info-system-size">--</strong></span>
                        <span class="forecast-info-item">📅 Annual: <strong id="info-annual">--</strong></span>
                        <span class="forecast-info-item">⚡ Yield: <strong id="info-specific">--</strong></span>
                        <span class="forecast-info-item">☀️ PSH: <strong id="info-psh">--</strong></span>
                    </div>
                </div>

                <div id="installation-guide" style="display: none;"></div>
            </div>
        </div>
    </main>

    <!-- Loading Overlay -->
    <div id="loading-overlay" class="loading-overlay hidden">
        <div class="loading-content">
            <div class="sun-spinner"></div>
            <p data-lang-key="loading">Finding best solar system for you...</p>
        </div>
    </div>

    <!-- Floating Action Widget (Appliance Stage) -->
    <div id="fab-load-widget" class="fab-widget" style="display:none;">
        <button type="button" class="fab-toggle" id="fab-toggle" title="View load summary">
            <span class="fab-icon">⚡</span>
            <span class="fab-badge" id="fab-count">0</span>
        </button>
        <div class="fab-panel" id="fab-panel">
            <div class="fab-panel-header">
                <span>🏠 Your Home Load</span>
                <button type="button" class="fab-panel-close" onclick="document.getElementById('fab-panel').classList.remove('open')">×</button>
            </div>
            <div class="fab-panel-stats">
                <div class="fab-stat">
                    <span class="fab-stat-val" id="fab-watts">0W</span>
                    <span class="fab-stat-lbl">Peak Load</span>
                </div>
                <div class="fab-stat">
                    <span class="fab-stat-val" id="fab-kwh">0 kWh</span>
                    <span class="fab-stat-lbl">Daily Usage</span>
                </div>
                <div class="fab-stat">
                    <span class="fab-stat-val" id="fab-units">0</span>
                    <span class="fab-stat-lbl">Units/Day</span>
                </div>
            </div>
            <div class="fab-panel-items" id="fab-items-list">
                <!-- Populated dynamically -->
            </div>
            <div class="fab-panel-footer">
                <button type="button" class="fab-calc-btn" id="fab-calc-btn" disabled>
                    Calculate My Load →
                </button>
            </div>
        </div>
    </div>

    <!-- Floating Category FAB (Recommendations Stage) -->
    <div id="fab-category-nav" class="fab-cat-nav" style="display:none;">
        <!-- Populated dynamically by recommender-v2.js -->
    </div>

    <?php renderAds('between-steps'); ?>

    <?php renderAds('footer'); ?>

    <!-- Scripts -->
    <script>
    function gm_authFailure() {
        var el = document.getElementById('locationMap');
        if (el) el.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;background:#fff3cd;color:#856404;font-size:14px;text-align:center;padding:20px;"><div><strong>⚠️ Maps API Error</strong><br>Check API key &amp; enabled APIs in Google Cloud Console.</div></div>';
    }
    </script>
    <script src="assets/js/location-selector.js"></script>

    <script src="assets/js/lang.js?v=3.3"></script>
    <script src="assets/js/app.js?v=3.3"></script>
    <script src="assets/js/city-selector.js?v=3.3"></script>
    <script src="assets/js/appliance-selector.js"></script>
    <script src="assets/js/energy-forecast.js?v=3.3"></script>
    <script>
    // Expose unique active product countries to JS
    window.dbCountries = <?php
        $db_countries = [];
        try {
            // Fetch countries with real product_count across inverters, batteries, and panels
            $mapped_query = "
                SELECT ct.code, ct.name, ct.flag_emoji,
                    (
                        SELECT COUNT(*) FROM inverters i
                        WHERE i.is_active = 1
                          AND i.country IS NOT NULL AND i.country != ''
                          AND LOWER(i.country COLLATE utf8mb4_general_ci) = LOWER(ct.name COLLATE utf8mb4_general_ci)
                    ) +
                    (
                        SELECT COUNT(*) FROM batteries b
                        WHERE b.is_active = 1
                          AND b.country IS NOT NULL AND b.country != ''
                          AND LOWER(b.country COLLATE utf8mb4_general_ci) = LOWER(ct.name COLLATE utf8mb4_general_ci)
                    ) +
                    (
                        SELECT COUNT(*) FROM panels p
                        WHERE p.is_active = 1
                          AND p.country_origin IS NOT NULL AND p.country_origin != ''
                          AND LOWER(p.country_origin COLLATE utf8mb4_general_ci) = LOWER(ct.name COLLATE utf8mb4_general_ci)
                    ) AS product_count
                FROM countries ct
                INNER JOIN (
                    SELECT DISTINCT country COLLATE utf8mb4_general_ci AS origin FROM inverters WHERE country IS NOT NULL AND country != '' AND is_active = 1
                    UNION
                    SELECT DISTINCT country COLLATE utf8mb4_general_ci AS origin FROM batteries WHERE country IS NOT NULL AND country != '' AND is_active = 1
                    UNION
                    SELECT DISTINCT country_origin COLLATE utf8mb4_general_ci AS origin FROM panels WHERE country_origin IS NOT NULL AND country_origin != '' AND is_active = 1
                ) o ON LOWER(ct.name COLLATE utf8mb4_general_ci) = LOWER(o.origin) OR LOWER(ct.code COLLATE utf8mb4_general_ci) = LOWER(o.origin)
                ORDER BY product_count DESC, ct.name ASC
            ";
            $stmt = $pdo->query($mapped_query);
            $db_countries = $stmt->fetchAll(PDO::FETCH_ASSOC);
            // Cast product_count to int for clean JSON
            foreach ($db_countries as &$row) {
                $row['product_count'] = (int)$row['product_count'];
            }
            unset($row);
        } catch (Exception $e) {
            // ignore
        }
        echo json_encode($db_countries);
    ?>;
    </script>
    <script src="assets/js/recommender-v8.js?v=3.3"></script>
    <script src="assets/js/system-configurator.js?v=3.3"></script>
    <script src="assets/js/circuit-diagram.js"></script>
    <script src="assets/js/circuit-diagram-professional.js?v=3.3"></script>
    <script src="assets/js/connection-diagram-3d.js"></script>
    <script src="assets/js/installation-guide.js"></script>
    <script src="assets/js/weather-background.js"></script>

    <!-- Initialize Map Location Picker -->
    <script>
    window.userDetectedCountry = '<?= $user_country ?>';
    (function() {
        // Init the map-based location picker
        SolarLocation.init('locationPickerContainer');

        // Enable continue button when location is selected
        SolarLocation.onLocationChange(function(location, solar) {
            var btn = document.getElementById('btn-city-continue');
            if (btn && location) {
                btn.disabled = false;
                btn.classList.add('active');

                // Store location globally for the recommendation engine
                window.selectedLocation = location;
                window.solarData = solar;

                // Also set selectedCity for the old city-selector flow compatibility
                window.selectedCity = {
                    id: 0,
                    name: location.name || 'Custom Location',
                    province: location.country || '',
                    lat: location.lat,
                    lng: location.lng,
                    avg_sun_hours: solar ? solar.avg_sun_hours : 5.0
                };

                // Update city badge
                var badge = document.getElementById('city-badge');
                var badgeName = document.getElementById('city-badge-name');
                if (badge && badgeName && location.name) {
                    badgeName.textContent = location.name;
                    badge.style.display = 'flex';
                }
            }
        });

        // Continue button click handler for map-based flow
        var continueBtn = document.getElementById('btn-city-continue');
        if (continueBtn) {
            continueBtn.addEventListener('click', function() {
                if (window.selectedLocation || window.selectedCity) {
                    if (typeof goToStep === 'function') {
                        goToStep(1);
                    }
                }
            });
        }
    })();
    </script>

    <!-- Nearby Dealers / Open Your Store CTA -->
    <section style="padding: 60px 0; background: linear-gradient(180deg, #F8FAFC 0%, #FFFFFF 100%); font-family: 'Inter', sans-serif;">
        <div style="max-width: 1200px; margin: 0 auto; padding: 0 24px;">
            <?php if ($dealer_count > 0): ?>
                <div style="text-align: center; margin-bottom: 40px;">
                    <h2 style="font-size: 1.75rem; font-weight: 800; color: #0F172A; margin: 0 0 8px 0;">
                        <?= !empty($user_country) ? 'Solar Dealers Near You' : 'Top Solar Dealers' ?>
                    </h2>
                    <p style="font-size: 1rem; color: #64748B; margin: 0;">
                        Browse verified dealers and find the best prices on solar equipment
                    </p>
                </div>

                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 32px;">
                    <?php foreach ($nearby_dealers as $dealer): ?>
                    <a href="<?= BASE_URL ?>store-detail.php?id=<?= (int)$dealer['id'] ?>" style="text-decoration: none; background: white; border: 1px solid #E2E8F0; border-radius: 14px; padding: 20px; display: flex; align-items: center; gap: 16px; transition: box-shadow 0.2s, border-color 0.2s;" onmouseover="this.style.boxShadow='0 8px 24px rgba(0,0,0,0.08)'; this.style.borderColor='#F59E0B'" onmouseout="this.style.boxShadow='none'; this.style.borderColor='#E2E8F0'">
                        <div style="width: 56px; height: 56px; border-radius: 12px; background: #F1F5F9; display: flex; align-items: center; justify-content: center; flex-shrink: 0; overflow: hidden;">
                            <?php if (!empty($dealer['logo_path'])): ?>
                                <img src="<?= get_image_url($dealer['logo_path']) ?>" alt="" style="width: 100%; height: 100%; object-fit: cover; border-radius: 12px;">
                            <?php else: ?>
                                <span style="font-size: 1.5rem;">&#127978;</span>
                            <?php endif; ?>
                        </div>
                        <div style="flex: 1; min-width: 0;">
                            <div style="font-weight: 600; font-size: 0.9375rem; color: #1E293B; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                <?= sanitize($dealer['business_name']) ?>
                            </div>
                            <div style="font-size: 0.8125rem; color: #64748B; margin-top: 2px;">
                                <?= sanitize($dealer['city'] ?? '') ?>
                                <?php if (!empty($dealer['country_code'])): ?>
                                    &middot; <?= sanitize($dealer['country_code']) ?>
                                <?php endif; ?>
                            </div>
                            <div style="display: flex; align-items: center; gap: 8px; margin-top: 6px;">
                                <?php if ((float)$dealer['avg_rating'] > 0): ?>
                                    <span style="color: #F59E0B; font-size: 0.8125rem;">
                                        <?= str_repeat('&#9733;', round((float)$dealer['avg_rating'])) ?><?= str_repeat('&#9734;', 5 - round((float)$dealer['avg_rating'])) ?>
                                    </span>
                                    <span style="font-size: 0.75rem; color: #94A3B8;">(<?= (int)$dealer['total_reviews'] ?>)</span>
                                <?php endif; ?>
                                <?php if ((int)$dealer['product_count'] > 0): ?>
                                    <span style="font-size: 0.75rem; color: #94A3B8; background: #F1F5F9; padding: 2px 8px; border-radius: 4px;">
                                        <?= (int)$dealer['product_count'] ?> products
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>

                <div style="text-align: center; display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                    <a href="<?= BASE_URL ?>stores.php" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 28px; background: linear-gradient(135deg, #F59E0B, #D97706); color: white; border-radius: 10px; font-weight: 600; font-size: 0.9375rem; text-decoration: none; transition: opacity 0.2s, transform 0.15s;" onmouseover="this.style.opacity='0.92'; this.style.transform='translateY(-1px)'" onmouseout="this.style.opacity='1'; this.style.transform='none'">
                        &#127978; Browse All Stores
                    </a>
                    <a href="<?= BASE_URL ?>become-dealer.php" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 28px; background: white; color: #D97706; border: 2px solid #F59E0B; border-radius: 10px; font-weight: 600; font-size: 0.9375rem; text-decoration: none; transition: background 0.2s;" onmouseover="this.style.background='#FFFBEB'" onmouseout="this.style.background='white'">
                        &#128640; Open Your Solar Store
                    </a>
                </div>

            <?php else: ?>
                <!-- No dealers — show CTA banner -->
                <div style="background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%); border-radius: 20px; padding: 60px 40px; text-align: center; position: relative; overflow: hidden;">
                    <div style="position: absolute; top: -30px; right: -30px; width: 200px; height: 200px; background: radial-gradient(circle, rgba(245,158,11,0.15), transparent 70%); border-radius: 50%;"></div>
                    <div style="position: absolute; bottom: -20px; left: -20px; width: 150px; height: 150px; background: radial-gradient(circle, rgba(245,158,11,0.1), transparent 70%); border-radius: 50%;"></div>
                    <div style="position: relative; z-index: 1;">
                        <div style="font-size: 3rem; margin-bottom: 16px;">&#127978;</div>
                        <h2 style="font-size: 1.75rem; font-weight: 800; color: #ffffff; margin: 0 0 12px 0;">
                            Open Your Solar Store on SolarGlobal
                        </h2>
                        <p style="font-size: 1.0625rem; color: #94A3B8; margin: 0 0 32px 0; max-width: 600px; display: inline-block; line-height: 1.6;">
                            Join the growing marketplace of solar equipment dealers. Reach thousands of customers, manage inventory, and grow your business with our powerful tools.
                        </p>
                        <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                            <a href="<?= BASE_URL ?>become-dealer.php" style="display: inline-flex; align-items: center; gap: 8px; padding: 14px 32px; background: linear-gradient(135deg, #F59E0B, #D97706); color: white; border-radius: 10px; font-weight: 700; font-size: 1rem; text-decoration: none; transition: opacity 0.2s, transform 0.15s;" onmouseover="this.style.opacity='0.92'; this.style.transform='translateY(-2px)'" onmouseout="this.style.opacity='1'; this.style.transform='none'">
                                &#128640; Register as Dealer
                            </a>
                            <a href="<?= BASE_URL ?>become-installer.php" style="display: inline-flex; align-items: center; gap: 8px; padding: 14px 32px; background: rgba(255,255,255,0.1); color: #E2E8F0; border: 1px solid rgba(255,255,255,0.2); border-radius: 10px; font-weight: 600; font-size: 1rem; text-decoration: none; transition: background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.15)'" onmouseout="this.style.background='rgba(255,255,255,0.1)'">
                                &#128295; Become an Installer
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <style>
    .clear-all-btn {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 5px 12px;
        background: rgba(239,68,68,0.1);
        border: 1px solid rgba(239,68,68,0.3);
        border-radius: 8px;
        color: #EF4444;
        font-size: 0.72rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        font-family: inherit;
    }
    .clear-all-btn:hover {
        background: rgba(239,68,68,0.2);
        border-color: #EF4444;
    }
    @media (max-width: 768px) {
        section > div > div[style*="grid-template-columns: repeat(3"] {
            grid-template-columns: 1fr !important;
        }
    }
    @media (min-width: 769px) and (max-width: 1024px) {
        section > div > div[style*="grid-template-columns: repeat(3"] {
            grid-template-columns: repeat(2, 1fr) !important;
        }
    }
    </style>

    <!-- Schema.org Structured Data for SEO -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "SolarGlobal Solar System Recommender",
        "url": "<?php echo getBaseUrl(); ?>",
        "description": "leading solar system recommendation platform with AI-powered calculator",
        "applicationCategory": "UtilityApplication",
        "operatingSystem": "Web Browser",
        "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD"
        },
        "creator": {
            "@type": "Person",
            "name": "Bilal Ansar",
            "jobTitle": "Software Engineer",
            "email": "info@SolarGlobal.com",
            "telephone": "<?php echo htmlspecialchars($phone_clean); ?>"
        },
        "provider": {
            "@type": "Organization",
            "name": "SolarGlobal",
            "url": "<?php echo getBaseUrl(); ?>",
            "logo": "<?php echo getBaseUrl(); ?>/assets/images/logo.png",
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "Kangniwala Main Kangni Wala Bazar, Mohalla Shama Ul Arfeen",
                "addressLocality": "Gujranwala",
                "addressRegion": "Punjab",
                "postalCode": "52250",
                "addressCountry": "PK"
            },
            "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "<?php echo htmlspecialchars($phone_clean); ?>",
                "contactType": "Customer Service",
                "email": "info@SolarGlobal.com",
                "availableLanguage": ["English", "Urdu"]
            }
        },
        "featureList": ["Solar System Calculator", "AI-Powered Recommendations", "Real-time Price Comparison", "Installation Guides", "Weather-Based Optimization"]
    }
    </script>

    <!-- Breadcrumb Schema -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [{
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "<?php echo getBaseUrl(); ?>"
        },{
            "@type": "ListItem",
            "position": 2,
            "name": "Solar Calculator",
            "item": "<?php echo getBaseUrl(); ?>/#calculator"
        }]
    }
    </script>

    <!-- Local Business Schema -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": "SolarGlobal Software Production & Training Center",
        "image": "<?php echo getBaseUrl(); ?>/assets/images/logo.png",
        "url": "https://solarglobal.com",
        "email": "<?php echo htmlspecialchars($contact_email); ?>",
        "address": {
            "@type": "PostalAddress",
            "addressCountry": "US"
        },
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
            "opens": "09:00",
            "closes": "18:00"
        },
        "priceRange": "Free Consultation"
    }
    </script>

    <!-- FAQ Schema for SEO -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": "How do I calculate the right solar system size for my home?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Use our free Solar System Recommender tool. Simply select your city, add your home appliances with usage hours, and our AI-powered calculator will recommend the perfect inverter, battery, and panel combination based on your specific energy needs and local solar conditions."
                }
            },
            {
                "@type": "Question",
                "name": "What are the best solar inverter brands in 2026?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Top solar inverter brands include Huawei, SMA Solar, Fronius, SolarEdge, Enphase, GoodWe, Growatt, Sungrow, and Victron Energy. The best choice depends on your budget, system size, and whether you need on-grid, off-grid, or hybrid functionality."
                }
            },
            {
                "@type": "Question",
                "name": "How much does a complete solar system cost?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A complete 5kW residential solar system costs approximately $8,000-$15,000 including inverter, panels, batteries, and installation. A 10kW system ranges from $15,000-$25,000. Prices vary based on brand selection, battery type, and local installation costs."
                }
            },
            {
                "@type": "Question",
                "name": "Should I choose lithium or lead-acid batteries for my solar system?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Lithium batteries (LiFePO4) offer longer lifespan (10+ years, 6000+ cycles), deeper discharge (90-95% DoD), and are maintenance-free but cost more upfront. Lead-acid batteries are cheaper initially but last 3-5 years with 50% DoD. For long-term value, lithium is strongly recommended."
                }
            }
        ]
    }
    </script>

    <?php
    // Dynamic product structured data from database
    try {
        $topInverters = $pdo->query("
            SELECT i.model, i.output_power_w, i.unit_price_usd, i.company
            FROM inverters i
            WHERE i.is_active = 1 AND i.type = 'hybrid'
            ORDER BY i.output_power_w DESC LIMIT 5
        ")->fetchAll();

        if (!empty($topInverters)):
    ?>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "ItemList",
        "name": "Top Solar Inverters",
        "description": "Best selling hybrid solar inverters available with current prices",
        "numberOfItems": <?= count($topInverters) ?>,
        "itemListElement": [
            <?php foreach ($topInverters as $idx => $inv): ?>
            {
                "@type": "ListItem",
                "position": <?= $idx + 1 ?>,
                "item": {
                    "@type": "Product",
                    "name": "<?= addslashes($inv['model'] ?? '') ?>",
                    "brand": {"@type": "Brand", "name": "<?= addslashes($inv['company'] ?? '') ?>"},
                    "category": "Solar Inverter",
                    "offers": {
                        "@type": "Offer",
                        "price": "<?= $inv['unit_price_usd'] ?? 0 ?>",
                        "priceCurrency": "PKR",
                        "availability": "https://schema.org/InStock"
                    }
                }
            }<?= $idx < count($topInverters) - 1 ? ',' : '' ?>
            <?php endforeach; ?>
        ]
    }
    </script>
    <?php endif; } catch (Exception $e) {} ?>

    <?php include 'includes/footer.php'; ?>
