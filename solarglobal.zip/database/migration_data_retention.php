<?php
/**
 * Migration: Data Retention Setup
 *
 * 1. Ensures subscription_plan column exists on dealers & installers
 * 2. Sets all NULL plans to 'basic' (default free tier)
 * 3. Ensures retention plan settings exist in system_settings
 * 4. Creates email_verifications table if not exists
 *
 * Safe to run multiple times (idempotent).
 */
require_once __DIR__ . '/../includes/db.php';

$db = getDB();
$log = [];

function mlog($msg) {
    global $log;
    $log[] = $msg;
    echo "  $msg\n";
}

echo "=== Data Retention Migration ===\n\n";

// ─── 1. Ensure subscription_plan column exists ───
foreach (['dealers', 'installers'] as $table) {
    try {
        $db->exec("ALTER TABLE {$table} ADD COLUMN subscription_plan VARCHAR(50) NULL DEFAULT 'basic'");
        mlog("Added subscription_plan column to {$table}");
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false) {
            mlog("{$table}.subscription_plan already exists — OK");
        } else {
            mlog("ERROR adding column to {$table}: " . $e->getMessage());
        }
    }

    // Set NULL values to 'basic'
    $stmt = $db->prepare("UPDATE {$table} SET subscription_plan = 'basic' WHERE subscription_plan IS NULL OR subscription_plan = ''");
    $stmt->execute();
    $count = $stmt->rowCount();
    if ($count > 0) {
        mlog("Set {$count} {$table} with NULL plan to 'basic'");
    } else {
        mlog("All {$table} already have a plan assigned — OK");
    }
}

// ─── 2. Ensure retention settings exist in system_settings ───
$retention_settings = [
    'retention_plan_basic_months'      => '6',
    'retention_plan_basic_fee'         => '0.00',
    'retention_plan_standard_months'   => '24',
    'retention_plan_standard_fee'      => '2.00',
    'retention_plan_premium_months'    => '60',
    'retention_plan_premium_fee'       => '5.00',
    'retention_plan_enterprise_months' => '120',
    'retention_plan_enterprise_fee'    => '10.00',
    'retention_order_history_months'   => '120',
];

$insert_stmt = $db->prepare("
    INSERT INTO system_settings (setting_key, setting_value, updated_at)
    VALUES (?, ?, NOW())
    ON DUPLICATE KEY UPDATE updated_at = updated_at
");

foreach ($retention_settings as $key => $default) {
    try {
        $insert_stmt->execute([$key, $default]);
        mlog("Ensured setting '{$key}' exists (default: {$default})");
    } catch (PDOException $e) {
        mlog("Setting '{$key}' error: " . $e->getMessage());
    }
}

// ─── 3. Create email_verifications table if not exists ───
try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS email_verifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) NOT NULL,
            code VARCHAR(10) NOT NULL,
            type VARCHAR(50) NOT NULL DEFAULT 'registration',
            expires_at TIMESTAMP NOT NULL,
            verified_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_email_code (email, code),
            INDEX idx_expires (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    mlog("email_verifications table ready");
} catch (PDOException $e) {
    mlog("email_verifications error: " . $e->getMessage());
}

// ─── 4. Create notifications table if not exists ───
try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_type ENUM('dealer','installer','customer','admin') NOT NULL,
            user_id INT NOT NULL,
            type VARCHAR(100) NOT NULL,
            title VARCHAR(255) NOT NULL,
            message TEXT,
            link VARCHAR(500) NULL,
            is_read TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user (user_type, user_id),
            INDEX idx_read (is_read)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    mlog("notifications table ready");
} catch (PDOException $e) {
    mlog("notifications error: " . $e->getMessage());
}

echo "\n=== Migration Complete ===\n";
echo count($log) . " actions performed.\n";
