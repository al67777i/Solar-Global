<?php
/**
 * Core Tables Migration
 * Creates ALL missing tables needed for the marketplace to function.
 * Safe to re-run — uses IF NOT EXISTS / IF NOT EXISTS checks.
 *
 * Run: http://localhost/solarglobal/database/migration_core_tables.php
 */
require_once __DIR__ . '/../includes/db.php';
$db = getDB();

$results = [];

function run_query($db, $label, $sql, &$results) {
    try {
        $db->exec($sql);
        $results[] = "✅ $label";
    } catch (PDOException $e) {
        $msg = $e->getMessage();
        if (stripos($msg, 'already exists') !== false || stripos($msg, 'Duplicate') !== false) {
            $results[] = "⏩ $label (already exists)";
        } else {
            $results[] = "❌ $label: $msg";
        }
    }
}

// ════════════════════════════════════════════════════════════════
// 1. DEALERS
// ════════════════════════════════════════════════════════════════
run_query($db, 'dealers', "
CREATE TABLE IF NOT EXISTS dealers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    business_name VARCHAR(200) NOT NULL,
    owner_name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(30) NULL,
    address TEXT NULL,
    city VARCHAR(100) NULL,
    country_code VARCHAR(3) NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    logo_path VARCHAR(255) NULL,
    description TEXT NULL,
    website VARCHAR(255) NULL,
    status ENUM('pending','active','suspended','rejected') DEFAULT 'pending',
    subscription_status ENUM('trial','active','expired') DEFAULT 'trial',
    subscription_plan VARCHAR(50) NULL,
    subscription_expires_at TIMESTAMP NULL,
    stripe_customer_id VARCHAR(100) NULL,
    stripe_subscription_id VARCHAR(100) NULL,
    rating_avg DECIMAL(3,2) DEFAULT 0,
    avg_rating DECIMAL(3,2) DEFAULT 0,
    total_reviews INT DEFAULT 0,
    completed_orders INT DEFAULT 0,
    last_login_at TIMESTAMP NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_email (email),
    INDEX idx_status (status),
    INDEX idx_country (country_code),
    INDEX idx_subscription (subscription_status),
    INDEX idx_location (latitude, longitude),
    INDEX idx_rating (rating_avg DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 2. INSTALLERS
// ════════════════════════════════════════════════════════════════
run_query($db, 'installers', "
CREATE TABLE IF NOT EXISTS installers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    business_name VARCHAR(200) NOT NULL,
    owner_name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(30) NULL,
    address TEXT NULL,
    city VARCHAR(100) NULL,
    country_code VARCHAR(3) NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    logo_path VARCHAR(255) NULL,
    description TEXT NULL,
    website VARCHAR(255) NULL,
    service_type ENUM('residential','commercial','industrial','all') DEFAULT 'all',
    certification VARCHAR(255) NULL,
    experience_years INT DEFAULT 0,
    status ENUM('pending','active','suspended','rejected') DEFAULT 'pending',
    subscription_status ENUM('trial','active','expired') DEFAULT 'trial',
    subscription_plan VARCHAR(50) NULL,
    subscription_expires_at TIMESTAMP NULL,
    stripe_customer_id VARCHAR(100) NULL,
    stripe_subscription_id VARCHAR(100) NULL,
    rating_avg DECIMAL(3,2) DEFAULT 0,
    total_reviews INT DEFAULT 0,
    completed_installations INT DEFAULT 0,
    service_radius_km INT DEFAULT 50,
    last_login_at TIMESTAMP NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_email (email),
    INDEX idx_status (status),
    INDEX idx_country (country_code),
    INDEX idx_subscription (subscription_status),
    INDEX idx_location (latitude, longitude),
    INDEX idx_rating (rating_avg DESC),
    INDEX idx_service_type (service_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 3. DEALER_PRODUCTS (dealer inventory)
// ════════════════════════════════════════════════════════════════
run_query($db, 'dealer_products', "
CREATE TABLE IF NOT EXISTS dealer_products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dealer_id INT NOT NULL,
    product_type ENUM('inverter','battery','panel','installation_appliance') NOT NULL,
    product_id INT NOT NULL,
    dealer_price DECIMAL(12,2) NULL COMMENT 'Dealer custom price (NULL = use catalog price)',
    quantity INT DEFAULT 0 COMMENT 'Stock quantity',
    stock_quantity INT DEFAULT 0 COMMENT 'Alias for quantity',
    is_active TINYINT(1) DEFAULT 1,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_dealer_product (dealer_id, product_type, product_id),
    INDEX idx_dealer (dealer_id),
    INDEX idx_product_type (product_type),
    INDEX idx_active (is_active),
    CONSTRAINT fk_dealer_products_dealer FOREIGN KEY (dealer_id) REFERENCES dealers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// Create a VIEW so code referencing dealer_inventory also works
run_query($db, 'dealer_inventory (view)', "
CREATE OR REPLACE VIEW dealer_inventory AS
SELECT id, dealer_id, product_type, product_id, dealer_price AS custom_price_usd,
       quantity, stock_quantity, is_active, notes, created_at, updated_at
FROM dealer_products
", $results);

// ════════════════════════════════════════════════════════════════
// 4. INSTALLATION_APPLIANCES
// ════════════════════════════════════════════════════════════════
run_query($db, 'installation_appliances', "
CREATE TABLE IF NOT EXISTS installation_appliances (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    category ENUM('breaker','wire','frame','mounting','connector',
                  'combiner_box','surge_protector','cable_tray','other') NOT NULL DEFAULT 'other',
    brand VARCHAR(150) NULL,
    specifications TEXT NULL,
    price_usd DECIMAL(10,2) NOT NULL DEFAULT 0,
    image_path VARCHAR(255) NULL,
    icon VARCHAR(50) DEFAULT '🔧',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_active (is_active),
    INDEX idx_brand (brand)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 5. COUNTRY_PRICE_ADJUSTMENTS
// ════════════════════════════════════════════════════════════════
run_query($db, 'country_price_adjustments', "
CREATE TABLE IF NOT EXISTS country_price_adjustments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    country_code VARCHAR(3) NOT NULL,
    product_type VARCHAR(30) NOT NULL DEFAULT 'all',
    markup_percent DECIMAL(5,2) DEFAULT 0,
    tax_percent DECIMAL(5,2) DEFAULT 0,
    shipping_flat_usd DECIMAL(8,2) DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_country_type (country_code, product_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 6. CUSTOMERS (if missing)
// ════════════════════════════════════════════════════════════════
run_query($db, 'customers', "
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL,
    google_id VARCHAR(100) NULL,
    password_hash VARCHAR(255) NULL,
    phone VARCHAR(30) NULL,
    country_code VARCHAR(3) NULL,
    city VARCHAR(100) NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    avatar_url VARCHAR(500) NULL,
    otp_code VARCHAR(10) NULL,
    otp_expires_at TIMESTAMP NULL,
    email_verified TINYINT(1) DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    last_login_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_email (email),
    INDEX idx_country (country_code),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 7. ORDERS
// ════════════════════════════════════════════════════════════════
run_query($db, 'orders', "
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(20) NOT NULL,
    customer_id INT NOT NULL,
    dealer_id INT NOT NULL,
    status ENUM('pending','confirmed','ready','picked_up','cancelled') DEFAULT 'pending',
    total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    currency VARCHAR(3) DEFAULT 'USD',
    item_count INT DEFAULT 0,
    notes TEXT NULL,
    admin_notes TEXT NULL,
    pickup_deadline TIMESTAMP NULL,
    confirmed_at TIMESTAMP NULL,
    ready_at TIMESTAMP NULL,
    picked_up_at TIMESTAMP NULL,
    cancelled_at TIMESTAMP NULL,
    cancel_reason VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_order_number (order_number),
    INDEX idx_customer (customer_id),
    INDEX idx_dealer (dealer_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 8. ORDER_ITEMS
// ════════════════════════════════════════════════════════════════
run_query($db, 'order_items', "
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_type ENUM('inverter','battery','panel','installation_appliance') NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(250) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(12,2) NOT NULL,
    total_price DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 9. DEALER_REVIEWS
// ════════════════════════════════════════════════════════════════
run_query($db, 'dealer_reviews', "
CREATE TABLE IF NOT EXISTS dealer_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dealer_id INT NOT NULL,
    customer_id INT NOT NULL,
    order_id INT NOT NULL,
    rating TINYINT NOT NULL,
    review_text TEXT NULL,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    admin_response TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_order_review (order_id),
    INDEX idx_dealer (dealer_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 10. INSTALLER_ORDERS
// ════════════════════════════════════════════════════════════════
run_query($db, 'installer_orders', "
CREATE TABLE IF NOT EXISTS installer_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    installer_id INT NOT NULL,
    status ENUM('requested','accepted','in_progress','completed','cancelled') DEFAULT 'requested',
    system_size_kw DECIMAL(8,2) NULL,
    system_type ENUM('on-grid','off-grid','hybrid') DEFAULT 'hybrid',
    description TEXT NULL,
    address TEXT NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    estimated_cost DECIMAL(12,2) NULL,
    total_amount DECIMAL(12,2) NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    scheduled_date DATE NULL,
    completed_at TIMESTAMP NULL,
    cancelled_at TIMESTAMP NULL,
    cancel_reason VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_customer (customer_id),
    INDEX idx_installer (installer_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 11. WATCHLIST
// ════════════════════════════════════════════════════════════════
run_query($db, 'watchlist', "
CREATE TABLE IF NOT EXISTS watchlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_type ENUM('inverter','battery','panel','installation_appliance') NOT NULL,
    product_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_customer_product (customer_id, product_type, product_id),
    INDEX idx_customer (customer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 12. ADD is_bot TO visitor_stats
// ════════════════════════════════════════════════════════════════
try {
    $cols = $db->query("SHOW COLUMNS FROM visitor_stats LIKE 'is_bot'")->fetch();
    if (!$cols) {
        $db->exec("ALTER TABLE visitor_stats ADD COLUMN is_bot TINYINT(1) DEFAULT 0 AFTER session_id");
        $db->exec("ALTER TABLE visitor_stats ADD INDEX idx_is_bot (is_bot)");
        $results[] = "✅ visitor_stats: added is_bot column";
    } else {
        $results[] = "⏩ visitor_stats: is_bot already exists";
    }
} catch (PDOException $e) {
    $results[] = "❌ visitor_stats is_bot: " . $e->getMessage();
}

// ════════════════════════════════════════════════════════════════
// 13. ADD sell_rate_kwh TO countries
// ════════════════════════════════════════════════════════════════
try {
    $cols = $db->query("SHOW COLUMNS FROM countries LIKE 'sell_rate_kwh'")->fetch();
    if (!$cols) {
        $db->exec("ALTER TABLE countries ADD COLUMN sell_rate_kwh DECIMAL(8,4) DEFAULT 0 AFTER electricity_rate_kwh");
        $results[] = "✅ countries: added sell_rate_kwh";
    } else {
        $results[] = "⏩ countries: sell_rate_kwh already exists";
    }
} catch (PDOException $e) {
    $results[] = "❌ countries sell_rate_kwh: " . $e->getMessage();
}

// ════════════════════════════════════════════════════════════════
// 14. CUSTOMER_SESSIONS
// ════════════════════════════════════════════════════════════════
run_query($db, 'customer_sessions', "
CREATE TABLE IF NOT EXISTS customer_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    session_token VARCHAR(64) NOT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(500) NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_token (session_token),
    INDEX idx_customer (customer_id),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// 15. CART TABLE (session-based, persists across pages)
// ════════════════════════════════════════════════════════════════
run_query($db, 'cart', "
CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(128) NOT NULL COMMENT 'PHP session ID (guest) or customer_id prefix',
    customer_id INT NULL COMMENT 'NULL for guests, populated on login',
    dealer_id INT NOT NULL,
    product_type ENUM('inverter','battery','panel','installation_appliance') NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_session_product (session_id, dealer_id, product_type, product_id),
    INDEX idx_session (session_id),
    INDEX idx_customer (customer_id),
    INDEX idx_dealer (dealer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $results);

// ════════════════════════════════════════════════════════════════
// VERIFY
// ════════════════════════════════════════════════════════════════
echo "<h1>SolarGlobal Core Tables Migration</h1><pre>\n";
foreach ($results as $r) echo "$r\n";

echo "\n--- Verification ---\n";
$tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
$check = ['dealers','installers','dealer_products','installation_appliances','country_price_adjustments',
          'customers','orders','order_items','dealer_reviews','installer_orders','watchlist','customer_sessions','cart'];
foreach ($check as $t) {
    if (in_array($t, $tables)) {
        $cnt = $db->query("SELECT COUNT(*) FROM $t")->fetchColumn();
        echo "✅ $t ($cnt rows)\n";
    } else {
        echo "❌ $t MISSING\n";
    }
}

// Check view
try {
    $db->query("SELECT 1 FROM dealer_inventory LIMIT 1");
    echo "✅ dealer_inventory (view) works\n";
} catch (Exception $e) {
    echo "❌ dealer_inventory view: " . $e->getMessage() . "\n";
}

// Check is_bot column
$cols = $db->query("SHOW COLUMNS FROM visitor_stats LIKE 'is_bot'")->fetch();
echo ($cols ? "✅" : "❌") . " visitor_stats.is_bot\n";

echo "\nMigration complete!\n</pre>";
