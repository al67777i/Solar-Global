<?php
/**
 * AJAX endpoint - Products Browse (panels / inverters / batteries)
 * GET params: type (panels|inverters|batteries), search, company_id, filter, page, per_page
 */
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/helpers.php';

header('Content-Type: application/json');

$db      = getDB();
$type    = trim($_GET['type'] ?? '');
$search  = trim($_GET['search'] ?? '');
$coId    = intval($_GET['company_id'] ?? 0);
$filter  = trim($_GET['filter'] ?? '');
$page    = max(1, intval($_GET['page'] ?? 1));
$perPage = max(10, min(200, intval($_GET['per_page'] ?? 25)));
$offset  = ($page - 1) * $perPage;

$allowed = ['panels', 'inverters', 'batteries'];
if (!in_array($type, $allowed)) {
    echo json_encode(['success' => false, 'error' => 'Invalid type']);
    exit;
}

$where  = [];
$params = [];

if ($type === 'panels') {
    $alias  = 'p';
    $table  = 'panels p LEFT JOIN companies c ON p.company_id = c.id';
    $cols   = 'p.id, p.name, p.image_path, p.wattage, p.price_usd, p.panel_type, p.is_active, c.name as company_name';
    $order  = 'p.wattage DESC';
    if ($search)  { $where[] = "(p.name LIKE ? OR c.name LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
    if ($coId)    { $where[] = "p.company_id = ?"; $params[] = $coId; }
    if ($filter)  { $where[] = "p.panel_type = ?"; $params[] = $filter; }

} elseif ($type === 'inverters') {
    $alias  = 'i';
    $table  = 'inverters i LEFT JOIN companies c ON i.company_id = c.id';
    $cols   = 'i.id, i.model, i.image_path, i.output_power_w, i.unit_price_usd, i.type, i.battery_voltage_range, i.supports_parallel, i.max_parallel_units, i.is_active, c.name as company_name';
    $order  = 'i.created_at DESC';
    if ($search)  { $where[] = "(i.model LIKE ? OR c.name LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
    if ($coId)    { $where[] = "i.company_id = ?"; $params[] = $coId; }
    if ($filter)  { $where[] = "i.type = ?"; $params[] = $filter; }

} elseif ($type === 'batteries') {
    $alias  = 'b';
    $table  = 'batteries b LEFT JOIN companies c ON b.company_id = c.id';
    $cols   = 'b.id, b.model, b.image_path, b.nominal_voltage, b.capacity_ah, b.price_unit_usd, b.type, b.is_bms, b.is_active, c.name as company_name';
    $order  = 'b.nominal_voltage, b.capacity_ah DESC';
    if ($search)  { $where[] = "(b.model LIKE ? OR c.name LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
    if ($coId)    { $where[] = "b.company_id = ?"; $params[] = $coId; }
    if ($filter)  { $where[] = "b.type = ?"; $params[] = $filter; }
}

$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Count
$cntStmt = $db->prepare("SELECT COUNT(*) FROM $table $whereSQL");
$cntStmt->execute($params);
$total = (int) $cntStmt->fetchColumn();

// Rows
$stmt = $db->prepare("SELECT $cols FROM $table $whereSQL ORDER BY $order LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Add image display URL
$base = rtrim(BASE_URL, '/') . '/';
$rows = array_map(function($row) use ($base) {
    if (!empty($row['image_path'])) {
        $raw = ltrim($row['image_path'], '/');
        // if it already looks like a full URL leave it; else build one
        if (strpos($raw, 'http') !== 0) {
            $row['img_url'] = $base . $raw;
        } else {
            $row['img_url'] = $row['image_path'];
        }
    } else {
        $row['img_url'] = null;
    }
    return $row;
}, $rows);

echo json_encode([
    'success'     => true,
    'rows'        => $rows,
    'total'       => $total,
    'page'        => $page,
    'per_page'    => $perPage,
    'total_pages' => ceil($total / $perPage),
]);
