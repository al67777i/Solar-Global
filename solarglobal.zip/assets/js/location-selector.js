﻿/**
 * SolarGlobal Location Selector
 * Uses Google Maps API for map + Places Autocomplete
 * + OpenMeteo for solar irradiance data
 */
var SolarLocation = (function() {
    var map = null;
    var marker = null;
    var autocomplete = null;
    var geocoder = null;
    var currentLocation = null;
    var solarData = null;
    var onChangeCallbacks = [];
    var containerId = null;

    // Default: center of world
    var DEFAULT_LAT = 25.0;
    var DEFAULT_LNG = 45.0;
    var DEFAULT_ZOOM = 3;

    // Country center coordinates for IP-based map focus
    var COUNTRY_CENTERS = {
        PK: { lat: 30.3753, lng: 69.3451, zoom: 5 },
        IN: { lat: 20.5937, lng: 78.9629, zoom: 5 },
        US: { lat: 37.0902, lng: -95.7129, zoom: 4 },
        GB: { lat: 55.3781, lng: -3.4360, zoom: 5 },
        DE: { lat: 51.1657, lng: 10.4515, zoom: 6 },
        FR: { lat: 46.2276, lng: 2.2137, zoom: 6 },
        SA: { lat: 23.8859, lng: 45.0792, zoom: 5 },
        AE: { lat: 23.4241, lng: 53.8478, zoom: 7 },
        AU: { lat: -25.2744, lng: 133.7751, zoom: 4 },
        ZA: { lat: -30.5595, lng: 22.9375, zoom: 5 },
        EG: { lat: 26.8206, lng: 30.8025, zoom: 6 },
        NG: { lat: 9.0820, lng: 8.6753, zoom: 6 },
        BR: { lat: -14.2350, lng: -51.9253, zoom: 4 },
        CN: { lat: 35.8617, lng: 104.1954, zoom: 4 },
        JP: { lat: 36.2048, lng: 138.2529, zoom: 5 },
        TR: { lat: 38.9637, lng: 35.2433, zoom: 6 },
        BD: { lat: 23.6850, lng: 90.3563, zoom: 7 },
        ID: { lat: -0.7893, lng: 113.9213, zoom: 4 },
        MY: { lat: 4.2105, lng: 101.9758, zoom: 6 },
        KE: { lat: -0.0236, lng: 37.9062, zoom: 6 },
        GH: { lat: 7.9465, lng: -1.0232, zoom: 7 },
        TZ: { lat: -6.3690, lng: 34.8888, zoom: 6 }
    };

    function init(cId, options) {
        options = options || {};
        containerId = cId;
        var container = document.getElementById(containerId);
        if (!container) {
            console.error('[SolarLocation] Container not found:', containerId);
            return;
        }

        // Build the HTML structure
        container.innerHTML = '' +
            '<div class="location-selector">' +
                '<div class="location-map-wrap">' +
                    '<div id="locationMap" class="location-map"></div>' +
                    '<div class="location-search-bar">' +
                        '<div class="search-input-wrap">' +
                            '<svg class="search-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#999" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>' +
                            '<input type="text" id="locationSearch" placeholder="Search city or address..." autocomplete="off">' +
                        '</div>' +
                    '</div>' +
                '</div>' +
                '<div class="location-info-card" id="locationInfoCard" style="display:none;">' +
                    '<div class="location-info-header">' +
                        '<h4 id="locationName">Select a location</h4>' +
                        '<span class="location-coords" id="locationCoords"></span>' +
                    '</div>' +
                    '<div class="location-solar-stats">' +
                        '<div class="solar-stat">' +
                            '<span class="solar-stat-value" id="sunHoursVal">--</span>' +
                            '<span class="solar-stat-label">Peak Sun Hours</span>' +
                        '</div>' +
                        '<div class="solar-stat">' +
                            '<span class="solar-stat-value" id="daylightHoursVal">--</span>' +
                            '<span class="solar-stat-label">Daylight Today</span>' +
                        '</div>' +
                        '<div class="solar-stat">' +
                            '<span class="solar-stat-value" id="sunriseVal">--</span>' +
                            '<span class="solar-stat-label">Sunrise</span>' +
                        '</div>' +
                        '<div class="solar-stat">' +
                            '<span class="solar-stat-value" id="sunsetVal">--</span>' +
                            '<span class="solar-stat-label">Sunset</span>' +
                        '</div>' +
                        '<div class="solar-stat">' +
                            '<span class="solar-stat-value" id="irradianceVal">--</span>' +
                            '<span class="solar-stat-label">kWh/m&sup2;/day</span>' +
                        '</div>' +
                        '<div class="solar-stat">' +
                            '<span class="solar-stat-value" id="tiltAngleVal">--</span>' +
                            '<span class="solar-stat-label">Optimal Tilt</span>' +
                        '</div>' +
                        '<div class="solar-stat">' +
                            '<span class="solar-stat-value" id="tempVal">--</span>' +
                            '<span class="solar-stat-label">Avg Temp</span>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
            '</div>';

        // Wait for Google Maps API to be ready (it may still be loading)
        waitForGoogleMaps(function() {
            initMap();
        });
    }

    function waitForGoogleMaps(callback) {
        var attempts = 0;
        var maxAttempts = 50; // 50 x 200ms = 10 seconds max wait

        function check() {
            attempts++;
            if (window.__gmapsReady || (typeof google !== 'undefined' && typeof google.maps !== 'undefined' && typeof google.maps.Map !== 'undefined')) {

                callback();
                return;
            }
            if (attempts >= maxAttempts) {
                console.error('[SolarLocation] Google Maps API failed to load after 10s');
                var mapEl = document.getElementById('locationMap');
                if (mapEl) {
                    mapEl.innerHTML =
                        '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;background:#f8f9fa;color:#555;font-size:14px;text-align:center;padding:20px;gap:12px;">' +
                            '<div style="font-size:36px;">🗺️</div>' +
                            '<div><strong>Map could not load</strong></div>' +
                            '<div style="font-size:12px;color:#888;">Check console for errors (F12). Possible causes:<br>• API key not valid<br>• Maps JavaScript API not enabled<br>• Places API not enabled<br>• Billing not set up in Google Cloud</div>' +
                            '<button onclick="location.reload()" style="margin-top:8px;padding:8px 20px;background:#f59e0b;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:13px;">Retry</button>' +
                        '</div>';
                }
                return;
            }
            setTimeout(check, 200);
        }

        check();
    }

    function initMap() {
        var mapEl = document.getElementById('locationMap');
        if (!mapEl) return;

        // Focus on user's detected country if available
        if (window.userDetectedCountry && COUNTRY_CENTERS[window.userDetectedCountry]) {
            var cc = COUNTRY_CENTERS[window.userDetectedCountry];
            DEFAULT_LAT = cc.lat;
            DEFAULT_LNG = cc.lng;
            DEFAULT_ZOOM = cc.zoom;
        }

        // Create Google Map
        try {
            map = new google.maps.Map(mapEl, {
                center: { lat: DEFAULT_LAT, lng: DEFAULT_LNG },
                zoom: DEFAULT_ZOOM,
                mapTypeControl: true,
                mapTypeControlOptions: {
                    style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
                    position: google.maps.ControlPosition.TOP_RIGHT
                },
                streetViewControl: false,
                fullscreenControl: true,
                fullscreenControlOptions: {
                    position: google.maps.ControlPosition.RIGHT_TOP
                },
                zoomControl: true,
                zoomControlOptions: {
                    position: google.maps.ControlPosition.RIGHT_BOTTOM
                },
                gestureHandling: 'greedy',
                styles: [
                    {
                        featureType: 'poi',
                        elementType: 'labels',
                        stylers: [{ visibility: 'off' }]
                    },
                    {
                        featureType: 'transit',
                        elementType: 'labels',
                        stylers: [{ visibility: 'off' }]
                    }
                ]
            });
        } catch (err) {
            console.error('[SolarLocation] Map init error:', err);
            mapEl.innerHTML =
                '<div style="display:flex;align-items:center;justify-content:center;height:100%;background:#f0f0f0;color:#c00;font-size:14px;text-align:center;padding:20px;">' +
                    '<div>❌ Map initialization failed.<br>' + err.message + '</div>' +
                '</div>';
            return;
        }

        geocoder = new google.maps.Geocoder();

        // Click on map to place marker
        map.addListener('click', function(e) {
            setLocation(e.latLng.lat(), e.latLng.lng());
        });

        // Setup Places Autocomplete
        setupAutocomplete();

        // Try restoring saved location
        var saved = loadSavedLocation();
        if (saved && saved.lat && saved.lng) {
            setLocation(saved.lat, saved.lng, saved.name, true);
            map.setCenter({ lat: saved.lat, lng: saved.lng });
            map.setZoom(10);
        }

        // Try browser geolocation if no saved location
        if (!saved && navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(pos) {
                if (!currentLocation) {
                    var lat = pos.coords.latitude;
                    var lng = pos.coords.longitude;
                    setLocation(lat, lng);
                    map.setCenter({ lat: lat, lng: lng });
                    map.setZoom(10);
                }
            }, function() {
                // denied — stay at default
            }, { timeout: 8000 });
        }
    }

    function setupAutocomplete() {
        var searchInput = document.getElementById('locationSearch');
        if (!searchInput) return;

        try {
            autocomplete = new google.maps.places.Autocomplete(searchInput, {
                fields: ['geometry', 'name', 'formatted_address', 'address_components']
            });

            // Bias results to current map viewport
            autocomplete.bindTo('bounds', map);

            autocomplete.addListener('place_changed', function() {
                var place = autocomplete.getPlace();

                if (!place || !place.geometry || !place.geometry.location) {
                    // User pressed enter without selecting — try geocoding the text
                    geocodeText(searchInput.value);
                    return;
                }

                var lat = place.geometry.location.lat();
                var lng = place.geometry.location.lng();
                var name = place.name || '';

                // Extract country
                var country = '';
                if (place.address_components) {
                    for (var i = 0; i < place.address_components.length; i++) {
                        if (place.address_components[i].types.indexOf('country') !== -1) {
                            country = place.address_components[i].long_name;
                            break;
                        }
                    }
                }

                var displayName = name + (country ? ', ' + country : '');

                map.setCenter({ lat: lat, lng: lng });
                map.setZoom(12);
                setLocation(lat, lng, displayName);
            });
        } catch (err) {
            console.warn('[SolarLocation] Places Autocomplete not available:', err.message);
            // Fallback: manual search with geocoder
            searchInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    geocodeText(searchInput.value);
                }
            });
        }
    }

    function geocodeText(text) {
        if (!text || text.length < 2 || !geocoder) return;

        geocoder.geocode({ address: text }, function(results, status) {
            if (status === 'OK' && results[0]) {
                var loc = results[0].geometry.location;
                var name = results[0].formatted_address || text;
                map.setCenter(loc);
                map.setZoom(12);
                setLocation(loc.lat(), loc.lng(), name.split(',').slice(0, 2).join(','));
            }
        });
    }

    function setLocation(lat, lng, name, skipFetch) {
        lat = Math.round(lat * 10000) / 10000;
        lng = Math.round(lng * 10000) / 10000;

        // Place or move marker
        if (marker) {
            marker.setPosition({ lat: lat, lng: lng });
        } else {
            marker = new google.maps.Marker({
                position: { lat: lat, lng: lng },
                map: map,
                draggable: true,
                animation: google.maps.Animation.DROP,
                title: 'Solar installation location'
            });

            // Drag to reposition
            marker.addListener('dragend', function() {
                var pos = marker.getPosition();
                setLocation(pos.lat(), pos.lng());
            });
        }

        currentLocation = { lat: lat, lng: lng, name: name || '' };

        // Reverse geocode if we don't have a name
        if (!name) {
            reverseGeocode(lat, lng);
        } else {
            updateInfoCard(name);
        }

        // Fetch solar data
        if (!skipFetch) {
            fetchSolarData(lat, lng);
        } else {
            var cached = loadCachedSolar();
            if (cached) {
                solarData = cached;
                updateSolarStats(cached);
                showInfoCard();
            } else {
                fetchSolarData(lat, lng);
            }
        }

        // Persist
        saveLocation();

        // Dispatch global event for weather background and other listeners
        window.dispatchEvent(new CustomEvent('locationSelected', {
            detail: { lat: lat, lng: lng, name: name || '' }
        }));

        // Notify
        onChangeCallbacks.forEach(function(cb) {
            try { cb(currentLocation, solarData); } catch(e) {}
        });
    }

    function reverseGeocode(lat, lng) {
        if (!geocoder) return;

        geocoder.geocode({ location: { lat: lat, lng: lng } }, function(results, status) {
            if (status === 'OK' && results && results[0]) {
                var name = '';
                var country = '';
                var countryCode = '';
                var components = results[0].address_components || [];

                for (var i = 0; i < components.length; i++) {
                    var types = components[i].types;
                    if (types.indexOf('locality') !== -1) {
                        name = components[i].long_name;
                    } else if (!name && types.indexOf('administrative_area_level_1') !== -1) {
                        name = components[i].long_name;
                    }
                    if (types.indexOf('country') !== -1) {
                        country = components[i].long_name;
                        countryCode = components[i].short_name;
                    }
                }

                if (!name) {
                    name = results[0].formatted_address ? results[0].formatted_address.split(',')[0] : '';
                }

                currentLocation.name = name;
                currentLocation.country = country;
                currentLocation.countryCode = countryCode;
                updateInfoCard(name + (country ? ', ' + country : ''));
                saveLocation();
            }
        });
    }

    function fetchSolarData(lat, lng) {
        // Show loading
        updateSolarStats({
            avg_sun_hours: '...',
            avg_irradiance: '...',
            optimal_tilt: '...',
            avg_temperature: '...'
        });
        showInfoCard();

        // Try our API first (caches results)
        var apiUrl = 'api/solar-data.php?lat=' + lat + '&lng=' + lng;
        fetch(apiUrl)
        .then(function(r) { return r.json(); })
        .catch(function() { return null; })
        .then(function(data) {
            if (data && data.success) {
                solarData = data;
                updateSolarStats(data);
                cacheSolarData(data);
                onChangeCallbacks.forEach(function(cb) {
                    try { cb(currentLocation, solarData); } catch(e) {}
                });
                return;
            }
            // Fallback: direct OpenMeteo
            return fetchOpenMeteoDirectly(lat, lng);
        });
    }

    function fetchOpenMeteoDirectly(lat, lng) {
        var url = 'https://api.open-meteo.com/v1/forecast?' +
            'latitude=' + lat + '&longitude=' + lng +
            '&daily=sunshine_duration,shortwave_radiation_sum,temperature_2m_max,temperature_2m_min,sunrise,sunset' +
            '&timezone=auto&past_days=30&forecast_days=7';

        return fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (!data || !data.daily) return;

            var days = data.daily.time.length;
            if (days === 0) return;

            var totalRadiation = 0;
            var totalTemp = 0;
            var totalDaylight = 0;

            for (var i = 0; i < days; i++) {
                var dailyIrr = (data.daily.shortwave_radiation_sum[i] || 0) * 0.27778;
                totalRadiation += dailyIrr;
                var tMax = data.daily.temperature_2m_max[i] || 25;
                var tMin = data.daily.temperature_2m_min[i] || 15;
                totalTemp += (tMax + tMin) / 2;
                totalDaylight += (data.daily.sunshine_duration[i] || 0) / 3600;
            }

            // Find today's sunrise/sunset
            var today = new Date().toISOString().slice(0, 10);
            var todayIdx = days - 1;
            for (var j = 0; j < days; j++) {
                if (data.daily.time[j] === today) { todayIdx = j; break; }
            }

            var sunrise = data.daily.sunrise ? data.daily.sunrise[todayIdx] : null;
            var sunset = data.daily.sunset ? data.daily.sunset[todayIdx] : null;
            var sunriseTime = sunrise ? sunrise.slice(11, 16) : null;
            var sunsetTime = sunset ? sunset.slice(11, 16) : null;

            var daylightHours = null;
            if (sunrise && sunset) {
                daylightHours = Math.round((new Date(sunset) - new Date(sunrise)) / 3600000 * 10) / 10;
            }

            var avgIrradiance = totalRadiation / days;
            solarData = {
                success: true,
                avg_sun_hours: Math.round(avgIrradiance * 10) / 10,
                avg_irradiance: Math.round(avgIrradiance * 100) / 100,
                avg_temperature: Math.round(totalTemp / days * 10) / 10,
                avg_daylight_hours: Math.round(totalDaylight / days * 10) / 10,
                optimal_tilt: Math.round(Math.abs(lat) * 10) / 10,
                sunrise: sunriseTime,
                sunset: sunsetTime,
                daylight_hours: daylightHours,
                latitude: lat,
                longitude: lng
            };

            updateSolarStats(solarData);
            cacheSolarData(solarData);
            onChangeCallbacks.forEach(function(cb) {
                try { cb(currentLocation, solarData); } catch(e) {}
            });
        })
        .catch(function(err) {
            console.warn('[SolarLocation] OpenMeteo fetch failed:', err);
        });
    }

    function updateInfoCard(name) {
        var nameEl = document.getElementById('locationName');
        var coordsEl = document.getElementById('locationCoords');
        if (nameEl) nameEl.textContent = name || 'Selected Location';
        if (coordsEl && currentLocation) {
            coordsEl.textContent = currentLocation.lat.toFixed(4) + '°, ' + currentLocation.lng.toFixed(4) + '°';
        }
    }

    function updateSolarStats(data) {
        var el;

        el = document.getElementById('sunHoursVal');
        if (el) {
            if (data.avg_sun_hours === '...') { el.textContent = '...'; }
            else el.textContent = (data.avg_sun_hours || '--') + 'h';
        }

        el = document.getElementById('irradianceVal');
        if (el) {
            if (data.avg_irradiance === '...') { el.textContent = '...'; }
            else el.textContent = data.avg_irradiance || '--';
        }

        el = document.getElementById('tiltAngleVal');
        if (el) {
            if (data.optimal_tilt === '...') { el.textContent = '...'; }
            else el.textContent = (data.optimal_tilt || '--') + '°';
        }

        el = document.getElementById('tempVal');
        if (el) {
            if (data.avg_temperature === '...') { el.textContent = '...'; }
            else el.textContent = (data.avg_temperature || '--') + '°C';
        }

        // Sunrise / Sunset / Daylight hours
        el = document.getElementById('sunriseVal');
        if (el) {
            if (data.sunrise === '...' || data.avg_sun_hours === '...') { el.textContent = '...'; }
            else el.textContent = data.sunrise || '--';
        }

        el = document.getElementById('sunsetVal');
        if (el) {
            if (data.sunset === '...' || data.avg_sun_hours === '...') { el.textContent = '...'; }
            else el.textContent = data.sunset || '--';
        }

        el = document.getElementById('daylightHoursVal');
        if (el) {
            if (data.daylight_hours === '...' || data.avg_sun_hours === '...') { el.textContent = '...'; }
            else el.textContent = data.daylight_hours ? data.daylight_hours + 'h' : '--';
        }
    }

    function showInfoCard() {
        var card = document.getElementById('locationInfoCard');
        if (card) {
            card.style.display = 'block';
        }
    }

    function saveLocation() {
        try {
            localStorage.setItem('solarglobal_location', JSON.stringify(currentLocation));
            // Also set sg_location cookie so PHP pages can read the country_code for currency
            var cookieData = JSON.stringify({
                lat: currentLocation.lat,
                lng: currentLocation.lng,
                city: currentLocation.name || '',
                country_code: currentLocation.countryCode || ''
            });
            document.cookie = 'sg_location=' + encodeURIComponent(cookieData) + ';path=/solarglobal/;max-age=' + (30 * 86400) + ';SameSite=Lax';
        } catch(e) {}
    }

    function loadSavedLocation() {
        try {
            var s = localStorage.getItem('solarglobal_location');
            return s ? JSON.parse(s) : null;
        } catch(e) { return null; }
    }

    function cacheSolarData(data) {
        try {
            localStorage.setItem('solarglobal_solar', JSON.stringify(data));
        } catch(e) {}
    }

    function loadCachedSolar() {
        try {
            var s = localStorage.getItem('solarglobal_solar');
            return s ? JSON.parse(s) : null;
        } catch(e) { return null; }
    }

    return {
        init: init,
        getLocation: function() { return currentLocation; },
        getSolarData: function() { return solarData; },
        onLocationChange: function(cb) { onChangeCallbacks.push(cb); },
        setLocation: setLocation
    };
})();
