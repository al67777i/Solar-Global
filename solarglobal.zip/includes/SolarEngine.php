<?php
/**
 * SolarEngine - Advanced Solar Calculation Engine
 *
 * Provides accurate solar position, generation modeling, and energy forecasting
 * for the locationi cities with real meteorological data integration.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/city_helper.php';

class SolarEngine {

    private $pdo;

    // Panel technology defaults (crystalline silicon)
    private const TEMP_COEFF = -0.0035; // %/°C power temperature coefficient
    private const NOCT = 45; // Nominal Operating Cell Temperature °C
    private const STC_TEMP = 25; // Standard Test Condition temperature °C
    private const STC_IRRADIANCE = 1000; // W/m² at STC

    // the location-specific soiling factors by month (1=Jan, 12=Dec)
    // Higher = more soiling loss (dust storms in May-June, monsoon cleans in Jul-Aug)
    private const SOILING_FACTORS = [
        1 => 0.03, 2 => 0.04, 3 => 0.05, 4 => 0.06,
        5 => 0.08, 6 => 0.09, 7 => 0.02, 8 => 0.02,
        9 => 0.03, 10 => 0.04, 11 => 0.04, 12 => 0.03
    ];

    // System loss components
    private const INVERTER_LOSS = 0.03;
    private const WIRING_LOSS = 0.02;
    private const MISMATCH_LOSS = 0.02;
    private const DEGRADATION_YEAR1 = 0.02; // First year degradation
    private const DEGRADATION_ANNUAL = 0.005; // Annual degradation after year 1

    public function __construct() {
        $this->pdo = getDB();
    }

    // ========================================================
    // SOLAR POSITION CALCULATIONS
    // ========================================================

    /**
     * Calculate solar declination angle for a given day of year
     */
    public function getSolarDeclination(int $dayOfYear): float {
        return 23.45 * sin(deg2rad((360 / 365) * ($dayOfYear - 81)));
    }

    /**
     * Calculate equation of time (minutes) for solar noon correction
     */
    public function getEquationOfTime(int $dayOfYear): float {
        $b = deg2rad((360 / 365) * ($dayOfYear - 81));
        return 9.87 * sin(2 * $b) - 7.53 * cos($b) - 1.5 * sin($b);
    }

    /**
     * Calculate solar hour angle for a given time
     */
    public function getHourAngle(float $localSolarTime): float {
        return ($localSolarTime - 12) * 15;
    }

    /**
     * Calculate solar elevation angle
     */
    public function getSolarElevation(float $lat, float $declination, float $hourAngle): float {
        $latRad = deg2rad($lat);
        $decRad = deg2rad($declination);
        $haRad = deg2rad($hourAngle);

        $sinElev = sin($latRad) * sin($decRad) + cos($latRad) * cos($decRad) * cos($haRad);
        return rad2deg(asin(max(-1, min(1, $sinElev))));
    }

    /**
     * Calculate solar azimuth angle (0=North, 90=East, 180=South, 270=West)
     */
    public function getSolarAzimuth(float $lat, float $declination, float $hourAngle, float $elevation): float {
        $latRad = deg2rad($lat);
        $decRad = deg2rad($declination);
        $haRad = deg2rad($hourAngle);
        $elevRad = deg2rad($elevation);

        $cosAz = (sin($decRad) - sin($latRad) * sin($elevRad)) / (cos($latRad) * cos($elevRad));
        $cosAz = max(-1, min(1, $cosAz));
        $azimuth = rad2deg(acos($cosAz));

        if ($hourAngle > 0) {
            $azimuth = 360 - $azimuth;
        }

        return $azimuth;
    }

    /**
     * Get complete solar position data for a city at a specific date/time
     */
    public function getSolarPosition(int $cityId, ?string $dateTime = null): array {
        $city = getCityById($cityId);
        if (!$city) return ['success' => false, 'error' => 'City not found'];

        $dt = $dateTime ? new DateTime($dateTime) : new DateTime();
        $dayOfYear = (int)$dt->format('z') + 1;
        $hour = (int)$dt->format('G') + (int)$dt->format('i') / 60;

        $lat = (float)$city['latitude'];
        $lng = (float)$city['longitude'];

        $declination = $this->getSolarDeclination($dayOfYear);
        $eot = $this->getEquationOfTime($dayOfYear);

        // the location Standard Time is UTC+5, reference meridian 75°E
        $timeCorrection = 4 * ($lng - 75) + $eot;
        $localSolarTime = $hour + $timeCorrection / 60;

        $hourAngle = $this->getHourAngle($localSolarTime);
        $elevation = $this->getSolarElevation($lat, $declination, $hourAngle);
        $azimuth = $this->getSolarAzimuth($lat, $declination, $hourAngle, $elevation);

        // Sunrise/sunset hour angles
        $sunriseHA = rad2deg(acos(-tan(deg2rad($lat)) * tan(deg2rad($declination))));
        $daylightHours = 2 * $sunriseHA / 15;

        return [
            'success' => true,
            'city' => $city['name_en'],
            'latitude' => $lat,
            'longitude' => $lng,
            'date' => $dt->format('Y-m-d'),
            'time' => $dt->format('H:i'),
            'day_of_year' => $dayOfYear,
            'declination' => round($declination, 2),
            'equation_of_time_min' => round($eot, 2),
            'hour_angle' => round($hourAngle, 2),
            'elevation' => round($elevation, 2),
            'azimuth' => round($azimuth, 2),
            'is_daylight' => $elevation > 0,
            'daylight_hours' => round($daylightHours, 2),
            'sunrise_hour' => round(12 - $sunriseHA / 15, 2),
            'sunset_hour' => round(12 + $sunriseHA / 15, 2)
        ];
    }

    // ========================================================
    // CELL TEMPERATURE MODEL
    // ========================================================

    /**
     * Calculate PV cell temperature using Ross model with wind correction
     * More accurate than simple NOCT approximation
     */
    public function getCellTemperature(float $ambientTemp, float $irradiance, float $windSpeed = 1.0): float {
        // Ross model: Tcell = Tambient + (NOCT - 20) × (Irradiance/800) × (1 - η/τα)
        // Simplified with wind correction factor
        $windFactor = 1.0 / (1.0 + 0.1 * $windSpeed);
        $cellTemp = $ambientTemp + (self::NOCT - 20) * ($irradiance / 800) * $windFactor;
        return $cellTemp;
    }

    /**
     * Calculate temperature derating factor
     */
    public function getTemperatureDerating(float $cellTemp): float {
        $deltaT = $cellTemp - self::STC_TEMP;
        return max(0.5, 1.0 + self::TEMP_COEFF * $deltaT);
    }

    // ========================================================
    // OPTIMAL TILT ANGLE
    // ========================================================

    /**
     * Calculate optimal tilt angle for a given latitude and month
     * For the location (northern hemisphere), panels face south (azimuth 180°)
     */
    public function getOptimalTilt(float $latitude, ?int $month = null): array {
        if ($month) {
            $dayOfYear = (int)((($month - 1) * 30.44) + 15);
            $declination = $this->getSolarDeclination($dayOfYear);
            $optimalTilt = $latitude - $declination;
            return [
                'tilt' => round(max(5, min(60, $optimalTilt)), 1),
                'azimuth' => 180,
                'type' => 'monthly_optimal',
                'month' => $month
            ];
        }

        // Annual optimal = latitude × 0.87 (empirical for fixed installations)
        $annualOptimal = $latitude * 0.87;

        // Seasonal recommendations
        $winterTilt = $latitude + 15;
        $summerTilt = $latitude - 15;

        return [
            'annual_fixed' => round($annualOptimal, 1),
            'summer_optimal' => round(max(5, $summerTilt), 1),
            'winter_optimal' => round(min(60, $winterTilt), 1),
            'azimuth' => 180,
            'type' => 'annual_recommendations'
        ];
    }

    /**
     * Calculate irradiance on tilted surface from horizontal irradiance
     */
    public function getIrradianceOnTilt(float $horizontalIrradiance, float $tiltAngle, float $latitude, int $dayOfYear): float {
        $declination = $this->getSolarDeclination($dayOfYear);
        $latRad = deg2rad($latitude);
        $decRad = deg2rad($declination);
        $tiltRad = deg2rad($tiltAngle);

        // Beam radiation ratio (Liu & Jordan model simplified)
        $cosZenith = sin($latRad) * sin($decRad) + cos($latRad) * cos($decRad);
        $cosTilt = sin($latRad - $tiltRad) * sin($decRad) + cos($latRad - $tiltRad) * cos($decRad);

        if ($cosZenith <= 0.01) return $horizontalIrradiance;

        $rb = max(0.5, min(2.5, $cosTilt / $cosZenith));

        // Assume 30% diffuse, 70% beam for clear skies
        $diffuseRatio = 0.30;
        $beamIrr = $horizontalIrradiance * (1 - $diffuseRatio) * $rb;
        $diffuseIrr = $horizontalIrradiance * $diffuseRatio * (1 + cos($tiltRad)) / 2;
        $groundReflected = $horizontalIrradiance * 0.2 * (1 - cos($tiltRad)) / 2;

        return $beamIrr + $diffuseIrr + $groundReflected;
    }

    // ========================================================
    // GENERATION CALCULATIONS
    // ========================================================

    /**
     * Calculate detailed daily generation with all loss factors
     */
    public function calculateDetailedGeneration(
        int $cityId,
        int $panelWattPeak,
        int $numPanels,
        ?int $month = null,
        ?float $tiltAngle = null,
        float $systemAgeYears = 0
    ): array {
        if (!$month) $month = (int)date('n');

        $city = getCityById($cityId);
        if (!$city) return ['success' => false, 'error' => 'City not found'];

        $sunData = getSunDataForCity($cityId, $month);
        if (!$sunData) return ['success' => false, 'error' => 'No sun data for this city/month'];

        $lat = (float)$city['latitude'];
        $totalCapacityKw = ($panelWattPeak * $numPanels) / 1000;

        // Optimal tilt if not specified
        if ($tiltAngle === null) {
            $tiltData = $this->getOptimalTilt($lat, $month);
            $tiltAngle = $tiltData['tilt'];
        }

        // Day of year for mid-month
        $dayOfYear = (int)((($month - 1) * 30.44) + 15);

        // Horizontal irradiance from sun_data (kWh/m²/day)
        $horizontalIrr = (float)$sunData['avg_irradiance_kwh_m2'];
        $psh = (float)$sunData['peak_sun_hours'];

        // Convert to tilted surface irradiance
        $tiltedIrr = $this->getIrradianceOnTilt($horizontalIrr, $tiltAngle, $lat, $dayOfYear);

        // Effective PSH on tilted surface
        $effectivePSH = $psh * ($tiltedIrr / max(0.1, $horizontalIrr));

        // Temperature derating
        $ambientTemp = (float)$sunData['avg_temperature_c'];
        $peakIrradiance = 800; // W/m² typical midday
        $windSpeed = 1.5; // m/s average
        $cellTemp = $this->getCellTemperature($ambientTemp, $peakIrradiance, $windSpeed);
        $tempDerating = $this->getTemperatureDerating($cellTemp);

        // Soiling loss
        $soilingLoss = self::SOILING_FACTORS[$month] ?? 0.04;

        // Age degradation
        $degradation = 1.0;
        if ($systemAgeYears > 0) {
            $degradation = (1 - self::DEGRADATION_YEAR1) * pow(1 - self::DEGRADATION_ANNUAL, max(0, $systemAgeYears - 1));
        }

        // Calculate generation
        $grossGen = $totalCapacityKw * $effectivePSH;
        $afterTemp = $grossGen * $tempDerating;
        $afterSoiling = $afterTemp * (1 - $soilingLoss);
        $afterSystemLoss = $afterSoiling * (1 - self::INVERTER_LOSS - self::WIRING_LOSS - self::MISMATCH_LOSS);
        $netGen = $afterSystemLoss * $degradation;

        $overallEfficiency = ($grossGen > 0) ? ($netGen / $grossGen) : 0;

        return [
            'success' => true,
            'city' => $city['name_en'],
            'month' => $month,
            'month_name' => date('F', mktime(0, 0, 0, $month, 1)),
            'system_kwp' => $totalCapacityKw,
            'tilt_angle' => $tiltAngle,
            'generation' => [
                'gross_kwh' => round($grossGen, 2),
                'after_temperature' => round($afterTemp, 2),
                'after_soiling' => round($afterSoiling, 2),
                'net_kwh' => round($netGen, 2)
            ],
            'losses' => [
                'temperature_loss_pct' => round((1 - $tempDerating) * 100, 1),
                'soiling_loss_pct' => round($soilingLoss * 100, 1),
                'inverter_loss_pct' => round(self::INVERTER_LOSS * 100, 1),
                'wiring_loss_pct' => round(self::WIRING_LOSS * 100, 1),
                'mismatch_loss_pct' => round(self::MISMATCH_LOSS * 100, 1),
                'degradation_pct' => round((1 - $degradation) * 100, 1),
                'total_loss_pct' => round((1 - $overallEfficiency) * 100, 1)
            ],
            'conditions' => [
                'ambient_temp_c' => $ambientTemp,
                'cell_temp_c' => round($cellTemp, 1),
                'peak_sun_hours' => $psh,
                'effective_psh_tilted' => round($effectivePSH, 2),
                'horizontal_irradiance' => $horizontalIrr,
                'tilted_irradiance' => round($tiltedIrr, 2),
                'cloud_cover_pct' => (float)$sunData['avg_cloud_cover_percent']
            ]
        ];
    }

    // ========================================================
    // ANNUAL ENERGY YIELD & FINANCIAL ANALYSIS
    // ========================================================

    /**
     * Calculate complete annual energy yield with monthly breakdown
     */
    public function getAnnualYield(
        int $cityId,
        int $panelWattPeak,
        int $numPanels,
        ?float $tiltAngle = null,
        float $systemAgeYears = 0
    ): array {
        $city = getCityById($cityId);
        if (!$city) return ['success' => false, 'error' => 'City not found'];

        $monthly = [];
        $totalAnnual = 0;

        for ($m = 1; $m <= 12; $m++) {
            $daily = $this->calculateDetailedGeneration($cityId, $panelWattPeak, $numPanels, $m, $tiltAngle, $systemAgeYears);
            if (!$daily['success']) continue;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $m, (int)date('Y'));
            $monthlyKwh = $daily['generation']['net_kwh'] * $daysInMonth;
            $totalAnnual += $monthlyKwh;

            $monthly[] = [
                'month' => $m,
                'month_name' => $daily['month_name'],
                'daily_kwh' => $daily['generation']['net_kwh'],
                'monthly_kwh' => round($monthlyKwh, 1),
                'effective_psh' => $daily['conditions']['effective_psh_tilted'],
                'avg_temp' => $daily['conditions']['ambient_temp_c'],
                'cell_temp' => $daily['conditions']['cell_temp_c'],
                'total_loss_pct' => $daily['losses']['total_loss_pct'],
                'tilt_angle' => $daily['tilt_angle']
            ];
        }

        $systemKwp = ($panelWattPeak * $numPanels) / 1000;
        $specificYield = $totalAnnual / max(0.01, $systemKwp); // kWh/kWp/year
        $capacityFactor = $totalAnnual / ($systemKwp * 8760) * 100;

        return [
            'success' => true,
            'city' => $city['name_en'],
            'system_kwp' => $systemKwp,
            'panel_watts' => $panelWattPeak,
            'num_panels' => $numPanels,
            'annual_kwh' => round($totalAnnual, 1),
            'specific_yield_kwh_kwp' => round($specificYield, 0),
            'capacity_factor_pct' => round($capacityFactor, 1),
            'performance_ratio' => round($specificYield / 1800, 2), // vs theoretical max ~1800 for the location
            'monthly' => $monthly
        ];
    }

    /**
     * Financial analysis: ROI, payback period, savings
     */
    public function getFinancialAnalysis(
        int $cityId,
        int $panelWattPeak,
        int $numPanels,
        float $systemCostUsd,
        float $electricityRateUSD = 0,
        float $netMeteringRateUSD = 0,
        float $selfConsumptionRatio = 0.7
    ): array {
        if (!$electricityRateUsd) $electricityRateUSD = getElectricityRate();
        if (!$netMeteringRateUsd) $netMeteringRateUSD = getNetMeteringRate();

        $annualYield = $this->getAnnualYield($cityId, $panelWattPeak, $numPanels);
        if (!$annualYield['success']) return $annualYield;

        $annualKwh = $annualYield['annual_kwh'];
        $selfConsumed = $annualKwh * $selfConsumptionRatio;
        $exported = $annualKwh * (1 - $selfConsumptionRatio);

        $annualSavings = ($selfConsumed * $electricityRateUsd) + ($exported * $netMeteringRateUsd);
        $paybackYears = $systemCostUSD / max(1, $annualSavings);

        // 25-year lifetime analysis
        $lifetimeGeneration = 0;
        $lifetimeSavings = 0;
        $yearlyBreakdown = [];
        $rateInflation = 0.10; // 10% annual electricity price increase

        for ($year = 1; $year <= 25; $year++) {
            $yearYield = $this->getAnnualYield($cityId, $panelWattPeak, $numPanels, null, $year);
            $yearKwh = $yearYield['success'] ? $yearYield['annual_kwh'] : $annualKwh * pow(0.995, $year);

            $yearRate = $electricityRateUSD * pow(1 + $rateInflation, $year - 1);
            $yearNetRate = $netMeteringRateUSD * pow(1 + $rateInflation, $year - 1);

            $yearSavings = ($yearKwh * $selfConsumptionRatio * $yearRate)
                         + ($yearKwh * (1 - $selfConsumptionRatio) * $yearNetRate);

            $lifetimeGeneration += $yearKwh;
            $lifetimeSavings += $yearSavings;

            $yearlyBreakdown[] = [
                'year' => $year,
                'generation_kwh' => round($yearKwh, 0),
                'savings_usd' => round($yearSavings, 0),
                'cumulative_savings_usd' => round($lifetimeSavings, 0),
                'net_position_usd' => round($lifetimeSavings - $systemCostUsd, 0)
            ];
        }

        $lcoe = $systemCostUSD / max(1, $lifetimeGeneration);

        return [
            'success' => true,
            'investment' => [
                'system_cost_usd' => $systemCostUsd,
                'system_kwp' => $annualYield['system_kwp'],
                'cost_per_watt_usd' => round($systemCostUSD / ($panelWattPeak * $numPanels), 1)
            ],
            'annual' => [
                'generation_kwh' => round($annualKwh, 0),
                'self_consumed_kwh' => round($selfConsumed, 0),
                'exported_kwh' => round($exported, 0),
                'savings_usd' => round($annualSavings, 0),
                'electricity_rate_usd' => $electricityRateUsd,
                'net_metering_rate_usd' => $netMeteringRateUsd
            ],
            'returns' => [
                'payback_years' => round($paybackYears, 1),
                'lifetime_generation_kwh' => round($lifetimeGeneration, 0),
                'lifetime_savings_usd' => round($lifetimeSavings, 0),
                'roi_percent' => round(($lifetimeSavings / max(1, $systemCostUsd) - 1) * 100, 0),
                'lcoe_usd_kwh' => round($lcoe, 2)
            ],
            'yearly_breakdown' => $yearlyBreakdown
        ];
    }

    // ========================================================
    // ENERGY FORECAST STORAGE
    // ========================================================

    /**
     * Generate and store 30-day energy forecast
     */
    public function generateForecast(int $cityId, int $panelWattPeak, int $numPanels): array {
        $city = getCityById($cityId);
        if (!$city) return ['success' => false, 'error' => 'City not found'];

        $lat = (float)$city['latitude'];
        $tiltData = $this->getOptimalTilt($lat);
        $tiltAngle = $tiltData['annual_fixed'];

        $forecasts = [];
        $today = new DateTime();

        for ($day = 0; $day < 30; $day++) {
            $date = clone $today;
            $date->modify("+$day days");
            $month = (int)$date->format('n');
            $dayOfYear = (int)$date->format('z') + 1;

            $sunData = getSunDataForCity($cityId, $month);
            if (!$sunData) continue;

            $totalCapacityKw = ($panelWattPeak * $numPanels) / 1000;
            $horizontalIrr = (float)$sunData['avg_irradiance_kwh_m2'];
            $psh = (float)$sunData['peak_sun_hours'];
            $tiltedIrr = $this->getIrradianceOnTilt($horizontalIrr, $tiltAngle, $lat, $dayOfYear);
            $effectivePSH = $psh * ($tiltedIrr / max(0.1, $horizontalIrr));

            $ambientTemp = (float)$sunData['avg_temperature_c'];
            $cellTemp = $this->getCellTemperature($ambientTemp, 800, 1.5);
            $tempDerating = $this->getTemperatureDerating($cellTemp);
            $soilingLoss = self::SOILING_FACTORS[$month] ?? 0.04;

            $grossGen = $totalCapacityKw * $effectivePSH;
            $netGen = $grossGen * $tempDerating * (1 - $soilingLoss)
                    * (1 - self::INVERTER_LOSS - self::WIRING_LOSS - self::MISMATCH_LOSS);

            $forecasts[] = [
                'date' => $date->format('Y-m-d'),
                'month' => $month,
                'gross_kwh' => round($grossGen, 2),
                'net_kwh' => round($netGen, 2),
                'psh' => round($effectivePSH, 2),
                'temp_c' => $ambientTemp,
                'cell_temp_c' => round($cellTemp, 1),
                'efficiency_pct' => round(($netGen / max(0.01, $grossGen)) * 100, 1)
            ];
        }

        // Store in energy_forecasts table
        $this->storeForecast($cityId, $panelWattPeak, $numPanels, $forecasts);

        $totalNet = array_sum(array_column($forecasts, 'net_kwh'));
        $avgDaily = count($forecasts) > 0 ? $totalNet / count($forecasts) : 0;

        return [
            'success' => true,
            'city' => $city['name_en'],
            'system_kwp' => ($panelWattPeak * $numPanels) / 1000,
            'tilt_angle' => $tiltAngle,
            'forecast_days' => count($forecasts),
            'total_net_kwh' => round($totalNet, 1),
            'avg_daily_kwh' => round($avgDaily, 2),
            'daily_forecast' => $forecasts
        ];
    }

    /**
     * Store forecast data in energy_forecasts table
     */
    private function storeForecast(int $cityId, int $panelWatts, int $numPanels, array $forecasts): void {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO energy_forecasts (city_id, forecast_date, panel_watts, num_panels, gross_kwh, net_kwh, peak_sun_hours, temperature_c, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE gross_kwh = VALUES(gross_kwh), net_kwh = VALUES(net_kwh),
                    peak_sun_hours = VALUES(peak_sun_hours), temperature_c = VALUES(temperature_c), created_at = NOW()
            ");

            foreach ($forecasts as $f) {
                $stmt->execute([
                    $cityId, $f['date'], $panelWatts, $numPanels,
                    $f['gross_kwh'], $f['net_kwh'], $f['psh'], $f['temp_c']
                ]);
            }
        } catch (PDOException $e) {
            error_log("SolarEngine forecast storage error: " . $e->getMessage());
        }
    }

    // ========================================================
    // COMPARISON & OPTIMIZATION
    // ========================================================

    /**
     * Compare generation across multiple cities
     */
    public function compareCities(array $cityIds, int $panelWattPeak, int $numPanels): array {
        $results = [];
        foreach ($cityIds as $cid) {
            $yield = $this->getAnnualYield($cid, $panelWattPeak, $numPanels);
            if ($yield['success']) {
                $results[] = [
                    'city_id' => $cid,
                    'city' => $yield['city'],
                    'annual_kwh' => $yield['annual_kwh'],
                    'specific_yield' => $yield['specific_yield_kwh_kwp'],
                    'capacity_factor' => $yield['capacity_factor_pct'],
                    'best_month' => null,
                    'worst_month' => null
                ];

                $best = $worst = $yield['monthly'][0];
                foreach ($yield['monthly'] as $m) {
                    if ($m['daily_kwh'] > $best['daily_kwh']) $best = $m;
                    if ($m['daily_kwh'] < $worst['daily_kwh']) $worst = $m;
                }
                $results[count($results) - 1]['best_month'] = $best['month_name'] . ' (' . $best['daily_kwh'] . ' kWh/day)';
                $results[count($results) - 1]['worst_month'] = $worst['month_name'] . ' (' . $worst['daily_kwh'] . ' kWh/day)';
            }
        }

        usort($results, fn($a, $b) => $b['annual_kwh'] <=> $a['annual_kwh']);

        return [
            'success' => true,
            'system_kwp' => ($panelWattPeak * $numPanels) / 1000,
            'comparison' => $results
        ];
    }

    /**
     * Find optimal system size for given daily consumption
     */
    public function optimizeSystemSize(int $cityId, float $dailyConsumptionKwh, int $panelWattPeak = 550): array {
        $city = getCityById($cityId);
        if (!$city) return ['success' => false, 'error' => 'City not found'];

        // Find minimum panels needed to meet daily demand on worst month
        $worstPSH = PHP_FLOAT_MAX;
        $worstMonth = 1;

        for ($m = 1; $m <= 12; $m++) {
            $gen = $this->calculateDetailedGeneration($cityId, $panelWattPeak, 1, $m);
            if ($gen['success'] && $gen['generation']['net_kwh'] < $worstPSH) {
                $worstPSH = $gen['generation']['net_kwh'];
                $worstMonth = $m;
            }
        }

        $panelDailyKwh = $worstPSH;
        $minPanels = (int)ceil($dailyConsumptionKwh / max(0.1, $panelDailyKwh));
        $recommendedPanels = (int)ceil($minPanels * 1.15); // 15% buffer

        $annualYield = $this->getAnnualYield($cityId, $panelWattPeak, $recommendedPanels);

        return [
            'success' => true,
            'city' => $city['name_en'],
            'daily_consumption_kwh' => $dailyConsumptionKwh,
            'monthly_consumption_kwh' => round($dailyConsumptionKwh * 30, 0),
            'panel_watts' => $panelWattPeak,
            'minimum_panels' => $minPanels,
            'recommended_panels' => $recommendedPanels,
            'system_kwp' => round(($panelWattPeak * $recommendedPanels) / 1000, 2),
            'worst_month' => date('F', mktime(0, 0, 0, $worstMonth, 1)),
            'worst_month_daily_kwh' => round($panelDailyKwh * $recommendedPanels, 2),
            'annual_generation_kwh' => $annualYield['success'] ? $annualYield['annual_kwh'] : 0,
            'self_sufficiency_pct' => $annualYield['success']
                ? round(min(100, ($annualYield['annual_kwh'] / ($dailyConsumptionKwh * 365)) * 100), 0)
                : 0
        ];
    }

    // ========================================================
    // SUN PATH DIAGRAM DATA
    // ========================================================

    /**
     * Generate sun path data for visualization (Chart.js polar/scatter)
     */
    public function getSunPathData(int $cityId, ?string $date = null): array {
        $city = getCityById($cityId);
        if (!$city) return ['success' => false, 'error' => 'City not found'];

        $lat = (float)$city['latitude'];
        $dt = $date ? new DateTime($date) : new DateTime();
        $dayOfYear = (int)$dt->format('z') + 1;
        $declination = $this->getSolarDeclination($dayOfYear);

        $path = [];
        // Calculate sun position for each hour 5am-7pm
        for ($h = 5; $h <= 19; $h += 0.5) {
            $hourAngle = $this->getHourAngle($h);
            $elevation = $this->getSolarElevation($lat, $declination, $hourAngle);
            if ($elevation < 0) continue;

            $azimuth = $this->getSolarAzimuth($lat, $declination, $hourAngle, $elevation);
            $path[] = [
                'hour' => $h,
                'elevation' => round($elevation, 1),
                'azimuth' => round($azimuth, 1)
            ];
        }

        // Key dates for annual sun path
        $keyDates = [
            ['name' => 'Summer Solstice', 'day' => 172],
            ['name' => 'Equinox', 'day' => 80],
            ['name' => 'Winter Solstice', 'day' => 355]
        ];

        $annualPaths = [];
        foreach ($keyDates as $kd) {
            $dec = $this->getSolarDeclination($kd['day']);
            $dayPath = [];
            for ($h = 5; $h <= 19; $h += 0.5) {
                $ha = $this->getHourAngle($h);
                $elev = $this->getSolarElevation($lat, $dec, $ha);
                if ($elev < 0) continue;
                $az = $this->getSolarAzimuth($lat, $dec, $ha, $elev);
                $dayPath[] = ['hour' => $h, 'elevation' => round($elev, 1), 'azimuth' => round($az, 1)];
            }
            $annualPaths[] = ['name' => $kd['name'], 'path' => $dayPath];
        }

        return [
            'success' => true,
            'city' => $city['name_en'],
            'latitude' => $lat,
            'date' => $dt->format('Y-m-d'),
            'today_path' => $path,
            'annual_paths' => $annualPaths,
            'max_elevation' => !empty($path) ? max(array_column($path, 'elevation')) : 0
        ];
    }
}
