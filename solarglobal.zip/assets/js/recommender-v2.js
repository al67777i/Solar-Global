﻿/**
 * Recommender V2 — Updated to use recommend_v7.php
 * Renders 3 clear categories:
 *   1. Traditional    (Non-BMS + Lead-Acid/Tubular)
 *   2. Maintenance-Free (Non-BMS + Dry/Gel/AGM)
 *   3. Premium Smart  (BMS + Lithium)
 * Each category shows Recommended / +2KW / +3KW tiers
 */

let backupHours = 4;

// ─── Backup hours slider ─────────────────────────────────────────────────────
function setupBackupHoursSlider() {
    const slider      = document.getElementById('backup-hours-slider');
    const display     = document.getElementById('backup-hours-display');
    const loadDisplay = document.getElementById('backup-load-display');
    const battDisplay = document.getElementById('backup-battery-display');
    if (!slider) return;

    slider.addEventListener('input', function () {
        backupHours = parseFloat(this.value);
        
        // FIXED: Use appState.totalWatts directly (already calculated with load factors)
        const totalWatts = window.appState?.totalWatts || 0;



        // Update backup hours display
        if (display) {
            display.textContent = backupHours;
        }
        
        // Update load display
        if (loadDisplay) {
            loadDisplay.textContent = totalWatts.toLocaleString() + 'W';
        }
        
        // Calculate and update battery requirement
        if (battDisplay && totalWatts > 0) {
            // Determine system voltage based on load
            const systemVoltage = totalWatts <= 1440 ? 12
                                : totalWatts <= 3600 ? 24 : 48;
            
            // Calculate required Ah (with 20% safety margin)
            const requiredWh = totalWatts * backupHours * 1.2;
            const requiredAh = Math.ceil(requiredWh / systemVoltage);
            
            battDisplay.textContent = '~' + requiredAh.toLocaleString() + 'Ah @ ' + systemVoltage + 'V';

        } else if (battDisplay) {
            battDisplay.textContent = '0 Ah';
        }
    });
    
    // Trigger initial update
    slider.dispatchEvent(new Event('input'));
}

// ─── Main entry point ────────────────────────────────────────────────────────
async function findSolarSystem() {
    if (!window.appState?.selectedAppliances?.length) {
        alert('Please select at least one appliance');
        return;
    }

    showLoading('Calculating best solar systems for you…');

    try {
        // Build appliance payload
        const appliances = window.appState.selectedAppliances.map(item => {
            if (!item.hourlyUsage) {
                item.hourlyUsage = Array(24).fill(0);
                if (item.startTime !== undefined && item.endTime !== undefined) {
                    for (let h = item.startTime; h < item.endTime; h++) item.hourlyUsage[h] = 1;
                }
            }
            let startTime = 0, endTime = 24;
            for (let h = 0; h < 24; h++) { if (item.hourlyUsage[h] === 1) { startTime = h; break; } }
            for (let h = 23; h >= 0; h--) { if (item.hourlyUsage[h] === 1) { endTime = h + 1; break; } }

            return {
                id:          item.applianceId,
                quantity:    1,
                hours:       item.hourlyUsage.filter(h => h === 1).length,
                startTime,
                endTime,
                hourlyUsage: item.hourlyUsage,
                loadFactor:  item.loadFactor || 100
            };
        });

        const csrfToken = window.csrfToken || '';
        if (!csrfToken) {
            hideLoading();
            alert('Security token missing. Please refresh the page.');
            return;
        }

        // ── Call V7 API (with city-specific solar intelligence) ────────────
        const cityId = window.citySelector?.getCityId() || localStorage.getItem('selectedCityId') || 0;
        const response = await fetch('api/recommend_v7.php', {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({
                csrf_token: csrfToken,
                appliances,
                backup_hours: backupHours,
                city_id: parseInt(cityId) || 0
            })
        });

        const data = await response.json();
        hideLoading();

        if (data.success) {
            window.appState.recommendations = data;

            // CRITICAL: Save state before rendering
            if (typeof saveState === 'function') {
                saveState();
            }

            renderV7Categories(data);

            // Energy forecast moved to Step 4 (configurator) — triggered on panel change

            goToStep(3);
        } else {
            handleApiError(data);
        }

    } catch (err) {
        hideLoading();
        console.error('Error:', err);
        alert('Failed to connect to server. Please try again.');
    }
}

// ─── Error handler ───────────────────────────────────────────────────────────
function handleApiError(data) {
    const container = document.getElementById('recommendations-container');
    if (data.error === 'no_inverters') {
        if (container) container.innerHTML = `
            <div style="text-align:center;padding:60px 20px;">
                <div style="font-size:64px;margin-bottom:16px;">⚠️</div>
                <h2 style="color:#DC2626;">No Inverters Available</h2>
                <p style="color:#64748B;">${data.message}</p>
                <button onclick="goToStep(2)" class="btn btn-primary" style="margin-top:20px;">← Go Back</button>
            </div>`;
        goToStep(3);
    } else {
        alert(data.message || 'Failed to get recommendations.');
    }
}

// ─── Render 3 categories ─────────────────────────────────────────────────────
function renderV7Categories(data) {
    const container = document.getElementById('recommendations-container');
    if (!container) return;

    const { load_analysis, categories, total_options } = data;

    const categoryColors = {
        'traditional':      { bg: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', icon: '🔧', color: '#667eea', name: 'Traditional' },
        'maintenance_free': { bg: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', icon: '💧', color: '#f093fb', name: 'Maintenance Free' },
        'premium_bms':      { bg: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', icon: '⚡', color: '#4facfe', name: 'Premium BMS' }
    };

    // Collect unique voltage classes from all options across categories
    const voltageClasses = new Set();
    categories.forEach(cat => {
        if (cat.options) {
            cat.options.forEach(opt => {
                if (opt.inverter?.voltage_class) voltageClasses.add(opt.inverter.voltage_class);
            });
        }
    });
    const voltageDisplay = voltageClasses.size > 0 
        ? [...voltageClasses].sort((a,b) => parseInt(a) - parseInt(b)).join(' / ')
        : (load_analysis.voltage_class || 'N/A');

    let html = `
        <!-- Load Summary Bar with Animated Background -->
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color:#fff;border-radius:20px;padding:24px 32px;
                    display:flex;flex-wrap:wrap;gap:24px;justify-content:space-between;
                    align-items:center;margin-bottom:32px;
                    box-shadow: 0 10px 40px rgba(102, 126, 234, 0.3);
                    position: relative;
                    overflow: hidden;">
            <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0;
                        background: repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.03) 10px, rgba(255,255,255,0.03) 20px);
                        animation: slideBackground 20s linear infinite;"></div>
            <div style="position: relative; z-index: 1;">
                <div style="font-size:13px;opacity:.8;margin-bottom:6px;font-weight:600;">Total Load</div>
                <div style="font-size:28px;font-weight:900;">${load_analysis.peak_load_watts.toLocaleString()}W</div>
            </div>
            <div style="position: relative; z-index: 1;">
                <div style="font-size:13px;opacity:.8;margin-bottom:6px;font-weight:600;">Daily Energy</div>
                <div style="font-size:28px;font-weight:900;">${load_analysis.daily_energy_kwh} kWh</div>
            </div>
            <div style="position: relative; z-index: 1;">
                <div style="font-size:13px;opacity:.8;margin-bottom:6px;font-weight:600;">System Voltages</div>
                <div style="font-size:${voltageClasses.size > 2 ? '20' : '28'}px;font-weight:900;">${voltageDisplay}</div>
            </div>
            <div style="position: relative; z-index: 1;">
                <div style="font-size:13px;opacity:.8;margin-bottom:6px;font-weight:600;">Options Found</div>
                <div style="font-size:28px;font-weight:900;">${total_options}</div>
            </div>
            <div style="position: relative; z-index: 1;">
                <div style="font-size:13px;opacity:.8;margin-bottom:6px;font-weight:600;">Backup Target</div>
                <div style="font-size:28px;font-weight:900;">${load_analysis.backup_hours_requested}h</div>
            </div>
        </div>
        
        <!-- Quick Navigation -->
        <div style="display: flex; gap: 16px; margin-bottom: 32px; flex-wrap: wrap; justify-content: center;">
            ${categories.map((cat, idx) => {
                const style = categoryColors[cat.category_id] || categoryColors['traditional'];
                return `
                    <button onclick="document.getElementById('category-${idx}').scrollIntoView({behavior:'smooth', block:'start'})"
                            style="background: ${style.bg};
                                   color: white;
                                   border: none;
                                   padding: 14px 28px;
                                   border-radius: 12px;
                                   font-weight: 700;
                                   font-size: 15px;
                                   cursor: pointer;
                                   box-shadow: 0 4px 16px rgba(0,0,0,0.15);
                                   transition: all 0.3s;
                                   display: flex;
                                   align-items: center;
                                   gap: 8px;"
                            onmouseenter="this.style.transform='translateY(-3px)';this.style.boxShadow='0 6px 20px rgba(0,0,0,0.2)'"
                            onmouseleave="this.style.transform='';this.style.boxShadow='0 4px 16px rgba(0,0,0,0.15)'">
                        <span style="font-size: 20px;">${style.icon}</span>
                        Jump to ${style.name}
                    </button>
                `;
            }).join('')}
        </div>
    `;

    // Add CSS animation
    html += `
        <style>
            @keyframes slideBackground {
                0% { transform: translateX(0); }
                100% { transform: translateX(50px); }
            }
        </style>
    `;

    // Render each category
    categories.forEach((cat, catIdx) => {
        const style = categoryColors[cat.category_id] || categoryColors['traditional'];

        html += `
        <div id="category-${catIdx}" style="background: white;
                    border-radius: 24px;
                    padding: 0;
                    margin-bottom: 40px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
                    overflow: hidden;
                    border: 3px solid transparent;
                    background-clip: padding-box;">
            <!-- Category header with animated gradient -->
            <div style="background: ${style.bg};
                        padding: 32px 28px;
                        text-align: center;
                        position: relative;
                        overflow: hidden;">
                <div style="position: absolute; top: -50%; left: -50%; width: 200%; height: 200%;
                            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
                            animation: rotate 20s linear infinite;"></div>
                <div style="position: relative; z-index: 1;">
                    <div style="font-size:48px;margin-bottom:12px;animation: float 3s ease-in-out infinite;">
                        ${style.icon}
                    </div>
                    <div style="font-size:32px;font-weight:900;color:#fff;margin-bottom:8px;text-shadow: 0 2px 10px rgba(0,0,0,0.2);">
                        ${cat.category_name}
                    </div>
                    <div style="font-size:16px;color:rgba(255,255,255,.95);margin-bottom:12px;font-weight:500;">
                        ${cat.category_description}
                    </div>
                    <div style="display:inline-flex;gap:12px;flex-wrap:wrap;justify-content:center;
                                font-size:13px;color:rgba(255,255,255,.9);background:rgba(255,255,255,0.15);
                                padding:10px 20px;border-radius:20px;backdrop-filter:blur(10px);">
                        <span>🔌 <strong>Inverter:</strong> ${cat.inverter_type}</span>
                        <span>🔋 <strong>Battery:</strong> ${cat.battery_types}</span>
                        <span>✅ <strong>Best for:</strong> ${cat.best_for}</span>
                    </div>
                </div>
            </div>`;

        if (!cat.has_options) {
            // Empty state
            html += `
            <div style="padding: 48px 32px; text-align:center;">
                <div style="font-size:64px;margin-bottom:16px;opacity:0.5;">❌</div>
                <h3 style="font-size:24px;font-weight:700;color:#374151;margin-bottom:8px;">No Options Available</h3>
                <p style="color:#6B7280;font-size:16px;">${cat.empty_message}</p>
            </div>`;
        } else {
            // Options grid with better spacing
            html += `<div style="padding: 32px 24px; background: #F8FAFC;">
                        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:24px;">`;

            cat.options.forEach((opt, optIdx) => {
                const globalIdx = (catIdx * 100) + optIdx;
                html += renderOptionCard(opt, globalIdx, catIdx, style.color);
            });

            html += `</div></div>`;
        }

        html += `</div>`; // close category
    });

    html += `
        <style>
            @keyframes rotate {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            @keyframes float {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-10px); }
            }
        </style>
    `;

    html += `
        <div style="text-align:center;margin-top:32px;">
            <button onclick="goToStep(2)" class="btn btn-secondary" style="padding:14px 32px;font-size:16px;">
                ← Back to Load Summary
            </button>
        </div>`;

    container.innerHTML = html;

    // Build floating category FAB
    const fabCatNav = document.getElementById('fab-category-nav');
    if (fabCatNav) {
        fabCatNav.innerHTML = categories.map((cat, idx) => {
            const style = categoryColors[cat.category_id] || categoryColors['traditional'];
            return `<button class="fab-cat-btn" data-cat-idx="${idx}"
                        onclick="document.getElementById('category-${idx}').scrollIntoView({behavior:'smooth',block:'start'});
                                 document.querySelectorAll('.fab-cat-btn').forEach(b=>b.classList.remove('active'));
                                 this.classList.add('active');">
                <span class="fab-cat-icon">${style.icon}</span>
                ${style.name}
            </button>`;
        }).join('') + `
        <button class="fab-cat-btn" onclick="goToStep(2)" style="background:rgba(239,68,68,0.2);color:#FCA5A5;">
            ← Back
        </button>`;
        fabCatNav.style.display = 'flex';
    }

    // Animate cards if anime.js is available
    if (typeof anime === 'function' && !window.matchMedia('(prefers-reduced-motion:reduce)').matches) {
        anime({ targets: '.rec-option-card', scale: [0.95, 1], opacity: [0, 1],
                duration: 500, delay: anime.stagger(60), easing: 'easeOutBack' });
    }

    // Auto-highlight active category on scroll
    const observerOptions = { root: null, rootMargin: '-40% 0px', threshold: 0 };
    const catObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const idx = entry.target.id.replace('category-', '');
                document.querySelectorAll('.fab-cat-btn').forEach(b => b.classList.remove('active'));
                const btn = document.querySelector(`.fab-cat-btn[data-cat-idx="${idx}"]`);
                if (btn) btn.classList.add('active');
            }
        });
    }, observerOptions);
    categories.forEach((_, idx) => {
        const el = document.getElementById(`category-${idx}`);
        if (el) catObserver.observe(el);
    });
}

// ─── Single option card — REDESIGNED ─────────────────────────────────────────
function renderOptionCard(opt, globalIdx, catIdx, badgeColor) {
    const inv  = opt.inverter;
    const bat  = opt.battery_config;
    const pan  = opt.panel_config;
    const batt = bat.battery;

    const isRecommended = opt.tier_name === 'Recommended';
    const tierColor = isRecommended ? '#10B981' : (opt.tier_name === '+2KW Upgrade' ? '#3B82F6' : '#8B5CF6');
    const cardBorder = isRecommended ? `border:3px solid ${tierColor};` : 'border:2px solid #E2E8F0;';

    return `
    <div class="rec-option-card" style="background:#fff;border-radius:20px;overflow:hidden;
         box-shadow:0 8px 24px rgba(0,0,0,.1);${cardBorder}
         transition:all .3s ease;display:flex;flex-direction:column;position:relative;"
         onmouseenter="this.style.transform='translateY(-6px) scale(1.02)';this.style.boxShadow='0 12px 40px rgba(0,0,0,.18)'"
         onmouseleave="this.style.transform='';this.style.boxShadow='0 8px 24px rgba(0,0,0,.1)'">

        <!-- Tier badge with animation -->
        <div style="background:${tierColor};color:#fff;font-size:12px;font-weight:900;
                    letter-spacing:1px;padding:12px 16px;text-align:center;
                    position:relative;overflow:hidden;">
            <div style="position:absolute;top:0;left:-100%;width:100%;height:100%;
                        background:linear-gradient(90deg,transparent,rgba(255,255,255,0.3),transparent);
                        animation:shimmer 3s infinite;"></div>
            <div style="position:relative;z-index:1;">
                ${isRecommended ? '⭐ ' : ''}${opt.tier_name.toUpperCase()}${isRecommended ? ' — BEST VALUE' : ''}
            </div>
        </div>

        <!-- Card body with better spacing -->
        <div style="padding:20px;flex:1;display:flex;flex-direction:column;gap:14px;">
            <!-- Inverter -->
            <div style="display:flex;align-items:center;gap:12px;padding:14px;
                        background:linear-gradient(135deg,#F0F9FF,#E0F2FE);
                        border-radius:12px;border:1px solid #BAE6FD;">
                <div style="width:44px;height:44px;background:linear-gradient(135deg,#0EA5E9,#0284C7);
                            border-radius:10px;display:flex;align-items:center;justify-content:center;
                            font-size:22px;flex-shrink:0;box-shadow:0 4px 12px rgba(14,165,233,0.3);">⚡</div>
                <div style="flex:1;min-width:0;">
                    <div style="font-weight:800;color:#0C4A6E;font-size:14px;margin-bottom:4px;
                                overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"
                         title="${inv.name}">${inv.company_name ? inv.company_name + ' ' : ''}${inv.name}</div>
                    <div style="font-size:12px;color:#0369A1;font-weight:600;">
                        ${inv.voltage_class} · ${Number(inv.max_load_watts).toLocaleString()}W
                        ${inv.has_bms == 1 ? ' · <span style="color:#10B981;font-weight:800;">BMS ✓</span>' : ''}
                    </div>
                </div>
                <div style="text-align:right;flex-shrink:0;">
                    <div style="font-weight:900;color:#0C4A6E;font-size:15px;">₨${fmtNum(inv.price_usd)}</div>
                </div>
            </div>

            <!-- Battery -->
            <div style="display:flex;align-items:center;gap:12px;padding:14px;
                        background:linear-gradient(135deg,#F0FDF4,#DCFCE7);
                        border-radius:12px;border:1px solid #BBF7D0;">
                <div style="width:44px;height:44px;background:linear-gradient(135deg,#10B981,#059669);
                            border-radius:10px;display:flex;align-items:center;justify-content:center;
                            font-size:22px;flex-shrink:0;box-shadow:0 4px 12px rgba(16,185,129,0.3);">🔋</div>
                <div style="flex:1;min-width:0;">
                    <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:4px;">
                        <span style="font-weight:800;color:#064E3B;font-size:14px;">
                            ${bat.quantity}× ${batt.capacity_ah}Ah
                        </span>
                        <span style="background:#A78BFA;color:#fff;padding:2px 8px;
                                     border-radius:10px;font-size:10px;font-weight:800;">
                            ${batt.battery_type}
                        </span>
                    </div>
                    <div style="font-size:11px;font-weight:700;color:#047857;margin-bottom:2px;">
                        🏢 ${batt.company_name || 'N/A'}
                    </div>
                    <div style="font-size:10px;color:#065F46;font-weight:600;">
                        ${bat.total_kwh || bat.usable_kwh}kWh · ${bat.backup_hours}h · ${bat.warranty_years}yr · ${bat.cycle_life} cycles
                    </div>
                </div>
                <div style="text-align:right;flex-shrink:0;">
                    <div style="font-weight:900;color:#064E3B;font-size:15px;">₨${fmtNum(bat.total_cost)}</div>
                </div>
            </div>

            <!-- Panel -->
            ${pan ? `
            <div style="display:flex;align-items:center;gap:12px;padding:14px;
                        background:linear-gradient(135deg,#FFFBEB,#FEF3C7);
                        border-radius:12px;border:1px solid #FDE68A;">
                <div style="width:44px;height:44px;background:linear-gradient(135deg,#F59E0B,#D97706);
                            border-radius:10px;display:flex;align-items:center;justify-content:center;
                            font-size:22px;flex-shrink:0;box-shadow:0 4px 12px rgba(245,158,11,0.3);">☀️</div>
                <div style="flex:1;min-width:0;">
                    <div style="font-weight:800;color:#78350F;font-size:14px;margin-bottom:4px;">
                        ${pan.quantity}× ${pan.panel.watt_peak}W = ${pan.total_kwp}kWp
                    </div>
                    <div style="font-size:10px;color:#92400E;font-weight:600;">
                        ${pan.wiring} · VDC: ${pan.vdc_used}V/${pan.vdc_limit}V
                        ${pan.within_vdc ? ' <span style="color:#10B981;">✅</span>' : ' <span style="color:#EF4444;">⚠️</span>'}
                    </div>
                </div>
                <div style="text-align:right;flex-shrink:0;">
                    <div style="font-weight:900;color:#78350F;font-size:15px;">₨${fmtNum(pan.total_cost)}</div>
                </div>
            </div>` : ''}

            <!-- Stats row with better design -->
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:6px;">
                <div style="background:linear-gradient(135deg,#ECFDF5,#D1FAE5);border-radius:12px;
                            padding:12px 8px;text-align:center;border:2px solid #A7F3D0;">
                    <div style="font-size:20px;font-weight:900;color:#047857;line-height:1;">${bat.backup_hours}h</div>
                    <div style="font-size:10px;color:#065F46;font-weight:700;margin-top:4px;">BACKUP</div>
                </div>
                <div style="background:linear-gradient(135deg,#FEF3C7,#FDE68A);border-radius:12px;
                            padding:12px 8px;text-align:center;border:2px solid #FCD34D;">
                    <div style="font-size:20px;font-weight:900;color:#92400E;line-height:1;">${bat.warranty_years}yr</div>
                    <div style="font-size:10px;color:#78350F;font-weight:700;margin-top:4px;">WARRANTY</div>
                </div>
                <div style="background:linear-gradient(135deg,#F5F3FF,#EDE9FE);border-radius:12px;
                            padding:12px 8px;text-align:center;border:2px solid #DDD6FE;">
                    <div style="font-size:20px;font-weight:900;color:#6D28D9;line-height:1;">${bat.dod_percent}%</div>
                    <div style="font-size:10px;color:#5B21B6;font-weight:700;margin-top:4px;">DOD</div>
                </div>
            </div>
        </div>

        <!-- Footer — NO OVERLAP, proper spacing -->
        <div style="background:linear-gradient(180deg,#F8FAFC,#F1F5F9);padding:20px;
                    border-top:3px solid #E2E8F0;display:flex;flex-direction:column;gap:14px;">
            <div style="display:flex;align-items:center;justify-content:space-between;">
                <div>
                    <div style="font-size:11px;color:#64748B;font-weight:700;text-transform:uppercase;
                                letter-spacing:0.5px;margin-bottom:4px;">Total System Cost</div>
                    <div style="font-size:26px;font-weight:900;color:#059669;line-height:1;">
                        ₨${fmtNum(opt.total_cost)}
                    </div>
                </div>
            </div>
            <button
                class="select-option-btn"
                id="select-btn-${catIdx}-${globalIdx}"
                onclick="selectV7Option(${catIdx}, ${globalIdx}); return false;"
                style="background:linear-gradient(135deg,#0D3B6E,#1E40AF);color:#fff;border:none;
                       padding:14px 24px;border-radius:12px;font-weight:800;font-size:14px;
                       cursor:pointer;width:100%;
                       transition:all .2s ease;box-shadow:0 4px 16px rgba(13,59,110,.4);
                       position:relative;overflow:hidden;"
                onmouseenter="this.style.transform='scale(1.03)';this.style.boxShadow='0 6px 20px rgba(13,59,110,.5)'"
                onmouseleave="this.style.transform='';this.style.boxShadow='0 4px 16px rgba(13,59,110,.4)'">
                <span style="position:relative;z-index:1;">Select & Configure →</span>
                <div style="position:absolute;top:0;left:-100%;width:100%;height:100%;
                            background:linear-gradient(90deg,transparent,rgba(255,255,255,0.2),transparent);
                            animation:shimmer 3s infinite;"></div>
            </button>
        </div>
    </div>
    
    <style>
        @keyframes shimmer {
            0% { left: -100%; }
            100% { left: 200%; }
        }
    </style>`;
}

// ─── Handle option selection ──────────────────────────────────────────────────
function selectV7Option(catIdx, globalIdx) {
    const rec = window.appState?.recommendations;
    if (!rec || !rec.categories) { alert('No recommendation data. Please go back and try again.'); return; }

    const cat = rec.categories[catIdx];
    if (!cat) { alert('Invalid category.'); return; }

    // Find the option (globalIdx encodes catIdx*100 + optIdx)
    const optIdx = globalIdx - (catIdx * 100);
    const opt = cat.options[optIdx];
    if (!opt) { alert('Invalid option.'); return; }

    window.appState.selectedSystem = opt;
    window.appState.selectedCategory = cat;

    // CRITICAL: Save state before navigating
    if (typeof saveState === 'function') {
        saveState();
    }

    const configuratorContainer = document.getElementById('configurator-container');
    if (!configuratorContainer) { alert('Configurator container not found.'); return; }

    if (typeof initializeConfigurator === 'function') {
        // Build a system_options-compatible object for the configurator
        initializeConfigurator(opt, rec.load_analysis, rec.categories.flatMap(c => c.options));
    }

    if (typeof goToStep === 'function') goToStep(4);
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Keep old alias for compatibility
window.selectSystemOption    = (idx) => selectV7Option(0, idx);
window.selectSystemAndNavigate = (idx) => selectV7Option(0, idx);

// ─── Number formatter ────────────────────────────────────────────────────────
function formatNumber(num) {
    return Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
function fmtNum(num) { return formatNumber(num); }

// ─── Init ────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', setupBackupHoursSlider);
