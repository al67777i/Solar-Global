/**
 * Cookie Consent Banner
 * Self-injecting script that displays a cookie/terms consent banner
 * Cookie: sg_consent=1 (365-day expiry)
 */
(function () {
    'use strict';

    var COOKIE_NAME = 'sg_consent';
    var COOKIE_DAYS = 365;

    function getCookie(name) {
        var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? match[2] : null;
    }

    function setCookie(name, value, days) {
        var expires = new Date(Date.now() + days * 864e5).toUTCString();
        document.cookie = name + '=' + value + '; expires=' + expires + '; path=/; SameSite=Lax';
    }

    function getBaseUrl() {
        return window.BASE_URL || '/solarglobal/';
    }

    function injectStyles() {
        var css = [
            '.sg-consent-banner {',
            '  position: fixed;',
            '  bottom: 0;',
            '  left: 0;',
            '  right: 0;',
            '  background: rgba(15, 23, 42, 0.95);',
            '  backdrop-filter: blur(10px);',
            '  -webkit-backdrop-filter: blur(10px);',
            '  z-index: 9999;',
            '  padding: 16px 24px;',
            '  transform: translateY(100%);',
            '  transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);',
            '}',
            '.sg-consent-banner.sg-visible {',
            '  transform: translateY(0);',
            '}',
            '.sg-consent-banner.sg-hiding {',
            '  transform: translateY(100%);',
            '}',
            '.sg-consent-inner {',
            '  max-width: 1200px;',
            '  margin: 0 auto;',
            '  display: flex;',
            '  align-items: center;',
            '  justify-content: space-between;',
            '  gap: 16px;',
            '}',
            '.sg-consent-text {',
            '  color: #ffffff;',
            '  font-size: 0.875rem;',
            '  line-height: 1.5;',
            '  margin: 0;',
            '}',
            '.sg-consent-text a {',
            '  color: #F59E0B;',
            '  text-decoration: none;',
            '  transition: text-decoration 0.2s;',
            '}',
            '.sg-consent-text a:hover {',
            '  text-decoration: underline;',
            '}',
            '.sg-consent-btn {',
            '  background: #F59E0B;',
            '  color: #1a1a2e;',
            '  border: none;',
            '  padding: 10px 24px;',
            '  border-radius: 6px;',
            '  font-size: 0.875rem;',
            '  font-weight: 700;',
            '  cursor: pointer;',
            '  white-space: nowrap;',
            '  transition: background 0.2s, transform 0.2s;',
            '}',
            '.sg-consent-btn:hover {',
            '  background: #d97706;',
            '  transform: scale(1.03);',
            '}',
            '@media (max-width: 600px) {',
            '  .sg-consent-inner {',
            '    flex-direction: column;',
            '    text-align: center;',
            '  }',
            '  .sg-consent-btn {',
            '    width: 100%;',
            '  }',
            '}'
        ].join('\n');

        var style = document.createElement('style');
        style.textContent = css;
        document.head.appendChild(style);
    }

    function createBanner() {
        var baseUrl = getBaseUrl();
        var siteName = document.title || 'this site';

        var banner = document.createElement('div');
        banner.className = 'sg-consent-banner';
        banner.innerHTML =
            '<div class="sg-consent-inner">' +
            '  <p class="sg-consent-text">By using ' + siteName + ', you agree to our ' +
            '    <a href="' + baseUrl + 'terms.php">Terms of Service</a> and ' +
            '    <a href="' + baseUrl + 'privacy-policy.php">Privacy Policy</a>.' +
            '  </p>' +
            '  <button class="sg-consent-btn" type="button">I Agree</button>' +
            '</div>';

        document.body.appendChild(banner);

        // Trigger slide-up after a frame so the transition fires
        requestAnimationFrame(function () {
            requestAnimationFrame(function () {
                banner.classList.add('sg-visible');
            });
        });

        // Handle dismiss
        banner.querySelector('.sg-consent-btn').addEventListener('click', function () {
            setCookie(COOKIE_NAME, '1', COOKIE_DAYS);
            banner.classList.remove('sg-visible');
            banner.classList.add('sg-hiding');
            banner.addEventListener('transitionend', function () {
                banner.parentNode.removeChild(banner);
            }, { once: true });
        });
    }

    function init() {
        if (getCookie(COOKIE_NAME) === '1') {
            return;
        }
        injectStyles();
        createBanner();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
