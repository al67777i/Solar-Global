<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = getDB();
$pageTitle = 'Countries';
$message = '';
$error = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid CSRF token.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'toggle_support') {
            $id = intval($_POST['id'] ?? 0);
            $db->prepare("UPDATE countries SET is_supported = NOT is_supported WHERE id = ?")->execute([$id]);
            $message = 'Country support status updated.';
        } elseif ($action === 'remove_flag_icon') {
            $id = intval($_POST['id'] ?? 0);
            // Get current icon to delete file
            $stmt = $db->prepare("SELECT flag_icon, name FROM countries WHERE id = ?");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if ($row && !empty($row['flag_icon'])) {
                $file_path = __DIR__ . '/../' . $row['flag_icon'];
                if (file_exists($file_path)) @unlink($file_path);
                $db->prepare("UPDATE countries SET flag_icon = NULL WHERE id = ?")->execute([$id]);
                $message = "Flag icon removed for " . htmlspecialchars($row['name']) . ".";
            }
        } elseif ($action === 'add' || $action === 'edit') {
            $id = intval($_POST['id'] ?? 0);
            $code = strtoupper(trim($_POST['code'] ?? ''));
            $name = trim($_POST['name'] ?? '');
            $currencyCode = strtoupper(trim($_POST['currency_code'] ?? ''));
            $currencySymbol = trim($_POST['currency_symbol'] ?? '');
            $gridVoltage = intval($_POST['grid_voltage'] ?? 230);
            $gridFrequency = intval($_POST['grid_frequency'] ?? 50);
            $electricityRate = floatval($_POST['electricity_rate_kwh'] ?? 0);
            $netMetering = isset($_POST['net_metering_available']) ? 1 : 0;
            $taxRate = floatval($_POST['tax_rate_pct'] ?? 0);
            $isSupported = isset($_POST['is_supported']) ? 1 : 0;
            $flagEmoji = trim($_POST['flag_emoji'] ?? '');

            // Handle flag icon upload
            $flagIconPath = null;
            $hasNewUpload = false;
            if (!empty($_FILES['flag_icon_file']['name']) && $_FILES['flag_icon_file']['error'] === UPLOAD_ERR_OK) {
                $allowed = ['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml', 'image/gif'];
                $ftype = $_FILES['flag_icon_file']['type'];
                $fsize = $_FILES['flag_icon_file']['size'];
                if (!in_array($ftype, $allowed)) {
                    $error = 'Flag icon must be PNG, JPG, WebP, SVG, or GIF.';
                } elseif ($fsize > 512000) { // 500KB max
                    $error = 'Flag icon must be under 500KB.';
                } else {
                    $ext = match($ftype) {
                        'image/png' => 'png',
                        'image/jpeg' => 'jpg',
                        'image/webp' => 'webp',
                        'image/svg+xml' => 'svg',
                        'image/gif' => 'gif',
                        default => 'png'
                    };
                    $upload_dir = __DIR__ . '/../uploads/flags/';
                    $cc = $action === 'add' ? $code : '';
                    if ($action === 'edit' && $id > 0) {
                        $stmt = $db->prepare("SELECT code FROM countries WHERE id = ?");
                        $stmt->execute([$id]);
                        $cc = $stmt->fetchColumn() ?: 'flag';
                    }
                    $filename = strtolower($cc) . '_' . time() . '.' . $ext;
                    if (move_uploaded_file($_FILES['flag_icon_file']['tmp_name'], $upload_dir . $filename)) {
                        $flagIconPath = 'uploads/flags/' . $filename;
                        $hasNewUpload = true;
                        // Delete old icon if editing
                        if ($action === 'edit' && $id > 0) {
                            $stmt = $db->prepare("SELECT flag_icon FROM countries WHERE id = ?");
                            $stmt->execute([$id]);
                            $old = $stmt->fetchColumn();
                            if ($old && file_exists(__DIR__ . '/../' . $old)) @unlink(__DIR__ . '/../' . $old);
                        }
                    } else {
                        $error = 'Failed to upload flag icon.';
                    }
                }
            }

            if (empty($error)) {
                if ($action === 'add') {
                    if (empty($code) || empty($name)) {
                        $error = 'Country code and name are required.';
                    } elseif (strlen($code) !== 2) {
                        $error = 'Country code must be exactly 2 characters (ISO 3166-1 alpha-2).';
                    } else {
                        $stmt = $db->prepare("SELECT id FROM countries WHERE code = ?");
                        $stmt->execute([$code]);
                        if ($stmt->fetch()) {
                            $error = "Country with code '$code' already exists.";
                        } else {
                            $stmt = $db->prepare("INSERT INTO countries (code, name, currency_code, currency_symbol, grid_voltage, grid_frequency, electricity_rate_kwh, net_metering_available, tax_rate_pct, is_supported, flag_emoji, flag_icon) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                            $stmt->execute([$code, $name, $currencyCode, $currencySymbol, $gridVoltage, $gridFrequency, $electricityRate, $netMetering, $taxRate, $isSupported, $flagEmoji, $flagIconPath]);
                            $message = "Country '$name' added successfully.";
                        }
                    }
                } else {
                    // Edit
                    if (empty($name) || $id === 0) {
                        $error = 'Country name is required.';
                    } else {
                        $iconSql = $hasNewUpload ? ', flag_icon = ?' : '';
                        $params = [$name, $currencyCode, $currencySymbol, $gridVoltage, $gridFrequency, $electricityRate, $netMetering, $taxRate, $isSupported, $flagEmoji];
                        if ($hasNewUpload) $params[] = $flagIconPath;
                        $params[] = $id;
                        $stmt = $db->prepare("UPDATE countries SET name = ?, currency_code = ?, currency_symbol = ?, grid_voltage = ?, grid_frequency = ?, electricity_rate_kwh = ?, net_metering_available = ?, tax_rate_pct = ?, is_supported = ?, flag_emoji = ?{$iconSql} WHERE id = ?");
                        $stmt->execute($params);
                        $message = "Country '$name' updated successfully.";
                    }
                }
            }
        }
    }
}

// Fetch all countries
$countries = $db->query("SELECT * FROM countries ORDER BY name ASC")->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<style>
    .countries-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .countries-header h2 { margin: 0; font-size: 18px; color: #1f2937; }
    .btn-add { background: #f59e0b; color: #fff; border: none; padding: 10px 20px; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; transition: background 0.2s; }
    .btn-add:hover { background: #d97706; }
    .countries-table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .countries-table th { text-align: left; padding: 12px 14px; background: #f9fafb; color: #6b7280; font-weight: 500; font-size: 12px; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 1px solid #e5e7eb; }
    .countries-table td { padding: 12px 14px; border-bottom: 1px solid #f3f4f6; font-size: 13px; color: #374151; vertical-align: middle; }
    .countries-table tr:hover td { background: #f9fafb; }
    .flag-cell { font-size: 22px; }
    .badge-supported { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; }
    .badge-yes { background: #d1fae5; color: #047857; }
    .badge-no { background: #fee2e2; color: #dc2626; }
    .btn-toggle { padding: 5px 12px; border-radius: 6px; border: 1px solid #d1d5db; background: #fff; font-size: 12px; cursor: pointer; transition: all 0.2s; }
    .btn-toggle:hover { background: #f3f4f6; }
    .btn-edit { padding: 5px 12px; border-radius: 6px; border: 1px solid #dbeafe; background: #eff6ff; color: #1d4ed8; font-size: 12px; cursor: pointer; transition: all 0.2s; }
    .btn-edit:hover { background: #dbeafe; }
    .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 14px; }
    .alert-success { background: #d1fae5; color: #065f46; border: 1px solid #6ee7b7; }
    .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }

    /* Modal */
    .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
    .modal-overlay.active { display: flex; }
    .modal-box { background: #fff; border-radius: 12px; padding: 28px; width: 100%; max-width: 560px; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
    .modal-box h3 { margin: 0 0 20px 0; font-size: 18px; color: #1f2937; }
    .modal-row { display: flex; gap: 12px; }
    .modal-row .form-group { flex: 1; }
    .form-group { margin-bottom: 14px; }
    .form-group label { display: block; font-weight: 500; font-size: 12px; color: #374151; margin-bottom: 4px; }
    .form-group input, .form-group select { width: 100%; padding: 8px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px; box-sizing: border-box; }
    .form-group input:focus, .form-group select:focus { outline: none; border-color: #f59e0b; box-shadow: 0 0 0 2px rgba(245,158,11,0.15); }
    .modal-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; }
    .btn-cancel { padding: 10px 20px; border-radius: 8px; border: 1px solid #d1d5db; background: #fff; font-size: 13px; cursor: pointer; }
    .btn-save { padding: 10px 20px; border-radius: 8px; border: none; background: #f59e0b; color: #fff; font-weight: 600; font-size: 13px; cursor: pointer; }
    .btn-save:hover { background: #d97706; }
    .checkbox-group { display: flex; align-items: center; gap: 6px; }
    .checkbox-group input[type="checkbox"] { width: auto; }
    .table-wrapper { overflow-x: auto; }
    .flag-upload-area { background: #F9FAFB; border: 1.5px dashed #D1D5DB; border-radius: 8px; padding: 12px; }
    .flag-upload-area input[type="file"] { font-size: 12px; }
    .btn-remove-flag { background: #FEE2E2; color: #DC2626; border: none; border-radius: 50%; width: 22px; height: 22px; font-size: 14px; cursor: pointer; vertical-align: middle; margin-left: 8px; line-height: 1; }
    .btn-remove-flag:hover { background: #FECACA; }
</style>

<?php if ($message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="countries-header">
    <h2>All Countries (<?= count($countries) ?>)</h2>
    <button class="btn-add" onclick="openAddModal()">+ Add Country</button>
</div>

<div class="table-wrapper">
    <table class="countries-table">
        <thead>
            <tr>
                <th>Flag</th>
                <th>Code</th>
                <th>Name</th>
                <th>Currency</th>
                <th>Grid</th>
                <th>Rate (kWh)</th>
                <th>Net Metering</th>
                <th>Tax %</th>
                <th>Supported</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($countries)): ?>
                <tr><td colspan="10" style="text-align:center; color:#9ca3af; padding:30px;">No countries found.</td></tr>
            <?php else: ?>
                <?php foreach ($countries as $c): ?>
                    <tr>
                        <td class="flag-cell"><?= get_country_flag($c, 28) ?></td>
                        <td><strong><?= htmlspecialchars($c['code']) ?></strong></td>
                        <td><?= htmlspecialchars($c['name']) ?></td>
                        <td><?= htmlspecialchars($c['currency_symbol'] ?? '') ?> <?= htmlspecialchars($c['currency_code'] ?? '') ?></td>
                        <td><?= intval($c['grid_voltage']) ?>V / <?= intval($c['grid_frequency']) ?>Hz</td>
                        <td><?= $c['electricity_rate_kwh'] !== null ? number_format($c['electricity_rate_kwh'], 3) : '-' ?></td>
                        <td><?= $c['net_metering_available'] ? '<span class="badge-supported badge-yes">Yes</span>' : '<span class="badge-supported badge-no">No</span>' ?></td>
                        <td><?= $c['tax_rate_pct'] !== null ? number_format($c['tax_rate_pct'], 1) . '%' : '-' ?></td>
                        <td>
                            <?php if ($c['is_supported']): ?>
                                <span class="badge-supported badge-yes">Active</span>
                            <?php else: ?>
                                <span class="badge-supported badge-no">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td style="white-space: nowrap;">
                            <form method="POST" style="display:inline;">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="toggle_support">
                                <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                <button type="submit" class="btn-toggle" title="Toggle support"><?= $c['is_supported'] ? 'Disable' : 'Enable' ?></button>
                            </form>
                            <button class="btn-edit" onclick='openEditModal(<?= json_encode($c, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>Edit</button>
                            <?php if (!empty($c['flag_icon'])): ?>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Remove flag icon?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="remove_flag_icon">
                                <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                <button type="submit" class="btn-toggle" title="Remove flag icon" style="color:#DC2626;">✕ Icon</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Add Country Modal -->
<div class="modal-overlay" id="add-modal">
    <div class="modal-box">
        <h3 id="modal-title">Add New Country</h3>
        <form method="POST" id="country-form" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" id="form-action" value="add">
            <input type="hidden" name="id" id="form-id" value="">

            <div class="modal-row">
                <div class="form-group" id="code-group">
                    <label>Country Code (ISO 2-letter)</label>
                    <input type="text" name="code" id="form-code" maxlength="2" required placeholder="US">
                </div>
                <div class="form-group">
                    <label>Flag Emoji (optional)</label>
                    <input type="text" name="flag_emoji" id="form-flag" maxlength="10" placeholder="🇺🇸">
                </div>
            </div>

            <div class="form-group">
                <label>Flag Icon Image (recommended — PNG/SVG/WebP, max 500KB)</label>
                <div class="flag-upload-area" id="flag-upload-area">
                    <div id="flag-preview-box" style="display:none; margin-bottom:8px;">
                        <img id="flag-preview-img" src="" alt="Flag preview" style="height:32px; border-radius:3px; border:1px solid #E2E8F0;">
                        <button type="button" class="btn-remove-flag" id="btn-remove-flag" onclick="clearFlagUpload()" title="Remove">&times;</button>
                    </div>
                    <input type="file" name="flag_icon_file" id="form-flag-icon" accept="image/png,image/jpeg,image/webp,image/svg+xml,image/gif" onchange="previewFlagIcon(this)">
                    <small style="color:#94A3B8; display:block; margin-top:4px;">Upload a flag image — shown instead of emoji on all platforms</small>
                </div>
            </div>

            <div class="form-group">
                <label>Country Name</label>
                <input type="text" name="name" id="form-name" required placeholder="United States">
            </div>

            <div class="modal-row">
                <div class="form-group">
                    <label>Currency Code</label>
                    <input type="text" name="currency_code" id="form-currency-code" maxlength="3" placeholder="USD">
                </div>
                <div class="form-group">
                    <label>Currency Symbol</label>
                    <input type="text" name="currency_symbol" id="form-currency-symbol" maxlength="5" placeholder="$">
                </div>
            </div>

            <div class="modal-row">
                <div class="form-group">
                    <label>Grid Voltage</label>
                    <input type="number" name="grid_voltage" id="form-voltage" value="230" min="100" max="400">
                </div>
                <div class="form-group">
                    <label>Grid Frequency (Hz)</label>
                    <input type="number" name="grid_frequency" id="form-frequency" value="50" min="40" max="70">
                </div>
            </div>

            <div class="modal-row">
                <div class="form-group">
                    <label>Electricity Rate (per kWh)</label>
                    <input type="number" name="electricity_rate_kwh" id="form-rate" step="0.001" min="0" placeholder="0.120">
                </div>
                <div class="form-group">
                    <label>Tax Rate (%)</label>
                    <input type="number" name="tax_rate_pct" id="form-tax" step="0.1" min="0" max="100" placeholder="15.0">
                </div>
            </div>

            <div class="modal-row">
                <div class="form-group">
                    <div class="checkbox-group">
                        <input type="checkbox" name="net_metering_available" id="form-net-metering" value="1">
                        <label for="form-net-metering" style="margin-bottom:0;">Net Metering Available</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="checkbox-group">
                        <input type="checkbox" name="is_supported" id="form-supported" value="1" checked>
                        <label for="form-supported" style="margin-bottom:0;">Supported / Active</label>
                    </div>
                </div>
            </div>

            <div class="modal-actions">
                <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn-save" id="modal-save-btn">Add Country</button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('modal-title').textContent = 'Add New Country';
        document.getElementById('form-action').value = 'add';
        document.getElementById('form-id').value = '';
        document.getElementById('form-code').value = '';
        document.getElementById('form-code').disabled = false;
        document.getElementById('code-group').style.display = '';
        document.getElementById('form-flag').value = '';
        document.getElementById('form-name').value = '';
        document.getElementById('form-currency-code').value = '';
        document.getElementById('form-currency-symbol').value = '';
        document.getElementById('form-voltage').value = '230';
        document.getElementById('form-frequency').value = '50';
        document.getElementById('form-rate').value = '';
        document.getElementById('form-tax').value = '';
        document.getElementById('form-net-metering').checked = false;
        document.getElementById('form-supported').checked = true;
        document.getElementById('modal-save-btn').textContent = 'Add Country';
        clearFlagUpload();
        document.getElementById('add-modal').classList.add('active');
    }

    function openEditModal(data) {
        document.getElementById('modal-title').textContent = 'Edit Country: ' + data.name;
        document.getElementById('form-action').value = 'edit';
        document.getElementById('form-id').value = data.id;
        document.getElementById('form-code').value = data.code;
        document.getElementById('form-code').disabled = true;
        document.getElementById('form-flag').value = data.flag_emoji || '';
        document.getElementById('form-name').value = data.name || '';
        document.getElementById('form-currency-code').value = data.currency_code || '';
        document.getElementById('form-currency-symbol').value = data.currency_symbol || '';
        document.getElementById('form-voltage').value = data.grid_voltage || 230;
        document.getElementById('form-frequency').value = data.grid_frequency || 50;
        document.getElementById('form-rate').value = data.electricity_rate_kwh || '';
        document.getElementById('form-tax').value = data.tax_rate_pct || '';
        document.getElementById('form-net-metering').checked = !!parseInt(data.net_metering_available);
        document.getElementById('form-supported').checked = !!parseInt(data.is_supported);
        document.getElementById('modal-save-btn').textContent = 'Save Changes';

        // Show existing flag icon preview
        clearFlagUpload();
        if (data.flag_icon) {
            document.getElementById('flag-preview-img').src = '/solarglobal/' + data.flag_icon;
            document.getElementById('flag-preview-box').style.display = 'flex';
            document.getElementById('flag-preview-box').style.alignItems = 'center';
        }

        document.getElementById('add-modal').classList.add('active');
    }

    function previewFlagIcon(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('flag-preview-img').src = e.target.result;
                document.getElementById('flag-preview-box').style.display = 'flex';
                document.getElementById('flag-preview-box').style.alignItems = 'center';
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    function clearFlagUpload() {
        document.getElementById('flag-preview-box').style.display = 'none';
        document.getElementById('flag-preview-img').src = '';
        document.getElementById('form-flag-icon').value = '';
    }

    function closeModal() {
        document.getElementById('add-modal').classList.remove('active');
    }

    // Close modal on overlay click
    document.getElementById('add-modal').addEventListener('click', function(e) {
        if (e.target === this) closeModal();
    });

    // Close on Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeModal();
    });
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
