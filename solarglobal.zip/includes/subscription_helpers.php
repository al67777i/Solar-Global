<?php
/**
 * Subscription Helpers — Centralized subscription filtering for public queries
 *
 * Used by: stores.php, find-dealer.php, find-installer.php, recommender API, store.php
 * Ensures expired/unpaid dealers and installers are hidden from customers.
 */

/**
 * Get SQL WHERE fragment for filtering visible dealers in public queries.
 *
 * A dealer is visible when ALL of these are true:
 *   1. status IN ('active','approved')
 *   2. AND one of:
 *      a. subscription_status = 'active' AND (subscription_expires_at IS NULL OR subscription_expires_at > NOW())
 *      b. Within free trial period (subscription_status IN ('none','trial') AND created_at + trial_days > NOW())
 *      c. Within grace period (subscription_status = 'expired' AND grace_period_ends_at > NOW())
 *
 * @param string $alias  Table alias (default 'd')
 * @return string SQL WHERE fragment (without leading AND/WHERE)
 */
function get_dealer_subscription_filter(string $alias = 'd'): string {
    $trialEnabled = '0';
    $trialDays = 30;
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('dealer_free_trial_enabled','dealer_free_trial_days')");
        $stmt->execute();
        foreach ($stmt->fetchAll(PDO::FETCH_KEY_PAIR) as $k => $v) {
            if ($k === 'dealer_free_trial_enabled') $trialEnabled = $v;
            if ($k === 'dealer_free_trial_days') $trialDays = (int)$v;
        }
    } catch (Exception $e) {}

    $a = $alias;

    // Base: must be active/approved status
    $sql = "{$a}.status IN ('active','approved')";

    // Subscription check: paid active OR within trial OR within grace
    $sub_conditions = [];

    // a. Paid active subscription (not expired)
    $sub_conditions[] = "({$a}.subscription_status = 'active' AND ({$a}.subscription_expires_at IS NULL OR {$a}.subscription_expires_at > NOW()))";

    // b. Free trial (if enabled): account created within trial_days
    if ($trialEnabled === '1' && $trialDays > 0) {
        $sub_conditions[] = "({$a}.subscription_status IN ('none','trial') AND {$a}.created_at > DATE_SUB(NOW(), INTERVAL {$trialDays} DAY))";
    }

    // c. Grace period: expired but within grace window
    $sub_conditions[] = "({$a}.subscription_status = 'expired' AND {$a}.grace_period_ends_at IS NOT NULL AND {$a}.grace_period_ends_at > NOW())";

    $sql .= " AND (" . implode(" OR ", $sub_conditions) . ")";

    return $sql;
}

/**
 * Get SQL WHERE fragment for filtering visible installers in public queries.
 * Same logic as dealers but uses installer-specific settings.
 *
 * @param string $alias  Table alias (default 'i')
 * @return string SQL WHERE fragment
 */
function get_installer_subscription_filter(string $alias = 'i'): string {
    $trialEnabled = '0';
    $trialDays = 30;
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('installer_free_trial_enabled','installer_free_trial_days')");
        $stmt->execute();
        foreach ($stmt->fetchAll(PDO::FETCH_KEY_PAIR) as $k => $v) {
            if ($k === 'installer_free_trial_enabled') $trialEnabled = $v;
            if ($k === 'installer_free_trial_days') $trialDays = (int)$v;
        }
    } catch (Exception $e) {}

    $a = $alias;

    $sql = "{$a}.status IN ('active','approved')";

    $sub_conditions = [];
    $sub_conditions[] = "({$a}.subscription_status = 'active' AND ({$a}.subscription_expires_at IS NULL OR {$a}.subscription_expires_at > NOW()))";

    if ($trialEnabled === '1' && $trialDays > 0) {
        $sub_conditions[] = "({$a}.subscription_status IN ('none','trial') AND {$a}.created_at > DATE_SUB(NOW(), INTERVAL {$trialDays} DAY))";
    }

    $sub_conditions[] = "({$a}.subscription_status = 'expired' AND {$a}.grace_period_ends_at IS NOT NULL AND {$a}.grace_period_ends_at > NOW())";

    $sql .= " AND (" . implode(" OR ", $sub_conditions) . ")";

    return $sql;
}

/**
 * Check if a specific dealer/installer has active subscription (for individual checks).
 *
 * @param string $type  'dealer' or 'installer'
 * @param int    $id    Entity ID
 * @return array ['active' => bool, 'reason' => string, 'grace' => bool, 'grace_days_left' => int, 'trial' => bool, 'trial_days_left' => int]
 */
function check_subscription(string $type, int $id): array {
    $default = ['active' => false, 'reason' => 'not_found', 'grace' => false, 'grace_days_left' => 0, 'trial' => false, 'trial_days_left' => 0];

    $table = $type === 'dealer' ? 'dealers' : 'installers';
    $trialKey = $type === 'dealer' ? 'dealer_free_trial_enabled' : 'installer_free_trial_enabled';
    $trialDaysKey = $type === 'dealer' ? 'dealer_free_trial_days' : 'installer_free_trial_days';

    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT status, subscription_status, subscription_expires_at, grace_period_ends_at, created_at FROM {$table} WHERE id = ?");
        $stmt->execute([$id]);
        $entity = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return $default;
    }

    if (!$entity) return $default;

    // Suspended/rejected = never active
    if (in_array($entity['status'], ['suspended', 'rejected'])) {
        return array_merge($default, ['reason' => 'suspended']);
    }

    $subStatus = $entity['subscription_status'] ?? 'none';
    $now = time();

    // 1. Paid active subscription
    if ($subStatus === 'active') {
        $expires = $entity['subscription_expires_at'] ?? null;
        if (!$expires || strtotime($expires) > $now) {
            return ['active' => true, 'reason' => 'paid', 'grace' => false, 'grace_days_left' => 0, 'trial' => false, 'trial_days_left' => 0];
        }
        // Expired but status not yet updated
    }

    // 2. Grace period check
    $graceEnd = $entity['grace_period_ends_at'] ?? null;
    if ($graceEnd && strtotime($graceEnd) > $now && in_array($subStatus, ['expired', 'past_due', 'canceled'])) {
        $graceDaysLeft = (int)ceil((strtotime($graceEnd) - $now) / 86400);
        return ['active' => false, 'reason' => 'grace_period', 'grace' => true, 'grace_days_left' => $graceDaysLeft, 'trial' => false, 'trial_days_left' => 0];
    }

    // 3. Free trial check
    try {
        $db = getDB();
        $trialEnabled = '0';
        $trialDays = 30;
        $stmtS = $db->prepare("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN (?, ?)");
        $stmtS->execute([$trialKey, $trialDaysKey]);
        foreach ($stmtS->fetchAll(PDO::FETCH_KEY_PAIR) as $k => $v) {
            if ($k === $trialKey) $trialEnabled = $v;
            if ($k === $trialDaysKey) $trialDays = (int)$v;
        }

        if ($trialEnabled === '1' && $trialDays > 0) {
            $createdAt = strtotime($entity['created_at']);
            $trialEnd = $createdAt + ($trialDays * 86400);
            if ($now < $trialEnd) {
                $daysLeft = (int)ceil(($trialEnd - $now) / 86400);
                return ['active' => true, 'reason' => 'free_trial', 'grace' => false, 'grace_days_left' => 0, 'trial' => true, 'trial_days_left' => $daysLeft];
            }
        }
    } catch (Exception $e) {}

    // 4. No active subscription
    return array_merge($default, ['reason' => 'no_subscription']);
}
