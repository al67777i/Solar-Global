<?php
/**
 * Installer Orders - Manage installation requests from customers
 * Accept, quote, start, complete, or cancel requests
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/installer_auth.php';

set_security_headers();
require_installer_login();
require_installer_subscription();

$installer = get_installer_profile();
$db = getDB();
$success = '';
$error = '';

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';
    $order_id = (int)($_POST['order_id'] ?? 0);

    // Verify ownership
    $stmt = $db->prepare("SELECT * FROM installer_orders WHERE id = ? AND installer_id = ?");
    $stmt->execute([$order_id, $installer['id']]);
    $order = $stmt->fetch();

    if (!$order) {
        $error = 'Order not found.';
    } else {
        // Transition matrix
        $transitions = [
            'accept' => ['from' => 'requested', 'to' => 'accepted', 'field' => 'accepted_at'],
            'start' => ['from' => 'accepted', 'to' => 'in_progress', 'field' => 'started_at'],
            'complete' => ['from' => 'in_progress', 'to' => 'completed', 'field' => 'completed_at'],
            'cancel' => ['from' => ['requested', 'accepted'], 'to' => 'cancelled', 'field' => 'cancelled_at'],
        ];

        if ($action === 'accept') {
            $estimated_cost = floatval($_POST['estimated_cost'] ?? 0);
            $installer_notes = trim($_POST['installer_notes'] ?? '');

            if ($order['status'] !== 'requested') {
                $error = 'Can only accept requests with "requested" status.';
            } elseif ($estimated_cost <= 0) {
                $error = 'Please provide a cost estimate.';
            } else {
                $stmt = $db->prepare("UPDATE installer_orders SET status = 'accepted', estimated_cost = ?, installer_notes = ?, accepted_at = NOW() WHERE id = ?");
                $stmt->execute([$estimated_cost, $installer_notes, $order_id]);
                $success = 'Request accepted! Customer has been notified of your quote.';
            }
        } elseif ($action === 'start') {
            if ($order['status'] !== 'accepted') {
                $error = 'Can only start accepted orders.';
            } else {
                $db->prepare("UPDATE installer_orders SET status = 'in_progress', started_at = NOW() WHERE id = ?")->execute([$order_id]);
                $success = 'Installation marked as in progress.';
            }
        } elseif ($action === 'complete') {
            $total_amount = floatval($_POST['total_amount'] ?? 0);
            if ($order['status'] !== 'in_progress') {
                $error = 'Can only complete orders that are in progress.';
            } elseif ($total_amount <= 0) {
                $error = 'Please enter the final amount.';
            } else {
                $db->prepare("UPDATE installer_orders SET status = 'completed', total_amount = ?, completed_at = NOW() WHERE id = ?")->execute([$total_amount, $order_id]);

                // Update installer's completed count
                try {
                    $count = $db->prepare("SELECT COUNT(*) FROM installer_orders WHERE installer_id = ? AND status = 'completed'");
                    $count->execute([$installer['id']]);
                    $completed_count = $count->fetchColumn();
                    $db->prepare("UPDATE installers SET completed_installations = ? WHERE id = ?")->execute([$completed_count, $installer['id']]);
                } catch (Exception $e) {}

                $success = 'Installation completed! Great work.';
            }
        } elseif ($action === 'cancel') {
            $cancel_reason = trim($_POST['cancel_reason'] ?? '');
            if (!in_array($order['status'], ['requested', 'accepted'])) {
                $error = 'Cannot cancel orders that are in progress or completed.';
            } else {
                $db->prepare("UPDATE installer_orders SET status = 'cancelled', cancel_reason = ?, cancelled_at = NOW() WHERE id = ?")->execute([$cancel_reason, $order_id]);
                $success = 'Order cancelled.';
            }
        }
    }
}

// Filters
$status_filter = $_GET['status'] ?? '';

// Count by status
$counts = ['all' => 0, 'requested' => 0, 'accepted' => 0, 'in_progress' => 0, 'completed' => 0, 'cancelled' => 0];
$stmt = $db->prepare("SELECT status, COUNT(*) as cnt FROM installer_orders WHERE installer_id = ? GROUP BY status");
$stmt->execute([$installer['id']]);
foreach ($stmt->fetchAll() as $r) {
    $counts[$r['status']] = (int)$r['cnt'];
    $counts['all'] += (int)$r['cnt'];
}

// Fetch orders
$where = "WHERE io.installer_id = ?";
$params = [$installer['id']];
if (in_array($status_filter, ['requested', 'accepted', 'in_progress', 'completed', 'cancelled'])) {
    $where .= " AND io.status = ?";
    $params[] = $status_filter;
}

$sql = "SELECT io.*, c.name as customer_name, c.email as customer_email, c.phone as customer_phone
        FROM installer_orders io
        LEFT JOIN customers c ON io.customer_id = c.id
        $where
        ORDER BY
            CASE io.status WHEN 'requested' THEN 1 WHEN 'accepted' THEN 2 WHEN 'in_progress' THEN 3 ELSE 4 END,
            io.created_at DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Portfolio count for badge
$portfolio_count = get_installer_portfolio_count();

// Review count
$stmt = $db->prepare("SELECT COUNT(*) FROM installer_reviews WHERE installer_id = ?");
$stmt->execute([$installer['id']]);
$review_count = (int)$stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders - <?= sanitize($installer['business_name']) ?> | <?= get_system_setting('site_name', 'SolarGlobal') ?> Installer</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 260px;
            background: #0F172A; color: white; z-index: 100;
            display: flex; flex-direction: column; transition: transform 0.3s;
        }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid #1E293B; }
        .sidebar-header h2 { font-size: 1.25rem; font-weight: 800; color: #F59E0B; }
        .sidebar-header p { font-size: 0.75rem; color: #94A3B8; margin-top: 2px; }
        .sidebar-nav { flex: 1; padding: 16px 12px; overflow-y: auto; }
        .nav-section { margin-bottom: 24px; }
        .nav-section-title { font-size: 0.6875rem; text-transform: uppercase; letter-spacing: 1px; color: #475569; padding: 0 12px; margin-bottom: 8px; font-weight: 600; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 8px; color: #CBD5E1; text-decoration: none; font-size: 0.875rem; font-weight: 500; transition: all 0.2s; }
        .nav-item:hover { background: #1E293B; color: white; }
        .nav-item.active { background: #D97706; color: white; }
        .nav-item .icon { font-size: 1.125rem; width: 24px; text-align: center; }
        .nav-item .badge { margin-left: auto; background: #DC2626; color: white; font-size: 0.6875rem; padding: 2px 7px; border-radius: 10px; font-weight: 700; }

        .sidebar-footer { padding: 16px 12px; border-top: 1px solid #1E293B; }
        .installer-info { display: flex; align-items: center; gap: 10px; padding: 8px; }
        .installer-avatar { width: 36px; height: 36px; border-radius: 8px; background: #334155; display: flex; align-items: center; justify-content: center; font-size: 1rem; overflow: hidden; }
        .installer-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .installer-meta .d-name { font-size: 0.8125rem; font-weight: 600; color: #E2E8F0; }
        .installer-meta .d-email { font-size: 0.6875rem; color: #64748B; }

        .main-content { margin-left: 260px; padding: 24px 32px; min-height: 100vh; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
        .top-bar h1 { font-size: 1.5rem; font-weight: 700; color: #1E293B; }
        .mobile-menu-btn { display: none; background: #0F172A; color: white; border: none; width: 40px; height: 40px; border-radius: 8px; font-size: 1.25rem; cursor: pointer; }

        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; }
        .alert-success { background: #DCFCE7; color: #166534; }
        .alert-error { background: #FEF2F2; color: #991B1B; }

        /* Tabs */
        .tabs { display: flex; gap: 4px; margin-bottom: 20px; background: white; border-radius: 10px; padding: 4px; box-shadow: 0 1px 4px rgba(0,0,0,0.05); overflow-x: auto; }
        .tab { padding: 8px 14px; text-align: center; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 0.75rem; color: #64748B; white-space: nowrap; }
        .tab.active { background: #D97706; color: white; }
        .tab:hover:not(.active) { background: #F1F5F9; }
        .tab .cnt { font-weight: 400; opacity: 0.7; }

        /* Order card */
        .order-card {
            background: white; border-radius: 12px; padding: 20px; margin-bottom: 14px;
            border: 2px solid #E2E8F0; transition: border-color 0.2s;
        }
        .order-card:hover { border-color: #CBD5E1; }
        .order-card.status-requested { border-left: 4px solid #F59E0B; }
        .order-card.status-accepted { border-left: 4px solid #3B82F6; }
        .order-card.status-in_progress { border-left: 4px solid #8B5CF6; }
        .order-card.status-completed { border-left: 4px solid #16A34A; }
        .order-card.status-cancelled { border-left: 4px solid #DC2626; }

        .oc-header { display: flex; justify-content: space-between; align-items: start; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; }
        .oc-customer { font-weight: 700; font-size: 1rem; color: #1E293B; }
        .oc-contact { font-size: 0.75rem; color: #64748B; }
        .oc-date { font-size: 0.6875rem; color: #94A3B8; }

        .status-badge { padding: 4px 12px; border-radius: 6px; font-size: 0.6875rem; font-weight: 700; text-transform: uppercase; }
        .s-requested { background: #FEF3C7; color: #92400E; }
        .s-accepted { background: #DBEAFE; color: #1E40AF; }
        .s-in_progress { background: #F3E8FF; color: #6D28D9; }
        .s-completed { background: #DCFCE7; color: #166534; }
        .s-cancelled { background: #FEE2E2; color: #991B1B; }

        .oc-desc { font-size: 0.875rem; color: #475569; line-height: 1.5; margin-bottom: 10px; background: #F8FAFC; padding: 10px; border-radius: 6px; }

        .oc-specs { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 12px; }
        .spec-badge { padding: 3px 10px; background: #F1F5F9; border-radius: 6px; font-size: 0.6875rem; color: #475569; font-weight: 600; }

        .oc-address { font-size: 0.8125rem; color: #64748B; margin-bottom: 12px; }
        .oc-address strong { color: #374151; }

        /* Action forms */
        .oc-actions { display: flex; gap: 8px; flex-wrap: wrap; align-items: end; margin-top: 12px; padding-top: 12px; border-top: 1px solid #F1F5F9; }
        .action-form { display: flex; gap: 6px; align-items: end; flex-wrap: wrap; }
        .action-form .fg { }
        .action-form label { display: block; font-size: 0.6875rem; font-weight: 600; color: #64748B; margin-bottom: 3px; }
        .action-form input { padding: 6px 10px; border: 1px solid #E2E8F0; border-radius: 6px; font-size: 0.8125rem; width: 120px; }

        .btn-action {
            padding: 8px 16px; border: none; border-radius: 6px; font-size: 0.75rem;
            font-weight: 700; cursor: pointer; font-family: inherit; white-space: nowrap;
        }
        .btn-accept { background: #16A34A; color: white; }
        .btn-accept:hover { background: #15803D; }
        .btn-start { background: #8B5CF6; color: white; }
        .btn-start:hover { background: #7C3AED; }
        .btn-complete { background: #059669; color: white; }
        .btn-complete:hover { background: #047857; }
        .btn-cancel { background: #FEE2E2; color: #991B1B; }
        .btn-cancel:hover { background: #FECACA; }

        .empty-state { text-align: center; padding: 60px 24px; color: #94A3B8; background: white; border-radius: 14px; border: 1px solid #E2E8F0; }

        @media (max-width: 900px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .mobile-menu-btn { display: block; }
        }
        .overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 90; }
        .overlay.active { display: block; }
    </style>
</head>
<body>
    <?php $current_installer_page = 'orders'; include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="top-bar">
            <div>
                <button class="mobile-menu-btn" onclick="toggleSidebar()">&#9776;</button>
                <h1>Installation Orders</h1>
            </div>
        </div>

        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>

        <div class="tabs">
            <a href="?status=" class="tab <?= !$status_filter ? 'active' : '' ?>">All <span class="cnt">(<?= $counts['all'] ?>)</span></a>
            <a href="?status=requested" class="tab <?= $status_filter === 'requested' ? 'active' : '' ?>">&#128276; New <span class="cnt">(<?= $counts['requested'] ?>)</span></a>
            <a href="?status=accepted" class="tab <?= $status_filter === 'accepted' ? 'active' : '' ?>">&#10003; Accepted <span class="cnt">(<?= $counts['accepted'] ?>)</span></a>
            <a href="?status=in_progress" class="tab <?= $status_filter === 'in_progress' ? 'active' : '' ?>">&#128296; In Progress <span class="cnt">(<?= $counts['in_progress'] ?>)</span></a>
            <a href="?status=completed" class="tab <?= $status_filter === 'completed' ? 'active' : '' ?>">&#10004; Done <span class="cnt">(<?= $counts['completed'] ?>)</span></a>
            <a href="?status=cancelled" class="tab <?= $status_filter === 'cancelled' ? 'active' : '' ?>">&#10060; Cancelled <span class="cnt">(<?= $counts['cancelled'] ?>)</span></a>
        </div>

        <?php if (empty($orders)): ?>
            <div class="empty-state">
                <div style="font-size:3rem;margin-bottom:12px;">&#128203;</div>
                <p>No installation orders<?= $status_filter ? ' with this status' : ' yet' ?>.</p>
            </div>
        <?php else: ?>
            <?php foreach ($orders as $o): ?>
                <div class="order-card status-<?= $o['status'] ?>">
                    <div class="oc-header">
                        <div>
                            <div class="oc-customer"><?= sanitize($o['customer_name']) ?></div>
                            <div class="oc-contact">
                                <?= sanitize($o['customer_email']) ?>
                                <?= $o['customer_phone'] ? ' &middot; ' . sanitize($o['customer_phone']) : '' ?>
                            </div>
                            <div class="oc-date"><?= date('M j, Y g:i A', strtotime($o['created_at'])) ?></div>
                        </div>
                        <span class="status-badge s-<?= $o['status'] ?>"><?= ucfirst(str_replace('_', ' ', $o['status'])) ?></span>
                    </div>

                    <div class="oc-desc"><?= nl2br(sanitize($o['description'])) ?></div>

                    <div class="oc-specs">
                        <?php if (!empty($o['property_type'])): ?>
                            <span class="spec-badge" style="background:#EDE9FE;color:#6D28D9;"><?= ucfirst(sanitize($o['property_type'])) ?></span>
                        <?php endif; ?>
                        <span class="spec-badge"><?= sanitize($o['system_type']) ?></span>
                        <span class="spec-badge"><?= $o['system_size_kw'] ?> kW</span>
                        <?php if (!empty($o['customer_budget_per_kw'])): ?>
                            <span class="spec-badge" style="color:#1565C0;font-weight:700;">Budget: $<?= number_format($o['customer_budget_per_kw'], 2) ?>/kW<?php if ($o['customer_budget_total']): ?> ($<?= number_format($o['customer_budget_total'], 0) ?> total)<?php endif; ?></span>
                        <?php endif; ?>
                        <?php if ($o['scheduled_date']): ?>
                            <span class="spec-badge">&#128197; <?= date('M j, Y', strtotime($o['scheduled_date'])) ?></span>
                        <?php endif; ?>
                        <?php
                        $time_labels = ['morning' => 'Morning (8am-12pm)', 'afternoon' => 'Afternoon (12pm-5pm)', 'evening' => 'Evening (5pm-8pm)', 'flexible' => 'Flexible'];
                        if (!empty($o['preferred_time']) && isset($time_labels[$o['preferred_time']])): ?>
                            <span class="spec-badge">&#128336; <?= $time_labels[$o['preferred_time']] ?></span>
                        <?php endif; ?>
                        <?php if ($o['estimated_cost']): ?>
                            <span class="spec-badge" style="color:#059669;font-weight:700;">Quote: $<?= number_format($o['estimated_cost'], 0) ?></span>
                        <?php endif; ?>
                        <?php if ($o['total_amount']): ?>
                            <span class="spec-badge" style="color:#1E293B;font-weight:700;">Final: $<?= number_format($o['total_amount'], 0) ?></span>
                        <?php endif; ?>
                    </div>

                    <?php if ($o['address']): ?>
                        <div class="oc-address"><strong>Address:</strong> <?= sanitize($o['address']) ?></div>
                    <?php endif; ?>

                    <?php if ($o['customer_notes']): ?>
                        <div style="font-size:0.8125rem;color:#64748B;margin-bottom:8px;"><em>Customer note: <?= sanitize($o['customer_notes']) ?></em></div>
                    <?php endif; ?>

                    <!-- Actions -->
                    <div class="oc-actions">
                        <?php if ($o['status'] === 'requested'): ?>
                            <form method="POST" class="action-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="accept">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <div class="fg">
                                    <label>Your Quote ($)</label>
                                    <input type="number" name="estimated_cost" step="0.01" min="1" required placeholder="e.g. 3000">
                                </div>
                                <div class="fg">
                                    <label>Notes (optional)</label>
                                    <input type="text" name="installer_notes" placeholder="Any notes..." style="width:180px;">
                                </div>
                                <button type="submit" class="btn-action btn-accept">&#10003; Accept & Quote</button>
                            </form>
                            <form method="POST" class="action-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="cancel">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <input type="hidden" name="cancel_reason" value="Declined by installer">
                                <button type="submit" class="btn-action btn-cancel" onclick="return confirm('Decline this request?')">&#10060; Decline</button>
                            </form>
                        <?php elseif ($o['status'] === 'accepted'): ?>
                            <form method="POST" class="action-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="start">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <button type="submit" class="btn-action btn-start">&#128296; Mark In Progress</button>
                            </form>
                            <form method="POST" class="action-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="cancel">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <input type="hidden" name="cancel_reason" value="Cancelled by installer">
                                <button type="submit" class="btn-action btn-cancel" onclick="return confirm('Cancel this order?')">&#10060; Cancel</button>
                            </form>
                        <?php elseif ($o['status'] === 'in_progress'): ?>
                            <form method="POST" class="action-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="complete">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <div class="fg">
                                    <label>Final Amount ($)</label>
                                    <input type="number" name="total_amount" step="0.01" min="1" value="<?= $o['estimated_cost'] ?? '' ?>" required>
                                </div>
                                <button type="submit" class="btn-action btn-complete">&#10004; Mark Completed</button>
                            </form>
                        <?php elseif ($o['status'] === 'cancelled'): ?>
                            <span style="font-size:0.8125rem;color:#991B1B;"><?= $o['cancel_reason'] ? sanitize($o['cancel_reason']) : 'Cancelled' ?></span>
                        <?php elseif ($o['status'] === 'completed'): ?>
                            <span style="font-size:0.8125rem;color:#059669;font-weight:600;">&#10004; Completed <?= $o['completed_at'] ? date('M j, Y', strtotime($o['completed_at'])) : '' ?></span>
                            <?php if (!empty($o['customer_confirmed'])): ?>
                                <span style="font-size:0.75rem;color:#16A34A;background:#DCFCE7;padding:3px 10px;border-radius:6px;font-weight:600;">&#9989; Customer Confirmed</span>
                            <?php else: ?>
                                <span style="font-size:0.75rem;color:#92400E;background:#FEF3C7;padding:3px 10px;border-radius:6px;font-weight:600;">&#9203; Awaiting Customer Confirmation</span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </main>

</body>
</html>
