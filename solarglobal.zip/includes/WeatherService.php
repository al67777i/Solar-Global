<?php
/**
 * Weather Service - Open-Meteo API Integration
 * Fetches 30-day weather forecast and calculates solar irradiance factors
 *
 * API: https://open-meteo.com/en/docs (Free, no key needed)
 * Provides: temperature, cloud cover, precipitation, humidity, UV, sunshine hours
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/city_helper.php';

class WeatherService {

    private $db;
    private $cacheHours;
    private $baseUrl = 'https://api.open-meteo.com/v1/forecast';

    public function __construct() {
        $this->db = getDB();
        $this->cacheHours = (int)getSetting('weather_cache_hours', 6);
    }

    /**
     * Get 30-day weather forecast for a city
     * Returns cached data if available and fresh, otherwise fetches from API
     */
    public function getForecast($cityId, $days = 30) {
        $city = getCityById($cityId);
        if (!$city) return ['success' => false, 'error' => 'City not found'];

        // Check cache first
        $cached = $this->getCachedForecast($cityId);
        if ($cached && count($cached) >= $days - 2) {
            return [
                'success' => true,
                'source' => 'cache',
                'city' => $city['name_en'],
                'data' => $cached
            ];
        }

        // Fetch from API
        $result = $this->fetchFromAPI($city, $days);
        if ($result['success']) {
            $this->cacheForecast($cityId, $result['data']);
            return [
                'success' => true,
                'source' => 'api',
                'city' => $city['name_en'],
                'data' => $result['data']
            ];
        }

        // API failed - try to use stale cache
        $staleCache = $this->getStaleCachedForecast($cityId);
        if ($staleCache) {
            return [
                'success' => true,
                'source' => 'stale_cache',
                'city' => $city['name_en'],
                'data' => $staleCache
            ];
        }

        // Last resort: generate from historical sun_data
        $estimated = $this->estimateFromSunData($cityId, $days);
        return [
            'success' => true,
            'source' => 'estimated',
            'city' => $city['name_en'],
            'data' => $estimated
        ];
    }

    /**
     * Fetch weather data from Open-Meteo API
     */
    private function fetchFromAPI($city, $days) {
        $params = http_build_query([
            'latitude' => $city['latitude'],
            'longitude' => $city['longitude'],
            'daily' => implode(',', [
                'temperature_2m_max',
                'temperature_2m_min',
                'temperature_2m_mean',
                'precipitation_sum',
                'precipitation_probability_max',
                'cloud_cover_mean',
                'relative_humidity_2m_mean',
                'wind_speed_10m_max',
                'uv_index_max',
                'sunshine_duration',
                'shortwave_radiation_sum'
            ]),
            'timezone' => 'Asia/Karachi',
            'forecast_days' => min($days, 16) // Open-Meteo free: max 16 days forecast
        ]);

        $url = $this->baseUrl . '?' . $params;

        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => 3,
                'header' => "Accept: application/json\r\nUser-Agent: SolarRecommenderPK/2.0\r\n"
            ]
        ]);

        $response = @file_get_contents($url, false, $context);

        if ($response === false) {
            return ['success' => false, 'error' => 'API request failed'];
        }

        $data = json_decode($response, true);

        if (!$data || !isset($data['daily'])) {
            return ['success' => false, 'error' => 'Invalid API response'];
        }

        // Parse API response into our format
        $forecasts = $this->parseAPIResponse($data, $city);

        // If we need more than 16 days, extend with historical patterns
        if ($days > count($forecasts)) {
            $extended = $this->extendForecast($city, $forecasts, $days);
            $forecasts = $extended;
        }

        return ['success' => true, 'data' => $forecasts];
    }

    /**
     * Parse Open-Meteo API response into our database format
     */
    private function parseAPIResponse($data, $city) {
        $daily = $data['daily'];
        $forecasts = [];

        for ($i = 0; $i < count($daily['time']); $i++) {
            $date = $daily['time'][$i];
            $tempMax = $daily['temperature_2m_max'][$i] ?? 30;
            $tempMin = $daily['temperature_2m_min'][$i] ?? 20;
            $tempAvg = $daily['temperature_2m_mean'][$i] ?? (($tempMax + $tempMin) / 2);
            $cloudCover = $daily['cloud_cover_mean'][$i] ?? 20;
            $precipitation = $daily['precipitation_sum'][$i] ?? 0;
            $humidity = $daily['relative_humidity_2m_mean'][$i] ?? 50;
            $windSpeed = $daily['wind_speed_10m_max'][$i] ?? 10;
            $uvIndex = $daily['uv_index_max'][$i] ?? 6;
            $sunshineSec = $daily['sunshine_duration'][$i] ?? 0;
            $radiation = $daily['shortwave_radiation_sum'][$i] ?? 0;

            // Convert sunshine seconds to hours
            $sunshineHours = round($sunshineSec / 3600, 2);

            // Calculate solar irradiance in kWh/m²
            // radiation from API is in MJ/m² per day, convert to kWh/m² (÷3.6)
            $irradiance = round($radiation / 3.6, 2);

            // Determine weather condition
            $condition = $this->determineCondition($cloudCover, $precipitation, $humidity);

            $forecasts[] = [
                'forecast_date' => $date,
                'temperature_max' => round($tempMax, 1),
                'temperature_min' => round($tempMin, 1),
                'temperature_avg' => round($tempAvg, 1),
                'cloud_cover_percent' => round($cloudCover, 1),
                'precipitation_mm' => round($precipitation, 1),
                'humidity_percent' => round($humidity, 1),
                'wind_speed_kmh' => round($windSpeed, 1),
                'uv_index' => round($uvIndex, 1),
                'sunshine_hours' => $sunshineHours,
                'solar_irradiance_kwh_m2' => $irradiance,
                'weather_condition' => $condition
            ];
        }

        return $forecasts;
    }

    /**
     * Extend forecast beyond API limit using seasonal patterns
     */
    private function extendForecast($city, $existingForecasts, $totalDays) {
        $lastDate = end($existingForecasts)['forecast_date'];
        $currentDate = new DateTime($lastDate);
        $needed = $totalDays - count($existingForecasts);

        for ($i = 0; $i < $needed; $i++) {
            $currentDate->modify('+1 day');
            $month = (int)$currentDate->format('n');
            $dateStr = $currentDate->format('Y-m-d');

            // Get historical averages for this month
            $sunData = getSunDataForCity((int)$city['id'], $month);

            if ($sunData) {
                // Add slight daily variation (±10%)
                $variance = (mt_rand(-10, 10) / 100);
                $temp = $sunData['avg_temperature_c'] * (1 + $variance * 0.3);
                $cloud = min(100, max(0, $sunData['avg_cloud_cover_percent'] + mt_rand(-15, 15)));
                $humidity = min(100, max(20, $sunData['avg_humidity_percent'] + mt_rand(-10, 10)));
                $psh = max(2, $sunData['peak_sun_hours'] * (1 + $variance * 0.5));
                $irradiance = max(1, $sunData['avg_irradiance_kwh_m2'] * (1 + $variance * 0.4));

                $existingForecasts[] = [
                    'forecast_date' => $dateStr,
                    'temperature_max' => round($temp + 5, 1),
                    'temperature_min' => round($temp - 5, 1),
                    'temperature_avg' => round($temp, 1),
                    'cloud_cover_percent' => round($cloud, 1),
                    'precipitation_mm' => $cloud > 60 ? round(mt_rand(0, 20), 1) : 0,
                    'humidity_percent' => round($humidity, 1),
                    'wind_speed_kmh' => round(mt_rand(5, 25), 1),
                    'uv_index' => round(max(1, min(12, $psh * 1.3)), 1),
                    'sunshine_hours' => round($psh, 2),
                    'solar_irradiance_kwh_m2' => round($irradiance, 2),
                    'weather_condition' => $this->determineCondition($cloud, $cloud > 60 ? 5 : 0, $humidity)
                ];
            }
        }

        return $existingForecasts;
    }

    /**
     * Determine weather condition string from metrics
     */
    private function determineCondition($cloudCover, $precipitation, $humidity) {
        if ($precipitation > 10) return 'Rainy';
        if ($precipitation > 2) return 'Light Rain';
        if ($cloudCover > 80) return 'Overcast';
        if ($cloudCover > 60) return 'Mostly Cloudy';
        if ($cloudCover > 40) return 'Partly Cloudy';
        if ($humidity > 85 && $cloudCover > 30) return 'Foggy';
        if ($cloudCover > 20) return 'Few Clouds';
        return 'Clear';
    }

    /**
     * Get valid cached forecast data
     */
    private function getCachedForecast($cityId) {
        $stmt = $this->db->prepare("
            SELECT * FROM weather_cache
            WHERE city_id = ?
            AND forecast_date >= CURDATE()
            AND (expires_at IS NULL OR expires_at > NOW())
            ORDER BY forecast_date
            LIMIT 30
        ");
        $stmt->execute([$cityId]);
        $results = $stmt->fetchAll();
        return count($results) > 0 ? $results : null;
    }

    /**
     * Get stale cache (expired but still usable as fallback)
     */
    private function getStaleCachedForecast($cityId) {
        $stmt = $this->db->prepare("
            SELECT * FROM weather_cache
            WHERE city_id = ?
            AND forecast_date >= CURDATE()
            ORDER BY forecast_date
            LIMIT 30
        ");
        $stmt->execute([$cityId]);
        $results = $stmt->fetchAll();
        return count($results) > 0 ? $results : null;
    }

    /**
     * Cache forecast data to database
     */
    private function cacheForecast($cityId, $forecasts) {
        $expiresAt = date('Y-m-d H:i:s', strtotime("+{$this->cacheHours} hours"));

        $stmt = $this->db->prepare("
            INSERT INTO weather_cache
            (city_id, forecast_date, temperature_max, temperature_min, temperature_avg,
             cloud_cover_percent, precipitation_mm, humidity_percent, wind_speed_kmh,
             uv_index, sunshine_hours, solar_irradiance_kwh_m2, weather_condition, expires_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                temperature_max = VALUES(temperature_max),
                temperature_min = VALUES(temperature_min),
                temperature_avg = VALUES(temperature_avg),
                cloud_cover_percent = VALUES(cloud_cover_percent),
                precipitation_mm = VALUES(precipitation_mm),
                humidity_percent = VALUES(humidity_percent),
                wind_speed_kmh = VALUES(wind_speed_kmh),
                uv_index = VALUES(uv_index),
                sunshine_hours = VALUES(sunshine_hours),
                solar_irradiance_kwh_m2 = VALUES(solar_irradiance_kwh_m2),
                weather_condition = VALUES(weather_condition),
                fetched_at = NOW(),
                expires_at = VALUES(expires_at)
        ");

        foreach ($forecasts as $day) {
            $stmt->execute([
                $cityId,
                $day['forecast_date'],
                $day['temperature_max'],
                $day['temperature_min'],
                $day['temperature_avg'],
                $day['cloud_cover_percent'],
                $day['precipitation_mm'],
                $day['humidity_percent'],
                $day['wind_speed_kmh'],
                $day['uv_index'],
                $day['sunshine_hours'],
                $day['solar_irradiance_kwh_m2'],
                $day['weather_condition'],
                $expiresAt
            ]);
        }
    }

    /**
     * Generate estimate from historical sun_data when API is unavailable
     */
    private function estimateFromSunData($cityId, $days) {
        $forecasts = [];
        $currentDate = new DateTime();

        for ($i = 0; $i < $days; $i++) {
            $month = (int)$currentDate->format('n');
            $sunData = getSunDataForCity($cityId, $month);

            if ($sunData) {
                $variance = (mt_rand(-8, 8) / 100);
                $forecasts[] = [
                    'forecast_date' => $currentDate->format('Y-m-d'),
                    'temperature_max' => round($sunData['avg_temperature_c'] + 5 + mt_rand(-2, 2), 1),
                    'temperature_min' => round($sunData['avg_temperature_c'] - 5 + mt_rand(-2, 2), 1),
                    'temperature_avg' => round($sunData['avg_temperature_c'] + mt_rand(-1, 1), 1),
                    'cloud_cover_percent' => round(min(100, max(0, $sunData['avg_cloud_cover_percent'] + mt_rand(-10, 10))), 1),
                    'precipitation_mm' => $sunData['avg_cloud_cover_percent'] > 50 ? round(mt_rand(0, 15), 1) : 0,
                    'humidity_percent' => round(min(100, max(20, $sunData['avg_humidity_percent'] + mt_rand(-8, 8))), 1),
                    'wind_speed_kmh' => round(mt_rand(5, 20), 1),
                    'uv_index' => round(max(1, $sunData['peak_sun_hours'] * 1.2 + mt_rand(-1, 1)), 1),
                    'sunshine_hours' => round(max(2, $sunData['peak_sun_hours'] * (1 + $variance)), 2),
                    'solar_irradiance_kwh_m2' => round(max(1, $sunData['avg_irradiance_kwh_m2'] * (1 + $variance)), 2),
                    'weather_condition' => $this->determineCondition(
                        $sunData['avg_cloud_cover_percent'],
                        0,
                        $sunData['avg_humidity_percent']
                    )
                ];
            }
            $currentDate->modify('+1 day');
        }

        return $forecasts;
    }

    /**
     * Calculate solar generation potential for each forecast day
     */
    public function calculateDailyGenerationPotential($cityId, $panelWattPeak, $numPanels) {
        $forecast = $this->getForecast($cityId);
        if (!$forecast['success']) return $forecast;

        $totalCapacityKw = ($panelWattPeak * $numPanels) / 1000;
        $generation = [];

        foreach ($forecast['data'] as $day) {
            $irradiance = $day['solar_irradiance_kwh_m2'] ?? 4.5;
            $temp = $day['temperature_avg'] ?? 30;
            $cloud = $day['cloud_cover_percent'] ?? 20;

            // Temperature derating (-0.4%/°C above 25°C for crystalline silicon)
            $tempLoss = max(0, ($temp - 25) * 0.004);

            // Cloud impact (already factored in irradiance, but add extra for diffuse radiation)
            $cloudFactor = 1 - ($cloud / 100) * 0.1;

            // System losses (inverter 3-5%, wiring 2-3%, dust 3-5%, mismatch 2%)
            $systemLoss = 0.15;

            // Daily generation = Capacity × PSH × efficiency factors
            $psh = $day['sunshine_hours'] ?? ($irradiance * 0.85);
            $grossGen = $totalCapacityKw * $psh;
            $netGen = $grossGen * (1 - $tempLoss) * $cloudFactor * (1 - $systemLoss);

            $generation[] = [
                'date' => $day['forecast_date'],
                'condition' => $day['weather_condition'],
                'temperature' => $temp,
                'cloud_cover' => $cloud,
                'irradiance' => $irradiance,
                'sunshine_hours' => $day['sunshine_hours'] ?? $psh,
                'gross_generation_kwh' => round($grossGen, 2),
                'net_generation_kwh' => round(max(0, $netGen), 2),
                'efficiency' => round((1 - $tempLoss) * $cloudFactor * (1 - $systemLoss) * 100, 1)
            ];
        }

        return [
            'success' => true,
            'city_id' => $cityId,
            'system_kw' => $totalCapacityKw,
            'forecast_days' => count($generation),
            'total_generation_kwh' => round(array_sum(array_column($generation, 'net_generation_kwh')), 2),
            'avg_daily_kwh' => round(array_sum(array_column($generation, 'net_generation_kwh')) / max(1, count($generation)), 2),
            'daily_forecast' => $generation
        ];
    }

    /**
     * Get weather summary for a city (used in UI)
     */
    public function getWeatherSummary($cityId) {
        $forecast = $this->getForecast($cityId, 7);
        if (!$forecast['success']) return null;

        $data = $forecast['data'];
        if (empty($data)) return null;

        $avgTemp = array_sum(array_column($data, 'temperature_avg')) / count($data);
        $avgCloud = array_sum(array_column($data, 'cloud_cover_percent')) / count($data);
        $totalRain = array_sum(array_column($data, 'precipitation_mm'));
        $avgIrradiance = array_sum(array_column($data, 'solar_irradiance_kwh_m2')) / count($data);
        $avgSunshine = array_sum(array_column($data, 'sunshine_hours')) / count($data);

        // Determine overall outlook and WMO weather code
        $weatherCode = 0; // Clear
        if ($totalRain > 30) { $outlook = 'Rainy Week'; $weatherCode = 61; }
        elseif ($totalRain > 10) { $outlook = 'Rainy Week'; $weatherCode = 51; }
        elseif ($avgCloud > 70) { $outlook = 'Cloudy Week'; $weatherCode = 3; }
        elseif ($avgCloud > 40) { $outlook = 'Mixed Week'; $weatherCode = 2; }
        else { $outlook = 'Sunny Week'; $weatherCode = 0; }

        return [
            'outlook' => $outlook,
            'weather_code' => $weatherCode,
            'avg_temperature' => round($avgTemp, 1),
            'avg_cloud_cover' => round($avgCloud, 1),
            'total_precipitation' => round($totalRain, 1),
            'avg_daily_irradiance' => round($avgIrradiance, 2),
            'avg_sunshine_hours' => round($avgSunshine, 1),
            'solar_rating' => $this->getSolarRating($avgIrradiance, $avgCloud),
            'source' => $forecast['source'],
            'days' => count($data)
        ];
    }

    /**
     * Rate solar potential (1-5 stars)
     */
    private function getSolarRating($irradiance, $cloudCover) {
        $score = ($irradiance / 7) * 60 + ((100 - $cloudCover) / 100) * 40;
        if ($score >= 80) return 5;
        if ($score >= 65) return 4;
        if ($score >= 50) return 3;
        if ($score >= 35) return 2;
        return 1;
    }

    /**
     * Clean expired cache entries
     */
    public function cleanExpiredCache() {
        $this->db->exec("DELETE FROM weather_cache WHERE forecast_date < CURDATE() - INTERVAL 7 DAY");
    }
}
