<?php
/**
 * SolarGlobal - Solar Calculator
 * Calculates solar production estimates based on location, irradiance, and system specs
 */

class SolarCalculator {

    // System efficiency factors
    const INVERTER_EFFICIENCY = 0.96;
    const CABLE_LOSS = 0.02;
    const DUST_LOSS = 0.03;
    const TEMPERATURE_COEFFICIENT = -0.004; // per degree above 25°C
    const STANDARD_TEST_TEMP = 25;
    const BATTERY_ROUND_TRIP = 0.90;

    private $latitude;
    private $longitude;
    private $avgSunHours;
    private $avgIrradiance;
    private $avgTemperature;
    private $optimalTilt;

    public function __construct($lat, $lng, $solarData = null) {
        $this->latitude = $lat;
        $this->longitude = $lng;

        if ($solarData) {
            $this->avgSunHours = $solarData['avg_sun_hours'] ?? 5.0;
            $this->avgIrradiance = $solarData['avg_irradiance'] ?? 4.5;
            $this->avgTemperature = $solarData['avg_temperature'] ?? 25;
            $this->optimalTilt = $solarData['optimal_tilt'] ?? abs($lat);
        } else {
            // Defaults based on latitude
            $this->avgSunHours = $this->estimateSunHours($lat);
            $this->avgIrradiance = $this->estimateIrradiance($lat);
            $this->avgTemperature = 25;
            $this->optimalTilt = abs($lat);
        }
    }

    /**
     * Calculate optimal tilt angle for solar panels
     * General rule: tilt ≈ latitude for annual optimization
     */
    public function getOptimalTilt() {
        return round(abs($this->latitude), 1);
    }

    /**
     * Get seasonal tilt recommendations
     */
    public function getSeasonalTilts() {
        $lat = abs($this->latitude);
        return [
            'annual' => round($lat, 1),
            'summer' => round($lat - 15, 1),
            'winter' => round($lat + 15, 1),
            'spring_fall' => round($lat, 1)
        ];
    }

    /**
     * Calculate daily energy production for a given system size
     * @param float $systemKw System size in kW
     * @return array Production estimates
     */
    public function calculateDailyProduction($systemKw) {
        // Base production = system size × sun hours × irradiance factor
        $peakSunHours = $this->avgSunHours;
        $irradianceFactor = $this->avgIrradiance / 5.0; // Normalize to STC (5 kWh/m²/day)

        // Temperature derating
        $tempDerate = 1.0;
        if ($this->avgTemperature > self::STANDARD_TEST_TEMP) {
            $tempDerate = 1 + (self::TEMPERATURE_COEFFICIENT * ($this->avgTemperature - self::STANDARD_TEST_TEMP));
        }

        // System losses
        $systemEfficiency = self::INVERTER_EFFICIENCY * (1 - self::CABLE_LOSS) * (1 - self::DUST_LOSS) * $tempDerate;

        // Daily production in kWh
        $dailyProduction = $systemKw * $peakSunHours * $irradianceFactor * $systemEfficiency;

        return [
            'daily_kwh' => round($dailyProduction, 2),
            'monthly_kwh' => round($dailyProduction * 30, 1),
            'annual_kwh' => round($dailyProduction * 365, 0),
            'peak_sun_hours' => $peakSunHours,
            'system_efficiency' => round($systemEfficiency * 100, 1),
            'temp_derate' => round($tempDerate * 100, 1)
        ];
    }

    /**
     * Calculate required system size for a given daily consumption
     * @param float $dailyConsumptionKwh Daily energy need in kWh
     * @return array System sizing recommendation
     */
    public function calculateRequiredSystem($dailyConsumptionKwh) {
        $peakSunHours = $this->avgSunHours;
        $irradianceFactor = $this->avgIrradiance / 5.0;

        // Temperature derating
        $tempDerate = 1.0;
        if ($this->avgTemperature > self::STANDARD_TEST_TEMP) {
            $tempDerate = 1 + (self::TEMPERATURE_COEFFICIENT * ($this->avgTemperature - self::STANDARD_TEST_TEMP));
        }

        $systemEfficiency = self::INVERTER_EFFICIENCY * (1 - self::CABLE_LOSS) * (1 - self::DUST_LOSS) * $tempDerate;

        // Required system size
        $requiredKw = $dailyConsumptionKwh / ($peakSunHours * $irradianceFactor * $systemEfficiency);

        // Add 20% buffer for cloudy days and degradation
        $recommendedKw = $requiredKw * 1.2;

        return [
            'minimum_kw' => round($requiredKw, 2),
            'recommended_kw' => round($recommendedKw, 2),
            'daily_consumption' => $dailyConsumptionKwh,
            'sun_hours' => $peakSunHours,
            'efficiency' => round($systemEfficiency * 100, 1)
        ];
    }

    /**
     * Calculate battery storage requirement
     * @param float $dailyConsumptionKwh Daily energy need
     * @param float $backupHours Hours of backup needed
     * @param float $dod Depth of discharge (0-1)
     * @return array Battery sizing
     */
    public function calculateBatteryStorage($dailyConsumptionKwh, $backupHours = 8, $dod = 0.8) {
        $hourlyConsumption = $dailyConsumptionKwh / 24;
        $requiredEnergy = $hourlyConsumption * $backupHours;

        // Account for inverter efficiency and DoD
        $actualCapacity = $requiredEnergy / ($dod * self::BATTERY_ROUND_TRIP);

        return [
            'required_kwh' => round($requiredEnergy, 2),
            'actual_capacity_kwh' => round($actualCapacity, 2),
            'hourly_consumption' => round($hourlyConsumption, 3),
            'backup_hours' => $backupHours,
            'depth_of_discharge' => $dod * 100
        ];
    }

    /**
     * Get monthly production estimates (seasonal variation)
     * @param float $systemKw System size in kW
     * @return array Monthly production values
     */
    public function getMonthlyProduction($systemKw) {
        // Seasonal factors based on hemisphere
        $isNorthern = $this->latitude >= 0;

        // Monthly irradiance variation factors (normalized to annual average = 1.0)
        $monthlyFactors = $isNorthern ? [
            0.70, 0.80, 0.95, 1.10, 1.20, 1.25, // Jan-Jun
            1.25, 1.18, 1.05, 0.88, 0.72, 0.65  // Jul-Dec
        ] : [
            1.25, 1.18, 1.05, 0.88, 0.72, 0.65, // Jan-Jun
            0.70, 0.80, 0.95, 1.10, 1.20, 1.25  // Jul-Dec
        ];

        // Latitude affects seasonal variation amplitude
        $latFactor = abs($this->latitude) / 60; // 0 at equator, 1 at 60°
        $latFactor = min($latFactor, 1.0);

        $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        $daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

        $baseDaily = $this->calculateDailyProduction($systemKw)['daily_kwh'];
        $monthlyData = [];

        for ($i = 0; $i < 12; $i++) {
            // Blend between flat (equator) and varied (high lat)
            $factor = 1.0 + ($monthlyFactors[$i] - 1.0) * $latFactor;
            $dailyProd = $baseDaily * $factor;
            $monthlyProd = $dailyProd * $daysInMonth[$i];

            $monthlyData[] = [
                'month' => $months[$i],
                'daily_kwh' => round($dailyProd, 2),
                'monthly_kwh' => round($monthlyProd, 1),
                'factor' => round($factor, 2)
            ];
        }

        return $monthlyData;
    }

    /**
     * Calculate CO2 offset
     * @param float $annualKwh Annual production in kWh
     * @return array Environmental impact
     */
    public function calculateEnvironmentalImpact($annualKwh) {
        // Average grid emission factor (global average ~0.5 kg CO2/kWh)
        $co2PerKwh = 0.5;
        $annualCo2Kg = $annualKwh * $co2PerKwh;

        // Trees equivalent (1 tree absorbs ~22 kg CO2/year)
        $treesEquivalent = $annualCo2Kg / 22;

        return [
            'annual_co2_offset_kg' => round($annualCo2Kg, 0),
            'annual_co2_offset_tons' => round($annualCo2Kg / 1000, 2),
            'trees_equivalent' => round($treesEquivalent, 0),
            'cars_equivalent' => round($annualCo2Kg / 4600, 1) // avg car = 4.6 tons/year
        ];
    }

    /**
     * Estimate sun hours from latitude (fallback when no API data)
     */
    private function estimateSunHours($lat) {
        $absLat = abs($lat);
        if ($absLat < 15) return 6.5;
        if ($absLat < 25) return 6.0;
        if ($absLat < 35) return 5.5;
        if ($absLat < 45) return 5.0;
        if ($absLat < 55) return 4.0;
        return 3.5;
    }

    /**
     * Estimate irradiance from latitude (fallback)
     */
    private function estimateIrradiance($lat) {
        $absLat = abs($lat);
        if ($absLat < 15) return 5.5;
        if ($absLat < 25) return 5.2;
        if ($absLat < 35) return 4.8;
        if ($absLat < 45) return 4.2;
        if ($absLat < 55) return 3.5;
        return 2.8;
    }

    // Getters
    public function getAvgSunHours() { return $this->avgSunHours; }
    public function getAvgIrradiance() { return $this->avgIrradiance; }
    public function getAvgTemperature() { return $this->avgTemperature; }
    public function getLatitude() { return $this->latitude; }
    public function getLongitude() { return $this->longitude; }
}
