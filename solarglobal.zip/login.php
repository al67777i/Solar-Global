<?php
/**
 * Admin Login Page
 */
session_start();
require_once 'includes/db.php';
require_once 'includes/csrf.php';
require_once 'includes/helpers.php';

set_security_headers();

$error = '';
$timeout_message = '';

// Check if session timed out
if (isset($_GET['timeout']) && $_GET['timeout'] == '1') {
    $timeout_message = 'Your session has expired. Please login again.';
}

// Rate limiting: track failed attempts
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['login_attempt_time'] = time();
}

// Reset counter after 10 minutes
if (time() - $_SESSION['login_attempt_time'] > 600) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['login_attempt_time'] = time();
}

// Check if blocked
$is_blocked = $_SESSION['login_attempts'] >= 5;
$block_time_remaining = 0;

if ($is_blocked) {
    $block_time_remaining = 900 - (time() - $_SESSION['login_attempt_time']); // 15 minutes
    if ($block_time_remaining <= 0) {
        $_SESSION['login_attempts'] = 0;
        $is_blocked = false;
    }
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_blocked) {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } elseif (!validate_honeypot('website_url')) {
        $error = 'Submission rejected.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($username) || empty($password)) {
            $error = 'Please enter both username and password.';
        } else {
            try {
                $db = getDB();
                $stmt = $db->prepare("SELECT id, username, password_hash FROM admin_users WHERE username = ? LIMIT 1");
                $stmt->execute([$username]);
                $user = $stmt->fetch();
                
                if ($user && password_verify($password, $user['password_hash'])) {
                    // Login successful
                    session_regenerate_id(true);
                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['admin_id'] = $user['id'];
                    $_SESSION['admin_username'] = $user['username'];
                    $_SESSION['last_activity'] = time();
                    $_SESSION['login_attempts'] = 0;
                    
                    // Redirect to dashboard or saved URL
                    $basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
                    $redirect = $_SESSION['redirect_after_login'] ?? $basePath . '/admin/dashboard.php';
                    unset($_SESSION['redirect_after_login']);
                    redirect($redirect);
                } else {
                    // Login failed
                    $_SESSION['login_attempts']++;
                    $error = 'Invalid username or password.';
                }
            } catch (Exception $e) {
                error_log("Login error: " . $e->getMessage());
                $error = 'An error occurred. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - <?= htmlspecialchars(get_system_setting('site_name', 'SolarGlobal')) ?> Solar</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0D3B6E 0%, #1565C0 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 420px;
            padding: 48px 40px;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 32px;
        }
        
        .logo h1 {
            font-size: 36px;
            font-weight: 700;
            color: #0D3B6E;
            margin-bottom: 8px;
        }
        
        .logo p {
            font-size: 14px;
            color: #64748B;
        }
        
        .form-group {
            margin-bottom: 24px;
        }
        
        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: #334155;
            margin-bottom: 8px;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #E2E8F0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.2s;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #1565C0;
            box-shadow: 0 0 0 3px rgba(21, 101, 192, 0.1);
        }
        
        .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #1565C0 0%, #0D3B6E 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .btn-login:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(21, 101, 192, 0.3);
        }
        
        .btn-login:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .error-message {
            background: #FEE2E2;
            color: #991B1B;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            border-left: 4px solid #DC2626;
        }
        
        .info-message {
            background: #DBEAFE;
            color: #1E40AF;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            border-left: 4px solid #3B82F6;
        }
        
        .block-message {
            background: #FEF3C7;
            color: #92400E;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            border-left: 4px solid #F59E0B;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <h1><?= htmlspecialchars(get_system_setting('site_name', 'SolarGlobal')) ?></h1>
            <p>Admin Control Panel</p>
        </div>
        
        <?php if ($timeout_message): ?>
            <div class="info-message"><?= sanitize($timeout_message) ?></div>
        <?php endif; ?>
        
        <?php if ($is_blocked): ?>
            <div class="block-message">
                Too many failed login attempts. Please try again in <?= ceil($block_time_remaining / 60) ?> minutes.
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="error-message"><?= sanitize($error) ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <?= csrf_field() ?>
            <?= render_honeypot_field('website_url') ?>
            
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required <?= $is_blocked ? 'disabled' : '' ?>>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required <?= $is_blocked ? 'disabled' : '' ?>>
            </div>
            
            <button type="submit" class="btn-login" <?= $is_blocked ? 'disabled' : '' ?>>
                Login
            </button>
        </form>
    </div>
</body>
</html>
