<?php
/**
 * Database Connection Handler
 * Singleton PDO connection with security best practices
 */

// Start session early — before any output — so login state is available in headers
if (session_status() === PHP_SESSION_NONE && php_sapi_name() !== 'cli') {
    session_start();
}

// Database configuration — from environment or defaults (local dev)
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'solarglobal');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');

// Singleton connection instance
$pdo = null;

/**
 * Get database connection (singleton pattern)
 * @return PDO
 */
function getDB() {
    global $pdo;
    
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false, // Use real prepared statements
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET . " COLLATE utf8mb4_unicode_ci"
            ];
            
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Log error securely (in production, log to file)
            error_log("Database connection failed: " . $e->getMessage());
            
            // Display generic error to user
            die("Service temporarily unavailable. Please try again later.");
        }
    }
    
    return $pdo;
}

// Initialize connection
getDB();
