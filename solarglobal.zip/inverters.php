<?php
require_once 'includes/db.php';
require_once 'includes/helpers.php';
set_security_headers();
trackVisitor($pdo);

// ── Anti-scraping: bot + rate limit ──────────────────────────────────
if (is_bot_request() && !rate_limit('bot_inverters_' . ($_SERVER['REMOTE_ADDR'] ?? ''), 10, 60)) {
    http_response_code(429);
    echo '<h1>429 Too Many Requests</h1>';
    exit;
}
if (!rate_limit('page_inverters_' . ($_SERVER['REMOTE_ADDR'] ?? ''), 60, 60)) {
    http_response_code(429);
    echo '<h1>429 Too Many Requests</h1><p>Please slow down.</p>';
    exit;
}

$current_page = 'inverters';
if (session_status() === PHP_SESSION_NONE) session_start();

// ── Anti-scraping: per-session price obfuscation key ─────────────────
if (empty($_SESSION['_sgpk'])) {
    $_SESSION['_sgpk'] = rand(41, 97);
}
$_pk = $_SESSION['_sgpk'];

// ── USER CURRENCY ─────────────────────────────────────────────────────
$user_cc = 'US';
$loc = json_decode($_COOKIE['sg_location'] ?? '{}', true);
if (!empty($loc['country_code'])) {
    $user_cc = $loc['country_code'];
} else {
    $detected = detect_user_country();
    if ($detected) $user_cc = $detected;
}
$currency_info   = get_country_currency_info($user_cc);
$currency_symbol = $currency_info['currency_symbol'];
$currency_code   = $currency_info['currency_code'];
$exchange_rate   = max(0.001, $currency_info['exchange_rate']);

// ── PARAMS ────────────────────────────────────────────────────────────
$origin_country = trim($_GET['country'] ?? '');
$company_id     = max(0, (int)($_GET['company'] ?? 0));
$brand_name     = '';

// ── ORIGIN COUNTRIES (always loaded) ─────────────────────────────────
$origin_countries = $pdo->query("
    SELECT DISTINCT c.country as name,
           ct.flag_emoji, ct.flag_icon, ct.code,
           COUNT(i.id) as product_count
    FROM companies c
    INNER JOIN inverters i ON i.company_id = c.id AND i.is_active = 1
    LEFT JOIN countries ct ON (
        LOWER(ct.name COLLATE utf8mb4_general_ci) = LOWER(c.country COLLATE utf8mb4_general_ci)
        OR ct.code COLLATE utf8mb4_general_ci = c.country COLLATE utf8mb4_general_ci
    )
    WHERE c.is_active = 1 AND c.country IS NOT NULL AND c.country != ''
    GROUP BY c.country
    ORDER BY product_count DESC, c.country ASC
")->fetchAll(PDO::FETCH_ASSOC);

// ── COMPANY LIST (when country selected) ──────────────────────────────
$company_cards = [];
if ($origin_country) {
    $stmt = $pdo->prepare("
        SELECT c.id, c.name, c.slug, c.logo_path, c.country, c.website,
               COUNT(i.id) as inverter_count,
               MIN(i.unit_price_usd) as min_price,
               MAX(i.unit_price_usd) as max_price
        FROM companies c
        INNER JOIN inverters i ON i.company_id = c.id AND i.is_active = 1
        WHERE c.is_active = 1 AND LOWER(c.country) = LOWER(?)
        GROUP BY c.id
        HAVING inverter_count > 0
        ORDER BY inverter_count DESC, c.name ASC
    ");
    $stmt->execute([$origin_country]);
    $company_cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// ── PRODUCTS (when company selected) ─────────────────────────────────
$inverters   = [];
$total       = 0;
$total_pages = 0;
$page_num    = 1;
$per_page    = 12;
$price_range = ['min' => 0, 'max' => 100000];
$power_range = ['min' => 0, 'max' => 100000];
$search = $type = $voltage = $min_price = $max_price = $min_watts = $max_watts = '';
$sort = 'price_asc';

if ($company_id) {
    $search    = trim($_GET['search']    ?? '');
    $type      = trim($_GET['type']      ?? '');
    $voltage   = trim($_GET['voltage']   ?? '');
    $min_price = trim($_GET['min_price'] ?? '');
    $max_price = trim($_GET['max_price'] ?? '');
    $min_watts = trim($_GET['min_watts'] ?? '');
    $max_watts = trim($_GET['max_watts'] ?? '');
    $sort      = trim($_GET['sort']      ?? 'price_asc');
    $page_num  = max(1, (int)($_GET['page'] ?? 1));
    $offset    = ($page_num - 1) * $per_page;

    $where  = ["i.is_active = 1", "i.company_id = ?"];
    $params = [$company_id];

    if ($search)    { $where[] = "(i.model LIKE ? OR c.name LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
    if ($type)      { $where[] = "i.type = ?";                         $params[] = $type; }
    if ($voltage)   { $where[] = "i.battery_voltage_range LIKE ?";     $params[] = "%$voltage%"; }
    if ($min_price) { $where[] = "i.unit_price_usd >= ?";              $params[] = (float)$min_price; }
    if ($max_price) { $where[] = "i.unit_price_usd <= ?";              $params[] = (float)$max_price; }
    if ($min_watts) { $where[] = "i.output_power_w >= ?";              $params[] = (float)$min_watts; }
    if ($max_watts) { $where[] = "i.output_power_w <= ?";              $params[] = (float)$max_watts; }

    $where_sql = implode(' AND ', $where);

    $cntStmt = $pdo->prepare("SELECT COUNT(*) FROM inverters i LEFT JOIN companies c ON i.company_id = c.id WHERE $where_sql");
    $cntStmt->execute($params);
    $total       = (int)$cntStmt->fetchColumn();
    $total_pages = max(1, ceil($total / $per_page));

    $allowed_sorts = [
        'price_asc'  => 'i.unit_price_usd ASC',
        'price_desc' => 'i.unit_price_usd DESC',
        'watts_asc'  => 'i.output_power_w ASC',
        'watts_desc' => 'i.output_power_w DESC',
        'name'       => 'i.model ASC',
    ];
    $order_by = $allowed_sorts[$sort] ?? 'i.unit_price_usd ASC';

    $sql = "SELECT i.*, c.name as company_name, c.country as company_country, c.logo_path as company_logo,
                   ct.flag_emoji as origin_flag, ct.flag_icon as origin_flag_icon, ct.code as origin_code
            FROM inverters i
            LEFT JOIN companies c ON i.company_id = c.id
            LEFT JOIN countries ct ON (
                LOWER(ct.name COLLATE utf8mb4_general_ci) = LOWER(COALESCE(i.country, c.country) COLLATE utf8mb4_general_ci)
                OR ct.code COLLATE utf8mb4_general_ci = COALESCE(i.country, c.country) COLLATE utf8mb4_general_ci
            )
            WHERE $where_sql ORDER BY $order_by LIMIT $per_page OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $inverters = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $pr = $pdo->query("SELECT MIN(unit_price_usd) as min, MAX(unit_price_usd) as max FROM inverters WHERE is_active = 1")->fetch();
    if ($pr) $price_range = $pr;
    $wr = $pdo->query("SELECT MIN(output_power_w) as min, MAX(output_power_w) as max FROM inverters WHERE is_active = 1")->fetch();
    if ($wr) $power_range = $wr;

    if (!$brand_name) {
        $s2 = $pdo->prepare("SELECT name, country FROM companies WHERE id = ? LIMIT 1");
        $s2->execute([$company_id]);
        $cn = $s2->fetch();
        if ($cn) {
            $brand_name = $cn['name'];
            if (!$origin_country) $origin_country = $cn['country'];
        }
    }
}

// ── STATS ─────────────────────────────────────────────────────────────
$total_inverters_all = (int)$pdo->query("SELECT COUNT(*) FROM inverters WHERE is_active = 1")->fetchColumn();
$total_brands_all    = (int)$pdo->query("SELECT COUNT(DISTINCT company_id) FROM inverters WHERE is_active = 1")->fetchColumn();

function toLocal($usd, $rate)         { return round($usd * $rate, 0); }
function formatLocal($usd, $rate, $s) { return $s . number_format(toLocal($usd, $rate)); }
/** Encode price for anti-scraping: only JS can decode it */
function encP($usd, $k) {
    if (!is_numeric($usd) || floatval($usd) <= 0) return '';
    return rtrim(base64_encode((string)(int)round(floatval($usd) * $k * 100)), '=');
}

// ── SEO ───────────────────────────────────────────────────────────────
$site_name        = get_system_setting('site_name', 'SolarGlobal');
$page_title       = "Solar Inverters – Browse by Country & Brand | $site_name";
$page_description = "Browse $total_inverters_all solar inverters from $total_brands_all+ brands across " . count($origin_countries) . " countries. Filter by type, voltage, and price.";
$page_keywords    = "solar inverters, inverter prices, hybrid inverter, on-grid, off-grid, compare inverters";
if ($origin_country && !$brand_name) {
    $page_title       = "$origin_country Solar Inverter Brands & Prices | $site_name";
    $page_description = "Browse solar inverter brands manufactured in $origin_country. Compare models and prices in $currency_code.";
}
if ($brand_name) {
    $page_title       = "$brand_name Solar Inverters – Full Catalog & Specs | $site_name";
    $page_description = "All $brand_name solar inverters. Compare $total inverter models, specs and prices in $currency_code.";
}

// ── NAVIGATION STATE ──────────────────────────────────────────────────
$state = 'countries';
if ($origin_country && !$company_id) $state = 'brands';
if ($company_id)                     $state = 'products';

// ── ACTIVE FILTERS COUNT ──────────────────────────────────────────────
$active_filters = array_filter([$search, $type, $voltage, $min_price, $max_price, $min_watts, $max_watts]);
$has_filters    = count($active_filters) > 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($page_description) ?>">
    <meta name="keywords"    content="<?= htmlspecialchars($page_keywords) ?>">
    <meta name="robots"      content="index, follow">
    <meta property="og:title"       content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($page_description) ?>">
    <link rel="canonical" href="<?= htmlspecialchars(getBaseUrl() . '/inverters') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <meta name="theme-color" content="#0D3B6E">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/frontend.css">
    <link rel="stylesheet" href="assets/css/products.css">
    <link rel="stylesheet" href="assets/css/mobile-app.css">

    <!-- JSON-LD: SEO structured data (prices still visible to search engines) -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      "name": <?= json_encode($page_title) ?>,
      "description": <?= json_encode($page_description) ?>,
      "url": <?= json_encode(getCurrentUrl()) ?>,
      "numberOfItems": <?= $company_id ? (int)$total : $total_inverters_all ?>
    }
    </script>

    <style>
    /* ═══════════════════════════════════════════════════
       CATALOG LAYOUT — Sidebar + Main
    ═══════════════════════════════════════════════════ */
    body { background: #F1F5F9; }

    /* Currency Bar */
    .currency-bar { background:#FFFBEB; border-bottom:1px solid #FDE68A; padding:7px 0; font-size:.82rem; }
    .currency-bar-inner { max-width:1440px; margin:0 auto; padding:0 20px; display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
    .currency-badge { background:#F59E0B; color:#fff; padding:3px 10px; border-radius:20px; font-weight:700; font-size:.75rem; }

    /* Hero — compact */
    .cat-hero {
        background: linear-gradient(135deg, #0D3B6E 0%, #1565C0 60%, #1E88E5 100%);
        padding: 36px 20px 32px;
        color: #fff;
        position: relative;
        overflow: hidden;
    }
    .cat-hero::before {
        content:""; position:absolute; inset:0;
        background-image: radial-gradient(circle at 20% 50%, rgba(255,255,255,.04) 0%,transparent 50%),
                          repeating-linear-gradient(135deg,transparent,transparent 40px,rgba(255,255,255,.015) 40px,rgba(255,255,255,.015) 80px);
        pointer-events:none;
    }
    .cat-hero-inner { max-width:1440px; margin:0 auto; position:relative; z-index:1; }
    .cat-hero-row { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:20px; }
    .cat-hero-left h1 { font-size:1.8rem; font-weight:800; margin:0 0 6px; letter-spacing:-.3px; }
    .cat-hero-left p  { font-size:.95rem; color:rgba(255,255,255,.8); margin:0; }
    .cat-hero-stats { display:flex; gap:28px; flex-wrap:wrap; }
    .cat-stat-val { display:block; font-size:1.4rem; font-weight:800; color:#FBBF24; }
    .cat-stat-lbl { display:block; font-size:.72rem; color:rgba(255,255,255,.7); margin-top:1px; }

    /* Breadcrumb bar */
    .cat-breadcrumb {
        background:#fff; border-bottom:1px solid #E2E8F0;
        padding:10px 20px; font-size:.82rem;
        display:flex; align-items:center; gap:6px; flex-wrap:wrap;
    }
    .cat-breadcrumb a { color:#64748B; text-decoration:none; transition:color .15s; }
    .cat-breadcrumb a:hover { color:#1565C0; }
    .cat-breadcrumb .sep { color:#CBD5E1; }
    .cat-breadcrumb .cur { color:#1E293B; font-weight:600; }
    .cat-breadcrumb-inner { max-width:1440px; margin:0 auto; width:100%; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }

    /* Outer wrapper: sidebar + main */
    .cat-layout {
        max-width: 1440px;
        margin: 0 auto;
        padding: 24px 20px 60px;
        display: grid;
        grid-template-columns: 280px 1fr;
        gap: 24px;
        align-items: start;
    }

    /* ── SIDEBAR ── */
    .cat-sidebar {
        background: #fff;
        border-radius: 14px;
        border: 1px solid #E2E8F0;
        box-shadow: 0 1px 4px rgba(0,0,0,.06);
        position: sticky;
        top: 20px;
        max-height: calc(100vh - 40px);
        overflow-y: auto;
        scrollbar-width: thin;
        scrollbar-color: #CBD5E1 transparent;
    }
    .cat-sidebar::-webkit-scrollbar { width:4px; }
    .cat-sidebar::-webkit-scrollbar-thumb { background:#CBD5E1; border-radius:2px; }

    /* Sidebar search */
    .sb-search { padding:16px 16px 12px; border-bottom:1px solid #F1F5F9; }
    .sb-search-wrap {
        display:flex; align-items:center; gap:8px;
        background:#F8FAFC; border:1.5px solid #E2E8F0; border-radius:10px;
        padding:9px 12px; transition:border-color .2s;
    }
    .sb-search-wrap:focus-within { border-color:#1565C0; background:#fff; }
    .sb-search-wrap input {
        flex:1; border:none; background:none; font-size:.88rem; color:#1E293B;
        font-family:inherit; outline:none;
    }
    .sb-search-wrap input::placeholder { color:#94A3B8; }
    .sb-search-icon { color:#94A3B8; font-size:1rem; flex-shrink:0; }

    /* Sidebar section header */
    .sb-section { border-bottom:1px solid #F1F5F9; }
    .sb-section-head {
        display:flex; align-items:center; justify-content:space-between;
        padding:14px 16px 10px; cursor:pointer; user-select:none;
    }
    .sb-section-title {
        font-size:.72rem; font-weight:700; text-transform:uppercase;
        letter-spacing:.08em; color:#94A3B8;
    }
    .sb-section-badge {
        background:#F1F5F9; color:#64748B; font-size:.68rem; font-weight:700;
        padding:2px 8px; border-radius:20px;
    }
    .sb-section-badge.active { background:#DBEAFE; color:#1D4ED8; }
    .sb-section-body { padding:0 8px 10px; }

    /* Country list in sidebar */
    .sb-country-item {
        display:flex; align-items:center; gap:10px; padding:8px 8px;
        border-radius:8px; text-decoration:none; color:#334155; font-size:.875rem;
        transition:all .15s; cursor:pointer;
    }
    .sb-country-item:hover { background:#F8FAFC; color:#1E293B; }
    .sb-country-item.active { background:#EFF6FF; color:#1D4ED8; font-weight:700; }
    .sb-country-item .sb-flag { font-size:1.15rem; flex-shrink:0; }
    .sb-country-item .sb-name { flex:1; min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .sb-country-item .sb-cnt { font-size:.72rem; color:#94A3B8; flex-shrink:0; background:#F1F5F9; padding:2px 7px; border-radius:10px; }
    .sb-country-item.active .sb-cnt { background:#DBEAFE; color:#1D4ED8; }

    /* Company list in sidebar */
    .sb-company-item {
        display:flex; align-items:center; gap:10px; padding:7px 8px;
        border-radius:8px; text-decoration:none; color:#334155; font-size:.85rem;
        transition:all .15s; cursor:pointer;
    }
    .sb-company-item:hover { background:#F8FAFC; color:#1E293B; }
    .sb-company-item.active { background:#EFF6FF; color:#1D4ED8; font-weight:700; }
    .sb-company-logo {
        width:32px; height:32px; border-radius:6px; background:#F8FAFC;
        border:1px solid #E2E8F0; display:flex; align-items:center; justify-content:center;
        overflow:hidden; flex-shrink:0;
    }
    .sb-company-logo img { width:100%; height:100%; object-fit:contain; padding:3px; }
    .sb-company-logo .sb-logo-icon { font-size:1rem; color:#94A3B8; }
    .sb-company-item .sb-name { flex:1; min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .sb-company-item .sb-cnt { font-size:.72rem; color:#94A3B8; flex-shrink:0; }
    .sb-company-item.active .sb-cnt { color:#1D4ED8; }

    /* Sidebar show-more */
    .sb-show-more {
        display:block; text-align:center; font-size:.78rem; color:#1565C0;
        font-weight:600; padding:6px 0; cursor:pointer; text-decoration:none;
        transition:color .15s;
    }
    .sb-show-more:hover { color:#0D3B6E; }

    /* Sidebar filter controls */
    .sb-filter-row { padding:0 8px; margin-bottom:10px; }
    .sb-filter-label { font-size:.78rem; font-weight:600; color:#475569; margin-bottom:5px; display:block; }
    .sb-filter-input, .sb-filter-select {
        width:100%; padding:8px 10px; border:1.5px solid #E2E8F0; border-radius:8px;
        font-size:.84rem; font-family:inherit; color:#1E293B; background:#fff;
        transition:border-color .2s; box-sizing:border-box;
    }
    .sb-filter-select {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%2364748B' stroke-width='1.5' fill='none'/%3E%3C/svg%3E");
        background-repeat:no-repeat; background-position:right 10px center;
        padding-right:30px; cursor:pointer; -webkit-appearance:none; appearance:none;
    }
    .sb-filter-input:focus, .sb-filter-select:focus { outline:none; border-color:#1565C0; box-shadow:0 0 0 3px rgba(21,101,192,.1); }
    .sb-filter-apply {
        display:block; width:100%; padding:11px; margin-top:4px;
        background:linear-gradient(135deg,#0D3B6E,#1565C0);
        color:#fff; border:none; border-radius:8px; font-weight:700;
        font-size:.9rem; cursor:pointer; transition:all .2s; font-family:inherit;
    }
    .sb-filter-apply:hover { background:linear-gradient(135deg,#1565C0,#1E88E5); transform:translateY(-1px); }
    .sb-filter-clear {
        display:block; text-align:center; font-size:.78rem; color:#EF4444;
        font-weight:600; padding:6px 0; cursor:pointer; text-decoration:none;
        transition:color .15s; margin-top:2px;
    }
    .sb-filter-clear:hover { color:#DC2626; }

    /* Sidebar bottom padding */
    .sb-bottom-pad { height:16px; }

    /* ── MAIN CONTENT AREA ── */
    .cat-main { min-height:600px; }

    /* Step guide (shown when no state yet) */
    .cat-guide {
        background:#fff; border-radius:14px; border:1px solid #E2E8F0;
        padding:32px; text-align:center; margin-bottom:24px;
    }
    .cat-guide h2 { font-size:1.25rem; font-weight:700; color:#1E293B; margin:0 0 8px; }
    .cat-guide p  { color:#64748B; font-size:.9rem; margin:0 0 24px; }
    .cat-steps { display:flex; align-items:center; justify-content:center; gap:0; flex-wrap:wrap; }
    .cat-step { display:flex; align-items:center; gap:10px; }
    .cat-step-num {
        width:36px; height:36px; border-radius:50%; font-weight:800; font-size:.9rem;
        display:flex; align-items:center; justify-content:center; flex-shrink:0;
    }
    .cat-step-num.done  { background:#1565C0; color:#fff; }
    .cat-step-num.cur   { background:#FBBF24; color:#1E293B; box-shadow:0 0 0 3px rgba(251,191,36,.25); }
    .cat-step-num.todo  { background:#F1F5F9; color:#94A3B8; }
    .cat-step-text { font-size:.85rem; font-weight:600; color:#334155; }
    .cat-step-arrow { color:#CBD5E1; margin:0 8px; font-size:1.2rem; }

    /* Country overview cards (shown on landing) */
    .cat-overview-title { font-size:1.1rem; font-weight:700; color:#1E293B; margin:0 0 14px; }
    .country-overview-grid {
        display:grid; grid-template-columns:repeat(auto-fill, minmax(200px, 1fr)); gap:12px;
    }
    .country-ov-card {
        background:#fff; border:1.5px solid #E2E8F0; border-radius:12px;
        padding:16px; text-decoration:none; color:inherit; transition:all .2s;
        display:flex; align-items:center; gap:12px;
    }
    .country-ov-card:hover { border-color:#1565C0; box-shadow:0 4px 16px rgba(21,101,192,.12); transform:translateY(-2px); }
    .country-ov-flag { font-size:1.8rem; flex-shrink:0; }
    .country-ov-info .ov-name { font-weight:700; font-size:.9rem; color:#1E293B; }
    .country-ov-info .ov-meta { font-size:.75rem; color:#64748B; margin-top:2px; }
    .country-ov-info .ov-cnt  { font-size:.75rem; color:#1565C0; font-weight:600; margin-top:3px; }

    /* Company cards grid (shown when country selected) */
    .brands-grid-title {
        display:flex; align-items:center; gap:10px; margin-bottom:16px;
    }
    .brands-grid-title h2 { font-size:1.2rem; font-weight:700; color:#1E293B; margin:0; }
    .brands-grid-title .badge {
        background:#DBEAFE; color:#1D4ED8; font-size:.72rem; font-weight:700;
        padding:3px 10px; border-radius:20px;
    }
    .brands-grid {
        display:grid; grid-template-columns:repeat(auto-fill, minmax(240px, 1fr)); gap:14px;
    }
    .brand-card {
        background:#fff; border:1.5px solid #E2E8F0; border-radius:12px;
        padding:18px; display:flex; align-items:center; gap:14px;
        text-decoration:none; color:inherit; transition:all .2s; cursor:pointer;
    }
    .brand-card:hover { border-color:#1565C0; box-shadow:0 6px 20px rgba(21,101,192,.12); transform:translateY(-2px); }
    .brand-card-logo {
        width:48px; height:48px; border-radius:10px; background:#F8FAFC;
        border:1px solid #E2E8F0; display:flex; align-items:center; justify-content:center;
        overflow:hidden; flex-shrink:0;
    }
    .brand-card-logo img { width:100%; height:100%; object-fit:contain; padding:4px; }
    .brand-card-info { flex:1; min-width:0; }
    .brand-card-name { font-size:.95rem; font-weight:700; color:#1E293B; }
    .brand-card-meta { font-size:.75rem; color:#64748B; margin-top:2px; }
    .brand-card-price { font-size:.75rem; color:#1565C0; font-weight:600; margin-top:3px; }
    .brand-card-arrow { color:#CBD5E1; font-size:1.1rem; flex-shrink:0; transition:color .2s; }
    .brand-card:hover .brand-card-arrow { color:#1565C0; }

    /* Products section */
    .products-header {
        background:#fff; border:1px solid #E2E8F0; border-radius:12px;
        padding:16px 20px; display:flex; align-items:center;
        justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:18px;
    }
    .products-header h2 { font-size:1.1rem; font-weight:700; color:#1E293B; margin:0; }
    .products-header .ph-meta { font-size:.8rem; color:#64748B; margin-top:2px; }
    .sort-select {
        padding:8px 32px 8px 12px; border:1.5px solid #E2E8F0; border-radius:8px;
        font-size:.84rem; font-family:inherit; color:#1E293B; cursor:pointer;
        background:#fff; -webkit-appearance:none; appearance:none;
        background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%2364748B' stroke-width='1.5' fill='none'/%3E%3C/svg%3E");
        background-repeat:no-repeat; background-position:right 10px center;
    }
    .sort-select:focus { outline:none; border-color:#1565C0; }

    /* Product cards grid */
    .products-grid {
        display:grid; grid-template-columns:repeat(auto-fill, minmax(290px, 1fr)); gap:18px;
    }

    /* Product card redesign */
    .product-card {
        background:#fff; border:1.5px solid #E2E8F0; border-radius:14px;
        display:flex; flex-direction:column; overflow:hidden;
        transition:all .25s; position:relative; box-shadow:0 1px 4px rgba(0,0,0,.06);
    }
    .product-card:hover { border-color:#1565C0; box-shadow:0 8px 28px rgba(21,101,192,.14); transform:translateY(-4px); }
    .product-card::before {
        content:""; position:absolute; top:0; left:0; right:0; height:3px;
        background:transparent; transition:background .2s; border-radius:14px 14px 0 0; z-index:2;
    }
    .product-card:hover::before { background:linear-gradient(90deg,#0D3B6E,#1565C0); }

    .product-card-top {
        position:absolute; top:12px; left:12px; right:12px;
        display:flex; justify-content:space-between; align-items:flex-start; z-index:3;
    }
    .product-badge {
        padding:4px 10px; border-radius:20px; font-size:.68rem; font-weight:700;
        text-transform:uppercase; letter-spacing:.5px; backdrop-filter:blur(4px);
    }
    .product-badge.hybrid      { background:#DBEAFE; color:#1E40AF; }
    .product-badge.ongrid      { background:#D1FAE5; color:#065F46; }
    .product-badge.offgrid     { background:#FEF3C7; color:#92400E; }
    .product-badge.microinverter { background:#F3E8FF; color:#6B21A8; }
    .product-badge.standard    { background:#F1F5F9; color:#475569; }

    .compare-toggle { cursor:pointer; display:flex; align-items:center; }
    .compare-toggle input[type=checkbox] { display:none; }
    .compare-toggle-icon {
        width:28px; height:28px; border-radius:6px; background:rgba(255,255,255,.9);
        border:1.5px solid #E2E8F0; display:flex; align-items:center; justify-content:center;
        color:#94A3B8; transition:all .2s;
    }
    .compare-toggle input:checked ~ .compare-toggle-icon { background:#1565C0; border-color:#1565C0; color:#fff; }

    .product-image {
        width:100%; height:180px; background:#F8FAFC;
        display:flex; align-items:center; justify-content:center;
        border-bottom:1px solid #F1F5F9; overflow:hidden;
    }
    .product-image img { width:100%; height:100%; object-fit:contain; padding:16px; transition:transform .3s; pointer-events:none; user-select:none; -webkit-user-drag:none; }
    .product-card:hover .product-image img { transform:scale(1.05); }
    .product-image-placeholder { display:flex; align-items:center; justify-content:center; width:100%; height:100%; }
    .product-image-placeholder span { font-size:3.5rem; opacity:.35; }

    .product-info { padding:14px 16px 10px; flex:1; }
    .product-brand {
        font-size:.72rem; font-weight:700; color:#64748B; text-transform:uppercase;
        letter-spacing:.7px; display:flex; align-items:center; gap:5px; margin-bottom:5px;
    }
    .product-name { font-size:.95rem; font-weight:700; color:#1E293B; margin:0 0 12px; line-height:1.35; }
    .product-name a { color:inherit; text-decoration:none; }
    .product-name a:hover { color:#1565C0; }

    .product-specs-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:8px; margin-bottom:10px; }
    .spec-pill { background:#F8FAFC; border-radius:8px; padding:8px; display:flex; align-items:center; gap:7px; border:1px solid #F1F5F9; }
    .spec-pill-icon { font-size:1rem; flex-shrink:0; }
    .spec-pill-label { display:block; font-size:.64rem; color:#94A3B8; font-weight:500; text-transform:uppercase; letter-spacing:.4px; }
    .spec-pill-value { display:block; font-size:.8rem; font-weight:700; color:#1E293B; user-select:none; -webkit-user-select:none; }

    .product-features { display:flex; flex-wrap:wrap; gap:5px; padding-bottom:4px; }
    .feature-tag {
        font-size:.68rem; font-weight:600; padding:3px 8px; border-radius:4px;
        background:#F1F5F9; color:#475569;
    }

    .product-footer {
        padding:12px 16px 16px; border-top:1px solid #F1F5F9;
        display:flex; align-items:center; justify-content:space-between; gap:10px;
    }
    .product-price .price-local {
        font-size:1.2rem; font-weight:800; color:#059669; display:block;
        user-select:none; -webkit-user-select:none;
    }
    .product-price .price-local::before { content:""; } /* placeholder */
    .product-price .price-usd { font-size:.72rem; color:#94A3B8; display:block; margin-top:1px; }
    .btn-view-details {
        padding:9px 16px; background:linear-gradient(135deg,#0D3B6E,#1565C0);
        color:#fff; border-radius:8px; text-decoration:none; font-size:.82rem;
        font-weight:700; white-space:nowrap; transition:all .2s; flex-shrink:0;
    }
    .btn-view-details:hover { background:linear-gradient(135deg,#1565C0,#1E88E5); transform:translateY(-1px); }

    /* Pagination */
    .pagination-wrap { text-align:center; margin-top:28px; }
    .pagination-info { font-size:.82rem; color:#64748B; margin-bottom:12px; }
    .btn-load-more {
        display:inline-flex; align-items:center; gap:8px;
        padding:12px 32px; background:linear-gradient(135deg,#0D3B6E,#1565C0);
        color:#fff; border-radius:10px; font-weight:700; font-size:.9rem;
        text-decoration:none; box-shadow:0 4px 15px rgba(21,101,192,.3); transition:all .2s;
    }
    .btn-load-more:hover { box-shadow:0 6px 24px rgba(21,101,192,.45); transform:translateY(-1px); }

    /* Empty state */
    .cat-empty {
        background:#fff; border-radius:14px; border:1px solid #E2E8F0;
        padding:48px 24px; text-align:center;
    }
    .cat-empty .em-icon { font-size:3rem; margin-bottom:12px; }
    .cat-empty h3 { font-size:1.1rem; font-weight:700; color:#1E293B; margin:0 0 8px; }
    .cat-empty p  { color:#64748B; font-size:.88rem; margin:0; }

    /* Mobile toggle button */
    .cat-filter-toggle {
        display:none; position:fixed; bottom:80px; left:16px;
        width:52px; height:52px; border-radius:50%;
        background:linear-gradient(135deg,#0D3B6E,#1565C0);
        color:#fff; border:none; cursor:pointer; z-index:9990;
        box-shadow:0 4px 20px rgba(13,59,110,.4); font-size:1.3rem;
        align-items:center; justify-content:center; transition:transform .2s;
    }
    .cat-filter-toggle:active { transform:scale(.92); }

    .cat-filter-overlay {
        display:none; position:fixed; inset:0;
        background:rgba(15,23,42,.55); z-index:9991;
    }
    .cat-filter-overlay.open { display:block; }

    /* Honeypot field (anti-bot) */
    .hp-field { display:none !important; visibility:hidden; }

    @media (max-width:1024px) {
        .cat-layout { grid-template-columns:1fr; }
        .cat-sidebar {
            display:none; position:fixed; bottom:70px; left:0; right:0; top:auto;
            width:100% !important; max-height:72vh; border-radius:20px 20px 0 0;
            z-index:9992; border:none; box-shadow:0 -6px 30px rgba(0,0,0,.18);
        }
        .cat-sidebar.open { display:block; }
        .cat-filter-toggle { display:flex; }
    }
    @media (max-width:640px) {
        .cat-hero-left h1 { font-size:1.4rem; }
        .brands-grid, .country-overview-grid { grid-template-columns:1fr; }
        .products-grid { grid-template-columns:1fr; }
        .cat-steps { gap:4px; }
        .cat-step-arrow { margin:0 2px; }
        .cat-layout { padding:16px 12px 60px; }
    }
    </style>
</head>

<body>
    <?php include 'includes/header-nav.php'; ?>
    <?php include_once 'includes/ad_display.php'; ?>
    <?php renderAds('header'); ?>

    <!-- Currency Bar -->
    <div class="currency-bar">
        <div class="currency-bar-inner">
            <span style="color:#92400E;font-weight:500;">Prices shown in:</span>
            <span class="currency-badge"><?= htmlspecialchars($currency_code) ?> (<?= htmlspecialchars($currency_symbol) ?>)</span>
            <span style="color:#B45309;font-size:.78rem;">· Exchange rate: 1 USD = <?= number_format($exchange_rate, 2) ?> <?= htmlspecialchars($currency_code) ?></span>
        </div>
    </div>

    <!-- Hero -->
    <div class="cat-hero">
        <div class="cat-hero-inner">
            <div class="cat-hero-row">
                <div class="cat-hero-left">
                    <h1>⚡ Solar Inverters</h1>
                    <p>Browse <?= number_format($total_inverters_all) ?> inverters from <?= $total_brands_all ?>+ brands across <?= count($origin_countries) ?> countries</p>
                </div>
                <div class="cat-hero-stats">
                    <div><span class="cat-stat-val"><?= number_format($total_inverters_all) ?></span><span class="cat-stat-lbl">Inverters</span></div>
                    <div><span class="cat-stat-val"><?= $total_brands_all ?>+</span><span class="cat-stat-lbl">Brands</span></div>
                    <div><span class="cat-stat-val"><?= count($origin_countries) ?></span><span class="cat-stat-lbl">Countries</span></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Breadcrumb -->
    <div class="cat-breadcrumb">
        <div class="cat-breadcrumb-inner">
            <a href="<?= BASE_URL ?>">Home</a>
            <span class="sep">/</span>
            <a href="<?= BASE_URL ?>inverters.php">Inverters</a>
            <?php if ($origin_country): ?>
                <span class="sep">/</span>
                <a href="<?= BASE_URL ?>inverters.php?country=<?= urlencode($origin_country) ?>"><?= htmlspecialchars($origin_country) ?></a>
            <?php endif; ?>
            <?php if ($brand_name): ?>
                <span class="sep">/</span>
                <span class="cur"><?= htmlspecialchars($brand_name) ?></span>
            <?php endif; ?>
        </div>
    </div>

    <!-- Mobile Filter Button -->
    <button class="cat-filter-toggle" id="catFilterToggle" aria-label="Open filters">&#9776;</button>
    <div class="cat-filter-overlay" id="catFilterOverlay"></div>

    <!-- Main Layout -->
    <div class="cat-layout">

        <!-- ═══ SIDEBAR ═══ -->
        <aside class="cat-sidebar" id="catSidebar">

            <!-- Search (always visible) -->
            <div class="sb-search">
                <form method="GET" action="<?= BASE_URL ?>inverters.php">
                    <?php if ($origin_country): ?><input type="hidden" name="country" value="<?= htmlspecialchars($origin_country) ?>"><?php endif; ?>
                    <?php if ($company_id): ?><input type="hidden" name="company" value="<?= $company_id ?>"><?php endif; ?>
                    <!-- Honeypot anti-bot field -->
                    <input type="text" name="website_url" class="hp-field" tabindex="-1" autocomplete="off">
                    <div class="sb-search-wrap">
                        <span class="sb-search-icon">&#128269;</span>
                        <input type="text" name="search" placeholder="Search inverters..." value="<?= htmlspecialchars($search) ?>" autocomplete="off">
                    </div>
                </form>
            </div>

            <!-- Step indicator -->
            <div style="padding:14px 16px;background:#F8FAFC;border-bottom:1px solid #F1F5F9;">
                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                    <div style="display:flex;align-items:center;gap:5px;">
                        <span style="width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:800;flex-shrink:0;<?= $state==='countries'?'background:#FBBF24;color:#1E293B;':($origin_country?'background:#059669;color:#fff;':'background:#F1F5F9;color:#94A3B8;') ?>">1</span>
                        <span style="font-size:.75rem;font-weight:600;color:<?= $origin_country?'#059669':'#1E293B' ?>;">Country</span>
                    </div>
                    <span style="color:#CBD5E1;font-size:.9rem;">›</span>
                    <div style="display:flex;align-items:center;gap:5px;">
                        <span style="width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:800;flex-shrink:0;<?= $state==='brands'?'background:#FBBF24;color:#1E293B;':($brand_name?'background:#059669;color:#fff;':'background:#F1F5F9;color:#94A3B8;') ?>">2</span>
                        <span style="font-size:.75rem;font-weight:600;color:<?= $brand_name?'#059669':($origin_country?'#1E293B':'#94A3B8') ?>;">Brand</span>
                    </div>
                    <span style="color:#CBD5E1;font-size:.9rem;">›</span>
                    <div style="display:flex;align-items:center;gap:5px;">
                        <span style="width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:800;flex-shrink:0;<?= $state==='products'?'background:#FBBF24;color:#1E293B;':'background:#F1F5F9;color:#94A3B8;' ?>">3</span>
                        <span style="font-size:.75rem;font-weight:600;color:<?= $state==='products'?'#1E293B':'#94A3B8' ?>;">Products</span>
                    </div>
                </div>
            </div>

            <!-- Countries section -->
            <div class="sb-section">
                <div class="sb-section-head" onclick="toggleSection(this)">
                    <span class="sb-section-title">&#127760; Manufacturing Country</span>
                    <span class="sb-section-badge <?= $origin_country ? 'active' : '' ?>"><?= count($origin_countries) ?></span>
                </div>
                <div class="sb-section-body">
                    <a class="sb-country-item <?= !$origin_country ? 'active' : '' ?>" href="<?= BASE_URL ?>inverters.php">
                        <span class="sb-flag">&#127758;</span>
                        <span class="sb-name">All Countries</span>
                        <span class="sb-cnt"><?= number_format($total_inverters_all) ?></span>
                    </a>
                    <?php
                    $show_countries = array_slice($origin_countries, 0, 15);
                    $more_countries = array_slice($origin_countries, 15);
                    foreach ($show_countries as $oc):
                        $is_active = (strtolower($origin_country) === strtolower($oc['name']));
                    ?>
                    <a class="sb-country-item <?= $is_active ? 'active' : '' ?>"
                       href="<?= BASE_URL ?>inverters.php?country=<?= urlencode($oc['name']) ?>">
                        <span class="sb-flag"><?= get_country_flag($oc, 18) ?></span>
                        <span class="sb-name"><?= htmlspecialchars($oc['name']) ?></span>
                        <span class="sb-cnt"><?= (int)$oc['product_count'] ?></span>
                    </a>
                    <?php endforeach; ?>
                    <?php if (!empty($more_countries)): ?>
                    <div id="moreCountries" style="display:none;">
                        <?php foreach ($more_countries as $oc):
                            $is_active = (strtolower($origin_country) === strtolower($oc['name']));
                        ?>
                        <a class="sb-country-item <?= $is_active ? 'active' : '' ?>"
                           href="<?= BASE_URL ?>inverters.php?country=<?= urlencode($oc['name']) ?>">
                            <span class="sb-flag"><?= get_country_flag($oc, 18) ?></span>
                            <span class="sb-name"><?= htmlspecialchars($oc['name']) ?></span>
                            <span class="sb-cnt"><?= (int)$oc['product_count'] ?></span>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <a class="sb-show-more" id="showMoreCountries" onclick="showMoreCountries(event)">
                        + <?= count($more_countries) ?> more countries
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Companies section (shown when country selected) -->
            <?php if ($origin_country && !empty($company_cards)): ?>
            <div class="sb-section">
                <div class="sb-section-head" onclick="toggleSection(this)">
                    <span class="sb-section-title">&#127970; Brands in <?= htmlspecialchars($origin_country) ?></span>
                    <span class="sb-section-badge active"><?= count($company_cards) ?></span>
                </div>
                <div class="sb-section-body">
                    <?php
                    $show_companies = array_slice($company_cards, 0, 12);
                    $more_companies = array_slice($company_cards, 12);
                    foreach ($show_companies as $cc):
                        $is_active_co = ($company_id === (int)$cc['id']);
                    ?>
                    <a class="sb-company-item <?= $is_active_co ? 'active' : '' ?>"
                       href="<?= BASE_URL ?>inverters.php?country=<?= urlencode($origin_country) ?>&company=<?= (int)$cc['id'] ?>#products">
                        <div class="sb-company-logo">
                            <?php if (!empty($cc['logo_path'])): ?>
                                <img src="<?= htmlspecialchars(get_image_url($cc['logo_path'])) ?>" alt="<?= htmlspecialchars($cc['name']) ?>" loading="lazy">
                            <?php else: ?>
                                <span class="sb-logo-icon">&#9889;</span>
                            <?php endif; ?>
                        </div>
                        <span class="sb-name"><?= htmlspecialchars($cc['name']) ?></span>
                        <span class="sb-cnt"><?= (int)$cc['inverter_count'] ?></span>
                    </a>
                    <?php endforeach; ?>
                    <?php if (!empty($more_companies)): ?>
                    <div id="moreCompanies" style="display:none;">
                        <?php foreach ($more_companies as $cc):
                            $is_active_co = ($company_id === (int)$cc['id']);
                        ?>
                        <a class="sb-company-item <?= $is_active_co ? 'active' : '' ?>"
                           href="<?= BASE_URL ?>inverters.php?country=<?= urlencode($origin_country) ?>&company=<?= (int)$cc['id'] ?>#products">
                            <div class="sb-company-logo">
                                <?php if (!empty($cc['logo_path'])): ?>
                                    <img src="<?= htmlspecialchars(get_image_url($cc['logo_path'])) ?>" alt="<?= htmlspecialchars($cc['name']) ?>" loading="lazy">
                                <?php else: ?>
                                    <span class="sb-logo-icon">&#9889;</span>
                                <?php endif; ?>
                            </div>
                            <span class="sb-name"><?= htmlspecialchars($cc['name']) ?></span>
                            <span class="sb-cnt"><?= (int)$cc['inverter_count'] ?></span>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <a class="sb-show-more" id="showMoreCompanies" onclick="showMoreCompanies(event)">
                        + <?= count($more_companies) ?> more brands
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Filters section (shown when company selected) -->
            <?php if ($company_id): ?>
            <div class="sb-section">
                <div class="sb-section-head" onclick="toggleSection(this)">
                    <span class="sb-section-title">&#127775; Filter Inverters</span>
                    <?php if ($has_filters): ?>
                    <span class="sb-section-badge active"><?= count($active_filters) ?> active</span>
                    <?php endif; ?>
                </div>
                <div class="sb-section-body">
                    <form method="GET" action="<?= BASE_URL ?>inverters.php" id="sidebarFilterForm">
                        <input type="hidden" name="country" value="<?= htmlspecialchars($origin_country) ?>">
                        <input type="hidden" name="company" value="<?= $company_id ?>">
                        <!-- Honeypot -->
                        <input type="text" name="website_url" class="hp-field" tabindex="-1" autocomplete="off">

                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#128269; Search</label>
                            <input type="text" name="search" class="sb-filter-input" placeholder="Search models..." value="<?= htmlspecialchars($search) ?>">
                        </div>

                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#128268; Type</label>
                            <select name="type" class="sb-filter-select">
                                <option value="">All Types</option>
                                <option value="Hybrid"        <?= $type==='Hybrid'        ? 'selected':'' ?>>Hybrid</option>
                                <option value="On-Grid"       <?= $type==='On-Grid'       ? 'selected':'' ?>>On-Grid</option>
                                <option value="Off-Grid"      <?= $type==='Off-Grid'       ? 'selected':'' ?>>Off-Grid</option>
                                <option value="Microinverter" <?= $type==='Microinverter' ? 'selected':'' ?>>Microinverter</option>
                            </select>
                        </div>

                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#128267; Battery Voltage</label>
                            <select name="voltage" class="sb-filter-select">
                                <option value="">All Voltages</option>
                                <option value="12V" <?= $voltage==='12V' ? 'selected':'' ?>>12V</option>
                                <option value="24V" <?= $voltage==='24V' ? 'selected':'' ?>>24V</option>
                                <option value="48V" <?= $voltage==='48V' ? 'selected':'' ?>>48V</option>
                            </select>
                        </div>

                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#128176; Price Range (USD)</label>
                            <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:6px;align-items:center;">
                                <input type="number" name="min_price" class="sb-filter-input" placeholder="Min" value="<?= htmlspecialchars($min_price) ?>" min="0" step="10">
                                <span style="color:#94A3B8;font-size:.8rem;text-align:center;">–</span>
                                <input type="number" name="max_price" class="sb-filter-input" placeholder="Max" value="<?= htmlspecialchars($max_price) ?>" min="0" step="10">
                            </div>
                        </div>

                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#9889; Power Range (W)</label>
                            <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:6px;align-items:center;">
                                <input type="number" name="min_watts" class="sb-filter-input" placeholder="Min" value="<?= htmlspecialchars($min_watts) ?>" min="0" step="100">
                                <span style="color:#94A3B8;font-size:.8rem;text-align:center;">–</span>
                                <input type="number" name="max_watts" class="sb-filter-input" placeholder="Max" value="<?= htmlspecialchars($max_watts) ?>" min="0" step="100">
                            </div>
                        </div>

                        <div class="sb-filter-row">
                            <label class="sb-filter-label">&#128196; Sort By</label>
                            <select name="sort" class="sb-filter-select">
                                <option value="price_asc"  <?= $sort==='price_asc'  ? 'selected':'' ?>>Price: Low → High</option>
                                <option value="price_desc" <?= $sort==='price_desc' ? 'selected':'' ?>>Price: High → Low</option>
                                <option value="watts_asc"  <?= $sort==='watts_asc'  ? 'selected':'' ?>>Power: Low → High</option>
                                <option value="watts_desc" <?= $sort==='watts_desc' ? 'selected':'' ?>>Power: High → Low</option>
                                <option value="name"       <?= $sort==='name'       ? 'selected':'' ?>>Name: A → Z</option>
                            </select>
                        </div>

                        <div class="sb-filter-row">
                            <button type="submit" class="sb-filter-apply">Apply Filters</button>
                            <?php if ($has_filters): ?>
                            <a href="<?= BASE_URL ?>inverters.php?country=<?= urlencode($origin_country) ?>&company=<?= $company_id ?>" class="sb-filter-clear">✕ Clear all filters</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>

            <div class="sb-bottom-pad"></div>
        </aside>
        <!-- /SIDEBAR -->

        <!-- ═══ MAIN CONTENT ═══ -->
        <main class="cat-main" id="products">

            <?php if ($state === 'countries'): ?>
            <!-- STATE 1: No country selected → welcome guide + country cards -->
            <div class="cat-guide">
                <h2>Browse Solar Inverters</h2>
                <p>Select a manufacturing country from the left sidebar, then choose a brand to view all available inverters.</p>
                <div class="cat-steps">
                    <div class="cat-step">
                        <span class="cat-step-num cur">1</span>
                        <span class="cat-step-text">Select Country</span>
                    </div>
                    <span class="cat-step-arrow">→</span>
                    <div class="cat-step">
                        <span class="cat-step-num todo">2</span>
                        <span class="cat-step-text">Choose Brand</span>
                    </div>
                    <span class="cat-step-arrow">→</span>
                    <div class="cat-step">
                        <span class="cat-step-num todo">3</span>
                        <span class="cat-step-text">View Products</span>
                    </div>
                </div>
            </div>

            <p class="cat-overview-title">&#127760; Top Manufacturing Countries</p>
            <div class="country-overview-grid">
                <?php foreach (array_slice($origin_countries, 0, 18) as $oc): ?>
                <a class="country-ov-card" href="<?= BASE_URL ?>inverters.php?country=<?= urlencode($oc['name']) ?>">
                    <span class="country-ov-flag"><?= get_country_flag($oc, 32) ?></span>
                    <div class="country-ov-info">
                        <div class="ov-name"><?= htmlspecialchars($oc['name']) ?></div>
                        <div class="ov-cnt">⚡ <?= (int)$oc['product_count'] ?> inverters</div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>

            <?php elseif ($state === 'brands'): ?>
            <!-- STATE 2: Country selected → company cards grid -->
            <div class="brands-grid-title">
                <h2>Brands from <?= htmlspecialchars($origin_country) ?></h2>
                <span class="badge"><?= count($company_cards) ?> brands</span>
            </div>

            <?php if (empty($company_cards)): ?>
            <div class="cat-empty">
                <div class="em-icon">&#128269;</div>
                <h3>No brands found</h3>
                <p>No inverter brands found for "<?= htmlspecialchars($origin_country) ?>". Please select a different country.</p>
            </div>
            <?php else: ?>
            <div class="brands-grid">
                <?php foreach ($company_cards as $cc): ?>
                <a class="brand-card" href="<?= BASE_URL ?>inverters.php?country=<?= urlencode($origin_country) ?>&company=<?= (int)$cc['id'] ?>#products">
                    <div class="brand-card-logo">
                        <?php if (!empty($cc['logo_path'])): ?>
                            <img src="<?= htmlspecialchars(get_image_url($cc['logo_path'])) ?>" alt="<?= htmlspecialchars($cc['name']) ?>" loading="lazy">
                        <?php else: ?>
                            <span style="font-size:1.4rem;color:#94A3B8;">&#9889;</span>
                        <?php endif; ?>
                    </div>
                    <div class="brand-card-info">
                        <div class="brand-card-name"><?= htmlspecialchars($cc['name']) ?></div>
                        <div class="brand-card-meta"><?= (int)$cc['inverter_count'] ?> inverters</div>
                        <div class="brand-card-price">
                            <span class="sg-price" data-v="<?= encP($cc['min_price'], $_pk) ?>" data-r="<?= $exchange_rate ?>" data-s="<?= htmlspecialchars($currency_symbol) ?>">—</span>
                            –
                            <span class="sg-price" data-v="<?= encP($cc['max_price'], $_pk) ?>" data-r="<?= $exchange_rate ?>" data-s="<?= htmlspecialchars($currency_symbol) ?>">—</span>
                        </div>
                    </div>
                    <span class="brand-card-arrow">→</span>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php elseif ($state === 'products'): ?>
            <!-- STATE 3: Company selected → products grid -->

            <!-- Products header bar -->
            <div class="products-header">
                <div>
                    <h2>
                        <?= htmlspecialchars($brand_name) ?> Inverters
                        <span style="color:#64748B;font-weight:400;font-size:.88rem;">(<?= number_format($total) ?>)</span>
                    </h2>
                    <?php if ($has_filters): ?>
                    <div class="ph-meta">
                        &#10003; Filters active ·
                        <?php if ($search)    echo 'Search: "' . htmlspecialchars($search) . '" · '; ?>
                        <?php if ($type)      echo 'Type: ' . htmlspecialchars($type) . ' · '; ?>
                        <?php if ($voltage)   echo 'Voltage: ' . htmlspecialchars($voltage) . ' · '; ?>
                        <a href="<?= BASE_URL ?>inverters.php?country=<?= urlencode($origin_country) ?>&company=<?= $company_id ?>" style="color:#EF4444;font-weight:600;text-decoration:none;">Clear</a>
                    </div>
                    <?php endif; ?>
                </div>
                <select class="sort-select" onchange="applySort(this.value)">
                    <option value="price_asc"  <?= $sort==='price_asc'  ? 'selected':'' ?>>Price ↑</option>
                    <option value="price_desc" <?= $sort==='price_desc' ? 'selected':'' ?>>Price ↓</option>
                    <option value="watts_asc"  <?= $sort==='watts_asc'  ? 'selected':'' ?>>Power ↑</option>
                    <option value="watts_desc" <?= $sort==='watts_desc' ? 'selected':'' ?>>Power ↓</option>
                    <option value="name"       <?= $sort==='name'       ? 'selected':'' ?>>Name A→Z</option>
                </select>
            </div>

            <?php if (empty($inverters)): ?>
            <div class="cat-empty">
                <div class="em-icon">&#128269;</div>
                <h3>No inverters found</h3>
                <p>Try adjusting or clearing your filters.</p>
            </div>
            <?php else: ?>

            <!-- Product Cards -->
            <div class="products-grid" id="productsGrid">
                <?php foreach ($inverters as $idx => $inv):
                    if ($idx > 0 && $idx % 6 === 0) echo getInlineAdHtml('sidebar');
                    $local_price  = toLocal($inv['unit_price_usd'], $exchange_rate);
                    $badge_label  = !empty($inv['type']) ? htmlspecialchars($inv['type']) : 'Standard';
                    $badge_class  = strtolower(preg_replace('/[^a-z]/i', '', $inv['type'] ?? 'standard'));
                    $image_url    = !empty($inv['image_path']) ? get_image_url($inv['image_path']) : '';
                    $price_per_w  = ($inv['output_power_w'] > 0 && $inv['unit_price_usd'] > 0)
                                    ? round($inv['unit_price_usd'] / $inv['output_power_w'], 3) : 0;

                    // Voltage display logic
                    $inv_type_lower  = strtolower($inv['type'] ?? '');
                    $voltage_label   = 'Battery';
                    $voltage_display = 'N/A';
                    if (strpos($inv_type_lower, 'on-grid') !== false || strpos($inv_type_lower, 'grid-tie') !== false) {
                        $voltage_label = 'PV Input';
                        if (!empty($inv['min_pv_voltage']) && !empty($inv['max_pv_voltage']))
                            $voltage_display = $inv['min_pv_voltage'] . '-' . $inv['max_pv_voltage'] . 'V';
                    } else {
                        if (!empty($inv['battery_voltage_range']))
                            $voltage_display = htmlspecialchars($inv['battery_voltage_range']);
                        elseif (!empty($inv['min_pv_voltage']) && !empty($inv['max_pv_voltage'])) {
                            $voltage_label   = 'PV Input';
                            $voltage_display = $inv['min_pv_voltage'] . '-' . $inv['max_pv_voltage'] . 'V';
                        }
                    }
                ?>
                <div class="product-card" data-id="<?= (int)$inv['id'] ?>">
                    <div class="product-card-top">
                        <span class="product-badge <?= $badge_class ?>"><?= $badge_label ?></span>
                        <label class="compare-toggle" title="Add to Compare">
                            <input type="checkbox" onchange="toggleCompare(<?= (int)$inv['id'] ?>,'inverter','<?= htmlspecialchars(addslashes($inv['model']), ENT_QUOTES) ?>')">
                            <span class="compare-toggle-icon">
                                <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                    <polyline points="9 11 12 14 22 4"/>
                                    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
                                </svg>
                            </span>
                        </label>
                    </div>

                    <div class="product-image">
                        <?php if ($image_url): ?>
                            <img src="<?= htmlspecialchars($image_url) ?>" alt="<?= htmlspecialchars($inv['model']) ?>" loading="lazy">
                        <?php else: ?>
                            <div class="product-image-placeholder"><span>&#9889;</span></div>
                        <?php endif; ?>
                    </div>

                    <div class="product-info">
                        <div class="product-brand">
                            <?php if (!empty($inv['origin_flag']) || !empty($inv['origin_flag_icon']) || !empty($inv['origin_code'])): ?>
                                <span><?= get_country_flag(['flag_emoji'=>$inv['origin_flag']??'','flag_icon'=>$inv['origin_flag_icon']??'','code'=>$inv['origin_code']??''], 16) ?></span>
                            <?php endif; ?>
                            <?= htmlspecialchars($inv['company_name'] ?? '') ?>
                        </div>
                        <h3 class="product-name">
                            <a href="<?= BASE_URL ?>inverter-detail.php?id=<?= (int)$inv['id'] ?>"><?= htmlspecialchars($inv['model']) ?></a>
                        </h3>
                        <div class="product-specs-grid">
                            <div class="spec-pill">
                                <span class="spec-pill-icon">&#9889;</span>
                                <div>
                                    <span class="spec-pill-label">Power</span>
                                    <span class="spec-pill-value"><?= number_format($inv['output_power_w']) ?> W</span>
                                </div>
                            </div>
                            <div class="spec-pill">
                                <span class="spec-pill-icon">&#128268;</span>
                                <div>
                                    <span class="spec-pill-label">Type</span>
                                    <span class="spec-pill-value"><?= htmlspecialchars($inv['type'] ?? 'N/A') ?></span>
                                </div>
                            </div>
                            <div class="spec-pill">
                                <span class="spec-pill-icon">&#128267;</span>
                                <div>
                                    <span class="spec-pill-label"><?= $voltage_label ?></span>
                                    <span class="spec-pill-value"><?= $voltage_display ?></span>
                                </div>
                            </div>
                            <div class="spec-pill">
                                <span class="spec-pill-icon">&#128737;&#65039;</span>
                                <div>
                                    <span class="spec-pill-label">Warranty</span>
                                    <span class="spec-pill-value"><?= !empty($inv['warranty_years']) ? (int)$inv['warranty_years'] . ' yr' : 'N/A' ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="product-features">
                            <?php if (!empty($inv['three_phase']) && in_array($inv['three_phase'], ['Yes','1',1], true)): ?>
                                <span class="feature-tag" style="background:#DBEAFE;color:#1D4ED8;">3&#934;</span>
                            <?php else: ?>
                                <span class="feature-tag">1&#934;</span>
                            <?php endif; ?>
                            <?php if (!empty($inv['mppt_count'])): ?>
                                <span class="feature-tag"><?= (int)$inv['mppt_count'] ?> MPPT</span>
                            <?php endif; ?>
                            <?php if (!empty($inv['wifi_monitoring'])): ?>
                                <span class="feature-tag" style="background:#DBEAFE;color:#1D4ED8;">WiFi</span>
                            <?php endif; ?>
                            <?php if (!empty($inv['ip_rating'])): ?>
                                <span class="feature-tag"><?= htmlspecialchars($inv['ip_rating']) ?></span>
                            <?php endif; ?>
                            <?php if (!empty($inv['max_parallel_units']) && $inv['max_parallel_units'] > 1): ?>
                                <span class="feature-tag" style="background:#059669;color:#fff;">&#8644; x<?= (int)$inv['max_parallel_units'] ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="product-footer">
                        <div class="product-price">
                            <!-- Price encoded — decoded by JS only (anti-scraping) -->
                            <span class="price-local sg-price"
                                  data-v="<?= encP($inv['unit_price_usd'], $_pk) ?>"
                                  data-r="<?= $exchange_rate ?>"
                                  data-s="<?= htmlspecialchars($currency_symbol) ?>">—</span>
                            <?php if ($currency_code !== 'USD'): ?>
                                <span class="price-usd" data-usd="<?= encP($inv['unit_price_usd'], $_pk) ?>"></span>
                            <?php endif; ?>
                            <?php if ($price_per_w > 0): ?>
                                <span class="price-usd">$<?= number_format($price_per_w, 3) ?>/W</span>
                            <?php endif; ?>
                        </div>
                        <a href="<?= BASE_URL ?>inverter-detail.php?id=<?= (int)$inv['id'] ?>" class="btn-view-details">Details →</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php $qp = array_filter($_GET, fn($k) => $k !== 'page', ARRAY_FILTER_USE_KEY); ?>
            <div class="pagination-wrap">
                <p class="pagination-info">Showing <?= min($page_num * $per_page, $total) ?> of <?= number_format($total) ?> inverters</p>
                <?php if ($page_num < $total_pages): ?>
                <a href="?<?= http_build_query(array_merge($qp, ['page' => $page_num + 1])) ?>#products" class="btn-load-more">
                    Load More ↓
                </a>
                <?php endif; ?>
                <?php if ($total_pages > 1): ?>
                <div style="margin-top:16px;display:flex;justify-content:center;gap:6px;flex-wrap:wrap;">
                    <?php for ($p = 1; $p <= min($total_pages, 8); $p++): ?>
                    <a href="?<?= http_build_query(array_merge($qp, ['page' => $p])) ?>#products"
                       style="width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.82rem;font-weight:600;text-decoration:none;border:1.5px solid;<?= $p===$page_num?'background:#1565C0;color:#fff;border-color:#1565C0;':'background:#fff;color:#475569;border-color:#E2E8F0;' ?>">
                        <?= $p ?>
                    </a>
                    <?php endfor; ?>
                    <?php if ($total_pages > 8): ?>
                    <span style="color:#94A3B8;align-self:center;font-size:.85rem;">... <?= $total_pages ?> pages</span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; // end products state ?>

            <?php endif; // end state switch ?>

        </main>
        <!-- /MAIN CONTENT -->

    </div><!-- /cat-layout -->

    <?php renderAds('footer'); ?>
    <script src="assets/js/comparison-widget.js"></script>
    <script src="assets/js/products.js"></script>

    <script>
    // ─── Price Decoder (anti-scraping) ────────────────────────────────
    (function() {
        var k = <?= (int)$_pk ?>;
        var sym = '<?= addslashes($currency_symbol) ?>';
        var rate = <?= (float)$exchange_rate ?>;

        function decodePrice(enc) {
            if (!enc) return null;
            try {
                var pad = enc.length % 4 === 0 ? enc : enc + '==='.slice(0, 4 - enc.length % 4);
                var raw = atob(pad);
                var num = parseInt(raw, 10);
                if (isNaN(num)) return null;
                return num / (k * 100);
            } catch(e) { return null; }
        }

        function fmt(usd) {
            var local = Math.round(usd * rate);
            return sym + local.toLocaleString();
        }

        // Decode all price spans
        document.querySelectorAll('.sg-price[data-v]').forEach(function(el) {
            var usd = decodePrice(el.dataset.v);
            if (usd !== null) {
                var s  = el.dataset.s || sym;
                var r  = parseFloat(el.dataset.r) || rate;
                var lv = Math.round(usd * r);
                el.textContent = s + lv.toLocaleString();
            }
        });

        // Decode USD price sub-labels
        document.querySelectorAll('[data-usd]').forEach(function(el) {
            var usd = decodePrice(el.dataset.usd);
            if (usd !== null) el.textContent = '$' + Math.round(usd).toLocaleString() + ' USD';
        });
    })();

    // ─── Sort ─────────────────────────────────────────────────────────
    function applySort(v) {
        var u = new URL(location.href);
        u.searchParams.set('sort', v);
        u.searchParams.delete('page');
        u.hash = 'products';
        location.href = u;
    }

    // ─── Sidebar toggle (mobile) ──────────────────────────────────────
    var sidebar  = document.getElementById('catSidebar');
    var overlay  = document.getElementById('catFilterOverlay');
    var togBtn   = document.getElementById('catFilterToggle');

    if (togBtn) {
        togBtn.addEventListener('click', function() {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('open');
            document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : '';
        });
    }
    if (overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('open');
            overlay.classList.remove('open');
            document.body.style.overflow = '';
        });
    }

    // ─── Sidebar section collapse ─────────────────────────────────────
    function toggleSection(header) {
        var body = header.nextElementSibling;
        if (!body) return;
        var isCollapsed = body.style.display === 'none';
        body.style.display = isCollapsed ? '' : 'none';
    }

    // ─── Show more countries ──────────────────────────────────────────
    function showMoreCountries(e) {
        e.preventDefault();
        var el = document.getElementById('moreCountries');
        var btn = document.getElementById('showMoreCountries');
        if (el) { el.style.display = ''; if (btn) btn.style.display = 'none'; }
    }

    // ─── Show more companies ──────────────────────────────────────────
    function showMoreCompanies(e) {
        e.preventDefault();
        var el = document.getElementById('moreCompanies');
        var btn = document.getElementById('showMoreCompanies');
        if (el) { el.style.display = ''; if (btn) btn.style.display = 'none'; }
    }

    // ─── Anti-scraping: detect headless browsers ──────────────────────
    (function() {
        var checks = [
            typeof window.chrome !== 'undefined' || typeof window.mozInnerScreenX !== 'undefined',
            navigator.webdriver === undefined || navigator.webdriver === false,
            screen.width > 0 && screen.height > 0,
            typeof window.outerWidth !== 'undefined' && window.outerWidth > 0
        ];
        // If it looks like a headless scraper, blur price data after a delay
        var realBrowser = checks.filter(Boolean).length >= 3;
        if (!realBrowser) {
            setTimeout(function() {
                document.querySelectorAll('.sg-price').forEach(function(el) { el.textContent = '—'; });
            }, 100);
        }
    })();
    </script>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
