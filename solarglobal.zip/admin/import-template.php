<?php
require_once __DIR__ . '/../includes/auth.php';

$type = $_GET['type'] ?? '';
$allowedTypes = ['inverter', 'battery', 'panel'];

if (!in_array($type, $allowedTypes)) {
    http_response_code(400);
    die('Invalid template type. Use ?type=inverter, ?type=battery, or ?type=panel');
}

$filename = "sample_{$type}_import.csv";

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$output = fopen('php://output', 'w');

if ($type === 'inverter') {
    // CSV: country, company, series_name, model, type, output_power_w, max_pv_input_w,
    // surge_power_w, max_dc_voltage, min_dc_voltage, mppt_count, dc_inputs, connectors,
    // price_per_watt, unit_price_usd, three_phase, output_ac_voltage_range, power_factor,
    // battery_voltage_range, bms, communication, max_efficiency, euro_efficiency, ip_rating,
    // cooling_method, display_type, operating_temperature, noise_level, weight_kg, dimensions,
    // warranty_years, supports_parallel, max_parallel_units
    fputcsv($output, [
        'country','company','series_name','model','type','output_power_w','max_pv_input_w',
        'surge_power_w','max_dc_voltage','min_dc_voltage','mppt_count','dc_inputs','connectors',
        'price_per_watt','unit_price_usd','three_phase','output_ac_voltage_range','power_factor',
        'battery_voltage_range','bms','communication','max_efficiency','euro_efficiency','ip_rating',
        'cooling_method','display_type','operating_temperature','noise_level','weight_kg','dimensions',
        'warranty_years','supports_parallel','max_parallel_units'
    ]);
    // Sample row 1: Residential hybrid
    fputcsv($output, [
        'China','Deye','SG03LP1','SUN-5K-SG03LP1','hybrid','5000','6500',
        '10000','500','120','2','4','MC4',
        '0.19','950.00','0','220-240V','1.0',
        '40-60V','Yes','RS485, WiFi','97.6','97.0','IP65',
        'Fan','LCD','-25~60C','<30dB','28.5','460x380x165mm',
        '10','Yes','6'
    ]);
    // Sample row 2: Commercial on-grid
    fputcsv($output, [
        'China','Sungrow','CX-P2','SG50CX-P2','on-grid','50000','75000',
        '50000','1100','200','5','10','MC4',
        '0.072','3600.00','1','380-415V','0.99',
        '','No','RS485, Ethernet','98.8','98.4','IP66',
        'Fan','LCD','-25~60C','<50dB','65.0','600x500x300mm',
        '10','No','1'
    ]);
    // Sample row 3: Off-grid
    fputcsv($output, [
        'China','Growatt','SPF','SPF 5000ES','off-grid','5000','5500',
        '10000','500','120','1','2','MC4',
        '0.14','700.00','0','230V','1.0',
        '48V','Yes','RS232','93.0','','IP21',
        'Fan','LCD','-10~50C','<45dB','15.0','460x380x165mm',
        '5','Yes','9'
    ]);
} elseif ($type === 'battery') {
    // CSV: country, brand, name, technology, nominal_voltage_v, capacity_kwh, nominal_energy_kwh, capacity_ah,
    // cycle_life, design_life, round_trip_efficiency, configuration, mounting_options,
    // max_parallel_units, ip_rating, cooling_method, communication, monitoring,
    // operating_temp, dimensions, weight_kg, price_per_kwh, price_unit_usd, warranty,
    // charge_voltage, discharge_voltage, max_charge_current, max_discharge_current,
    // depth_of_discharge, self_discharge, certifications, currency, available_regions, features, notes
    fputcsv($output, [
        'country','brand','name','technology','nominal_voltage_v','capacity_kwh','nominal_energy_kwh','capacity_ah',
        'cycle_life','design_life','round_trip_efficiency','configuration','mounting_options',
        'max_parallel_units','ip_rating','cooling_method','communication','monitoring',
        'operating_temp','dimensions','weight_kg','price_per_kwh','price_unit_usd','warranty',
        'charge_voltage','discharge_voltage','max_charge_current','max_discharge_current',
        'depth_of_discharge','self_discharge','certifications','currency','available_regions','features','notes'
    ]);
    // Sample row 1: Pylontech US3000C (LFP with all critical fields)
    fputcsv($output, [
        'China','Pylontech','US3000C 48V 3.55kWh','LFP','48','3.55','3.55','74',
        '6000','15 years','95.0','1P16S','Wall/Floor/Rack',
        '16','IP55','Natural','RS485, CAN','App, LED',
        '-10~50C','442x420x132mm','36.0','295.77','1050.00','10 years',
        '52.5V','44.5V','100','100',
        '90','<3.5%/month','IEC 62619, UN38.3','USD','global','Rack mount, stackable up to 16 units',''
    ]);
    // Sample row 2: BYD Battery-Box Premium HVS 5.1 (High Voltage)
    fputcsv($output, [
        'China','BYD','Battery-Box Premium HVS 5.1','LFP','51','5.12','5.12','100',
        '6000','15 years','97.0','HV Modular','Wall',
        '3','IP66','Natural','CAN, WiFi','FusionSolar App',
        '-10~55C','670x150x600mm','82.0','878.91','4500.00','10 years',
        '54V','45V','100','100',
        '95','<2%/month','IEC 62619, UN38.3','USD','global','Modular high voltage system, cobalt-free',''
    ]);
    // Sample row 3: Narada GEL 12V 200Ah (Lead-Acid)
    fputcsv($output, [
        'China','Narada','GEL 12V 200Ah','GEL Lead-Acid','12','2.4','2.4','200',
        '1500','8 years','80.0','2V cells x 6','Floor',
        '4','IP20','Natural','','None',
        '-10~45C','522x240x219mm','58.0','116.67','280.00','3 years',
        '14.4V','10.5V','40','100',
        '70','<5%/month','IEC 60896','USD','global','Deep cycle gel battery',''
    ]);
    // Sample row 4: LG RESU 10H Prime (Premium Lithium)
    fputcsv($output, [
        'South Korea','LG Energy','RESU 10H Prime','LFP','52','9.60','9.60','189',
        '6000','10 years','95.0','Integrated','Wall',
        '2','IP55','Natural','RS485','LG App',
        '-10~45C','452x226x649mm','97.0','572.92','5500.00','10 years',
        '58V','44V','100','100',
        '95','<3%/month','IEC 62619, UL1973','USD','global','Compact wall-mount, high efficiency',''
    ]);
} elseif ($type === 'panel') {
    // CSV: name, brand, country, technology, power_range, pmax_w, voc_v, isc_a,
    // cell_type, cell_count, cell_size, dimensions, weight_kg, price_per_watt,
    // price_actual, warranty_product, glass_type, glass_thickness, frame_type,
    // junction_box, connector, cable_spec
    fputcsv($output, [
        'name','brand','country','technology','power_range','pmax_w','voc_v','isc_a',
        'cell_type','cell_count','cell_size','dimensions','weight_kg','price_per_watt',
        'price_actual','warranty_product','glass_type','glass_thickness','frame_type',
        'junction_box','connector','cable_spec'
    ]);
    // Sample row 1: N-type TOPCon
    fputcsv($output, [
        'Tiger Neo 580W','JinkoSolar','China','N-type Mono','575-590W','580','51.52','13.90',
        'N-type','144','182mm','2278x1134x30mm','28.8','0.31',
        '180.00','12 years','Tempered Glass','3.2mm','Anodized Aluminium',
        'IP68','MC4','4mm2, 1200mm'
    ]);
    // Sample row 2: Bifacial
    fputcsv($output, [
        'Hi-MO 7 600W','LONGi','China','N-type Bifacial','595-610W','600','52.40','14.10',
        'N-type HJT','144','182mm','2278x1134x30mm','29.5','0.34',
        '205.00','15 years','Dual Glass','2.0mm','Anodized Aluminium',
        'IP68','MC4 EVO2','4mm2, 1200mm'
    ]);
    // Sample row 3: Budget poly
    fputcsv($output, [
        'JAP72S10 340W','JA Solar','China','Polycrystalline','335-345W','340','40.20','10.75',
        'Poly','72','156mm','1960x992x35mm','22.2','0.23',
        '78.00','10 years','Tempered Glass','3.2mm','Anodized Aluminium',
        'IP67','MC4','4mm2, 1000mm'
    ]);
}

fclose($output);
exit;
