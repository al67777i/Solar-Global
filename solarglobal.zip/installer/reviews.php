<?php
/**
 * Installer Reviews Page (Read-only)
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/installer_auth.php';

set_security_headers();
require_installer_login();

$installer = get_installer_profile();
$db = getDB();

// Filter by rating
$filter_rating = isset($_GET['rating']) ? (int)$_GET['rating'] : 0;

// Get reviews
$sql = "SELECT * FROM installer_reviews WHERE installer_id = ?";
$params = [$installer['id']];

if ($filter_rating >= 1 && $filter_rating <= 5) {
    $sql .= " AND rating = ?";
    $params[] = $filter_rating;
}

$sql .= " ORDER BY created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$reviews = $stmt->fetchAll();

// Stats
$stmt = $db->prepare("SELECT COUNT(*) as cnt, COALESCE(AVG(rating), 0) as avg_rating FROM installer_reviews WHERE installer_id = ?");
$stmt->execute([$installer['id']]);
$stats = $stmt->fetch();
$total_reviews = (int)$stats['cnt'];
$avg_rating = round((float)$stats['avg_rating'], 1);

// Rating breakdown
$rating_breakdown = [];
for ($i = 5; $i >= 1; $i--) {
    $stmt = $db->prepare("SELECT COUNT(*) FROM installer_reviews WHERE installer_id = ? AND rating = ?");
    $stmt->execute([$installer['id'], $i]);
    $rating_breakdown[$i] = (int)$stmt->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews - <?= sanitize($installer['business_name']) ?> | <?= get_system_setting('site_name', 'SolarGlobal') ?> Installer</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 260px;
            background: #0F172A; color: white; z-index: 100;
            display: flex; flex-direction: column; transition: transform 0.3s;
        }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid #1E293B; }
        .sidebar-header h2 { font-size: 1.25rem; font-weight: 800; color: #F59E0B; }
        .sidebar-header p { font-size: 0.75rem; color: #94A3B8; margin-top: 2px; }
        .sidebar-nav { flex: 1; padding: 16px 12px; overflow-y: auto; }
        .nav-section { margin-bottom: 24px; }
        .nav-section-title { font-size: 0.6875rem; text-transform: uppercase; letter-spacing: 1px; color: #475569; padding: 0 12px; margin-bottom: 8px; font-weight: 600; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 8px; color: #CBD5E1; text-decoration: none; font-size: 0.875rem; font-weight: 500; transition: all 0.2s; }
        .nav-item:hover { background: #1E293B; color: white; }
        .nav-item.active { background: #D97706; color: white; }
        .nav-item .icon { font-size: 1.125rem; width: 24px; text-align: center; }

        .main-content { margin-left: 260px; padding: 24px 32px; min-height: 100vh; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; }
        .top-bar h1 { font-size: 1.5rem; font-weight: 700; color: #1E293B; }

        .mobile-menu-btn { display: none; background: #0F172A; color: white; border: none; width: 40px; height: 40px; border-radius: 8px; font-size: 1.25rem; cursor: pointer; }

        /* Rating summary */
        .rating-summary {
            background: white; border-radius: 14px; padding: 32px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
            margin-bottom: 24px; display: flex; gap: 40px; align-items: center;
        }
        .rating-big { text-align: center; }
        .rating-big .r-number { font-size: 3rem; font-weight: 800; color: #1E293B; }
        .rating-big .r-stars { color: #F59E0B; font-size: 1.25rem; margin: 4px 0; }
        .rating-big .r-total { font-size: 0.875rem; color: #64748B; }

        .rating-bars { flex: 1; }
        .bar-row { display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }
        .bar-row .br-label { font-size: 0.8125rem; color: #64748B; min-width: 50px; }
        .bar-row .br-track { flex: 1; height: 8px; background: #E2E8F0; border-radius: 4px; overflow: hidden; }
        .bar-row .br-fill { height: 100%; background: #F59E0B; border-radius: 4px; transition: width 0.3s; }
        .bar-row .br-count { font-size: 0.8125rem; color: #94A3B8; min-width: 30px; text-align: right; }

        /* Filters */
        .filter-bar {
            display: flex; gap: 8px; margin-bottom: 24px; flex-wrap: wrap;
        }
        .filter-btn {
            padding: 8px 16px; border: 2px solid #E2E8F0; border-radius: 8px;
            background: white; color: #64748B; font-size: 0.8125rem; font-weight: 600;
            cursor: pointer; text-decoration: none; transition: all 0.2s;
        }
        .filter-btn:hover { border-color: #F59E0B; color: #D97706; }
        .filter-btn.active { border-color: #F59E0B; background: #FFFBEB; color: #D97706; }

        /* Review cards */
        .review-card {
            background: white; border-radius: 14px; padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
            margin-bottom: 16px;
        }
        .review-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px; }
        .reviewer-info .rv-name { font-weight: 700; font-size: 0.9375rem; color: #1E293B; }
        .reviewer-info .rv-date { font-size: 0.8125rem; color: #94A3B8; margin-top: 2px; }
        .review-stars { color: #F59E0B; font-size: 1rem; }
        .review-text { font-size: 0.9375rem; color: #475569; line-height: 1.6; }

        .empty-state {
            text-align: center; padding: 60px 24px; color: #94A3B8;
            background: white; border-radius: 14px; border: 1px solid #E2E8F0;
        }
        .empty-state .e-icon { font-size: 3rem; margin-bottom: 12px; }
        .empty-state p { font-size: 0.9375rem; }

        @media (max-width: 900px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .mobile-menu-btn { display: block; }
            .rating-summary { flex-direction: column; gap: 24px; }
        }
        .overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 90; }
        .overlay.active { display: block; }
    </style>
</head>
<body>
    <?php $current_installer_page = 'reviews'; include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="top-bar">
            <div>
                <button class="mobile-menu-btn" onclick="toggleSidebar()">&#9776;</button>
                <h1>Reviews</h1>
            </div>
        </div>

        <!-- Rating Summary -->
        <div class="rating-summary">
            <div class="rating-big">
                <div class="r-number"><?= $avg_rating > 0 ? $avg_rating : '--' ?></div>
                <div class="r-stars">
                    <?php if ($avg_rating > 0): ?>
                        <?= str_repeat('&#9733;', round($avg_rating)) ?><?= str_repeat('&#9734;', 5 - round($avg_rating)) ?>
                    <?php else: ?>
                        &#9734;&#9734;&#9734;&#9734;&#9734;
                    <?php endif; ?>
                </div>
                <div class="r-total"><?= $total_reviews ?> review<?= $total_reviews !== 1 ? 's' : '' ?></div>
            </div>
            <div class="rating-bars">
                <?php for ($i = 5; $i >= 1; $i--):
                    $pct = $total_reviews > 0 ? ($rating_breakdown[$i] / $total_reviews) * 100 : 0;
                ?>
                <div class="bar-row">
                    <span class="br-label"><?= $i ?> star</span>
                    <div class="br-track"><div class="br-fill" style="width:<?= $pct ?>%"></div></div>
                    <span class="br-count"><?= $rating_breakdown[$i] ?></span>
                </div>
                <?php endfor; ?>
            </div>
        </div>

        <!-- Filters -->
        <div class="filter-bar">
            <a href="reviews.php" class="filter-btn <?= $filter_rating === 0 ? 'active' : '' ?>">All</a>
            <?php for ($i = 5; $i >= 1; $i--): ?>
                <a href="reviews.php?rating=<?= $i ?>" class="filter-btn <?= $filter_rating === $i ? 'active' : '' ?>">
                    <?= $i ?> &#9733;
                </a>
            <?php endfor; ?>
        </div>

        <!-- Reviews List -->
        <?php if (empty($reviews)): ?>
            <div class="empty-state">
                <div class="e-icon">&#11088;</div>
                <p><?= $filter_rating ? 'No reviews with ' . $filter_rating . ' stars.' : 'No reviews yet. They will appear here once customers rate your service.' ?></p>
            </div>
        <?php else: ?>
            <?php foreach ($reviews as $review): ?>
                <div class="review-card">
                    <div class="review-header">
                        <div class="reviewer-info">
                            <div class="rv-name"><?= sanitize($review['reviewer_name'] ?? 'Anonymous') ?></div>
                            <div class="rv-date"><?= date('F d, Y', strtotime($review['created_at'])) ?></div>
                        </div>
                        <div class="review-stars">
                            <?= str_repeat('&#9733;', (int)$review['rating']) ?><?= str_repeat('&#9734;', 5 - (int)$review['rating']) ?>
                        </div>
                    </div>
                    <?php if (!empty($review['comment'])): ?>
                        <div class="review-text"><?= sanitize($review['comment']) ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </main>

</body>
</html>
