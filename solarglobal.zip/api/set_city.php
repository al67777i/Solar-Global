<?php
/**
 * Set City Session API
 * Stores selected city in PHP session for server-side calculations
 */

header('Content-Type: application/json; charset=utf-8');
session_start();

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/city_helper.php';
require_once __DIR__ . '/../includes/helpers.php';

if (!rate_limit('api_set_city', 30, 60)) { respond_rate_limited(); }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'POST required']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$cityId = (int)($input['city_id'] ?? 0);

if (!$cityId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'city_id required']);
    exit;
}

$city = getCityById($cityId);
if (!$city) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'City not found']);
    exit;
}

$_SESSION['selected_city_id'] = $cityId;
$_SESSION['selected_city_name'] = $city['name_en'];

$currentMonth = (int)date('n');
$sunData = getSunDataForCity($cityId, $currentMonth);
$season = getCurrentSeason();

echo json_encode([
    'success' => true,
    'city' => $city,
    'season' => $season,
    'sun_data' => $sunData
]);
