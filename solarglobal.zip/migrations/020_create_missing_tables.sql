-- =====================================================
-- Migration: Create missing tables for admin panel
-- Tables: custom_ads, visitor_stats, site_settings, system_settings, contact_messages
-- =====================================================

USE solars;

-- =====================================================
-- TABLE: custom_ads
-- =====================================================
CREATE TABLE IF NOT EXISTS custom_ads (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    image_path VARCHAR(500) NOT NULL,
    redirect_url VARCHAR(500) NOT NULL,
    position ENUM('header', 'sidebar', 'footer', 'popup', 'between-steps') DEFAULT 'sidebar',
    width INT DEFAULT 728,
    height INT DEFAULT 90,
    is_active TINYINT(1) DEFAULT 1,
    priority INT DEFAULT 0,
    impressions INT DEFAULT 0,
    clicks INT DEFAULT 0,
    start_date DATE DEFAULT NULL,
    end_date DATE DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_active (is_active),
    INDEX idx_position (position),
    INDEX idx_priority (priority)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: visitor_stats
-- =====================================================
CREATE TABLE IF NOT EXISTS visitor_stats (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ip_address VARCHAR(45) NOT NULL,
    user_agent TEXT,
    page_url VARCHAR(500),
    referer VARCHAR(500) DEFAULT '',
    location VARCHAR(255) DEFAULT '',
    device_type VARCHAR(20) DEFAULT 'desktop',
    browser VARCHAR(50) DEFAULT 'Other',
    os VARCHAR(50) DEFAULT 'Other',
    session_id VARCHAR(100) DEFAULT '',
    visit_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_visit_date (visit_date),
    INDEX idx_ip (ip_address),
    INDEX idx_device (device_type),
    INDEX idx_session (session_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: site_settings (used by settings.php)
-- =====================================================
CREATE TABLE IF NOT EXISTS site_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default settings
INSERT IGNORE INTO site_settings (setting_key, setting_value) VALUES
('site_name', 'SolarGlobal'),
('site_tagline', 'Smart Solar System Recommender'),
('contact_email', ''),
('contact_phone', ''),
('whatsapp_number', '');

-- =====================================================
-- TABLE: system_settings (used by seo.php)
-- =====================================================
CREATE TABLE IF NOT EXISTS system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default SEO settings
INSERT IGNORE INTO system_settings (setting_key, setting_value) VALUES
('site_domain', ''),
('meta_title_suffix', ' | SolarGlobal'),
('og_image', ''),
('google_analytics_id', '');

-- =====================================================
-- TABLE: contact_messages
-- =====================================================
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(200) NOT NULL,
    phone VARCHAR(30) DEFAULT '',
    subject VARCHAR(255) DEFAULT '',
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_read (is_read),
    INDEX idx_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
