-- SolarGlobal International Database Migration
-- Creates the solarglobal database with international brands and data

CREATE DATABASE IF NOT EXISTS `solarglobal` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `solarglobal`;

-- Admin Users
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_users` (`username`, `password_hash`) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Companies (International)
CREATE TABLE IF NOT EXISTS `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `logo_path` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `companies` (`name`, `slug`, `website`, `country`, `description`, `is_active`) VALUES
('Huawei', 'huawei', 'https://solar.huawei.com', 'China', 'Global leader in smart PV solutions', 1),
('SMA Solar', 'sma', 'https://www.sma.de', 'Germany', 'German engineering for solar inverters', 1),
('Fronius', 'fronius', 'https://www.fronius.com', 'Austria', 'Premium hybrid inverters', 1),
('SolarEdge', 'solaredge', 'https://www.solaredge.com', 'Israel', 'Smart energy solutions with optimizers', 1),
('Enphase', 'enphase', 'https://www.enphase.com', 'USA', 'Microinverter technology leader', 1),
('GoodWe', 'goodwe', 'https://www.goodwe.com', 'China', 'Reliable solar inverters worldwide', 1),
('Growatt', 'growatt', 'https://www.growatt.com', 'China', 'Cost-effective solar solutions', 1),
('Sungrow', 'sungrow', 'https://www.sungrowpower.com', 'China', 'Largest inverter manufacturer', 1),
('Tesla', 'tesla', 'https://www.tesla.com/powerwall', 'USA', 'Powerwall home battery systems', 1),
('BYD', 'byd', 'https://www.bydbatterybox.com', 'China', 'Battery Box premium energy storage', 1),
('LG Energy', 'lg-energy', 'https://www.lgessbattery.com', 'South Korea', 'RESU battery systems', 1),
('Pylontech', 'pylontech', 'https://www.pylontech.com.cn', 'China', 'Lithium battery storage', 1),
('Canadian Solar', 'canadian-solar', 'https://www.canadiansolar.com', 'Canada', 'Tier 1 solar panel manufacturer', 1),
('JA Solar', 'ja-solar', 'https://www.jasolar.com', 'China', 'High-efficiency solar panels', 1),
('Trina Solar', 'trina-solar', 'https://www.trinasolar.com', 'China', 'Vertex series premium panels', 1),
('LONGi', 'longi', 'https://www.longi.com', 'China', 'Hi-MO series monocrystalline panels', 1),
('Jinko Solar', 'jinko-solar', 'https://www.jinkosolar.com', 'China', 'Tiger series high-power panels', 1),
('REC Group', 'rec-group', 'https://www.recgroup.com', 'Norway', 'Premium European solar panels', 1),
('SunPower', 'sunpower', 'https://www.sunpower.com', 'USA', 'Maxeon cell technology', 1),
('Panasonic', 'panasonic', 'https://www.panasonic.com', 'Japan', 'EverVolt solar panels', 1),
('Q CELLS', 'qcells', 'https://www.q-cells.com', 'South Korea', 'German engineered Q.PEAK panels', 1),
('Victron Energy', 'victron', 'https://www.victronenergy.com', 'Netherlands', 'Off-grid and marine energy solutions', 1),
('Deye', 'deye', 'https://www.deyeinverter.com', 'China', 'Hybrid inverters for residential', 1),
('Fox ESS', 'foxess', 'https://www.fox-ess.com', 'China', 'Hybrid inverter and battery storage', 1),
('Sonnen', 'sonnen', 'https://sonnen.de', 'Germany', 'Premium German battery storage', 1),
('Generac', 'generac', 'https://www.generac.com', 'USA', 'PWRcell battery storage systems', 1),
('Alpha ESS', 'alpha-ess', 'https://www.alpha-ess.com', 'China', 'Residential energy storage', 1),
('Solax Power', 'solax', 'https://www.solaxpower.com', 'China', 'X-Hybrid series inverters', 1);

-- Appliances (International - no Urdu)
CREATE TABLE IF NOT EXISTS `appliances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(150) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `watt_typical` int(11) NOT NULL,
  `surge_load_watts` int(11) DEFAULT 0,
  `standby_watts` int(11) DEFAULT 0,
  `category` varchar(100) DEFAULT 'General',
  `season_tags` varchar(255) DEFAULT 'all_year',
  `usage_hours_summer` decimal(4,1) DEFAULT 4.0,
  `usage_hours_winter` decimal(4,1) DEFAULT 4.0,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `appliances` (`name_en`, `icon`, `watt_typical`, `surge_load_watts`, `standby_watts`, `category`, `season_tags`, `usage_hours_summer`, `usage_hours_winter`) VALUES
('LED Light (9W)', '💡', 9, 0, 0, 'Lighting', 'all_year', 6.0, 8.0),
('LED Light (15W)', '💡', 15, 0, 0, 'Lighting', 'all_year', 6.0, 8.0),
('Ceiling Fan', '🌀', 75, 150, 0, 'Cooling', 'summer', 12.0, 2.0),
('Standing Fan', '🌀', 55, 110, 0, 'Cooling', 'summer', 8.0, 0.0),
('Air Conditioner (1 Ton)', '❄️', 1200, 3600, 5, 'Cooling', 'summer', 8.0, 0.0),
('Air Conditioner (1.5 Ton)', '❄️', 1800, 5400, 5, 'Cooling', 'summer', 8.0, 0.0),
('Air Conditioner (2 Ton)', '❄️', 2400, 7200, 5, 'Cooling', 'summer', 8.0, 0.0),
('Refrigerator (Small)', '🧊', 100, 300, 5, 'Kitchen', 'all_year', 24.0, 24.0),
('Refrigerator (Large)', '🧊', 200, 600, 8, 'Kitchen', 'all_year', 24.0, 24.0),
('Washing Machine', '👕', 500, 1500, 3, 'Laundry', 'all_year', 1.0, 1.0),
('Clothes Dryer', '👔', 3000, 4500, 5, 'Laundry', 'all_year', 1.0, 1.5),
('Iron', '👔', 1200, 1500, 0, 'Laundry', 'all_year', 0.5, 0.5),
('TV (LED 32")', '📺', 40, 0, 3, 'Electronics', 'all_year', 5.0, 6.0),
('TV (LED 55")', '📺', 80, 0, 5, 'Electronics', 'all_year', 5.0, 6.0),
('Computer/Desktop', '💻', 250, 400, 5, 'Electronics', 'all_year', 6.0, 6.0),
('Laptop', '💻', 65, 0, 2, 'Electronics', 'all_year', 6.0, 6.0),
('WiFi Router', '📶', 15, 0, 0, 'Electronics', 'all_year', 24.0, 24.0),
('Microwave Oven', '🍳', 1200, 1500, 3, 'Kitchen', 'all_year', 0.5, 0.5),
('Electric Kettle', '☕', 1500, 1800, 0, 'Kitchen', 'all_year', 0.3, 0.5),
('Toaster', '🍞', 800, 1000, 0, 'Kitchen', 'all_year', 0.2, 0.2),
('Water Pump', '💧', 750, 2250, 0, 'Utility', 'all_year', 2.0, 1.5),
('Vacuum Cleaner', '🧹', 1200, 1800, 0, 'Utility', 'all_year', 0.5, 0.5),
('Security Camera System', '📷', 50, 0, 10, 'Electronics', 'all_year', 24.0, 24.0),
('Gaming Console', '🎮', 200, 0, 5, 'Electronics', 'all_year', 3.0, 4.0),
('Space Heater', '🔥', 1500, 1800, 0, 'Heating', 'winter', 0.0, 6.0),
('Water Heater (Tank)', '🚿', 3000, 3500, 10, 'Heating', 'winter', 0.0, 2.0),
('Hair Dryer', '💇', 1800, 2200, 0, 'Utility', 'all_year', 0.2, 0.2),
('Electric Oven', '🍕', 2000, 2500, 5, 'Kitchen', 'all_year', 1.0, 1.5),
('Dishwasher', '🍽️', 1800, 2400, 3, 'Kitchen', 'all_year', 1.0, 1.0),
('EV Charger (Level 2)', '🔌', 7200, 8000, 5, 'Utility', 'all_year', 4.0, 4.0),
('Heat Pump', '🌡️', 3500, 7000, 10, 'Heating', 'winter', 2.0, 8.0),
('Pool Pump', '🏊', 1500, 3000, 0, 'Utility', 'summer', 6.0, 2.0),
('Garage Door Opener', '🚗', 500, 1000, 5, 'Utility', 'all_year', 0.1, 0.1),
('Induction Cooktop', '🍳', 2000, 2500, 0, 'Kitchen', 'all_year', 1.5, 2.0),
('Chest Freezer', '🧊', 150, 450, 5, 'Kitchen', 'all_year', 24.0, 24.0),
('Dehumidifier', '💨', 500, 700, 3, 'Utility', 'summer,monsoon', 6.0, 2.0),
('Electric Blanket', '🛏️', 200, 0, 0, 'Heating', 'winter', 0.0, 8.0),
('Home Theater System', '🔊', 300, 0, 8, 'Electronics', 'all_year', 3.0, 4.0);

-- Inverters (International brands, USD pricing)
CREATE TABLE IF NOT EXISTS `inverters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `power_rating` int(11) NOT NULL COMMENT 'Watts',
  `type` enum('hybrid','on-grid','off-grid','microinverter') DEFAULT 'hybrid',
  `vdc_type` enum('48V','96V','HV','LV') DEFAULT '48V',
  `max_solar_input` int(11) DEFAULT NULL COMMENT 'Watts',
  `mppt_channels` int(11) DEFAULT 2,
  `efficiency` decimal(4,1) DEFAULT 97.0,
  `price_usd` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'USD',
  `available_regions` varchar(255) DEFAULT 'global',
  `image_path` varchar(255) DEFAULT NULL,
  `features` text DEFAULT NULL,
  `warranty_years` int(11) DEFAULT 5,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_power` (`power_rating`),
  KEY `idx_brand` (`brand`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inverters` (`name`, `brand`, `power_rating`, `type`, `vdc_type`, `max_solar_input`, `mppt_channels`, `efficiency`, `price_usd`, `available_regions`, `features`, `warranty_years`) VALUES
('SUN2000-3KTL-L1', 'Huawei', 3000, 'hybrid', 'HV', 5000, 2, 97.7, 1200.00, 'global', 'Smart string, AFCI, optimizer ready', 10),
('SUN2000-5KTL-L1', 'Huawei', 5000, 'hybrid', 'HV', 7500, 2, 97.7, 1600.00, 'global', 'Smart string, AFCI, optimizer ready', 10),
('SUN2000-8KTL-L1', 'Huawei', 8000, 'hybrid', 'HV', 12000, 2, 98.0, 2100.00, 'global', 'Smart string, 100A battery charge', 10),
('SUN2000-10KTL-M1', 'Huawei', 10000, 'hybrid', 'HV', 15000, 2, 98.2, 2600.00, 'global', 'Three phase, commercial grade', 10),
('Sunny Boy 5.0', 'SMA Solar', 5000, 'on-grid', 'HV', 7500, 2, 97.2, 1500.00, 'global', 'German engineering, SMA Smart Connected', 10),
('Sunny Tripower 8.0', 'SMA Solar', 8000, 'on-grid', 'HV', 12000, 2, 98.0, 2200.00, 'global', 'Three phase, commercial', 10),
('Symo GEN24 5.0 Plus', 'Fronius', 5000, 'hybrid', 'HV', 7500, 2, 97.6, 2000.00, 'global', 'Austrian quality, emergency power', 10),
('Symo GEN24 10.0 Plus', 'Fronius', 10000, 'hybrid', 'HV', 15000, 2, 97.8, 3200.00, 'global', 'Three phase, full backup', 10),
('SE5000H', 'SolarEdge', 5000, 'hybrid', 'HV', 8000, 1, 99.2, 1800.00, 'global', 'HD-Wave, optimizer based, 99.2% efficiency', 12),
('SE10000H', 'SolarEdge', 10000, 'hybrid', 'HV', 13500, 1, 99.2, 2800.00, 'global', 'HD-Wave, backup ready, optimized', 12),
('IQ8+', 'Enphase', 380, 'microinverter', 'LV', 440, 1, 97.5, 220.00, 'global', 'Microinverter, module-level optimization', 25),
('IQ8M', 'Enphase', 330, 'microinverter', 'LV', 400, 1, 97.5, 200.00, 'global', 'Microinverter, Sunlight Backup', 25),
('GW5000-ES', 'GoodWe', 5000, 'hybrid', '48V', 6500, 2, 97.0, 1100.00, 'global', 'ET series, backup capable', 5),
('GW8000-ET', 'GoodWe', 8000, 'hybrid', 'HV', 10400, 2, 97.8, 1800.00, 'global', 'ET Plus series, high voltage battery', 10),
('GW10K-ET', 'GoodWe', 10000, 'hybrid', 'HV', 13000, 2, 97.8, 2200.00, 'global', 'Three phase ET series', 10),
('MIN 5000TL-X', 'Growatt', 5000, 'hybrid', '48V', 6500, 2, 97.5, 900.00, 'global', 'Budget friendly, WiFi built-in', 5),
('SPH 8000TL3', 'Growatt', 8000, 'hybrid', 'HV', 12000, 2, 97.8, 1600.00, 'global', 'Three phase hybrid, ATS', 10),
('SPH 10000TL3', 'Growatt', 10000, 'hybrid', 'HV', 15000, 2, 97.8, 2000.00, 'global', 'Three phase, 200% PV oversizing', 10),
('SG5.0RS', 'Sungrow', 5000, 'hybrid', 'HV', 6500, 2, 97.7, 1300.00, 'global', 'Residential hybrid, built-in EMS', 10),
('SG10RT', 'Sungrow', 10000, 'hybrid', 'HV', 15000, 2, 98.5, 2400.00, 'global', 'Three phase, string-level monitoring', 10),
('SG12RT', 'Sungrow', 12000, 'hybrid', 'HV', 18000, 2, 98.5, 2900.00, 'global', 'Commercial three phase', 10),
('MultiPlus-II 48/5000', 'Victron Energy', 5000, 'off-grid', '48V', 7000, 1, 96.0, 2200.00, 'global', 'Off-grid king, marine rated, parallel capable', 5),
('Quattro-II 48/10000', 'Victron Energy', 10000, 'off-grid', '48V', 14000, 1, 96.0, 4000.00, 'global', 'Dual AC input, off-grid/marine', 5),
('SUN-5K-SG04LP1', 'Deye', 5000, 'hybrid', '48V', 6500, 2, 97.0, 850.00, 'global', 'Budget hybrid, parallel capable', 5),
('SUN-8K-SG01LP1', 'Deye', 8000, 'hybrid', '48V', 10400, 2, 97.5, 1400.00, 'global', 'High power LV battery', 5),
('SUN-12K-SG04LP3', 'Deye', 12000, 'hybrid', '48V', 18000, 2, 97.5, 2100.00, 'global', 'Three phase, 48V battery bank', 5),
('H1-5.0-E', 'Fox ESS', 5000, 'hybrid', 'HV', 6500, 2, 97.3, 1000.00, 'global', 'Compact hybrid, EPS backup', 10),
('X3-Hybrid-10.0-D', 'Solax Power', 10000, 'hybrid', 'HV', 15000, 2, 97.8, 2300.00, 'global', 'Three phase, dual MPPT', 10),
('X1-Hybrid-5.0-D', 'Solax Power', 5000, 'hybrid', 'HV', 7500, 2, 97.6, 1200.00, 'global', 'Single phase hybrid, compact', 10);

-- Batteries (International, USD)
CREATE TABLE IF NOT EXISTS `batteries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `capacity_ah` int(11) NOT NULL,
  `voltage` int(11) NOT NULL DEFAULT 48,
  `capacity_kwh` decimal(5,2) DEFAULT NULL,
  `type` enum('lithium','lfp','lead-acid','gel','agm') DEFAULT 'lfp',
  `is_bms` tinyint(1) DEFAULT 1,
  `cycle_life` int(11) DEFAULT 3000,
  `dod` decimal(3,2) DEFAULT 0.90 COMMENT 'Depth of discharge',
  `price_usd` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'USD',
  `available_regions` varchar(255) DEFAULT 'global',
  `image_path` varchar(255) DEFAULT NULL,
  `features` text DEFAULT NULL,
  `warranty_years` int(11) DEFAULT 10,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_capacity` (`capacity_ah`),
  KEY `idx_brand` (`brand`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `batteries` (`name`, `brand`, `capacity_ah`, `voltage`, `capacity_kwh`, `type`, `is_bms`, `cycle_life`, `dod`, `price_usd`, `available_regions`, `features`, `warranty_years`) VALUES
('Powerwall 2', 'Tesla', 280, 48, 13.50, 'lfp', 1, 5000, 1.00, 8500.00, 'global', 'Integrated inverter, liquid cooled, floor/wall mount', 10),
('Powerwall 3', 'Tesla', 280, 48, 13.50, 'lfp', 1, 6000, 1.00, 9500.00, 'global', 'Integrated solar inverter, 11.5kW continuous', 10),
('Battery-Box Premium HVS 5.1', 'BYD', 64, 200, 5.12, 'lfp', 1, 6000, 0.96, 3200.00, 'global', 'Modular, cobalt-free, rack mount', 10),
('Battery-Box Premium HVS 10.2', 'BYD', 128, 200, 10.24, 'lfp', 1, 6000, 0.96, 5800.00, 'global', 'Modular stackable, up to 3 towers', 10),
('Battery-Box Premium HVM 11.0', 'BYD', 138, 200, 11.04, 'lfp', 1, 6000, 0.96, 6200.00, 'global', 'High voltage modular, scalable', 10),
('RESU 10H Prime', 'LG Energy', 189, 52, 9.60, 'lfp', 1, 6000, 0.95, 5500.00, 'global', 'Compact wall-mount, high efficiency', 10),
('RESU 16H Prime', 'LG Energy', 300, 52, 16.00, 'lfp', 1, 6000, 0.95, 8000.00, 'global', 'Large capacity, floor standing', 10),
('US3000C', 'Pylontech', 74, 48, 3.55, 'lfp', 1, 6000, 0.90, 1200.00, 'global', 'Rack mount, stackable up to 16', 10),
('US5000', 'Pylontech', 100, 48, 4.80, 'lfp', 1, 6000, 0.90, 1600.00, 'global', 'Server rack, CAN/RS485 comms', 10),
('Force H2 10.65', 'Pylontech', 200, 48, 10.65, 'lfp', 1, 6000, 0.90, 4800.00, 'global', 'High voltage, outdoor rated IP55', 10),
('sonnenBatterie 10', 'Sonnen', 200, 48, 10.00, 'lfp', 1, 10000, 0.90, 12000.00, 'EU,US', 'German made, smart energy management', 10),
('PWRcell M6', 'Generac', 125, 48, 6.00, 'lfp', 1, 5000, 0.84, 4000.00, 'US', 'Modular, outdoor rated, Generac ecosystem', 10),
('SMILE-BAT-5.8P', 'Alpha ESS', 116, 50, 5.80, 'lfp', 1, 6000, 0.90, 3000.00, 'global', 'All-in-one with hybrid inverter', 10),
('SMILE-BAT-11.4P', 'Alpha ESS', 228, 50, 11.40, 'lfp', 1, 6000, 0.90, 5500.00, 'global', 'Expandable, fast charge/discharge', 10),
('Triple Power T-BAT H 5.8', 'Solax Power', 116, 50, 5.80, 'lfp', 1, 6000, 0.90, 2800.00, 'global', 'Compatible with Solax inverters', 10),
('Lynx Smart BMS 500', 'Victron Energy', 200, 48, 9.60, 'lfp', 1, 5000, 0.80, 3500.00, 'global', 'Marine grade, off-grid specialist', 5),
('SmartSolar Battery 48V 100Ah', 'Victron Energy', 100, 48, 4.80, 'lfp', 1, 5000, 0.80, 2200.00, 'global', 'Bluetooth monitoring, robust', 5),
('ECS Cube 5.0', 'Fox ESS', 100, 48, 5.00, 'lfp', 1, 6000, 0.90, 2500.00, 'global', 'Compatible with Fox inverters', 10),
('ECS Cube 10.0', 'Fox ESS', 200, 48, 10.00, 'lfp', 1, 6000, 0.90, 4500.00, 'global', 'Stackable, 10kWh per unit', 10),
('SBR128 (HV)', 'Sungrow', 128, 200, 12.80, 'lfp', 1, 6000, 0.90, 5000.00, 'global', 'High voltage rack battery, max 8 modules', 10);

-- Solar Panels (International, USD)
CREATE TABLE IF NOT EXISTS `panels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `wattage` int(11) NOT NULL,
  `type` enum('mono','poly','bifacial','thin-film') DEFAULT 'mono',
  `efficiency` decimal(4,1) DEFAULT 21.0,
  `dimensions` varchar(100) DEFAULT NULL,
  `weight_kg` decimal(4,1) DEFAULT NULL,
  `price_usd` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'USD',
  `available_regions` varchar(255) DEFAULT 'global',
  `image_path` varchar(255) DEFAULT NULL,
  `features` text DEFAULT NULL,
  `warranty_years` int(11) DEFAULT 25,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_wattage` (`wattage`),
  KEY `idx_brand` (`brand`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `panels` (`name`, `brand`, `wattage`, `type`, `efficiency`, `dimensions`, `weight_kg`, `price_usd`, `available_regions`, `features`, `warranty_years`) VALUES
('HiKu7 CS7L-595MS', 'Canadian Solar', 595, 'mono', 21.6, '2384x1303x35mm', 32.2, 185.00, 'global', 'TOPCon, 132 half-cells, low LID', 25),
('HiKu6 CS6R-420MS', 'Canadian Solar', 420, 'mono', 21.0, '1722x1134x30mm', 21.5, 145.00, 'global', 'PERC mono, 108 half-cells', 25),
('DeepBlue 4.0 Pro JAM72D42-580', 'JA Solar', 580, 'bifacial', 22.3, '2278x1134x30mm', 31.2, 175.00, 'global', 'N-type bifacial, 30yr warranty', 30),
('DeepBlue 3.0 JAM60S20-380', 'JA Solar', 380, 'mono', 20.7, '1722x1134x30mm', 21.0, 130.00, 'global', 'PERC mono, compact residential', 25),
('Vertex S+ NEG9RC.27 440W', 'Trina Solar', 440, 'mono', 22.2, '1762x1134x30mm', 21.8, 155.00, 'global', 'N-type i-TOPCon, 0.4%/yr degradation', 25),
('Vertex N 585W', 'Trina Solar', 585, 'bifacial', 22.4, '2384x1134x30mm', 30.8, 180.00, 'global', 'N-type bifacial, dual glass', 30),
('Hi-MO 6 LR5-54HTH 430W', 'LONGi', 430, 'mono', 22.0, '1722x1134x30mm', 21.0, 150.00, 'global', 'HPBC technology, anti-LID/PID', 25),
('Hi-MO X6 580W', 'LONGi', 580, 'bifacial', 22.5, '2278x1134x30mm', 30.5, 185.00, 'global', 'N-type HJT bifacial, premium', 30),
('Tiger Neo N-type 580W', 'Jinko Solar', 580, 'bifacial', 22.3, '2278x1134x30mm', 30.8, 170.00, 'global', 'N-type TOPCon, smash-proof', 30),
('Tiger Neo 440W', 'Jinko Solar', 440, 'mono', 22.0, '1762x1134x30mm', 22.0, 148.00, 'global', 'N-type residential, compact', 25),
('Alpha Series REC400AA', 'REC Group', 400, 'mono', 21.9, '1721x1016x30mm', 19.5, 280.00, 'EU,US', 'HJT cells, 92% at 25yrs, Norwegian design', 25),
('TwinPeak 5 REC430TP5', 'REC Group', 430, 'mono', 21.6, '1821x1016x30mm', 20.5, 300.00, 'EU,US', 'Split-cell, shade tolerant', 25),
('Maxeon 7 SPR-M430', 'SunPower', 430, 'mono', 22.8, '1812x1046x40mm', 21.5, 350.00, 'US,EU', 'IBC cells, 40yr useful life, best warranty', 40),
('Maxeon 6 SPR-M410', 'SunPower', 410, 'mono', 22.5, '1690x1046x40mm', 19.0, 320.00, 'US,EU', 'Performance series, IBC technology', 25),
('EverVolt EVPV-410HK', 'Panasonic', 410, 'mono', 21.7, '1722x1134x35mm', 22.0, 290.00, 'global', 'HJT cells, low temp coefficient', 25),
('Q.PEAK DUO BLK ML-G11+ 410', 'Q CELLS', 410, 'mono', 21.4, '1722x1134x32mm', 21.0, 220.00, 'global', 'Q.ANTUM DUO Z, German engineered', 25),
('Q.PEAK DUO ML-G11S+ 440', 'Q CELLS', 440, 'mono', 21.8, '1762x1134x32mm', 22.5, 240.00, 'global', 'Zero-gap cell layout, premium', 25),
('CS Ntype BiHiKu7 600W', 'Canadian Solar', 600, 'bifacial', 22.0, '2384x1303x35mm', 33.0, 195.00, 'global', 'N-type bifacial, utility scale', 30),
('Tiger Pro JKM545M-72HL4', 'Jinko Solar', 545, 'mono', 21.3, '2274x1134x35mm', 28.5, 160.00, 'global', 'TR technology, half-cut PERC', 25),
('Hi-MO 5 LR5-72HBD 540W', 'LONGi', 540, 'bifacial', 21.1, '2256x1133x35mm', 28.0, 165.00, 'global', 'Bifacial gallium-doped, M10 cells', 25);

-- User Locations (for saved preferences)
CREATE TABLE IF NOT EXISTS `user_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) NOT NULL,
  `latitude` decimal(8,4) NOT NULL,
  `longitude` decimal(9,4) NOT NULL,
  `location_name` varchar(200) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `country_code` varchar(5) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_coords` (`latitude`, `longitude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Solar Irradiance Cache
CREATE TABLE IF NOT EXISTS `solar_irradiance_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `latitude` decimal(6,2) NOT NULL,
  `longitude` decimal(7,2) NOT NULL,
  `avg_sun_hours` decimal(4,1) DEFAULT NULL,
  `avg_irradiance` decimal(5,2) DEFAULT NULL,
  `avg_temperature` decimal(4,1) DEFAULT NULL,
  `optimal_tilt` decimal(4,1) DEFAULT NULL,
  `fetched_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_coords` (`latitude`, `longitude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- System Settings
CREATE TABLE IF NOT EXISTS `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'SolarGlobal'),
('currency', 'USD'),
('currency_symbol', '$'),
('default_warranty_years', '10'),
('admin_email', 'info@solarglobal.com'),
('solar_degradation_rate', '0.5'),
('electricity_cost_per_kwh', '0.12');

-- Visitors tracking
CREATE TABLE IF NOT EXISTS `visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `page_url` varchar(500) DEFAULT NULL,
  `referrer` varchar(500) DEFAULT NULL,
  `visited_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_visited` (`visited_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ads table
CREATE TABLE IF NOT EXISTS `ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
