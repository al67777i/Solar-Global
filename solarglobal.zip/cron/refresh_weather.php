<?php
/**
 * Weather Cache Refresh Script
 * Run via cron or manually to pre-fetch weather for popular cities
 * Usage: php refresh_weather.php [--all] [--city=ID]
 */

require_once __DIR__ . '/../includes/WeatherService.php';

$weather = new WeatherService();

// Popular cities to always keep fresh
$popularCityIds = [1, 2, 3, 4, 5, 20, 21, 28, 38, 43]; // Lahore, Faisalabad, Rawalpindi, Multan, Gujranwala, Karachi, Hyderabad, Peshawar, Quetta, Islamabad

$mode = 'popular';
$specificCity = null;

// Parse CLI arguments
if (php_sapi_name() === 'cli') {
    foreach ($argv as $arg) {
        if ($arg === '--all') $mode = 'all';
        if (strpos($arg, '--city=') === 0) {
            $specificCity = (int)substr($arg, 7);
            $mode = 'specific';
        }
    }
}

echo "Weather Cache Refresh - " . date('Y-m-d H:i:s') . "\n";
echo "Mode: $mode\n\n";

// Clean expired entries first
$weather->cleanExpiredCache();
echo "Expired cache cleaned.\n\n";

$cities = [];
$db = getDB();

switch ($mode) {
    case 'all':
        $stmt = $db->query("SELECT id, name_en FROM cities WHERE is_active = 1 ORDER BY id");
        $cities = $stmt->fetchAll();
        break;
    case 'specific':
        $stmt = $db->prepare("SELECT id, name_en FROM cities WHERE id = ?");
        $stmt->execute([$specificCity]);
        $cities = $stmt->fetchAll();
        break;
    default:
        $stmt = $db->prepare("SELECT id, name_en FROM cities WHERE id IN (" . implode(',', $popularCityIds) . ") ORDER BY id");
        $stmt->execute();
        $cities = $stmt->fetchAll();
}

$success = 0;
$failed = 0;

foreach ($cities as $city) {
    echo "  Fetching: {$city['name_en']} (ID: {$city['id']})... ";
    $result = $weather->getForecast($city['id'], 30);

    if ($result['success']) {
        echo "OK ({$result['source']}, " . count($result['data']) . " days)\n";
        $success++;
    } else {
        echo "FAILED\n";
        $failed++;
    }

    // Rate limiting: 200ms between API calls
    usleep(200000);
}

echo "\nDone! Success: $success, Failed: $failed\n";
