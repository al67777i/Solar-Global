<?php
/**
 * Price Adjustment API
 * Returns the adjusted price for a product based on country
 *
 * GET /api/price-adjusted.php?country=PK&product_type=inverter&product_id=5
 * GET /api/price-adjusted.php?country=PK  (returns all adjustments for country)
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json');

if (!rate_limit('api_price', 30, 60)) { respond_rate_limited(); }

$db = getDB();
$country = strtoupper(trim($_GET['country'] ?? ''));
$productType = $_GET['product_type'] ?? null;
$productId = intval($_GET['product_id'] ?? 0);

if (empty($country)) {
    echo json_encode(['success' => false, 'error' => 'country parameter required']);
    exit;
}

// Get adjustments for this country
$stmt = $db->prepare("SELECT * FROM country_price_adjustments WHERE country_code = ?");
$stmt->execute([$country]);
$adjustments = [];
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $adjustments[$row['product_type']] = $row;
}

// If requesting specific product price
if ($productType && $productId > 0) {
    $table = null;
    if ($productType === 'inverter') $table = 'inverters';
    elseif ($productType === 'battery') $table = 'batteries';
    elseif ($productType === 'panel') $table = 'panels';

    if (!$table) {
        echo json_encode(['success' => false, 'error' => 'Invalid product_type']);
        exit;
    }

    $stmt = $db->prepare("SELECT id, name, price_usd FROM $table WHERE id = ? AND is_active = 1");
    $stmt->execute([$productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        echo json_encode(['success' => false, 'error' => 'Product not found']);
        exit;
    }

    $finalPrice = calculateAdjustedPrice($product['price_usd'], $productType, $adjustments);

    echo json_encode([
        'success' => true,
        'product' => $product['name'],
        'base_price_usd' => floatval($product['price_usd']),
        'adjusted_price_usd' => $finalPrice,
        'country' => $country,
        'adjustments_applied' => getAppliedAdjustments($productType, $adjustments)
    ]);
    exit;
}

// Return all adjustments for country
echo json_encode([
    'success' => true,
    'country' => $country,
    'adjustments' => $adjustments
]);

/**
 * Calculate adjusted price
 * "all" adjustments apply as base, category-specific adds on top
 */
function calculateAdjustedPrice($basePrice, $productType, $adjustments) {
    $price = floatval($basePrice);

    // Apply "all" category first
    if (isset($adjustments['all'])) {
        $all = $adjustments['all'];
        $price = $price * (1 + floatval($all['markup_percent']) / 100);
        $price = $price * (1 + floatval($all['tax_percent']) / 100);
        $price += floatval($all['shipping_flat_usd']);
    }

    // Apply category-specific on top
    if (isset($adjustments[$productType])) {
        $cat = $adjustments[$productType];
        $price = $price * (1 + floatval($cat['markup_percent']) / 100);
        $price = $price * (1 + floatval($cat['tax_percent']) / 100);
        $price += floatval($cat['shipping_flat_usd']);
    }

    return round($price, 2);
}

function getAppliedAdjustments($productType, $adjustments) {
    $applied = [];
    if (isset($adjustments['all'])) {
        $applied['all'] = [
            'markup' => floatval($adjustments['all']['markup_percent']),
            'tax' => floatval($adjustments['all']['tax_percent']),
            'shipping' => floatval($adjustments['all']['shipping_flat_usd'])
        ];
    }
    if (isset($adjustments[$productType])) {
        $applied[$productType] = [
            'markup' => floatval($adjustments[$productType]['markup_percent']),
            'tax' => floatval($adjustments[$productType]['tax_percent']),
            'shipping' => floatval($adjustments[$productType]['shipping_flat_usd'])
        ];
    }
    return $applied;
}
