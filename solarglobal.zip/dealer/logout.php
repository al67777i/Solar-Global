<?php
/**
 * Dealer Logout
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

dealer_logout();
header('Location: /solarglobal/dealer/login.php?logout=1');
exit();
