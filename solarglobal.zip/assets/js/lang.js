﻿/**
 * Language Translations
 * English and Urdu strings
 */

window.lang = {
    en: {
        // Header
        tagline: "Best Smart Solar Advisor",
        
        // Hero
        hero_title: "Find the Perfect Solar System for Your Home",
        hero_subtitle: "Smart recommendations based on your actual power needs",
        feature_smart: "Smart Recommendation",
        feature_price: "Best Price",
        feature_guide: "Installation Guide",
        
        // Steps
        step1: "Select Appliances",
        step2: "Review Load",
        step3: "View Recommendations",
        step4: "Energy Forecast",
        
        // Categories
        cat_all: "All",
        cat_cooling: "Cooling",
        cat_lighting: "Lighting",
        cat_kitchen: "Kitchen",
        cat_laundry: "Laundry",
        cat_utility: "Utility",
        cat_electronics: "Electronics",
        cat_entertainment: "Entertainment",
        cat_security: "Security",
        cat_water_heating: "Water Heating",
        cat_ventilation: "Ventilation",
        cat_appliances: "Appliances",
        
        // Home Illustration
        your_home: "Your Home",
        room_living: "Living",
        room_kitchen: "Kitchen",
        room_utility: "Utility",
        
        // Load Summary
        total_load: "Total Load",
        daily_usage: "Daily Usage",
        daily_units: "Daily Units",
        units: "Units",
        units_per_day: "Units/Day",
        
        // Buttons
        btn_calculate: "Calculate My Load",
        btn_back: "Back",
        btn_find_system: "Find Best Solar System",
        btn_view_details: "View Details",
        btn_download_diagram: "Download Circuit Diagram",
        
        // Step 2
        load_summary_title: "Your Load Summary",
        appliances_selected: "Appliances Selected",
        recommended_voltage: "Recommended Voltage Class",
        estimated_daily: "Estimated Daily Usage",
        safety_buffer: "20% safety buffer applied",
        load_breakdown_title: "Detailed Load Breakdown",
        appliance: "Appliance",
        hours_per_day: "Hours/Day",
        power: "Power",
        total_units_per_day: "Total Units Per Day",
        
        // Step 3
        best_match: "Best Match for Your Load",
        alternative_options: "Alternative Options",
        company: "Company",
        voltage_class: "Voltage Class",
        max_load: "Max Load",
        price: "Price",
        bms_included: "BMS Included",
        no_bms: "No BMS",
        compatible_batteries: "Compatible Batteries",
        
        // Step 4
        installation_guide_title: "Installation Guide & Circuit Diagram",
        system_components: "System Components",
        recommended_inverter: "Recommended Inverter",
        recommended_battery: "Recommended Battery",
        recommended_panels: "Recommended Solar Panels",
        total_system_cost: "Total System Cost",
        installation_note: "Prices are approximate. Visit your local solar dealer for exact quotation.",
        
        // Loading
        loading: "Finding best solar system for you...",
        
        // Footer
        footer_note: "Prices are approximate. Visit your local solar dealer for exact quotation.",
        
        // Errors
        error_no_appliances: "Please select at least one appliance",
        error_loading: "Error loading data. Please try again.",
        error_no_match: "No suitable inverters found for your load. Please contact SolarGlobal.",
    },
    
    ur: {
        // Header
        tagline: "پاکستان کا بہترین سولر سسٹم مشیر",
        
        // Hero
        hero_title: "اپنے گھر کے لیے بہترین سولر سسٹم تلاش کریں",
        hero_subtitle: "آپ کی اصل بجلی کی ضروریات کی بنیاد پر سمارٹ سفارشات",
        feature_smart: "سمارٹ سفارش",
        feature_price: "بہترین قیمت",
        feature_guide: "تنصیب کی رہنمائی",
        
        // Steps
        step1: "آلات منتخب کریں",
        step2: "لوڈ کا جائزہ لیں",
        step3: "سفارشات دیکھیں",
        step4: "توانائی کی پیشن گوئی",
        
        // Categories
        cat_all: "تمام",
        cat_cooling: "ٹھنڈک",
        cat_lighting: "روشنی",
        cat_kitchen: "باورچی خانہ",
        cat_laundry: "لانڈری",
        cat_utility: "افادیت",
        cat_electronics: "الیکٹرانکس",
        cat_entertainment: "تفریح",
        cat_security: "سیکیورٹی",
        cat_water_heating: "پانی گرم کرنا",
        cat_ventilation: "ہوا کی گردش",
        cat_appliances: "آلات",
        
        // Home Illustration
        your_home: "آپ کا گھر",
        room_living: "رہائش",
        room_kitchen: "باورچی خانہ",
        room_utility: "افادیت",
        
        // Load Summary
        total_load: "کل لوڈ",
        daily_usage: "روزانہ استعمال",
        daily_units: "روزانہ یونٹس",
        units: "یونٹس",
        units_per_day: "یونٹس/دن",
        
        // Buttons
        btn_calculate: "میرا لوڈ شمار کریں",
        btn_back: "واپس",
        btn_find_system: "بہترین سولر سسٹم تلاش کریں",
        btn_view_details: "تفصیلات دیکھیں",
        btn_download_diagram: "سرکٹ ڈایاگرام ڈاؤن لوڈ کریں",
        
        // Step 2
        load_summary_title: "آپ کے لوڈ کا خلاصہ",
        appliances_selected: "منتخب شدہ آلات",
        recommended_voltage: "تجویز کردہ وولٹیج کلاس",
        estimated_daily: "تخمینی روزانہ استعمال",
        safety_buffer: "20٪ حفاظتی بفر لاگو",
        load_breakdown_title: "تفصیلی لوڈ بریک ڈاؤن",
        appliance: "آلہ",
        hours_per_day: "گھنٹے/دن",
        power: "طاقت",
        total_units_per_day: "کل یونٹس فی دن",
        
        // Step 3
        best_match: "آپ کے لوڈ کے لیے بہترین میچ",
        alternative_options: "متبادل اختیارات",
        company: "کمپنی",
        voltage_class: "وولٹیج کلاس",
        max_load: "زیادہ سے زیادہ لوڈ",
        price: "قیمت",
        bms_included: "بی ایم ایس شامل",
        no_bms: "بی ایم ایس نہیں",
        compatible_batteries: "مطابقت پذیر بیٹریاں",
        
        // Step 4
        installation_guide_title: "تنصیب کی رہنمائی اور سرکٹ ڈایاگرام",
        system_components: "سسٹم کے اجزاء",
        recommended_inverter: "تجویز کردہ انورٹر",
        recommended_battery: "تجویز کردہ بیٹری",
        recommended_panels: "تجویز کردہ سولر پینل",
        total_system_cost: "کل سسٹم کی لاگت",
        installation_note: "قیمتیں تقریبی ہیں۔ درست قیمت کے لیے اپنے مقامی سولر ڈیلر سے رابطہ کریں۔",
        
        // Loading
        loading: "آپ کے لیے بہترین سولر سسٹم تلاش کیا جا رہا ہے...",
        
        // Footer
        footer_note: "قیمتیں تقریبی ہیں۔ درست قیمت کے لیے اپنے مقامی سولر ڈیلر سے رابطہ کریں۔",
        
        // Errors
        error_no_appliances: "براہ کرم کم از کم ایک آلہ منتخب کریں",
        error_loading: "ڈیٹا لوڈ کرنے میں خرابی۔ براہ کرم دوبارہ کوشش کریں۔",
        error_no_match: "آپ کے لوڈ کے لیے کوئی موزوں انورٹر نہیں ملا۔ براہ کرم SolarGlobal سے رابطہ کریں۔",
    }
};

/**
 * Current active language
 */
window.currentLang = localStorage.getItem('lang') || 'en';

/**
 * Translate all elements with data-lang-key attribute
 */
function translatePage() {
    const elements = document.querySelectorAll('[data-lang-key]');
    elements.forEach(el => {
        const key = el.getAttribute('data-lang-key');
        if (window.lang[window.currentLang] && window.lang[window.currentLang][key]) {
            el.textContent = window.lang[window.currentLang][key];
        }
    });
}

/**
 * Toggle language between English and Urdu
 */
function toggleLanguage() {
    window.currentLang = window.currentLang === 'en' ? 'ur' : 'en';
    localStorage.setItem('lang', window.currentLang);
    
    // Update HTML attributes
    const html = document.getElementById('html-root');
    const body = document.body;
    
    if (window.currentLang === 'ur') {
        html.setAttribute('lang', 'ur');
        html.setAttribute('dir', 'rtl');
        body.classList.add('rtl');
    } else {
        html.setAttribute('lang', 'en');
        html.setAttribute('dir', 'ltr');
        body.classList.remove('rtl');
    }
    
    // Update language toggle button
    const langOptions = document.querySelectorAll('.lang-option');
    langOptions.forEach(opt => {
        if (opt.getAttribute('data-lang') === window.currentLang) {
            opt.classList.add('active');
        } else {
            opt.classList.remove('active');
        }
    });
    
    // Translate all text
    translatePage();
}

/**
 * Get translated string
 */
function t(key) {
    return window.lang[window.currentLang][key] || key;
}

// Initialize language on page load
document.addEventListener('DOMContentLoaded', () => {
    // Set initial language
    if (window.currentLang === 'ur') {
        const html = document.getElementById('html-root');
        const body = document.body;
        html.setAttribute('lang', 'ur');
        html.setAttribute('dir', 'rtl');
        body.classList.add('rtl');
    }
    
    translatePage();
    
    // Setup language toggle button
    const langToggle = document.getElementById('lang-toggle');
    if (langToggle) {
        langToggle.addEventListener('click', toggleLanguage);
    }
});
