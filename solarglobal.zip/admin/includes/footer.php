            </div>
        </main>
    </div>

    <!-- Admin Panel JavaScript -->
    <script>
        // Sidebar toggle
        const sidebar = document.getElementById('admin-sidebar');
        const mobileToggle = document.getElementById('mobile-toggle');
        const sidebarToggle = document.getElementById('sidebar-toggle');

        if (mobileToggle) {
            mobileToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
        }
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => sidebar.classList.remove('open'));
        }

        // Close sidebar on outside click (mobile)
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 768 && sidebar.classList.contains('open') &&
                !sidebar.contains(e.target) && e.target !== mobileToggle) {
                sidebar.classList.remove('open');
            }
        });

        // Modal utility
        function hideForm() {
            const modal = document.getElementById('form-modal');
            if (modal) modal.style.display = 'none';
        }

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') hideForm();
        });

        document.addEventListener('click', (e) => {
            if (e.target && e.target.id === 'form-modal') hideForm();
        });
    </script>
</body>
</html>
