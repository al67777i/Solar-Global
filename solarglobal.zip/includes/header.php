<?php
/**
 * Main Header with Navigation
 */

// Ensure session is started FIRST — needed for customer login state across all pages
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$current_page = $current_page ?? basename($_SERVER['PHP_SELF'], '.php');

// Load Google Analytics ID from settings
$_ga_id = '';
try {
    $_ga_db = getDB();
    $_ga_stmt = $_ga_db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'google_analytics_id'");
    $_ga_stmt->execute();
    $_ga_id = $_ga_stmt->fetchColumn() ?: '';
} catch (Exception $e) {}

// Check if customer is logged in
$_customer_logged_in = !empty($_SESSION['customer_logged_in']);
$_customer_name = $_SESSION['customer_name'] ?? '';
$_customer_avatar = $_SESSION['customer_avatar'] ?? '';
$_customer_email = $_SESSION['customer_email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en" id="html-root">
<head>
    <meta charset="UTF-8">
    <?php if (!empty($_ga_id)): ?>
    <!-- Google Analytics (GA4) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?= htmlspecialchars($_ga_id) ?>"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '<?= htmlspecialchars($_ga_id) ?>');
    </script>
    <?php endif; ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0D3B6E">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="mobile-web-app-capable" content="yes">
    <?php
    $_site_name = get_system_setting('site_name', 'SolarGlobal');
    $_site_tagline = get_system_setting('site_tagline', 'Smart Solar Advisor');
    $_logo_path = get_system_setting('logo', '');
    $_favicon_setting = get_system_setting('favicon', '');
    ?>
    <?php
    $_page_desc = isset($page_description) ? sanitize($page_description) : sanitize($_site_name) . ' - ' . sanitize($_site_tagline) . '. Find perfect solar solutions for your home.';
    $_page_full_title = (isset($page_title) ? sanitize($page_title) . ' - ' : '') . sanitize($_site_name) . ' ' . sanitize($_site_tagline);
    // Canonical URL — supports HTTPS detection and $page_canonical override
    $_default_domain = get_system_setting('site_domain', 'solarglobal.com') ?: 'solarglobal.com';
    $_canonical_base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? $_default_domain);
    $_canonical_path = strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
    $_canonical_url = $page_canonical ?? ($_canonical_base . $_canonical_path);
    // OG image — allow page override via $page_image
    $_og_image = isset($page_image) ? $page_image : 'https://' . ($_SERVER['HTTP_HOST'] ?? $_default_domain) . BASE_URL . 'assets/images/og-share.png';
    // OG type — allow page override via $page_og_type (e.g. "product")
    $_og_type = isset($page_og_type) ? sanitize($page_og_type) : 'website';
    ?>
    <meta name="description" content="<?= $_page_desc ?>">
    <meta name="author" content="<?= sanitize($_site_name) ?>">
    <?php if (!empty($page_keywords)): ?>
    <meta name="keywords" content="<?= sanitize($page_keywords) ?>">
    <?php endif; ?>
    <title><?= $_page_full_title ?></title>

    <!-- Favicon -->
    <?php $_favicon_url = !empty($_favicon_setting) ? BASE_URL . $_favicon_setting : BASE_URL . 'assets/images/favicon.png'; ?>
    <link rel="icon" type="image/png" href="<?= $_favicon_url ?>">
    <link rel="apple-touch-icon" href="<?= $_favicon_url ?>">

    <!-- SEO: Open Graph -->
    <meta property="og:title" content="<?= $_page_full_title ?>">
    <meta property="og:description" content="<?= $_page_desc ?>">
    <meta property="og:type" content="<?= $_og_type ?>">
    <meta property="og:url" content="<?= htmlspecialchars($_canonical_url) ?>">
    <meta property="og:site_name" content="<?= sanitize($_site_name) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($_og_image) ?>">

    <!-- SEO: Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= $_page_full_title ?>">
    <meta name="twitter:description" content="<?= $_page_desc ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($_og_image) ?>">

    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?= htmlspecialchars($_canonical_url) ?>">

    <!-- JSON-LD: Organization Schema -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": "<?= sanitize($_site_name) ?>",
        "url": "https://<?= htmlspecialchars($_default_domain) ?>",
        "logo": "<?= 'https://' . ($_SERVER['HTTP_HOST'] ?? $_default_domain) . BASE_URL . (!empty($_logo_path) ? sanitize($_logo_path) : 'assets/images/favicon.png') ?>",
        "description": "<?= sanitize($_site_tagline) ?>",
        "sameAs": []
    }
    </script>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Nastaliq+Urdu:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/main.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/frontend.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/animations.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/recommendations.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/installation-guide.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/pages.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/mobile-app.css">

    <!-- Global JS config -->
    <script>window.BASE_URL = '<?= BASE_URL ?>';</script>

    <!-- Anime.js -->
    <script src="<?= BASE_URL ?>assets/js/anime.min.js"></script>

    <style>
    /* ===== SolarGlobal Navigation v2 ===== */
    .sg-nav {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1000;
        background: #ffffff;
        border-bottom: 1px solid #E2E8F0;
        transition: box-shadow 0.3s ease;
        font-family: 'Inter', sans-serif;
    }
    .sg-nav.scrolled {
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    .sg-nav-inner {
        max-width: 1280px;
        margin: 0 auto;
        padding: 0 24px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 68px;
    }

    /* Logo */
    .sg-logo {
        display: flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
        color: inherit;
        flex-shrink: 0;
    }
    .sg-logo-icon {
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, #F59E0B, #D97706);
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
    }
    .sg-logo-text {
        font-size: 1.25rem;
        font-weight: 700;
        color: #0F172A;
        margin: 0;
        line-height: 1.2;
    }
    .sg-logo-tagline {
        font-size: 0.7rem;
        color: #64748B;
        margin: 0;
        font-weight: 400;
        letter-spacing: 0.02em;
    }

    /* Desktop Menu */
    .sg-menu {
        display: flex;
        align-items: center;
        gap: 4px;
        list-style: none;
        margin: 0;
        padding: 0;
    }
    .sg-menu-item {
        position: relative;
    }
    .sg-menu-link {
        display: flex;
        align-items: center;
        gap: 4px;
        padding: 8px 16px;
        font-size: 0.9rem;
        font-weight: 500;
        color: #334155;
        text-decoration: none;
        border-radius: 6px;
        transition: color 0.2s, background 0.2s;
        white-space: nowrap;
        cursor: pointer;
        border: none;
        background: none;
        font-family: inherit;
    }
    .sg-menu-link:hover {
        color: #0F172A;
        background: #F8FAFC;
    }
    .sg-menu-link.active {
        color: #D97706;
        position: relative;
    }
    .sg-menu-link.active::after {
        content: '';
        position: absolute;
        bottom: -4px;
        left: 16px;
        right: 16px;
        height: 2px;
        background: #F59E0B;
        border-radius: 1px;
    }
    .sg-menu-arrow {
        font-size: 0.6rem;
        transition: transform 0.2s;
        color: #94A3B8;
    }

    /* Dropdown */
    .sg-dropdown {
        position: absolute;
        top: calc(100% + 8px);
        left: 0;
        min-width: 200px;
        background: #ffffff;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        padding: 6px;
        opacity: 0;
        visibility: hidden;
        transform: translateY(-4px);
        transition: opacity 0.2s, transform 0.2s, visibility 0.2s;
        z-index: 100;
    }
    .sg-menu-item:hover > .sg-dropdown,
    .sg-menu-item.open > .sg-dropdown {
        opacity: 1;
        visibility: visible;
        transform: translateY(0);
    }
    .sg-menu-item:hover > .sg-menu-link .sg-menu-arrow,
    .sg-menu-item.open > .sg-menu-link .sg-menu-arrow {
        transform: rotate(180deg);
    }
    .sg-dropdown-link {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 14px;
        font-size: 0.875rem;
        font-weight: 450;
        color: #334155;
        text-decoration: none;
        border-radius: 6px;
        transition: background 0.15s, color 0.15s;
    }
    .sg-dropdown-link:hover {
        background: #FFF7ED;
        color: #D97706;
    }
    .sg-dropdown-link .sg-dd-icon {
        width: 32px;
        height: 32px;
        background: #F1F5F9;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.9rem;
        flex-shrink: 0;
    }
    .sg-dropdown-link:hover .sg-dd-icon {
        background: #FEF3C7;
    }

    /* ===== Global Search ===== */
    .sg-search-wrap {
        position: relative;
    }
    .sg-search-btn {
        width: 38px;
        height: 38px;
        border-radius: 10px;
        border: 2px solid #E2E8F0;
        background: white;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: #475569;
        transition: all 0.2s;
    }
    .sg-search-btn:hover { border-color: #F59E0B; color: #D97706; background: #FFF7ED; }
    .sg-search-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.4);
        z-index: 2000;
    }
    .sg-search-overlay.open { display: block; }
    .sg-search-modal {
        display: none;
        position: fixed;
        top: 80px;
        left: 50%;
        transform: translateX(-50%);
        width: 90%;
        max-width: 600px;
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.2);
        z-index: 2001;
        overflow: hidden;
    }
    .sg-search-modal.open { display: block; }
    .sg-search-input-wrap {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 16px 20px;
        border-bottom: 1px solid #E2E8F0;
    }
    .sg-search-input-wrap svg { flex-shrink: 0; color: #94A3B8; }
    .sg-search-input {
        flex: 1;
        border: none;
        outline: none;
        font-size: 1rem;
        font-family: inherit;
        color: #1E293B;
        background: transparent;
    }
    .sg-search-input::placeholder { color: #94A3B8; }
    .sg-search-close {
        background: none;
        border: none;
        font-size: 1.25rem;
        cursor: pointer;
        color: #94A3B8;
        padding: 4px;
        line-height: 1;
    }
    .sg-search-close:hover { color: #1E293B; }
    .sg-search-results {
        max-height: 400px;
        overflow-y: auto;
        padding: 8px 0;
    }
    .sg-search-section {
        padding: 4px 0;
    }
    .sg-search-section-title {
        font-size: 0.6875rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #94A3B8;
        padding: 8px 20px 4px;
    }
    .sg-search-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 20px;
        text-decoration: none;
        color: inherit;
        transition: background 0.15s;
    }
    .sg-search-item:hover { background: #F8FAFC; }
    .sg-search-item-icon {
        width: 40px;
        height: 40px;
        border-radius: 8px;
        background: #F1F5F9;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1rem;
        flex-shrink: 0;
        overflow: hidden;
    }
    .sg-search-item-icon img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .sg-search-item-body { flex: 1; min-width: 0; }
    .sg-search-item-name {
        font-size: 0.875rem;
        font-weight: 600;
        color: #1E293B;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .sg-search-item-meta {
        font-size: 0.75rem;
        color: #64748B;
        margin-top: 2px;
    }
    .sg-search-item-price {
        font-size: 0.875rem;
        font-weight: 700;
        color: #D97706;
        flex-shrink: 0;
    }
    .sg-search-empty {
        text-align: center;
        padding: 32px 20px;
        color: #94A3B8;
        font-size: 0.875rem;
    }
    .sg-search-loading {
        text-align: center;
        padding: 24px 20px;
        color: #94A3B8;
        font-size: 0.875rem;
    }

    /* Right side actions */
    .sg-nav-actions {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-shrink: 0;
    }
    .sg-btn-partner {
        padding: 8px 18px;
        font-size: 0.85rem;
        font-weight: 600;
        color: #ffffff;
        background: linear-gradient(135deg, #F59E0B, #D97706);
        border: none;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        transition: opacity 0.2s, transform 0.15s;
        font-family: inherit;
        text-decoration: none;
        white-space: nowrap;
    }
    .sg-btn-partner:hover {
        opacity: 0.92;
        transform: translateY(-1px);
    }
    .sg-btn-login {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        border: 1px solid #E2E8F0;
        background: #F8FAFC;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: border-color 0.2s, background 0.2s;
        font-size: 1rem;
        color: #64748B;
    }
    .sg-btn-login:hover {
        border-color: #F59E0B;
        background: #FFF7ED;
        color: #D97706;
    }
    .sg-cart-btn {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 38px;
        height: 38px;
        border-radius: 10px;
        border: 2px solid #E2E8F0;
        background: white;
        cursor: pointer;
        color: #475569;
        transition: all 0.2s;
        text-decoration: none;
    }
    .sg-cart-btn:hover { border-color: #F59E0B; color: #D97706; background: #FFF7ED; }
    .sg-cart-badge {
        position: absolute;
        top: -5px; right: -5px;
        background: #F59E0B;
        color: #1E293B;
        font-size: 0.6rem;
        font-weight: 800;
        min-width: 16px;
        height: 16px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        line-height: 1;
        padding: 0 4px;
    }
    .sg-login-wrap {
        position: relative;
    }
    .sg-login-wrap .sg-dropdown {
        right: 0;
        left: auto;
        min-width: 180px;
    }
    .sg-user-avatar {
        width: 38px; height: 38px; border-radius: 50%; border: 2px solid #F59E0B;
        display: flex; align-items: center; justify-content: center;
        cursor: pointer; overflow: hidden; background: #F59E0B; color: #1E293B;
        font-weight: 700; font-size: 0.875rem;
    }
    .sg-user-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .sg-dropdown-greeting {
        padding: 12px 14px; font-size: 0.8125rem; font-weight: 600; color: #1E293B;
        border-bottom: 1px solid #E2E8F0; margin-bottom: 4px;
    }
    .sg-dropdown-divider {
        height: 1px; background: #E2E8F0; margin: 4px 0;
    }
    .sg-partner-wrap {
        position: relative;
    }
    .sg-partner-wrap .sg-dropdown {
        right: 0;
        left: auto;
        min-width: 200px;
    }

    /* Nav spacer */
    .sg-nav-spacer {
        height: 68px;
    }

    /* ===== Mobile Bottom Nav ===== */
    .sg-bottom-nav {
        display: none;
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        z-index: 1000;
        background: #ffffff;
        border-top: 1px solid #E2E8F0;
        box-shadow: 0 -2px 12px rgba(0,0,0,0.06);
        padding: 6px 0 max(6px, env(safe-area-inset-bottom));
    }
    .sg-bottom-nav-inner {
        display: flex;
        align-items: center;
        justify-content: space-around;
        max-width: 500px;
        margin: 0 auto;
    }
    .sg-bottom-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 2px;
        padding: 6px 12px;
        min-height: 44px;
        min-width: 44px;
        text-decoration: none;
        color: #64748B;
        border: none;
        background: none;
        cursor: pointer;
        font-family: inherit;
        transition: color 0.2s;
        -webkit-tap-highlight-color: transparent;
    }
    .sg-bottom-item.active {
        color: #D97706;
    }
    .sg-bottom-icon {
        font-size: 1.25rem;
        line-height: 1;
    }
    .sg-bottom-label {
        font-size: 0.65rem;
        font-weight: 500;
        letter-spacing: 0.01em;
    }

    /* ===== More Menu Sheet ===== */
    .sg-more-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.4);
        z-index: 1100;
        opacity: 0;
        transition: opacity 0.3s;
    }
    .sg-more-overlay.active {
        display: block;
        opacity: 1;
    }
    .sg-more-sheet {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        z-index: 1200;
        background: #ffffff;
        border-radius: 16px 16px 0 0;
        max-height: 80vh;
        overflow-y: auto;
        transform: translateY(100%);
        transition: transform 0.35s cubic-bezier(0.32, 0.72, 0, 1);
        padding-bottom: max(16px, env(safe-area-inset-bottom));
    }
    .sg-more-sheet.active {
        transform: translateY(0);
    }
    .sg-more-handle {
        width: 36px;
        height: 4px;
        background: #CBD5E1;
        border-radius: 2px;
        margin: 10px auto 4px;
    }
    .sg-more-header {
        padding: 12px 20px 8px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .sg-more-title {
        font-size: 1.1rem;
        font-weight: 700;
        color: #0F172A;
        margin: 0;
    }
    .sg-more-close {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        border: none;
        background: #F1F5F9;
        font-size: 1.1rem;
        color: #64748B;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .sg-more-section {
        padding: 4px 16px;
    }
    .sg-more-section-title {
        font-size: 0.7rem;
        font-weight: 600;
        color: #94A3B8;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        padding: 12px 8px 6px;
        margin: 0;
    }
    .sg-more-link {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 8px;
        text-decoration: none;
        color: #334155;
        font-size: 0.9rem;
        font-weight: 450;
        border-radius: 8px;
        transition: background 0.15s;
        min-height: 44px;
    }
    .sg-more-link:hover,
    .sg-more-link:active {
        background: #F8FAFC;
    }
    .sg-more-link-icon {
        width: 36px;
        height: 36px;
        border-radius: 10px;
        background: #F1F5F9;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1rem;
        flex-shrink: 0;
    }
    .sg-more-link.highlight {
        color: #D97706;
        font-weight: 600;
    }
    .sg-more-link.highlight .sg-more-link-icon {
        background: #FEF3C7;
    }
    .sg-more-divider {
        height: 1px;
        background: #F1F5F9;
        margin: 4px 20px;
    }

    /* ===== Notification Bell ===== */
    .sg-notif-wrap {
        position: relative;
        display: inline-flex;
    }
    .sg-notif-btn {
        position: relative;
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        padding: 8px;
        border-radius: 8px;
        transition: background 0.2s;
    }
    .sg-notif-btn:hover {
        background: rgba(255,255,255,0.1);
    }
    .sg-notif-badge {
        position: absolute;
        top: 2px;
        right: 2px;
        background: #EF4444;
        color: white;
        font-size: 0.6rem;
        font-weight: 700;
        min-width: 16px;
        height: 16px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 4px;
        line-height: 1;
    }
    .sg-notif-dropdown {
        display: none;
        position: absolute;
        top: 100%;
        right: 0;
        width: 340px;
        max-height: 420px;
        background: white;
        border-radius: 12px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        z-index: 1000;
        overflow: hidden;
        margin-top: 8px;
    }
    .sg-notif-dropdown.open {
        display: block;
    }
    .sg-notif-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 16px;
        border-bottom: 1px solid #E2E8F0;
    }
    .sg-notif-title {
        font-size: 0.9375rem;
        font-weight: 700;
        color: #1E293B;
    }
    .sg-notif-mark-all {
        font-size: 0.75rem;
        color: #3B82F6;
        background: none;
        border: none;
        cursor: pointer;
        font-weight: 600;
    }
    .sg-notif-mark-all:hover {
        text-decoration: underline;
    }
    .sg-notif-list {
        overflow-y: auto;
        max-height: 360px;
    }
    .sg-notif-item {
        display: block;
        padding: 12px 16px;
        border-bottom: 1px solid #F1F5F9;
        text-decoration: none;
        transition: background 0.15s;
        cursor: pointer;
    }
    .sg-notif-item:hover {
        background: #F8FAFC;
    }
    .sg-notif-item.unread {
        background: #EFF6FF;
        border-left: 3px solid #3B82F6;
    }
    .sg-notif-item-title {
        font-size: 0.8125rem;
        font-weight: 600;
        color: #1E293B;
        margin-bottom: 2px;
    }
    .sg-notif-item-msg {
        font-size: 0.75rem;
        color: #64748B;
        line-height: 1.4;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }
    .sg-notif-item-time {
        font-size: 0.6875rem;
        color: #94A3B8;
        margin-top: 4px;
    }
    .sg-notif-empty {
        text-align: center;
        padding: 32px 16px;
        color: #94A3B8;
        font-size: 0.875rem;
    }

    /* ===== Responsive ===== */
    @media (max-width: 1024px) {
        .sg-menu,
        .sg-nav-actions {
            display: none;
        }
        .sg-bottom-nav {
            display: block;
        }
        .sg-nav-inner {
            height: 56px;
        }
        .sg-nav-spacer {
            height: 56px;
        }
    }
    @media (min-width: 1025px) {
        .sg-bottom-nav,
        .sg-more-overlay,
        .sg-more-sheet {
            display: none !important;
        }
    }
    </style>
    <?php if (!empty($page_extra_head)) echo $page_extra_head; ?>
</head>
<body>
    <!-- Top Navigation -->
    <nav class="sg-nav main-nav" id="mainNav">
        <div class="sg-nav-inner nav-container">
            <!-- Logo -->
            <a href="<?= BASE_URL ?>index.php" class="sg-logo nav-logo">
                <?php if (!empty($_logo_path)): ?>
                <div class="sg-logo-icon" style="padding:0;overflow:hidden;border-radius:8px;">
                    <img src="<?= BASE_URL . sanitize($_logo_path) ?>" alt="<?= sanitize($_site_name) ?>" style="width:36px;height:36px;object-fit:contain;display:block;">
                </div>
                <?php else: ?>
                <div class="sg-logo-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                </div>
                <?php endif; ?>
                <div>
                    <h1 class="sg-logo-text"><?= sanitize($_site_name) ?></h1>
                    <p class="sg-logo-tagline"><?= sanitize($_site_tagline) ?></p>
                </div>
            </a>

            <!-- Desktop Menu -->
            <ul class="sg-menu nav-menu" id="navMenu">
                <li class="sg-menu-item">
                    <a href="<?= BASE_URL ?>index.php" class="sg-menu-link <?php echo $current_page == 'index' ? 'active' : ''; ?>">Home</a>
                </li>
                <li class="sg-menu-item">
                    <button type="button" class="sg-menu-link <?php echo in_array($current_page, ['find-installer','stores','store-detail']) ? 'active' : ''; ?>">
                        Services <span class="sg-menu-arrow">&#9662;</span>
                    </button>
                    <div class="sg-dropdown">
                        <a href="<?= BASE_URL ?>stores.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#127978;</span>
                            <span>Browse Stores</span>
                        </a>
                        <a href="<?= BASE_URL ?>find-installer.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128270;</span>
                            <span>Find Installer</span>
                        </a>
                        <a href="<?= BASE_URL ?>index.php#calculator" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#9889;</span>
                            <span>Solar Calculator</span>
                        </a>
                    </div>
                </li>
                <li class="sg-menu-item">
                    <button type="button" class="sg-menu-link <?php echo in_array($current_page, ['inverters','batteries','panels','compare']) ? 'active' : ''; ?>">
                        Products <span class="sg-menu-arrow">&#9662;</span>
                    </button>
                    <div class="sg-dropdown">
                        <a href="<?= BASE_URL ?>inverters.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#9889;</span>
                            <span>Inverters</span>
                        </a>
                        <a href="<?= BASE_URL ?>batteries.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128267;</span>
                            <span>Batteries</span>
                        </a>
                        <a href="<?= BASE_URL ?>panels.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#9728;</span>
                            <span>Solar Panels</span>
                        </a>
                        <a href="<?= BASE_URL ?>compare.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#9878;</span>
                            <span>Compare Products</span>
                        </a>
                    </div>
                </li>
                <li class="sg-menu-item">
                    <a href="<?= BASE_URL ?>store.php" class="sg-menu-link <?php echo $current_page == 'store' ? 'active' : ''; ?>">Solar Shop</a>
                </li>
                <li class="sg-menu-item">
                    <a href="<?= BASE_URL ?>about.php" class="sg-menu-link <?php echo $current_page == 'about' ? 'active' : ''; ?>">About</a>
                </li>
                <li class="sg-menu-item">
                    <a href="<?= BASE_URL ?>contact.php" class="sg-menu-link <?php echo $current_page == 'contact' ? 'active' : ''; ?>">Contact</a>
                </li>
            </ul>

            <!-- Right Actions -->
            <div class="sg-nav-actions">
                <!-- Search -->
                <div class="sg-search-wrap">
                    <button type="button" class="sg-search-btn" id="sgSearchBtn" title="Search" aria-label="Search">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    </button>
                </div>

                <div class="sg-partner-wrap sg-menu-item">
                    <button type="button" class="sg-btn-partner">
                        Become a Partner <span class="sg-menu-arrow" style="color:rgba(255,255,255,0.7)">&#9662;</span>
                    </button>
                    <div class="sg-dropdown">
                        <a href="<?= BASE_URL ?>become-dealer.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#127978;</span>
                            <span>Open a Store</span>
                        </a>
                        <a href="<?= BASE_URL ?>become-installer.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128295;</span>
                            <span>Become an Installer</span>
                        </a>
                    </div>
                </div>
                <?php
                    $hdr_cart_count = 0;
                    if (session_status() === PHP_SESSION_NONE) session_start();
                    if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
                        foreach ($_SESSION['cart'] as $dc) {
                            if (!empty($dc['items'])) foreach ($dc['items'] as $ci) $hdr_cart_count += ($ci['quantity'] ?? 1);
                        }
                    }
                ?>
                <a href="<?= BASE_URL ?>customer/cart.php?view=cart" class="sg-cart-btn" title="Shopping Cart">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
                    <?php if ($hdr_cart_count > 0): ?><span class="sg-cart-badge"><?= $hdr_cart_count ?></span><?php endif; ?>
                </a>
                <?php
                // Notification bell (for logged-in customers)
                $hdr_notif_count = 0;
                if (!empty($_SESSION['customer_id'])) {
                    require_once __DIR__ . '/notification_helpers.php';
                    $hdr_notif_count = get_unread_notification_count('customer', (int)$_SESSION['customer_id']);
                }
                if (!empty($_SESSION['customer_id'])):
                ?>
                <div class="sg-notif-wrap" id="sgNotifWrap">
                    <button type="button" class="sg-notif-btn" id="sgNotifBtn" title="Notifications" aria-label="Notifications">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                        <?php if ($hdr_notif_count > 0): ?><span class="sg-notif-badge" id="sgNotifBadge"><?= $hdr_notif_count ?></span><?php endif; ?>
                    </button>
                    <div class="sg-notif-dropdown" id="sgNotifDropdown">
                        <div class="sg-notif-header">
                            <span class="sg-notif-title">Notifications</span>
                            <button type="button" class="sg-notif-mark-all" id="sgNotifMarkAll">Mark all read</button>
                        </div>
                        <div class="sg-notif-list" id="sgNotifList">
                            <div class="sg-notif-empty">No notifications</div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="sg-login-wrap sg-menu-item">
                    <?php if ($_customer_logged_in): ?>
                    <button type="button" class="sg-user-avatar" aria-label="Account menu">
                        <?php if (!empty($_customer_avatar)): ?>
                            <img src="<?= htmlspecialchars($_customer_avatar) ?>" alt="<?= htmlspecialchars($_customer_name) ?>">
                        <?php else: ?>
                            <?= strtoupper(mb_substr($_customer_name ?: 'U', 0, 1)) ?>
                        <?php endif; ?>
                    </button>
                    <div class="sg-dropdown">
                        <div class="sg-dropdown-greeting">Hi, <?= htmlspecialchars($_customer_name ?: 'Customer') ?></div>
                        <a href="<?= BASE_URL ?>customer/orders.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128230;</span>
                            <span>My Orders</span>
                        </a>
                        <a href="<?= BASE_URL ?>customer/cart.php?view=cart" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128722;</span>
                            <span>Cart</span>
                        </a>
                        <a href="<?= BASE_URL ?>customer/watchlist.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128065;</span>
                            <span>Watchlist</span>
                        </a>
                        <a href="<?= BASE_URL ?>customer/reviews.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#11088;</span>
                            <span>My Reviews</span>
                        </a>
                        <a href="<?= BASE_URL ?>customer/installations.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128295;</span>
                            <span>My Installations</span>
                        </a>
                        <div class="sg-dropdown-divider"></div>
                        <a href="<?= BASE_URL ?>customer/logout.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128682;</span>
                            <span>Logout</span>
                        </a>
                    </div>
                    <?php else: ?>
                    <button type="button" class="sg-btn-login" aria-label="Login options">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </button>
                    <div class="sg-dropdown">
                        <a href="<?= BASE_URL ?>customer/login.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128722;</span>
                            <span>Customer Login</span>
                        </a>
                        <a href="<?= BASE_URL ?>dealer/login.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128100;</span>
                            <span>Dealer Login</span>
                        </a>
                        <a href="<?= BASE_URL ?>installer/login.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128295;</span>
                            <span>Installer Login</span>
                        </a>
                        <a href="<?= BASE_URL ?>login.php" class="sg-dropdown-link">
                            <span class="sg-dd-icon">&#128272;</span>
                            <span>Admin</span>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Nav spacer -->
    <div class="sg-nav-spacer"></div>

    <!-- Mobile Bottom Navigation -->
    <nav class="sg-bottom-nav bottom-nav" id="bottomNav">
        <div class="sg-bottom-nav-inner">
            <a href="<?= BASE_URL ?>index.php" class="sg-bottom-item <?php echo $current_page == 'index' ? 'active' : ''; ?>">
                <span class="sg-bottom-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                </span>
                <span class="sg-bottom-label">Home</span>
            </a>
            <a href="<?= BASE_URL ?>inverters.php" class="sg-bottom-item <?php echo in_array($current_page, ['inverters','batteries','panels','compare']) ? 'active' : ''; ?>">
                <span class="sg-bottom-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v3"/><line x1="12" y1="11" x2="12" y2="17"/><line x1="9" y1="14" x2="15" y2="14"/></svg>
                </span>
                <span class="sg-bottom-label">Products</span>
            </a>
            <button type="button" class="sg-bottom-item <?php echo in_array($current_page, ['find-installer','stores','store-detail','store']) ? 'active' : ''; ?>" id="mobileServicesBtn">
                <span class="sg-bottom-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
                </span>
                <span class="sg-bottom-label">Services</span>
            </button>
            <a href="<?= BASE_URL ?>index.php#calculator" class="sg-bottom-item">
                <span class="sg-bottom-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2"/><line x1="8" y1="6" x2="16" y2="6"/><line x1="8" y1="10" x2="10" y2="10"/><line x1="14" y1="10" x2="16" y2="10"/><line x1="8" y1="14" x2="10" y2="14"/><line x1="14" y1="14" x2="16" y2="14"/><line x1="8" y1="18" x2="16" y2="18"/></svg>
                </span>
                <span class="sg-bottom-label">Calculator</span>
            </a>
            <button type="button" class="sg-bottom-item" id="moreMenuBtn" aria-label="More options">
                <span class="sg-bottom-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="1.5" fill="currentColor"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/><circle cx="12" cy="19" r="1.5" fill="currentColor"/></svg>
                </span>
                <span class="sg-bottom-label">More</span>
            </button>
        </div>
    </nav>

    <!-- More Menu Overlay -->
    <div class="sg-more-overlay more-menu-overlay" id="moreMenuOverlay"></div>

    <!-- More Menu Sheet -->
    <div class="sg-more-sheet more-menu" id="moreMenu">
        <div class="sg-more-handle"></div>
        <div class="sg-more-header">
            <h2 class="sg-more-title">Menu</h2>
            <button type="button" class="sg-more-close" id="moreMenuClose" aria-label="Close menu">&#10005;</button>
        </div>

        <!-- Solar Shop (standalone) -->
        <div class="sg-more-section">
            <a href="<?= BASE_URL ?>store.php" class="sg-more-link" style="font-weight:700;color:#F59E0B;">
                <span class="sg-more-link-icon">&#9889;</span>
                <span>Solar Shop</span>
            </a>
        </div>

        <div class="sg-more-divider"></div>

        <!-- Services -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">Services</h3>
            <a href="<?= BASE_URL ?>stores.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#127978;</span>
                <span>Browse Stores</span>
            </a>
            <a href="<?= BASE_URL ?>find-installer.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128270;</span>
                <span>Find Installer</span>
            </a>
            <a href="<?= BASE_URL ?>index.php#calculator" class="sg-more-link">
                <span class="sg-more-link-icon">&#9889;</span>
                <span>Solar Calculator</span>
            </a>
        </div>

        <div class="sg-more-divider"></div>

        <!-- Products -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">Products</h3>
            <a href="<?= BASE_URL ?>inverters.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#9889;</span>
                <span>Inverters</span>
            </a>
            <a href="<?= BASE_URL ?>batteries.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128267;</span>
                <span>Batteries</span>
            </a>
            <a href="<?= BASE_URL ?>panels.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#9728;</span>
                <span>Solar Panels</span>
            </a>
            <a href="<?= BASE_URL ?>compare.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#9878;</span>
                <span>Compare Products</span>
            </a>
        </div>

        <div class="sg-more-divider"></div>

        <!-- For Business -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">For Business</h3>
            <a href="<?= BASE_URL ?>become-dealer.php" class="sg-more-link highlight">
                <span class="sg-more-link-icon">&#127978;</span>
                <span>Open Your Store</span>
            </a>
            <a href="<?= BASE_URL ?>become-installer.php" class="sg-more-link highlight">
                <span class="sg-more-link-icon">&#128295;</span>
                <span>Become an Installer</span>
            </a>
        </div>

        <div class="sg-more-divider"></div>

        <!-- Account -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">Account</h3>
            <?php if ($_customer_logged_in): ?>
            <div style="padding: 8px 16px; font-size: 0.8125rem; font-weight: 600; color: #1E293B;">Hi, <?= htmlspecialchars($_customer_name ?: 'Customer') ?></div>
            <a href="<?= BASE_URL ?>customer/orders.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128230;</span>
                <span>My Orders</span>
            </a>
            <a href="<?= BASE_URL ?>customer/cart.php?view=cart" class="sg-more-link">
                <span class="sg-more-link-icon">&#128722;</span>
                <span>Cart</span>
            </a>
            <a href="<?= BASE_URL ?>customer/watchlist.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128065;</span>
                <span>Watchlist</span>
            </a>
            <a href="<?= BASE_URL ?>customer/reviews.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#11088;</span>
                <span>My Reviews</span>
            </a>
            <a href="<?= BASE_URL ?>customer/logout.php" class="sg-more-link" style="color: #DC2626;">
                <span class="sg-more-link-icon">&#128682;</span>
                <span>Logout</span>
            </a>
            <?php else: ?>
            <a href="<?= BASE_URL ?>customer/login.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128722;</span>
                <span>Customer Login</span>
            </a>
            <a href="<?= BASE_URL ?>dealer/login.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128100;</span>
                <span>Dealer Login</span>
            </a>
            <a href="<?= BASE_URL ?>installer/login.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128295;</span>
                <span>Installer Login</span>
            </a>
            <?php endif; ?>
        </div>

        <div class="sg-more-divider"></div>

        <!-- Company -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">Company</h3>
            <a href="<?= BASE_URL ?>about.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#8505;</span>
                <span>About Us</span>
            </a>
            <a href="<?= BASE_URL ?>contact.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#9993;</span>
                <span>Contact Us</span>
            </a>
        </div>

        <div class="sg-more-divider"></div>

        <!-- Admin -->
        <div class="sg-more-section">
            <h3 class="sg-more-section-title">Admin</h3>
            <a href="<?= BASE_URL ?>login.php" class="sg-more-link">
                <span class="sg-more-link-icon">&#128272;</span>
                <span>Admin Panel</span>
            </a>
        </div>
    </div>

    <!-- Search Overlay & Modal -->
    <div class="sg-search-overlay" id="sgSearchOverlay"></div>
    <div class="sg-search-modal" id="sgSearchModal">
        <div class="sg-search-input-wrap">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" class="sg-search-input" id="sgSearchInput" placeholder="Search products, stores, installers..." autocomplete="off">
            <button type="button" class="sg-search-close" id="sgSearchClose" aria-label="Close search">&#10005;</button>
        </div>
        <div class="sg-search-results" id="sgSearchResults">
            <div class="sg-search-empty">Type to search across products, stores, and installers</div>
        </div>
    </div>

    <script>
    (function() {
        // Scroll shadow
        window.addEventListener('scroll', function() {
            var nav = document.getElementById('mainNav');
            if (nav) nav.classList.toggle('scrolled', window.scrollY > 10);
        });

        // Desktop dropdown click support (for accessibility)
        document.querySelectorAll('.sg-menu-item > button.sg-menu-link, .sg-btn-partner, .sg-btn-login, .sg-user-avatar').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                var parent = this.closest('.sg-menu-item, .sg-partner-wrap, .sg-login-wrap');
                if (parent) {
                    // Close other open dropdowns
                    document.querySelectorAll('.sg-menu-item.open, .sg-partner-wrap.open, .sg-login-wrap.open').forEach(function(el) {
                        if (el !== parent) el.classList.remove('open');
                    });
                    parent.classList.toggle('open');
                    e.stopPropagation();
                }
            });
        });
        document.addEventListener('click', function() {
            document.querySelectorAll('.sg-menu-item.open, .sg-partner-wrap.open, .sg-login-wrap.open').forEach(function(el) {
                el.classList.remove('open');
            });
        });

        // More menu toggle
        var moreBtn = document.getElementById('moreMenuBtn');
        var moreMenu = document.getElementById('moreMenu');
        var moreOverlay = document.getElementById('moreMenuOverlay');
        var moreClose = document.getElementById('moreMenuClose');

        function openMore() {
            if (moreMenu && moreOverlay) {
                moreOverlay.classList.add('active');
                // Force reflow for animation
                moreMenu.offsetHeight;
                moreMenu.classList.add('active');
            }
        }
        function closeMore() {
            if (moreMenu && moreOverlay) {
                moreMenu.classList.remove('active');
                moreOverlay.classList.remove('active');
            }
        }
        if (moreBtn) moreBtn.addEventListener('click', openMore);
        if (moreOverlay) moreOverlay.addEventListener('click', closeMore);
        if (moreClose) moreClose.addEventListener('click', closeMore);

        // Mobile Services button → opens More menu (scrolled to Services section)
        var servicesBtn = document.getElementById('mobileServicesBtn');
        if (servicesBtn) {
            servicesBtn.addEventListener('click', function() {
                openMore();
                // Scroll to services section after opening
                setTimeout(function() {
                    var sections = moreMenu ? moreMenu.querySelectorAll('.sg-more-section-title') : [];
                    for (var i = 0; i < sections.length; i++) {
                        if (sections[i].textContent.trim() === 'Services') {
                            sections[i].scrollIntoView({ behavior: 'smooth', block: 'start' });
                            break;
                        }
                    }
                }, 100);
            });
        }

        // ─── Global Search ───
        var searchBtn = document.getElementById('sgSearchBtn');
        var searchOverlay = document.getElementById('sgSearchOverlay');
        var searchModal = document.getElementById('sgSearchModal');
        var searchInput = document.getElementById('sgSearchInput');
        var searchResults = document.getElementById('sgSearchResults');
        var searchClose = document.getElementById('sgSearchClose');
        var searchTimer = null;

        function openSearch() {
            if (searchOverlay && searchModal) {
                searchOverlay.classList.add('open');
                searchModal.classList.add('open');
                if (searchInput) { searchInput.value = ''; searchInput.focus(); }
                if (searchResults) searchResults.innerHTML = '<div class="sg-search-empty">Type to search across products, stores, and installers</div>';
            }
        }
        function closeSearch() {
            if (searchOverlay && searchModal) {
                searchOverlay.classList.remove('open');
                searchModal.classList.remove('open');
            }
        }

        if (searchBtn) searchBtn.addEventListener('click', openSearch);
        if (searchOverlay) searchOverlay.addEventListener('click', closeSearch);
        if (searchClose) searchClose.addEventListener('click', closeSearch);

        // Ctrl+K / Cmd+K keyboard shortcut
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                openSearch();
            }
            if (e.key === 'Escape') closeSearch();
        });

        if (searchInput) {
            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimer);
                var q = searchInput.value.trim();
                if (q.length < 2) {
                    searchResults.innerHTML = '<div class="sg-search-empty">Type to search across products, stores, and installers</div>';
                    return;
                }
                searchResults.innerHTML = '<div class="sg-search-loading">Searching...</div>';
                searchTimer = setTimeout(function() { doSearch(q); }, 300);
            });
        }

        function doSearch(q) {
            fetch('<?= BASE_URL ?>api/search.php?q=' + encodeURIComponent(q) + '&limit=5')
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    var html = '';
                    var hasResults = false;

                    // Products
                    if (data.products && data.products.length > 0) {
                        hasResults = true;
                        html += '<div class="sg-search-section">';
                        html += '<div class="sg-search-section-title">Products</div>';
                        data.products.forEach(function(p) {
                            var img = p.image ? '<img src="' + escA(p.image) + '" alt="">' : '&#128230;';
                            html += '<a href="<?= BASE_URL ?>store-detail.php?id=' + p.dealer_id + '" class="sg-search-item">' +
                                '<div class="sg-search-item-icon">' + img + '</div>' +
                                '<div class="sg-search-item-body">' +
                                    '<div class="sg-search-item-name">' + escH(p.name) + '</div>' +
                                    '<div class="sg-search-item-meta">' + escH(p.brand) + ' &middot; ' + escH(p.dealer_name) + (p.city ? ', ' + escH(p.city) : '') + '</div>' +
                                '</div>' +
                                '<div class="sg-search-item-price">$' + p.price.toFixed(2) + '</div>' +
                            '</a>';
                        });
                        html += '</div>';
                    }

                    // Stores
                    if (data.stores && data.stores.length > 0) {
                        hasResults = true;
                        html += '<div class="sg-search-section">';
                        html += '<div class="sg-search-section-title">Stores</div>';
                        data.stores.forEach(function(s) {
                            var img = s.logo ? '<img src="' + escA(s.logo) + '" alt="">' : '&#127978;';
                            var stars = s.rating > 0 ? '&#9733; ' + s.rating.toFixed(1) + ' (' + s.reviews + ')' : 'New store';
                            html += '<a href="<?= BASE_URL ?>store-detail.php?id=' + s.id + '" class="sg-search-item">' +
                                '<div class="sg-search-item-icon">' + img + '</div>' +
                                '<div class="sg-search-item-body">' +
                                    '<div class="sg-search-item-name">' + escH(s.business_name) + '</div>' +
                                    '<div class="sg-search-item-meta">' + stars + (s.city ? ' &middot; ' + escH(s.city) : '') + '</div>' +
                                '</div>' +
                            '</a>';
                        });
                        html += '</div>';
                    }

                    // Installers
                    if (data.installers && data.installers.length > 0) {
                        hasResults = true;
                        html += '<div class="sg-search-section">';
                        html += '<div class="sg-search-section-title">Installers</div>';
                        data.installers.forEach(function(inst) {
                            var img = inst.logo ? '<img src="' + escA(inst.logo) + '" alt="">' : '&#128295;';
                            var stars = inst.rating > 0 ? '&#9733; ' + inst.rating.toFixed(1) : '';
                            var exp = inst.experience > 0 ? inst.experience + ' yrs exp' : '';
                            var meta = [stars, exp, inst.city].filter(Boolean).join(' &middot; ');
                            html += '<a href="<?= BASE_URL ?>find-installer.php?highlight=' + inst.id + '" class="sg-search-item">' +
                                '<div class="sg-search-item-icon">' + img + '</div>' +
                                '<div class="sg-search-item-body">' +
                                    '<div class="sg-search-item-name">' + escH(inst.business_name) + '</div>' +
                                    '<div class="sg-search-item-meta">' + meta + '</div>' +
                                '</div>' +
                            '</a>';
                        });
                        html += '</div>';
                    }

                    if (!hasResults) {
                        html = '<div class="sg-search-empty">No results found for "' + escH(q) + '"</div>';
                    }

                    searchResults.innerHTML = html;
                })
                .catch(function() {
                    searchResults.innerHTML = '<div class="sg-search-empty">Search failed. Please try again.</div>';
                });
        }

        function escH(s) { var d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
        function escA(s) { return (s || '').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }
    })();
    </script>
    <?php if (!empty($_SESSION['customer_id'])): ?>
    <script>
    (function() {
        var notifBtn = document.getElementById('sgNotifBtn');
        var notifDropdown = document.getElementById('sgNotifDropdown');
        var notifList = document.getElementById('sgNotifList');
        var notifBadge = document.getElementById('sgNotifBadge');
        var markAllBtn = document.getElementById('sgNotifMarkAll');
        if (!notifBtn) return;

        var isOpen = false;

        function toggleDropdown(e) {
            e.stopPropagation();
            isOpen = !isOpen;
            notifDropdown.classList.toggle('open', isOpen);
            if (isOpen) loadNotifications();
        }

        function closeDropdown() {
            isOpen = false;
            notifDropdown.classList.remove('open');
        }

        notifBtn.addEventListener('click', toggleDropdown);
        document.addEventListener('click', function(e) {
            if (!notifDropdown.contains(e.target) && e.target !== notifBtn) closeDropdown();
        });

        function loadNotifications() {
            fetch('<?= BASE_URL ?>api/notifications.php?limit=10')
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (!data.success) return;
                    updateBadge(data.unread_count);
                    if (!data.notifications || data.notifications.length === 0) {
                        notifList.innerHTML = '<div class="sg-notif-empty">No notifications yet</div>';
                        return;
                    }
                    var html = '';
                    data.notifications.forEach(function(n) {
                        html += '<div class="sg-notif-item' + (n.is_read ? '' : ' unread') + '" data-id="' + n.id + '"' +
                            (n.link ? ' data-link="' + escAttr(n.link) + '"' : '') + '>' +
                            '<div class="sg-notif-item-title">' + esc(n.title) + '</div>' +
                            '<div class="sg-notif-item-msg">' + esc(n.message) + '</div>' +
                            '<div class="sg-notif-item-time">' + esc(n.time_ago) + '</div>' +
                        '</div>';
                    });
                    notifList.innerHTML = html;
                    // Bind click on items
                    notifList.querySelectorAll('.sg-notif-item').forEach(function(item) {
                        item.addEventListener('click', function() {
                            var nid = item.dataset.id;
                            var link = item.dataset.link;
                            markRead(nid);
                            item.classList.remove('unread');
                            if (link) window.location.href = link;
                        });
                    });
                })
                .catch(function() {});
        }

        function markRead(id) {
            fetch('<?= BASE_URL ?>api/notifications.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({action: 'mark_read', id: parseInt(id)})
            }).then(function(r) { return r.json(); }).then(function(d) {
                if (d.unread_count !== undefined) updateBadge(d.unread_count);
            }).catch(function() {});
        }

        if (markAllBtn) {
            markAllBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                fetch('<?= BASE_URL ?>api/notifications.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'mark_all_read'})
                }).then(function(r) { return r.json(); }).then(function(d) {
                    updateBadge(0);
                    notifList.querySelectorAll('.sg-notif-item').forEach(function(item) {
                        item.classList.remove('unread');
                    });
                }).catch(function() {});
            });
        }

        function updateBadge(count) {
            if (!notifBadge && count > 0) {
                var b = document.createElement('span');
                b.className = 'sg-notif-badge';
                b.id = 'sgNotifBadge';
                notifBtn.appendChild(b);
                notifBadge = b;
            }
            if (notifBadge) {
                notifBadge.textContent = count;
                notifBadge.style.display = count > 0 ? '' : 'none';
            }
        }

        function esc(s) { var d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
        function escAttr(s) { return (s || '').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }

        // Poll for new notifications every 60 seconds
        setInterval(function() {
            fetch('<?= BASE_URL ?>api/notifications.php?limit=1')
                .then(function(r) { return r.json(); })
                .then(function(d) { if (d.unread_count !== undefined) updateBadge(d.unread_count); })
                .catch(function() {});
        }, 60000);
    })();
    </script>
    <?php endif; ?>
