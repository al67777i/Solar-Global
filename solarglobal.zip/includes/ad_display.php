<?php
/**
 * Ad Display Component
 * Include this file and call renderAds($position) to show ads on frontend pages.
 *
 * Positions: header, sidebar, footer, between-steps
 * Supports: rotation of multiple ads in same position, impression tracking, GIF images
 *
 * Usage:
 *   <?php include_once 'includes/ad_display.php'; ?>
 *   <?php renderAds('header'); ?>
 */

/**
 * Get active ads for a position (with date filtering + geo-targeting)
 *
 * Logic:
 *  1. Try to detect user's country (IP/cookie)
 *  2. Fetch ads targeted to that country for this position
 *  3. If none found, fall back to universal ads (country_code IS NULL)
 *  4. If country-specific AND universal both exist, show country-specific first
 */
function getAdsForPosition($position) {
    static $cache = [];
    if (isset($cache[$position])) return $cache[$position];

    try {
        $pdo = getDB();
        $user_cc = '';

        // Detect user country
        if (function_exists('get_user_country_code')) {
            $user_cc = strtoupper(get_user_country_code());
        } elseif (function_exists('detect_user_country')) {
            $user_cc = strtoupper(detect_user_country() ?: '');
        }

        // Fetch country-specific ads first, then universal (country_code IS NULL)
        if (!empty($user_cc)) {
            $stmt = $pdo->prepare("
                SELECT id, title, image_path, redirect_url, width, height, position, country_code,
                       CASE WHEN country_code = ? THEN 0 ELSE 1 END AS sort_geo
                FROM custom_ads
                WHERE is_active = 1
                  AND position = ?
                  AND (country_code = ? OR country_code IS NULL OR country_code = '')
                  AND (start_date IS NULL OR start_date <= CURDATE())
                  AND (end_date IS NULL OR end_date >= CURDATE())
                ORDER BY sort_geo ASC, priority DESC, RAND()
            ");
            $stmt->execute([$user_cc, $position, $user_cc]);
        } else {
            // No country detected — show universal ads only
            $stmt = $pdo->prepare("
                SELECT id, title, image_path, redirect_url, width, height, position, country_code
                FROM custom_ads
                WHERE is_active = 1
                  AND position = ?
                  AND (country_code IS NULL OR country_code = '')
                  AND (start_date IS NULL OR start_date <= CURDATE())
                  AND (end_date IS NULL OR end_date >= CURDATE())
                ORDER BY priority DESC, RAND()
            ");
            $stmt->execute([$position]);
        }

        $all_ads = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // If country-specific ads exist, prefer those; otherwise use universal
        $country_ads = array_filter($all_ads, fn($a) => !empty($a['country_code']) && strtoupper($a['country_code']) === $user_cc);
        $universal_ads = array_filter($all_ads, fn($a) => empty($a['country_code']));

        // Country-specific takes priority; if none, fall back to universal
        $cache[$position] = !empty($country_ads) ? array_values($country_ads) : array_values($universal_ads);

    } catch (Exception $e) {
        $cache[$position] = [];
    }

    return $cache[$position];
}

/**
 * Render ads for a given position
 * @param string $position  One of: header, sidebar, footer, between-steps
 * @param int    $limit     Max ads to render (for rotation, all are rendered but only 1 visible)
 */
function renderAds($position, $limit = 10) {
    $ads = getAdsForPosition($position);
    if (empty($ads)) return;

    $ads = array_slice($ads, 0, $limit);
    $slotId = 'ad-slot-' . $position . '-' . mt_rand(1000, 9999);
    $count = count($ads);

    // Track impressions for the first visible ad (JS will track on rotation)
    $firstAd = $ads[0];
    trackAdImpression(getDB(), $firstAd['id']);

    // Container classes based on position
    $containerClass = 'SolarGlobal-ad-slot';
    $alignClass = '';
    switch ($position) {
        case 'header':
            $containerClass .= ' ad-slot-header';
            $alignClass = 'text-align:center;';
            break;
        case 'sidebar':
            $containerClass .= ' ad-slot-sidebar';
            $alignClass = 'text-align:center;';
            break;
        case 'footer':
            $containerClass .= ' ad-slot-footer';
            $alignClass = 'text-align:center;';
            break;
        case 'between-steps':
            $containerClass .= ' ad-slot-between';
            $alignClass = 'text-align:center;';
            break;
    }
    ?>
    <div class="<?= $containerClass ?>" id="<?= $slotId ?>" style="<?= $alignClass ?>overflow:hidden;margin:16px auto;max-width:100%;">
        <?php foreach ($ads as $i => $ad):
            $w = intval($ad['width']) ?: 728;
            $h = intval($ad['height']) ?: 90;
            $display = $i === 0 ? 'block' : 'none';
        ?>
        <div class="ad-item" data-ad-id="<?= $ad['id'] ?>" style="display:<?= $display ?>;">
            <a href="api/track_ad.php?id=<?= $ad['id'] ?>"
               target="_blank" rel="noopener sponsored"
               title="<?= sanitize($ad['title']) ?>"
               style="display:inline-block;line-height:0;">
                <img src="<?= sanitize($ad['image_path']) ?>"
                     alt="<?= sanitize($ad['title']) ?>"
                     width="<?= $w ?>"
                     height="<?= $h ?>"
                     loading="lazy"
                     style="max-width:100%;height:auto;border-radius:8px;cursor:pointer;">
            </a>
        </div>
        <?php endforeach; ?>
        <?php if ($count > 1): ?>
        <script>
        (function() {
            var slot = document.getElementById('<?= $slotId ?>');
            if (!slot) return;
            var items = slot.querySelectorAll('.ad-item');
            var total = items.length;
            if (total <= 1) return;
            var current = 0;
            var rotateInterval = <?= ($count <= 3) ? 60000 : 30000 ?>; // 60s for few ads, 30s for many

            setInterval(function() {
                items[current].style.display = 'none';
                current = (current + 1) % total;
                items[current].style.display = 'block';

                // Track impression via beacon
                var adId = items[current].getAttribute('data-ad-id');
                if (navigator.sendBeacon) {
                    navigator.sendBeacon('api/track_impression.php?id=' + adId);
                }
            }, rotateInterval);
        })();
        </script>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Render a single inline ad between product cards (for grid insertion)
 * Returns HTML string instead of echoing
 */
function getInlineAdHtml($position = 'sidebar') {
    $ads = getAdsForPosition($position);
    if (empty($ads)) return '';

    // Pick a random ad
    $ad = $ads[array_rand($ads)];
    $w = intval($ad['width']) ?: 728;
    $h = intval($ad['height']) ?: 90;

    trackAdImpression(getDB(), $ad['id']);

    return '<div class="SolarGlobal-ad-inline" style="text-align:center;margin:12px 0;grid-column:1/-1;">
        <a href="api/track_ad.php?id=' . $ad['id'] . '"
           target="_blank" rel="noopener sponsored"
           title="' . sanitize($ad['title']) . '"
           style="display:inline-block;line-height:0;">
            <img src="' . sanitize($ad['image_path']) . '"
                 alt="' . sanitize($ad['title']) . '"
                 width="' . $w . '" height="' . $h . '"
                 loading="lazy"
                 style="max-width:100%;height:auto;border-radius:8px;cursor:pointer;">
        </a>
    </div>';
}
