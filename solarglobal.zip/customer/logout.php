<?php
/**
 * Customer Logout
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/customer_auth.php';

customer_logout();
header('Location: /solarglobal/customer/login.php');
exit();
