﻿/**
 * Admin Pinpoint Editor
 * For marking connection points on inverter/panel/battery images
 */

// This file is for future pinpoint editor functionality
// Currently just ensures no JavaScript errors
