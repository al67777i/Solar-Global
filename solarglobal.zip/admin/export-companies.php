<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

$db = getDB();

$format = $_GET['format'] ?? 'csv';

$companies = $db->query("
    SELECT c.id, c.name,
           COUNT(DISTINCT i.id) as inverter_count,
           COUNT(DISTINCT b.id) as battery_count,
           COUNT(DISTINCT p.id) as panel_count
    FROM companies c
    LEFT JOIN inverters i ON i.company_id = c.id
    LEFT JOIN batteries b ON b.company_id = c.id
    LEFT JOIN panels p ON p.company_id = c.id
    WHERE c.is_active = 1
    GROUP BY c.id, c.name
    ORDER BY c.name ASC
")->fetchAll();

if ($format === 'json') {
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="companies_list.json"');
    echo json_encode([
        'instruction' => 'Use these exact brand names in the "brand" column of your CSV import. Do NOT create new brand names - use one from this list.',
        'price_note' => 'All prices must be in USD (price_usd column). The system stores everything in USD globally.',
        'companies' => array_map(function($c) {
            return [
                'brand_name' => $c['name'],
                'products' => [
                    'inverters' => (int)$c['inverter_count'],
                    'batteries' => (int)$c['battery_count'],
                    'panels' => (int)$c['panel_count']
                ]
            ];
        }, $companies)
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} else {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="companies_list.csv"');
    header('Cache-Control: no-cache, no-store, must-revalidate');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['brand_name', 'inverter_count', 'battery_count', 'panel_count']);
    foreach ($companies as $c) {
        fputcsv($output, [$c['name'], $c['inverter_count'], $c['battery_count'], $c['panel_count']]);
    }
    fclose($output);
}
exit;
