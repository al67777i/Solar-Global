<?php
/**
 * Ad Click Tracking API
 * Records ad clicks and redirects to target URL
 */
require_once '../includes/db.php';
require_once '../includes/helpers.php';

if (!rate_limit('api_track_ad', 60, 60)) { respond_rate_limited(); }

$adId = intval($_GET['id'] ?? 0);
if ($adId <= 0) {
    http_response_code(400);
    exit('Invalid ad ID');
}

$db = getDB();
trackAdClick($db, $adId);

// Get redirect URL
$stmt = $db->prepare("SELECT redirect_url FROM custom_ads WHERE id = ?");
$stmt->execute([$adId]);
$ad = $stmt->fetch();

if ($ad) {
    header('Location: ' . $ad['redirect_url'], true, 302);
} else {
    header('Location: /');
}
exit;
