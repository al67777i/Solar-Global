<?php
/**
 * Auto-Cancel Orders Cron Job
 * Cancels orders where status='ready' AND pickup_deadline < NOW()
 *
 * Run via cron: php /path/to/solarglobal/cron/auto_cancel_orders.php
 * Recommended: every 15 minutes
 *
 * Or via browser: http://localhost/solarglobal/cron/auto_cancel_orders.php?key=YOUR_CRON_KEY
 */

// Security: require cron key if accessed via browser
if (php_sapi_name() !== 'cli') {
    $expected_key = 'solarglobal_cron_2026'; // Change this in production
    if (($_GET['key'] ?? '') !== $expected_key) {
        http_response_code(403);
        die('Forbidden');
    }
}

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/notification_helpers.php';

$db = getDB();
$cancelled = 0;
$restored_items = 0;

try {
    // Find orders that are 'ready' and past pickup deadline
    $stmt = $db->query("
        SELECT id, order_number, dealer_id, customer_id
        FROM orders
        WHERE status = 'ready'
        AND pickup_deadline IS NOT NULL
        AND pickup_deadline < NOW()
    ");
    $expired_orders = $stmt->fetchAll();

    foreach ($expired_orders as $order) {
        try {
            $db->beginTransaction();

            // Cancel the order
            $db->prepare("
                UPDATE orders
                SET status = 'cancelled',
                    cancelled_at = NOW(),
                    cancel_reason = 'Auto-cancelled: pickup deadline exceeded'
                WHERE id = ? AND status = 'ready'
            ")->execute([$order['id']]);

            // Restore stock for each item
            $items = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
            $items->execute([$order['id']]);

            foreach ($items->fetchAll() as $item) {
                // Find the dealer_product and restore stock
                $db->prepare("
                    UPDATE dealer_products
                    SET stock_quantity = stock_quantity + ?,
                        stock_status = CASE
                            WHEN stock_quantity + ? > 5 THEN 'in_stock'
                            WHEN stock_quantity + ? > 0 THEN 'low_stock'
                            ELSE 'out_of_stock'
                        END
                    WHERE dealer_id = ? AND product_type = ? AND product_id = ?
                ")->execute([
                    $item['quantity'], $item['quantity'], $item['quantity'],
                    $order['dealer_id'], $item['product_type'], $item['product_id']
                ]);

                $restored_items++;
            }

            $db->commit();
            $cancelled++;

            // Notify customer and dealer
            if (!empty($order['customer_id'])) {
                create_notification('customer', (int)$order['customer_id'], 'order_cancelled',
                    'Order Auto-Cancelled: ' . $order['order_number'],
                    'Your order was automatically cancelled because the pickup deadline was exceeded.',
                    '/solarglobal/customer/orders.php');
            }
            create_notification('dealer', (int)$order['dealer_id'], 'order_cancelled',
                'Order Auto-Cancelled: ' . $order['order_number'],
                'Order was automatically cancelled (pickup deadline exceeded). Stock has been restored.',
                '/solarglobal/dealer/orders.php');

            echo "[" . date('Y-m-d H:i:s') . "] Cancelled order {$order['order_number']} (ID: {$order['id']})\n";

        } catch (Exception $e) {
            $db->rollBack();
            echo "[" . date('Y-m-d H:i:s') . "] ERROR cancelling order {$order['order_number']}: {$e->getMessage()}\n";
        }
    }

    // Also cancel 'pending' orders older than 48 hours (dealer never confirmed)
    $stmt = $db->query("
        SELECT id, order_number, dealer_id, customer_id
        FROM orders
        WHERE status = 'pending'
        AND created_at < DATE_SUB(NOW(), INTERVAL 48 HOUR)
    ");
    $stale_orders = $stmt->fetchAll();

    foreach ($stale_orders as $order) {
        try {
            $db->beginTransaction();

            $db->prepare("
                UPDATE orders
                SET status = 'cancelled',
                    cancelled_at = NOW(),
                    cancel_reason = 'Auto-cancelled: dealer did not confirm within 48 hours'
                WHERE id = ? AND status = 'pending'
            ")->execute([$order['id']]);

            // Restore stock
            $items = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
            $items->execute([$order['id']]);

            foreach ($items->fetchAll() as $item) {
                $db->prepare("
                    UPDATE dealer_products
                    SET stock_quantity = stock_quantity + ?,
                        stock_status = CASE
                            WHEN stock_quantity + ? > 5 THEN 'in_stock'
                            WHEN stock_quantity + ? > 0 THEN 'low_stock'
                            ELSE 'out_of_stock'
                        END
                    WHERE dealer_id = ? AND product_type = ? AND product_id = ?
                ")->execute([
                    $item['quantity'], $item['quantity'], $item['quantity'],
                    $order['dealer_id'], $item['product_type'], $item['product_id']
                ]);

                $restored_items++;
            }

            $db->commit();
            $cancelled++;

            // Notify customer and dealer about stale cancellation
            if (!empty($order['customer_id'])) {
                create_notification('customer', (int)$order['customer_id'], 'order_cancelled',
                    'Order Auto-Cancelled: ' . $order['order_number'],
                    'Your order was automatically cancelled because the dealer did not confirm it within 48 hours.',
                    '/solarglobal/customer/orders.php');
            }
            create_notification('dealer', (int)$order['dealer_id'], 'order_cancelled',
                'Unconfirmed Order Cancelled: ' . $order['order_number'],
                'This order was automatically cancelled because it was not confirmed within 48 hours. Please check your orders regularly.',
                '/solarglobal/dealer/orders.php');

            echo "[" . date('Y-m-d H:i:s') . "] Cancelled stale order {$order['order_number']} (ID: {$order['id']})\n";

        } catch (Exception $e) {
            $db->rollBack();
            echo "[" . date('Y-m-d H:i:s') . "] ERROR cancelling stale order {$order['order_number']}: {$e->getMessage()}\n";
        }
    }

} catch (Exception $e) {
    echo "[" . date('Y-m-d H:i:s') . "] FATAL ERROR: {$e->getMessage()}\n";
    exit(1);
}

echo "\n[" . date('Y-m-d H:i:s') . "] Done. Cancelled: $cancelled orders, Restored: $restored_items item stocks.\n";
