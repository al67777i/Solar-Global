-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: solarglobal
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appliances`
--

DROP TABLE IF EXISTS `appliances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appliances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(150) NOT NULL,
  `name_ur` varchar(150) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `watt_typical` int(11) NOT NULL,
  `surge_load_watts` int(11) DEFAULT 0 COMMENT 'Starting surge load for motors/compressors (0 if no surge)',
  `standby_watts` int(11) DEFAULT 0 COMMENT 'Standby power consumption',
  `category` varchar(100) DEFAULT 'General',
  `season_tags` varchar(255) DEFAULT 'all_year' COMMENT 'Comma-separated: summer,winter,monsoon,spring,all_year',
  `usage_hours_summer` decimal(4,1) DEFAULT 4.0,
  `usage_hours_winter` decimal(4,1) DEFAULT 4.0,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `batteries`
--

DROP TABLE IF EXISTS `batteries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batteries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `voltage` int(11) NOT NULL,
  `capacity_ah` int(11) NOT NULL,
  `price_pkr` decimal(10,2) NOT NULL,
  `has_bms` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `pinpoints` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pinpoints`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `battery_type` varchar(50) DEFAULT 'Deep Cycle',
  `warranty_years` int(11) DEFAULT 2,
  `cycle_life` int(11) DEFAULT NULL COMMENT 'Expected charge/discharge cycles',
  `depth_of_discharge` int(11) DEFAULT 50 COMMENT 'Recommended DoD percentage',
  `charging_current_max` int(11) DEFAULT NULL COMMENT 'Maximum charging current (Amps)',
  `weight_kg` decimal(6,2) DEFAULT NULL COMMENT 'Weight in kilograms',
  `dimensions` varchar(50) DEFAULT NULL COMMENT 'Dimensions L x W x H (mm)',
  `maintenance_free` tinyint(1) DEFAULT 0 COMMENT '1=Maintenance free, 0=Requires maintenance',
  `temperature_range` varchar(30) DEFAULT '-10C to 50C' COMMENT 'Operating temperature range',
  `communication` varchar(100) DEFAULT NULL COMMENT 'Communication protocol RS485/CAN/None',
  `certifications` varchar(200) DEFAULT NULL COMMENT 'Certifications CE/UL/IEC',
  `country_origin` varchar(50) DEFAULT NULL COMMENT 'Country of manufacture',
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  KEY `idx_voltage` (`voltage`),
  KEY `idx_active` (`is_active`),
  KEY `idx_battery_type` (`battery_type`),
  KEY `idx_cycle_life` (`cycle_life`),
  KEY `idx_maintenance_free` (`maintenance_free`),
  CONSTRAINT `batteries_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `battery_inverter_compatibility`
--

DROP TABLE IF EXISTS `battery_inverter_compatibility`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `battery_inverter_compatibility` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inverter_id` int(11) NOT NULL,
  `battery_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_pair` (`inverter_id`,`battery_id`),
  KEY `battery_id` (`battery_id`),
  CONSTRAINT `battery_inverter_compatibility_ibfk_1` FOREIGN KEY (`inverter_id`) REFERENCES `inverters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `battery_inverter_compatibility_ibfk_2` FOREIGN KEY (`battery_id`) REFERENCES `batteries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `battery_pinpoints`
--

DROP TABLE IF EXISTS `battery_pinpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `battery_pinpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `battery_id` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  `x_percent` decimal(5,2) NOT NULL,
  `y_percent` decimal(5,2) NOT NULL,
  `color` varchar(20) DEFAULT '#FF0000',
  PRIMARY KEY (`id`),
  KEY `idx_battery` (`battery_id`),
  CONSTRAINT `battery_pinpoints_ibfk_1` FOREIGN KEY (`battery_id`) REFERENCES `batteries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) NOT NULL,
  `name_ur` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `latitude` decimal(8,5) NOT NULL,
  `longitude` decimal(8,5) NOT NULL,
  `elevation_m` int(11) DEFAULT 0,
  `timezone` varchar(50) DEFAULT 'Asia/Karachi',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name_en`),
  KEY `idx_province` (`province`),
  KEY `idx_active` (`is_active`),
  KEY `idx_coords` (`latitude`,`longitude`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `logo_path` varchar(255) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'Pakistan',
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `city_id` (`city_id`),
  KEY `idx_read` (`is_read`),
  KEY `idx_date` (`created_at`),
  CONSTRAINT `contact_messages_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_ads`
--

DROP TABLE IF EXISTS `custom_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `image_path` varchar(500) NOT NULL,
  `redirect_url` varchar(500) NOT NULL,
  `position` enum('header','sidebar','footer','popup','between-steps') DEFAULT 'sidebar',
  `width` int(11) DEFAULT 728,
  `height` int(11) DEFAULT 90,
  `is_active` tinyint(1) DEFAULT 1,
  `impressions` int(11) DEFAULT 0,
  `clicks` int(11) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `priority` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_active` (`is_active`),
  KEY `idx_position` (`position`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_forecasts`
--

DROP TABLE IF EXISTS `energy_forecasts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_forecasts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) NOT NULL,
  `forecast_date` date NOT NULL,
  `panel_watts` int(11) NOT NULL DEFAULT 550,
  `num_panels` int(11) NOT NULL DEFAULT 4,
  `gross_kwh` decimal(6,2) NOT NULL,
  `net_kwh` decimal(6,2) NOT NULL,
  `peak_sun_hours` decimal(4,2) DEFAULT NULL,
  `temperature_c` decimal(4,1) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_forecast` (`city_id`,`forecast_date`,`panel_watts`,`num_panels`),
  KEY `idx_city_date` (`city_id`,`forecast_date`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2221 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inverter_pinpoints`
--

DROP TABLE IF EXISTS `inverter_pinpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inverter_pinpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inverter_id` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  `x_percent` decimal(5,2) NOT NULL,
  `y_percent` decimal(5,2) NOT NULL,
  `color` varchar(20) DEFAULT '#FF0000',
  PRIMARY KEY (`id`),
  KEY `idx_inverter` (`inverter_id`),
  CONSTRAINT `inverter_pinpoints_ibfk_1` FOREIGN KEY (`inverter_id`) REFERENCES `inverters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inverters`
--

DROP TABLE IF EXISTS `inverters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inverters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `voltage_class` enum('12V','24V','48V') NOT NULL,
  `max_load_watts` int(11) NOT NULL,
  `output_watts` int(11) NOT NULL,
  `price_pkr` decimal(10,2) NOT NULL,
  `has_bms` tinyint(1) DEFAULT 0,
  `inverter_type` enum('off-grid','on-grid','hybrid') DEFAULT 'off-grid',
  `has_l1` tinyint(1) DEFAULT 1,
  `has_l2` tinyint(1) DEFAULT 0,
  `has_l3` tinyint(1) DEFAULT 0,
  `has_grid_import` tinyint(1) DEFAULT 0,
  `pinpoints` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pinpoints`)),
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `efficiency_percent` decimal(5,2) DEFAULT 90.00,
  `ip_rating` varchar(10) DEFAULT NULL COMMENT 'IP protection rating (IP21/IP54/IP65/IP66)',
  `input_voltage_min` int(11) DEFAULT NULL COMMENT 'Minimum PV input voltage (VDC)',
  `input_voltage_max` int(11) DEFAULT NULL COMMENT 'Maximum PV input voltage (VDC)',
  `max_pv_input` int(11) DEFAULT NULL COMMENT 'Maximum PV input power (Watts)',
  `mppt_count` int(11) DEFAULT 1 COMMENT 'Number of MPPT trackers',
  `max_input_current` int(11) DEFAULT NULL COMMENT 'Maximum input current per MPPT (Amps)',
  `output_voltage` int(11) DEFAULT 230 COMMENT 'Output voltage (VAC)',
  `output_frequency` int(11) DEFAULT 50 COMMENT 'Output frequency (Hz)',
  `surge_power_watts` int(11) DEFAULT NULL COMMENT 'Surge/Peak power capacity (Watts)',
  `warranty_years` int(11) DEFAULT 5 COMMENT 'Warranty period (years)',
  `weight_kg` decimal(6,2) DEFAULT NULL COMMENT 'Weight (kg)',
  `dimensions` varchar(50) DEFAULT NULL COMMENT 'Dimensions L×W×H (mm)',
  `cooling_method` varchar(50) DEFAULT 'Natural' COMMENT 'Cooling method (Natural/Fan/Liquid)',
  `display_type` varchar(50) DEFAULT NULL COMMENT 'Display type (LCD/LED/OLED/None)',
  `communication` varchar(100) DEFAULT NULL COMMENT 'Communication interfaces',
  `certifications` varchar(200) DEFAULT NULL COMMENT 'Certifications (CE/IEC/VDE/UL)',
  `country_origin` varchar(50) DEFAULT NULL COMMENT 'Country of manufacture',
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  KEY `idx_voltage` (`voltage_class`),
  KEY `idx_active` (`is_active`),
  KEY `idx_load` (`max_load_watts`),
  KEY `idx_max_pv_input` (`max_pv_input`),
  CONSTRAINT `inverters_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=485 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `panels`
--

DROP TABLE IF EXISTS `panels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `panels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `watt_peak` int(11) NOT NULL,
  `voc` decimal(6,2) NOT NULL,
  `vmp` decimal(6,2) NOT NULL,
  `isc` decimal(6,2) NOT NULL,
  `price_pkr` decimal(10,2) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `pinpoints` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pinpoints`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `panel_type` varchar(50) DEFAULT 'Monocrystalline',
  `efficiency_percent` decimal(5,2) DEFAULT 20.00,
  `warranty_years` int(11) DEFAULT 25,
  `degradation_percent` decimal(4,2) DEFAULT 0.55 COMMENT 'Annual degradation rate',
  `temperature_coefficient` decimal(5,3) DEFAULT -0.350 COMMENT 'Temperature coefficient pct per degree C',
  `dimensions` varchar(50) DEFAULT NULL COMMENT 'Panel dimensions L x W x H mm',
  `weight_kg` decimal(6,2) DEFAULT NULL COMMENT 'Weight in kilograms',
  `cells_count` int(11) DEFAULT 60 COMMENT 'Number of solar cells',
  `max_system_voltage` int(11) DEFAULT 1000 COMMENT 'Maximum system voltage VDC',
  `operating_temp` varchar(30) DEFAULT '-40C to +85C' COMMENT 'Operating temperature range',
  `certifications` varchar(200) DEFAULT NULL COMMENT 'Certifications IEC/CE/UL',
  `country_origin` varchar(50) DEFAULT NULL COMMENT 'Country of manufacture',
  `frame_color` varchar(30) DEFAULT 'Silver' COMMENT 'Frame color Silver or Black',
  `backsheet_color` varchar(30) DEFAULT 'White' COMMENT 'Backsheet color White or Black',
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  KEY `idx_active` (`is_active`),
  KEY `idx_watt` (`watt_peak`),
  KEY `idx_panel_type` (`panel_type`),
  KEY `idx_efficiency` (`efficiency_percent`),
  KEY `idx_watt_peak` (`watt_peak`),
  CONSTRAINT `panels_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=252 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `seasonal_appliance_mapping`
--

DROP TABLE IF EXISTS `seasonal_appliance_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seasonal_appliance_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appliance_id` int(11) NOT NULL,
  `season` enum('summer','winter','monsoon','spring','all_year') NOT NULL,
  `usage_probability` decimal(3,2) NOT NULL DEFAULT 0.50 COMMENT '0.00-1.00 likelihood of use',
  `priority_rank` tinyint(4) DEFAULT 5 COMMENT '1=essential, 10=optional',
  `recommended_hours` decimal(4,1) DEFAULT 4.0 COMMENT 'Daily recommended usage hours',
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_appliance_season` (`appliance_id`,`season`),
  KEY `idx_season` (`season`),
  KEY `idx_priority` (`priority_rank`),
  CONSTRAINT `seasonal_appliance_mapping_ibfk_1` FOREIGN KEY (`appliance_id`) REFERENCES `appliances` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sun_data`
--

DROP TABLE IF EXISTS `sun_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sun_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) NOT NULL,
  `month` tinyint(4) NOT NULL COMMENT '1=Jan, 12=Dec',
  `avg_sunrise` time NOT NULL,
  `avg_sunset` time NOT NULL,
  `avg_daylight_hours` decimal(4,2) NOT NULL,
  `peak_sun_hours` decimal(4,2) NOT NULL COMMENT 'Effective solar hours (PSH)',
  `avg_irradiance_kwh_m2` decimal(5,2) NOT NULL COMMENT 'Daily solar irradiance kWh/m??',
  `avg_temperature_c` decimal(4,1) NOT NULL,
  `avg_cloud_cover_percent` decimal(4,1) DEFAULT 20.0,
  `avg_humidity_percent` decimal(4,1) DEFAULT 50.0,
  `panel_efficiency_factor` decimal(4,3) DEFAULT 0.800 COMMENT 'Weather-adjusted efficiency 0-1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_city_month` (`city_id`,`month`),
  KEY `idx_city` (`city_id`),
  KEY `idx_month` (`month`),
  CONSTRAINT `sun_data_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=577 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `description` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `traffic_daily`
--

DROP TABLE IF EXISTS `traffic_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `traffic_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_date` date NOT NULL,
  `page_views` int(11) DEFAULT 0,
  `unique_visitors` int(11) DEFAULT 0,
  `new_visitors` int(11) DEFAULT 0,
  `bounce_rate` decimal(5,2) DEFAULT 0.00,
  `avg_session_duration` int(11) DEFAULT 0,
  `top_page` varchar(200) DEFAULT NULL,
  `top_referer` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_date` (`visit_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `visitor_stats`
--

DROP TABLE IF EXISTS `visitor_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitor_stats` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `page_url` varchar(500) DEFAULT NULL,
  `referer` varchar(500) DEFAULT NULL,
  `location` varchar(100) DEFAULT 'Unknown',
  `country` varchar(50) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `device_type` enum('desktop','mobile','tablet','bot') DEFAULT 'desktop',
  `browser` varchar(50) DEFAULT NULL,
  `os` varchar(50) DEFAULT NULL,
  `session_id` varchar(64) DEFAULT NULL,
  `visit_date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_date` (`visit_date`),
  KEY `idx_page` (`page_url`(100)),
  KEY `idx_session` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=248 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `weather_cache`
--

DROP TABLE IF EXISTS `weather_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weather_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) NOT NULL,
  `forecast_date` date NOT NULL,
  `temperature_max` decimal(4,1) NOT NULL,
  `temperature_min` decimal(4,1) NOT NULL,
  `temperature_avg` decimal(4,1) NOT NULL,
  `cloud_cover_percent` decimal(4,1) DEFAULT 0.0,
  `precipitation_mm` decimal(5,1) DEFAULT 0.0,
  `humidity_percent` decimal(4,1) DEFAULT 50.0,
  `wind_speed_kmh` decimal(5,1) DEFAULT 0.0,
  `uv_index` decimal(3,1) DEFAULT 5.0,
  `sunshine_hours` decimal(4,2) DEFAULT 0.00,
  `solar_irradiance_kwh_m2` decimal(5,2) DEFAULT 0.00 COMMENT 'Calculated daily irradiance',
  `weather_condition` varchar(50) DEFAULT 'Clear' COMMENT 'Clear, Cloudy, Rainy, Foggy, etc.',
  `fetched_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_city_date` (`city_id`,`forecast_date`),
  KEY `idx_city` (`city_id`),
  KEY `idx_date` (`forecast_date`),
  KEY `idx_expires` (`expires_at`),
  CONSTRAINT `weather_cache_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=495 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-14  8:41:06
