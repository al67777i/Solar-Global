<?php
/**
 * Dealer Orders Detail – JSON endpoint for order detail modal
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

header('Content-Type: application/json; charset=utf-8');

// Must be logged in
if (!is_dealer_logged_in()) {
    echo json_encode(['error' => 'Unauthorised']);
    exit;
}

$dealer_id = (int)get_dealer_id();
$order_id  = (int)($_GET['id'] ?? 0);

if (!$order_id) {
    echo json_encode(['error' => 'Invalid order ID']);
    exit;
}

$db = getDB();

// Fetch order (must belong to this dealer)
$stmt = $db->prepare(
    "SELECT o.*, c.name AS cust_name, c.email AS cust_email, c.phone AS cust_phone
     FROM orders o
     LEFT JOIN customers c ON c.id = o.customer_id
     WHERE o.id = ? AND o.dealer_id = ?"
);
$stmt->execute([$order_id, $dealer_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    echo json_encode(['error' => 'Order not found']);
    exit;
}

// Fetch order items
$items_stmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ? ORDER BY id ASC");
$items_stmt->execute([$order_id]);
$items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

// Build response
$order = [
    'id'             => (int)$row['id'],
    'order_number'   => $row['order_number'],
    'status'         => $row['status'],
    'total_amount'   => $row['total_amount'],
    'currency'       => $row['currency'] ?: 'USD',
    'item_count'     => (int)$row['item_count'],
    'notes'          => $row['notes'],
    'pickup_deadline'=> $row['pickup_deadline'],
    'created_at'     => $row['created_at'],
    'confirmed_at'   => $row['confirmed_at'],
    'ready_at'       => $row['ready_at'],
    'picked_up_at'   => $row['picked_up_at'],
    'cancelled_at'   => $row['cancelled_at'],
    'cancel_reason'  => $row['cancel_reason'],
];

$customer = [
    'name'  => $row['cust_name'],
    'email' => $row['cust_email'],
    'phone' => $row['cust_phone'],
];

echo json_encode([
    'order'    => $order,
    'customer' => $customer,
    'items'    => $items,
], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
