<?php
/**
 * AJAX endpoint for browsing companies with pagination
 */
require_once '../../includes/auth.php';
require_once '../../includes/db.php';
require_once '../../includes/helpers.php';

header('Content-Type: application/json');

$db = getDB();

// Pagination
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = max(10, min(100, intval($_GET['per_page'] ?? 25)));
$offset = ($page - 1) * $perPage;

// Search & filters
$search = trim($_GET['search'] ?? '');
$sort = $_GET['sort'] ?? 'name';

// Build query
$where = [];
$params = [];

if (!empty($search)) {
    $where[] = "c.name LIKE ?";
    $params[] = "%$search%";
}

$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Count total
$countSQL = "SELECT COUNT(*) FROM companies c $whereSQL";
$stmt = $db->prepare($countSQL);
$stmt->execute($params);
$total = (int)$stmt->fetchColumn();

// Build ORDER BY
$orderBy = "ORDER BY c.name ASC";
if ($sort === 'products') {
    $orderBy = "ORDER BY (SELECT COUNT(*) FROM inverters WHERE company_id=c.id)+(SELECT COUNT(*) FROM batteries WHERE company_id=c.id)+(SELECT COUNT(*) FROM panels WHERE company_id=c.id) DESC";
} elseif ($sort === 'country') {
    $orderBy = "ORDER BY c.country ASC, c.name ASC";
}

// Fetch companies with product counts
$sql = "SELECT c.*,
    (SELECT COUNT(*) FROM inverters WHERE company_id=c.id AND is_active=1) AS inverter_count,
    (SELECT COUNT(*) FROM batteries WHERE company_id=c.id AND is_active=1) AS battery_count,
    (SELECT COUNT(*) FROM panels WHERE company_id=c.id AND is_active=1) AS panel_count
    FROM companies c
    $whereSQL
    $orderBy
    LIMIT $perPage OFFSET $offset";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$companies = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Format for JSON
$rows = [];
foreach ($companies as $c) {
    $rows[] = [
        'id' => (int)$c['id'],
        'name' => $c['name'],
        'country' => $c['country'] ?? '',
        'website' => $c['website'] ?? '',
        'description' => $c['description'] ?? '',
        'logo_path' => $c['logo_path'] ?? '',
        'inverter_count' => (int)$c['inverter_count'],
        'battery_count' => (int)$c['battery_count'],
        'panel_count' => (int)$c['panel_count'],
        'total_products' => (int)$c['inverter_count'] + (int)$c['battery_count'] + (int)$c['panel_count']
    ];
}

$totalPages = max(1, ceil($total / $perPage));

echo json_encode([
    'success' => true,
    'rows' => $rows,
    'page' => $page,
    'per_page' => $perPage,
    'total' => $total,
    'total_pages' => $totalPages
]);
