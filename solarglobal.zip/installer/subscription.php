<?php
/**
 * Installer Subscription Page
 * Stripe Checkout integration for installer subscriptions
 * If installer fee is $0, allows free activation without Stripe
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/installer_auth.php';
require_once __DIR__ . '/../includes/stripe_config.php';
require_once __DIR__ . '/../includes/data_retention.php';

set_security_headers();
require_installer_login();

$installer = get_installer_profile();
$db = getDB();

// Note: subscription columns (stripe_customer_id, stripe_subscription_id, subscription_status,
// subscription_started_at, subscription_expires_at) are created by migration_core_tables.php
// and fixed by migration_030_subscription_fix.php — no runtime ALTER TABLE needed.

$success = '';
$error = '';

// Get payment settings
$stripeKeys = getStripeKeys();
$installerFee = (float)getPaymentSetting('installer_monthly_fee', '0.00');
$currency = getPaymentSetting('payment_currency', 'usd');
$isTestMode = ($stripeKeys['mode'] === 'test');
$stripeConfigured = !empty($stripeKeys['secret_key']) && !empty($stripeKeys['publishable_key']);
$isFree = ($installerFee <= 0);

// Handle successful return from Stripe Checkout
if (isset($_GET['session_id']) && !empty($_GET['session_id'])) {
    $sessionId = $_GET['session_id'];
    $result = getStripeCheckoutSession($sessionId);

    if ($result['success'] && $result['data']['payment_status'] === 'paid') {
        $session = $result['data'];
        $stripeCustomerId = $session['customer'] ?? '';
        $stripeSubscriptionId = $session['subscription'] ?? '';

        $stmt = $db->prepare("
            UPDATE installers SET
                stripe_customer_id = ?,
                stripe_subscription_id = ?,
                subscription_status = 'active',
                subscription_started_at = NOW(),
                subscription_expires_at = DATE_ADD(NOW(), INTERVAL 1 MONTH),
                status = CASE WHEN status IN ('approved','pending','inactive') THEN 'active' ELSE status END
            WHERE id = ?
        ");
        $stmt->execute([$stripeCustomerId, $stripeSubscriptionId, $installer['id']]);

        $_SESSION['installer_status'] = 'active';
        $success = 'Subscription activated! Your installer profile is now live.';
        $installer = get_installer_profile();
    } else {
        $error = 'Could not verify payment session. Please contact support if you were charged.';
    }
}

// Handle canceled return from Stripe
if (isset($_GET['canceled'])) {
    $error = 'Payment was canceled. You can try again when ready.';
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';

    if ($action === 'activate_free') {
        if (!$isFree) {
            $error = 'This subscription requires payment.';
        } else {
            $stmt = $db->prepare("
                UPDATE installers SET
                    subscription_status = 'active',
                    subscription_started_at = NOW(),
                    subscription_expires_at = NULL,
                    status = CASE WHEN status IN ('approved','pending','inactive') THEN 'active' ELSE status END
                WHERE id = ?
            ");
            $stmt->execute([$installer['id']]);

            $_SESSION['installer_status'] = 'active';
            $success = 'Your free installer profile has been activated!';
            $installer = get_installer_profile();
        }
    }

    if ($action === 'create_checkout') {
        if (!$stripeConfigured) {
            $error = 'Payment system is not configured. Please contact the administrator.';
        } elseif ($installerFee <= 0) {
            $error = 'Invalid subscription fee configured.';
        } else {
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $baseUrl = $protocol . '://' . $_SERVER['HTTP_HOST'] . '/solarglobal/installer/subscription.php';

            $checkoutParams = [
                'customer_email' => $installer['email'],
                'price_amount' => (int)round($installerFee * 100),
                'currency' => $currency,
                'product_name' => get_system_setting('site_name', 'SolarGlobal') . ' Installer Profile - Monthly Subscription',
                'success_url' => $baseUrl . '?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => $baseUrl . '?canceled=1',
                'metadata' => [
                    'installer_id' => (string)$installer['id'],
                    'type' => 'installer',
                ],
            ];

            if (!empty($installer['stripe_customer_id'])) {
                $checkoutParams['customer_id'] = $installer['stripe_customer_id'];
                unset($checkoutParams['customer_email']);
            }

            $result = createStripeCheckoutSession($checkoutParams);

            if ($result['success'] && !empty($result['data']['url'])) {
                header('Location: ' . $result['data']['url']);
                exit();
            } else {
                $error = 'Could not create checkout session: ' . ($result['error'] ?? 'Unknown error');
            }
        }
    }

    if ($action === 'change_retention_plan') {
        $new_plan = strtolower(trim($_POST['retention_plan'] ?? ''));
        if (update_retention_plan($db, 'installers', $installer['id'], $new_plan)) {
            $info = get_retention_info($new_plan);
            $success = "Data retention plan updated to {$info['label']}. Your records will be kept for {$info['months']} months.";
            $installer = get_installer_profile();
        } else {
            $error = 'Invalid retention plan selected.';
        }
    }

    if ($action === 'cancel_subscription') {
        if (!empty($installer['stripe_subscription_id'])) {
            $result = cancelStripeSubscription($installer['stripe_subscription_id']);

            if ($result['success']) {
                $stmt = $db->prepare("UPDATE installers SET subscription_status = 'canceled' WHERE id = ?");
                $stmt->execute([$installer['id']]);
                $success = 'Subscription has been canceled. You will retain access until the end of your billing period.';
                $installer = get_installer_profile();
            } else {
                $error = 'Could not cancel subscription: ' . ($result['error'] ?? 'Unknown error');
            }
        } else {
            $stmt = $db->prepare("UPDATE installers SET subscription_status = 'canceled' WHERE id = ?");
            $stmt->execute([$installer['id']]);
            $success = 'Subscription canceled.';
            $installer = get_installer_profile();
        }
    }
}

$is_active = ($installer['subscription_status'] ?? 'none') === 'active';
$is_canceled = ($installer['subscription_status'] ?? '') === 'canceled';
$is_past_due = ($installer['subscription_status'] ?? '') === 'past_due';
$expires = !empty($installer['subscription_expires_at']) ? date('M d, Y', strtotime($installer['subscription_expires_at'])) : null;
$formattedFee = $isFree ? 'FREE' : ('$' . number_format($installerFee, 2));

// Data retention plan info
$current_retention = get_retention_info($installer['subscription_plan'] ?? null);
$all_retention_plans = get_all_retention_plans();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscription - <?= get_system_setting('site_name', 'SolarGlobal') ?> Installer</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        .sidebar {
            position: fixed; left: 0; top: 0; bottom: 0; width: 260px;
            background: #0F172A; color: white; z-index: 100;
            display: flex; flex-direction: column; transition: transform 0.3s;
        }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid #1E293B; }
        .sidebar-header h2 { font-size: 1.25rem; font-weight: 800; color: #F59E0B; }
        .sidebar-header p { font-size: 0.75rem; color: #94A3B8; margin-top: 2px; }
        .sidebar-nav { flex: 1; padding: 16px 12px; overflow-y: auto; }
        .nav-section { margin-bottom: 24px; }
        .nav-section-title { font-size: 0.6875rem; text-transform: uppercase; letter-spacing: 1px; color: #475569; padding: 0 12px; margin-bottom: 8px; font-weight: 600; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 8px; color: #CBD5E1; text-decoration: none; font-size: 0.875rem; font-weight: 500; transition: all 0.2s; }
        .nav-item:hover { background: #1E293B; color: white; }
        .nav-item.active { background: #D97706; color: white; }
        .nav-item .icon { font-size: 1.125rem; width: 24px; text-align: center; }
        .nav-item .badge { margin-left: auto; background: #DC2626; color: white; font-size: 0.6875rem; padding: 2px 7px; border-radius: 10px; font-weight: 700; }
        .sidebar-footer { padding: 16px 12px; border-top: 1px solid #1E293B; }
        .installer-info { display: flex; align-items: center; gap: 10px; padding: 8px; }
        .installer-avatar { width: 36px; height: 36px; border-radius: 8px; background: #334155; display: flex; align-items: center; justify-content: center; font-size: 1rem; overflow: hidden; }
        .installer-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .installer-meta .d-name { font-size: 0.8125rem; font-weight: 600; color: #E2E8F0; }
        .installer-meta .d-email { font-size: 0.6875rem; color: #64748B; }
        .overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 90; }
        .overlay.active { display: block; }

        .main-content { margin-left: 260px; padding: 24px 32px; min-height: 100vh; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
        .top-bar h1 { font-size: 1.5rem; font-weight: 700; color: #1E293B; }
        .mobile-menu-btn { display: none; background: #0F172A; color: white; border: none; width: 40px; height: 40px; border-radius: 8px; font-size: 1.25rem; cursor: pointer; }
        .container { max-width: 700px; padding: 0; }

        @media (max-width: 900px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .mobile-menu-btn { display: block; }
        }

        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 0.875rem; }
        .alert-success { background: #DCFCE7; color: #166534; }
        .alert-error { background: #FEE2E2; color: #991B1B; }

        .plan-card {
            background: white; border-radius: 16px; padding: 40px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08); text-align: center;
            border: 2px solid #E2E8F0; margin-bottom: 24px; position: relative; overflow: hidden;
        }
        .plan-card.active { border-color: #16A34A; }
        .plan-card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px;
            background: linear-gradient(90deg, #16A34A, #1565C0);
        }

        .plan-icon { font-size: 3rem; margin-bottom: 16px; }
        .plan-name { font-size: 1.5rem; font-weight: 800; color: #0D3B6E; margin-bottom: 8px; }
        .plan-price { font-size: 2.5rem; font-weight: 800; color: #1E293B; }
        .plan-price small { font-size: 1rem; font-weight: 400; color: #64748B; }
        .plan-price.free { color: #16A34A; }
        .plan-desc { color: #64748B; margin: 16px 0 24px; font-size: 0.9375rem; }

        .features-list { text-align: left; max-width: 400px; margin: 0 auto 32px; }
        .feature-item {
            display: flex; align-items: center; gap: 10px; padding: 8px 0;
            font-size: 0.9375rem; color: #334155;
        }
        .feature-item .check { color: #16A34A; font-weight: 700; font-size: 1.125rem; }

        .btn-activate {
            padding: 16px 48px; border: none; border-radius: 12px;
            font-size: 1.0625rem; font-weight: 700; cursor: pointer;
            transition: all 0.3s;
        }
        .btn-activate.primary {
            background: linear-gradient(135deg, #16A34A, #15803D);
            color: white;
        }
        .btn-activate.primary:hover {
            transform: translateY(-2px); box-shadow: 0 8px 25px rgba(22,163,74,0.4);
        }
        .btn-activate.disabled {
            background: #E2E8F0; color: #94A3B8; cursor: default;
        }
        .btn-cancel {
            display: inline-block; margin-top: 16px; padding: 10px 24px;
            border: 2px solid #EF4444; border-radius: 8px; background: white;
            color: #EF4444; font-size: 0.875rem; font-weight: 600; cursor: pointer;
            transition: all 0.3s;
        }
        .btn-cancel:hover { background: #FEE2E2; }

        .status-card {
            background: white; border-radius: 12px; padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); margin-bottom: 16px;
        }
        .status-row {
            display: flex; justify-content: space-between; padding: 10px 0;
            border-bottom: 1px solid #F1F5F9; font-size: 0.9375rem;
        }
        .status-row:last-child { border-bottom: none; }
        .status-row .label { color: #64748B; }
        .status-row .value { font-weight: 600; }
        .status-row .value.active { color: #16A34A; }
        .status-row .value.inactive { color: #94A3B8; }
        .status-row .value.past-due { color: #F59E0B; }
        .status-row .value.canceled { color: #EF4444; }

        .dev-notice {
            background: #FEF3C7; border: 1px solid #FDE68A; padding: 16px;
            border-radius: 8px; margin-top: 24px; font-size: 0.8125rem; color: #92400E;
        }
    </style>
</head>
<body>
<?php $current_installer_page = 'subscription'; include __DIR__ . '/includes/sidebar.php'; ?>

<main class="main-content">
    <div class="top-bar">
        <div>
            <button class="mobile-menu-btn" onclick="toggleSidebar()">&#9776;</button>
            <h1>&#128296; Subscription</h1>
        </div>
    </div>

    <div class="container">
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>

        <!-- Current Status -->
        <div class="status-card">
            <div class="status-row">
                <span class="label">Subscription Status</span>
                <span class="value <?= $is_active ? 'active' : ($is_past_due ? 'past-due' : ($is_canceled ? 'canceled' : 'inactive')) ?>">
                    <?php if ($is_active): ?>&#10004; Active
                    <?php elseif ($is_past_due): ?>&#9888; Past Due
                    <?php elseif ($is_canceled): ?>&#10060; Canceled
                    <?php else: ?>&#10060; Inactive<?php endif; ?>
                </span>
            </div>
            <?php if (!empty($installer['subscription_started_at'])): ?>
            <div class="status-row">
                <span class="label">Started</span>
                <span class="value"><?= date('M d, Y', strtotime($installer['subscription_started_at'])) ?></span>
            </div>
            <?php endif; ?>
            <?php if ($expires): ?>
            <div class="status-row">
                <span class="label"><?= $isFree ? 'Plan' : 'Renews On' ?></span>
                <span class="value"><?= $isFree ? 'Free (no expiry)' : $expires ?></span>
            </div>
            <?php endif; ?>
            <div class="status-row">
                <span class="label">Profile Status</span>
                <span class="value"><?= ucfirst($installer['status']) ?></span>
            </div>
            <div class="status-row">
                <span class="label">Payment</span>
                <span class="value"><?= $isFree ? 'Free Plan' : 'Stripe' ?></span>
            </div>
        </div>

        <!-- Plan -->
        <div class="plan-card <?= $is_active ? 'active' : '' ?>">
            <div class="plan-icon">&#128296;</div>
            <div class="plan-name"><?= get_system_setting('site_name', 'SolarGlobal') ?> Installer Profile</div>
            <div class="plan-price <?= $isFree ? 'free' : '' ?>">
                <?= $formattedFee ?>
                <?php if (!$isFree): ?><small>/month</small><?php endif; ?>
            </div>
            <div class="plan-desc">Get discovered by customers looking for solar installation services</div>

            <div class="features-list">
                <div class="feature-item"><span class="check">&#10003;</span> Public installer profile</div>
                <div class="feature-item"><span class="check">&#10003;</span> Portfolio showcase</div>
                <div class="feature-item"><span class="check">&#10003;</span> Customer reviews and ratings</div>
                <div class="feature-item"><span class="check">&#10003;</span> Appear in installer recommendations</div>
                <div class="feature-item"><span class="check">&#10003;</span> Location-based customer matching</div>
                <div class="feature-item"><span class="check">&#10003;</span> Lead generation</div>
                <div class="feature-item"><span class="check">&#10003;</span> Dashboard analytics</div>
            </div>

            <?php if ($is_active): ?>
                <button class="btn-activate disabled">&#10004; Currently Active</button>
                <?php if (!$isFree): ?>
                <br>
                <form method="POST" style="display:inline" onsubmit="return confirm('Are you sure you want to cancel your subscription?');">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="cancel_subscription">
                    <button type="submit" class="btn-cancel">Cancel Subscription</button>
                </form>
                <?php endif; ?>
            <?php elseif ($isFree): ?>
                <form method="POST" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="activate_free">
                    <button type="submit" class="btn-activate primary">
                        &#10003; Activate Free Profile
                    </button>
                </form>
            <?php elseif (!$stripeConfigured): ?>
                <button class="btn-activate disabled" title="Payment system not configured">&#9889; Payment System Unavailable</button>
            <?php else: ?>
                <form method="POST" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="create_checkout">
                    <button type="submit" class="btn-activate primary">
                        &#9889; Activate Subscription - <?= $formattedFee ?>/month
                    </button>
                </form>
            <?php endif; ?>
        </div>

        <?php if ($isTestMode && !$isFree): ?>
        <div class="dev-notice">
            <strong>Stripe TEST Mode:</strong> Payments are processed using Stripe's test environment.
            No real charges will be made. Use test card <strong>4242 4242 4242 4242</strong> with any future expiry and any CVC.
        </div>
        <?php endif; ?>

        <!-- ═══ Data Retention Plan Section ═══ -->
        <div class="plan-card" style="margin-top: 32px;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                <span style="font-size: 1.5rem;">&#128451;</span>
                <h3 style="font-weight: 700; color: #0F172A;">Data Retention Plan</h3>
            </div>
            <p style="color: #64748B; font-size: 0.875rem; margin-bottom: 20px;">
                Choose how long your job history, reviews, and records are kept.
                When data passes your plan's retention period, it is <strong>automatically and permanently deleted</strong>.
            </p>

            <div style="background: #F0FDF4; border: 1px solid #BBF7D0; border-radius: 10px; padding: 14px 18px; margin-bottom: 20px;">
                <div style="font-weight: 600; color: #166534; font-size: 0.9rem;">
                    Current Plan: <span style="color: #15803D;"><?= sanitize($current_retention['label']) ?></span>
                </div>
                <div style="color: #166534; font-size: 0.82rem; margin-top: 4px;">
                    Your data is kept for <strong><?= $current_retention['months'] ?> months (~<?= $current_retention['days'] ?> days)</strong>.
                    <?= $current_retention['fee'] > 0 ? 'Add-on fee: <strong>$' . number_format($current_retention['fee'], 2) . '/month</strong>' : '<strong>Free — included.</strong>' ?>
                </div>
            </div>

            <form method="POST" id="retentionForm">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="change_retention_plan">

                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 12px; margin-bottom: 20px;">
                    <?php
                    $plan_colors = [
                        'basic'      => ['border' => '#E2E8F0', 'bg' => '#F8FAFC', 'text' => '#334155', 'badge' => '#94A3B8'],
                        'standard'   => ['border' => '#BFDBFE', 'bg' => '#EFF6FF', 'text' => '#1D4ED8', 'badge' => '#3B82F6'],
                        'premium'    => ['border' => '#FDE68A', 'bg' => '#FFFBEB', 'text' => '#92400E', 'badge' => '#F59E0B'],
                        'enterprise' => ['border' => '#C4B5FD', 'bg' => '#F5F3FF', 'text' => '#5B21B6', 'badge' => '#8B5CF6'],
                    ];
                    foreach ($all_retention_plans as $rp):
                        $c = $plan_colors[$rp['plan']] ?? $plan_colors['basic'];
                        $is_current = ($rp['plan'] === $current_retention['plan']);
                    ?>
                    <label style="cursor: pointer; display: block;">
                        <input type="radio" name="retention_plan" value="<?= $rp['plan'] ?>"
                               <?= $is_current ? 'checked' : '' ?>
                               style="display: none;" onchange="document.getElementById('retentionSubmit').style.display='inline-flex'">
                        <div style="padding: 16px; border-radius: 10px; border: 2px solid <?= $is_current ? $c['badge'] : $c['border'] ?>; background: <?= $c['bg'] ?>; transition: all 0.2s; cursor: pointer;"
                             onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 4px 12px rgba(0,0,0,0.08)'"
                             onmouseout="this.style.transform='';this.style.boxShadow=''">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                                <span style="font-weight: 700; color: <?= $c['text'] ?>; font-size: 0.95rem;"><?= ucfirst($rp['plan']) ?></span>
                                <?php if ($is_current): ?>
                                    <span style="font-size: 0.7rem; background: <?= $c['badge'] ?>; color: white; padding: 2px 8px; border-radius: 20px; font-weight: 600;">CURRENT</span>
                                <?php endif; ?>
                            </div>
                            <div style="font-size: 1.4rem; font-weight: 800; color: <?= $c['text'] ?>;"><?= $rp['months'] ?> <span style="font-size: 0.75rem; font-weight: 500;">months</span></div>
                            <div style="font-size: 0.8rem; color: #64748B; margin-top: 4px;">~<?= $rp['days'] ?> days</div>
                            <div style="font-size: 0.82rem; font-weight: 600; color: <?= $c['text'] ?>; margin-top: 8px;">
                                <?= $rp['fee'] <= 0 ? 'Free (Included)' : '+$' . number_format($rp['fee'], 2) . '/month' ?>
                            </div>
                        </div>
                    </label>
                    <?php endforeach; ?>
                </div>

                <button type="submit" id="retentionSubmit"
                        style="display: none; background: #7C3AED; color: white; border: none; padding: 12px 28px; border-radius: 10px; font-weight: 600; font-size: 0.9rem; cursor: pointer;"
                        onmouseover="this.style.background='#6D28D9'" onmouseout="this.style.background='#7C3AED'">
                    &#128451; Update Retention Plan
                </button>
            </form>

            <div style="margin-top: 16px; padding: 12px 16px; background: #FEF3C7; border: 1px solid #FDE68A; border-radius: 8px; font-size: 0.8rem; color: #92400E;">
                <strong>&#9888;&#65039; Important:</strong> Downgrading your plan will cause data older than the new retention period to be
                <strong>permanently deleted</strong> on the next cleanup cycle. This cannot be undone.
            </div>
        </div>
    </div>
</main>
</body>
</html>
