-- Phase 5: Expand Appliance Database
-- Adds 30+ new appliances common in Pakistani households
-- Categories: Cooling, Heating, Kitchen, Laundry, Electronics, Security, Health, Office, Outdoor, Kids

-- ============================================================
-- NEW APPLIANCES
-- ============================================================

INSERT IGNORE INTO appliances (name_en, name_ur, icon, watt_typical, category, season_tags, usage_hours_summer, usage_hours_winter, surge_load_watts, standby_watts, is_active) VALUES

-- === COOLING (additional) ===
('Room Air Cooler', 'روم ایئر کولر', '🌬️', 200, 'Cooling', 'summer', 12.0, 0.0, 400, 0, 1),
('Tower Fan', 'ٹاور فین', '🗼', 55, 'Cooling', 'summer', 10.0, 0.0, 80, 0, 1),
('Bracket Fan', 'بریکٹ فین', '💨', 80, 'Cooling', 'summer', 14.0, 0.0, 120, 0, 1),
('Mini Portable AC', 'پورٹیبل اے سی', '❄️', 1000, 'Cooling', 'summer', 8.0, 0.0, 1800, 5, 1),

-- === HEATING ===
('Electric Heater (Rod)', 'الیکٹرک ہیٹر', '🔥', 1500, 'Heating', 'winter', 0.0, 6.0, 1500, 0, 1),
('Oil Filled Radiator', 'آئل ہیٹر', '♨️', 2000, 'Heating', 'winter', 0.0, 8.0, 2000, 0, 1),
('Electric Blanket', 'الیکٹرک کمبل', '🛏️', 150, 'Heating', 'winter', 0.0, 8.0, 150, 0, 1),
('Fan Heater (Blower)', 'فین ہیٹر', '🌡️', 2000, 'Heating', 'winter', 0.0, 4.0, 2200, 0, 1),

-- === KITCHEN (additional) ===
('Food Processor', 'فوڈ پروسیسر', '🍽️', 600, 'Kitchen', 'all_year', 0.5, 0.5, 1000, 0, 1),
('Electric Oven/Baking', 'الیکٹرک اوون', '🍞', 2000, 'Kitchen', 'all_year', 1.0, 1.5, 2000, 0, 1),
('Induction Cooktop', 'انڈکشن چولہا', '🍳', 1800, 'Kitchen', 'all_year', 2.0, 2.0, 1800, 0, 1),
('Air Fryer', 'ایئر فرائر', '🍟', 1500, 'Kitchen', 'all_year', 0.5, 0.5, 1500, 0, 1),
('Water Purifier (RO)', 'واٹر پیوریفائر', '💧', 60, 'Kitchen', 'all_year', 6.0, 4.0, 80, 5, 1),
('Dishwasher', 'ڈش واشر', '🍽️', 1400, 'Kitchen', 'all_year', 1.5, 1.5, 1800, 2, 1),
('Electric Stove (Hot Plate)', 'الیکٹرک چولہا', '🔴', 1500, 'Kitchen', 'all_year', 2.0, 3.0, 1500, 0, 1),
('Sandwich Maker', 'سینڈوچ میکر', '🥪', 700, 'Kitchen', 'all_year', 0.3, 0.3, 700, 0, 1),
('Coffee/Tea Maker', 'کافی میکر', '☕', 800, 'Kitchen', 'all_year', 0.5, 1.0, 800, 0, 1),

-- === ENTERTAINMENT (additional) ===
('Home Theater/Sound Bar', 'ہوم تھیٹر', '🔊', 150, 'Entertainment', 'all_year', 3.0, 3.0, 200, 5, 1),
('Gaming Console', 'گیمنگ کنسول', '🎮', 200, 'Entertainment', 'all_year', 3.0, 3.0, 250, 2, 1),
('Projector', 'پروجیکٹر', '📽️', 250, 'Entertainment', 'all_year', 2.0, 2.0, 300, 3, 1),
('LED TV 43 inch', 'ایل ای ڈی ٹی وی 43', '📺', 100, 'Entertainment', 'all_year', 5.0, 5.0, 120, 3, 1),

-- === ELECTRONICS (additional) ===
('Tablet Charger', 'ٹیبلٹ چارجر', '📱', 30, 'Electronics', 'all_year', 3.0, 3.0, 30, 0, 1),
('UPS (Small)', 'یو پی ایس', '🔋', 100, 'Electronics', 'all_year', 24.0, 24.0, 150, 10, 1),
('Inverter/UPS (Large)', 'انورٹر یو پی ایس', '⚡', 300, 'Electronics', 'all_year', 24.0, 24.0, 500, 15, 1),
('Smart Home Hub', 'سمارٹ ہوم ہب', '🏠', 10, 'Electronics', 'all_year', 24.0, 24.0, 10, 5, 1),

-- === HEALTH & PERSONAL CARE ===
('Hair Dryer', 'ہیئر ڈرائر', '💇', 1200, 'Health', 'all_year', 0.3, 0.3, 1500, 0, 1),
('Electric Trimmer', 'ٹرمر', '✂️', 15, 'Health', 'all_year', 0.2, 0.2, 15, 0, 1),
('Nebulizer', 'نیبولائزر', '💨', 50, 'Health', 'all_year', 0.5, 0.5, 60, 0, 1),
('CPAP Machine', 'سی پیپ مشین', '😴', 60, 'Health', 'all_year', 8.0, 8.0, 80, 0, 1),
('Treadmill', 'ٹریڈمل', '🏃', 1500, 'Health', 'all_year', 1.0, 1.0, 3000, 5, 1),

-- === SECURITY ===
('Electric Gate Motor', 'الیکٹرک گیٹ', '🚪', 300, 'Security', 'all_year', 0.5, 0.5, 600, 5, 1),
('Motion Sensor Lights', 'موشن سینسر لائٹ', '💡', 30, 'Security', 'all_year', 6.0, 10.0, 30, 2, 1),
('Video Doorbell', 'ویڈیو ڈور بیل', '🔔', 10, 'Security', 'all_year', 24.0, 24.0, 10, 5, 1),

-- === OUTDOOR/GARDEN ===
('Garden Lights (Solar Hybrid)', 'گارڈن لائٹس', '🌿', 40, 'Outdoor', 'all_year', 6.0, 4.0, 40, 0, 1),
('Lawn Mower (Electric)', 'لان موور', '🌱', 1200, 'Outdoor', 'summer, spring', 0.5, 0.0, 2000, 0, 1),
('Pressure Washer', 'پریشر واشر', '🚿', 1800, 'Outdoor', 'all_year', 0.3, 0.3, 3000, 0, 1),

-- === OFFICE/WORK FROM HOME ===
('Inkjet Printer', 'انک جیٹ پرنٹر', '🖨️', 60, 'Electronics', 'all_year', 1.0, 1.0, 80, 5, 1),
('Monitor (24 inch)', 'مانیٹر', '🖥️', 40, 'Electronics', 'all_year', 8.0, 8.0, 50, 2, 1),
('Scanner/Copier', 'سکینر', '📄', 50, 'Electronics', 'all_year', 0.5, 0.5, 80, 5, 1);

-- ============================================================
-- SEASONAL MAPPING FOR NEW APPLIANCES
-- ============================================================

-- Get the IDs of newly inserted appliances dynamically
-- We'll use name_en to reference them

INSERT INTO seasonal_appliance_mapping (appliance_id, season, usage_probability, priority_rank, recommended_hours, notes)
SELECT id, 'summer', 1.00, 1, 12.0, 'Primary cooling in areas without AC' FROM appliances WHERE name_en = 'Room Air Cooler'
UNION ALL
SELECT id, 'summer', 0.90, 2, 10.0, 'Secondary fan option' FROM appliances WHERE name_en = 'Tower Fan'
UNION ALL
SELECT id, 'summer', 0.95, 1, 14.0, 'Wall-mounted for continuous airflow' FROM appliances WHERE name_en = 'Bracket Fan'
UNION ALL
SELECT id, 'summer', 0.80, 2, 8.0, 'Portable cooling for small rooms' FROM appliances WHERE name_en = 'Mini Portable AC'
UNION ALL
SELECT id, 'winter', 1.00, 1, 6.0, 'Essential heating in cold areas' FROM appliances WHERE name_en = 'Electric Heater (Rod)'
UNION ALL
SELECT id, 'winter', 0.80, 2, 8.0, 'Safe overnight heating' FROM appliances WHERE name_en = 'Oil Filled Radiator'
UNION ALL
SELECT id, 'winter', 0.70, 3, 8.0, 'Energy-efficient bed warming' FROM appliances WHERE name_en = 'Electric Blanket'
UNION ALL
SELECT id, 'winter', 0.90, 2, 4.0, 'Quick room heating' FROM appliances WHERE name_en = 'Fan Heater (Blower)'
UNION ALL
SELECT id, 'summer', 0.95, 1, 6.0, 'Clean drinking water essential in heat' FROM appliances WHERE name_en = 'Water Purifier (RO)'
UNION ALL
SELECT id, 'winter', 0.85, 2, 4.0, 'More water purification in winter illness season' FROM appliances WHERE name_en = 'Water Purifier (RO)'
UNION ALL
SELECT id, 'summer', 0.30, 8, 0.5, 'Seasonal garden maintenance' FROM appliances WHERE name_en = 'Lawn Mower (Electric)'
UNION ALL
SELECT id, 'spring', 0.60, 5, 0.5, 'Peak garden season' FROM appliances WHERE name_en = 'Lawn Mower (Electric)';
