<?php
http_response_code(403);
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
$site_name = get_system_setting('site_name', 'SolarGlobal');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 - Access Denied | <?= htmlspecialchars($site_name) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', -apple-system, sans-serif; background: linear-gradient(135deg, #0F172A, #1E3A5F); min-height: 100vh; display: flex; align-items: center; justify-content: center; color: white; }
        .container { text-align: center; padding: 40px; }
        .icon { font-size: 80px; margin-bottom: 20px; }
        h1 { font-size: 48px; margin-bottom: 12px; }
        p { font-size: 18px; color: rgba(255,255,255,0.7); margin-bottom: 32px; }
        a { display: inline-block; padding: 14px 32px; background: linear-gradient(135deg, #3B82F6, #1D4ED8); color: white; text-decoration: none; border-radius: 8px; font-weight: 600; }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">🔒</div>
        <h1>403</h1>
        <p>Access denied. You don't have permission to view this resource.</p>
        <a href="<?= BASE_URL ?>">Back to Home</a>
    </div>
</body>
</html>
