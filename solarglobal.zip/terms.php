<?php
$page_title = 'Terms of Service';
$page_description = 'Terms of Service - Read our terms and conditions for using the platform, dealer listings, and subscription services.';
$current_page = 'terms';

require_once 'includes/db.php';
require_once 'includes/helpers.php';

$site_name = get_system_setting('site_name', 'SolarGlobal');
$contact_email = get_system_setting('contact_email', 'support@solarglobal.com');

include 'includes/header.php';
?>

<style>
    .terms-container {
        max-width: 800px;
        margin: 40px auto;
        padding: 30px 40px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, sans-serif;
        color: #333;
        line-height: 1.7;
    }

    .terms-container h1 {
        font-size: 2rem;
        margin-bottom: 5px;
        color: #1a1a1a;
    }

    .terms-container .last-updated {
        color: #777;
        font-size: 0.9rem;
        margin-bottom: 35px;
    }

    .terms-container section {
        margin-bottom: 30px;
        padding-left: 20px;
        border-left: 3px solid #e8e8e8;
    }

    .terms-container section:hover {
        border-left-color: #f39c12;
    }

    .terms-container h2 {
        font-size: 1.3rem;
        color: #1a1a1a;
        margin-bottom: 10px;
    }

    .terms-container p,
    .terms-container ul {
        font-size: 0.95rem;
        color: #555;
        margin-bottom: 12px;
    }

    .terms-container ul {
        padding-left: 20px;
    }

    .terms-container ul li {
        margin-bottom: 6px;
    }

    .terms-container a {
        color: #f39c12;
        text-decoration: none;
    }

    .terms-container a:hover {
        text-decoration: underline;
    }
</style>

<div class="terms-container">
    <h1>Terms of Service</h1>
    <p class="last-updated">Last updated: May 2026</p>

    <section>
        <h2>1. Acceptance of Terms</h2>
        <p>By accessing or using the <?php echo htmlspecialchars($site_name); ?> platform, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our platform.</p>
        <p>These terms apply to all users of the site, including visitors, registered users, dealers, and installers.</p>
    </section>

    <section>
        <h2>2. Service Description</h2>
        <p><?php echo htmlspecialchars($site_name); ?> is an informative solar product comparison platform. We provide information about solar panels, inverters, batteries, and related products to help consumers make informed decisions.</p>
        <p><strong>Important:</strong> We are NOT a retailer, distributor, or seller of solar products. Our platform connects potential buyers with dealers and installers. All transactions occur directly between you and the respective dealer or installer.</p>
    </section>

    <section>
        <h2>3. User Accounts</h2>
        <p>When you create an account on <?php echo htmlspecialchars($site_name); ?>, you agree to:</p>
        <ul>
            <li>Provide accurate, current, and complete information during registration</li>
            <li>Maintain and promptly update your account information</li>
            <li>Keep your password secure and confidential</li>
            <li>Accept responsibility for all activities that occur under your account</li>
            <li>Notify us immediately of any unauthorized use of your account</li>
        </ul>
        <p>You must be at least 18 years of age to create an account on this platform.</p>
    </section>

    <section>
        <h2>4. User Responsibilities</h2>
        <p>As a user of <?php echo htmlspecialchars($site_name); ?>, you agree to:</p>
        <ul>
            <li>Use the platform only for lawful purposes and in accordance with these terms</li>
            <li>Provide accurate information in all interactions on the platform</li>
            <li>Not misuse, disrupt, or interfere with the platform's functionality</li>
            <li>Not attempt to gain unauthorized access to any part of the platform</li>
            <li>Not use automated tools to scrape or extract data from the platform</li>
            <li>Not post false, misleading, or defamatory content</li>
            <li>Not impersonate any person or entity</li>
        </ul>
    </section>

    <section>
        <h2>5. Dealer/Installer Listings</h2>
        <p>Product listings, dealer profiles, and installer information on <?php echo htmlspecialchars($site_name); ?> are provided for informational purposes only. Please be aware that:</p>
        <ul>
            <li>We do not guarantee the accuracy of product specifications, pricing, or availability</li>
            <li>We do not endorse or warrant the quality of any listed products or services</li>
            <li>Pricing and availability are subject to change without notice by the respective dealers</li>
            <li>All transactions occur directly between you and the dealer/installer</li>
            <li>We are not a party to any agreement between buyers and dealers/installers</li>
            <li>We do not handle payments, shipping, installation, or warranties</li>
        </ul>
        <p>We encourage users to conduct their own due diligence before engaging with any dealer or installer listed on our platform.</p>
    </section>

    <section>
        <h2>6. Intellectual Property</h2>
        <p>All content on <?php echo htmlspecialchars($site_name); ?>, including but not limited to text, graphics, logos, icons, images, software, and the compilation thereof, is the property of <?php echo htmlspecialchars($site_name); ?> or its content suppliers and is protected by applicable intellectual property laws.</p>
        <p>Users retain ownership of any data, reviews, or content they submit to the platform. By submitting content, you grant <?php echo htmlspecialchars($site_name); ?> a non-exclusive, royalty-free license to use, display, and distribute such content on the platform.</p>
    </section>

    <section>
        <h2>7. Limitation of Liability</h2>
        <p><?php echo htmlspecialchars($site_name); ?> is provided on an "as is" and "as available" basis. To the fullest extent permitted by law, we disclaim all warranties, express or implied.</p>
        <p><strong>We are NOT liable for:</strong></p>
        <ul>
            <li>Any transactions between users and dealers/installers</li>
            <li>The quality, safety, or legality of products or services listed</li>
            <li>The conduct of any dealer, installer, or user on the platform</li>
            <li>Any direct, indirect, incidental, or consequential damages arising from use of the platform</li>
            <li>Loss of data, profits, or business opportunities</li>
            <li>Inaccuracies in product information or pricing</li>
        </ul>
        <p>Your use of the platform and any reliance on information provided is entirely at your own risk.</p>
    </section>

    <section>
        <h2>8. Subscription Terms</h2>
        <p>For dealers and installers with paid subscriptions:</p>
        <ul>
            <li><strong>Billing:</strong> Subscriptions are billed on a recurring basis (monthly or annually) as selected during sign-up</li>
            <li><strong>Auto-Renewal:</strong> Subscriptions automatically renew at the end of each billing cycle unless cancelled</li>
            <li><strong>Cancellation:</strong> You may cancel your subscription at any time through your account settings. Cancellation takes effect at the end of the current billing period</li>
            <li><strong>Refunds:</strong> No refunds are provided for partial months or unused portions of a subscription period</li>
            <li><strong>Price Changes:</strong> We reserve the right to modify subscription pricing with at least 30 days notice before the next billing cycle</li>
        </ul>
    </section>

    <section>
        <h2>9. Privacy</h2>
        <p>Your privacy is important to us. Our collection, use, and protection of your personal information is governed by our <a href="<?php echo BASE_URL; ?>privacy">Privacy Policy</a>, which is incorporated into these Terms of Service by reference.</p>
        <p>By using <?php echo htmlspecialchars($site_name); ?>, you consent to the collection and use of information as described in our Privacy Policy.</p>
    </section>

    <section>
        <h2>10. Termination</h2>
        <p><?php echo htmlspecialchars($site_name); ?> reserves the right to suspend or terminate your account and access to the platform at our sole discretion, without prior notice, for conduct that we believe:</p>
        <ul>
            <li>Violates these Terms of Service</li>
            <li>Is harmful to other users, dealers, or third parties</li>
            <li>Is fraudulent, misleading, or deceptive</li>
            <li>Involves illegal activity</li>
        </ul>
        <p>Upon termination, your right to use the platform ceases immediately. Provisions that by their nature should survive termination shall remain in effect.</p>
    </section>

    <section>
        <h2>11. Governing Law & Dispute Resolution</h2>
        <p>These Terms of Service shall be governed by and construed in accordance with applicable laws. Any disputes arising out of or relating to these terms or the use of the platform shall be resolved through binding arbitration, rather than in court.</p>
        <p>Both parties agree to attempt to resolve any disputes informally before initiating arbitration. The arbitration shall be conducted by a mutually agreed-upon arbitrator, and the decision shall be final and binding.</p>
    </section>

    <section>
        <h2>12. Changes to Terms</h2>
        <p><?php echo htmlspecialchars($site_name); ?> reserves the right to modify these Terms of Service at any time. When we make changes, we will update the "Last updated" date at the top of this page and, where appropriate, notify users via email or through a notice on the platform.</p>
        <p>Your continued use of the platform after any changes constitutes your acceptance of the revised terms. We encourage you to review these terms periodically.</p>
    </section>

    <section>
        <h2>13. Contact Us</h2>
        <p>If you have any questions, concerns, or feedback regarding these Terms of Service, please contact us at:</p>
        <p><strong>Email:</strong> <a href="mailto:<?php echo htmlspecialchars($contact_email); ?>"><?php echo htmlspecialchars($contact_email); ?></a></p>
    </section>
</div>

<?php include 'includes/footer.php'; ?>
