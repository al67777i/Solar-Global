<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = getDB();
$pageTitle = 'Import Products';
$message = '';
$error = '';
$importResults = null;

// Fetch countries for dropdown
$countries = $db->query("SELECT id, code, name, flag_emoji, flag_icon FROM countries WHERE is_supported = 1 ORDER BY name ASC")->fetchAll();

// Handle import POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'import') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid CSRF token. Please refresh and try again.';
    } else {
        $productType = $_POST['product_type'] ?? '';
        $countryCode = trim($_POST['country_code'] ?? '');

        $allowedTypes = ['inverter', 'battery', 'panel'];
        if (!in_array($productType, $allowedTypes)) {
            $error = 'Invalid product type selected.';
        } elseif (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
            $error = 'Please upload a valid CSV file.';
        } else {
            $file = $_FILES['csv_file'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $maxSize = 10 * 1024 * 1024; // 10MB

            if ($ext !== 'csv') {
                $error = 'Only CSV files are allowed.';
            } elseif ($file['size'] > $maxSize) {
                $error = 'File size exceeds 10MB limit.';
            } else {
                // Process CSV
                $handle = fopen($file['tmp_name'], 'r');
                if ($handle === false) {
                    $error = 'Failed to open uploaded file.';
                } else {
                    // Read header row
                    $headers = fgetcsv($handle);
                    if ($headers === false) {
                        $error = 'CSV file is empty or unreadable.';
                        fclose($handle);
                    } else {
                        $headers = array_map('trim', $headers);
                        $headers = array_map('strtolower', $headers);

                        $inserted = 0;
                        $updated = 0;
                        $skipped = 0;
                        $errors = [];
                        $rowNum = 1;

                        while (($row = fgetcsv($handle)) !== false) {
                            $rowNum++;
                            if (count($row) < 2) {
                                $skipped++;
                                continue;
                            }

                            // Map row to associative array
                            $data = [];
                            foreach ($headers as $i => $header) {
                                $data[$header] = isset($row[$i]) ? trim($row[$i]) : '';
                            }

                            // Validate required fields per product type
                            if ($productType === 'inverter') {
                                $brand = $data['company'] ?? '';
                                $name = $data['model'] ?? '';
                                if (empty($name) || empty($brand)) {
                                    $errors[] = "Row $rowNum: 'model' and 'company' are required for inverters.";
                                    $skipped++;
                                    continue;
                                }
                            } elseif ($productType === 'panel') {
                                $brand = $data['brand'] ?? '';
                                $name = $data['name'] ?? '';
                                if (empty($name) || empty($brand)) {
                                    $errors[] = "Row $rowNum: 'name' and 'brand' are required for panels.";
                                    $skipped++;
                                    continue;
                                }
                            } elseif ($productType === 'battery') {
                                $brand = $data['brand'] ?? '';
                                if (empty($brand)) {
                                    $errors[] = "Row $rowNum: 'brand' is required for batteries.";
                                    $skipped++;
                                    continue;
                                }
                            }

                            // Auto-create country from CSV data if present
                            $csvCountry = $data['country'] ?? '';
                            if (!empty($csvCountry)) {
                                getOrCreateCountry($db, $csvCountry);
                            }

                            try {
                                if ($productType === 'inverter') {
                                    $result = importInverter($db, $data, $countryCode);
                                } elseif ($productType === 'battery') {
                                    $result = importBattery($db, $data, $countryCode);
                                } elseif ($productType === 'panel') {
                                    $result = importPanel($db, $data, $countryCode);
                                }

                                if ($result === 'inserted') {
                                    $inserted++;
                                } elseif ($result === 'updated') {
                                    $updated++;
                                }
                            } catch (Exception $e) {
                                $errors[] = "Row $rowNum: " . $e->getMessage();
                                $skipped++;
                            }
                        }

                        fclose($handle);

                        $importResults = [
                            'inserted' => $inserted,
                            'updated' => $updated,
                            'skipped' => $skipped,
                            'errors' => $errors,
                            'total' => $rowNum - 1
                        ];

                        // Log the import
                        try {
                            $adminId = intval($_SESSION['admin_id'] ?? 0);
                            $errorDetails = !empty($errors) ? json_encode($errors) : null;
                            $db->prepare("INSERT INTO import_logs (admin_id, product_type, country_code, filename, total_rows, inserted, updated, skipped, errors, error_details, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', NOW())")
                                ->execute([$adminId, $productType, $countryCode ?: 'global', $file['name'], $rowNum - 1, $inserted, $updated, $skipped, count($errors), $errorDetails]);
                        } catch (Exception $e) {
                            // Log table might not exist yet, ignore
                        }

                        if ($inserted > 0 || $updated > 0) {
                            $message = "Import complete: $inserted inserted, $updated updated, $skipped skipped.";
                        }
                        if (count($errors) > 0) {
                            $error = count($errors) . " row(s) had errors.";
                        }
                    }
                }
            }
        }
    }
}

// ── Import helper functions ────────────────────────────────────────────────

/**
 * Find or create a company by name.
 * NOW ALSO SETS COUNTRY if provided!
 * Collation-safe: avoids LOWER() which causes utf8mb4 collation mismatch on MariaDB.
 * Always returns a valid company ID; never throws.
 */
function getOrCreateCompany($db, $brand, $country = '') {
    $brand = trim($brand);
    if (empty($brand)) {
        // Create a placeholder so the import row isn't lost
        $brand = 'Unknown';
    }
    
    $country = trim($country);
    
    try {
        // Use direct equality — the DB collation (utf8mb4_unicode_ci) handles
        // case-insensitive matching natively without LOWER()
        $stmt = $db->prepare("SELECT id, country FROM companies WHERE name = ? LIMIT 1");
        $stmt->execute([$brand]);
        $company = $stmt->fetch();
        
        if ($company) {
            // Company exists - UPDATE country if provided and currently empty
            if (!empty($country) && empty($company['country'])) {
                $updateStmt = $db->prepare("UPDATE companies SET country = ? WHERE id = ?");
                $updateStmt->execute([$country, $company['id']]);
                error_log("Updated company '{$brand}' with country: {$country}");
            }
            return (int)$company['id'];
        }
        
        // Auto-create the company WITH country
        $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $brand));
        $slug = trim($slug, '-');
        
        if (!empty($country)) {
            $stmt = $db->prepare("INSERT INTO companies (name, slug, country, is_active) VALUES (?, ?, ?, 1)");
            $stmt->execute([$brand, $slug, $country]);
            error_log("Created company '{$brand}' with country: {$country}");
        } else {
            $stmt = $db->prepare("INSERT INTO companies (name, slug, is_active) VALUES (?, ?, 1)");
            $stmt->execute([$brand, $slug]);
            error_log("Created company '{$brand}' without country");
        }
        
        return (int)$db->lastInsertId();
    } catch (Exception $e) {
        // Last resort: try a fresh SELECT in case a race condition inserted it
        try {
            $stmt = $db->prepare("SELECT id FROM companies WHERE name = ? LIMIT 1");
            $stmt->execute([$brand]);
            $row = $stmt->fetch();
            if ($row) return (int)$row['id'];
        } catch (Exception $e2) {}
        // Return 0 — the row will be skipped but import continues
        error_log("getOrCreateCompany failed for '$brand': " . $e->getMessage());
        return 0;
    }
}

/**
 * Find or create a country by name.
 * Collation-safe; silently ignores errors so import continues.
 */
function getOrCreateCountry($db, $countryName) {
    if (empty(trim($countryName))) return;
    try {
        $stmt = $db->prepare("SELECT id FROM countries WHERE name = ? LIMIT 1");
        $stmt->execute([trim($countryName)]);
        if ($stmt->fetch()) return; // already exists

        // Generate a 2-letter code
        $code = strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $countryName), 0, 2));
        if (empty($code)) $code = 'XX';

        // Make code unique if it already exists
        $codeCheck = $db->prepare("SELECT id FROM countries WHERE code = ? LIMIT 1");
        $codeCheck->execute([$code]);
        if ($codeCheck->fetch()) {
            // Append digit to avoid duplicate code
            $code = substr($code, 0, 1) . rand(1, 9);
        }

        $db->prepare("INSERT IGNORE INTO countries (code, name, is_supported) VALUES (?, ?, 0)")
           ->execute([$code, trim($countryName)]);
    } catch (Exception $e) {
        // Silently ignore — country creation is best-effort
        error_log("getOrCreateCountry failed for '$countryName': " . $e->getMessage());
    }
}

function importInverter($db, $data, $countryCode) {
    // CSV columns from China Excel format (PERFECT DATA):
    // country, company, series_name, model, type, output_power_w, max_pv_input_w,
    // surge_power_w, min_pv_voltage, max_pv_voltage, price_per_watt_usd, unit_price_usd,
    // three_phase, output_ac_voltage_range, power_factor, battery_voltage_range, bms,
    // communication, max_efficiency, ip_rating, cooling_method, display_type,
    // operating_temperature, noise_level, weight_kg, dimensions, warranty_years,
    // supports_parallel, max_parallel_units, Primary Application,
    // hybrid_offgrid_charging_power_watt, Status

    $brand = trim($data['company'] ?? '');
    $name = trim($data['model'] ?? '');
    $csvCountry = trim($data['country'] ?? '');
    
    if (empty($name) || empty($brand)) {
        throw new Exception("'model' and 'company' are required for inverters.");
    }
    
    $companyId = getOrCreateCompany($db, $brand, $csvCountry);

    // Core specs
    $seriesName = $data['series_name'] ?? null;
    $outputWatts = intval($data['output_power_w'] ?? 0);
    $maxLoadWatts = $outputWatts; // same as output power
    $maxPvInput = intval($data['max_pv_input_w'] ?? 0);
    $surgeWatts = intval($data['surge_power_w'] ?? 0) ?: null;
    
    // NEW: Use min_pv_voltage and max_pv_voltage from China format
    $minPvVoltage = intval($data['min_pv_voltage'] ?? 0) ?: null;
    $maxPvVoltage = intval($data['max_pv_voltage'] ?? 0) ?: null;
    
    // Fallback to old column names if new ones not present
    if ($minPvVoltage === null && isset($data['min_dc_voltage'])) {
        $minPvVoltage = intval($data['min_dc_voltage']) ?: null;
    }
    if ($maxPvVoltage === null && isset($data['max_dc_voltage'])) {
        $maxPvVoltage = intval($data['max_dc_voltage']) ?: null;
    }
    
    $mpptCount = intval($data['mppt_count'] ?? 1);
    $dcInputs = intval($data['dc_inputs'] ?? 0) ?: null;
    $connectors = $data['connectors'] ?? null;

    // Inverter type - convert from China format to database format
    $inverterType = strtolower(trim($data['type'] ?? 'hybrid'));
    $inverterType = str_replace(['on-grid', 'off-grid'], ['on-grid', 'off-grid'], $inverterType);
    if (!in_array($inverterType, ['hybrid', 'on-grid', 'off-grid', 'microinverter'])) {
        $inverterType = 'hybrid';
    }

    // Pricing
    $pricePerWatt = floatval($data['price_per_watt_usd'] ?? $data['price_per_watt'] ?? 0);
    $priceUsd = floatval($data['unit_price_usd'] ?? 0);

    // Phase & output
    $threePhaseValue = strtolower(trim($data['three_phase'] ?? 'no'));
    $threePhase = ($threePhaseValue === 'yes' || $threePhaseValue === '1' || $threePhaseValue === 'true') ? 1 : 0;
    $outputAcVoltageRange = $data['output_ac_voltage_range'] ?? null;
    $powerFactor = $data['power_factor'] ?? null;

    // Battery info
    $batteryVoltageRange = $data['battery_voltage_range'] ?? null;
    // Clean up battery voltage range (remove "0" values)
    if ($batteryVoltageRange === '0' || $batteryVoltageRange === 0) {
        $batteryVoltageRange = null;
    }
    
    $hasBms = 0;
    $bmsVal = strtolower(trim($data['bms'] ?? 'no'));
    if ($bmsVal === 'yes' || $bmsVal === '1' || $bmsVal === 'true') {
        $hasBms = 1;
    }

    // Communication & efficiency
    $communication = $data['communication'] ?? null;
    $maxEfficiency = floatval($data['max_efficiency'] ?? 0);
    // Convert efficiency from decimal (0.972) to percentage (97.2) if needed
    if ($maxEfficiency > 0 && $maxEfficiency < 1) {
        $maxEfficiency = $maxEfficiency * 100;
    }
    $euroEfficiency = floatval($data['euro_efficiency'] ?? 0) ?: null;

    // Physical
    $ipRating = $data['ip_rating'] ?? null;
    $coolingMethod = $data['cooling_method'] ?? null;
    $displayType = $data['display_type'] ?? null;
    $operatingTemp = $data['operating_temperature'] ?? null;
    $noiseLevel = $data['noise_level'] ?? null;
    $weightKg = floatval($data['weight_kg'] ?? 0) ?: null;
    $dimensions = $data['dimensions'] ?? null;
    $warrantyYears = intval($data['warranty_years'] ?? 5);

    // Parallel capability
    $supportsParallel = 0;
    $spVal = strtolower(trim($data['supports_parallel'] ?? 'no'));
    if ($spVal === 'yes' || $spVal === '1' || $spVal === 'true') {
        $supportsParallel = 1;
    }
    $maxParallelUnits = intval($data['max_parallel_units'] ?? 1);
    
    // NEW: Primary Application
    $primaryApplication = strtolower(trim($data['Primary Application'] ?? $data['primary_application'] ?? 'residential'));
    if (!in_array($primaryApplication, ['residential', 'commercial', 'industrial', 'utility'])) {
        // Auto-detect from power rating
        if ($outputWatts < 5000) $primaryApplication = 'residential';
        elseif ($outputWatts < 50000) $primaryApplication = 'commercial';
        elseif ($outputWatts < 500000) $primaryApplication = 'industrial';
        else $primaryApplication = 'utility';
    }
    
    // NEW: Hybrid/Off-grid charging power
    $hybridChargingPower = intval($data['hybrid_offgrid_charging_power_watt'] ?? 0);
    
    // NEW: Status
    $status = strtolower(trim($data['Status'] ?? $data['status'] ?? 'available'));
    if (!in_array($status, ['available', 'discontinued', 'coming_soon'])) {
        $status = 'available';
    }

    // Derive voltage_class from battery_voltage_range, input voltages, and power rating
    // Think like an electrical engineer: high power = high voltage
    $voltageClass = null;
    
    // Method 1: Parse battery_voltage_range intelligently
    if (!empty($batteryVoltageRange)) {
        $bvr = trim($batteryVoltageRange);
        
        // Extract all numbers from the range
        preg_match_all('/(\d+)/', $bvr, $matches);
        $voltages = array_map('intval', $matches[0]);
        
        if (!empty($voltages)) {
            // Use the MAXIMUM voltage in the range (most important for classification)
            $maxBatteryV = max($voltages);
            
            // Classify based on actual voltage (not just first digit!)
            if ($maxBatteryV <= 16) {
                $voltageClass = '12V';
            } elseif ($maxBatteryV <= 30) {
                $voltageClass = '24V';
            } elseif ($maxBatteryV <= 60) {
                $voltageClass = '48V';
            } elseif ($maxBatteryV <= 120) {
                $voltageClass = '96V';
            } elseif ($maxBatteryV <= 250) {
                $voltageClass = '200V';
            } elseif ($maxBatteryV <= 350) {
                $voltageClass = '300V';
            } elseif ($maxBatteryV <= 450) {
                $voltageClass = '400V';
            } elseif ($maxBatteryV <= 650) {
                $voltageClass = '600V';
            } elseif ($maxBatteryV <= 850) {
                $voltageClass = '800V';
            } else {
                $voltageClass = '1000V+';
            }
        }
    }
    
    // Method 2: If no battery_voltage_range, use max_pv_voltage (DC input from PV/batteries)
    if (empty($voltageClass) && !empty($maxPvVoltage)) {
        if ($maxPvVoltage <= 20) {
            $voltageClass = '12V';
        } elseif ($maxPvVoltage <= 35) {
            $voltageClass = '24V';
        } elseif ($maxPvVoltage <= 65) {
            $voltageClass = '48V';
        } elseif ($maxPvVoltage <= 125) {
            $voltageClass = '96V';
        } elseif ($maxPvVoltage <= 250) {
            $voltageClass = '200V';
        } elseif ($maxPvVoltage <= 350) {
            $voltageClass = '300V';
        } elseif ($maxPvVoltage <= 450) {
            $voltageClass = '400V';
        } elseif ($maxPvVoltage <= 650) {
            $voltageClass = '600V';
        } elseif ($maxPvVoltage <= 850) {
            $voltageClass = '800V';
        } else {
            $voltageClass = '1000V+';
        }
    }
    
    // Method 3: Power-based estimation (high power inverters use high voltage)
    if (empty($voltageClass) && $outputWatts > 0) {
        if ($outputWatts >= 100000) {
            $voltageClass = '800V'; // 100kW+ typically 600-1000V
        } elseif ($outputWatts >= 50000) {
            $voltageClass = '600V'; // 50-100kW typically 400-800V
        } elseif ($outputWatts >= 20000) {
            $voltageClass = '400V'; // 20-50kW typically 300-600V
        } elseif ($outputWatts >= 10000) {
            $voltageClass = '300V'; // 10-20kW typically 200-400V
        } elseif ($outputWatts >= 5000) {
            $voltageClass = '200V'; // 5-10kW could be 96-300V
        } else {
            $voltageClass = '48V'; // <5kW typically 48V or lower
        }
    }
    
    // Fallback: default to 48V (most common for small systems)
    if (empty($voltageClass)) {
        $voltageClass = '48V';
    }

    // Country
    $countryOrigin = $csvCountry;
    $cc = !empty($countryCode) ? $countryCode : (!empty($csvCountry) ? strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $csvCountry), 0, 2)) : 'global');

    // Convert three_phase and supports_parallel to Yes/No (clean table format)
    $threePhaseStr = $threePhase ? 'Yes' : 'No';
    $supportsParallelStr = $supportsParallel ? 'Yes' : 'No';
    $bmsStr = $hasBms ? 'Yes' : 'No';
    
    // Format efficiency as percentage string
    if ($maxEfficiency > 0) {
        $maxEfficiencyStr = $maxEfficiency . '%';
    } else {
        $maxEfficiencyStr = null;
    }

    // Detect table structure (old vs clean)
    $hasModelColumn = false;
    try {
        $stmt = $db->query("SHOW COLUMNS FROM inverters LIKE 'model'");
        $hasModelColumn = ($stmt->rowCount() > 0);
    } catch (Exception $e) {
        $hasModelColumn = false;
    }

    // Check duplicate using appropriate column name
    if ($hasModelColumn) {
        // New clean table structure
        $stmt = $db->prepare("SELECT id FROM inverters WHERE company_id = ? AND LOWER(model) = LOWER(?)");
    } else {
        // Old table structure
        $stmt = $db->prepare("SELECT id FROM inverters WHERE company_id = ? AND LOWER(name) = LOWER(?)");
    }
    $stmt->execute([$companyId, $name]);
    $existing = $stmt->fetch();

    if ($existing) {
        // UPDATE - Use appropriate column names based on table structure
        if ($hasModelColumn) {
            // CLEAN TABLE (new structure)
            $stmt = $db->prepare("UPDATE inverters SET
                company = ?, series_name = ?, type = ?, output_power_w = ?,
                max_pv_input_w = ?, surge_power_w = ?, min_pv_voltage = ?, max_pv_voltage = ?,
                price_per_watt_usd = ?, unit_price_usd = ?,
                three_phase = ?, output_ac_voltage_range = ?, power_factor = ?,
                battery_voltage_range = ?, bms = ?, communication = ?,
                max_efficiency = ?, ip_rating = ?, cooling_method = ?,
                display_type = ?, operating_temperature = ?, noise_level = ?,
                weight_kg = ?, dimensions = ?, warranty_years = ?,
                supports_parallel = ?, max_parallel_units = ?,
                primary_application = ?, hybrid_offgrid_charging_power_watt = ?, status = ?,
                country = ?, is_active = 1
                WHERE id = ?");
            $stmt->execute([
                $brand, $seriesName, $inverterType, $outputWatts,
                $maxPvInput, $surgeWatts, $minPvVoltage, $maxPvVoltage,
                $pricePerWatt, $priceUsd,
                $threePhaseStr, $outputAcVoltageRange, $powerFactor,
                $batteryVoltageRange, $bmsStr, $communication,
                $maxEfficiencyStr, $ipRating, $coolingMethod,
                $displayType, $operatingTemp, $noiseLevel,
                $weightKg, $dimensions, $warrantyYears,
                $supportsParallelStr, $maxParallelUnits,
                $primaryApplication, $hybridChargingPower, $status,
                $countryOrigin, $existing['id']
            ]);
        } else {
            // OLD TABLE (original structure)
            // Check if min_pv_voltage exists in old table
            $hasPvVoltageColumns = false;
            try {
                $stmt = $db->query("SHOW COLUMNS FROM inverters LIKE 'min_pv_voltage'");
                $hasPvVoltageColumns = ($stmt->rowCount() > 0);
            } catch (Exception $e) {
                $hasPvVoltageColumns = false;
            }
            
            if ($hasPvVoltageColumns) {
                // Old table WITH min/max_pv_voltage columns
                $stmt = $db->prepare("UPDATE inverters SET
                    brand = ?, series_name = ?, type = ?, output_watts = ?, power_rating = ?,
                    max_pv_input = ?, surge_power_watts = ?, min_pv_voltage = ?, max_pv_voltage = ?,
                    input_voltage_min = ?, input_voltage_max = ?,
                    price_usd = ?, price_per_watt = ?,
                    three_phase = ?, output_ac_voltage_range = ?, power_factor = ?,
                    battery_voltage_range = ?, has_bms = ?, communication = ?,
                    efficiency = ?, ip_rating = ?, cooling_method = ?,
                    display_type = ?, operating_temperature = ?, noise_level = ?,
                    weight_kg = ?, dimensions = ?, warranty_years = ?,
                    supports_parallel = ?, max_parallel_units = ?,
                    primary_application = ?, hybrid_offgrid_charging_power_watt = ?, status = ?,
                    country_origin = ?, is_active = 1
                    WHERE id = ?");
                $stmt->execute([
                    $brand, $seriesName, $inverterType, $outputWatts, $outputWatts,
                    $maxPvInput, $surgeWatts, $minPvVoltage, $maxPvVoltage,
                    $minPvVoltage, $maxPvVoltage,
                    $priceUsd, $pricePerWatt,
                    $threePhase, $outputAcVoltageRange, $powerFactor,
                    $batteryVoltageRange, $hasBms, $communication,
                    $maxEfficiency, $ipRating, $coolingMethod,
                    $displayType, $operatingTemp, $noiseLevel,
                    $weightKg, $dimensions, $warrantyYears,
                    $supportsParallel, $maxParallelUnits,
                    $primaryApplication, $hybridChargingPower, $status,
                    $countryOrigin, $existing['id']
                ]);
            } else {
                // Old table WITHOUT min/max_pv_voltage columns
                // Check if primary_application exists
                $hasNewColumns = false;
                try {
                    $stmt = $db->query("SHOW COLUMNS FROM inverters LIKE 'primary_application'");
                    $hasNewColumns = ($stmt->rowCount() > 0);
                } catch (Exception $e) {
                    $hasNewColumns = false;
                }
                
                if ($hasNewColumns) {
                    // Old table with some new columns added
                    $stmt = $db->prepare("UPDATE inverters SET
                        brand = ?, series_name = ?, type = ?, output_watts = ?, power_rating = ?,
                        max_pv_input = ?, surge_power_watts = ?,
                        input_voltage_min = ?, input_voltage_max = ?,
                        price_usd = ?, price_per_watt = ?,
                        three_phase = ?, output_ac_voltage_range = ?, power_factor = ?,
                        battery_voltage_range = ?, has_bms = ?, communication = ?,
                        efficiency = ?, ip_rating = ?, cooling_method = ?,
                        display_type = ?, operating_temperature = ?, noise_level = ?,
                        weight_kg = ?, dimensions = ?, warranty_years = ?,
                        supports_parallel = ?, max_parallel_units = ?,
                        primary_application = ?, hybrid_offgrid_charging_power_watt = ?, status = ?,
                        country_origin = ?, is_active = 1
                        WHERE id = ?");
                    $stmt->execute([
                        $brand, $seriesName, $inverterType, $outputWatts, $outputWatts,
                        $maxPvInput, $surgeWatts,
                        $minPvVoltage, $maxPvVoltage,
                        $priceUsd, $pricePerWatt,
                        $threePhase, $outputAcVoltageRange, $powerFactor,
                        $batteryVoltageRange, $hasBms, $communication,
                        $maxEfficiency, $ipRating, $coolingMethod,
                        $displayType, $operatingTemp, $noiseLevel,
                        $weightKg, $dimensions, $warrantyYears,
                        $supportsParallel, $maxParallelUnits,
                        $primaryApplication, $hybridChargingPower, $status,
                        $countryOrigin, $existing['id']
                    ]);
                } else {
                    // Very old table - YOUR CURRENT TABLE (59 columns, usage_type ENUM)
                    $stmt = $db->prepare("UPDATE inverters SET
                        brand = ?, series_name = ?, type = ?, output_watts = ?, power_rating = ?,
                        max_pv_input = ?, surge_power_watts = ?,
                        input_voltage_min = ?, input_voltage_max = ?,
                        price_usd = ?, price_per_watt = ?,
                        three_phase = ?, output_ac_voltage_range = ?, power_factor = ?,
                        battery_voltage_range = ?, has_bms = ?, communication = ?,
                        efficiency = ?, ip_rating = ?, cooling_method = ?,
                        display_type = ?, operating_temperature = ?, noise_level = ?,
                        weight_kg = ?, dimensions = ?, warranty_years = ?,
                        supports_parallel = ?, max_parallel_units = ?,
                        usage_type = ?, country_origin = ?, is_active = 1
                        WHERE id = ?");
                    $stmt->execute([
                        $brand, $seriesName, $inverterType, $outputWatts, $outputWatts,
                        $maxPvInput, $surgeWatts,
                        $minPvVoltage, $maxPvVoltage,
                        $priceUsd, $pricePerWatt,
                        $threePhase, $outputAcVoltageRange, $powerFactor,
                        $batteryVoltageRange, $hasBms, $communication,
                        $maxEfficiency, $ipRating, $coolingMethod,
                        $displayType, $operatingTemp, $noiseLevel,
                        $weightKg, $dimensions, $warrantyYears,
                        $supportsParallel, $maxParallelUnits,
                        $primaryApplication, $countryOrigin, $existing['id']
                    ]);
                }
            }
        }
        return 'updated';
    } else {
        // INSERT - Use appropriate column names based on table structure
        if ($hasModelColumn) {
            // CLEAN TABLE (new structure)
            $stmt = $db->prepare("INSERT INTO inverters (
                company_id, model, company, series_name, type, output_power_w,
                max_pv_input_w, surge_power_w, min_pv_voltage, max_pv_voltage,
                price_per_watt_usd, unit_price_usd,
                three_phase, output_ac_voltage_range, power_factor,
                battery_voltage_range, bms, communication,
                max_efficiency, ip_rating, cooling_method,
                display_type, operating_temperature, noise_level,
                weight_kg, dimensions, warranty_years,
                supports_parallel, max_parallel_units,
                primary_application, hybrid_offgrid_charging_power_watt, status,
                country, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
            $stmt->execute([
                $companyId, $name, $brand, $seriesName, $inverterType, $outputWatts,
                $maxPvInput, $surgeWatts, $minPvVoltage, $maxPvVoltage,
                $pricePerWatt, $priceUsd,
                $threePhaseStr, $outputAcVoltageRange, $powerFactor,
                $batteryVoltageRange, $bmsStr, $communication,
                $maxEfficiencyStr, $ipRating, $coolingMethod,
                $displayType, $operatingTemp, $noiseLevel,
                $weightKg, $dimensions, $warrantyYears,
                $supportsParallelStr, $maxParallelUnits,
                $primaryApplication, $hybridChargingPower, $status,
                $countryOrigin
            ]);
        } else {
            // OLD TABLE (original structure)
            // Check if min_pv_voltage exists in old table
            $hasPvVoltageColumns = false;
            try {
                $stmt = $db->query("SHOW COLUMNS FROM inverters LIKE 'min_pv_voltage'");
                $hasPvVoltageColumns = ($stmt->rowCount() > 0);
            } catch (Exception $e) {
                $hasPvVoltageColumns = false;
            }
            
            if ($hasPvVoltageColumns) {
                // Old table WITH min/max_pv_voltage columns
                $stmt = $db->prepare("INSERT INTO inverters (
                    company_id, name, brand, series_name, type, output_watts, power_rating,
                    max_pv_input, surge_power_watts, min_pv_voltage, max_pv_voltage,
                    input_voltage_min, input_voltage_max,
                    price_usd, price_per_watt,
                    three_phase, output_ac_voltage_range, power_factor,
                    battery_voltage_range, has_bms, communication,
                    efficiency, ip_rating, cooling_method,
                    display_type, operating_temperature, noise_level,
                    weight_kg, dimensions, warranty_years,
                    supports_parallel, max_parallel_units,
                    primary_application, hybrid_offgrid_charging_power_watt, status,
                    country_origin, is_active
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
                $stmt->execute([
                    $companyId, $name, $brand, $seriesName, $inverterType, $outputWatts, $outputWatts,
                    $maxPvInput, $surgeWatts, $minPvVoltage, $maxPvVoltage,
                    $minPvVoltage, $maxPvVoltage,
                    $priceUsd, $pricePerWatt,
                    $threePhase, $outputAcVoltageRange, $powerFactor,
                    $batteryVoltageRange, $hasBms, $communication,
                    $maxEfficiency, $ipRating, $coolingMethod,
                    $displayType, $operatingTemp, $noiseLevel,
                    $weightKg, $dimensions, $warrantyYears,
                    $supportsParallel, $maxParallelUnits,
                    $primaryApplication, $hybridChargingPower, $status,
                    $countryOrigin
                ]);
            } else {
                // Old table WITHOUT min/max_pv_voltage columns (basic version)
                // Also check for newer columns
                $hasNewColumns = false;
                try {
                    $stmt = $db->query("SHOW COLUMNS FROM inverters LIKE 'primary_application'");
                    $hasNewColumns = ($stmt->rowCount() > 0);
                } catch (Exception $e) {
                    $hasNewColumns = false;
                }
                
                if ($hasNewColumns) {
                    $stmt = $db->prepare("INSERT INTO inverters (
                        company_id, name, brand, series_name, type, output_watts, power_rating,
                        max_pv_input, surge_power_watts,
                        input_voltage_min, input_voltage_max,
                        price_usd, price_per_watt,
                        three_phase, output_ac_voltage_range, power_factor,
                        battery_voltage_range, has_bms, communication,
                        efficiency, ip_rating, cooling_method,
                        display_type, operating_temperature, noise_level,
                        weight_kg, dimensions, warranty_years,
                        supports_parallel, max_parallel_units,
                        primary_application, hybrid_offgrid_charging_power_watt, status,
                        country_origin, is_active
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
                    $stmt->execute([
                        $companyId, $name, $brand, $seriesName, $inverterType, $outputWatts, $outputWatts,
                        $maxPvInput, $surgeWatts,
                        $minPvVoltage, $maxPvVoltage,
                        $priceUsd, $pricePerWatt,
                        $threePhase, $outputAcVoltageRange, $powerFactor,
                        $batteryVoltageRange, $hasBms, $communication,
                        $maxEfficiency, $ipRating, $coolingMethod,
                        $displayType, $operatingTemp, $noiseLevel,
                        $weightKg, $dimensions, $warrantyYears,
                        $supportsParallel, $maxParallelUnits,
                        $primaryApplication, $hybridChargingPower, $status,
                        $countryOrigin
                    ]);
                } else {
                    // Very old table - YOUR CURRENT TABLE (59 columns, usage_type ENUM)
                    $stmt = $db->prepare("INSERT INTO inverters (
                        company_id, name, brand, series_name, type, output_watts, power_rating,
                        max_pv_input, surge_power_watts,
                        input_voltage_min, input_voltage_max,
                        price_usd, price_per_watt,
                        three_phase, output_ac_voltage_range, power_factor,
                        battery_voltage_range, has_bms, communication,
                        efficiency, ip_rating, cooling_method,
                        display_type, operating_temperature, noise_level,
                        weight_kg, dimensions, warranty_years,
                        supports_parallel, max_parallel_units,
                        usage_type, country_origin, is_active
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
                    $stmt->execute([
                        $companyId, $name, $brand, $seriesName, $inverterType, $outputWatts, $outputWatts,
                        $maxPvInput, $surgeWatts,
                        $minPvVoltage, $maxPvVoltage,
                        $priceUsd, $pricePerWatt,
                        $threePhase, $outputAcVoltageRange, $powerFactor,
                        $batteryVoltageRange, $hasBms, $communication,
                        $maxEfficiency, $ipRating, $coolingMethod,
                        $displayType, $operatingTemp, $noiseLevel,
                        $weightKg, $dimensions, $warrantyYears,
                        $supportsParallel, $maxParallelUnits,
                        $primaryApplication, $countryOrigin
                    ]);
                }
            }
        }
        return 'inserted';
    }
}

function importBattery($db, $data, $countryCode) {
    // CSV columns: country, brand, model, technology, nominal_voltage_v, capacity_kwh, nominal_energy_kwh, capacity_ah,
    // cycle_life, design_life, round_trip_efficiency, configuration, mounting_options,
    // max_parallel_units, ip_rating, cooling_method, communication, monitoring,
    // operating_temp, dimensions, weight_kg, price_per_kwh, price_unit_usd, warranty,
    // charge_voltage, discharge_voltage, max_charge_current, max_discharge_current,
    // depth_of_discharge, self_discharge, certifications

    $csvCountry = trim($data['country'] ?? '');
    $brand = trim($data['brand'] ?? '');
    $model = trim($data['model'] ?? '');
    $companyId = getOrCreateCompany($db, $brand, $csvCountry);

    // Core specs
    $nominalVoltage = intval($data['nominal_voltage_v'] ?? 48);
    $energyKwh = floatval($data['nominal_energy_kwh'] ?? 0);
    $capacityKwh = floatval($data['capacity_kwh'] ?? 0);
    $capacityAh = intval($data['capacity_ah'] ?? 0);
    
    // Use capacity_kwh if provided, otherwise use nominal_energy_kwh
    if ($capacityKwh > 0) {
        $energyKwh = $capacityKwh;
    }
    
    // If capacity_ah not provided, derive from energy: kWh = V * Ah / 1000 → Ah = kWh * 1000 / V
    if ($capacityAh == 0 && $nominalVoltage > 0 && $energyKwh > 0) {
        $capacityAh = round($energyKwh * 1000 / $nominalVoltage);
    }
    
    // If energy not provided, derive from capacity: kWh = V * Ah / 1000
    if ($energyKwh == 0 && $nominalVoltage > 0 && $capacityAh > 0) {
        $energyKwh = round($nominalVoltage * $capacityAh / 1000, 2);
    }

    // Auto-generate model if not provided: Brand VoltageV EnergyKwh
    if (empty($model)) {
        $model = trim($brand) . ' ' . $nominalVoltage . 'V ' . $energyKwh . 'kWh';
    }

    // Check duplicate by company + model (using new column name)
    $stmt = $db->prepare("SELECT id FROM batteries WHERE company_id = ? AND LOWER(model) = LOWER(?)");
    $stmt->execute([$companyId, $model]);
    $existing = $stmt->fetch();

    // Technology → type mapping (removed battery_type column)
    $technology = $data['technology'] ?? 'LFP';
    $type = 'lfp'; // default for type column
    $techLower = strtolower($technology);
    
    if (strpos($techLower, 'lfp') !== false || strpos($techLower, 'lifepo4') !== false) {
        $type = 'lfp';
    } elseif (strpos($techLower, 'lithium') !== false || strpos($techLower, 'li-ion') !== false || strpos($techLower, 'nmc') !== false) {
        $type = 'lithium';
    } elseif (strpos($techLower, 'lead') !== false) {
        $type = 'lead-acid';
    } elseif (strpos($techLower, 'gel') !== false) {
        $type = 'gel';
    } elseif (strpos($techLower, 'agm') !== false) {
        $type = 'agm';
    }

    $cycleLife = intval($data['cycle_life'] ?? 0) ?: null;
    $designLife = $data['design_life'] ?? null;
    $roundTripEfficiency = floatval($data['round_trip_efficiency'] ?? 0) ?: null;
    $configuration = $data['configuration'] ?? null;
    $mountingOptions = $data['mounting_options'] ?? null;
    $maxParallelUnits = intval($data['max_parallel_units'] ?? 1);
    $ipRating = $data['ip_rating'] ?? null;
    $coolingMethod = $data['cooling_method'] ?? null;
    $communication = $data['communication'] ?? null;
    $monitoring = $data['monitoring'] ?? null;
    $operatingTemp = $data['operating_temp'] ?? '-10C to 50C';
    $dimensions = $data['dimensions'] ?? null;
    $weightKg = floatval($data['weight_kg'] ?? 0) ?: null;

    // Pricing - CRITICAL FIELDS (using new column name price_unit_usd)
    $pricePerKwh = floatval($data['price_per_kwh'] ?? 0) ?: null;
    $priceUnitUsd = floatval($data['price_unit_usd'] ?? 0);
    $currency = $data['currency'] ?? 'USD';

    // Warranty — parse number from string like "10 years" or just "10"
    $warrantyRaw = $data['warranty'] ?? '10';
    $warrantyYears = intval(preg_replace('/[^0-9]/', '', $warrantyRaw)) ?: 10;

    // Electrical details
    $chargeVoltage = $data['charge_voltage'] ?? null;
    $dischargeVoltage = $data['discharge_voltage'] ?? null;
    $maxChargeCurrent = intval($data['max_charge_current'] ?? 0) ?: null;
    $maxDischargeCurrent = intval($data['max_discharge_current'] ?? 0) ?: null;
    
    // Depth of discharge - handle both decimal and percentage
    $dodRaw = floatval($data['depth_of_discharge'] ?? 0);
    if ($dodRaw > 0 && $dodRaw <= 1) {
        $dod = $dodRaw; // 0.90 format for dod column
        $dodPercent = intval($dodRaw * 100); // 90 for depth_of_discharge column
    } elseif ($dodRaw > 1) {
        $dod = $dodRaw / 100; // 90 → 0.90
        $dodPercent = intval($dodRaw); // 90
    } else {
        $dod = 0.90; // default 90%
        $dodPercent = 90;
    }
    
    $selfDischarge = $data['self_discharge'] ?? null;
    $certifications = $data['certifications'] ?? null;

    // BMS: lithium batteries almost always have BMS (convert to 'Yes'/'No' string)
    $hasBms = (strpos($techLower, 'lithium') !== false || strpos($techLower, 'lfp') !== false || strpos($techLower, 'li') !== false);
    $isBms = $hasBms ? 'Yes' : 'No'; // New format: string 'Yes'/'No'
    $maintenanceFree = ($type !== 'lead-acid') ? 1 : 0;

    // Country (using new column name: country instead of country_origin)
    $country = $csvCountry;
    $cc = !empty($countryCode) ? $countryCode : (!empty($csvCountry) ? strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $csvCountry), 0, 2)) : 'global');
    
    $availableRegions = $data['available_regions'] ?? 'global';
    $features = $data['features'] ?? null;
    $notes = $data['notes'] ?? null;

    if ($existing) {
        // UPDATE query using actual battery table column names (brand, not company)
        // Note: batteries table uses 'brand' while inverters use 'company'
        $stmt = $db->prepare("UPDATE batteries SET
            model = ?, brand = ?, type = ?, technology = ?, nominal_voltage = ?, capacity_ah = ?,
            energy_capacity_kwh = ?, cycle_life = ?, design_life = ?,
            round_trip_efficiency = ?, configuration = ?, mounting_options = ?,
            max_parallel_units = ?, ip_rating = ?, cooling_method = ?,
            communication = ?, monitoring = ?, operating_temp = ?,
            dimensions = ?, weight_kg = ?, price_unit_usd = ?,
            warranty_years = ?, charge_voltage = ?, discharge_voltage = ?,
            charging_current_max = ?, max_discharge_current = ?,
            depth_of_discharge = ?, self_discharge = ?, certifications = ?,
            is_bms = ?, maintenance_free = ?,
            country = ?, available_regions = ?,
            features = ?, notes = ?, is_active = 1
            WHERE id = ?");
        $stmt->execute([
            $model, $brand, $type, $technology, $nominalVoltage, $capacityAh,
            $energyKwh, $cycleLife, $designLife,
            $roundTripEfficiency, $configuration, $mountingOptions,
            $maxParallelUnits, $ipRating, $coolingMethod,
            $communication, $monitoring, $operatingTemp,
            $dimensions, $weightKg, $priceUnitUsd,
            $warrantyYears, $chargeVoltage, $dischargeVoltage,
            $maxChargeCurrent, $maxDischargeCurrent,
            $dodPercent, $selfDischarge, $certifications,
            $isBms, $maintenanceFree,
            $country, $availableRegions,
            $features, $notes, $existing['id']
        ]);
        return 'updated';
    } else {
        // INSERT query using actual battery table column names (brand, not company)
        // Note: batteries table uses 'brand' while inverters use 'company'
        $stmt = $db->prepare("INSERT INTO batteries (
            company_id, model, brand, type, technology, nominal_voltage, capacity_ah,
            energy_capacity_kwh, cycle_life, design_life,
            round_trip_efficiency, configuration, mounting_options,
            max_parallel_units, ip_rating, cooling_method,
            communication, monitoring, operating_temp,
            dimensions, weight_kg, price_unit_usd,
            warranty_years, charge_voltage, discharge_voltage,
            charging_current_max, max_discharge_current,
            depth_of_discharge, self_discharge, certifications,
            is_bms, maintenance_free,
            country, available_regions,
            features, notes, is_active
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([
            $companyId, $model, $brand, $type, $technology, $nominalVoltage, $capacityAh,
            $energyKwh, $cycleLife, $designLife,
            $roundTripEfficiency, $configuration, $mountingOptions,
            $maxParallelUnits, $ipRating, $coolingMethod,
            $communication, $monitoring, $operatingTemp,
            $dimensions, $weightKg, $priceUnitUsd,
            $warrantyYears, $chargeVoltage, $dischargeVoltage,
            $maxChargeCurrent, $maxDischargeCurrent,
            $dodPercent, $selfDischarge, $certifications,
            $isBms, $maintenanceFree,
            $country, $availableRegions,
            $features, $notes
        ]);
        return 'inserted';
    }
}

function importPanel($db, $data, $countryCode) {
    // CSV columns: name, brand, country, technology, power_range, pmax_w, voc_v, isc_a,
    // cell_type, cell_count, cell_size, dimensions, weight_kg, price_per_watt, price_actual,
    // warranty_product, glass_type, glass_thickness, frame_type, junction_box, connector, cable_spec

    $brand = trim($data['brand']);
    $name = trim($data['name']);
    $csvCountry = $data['country'] ?? '';
    $companyId = getOrCreateCompany($db, $brand, $csvCountry);

    // Check duplicate by company + name (case-insensitive)
    $stmt = $db->prepare("SELECT id FROM panels WHERE company_id = ? AND LOWER(name) = LOWER(?)");
    $stmt->execute([$companyId, $name]);
    $existing = $stmt->fetch();

    // Technology → panel_type mapping
    $technology = $data['technology'] ?? 'Monocrystalline';
    $panelType = 'Monocrystalline'; // default
    $techLower = strtolower($technology);
    if (strpos($techLower, 'mono') !== false) {
        $panelType = 'Monocrystalline';
    } elseif (strpos($techLower, 'poly') !== false || strpos($techLower, 'multi') !== false) {
        $panelType = 'Polycrystalline';
    } elseif (strpos($techLower, 'bifacial') !== false) {
        $panelType = 'Bifacial';
    } elseif (strpos($techLower, 'thin') !== false) {
        $panelType = 'Thin-Film';
    }

    // Core specs
    $powerRange = $data['power_range'] ?? null;
    $wattPeak = intval($data['pmax_w'] ?? 0);
    $voc = floatval($data['voc_v'] ?? 0);
    $isc = floatval($data['isc_a'] ?? 0);
    // Estimate Vmp from Voc if not provided (typically ~82% of Voc)
    $vmp = ($voc > 0) ? round($voc * 0.82, 2) : 0;

    $cellType = $data['cell_type'] ?? null;
    $cellCount = intval($data['cell_count'] ?? 0) ?: null;
    $cellSize = $data['cell_size'] ?? null;
    $dimensions = $data['dimensions'] ?? null;
    $weightKg = floatval($data['weight_kg'] ?? 0) ?: null;

    // Pricing
    $pricePerWatt = floatval($data['price_per_watt'] ?? 0);
    $priceUsd = floatval($data['price_actual'] ?? 0);
    // If price_actual is 0 but we have price_per_watt and wattage, calculate
    if ($priceUsd <= 0 && $pricePerWatt > 0 && $wattPeak > 0) {
        $priceUsd = round($pricePerWatt * $wattPeak, 2);
    }

    // Warranty — parse number from string like "12 years" or just "12"
    $warrantyProduct = $data['warranty_product'] ?? null;
    $warrantyYears = 25; // default for panels
    if (!empty($warrantyProduct)) {
        $wy = intval(preg_replace('/[^0-9]/', '', $warrantyProduct));
        if ($wy > 0) $warrantyYears = $wy;
    }

    // Physical construction
    $glassType = $data['glass_type'] ?? null;
    $glassThickness = $data['glass_thickness'] ?? null;
    $frameType = $data['frame_type'] ?? null;
    $junctionBox = $data['junction_box'] ?? null;
    $connector = $data['connector'] ?? null;
    $cableSpec = $data['cable_spec'] ?? null;

    // Estimate efficiency if dimensions available: eff = Pmax / (area_m2 * 1000) * 100
    $efficiency = 20.0; // default
    if ($wattPeak > 0 && !empty($dimensions)) {
        // Try to parse dimensions like "2278×1134×30mm" or "2278x1134x30"
        if (preg_match('/(\d+)\s*[x×]\s*(\d+)/i', $dimensions, $dm)) {
            $areaM2 = ($dm[1] / 1000) * ($dm[2] / 1000);
            if ($areaM2 > 0) {
                $efficiency = round(($wattPeak / ($areaM2 * 1000)) * 100, 2);
            }
        }
    }

    // Country
    $csvCountry = $data['country'] ?? '';
    $cc = !empty($countryCode) ? $countryCode : (!empty($csvCountry) ? strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $csvCountry), 0, 2)) : 'global');

    if ($existing) {
        $stmt = $db->prepare("UPDATE panels SET
            brand = ?, panel_type = ?, technology = ?, power_range = ?, wattage = ?,
            voc = ?, isc = ?, vmp = ?,
            cell_type = ?, cells_count = ?, cell_size = ?,
            dimensions = ?, weight_kg = ?,
            price_per_watt = ?, price_usd = ?,
            efficiency = ?, warranty_years = ?, warranty_product = ?,
            glass_type = ?, glass_thickness = ?, frame_type = ?,
            junction_box = ?, connector = ?, cable_spec = ?,
            country_origin = ?, country_code = ?, is_active = 1
            WHERE id = ?");
        $stmt->execute([
            $brand, $panelType, $technology, $powerRange, $wattPeak,
            $voc, $isc, $vmp,
            $cellType, $cellCount, $cellSize,
            $dimensions, $weightKg,
            $pricePerWatt, $priceUsd,
            $efficiency, $warrantyYears, $warrantyProduct,
            $glassType, $glassThickness, $frameType,
            $junctionBox, $connector, $cableSpec,
            $csvCountry, $cc, $existing['id']
        ]);
        return 'updated';
    } else {
        $stmt = $db->prepare("INSERT INTO panels (
            company_id, name, brand, panel_type, technology, power_range, wattage,
            voc, isc, vmp,
            cell_type, cells_count, cell_size,
            dimensions, weight_kg,
            price_per_watt, price_usd,
            efficiency, warranty_years, warranty_product,
            glass_type, glass_thickness, frame_type,
            junction_box, connector, cable_spec,
            country_origin, country_code, is_active
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([
            $companyId, $name, $brand, $panelType, $technology, $powerRange, $wattPeak,
            $voc, $isc, $vmp,
            $cellType, $cellCount, $cellSize,
            $dimensions, $weightKg,
            $pricePerWatt, $priceUsd,
            $efficiency, $warrantyYears, $warrantyProduct,
            $glassType, $glassThickness, $frameType,
            $junctionBox, $connector, $cableSpec,
            $csvCountry, $cc
        ]);
        return 'inserted';
    }
}

// Fetch recent import logs
$recentImports = [];
try {
    $recentImports = $db->query("SELECT * FROM import_logs ORDER BY created_at DESC LIMIT 10")->fetchAll();
} catch (Exception $e) {
    // Table might not exist yet
}

include __DIR__ . '/includes/header.php';
?>

<style>
    .import-container { max-width: 900px; margin: 0 auto; }
    .import-tabs { display: flex; gap: 0; margin-bottom: 24px; border-bottom: 2px solid #e5e7eb; }
    .import-tab { padding: 12px 24px; cursor: pointer; font-weight: 500; color: #6b7280; border-bottom: 2px solid transparent; margin-bottom: -2px; transition: all 0.2s; background: none; border-top: none; border-left: none; border-right: none; font-size: 14px; }
    .import-tab:hover { color: #f59e0b; }
    .import-tab.active { color: #f59e0b; border-bottom-color: #f59e0b; }
    .import-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 24px; }
    .import-card h3 { margin: 0 0 16px 0; font-size: 16px; color: #1f2937; }
    .form-group { margin-bottom: 16px; }
    .form-group label { display: block; font-weight: 500; font-size: 13px; color: #374151; margin-bottom: 6px; }
    .form-group select, .form-group input[type="file"] { width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; background: #fff; }
    .form-group select:focus { outline: none; border-color: #f59e0b; box-shadow: 0 0 0 3px rgba(245,158,11,0.1); }
    .btn-import { background: #f59e0b; color: #fff; border: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; font-size: 14px; cursor: pointer; transition: background 0.2s; }
    .btn-import:hover { background: #d97706; }
    .btn-template { background: #e5e7eb; color: #374151; border: none; padding: 8px 16px; border-radius: 6px; font-size: 13px; cursor: pointer; text-decoration: none; display: inline-block; transition: background 0.2s; }
    .btn-template:hover { background: #d1d5db; }
    .results-box { padding: 16px; border-radius: 8px; margin-bottom: 16px; }
    .results-success { background: #d1fae5; border: 1px solid #6ee7b7; }
    .results-error { background: #fee2e2; border: 1px solid #fca5a5; }
    .results-box .stat { display: inline-block; margin-right: 20px; font-size: 14px; }
    .results-box .stat strong { font-weight: 600; }
    .error-list { max-height: 200px; overflow-y: auto; font-size: 13px; color: #dc2626; margin-top: 8px; padding: 8px; background: #fff; border-radius: 4px; }
    .import-history { margin-top: 32px; }
    .import-history table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .import-history th { text-align: left; padding: 10px 12px; background: #f9fafb; color: #6b7280; font-weight: 500; border-bottom: 1px solid #e5e7eb; }
    .import-history td { padding: 10px 12px; border-bottom: 1px solid #f3f4f6; color: #374151; }
    .import-history tr:hover td { background: #f9fafb; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
    .badge-inverter { background: #dbeafe; color: #1d4ed8; }
    .badge-battery { background: #d1fae5; color: #047857; }
    .badge-panel { background: #fef3c7; color: #b45309; }
    .templates-section { display: flex; gap: 12px; flex-wrap: wrap; margin-top: 8px; }
    .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 14px; }
    .alert-success { background: #d1fae5; color: #065f46; border: 1px solid #6ee7b7; }
    .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
</style>

<div class="import-container">
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Import Results -->
    <?php if ($importResults): ?>
        <div class="import-card">
            <h3>Import Results</h3>
            <div class="results-box <?= ($importResults['inserted'] > 0 || $importResults['updated'] > 0) ? 'results-success' : 'results-error' ?>">
                <span class="stat"><strong><?= $importResults['total'] ?></strong> total rows</span>
                <span class="stat"><strong><?= $importResults['inserted'] ?></strong> inserted</span>
                <span class="stat"><strong><?= $importResults['updated'] ?></strong> updated</span>
                <span class="stat"><strong><?= $importResults['skipped'] ?></strong> skipped</span>
            </div>
            <?php if (!empty($importResults['errors'])): ?>
                <div class="error-list">
                    <?php foreach ($importResults['errors'] as $err): ?>
                        <div><?= htmlspecialchars($err) ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Import Form -->
    <div class="import-card">
        <h3>Step 1: Select Product Type</h3>
        <div class="import-tabs" id="product-tabs">
            <button class="import-tab active" data-type="inverter">Inverters</button>
            <button class="import-tab" data-type="battery">Batteries</button>
            <button class="import-tab" data-type="panel">Solar Panels</button>
        </div>

        <h3>Step 2: Download Sample Template & Company List</h3>
        <div class="templates-section">
            <a href="import-template.php?type=inverter" class="btn-template" id="tpl-link">&#128196; Download Inverter Template</a>
            <a href="export-companies.php?format=csv" class="btn-template" style="background:#dbeafe;color:#1d4ed8;">&#127970; Export Companies (CSV)</a>
            <a href="export-companies.php?format=json" class="btn-template" style="background:#d1fae5;color:#047857;">&#129302; Export Companies (JSON for AI)</a>
            <a href="export-schema.php" class="btn-template" style="background:#fef3c7;color:#b45309;">&#128218; Full Schema (JSON for AI)</a>
        </div>
        <p style="font-size:12px;color:#6b7280;margin-top:8px;">
            <b>For AI:</b> Download the <b>Full Schema</b> JSON and give it to your AI model. It contains all column definitions, allowed values, and the list of existing companies.<br>
            The AI must use exact brand names from the companies list. All prices must be in <b>USD</b>. The system links each product to its company via the "brand" column name match.
        </p>

        <form method="POST" enctype="multipart/form-data" style="margin-top: 24px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="import">
            <input type="hidden" name="product_type" id="product_type" value="inverter">

            <h3>Step 3: Select Country & Upload File</h3>
            <div class="form-group">
                <label for="country_code">Target Country</label>
                <select name="country_code" id="country_code">
                    <option value="">Global (No specific country)</option>
                    <?php foreach ($countries as $c): ?>
                        <option value="<?= htmlspecialchars($c['code']) ?>"><?= get_country_flag($c, 16) ?> <?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['code']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="csv_file">CSV File (max 10MB)</label>
                <input type="file" name="csv_file" id="csv_file" accept=".csv" required>
            </div>

            <button type="submit" class="btn-import">Import Products</button>
        </form>
    </div>

    <!-- Recent Import History -->
    <div class="import-card import-history">
        <h3>Recent Import History</h3>
        <?php if (empty($recentImports)): ?>
            <p style="color: #6b7280; font-size: 14px;">No imports yet.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Country</th>
                        <th>File</th>
                        <th>Inserted</th>
                        <th>Updated</th>
                        <th>Skipped</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentImports as $log): ?>
                        <tr>
                            <td><?= htmlspecialchars(date('M j, Y H:i', strtotime($log['created_at']))) ?></td>
                            <td><span class="badge badge-<?= htmlspecialchars($log['product_type']) ?>"><?= htmlspecialchars($log['product_type']) ?></span></td>
                            <td><?= htmlspecialchars(($log['country_code'] && $log['country_code'] !== 'global') ? $log['country_code'] : 'Global') ?></td>
                            <td><?= htmlspecialchars($log['filename'] ?? '') ?></td>
                            <td><?= intval($log['inserted']) ?></td>
                            <td><?= intval($log['updated']) ?></td>
                            <td><?= intval($log['skipped']) ?></td>
                            <td><?= htmlspecialchars($log['status'] ?? '') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<script>
    // Tab switching
    const tabs = document.querySelectorAll('.import-tab');
    const productTypeInput = document.getElementById('product_type');
    const tplLink = document.getElementById('tpl-link');

    const typeLabels = { inverter: 'Inverter', battery: 'Battery', panel: 'Panel' };

    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            const type = this.getAttribute('data-type');
            productTypeInput.value = type;
            tplLink.href = 'import-template.php?type=' + type;
            tplLink.textContent = 'Download ' + typeLabels[type] + ' Template';
        });
    });
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
