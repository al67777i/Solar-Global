<?php
/**
 * Customer Watchlist Page
 * View and manage watched products
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/customer_auth.php';

set_security_headers();
require_customer_login();

$customer = get_customer_profile();
$db = getDB();
$success = '';

// Handle remove
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';
    if ($action === 'remove') {
        $wid = (int)($_POST['watchlist_id'] ?? 0);
        $db->prepare("DELETE FROM watchlist WHERE id = ? AND customer_id = ?")->execute([$wid, $customer['id']]);
        $success = 'Removed from watchlist.';
    }
}

// Fetch watchlist with product details
$sql = "SELECT w.*,
        CASE w.product_type
            WHEN 'inverter' THEN (SELECT name FROM inverters WHERE id = w.product_id)
            WHEN 'battery' THEN (SELECT name FROM batteries WHERE id = w.product_id)
            WHEN 'panel' THEN (SELECT name FROM panels WHERE id = w.product_id)
            WHEN 'installation_appliance' THEN (SELECT name FROM installation_appliances WHERE id = w.product_id)
        END as product_name,
        CASE w.product_type
            WHEN 'inverter' THEN (SELECT brand FROM inverters WHERE id = w.product_id)
            WHEN 'battery' THEN (SELECT brand FROM batteries WHERE id = w.product_id)
            WHEN 'panel' THEN (SELECT brand FROM panels WHERE id = w.product_id)
            WHEN 'installation_appliance' THEN (SELECT brand FROM installation_appliances WHERE id = w.product_id)
        END as brand,
        CASE w.product_type
            WHEN 'inverter' THEN (SELECT price_usd FROM inverters WHERE id = w.product_id)
            WHEN 'battery' THEN (SELECT price_usd FROM batteries WHERE id = w.product_id)
            WHEN 'panel' THEN (SELECT price_usd FROM panels WHERE id = w.product_id)
            WHEN 'installation_appliance' THEN (SELECT price_usd FROM installation_appliances WHERE id = w.product_id)
        END as base_price,
        (SELECT COUNT(*) FROM dealer_products dp WHERE dp.product_type = w.product_type AND dp.product_id = w.product_id AND dp.is_active = 1 AND dp.stock_status != 'out_of_stock') as dealer_count,
        (SELECT MIN(dp2.dealer_price) FROM dealer_products dp2 WHERE dp2.product_type = w.product_type AND dp2.product_id = w.product_id AND dp2.is_active = 1) as lowest_dealer_price
        FROM watchlist w
        WHERE w.customer_id = ?
        ORDER BY w.created_at DESC";
$stmt = $db->prepare($sql);
$stmt->execute([$customer['id']]);
$items = $stmt->fetchAll();

$cart_count = 0;
foreach ($_SESSION['cart'] ?? [] as $dc) {
    foreach ($dc['items'] ?? [] as $ci) $cart_count += $ci['quantity'];
}


$page_title = 'Watchlist';
$current_page = 'watchlist';
include __DIR__ . '/../includes/header.php';
?>

<style>
    .container { max-width: 800px; margin: 24px auto; padding: 0 20px; }

    .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; }
    .alert-success { background: #DCFCE7; color: #166534; }

    .wl-card {
        background: white; border-radius: 10px; padding: 16px; margin-bottom: 10px;
        border: 2px solid #E2E8F0; display: flex; justify-content: space-between; align-items: center;
        gap: 12px; flex-wrap: wrap; transition: border-color 0.2s;
    }
    .wl-card:hover { border-color: #CBD5E1; }
    .wl-info { flex: 1; min-width: 180px; }
    .wl-brand { font-size: 0.6875rem; font-weight: 600; color: #1565C0; text-transform: uppercase; }
    .wl-name { font-size: 0.9375rem; font-weight: 700; color: #1E293B; margin: 2px 0; }
    .wl-type { font-size: 0.75rem; color: #64748B; }
    .wl-meta { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
    .wl-price { font-weight: 700; color: #059669; font-size: 0.9375rem; }
    .wl-dealers { font-size: 0.75rem; color: #64748B; }
    .wl-lowest { font-size: 0.6875rem; color: #F59E0B; font-weight: 600; }
    .btn-remove {
        padding: 6px 12px; background: #FEE2E2; color: #991B1B; border: none;
        border-radius: 6px; font-size: 0.75rem; font-weight: 600; cursor: pointer;
    }
    .btn-remove:hover { background: #FECACA; }

    .empty-msg { text-align: center; padding: 60px 20px; color: #64748B; }
    .empty-msg a { color: #1565C0; text-decoration: none; font-weight: 600; }
</style>

    <div class="container">
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>

        <p style="font-size:0.8125rem;color:#64748B;margin-bottom:16px;"><?= count($items) ?> item<?= count($items) !== 1 ? 's' : '' ?> in your watchlist</p>

        <?php if (empty($items)): ?>
            <div class="empty-msg">
                <h3>Your watchlist is empty</h3>
                <p>Browse products and add items you're interested in to your watchlist.</p>
                <p style="margin-top:8px;"><a href="/solarglobal/store.php">Find Dealers</a></p>
            </div>
        <?php else: ?>
            <?php foreach ($items as $item): ?>
                <div class="wl-card">
                    <div class="wl-info">
                        <span class="wl-brand"><?= sanitize($item['brand'] ?? '') ?></span>
                        <div class="wl-name"><?= sanitize($item['product_name'] ?? 'Unknown Product') ?></div>
                        <span class="wl-type"><?= ucfirst(str_replace('_', ' ', $item['product_type'])) ?></span>
                    </div>
                    <div class="wl-meta">
                        <div>
                            <div class="wl-price">$<?= number_format($item['base_price'] ?? 0, 0) ?> base</div>
                            <?php if ($item['dealer_count'] > 0): ?>
                                <div class="wl-dealers"><?= $item['dealer_count'] ?> dealer<?= $item['dealer_count'] > 1 ? 's' : '' ?> have this</div>
                                <?php if ($item['lowest_dealer_price']): ?>
                                    <div class="wl-lowest">From $<?= number_format($item['lowest_dealer_price'], 0) ?></div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="wl-dealers">Not available at dealers</div>
                            <?php endif; ?>
                        </div>
                        <form method="POST" style="display:inline;">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="remove">
                            <input type="hidden" name="watchlist_id" value="<?= $item['id'] ?>">
                            <button type="submit" class="btn-remove">&#10005; Remove</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
