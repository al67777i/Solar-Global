<?php
/**
 * Logout Handler
 * Destroys session and redirects to login
 */
session_start();
session_unset();
session_destroy();

// Determine base path dynamically (works on both localhost and production)
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
header('Location: ' . $basePath . '/login.php');
exit();
