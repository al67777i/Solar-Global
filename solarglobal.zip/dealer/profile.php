<?php
/**
 * Dealer Profile Management
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

set_security_headers();
require_dealer_login();

$dealer = get_dealer_profile();
$db = getDB();
$success = '';
$error = '';

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request.';
    } else {
        $action = $_POST['action'] ?? 'update_profile';

        if ($action === 'update_profile') {
            $business_name = trim($_POST['business_name'] ?? '');
            $owner_name = trim($_POST['owner_name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $store_description = trim($_POST['store_description'] ?? '');
            $address = trim($_POST['address'] ?? '');

            if (empty($business_name) || empty($owner_name)) {
                $error = 'Business name and owner name are required.';
            } else {
                $stmt = $db->prepare("
                    UPDATE dealers SET business_name = ?, owner_name = ?, phone = ?,
                    store_description = ?, address = ? WHERE id = ?
                ");
                $stmt->execute([$business_name, $owner_name, $phone, $store_description, $address, $dealer['id']]);

                // Update session
                $_SESSION['dealer_business_name'] = $business_name;
                $_SESSION['dealer_owner_name'] = $owner_name;
                $success = 'Profile updated successfully!';
                $dealer = get_dealer_profile(); // Refresh
            }
        } elseif ($action === 'change_password') {
            $current_pw = $_POST['current_password'] ?? '';
            $new_pw = $_POST['new_password'] ?? '';
            $confirm_pw = $_POST['confirm_password'] ?? '';

            // Verify current password
            $stmt = $db->prepare("SELECT password_hash FROM dealers WHERE id = ?");
            $stmt->execute([$dealer['id']]);
            $row = $stmt->fetch();

            if (!password_verify($current_pw, $row['password_hash'])) {
                $error = 'Current password is incorrect.';
            } elseif (strlen($new_pw) < 8) {
                $error = 'New password must be at least 8 characters.';
            } elseif (!preg_match('/[A-Z]/', $new_pw)) {
                $error = 'New password must contain at least one uppercase letter.';
            } elseif (!preg_match('/[0-9]/', $new_pw)) {
                $error = 'New password must contain at least one number.';
            } elseif ($new_pw !== $confirm_pw) {
                $error = 'New passwords do not match.';
            } else {
                $hash = password_hash($new_pw, PASSWORD_BCRYPT);
                $db->prepare("UPDATE dealers SET password_hash = ? WHERE id = ?")->execute([$hash, $dealer['id']]);
                $success = 'Password changed successfully!';
            }
        } elseif ($action === 'update_logo') {
            if (isset($_FILES['store_logo']) && $_FILES['store_logo']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['store_logo'];
                $allowed = ['image/jpeg', 'image/png', 'image/webp'];
                if (!in_array($file['type'], $allowed)) {
                    $error = 'Logo must be JPG, PNG, or WebP.';
                } elseif ($file['size'] > 2 * 1024 * 1024) {
                    $error = 'Logo must be under 2MB.';
                } else {
                    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $filename = 'dealer_logo_' . $dealer['id'] . '_' . time() . '.' . $ext;
                    $upload_dir = __DIR__ . '/../uploads/dealers/logos/';
                    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

                    // Delete old logo
                    if ($dealer['logo_path'] && file_exists(__DIR__ . '/../' . $dealer['logo_path'])) {
                        @unlink(__DIR__ . '/../' . $dealer['logo_path']);
                    }

                    if (move_uploaded_file($file['tmp_name'], $upload_dir . $filename)) {
                        $logo_path = 'uploads/dealers/logos/' . $filename;
                        $db->prepare("UPDATE dealers SET logo_path = ? WHERE id = ?")->execute([$logo_path, $dealer['id']]);
                        $_SESSION['dealer_logo'] = $logo_path;
                        $success = 'Logo updated!';
                        $dealer = get_dealer_profile();
                    } else {
                        $error = 'Failed to upload logo.';
                    }
                }
            } else {
                $error = 'Please select a logo file.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }

        .container { max-width: 800px; margin: 0 auto; padding: 0; }

        .card {
            background: white; border-radius: 14px; padding: 32px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0;
            margin-bottom: 24px;
        }
        .card h2 {
            font-size: 1.125rem; font-weight: 700; color: #0D3B6E;
            margin-bottom: 20px; padding-bottom: 12px; border-bottom: 2px solid #F1F5F9;
        }

        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media (max-width: 600px) { .form-row { grid-template-columns: 1fr; } }

        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; font-size: 0.875rem; font-weight: 600; color: #334155; margin-bottom: 6px; }
        .form-group input, .form-group textarea {
            width: 100%; padding: 11px 14px; border: 2px solid #E2E8F0;
            border-radius: 8px; font-size: 0.9375rem; font-family: inherit; background: #F8FAFC;
        }
        .form-group input:focus, .form-group textarea:focus {
            outline: none; border-color: #1565C0; background: white;
        }
        .form-group textarea { resize: vertical; min-height: 80px; }

        .btn {
            padding: 12px 28px; border: none; border-radius: 8px;
            font-size: 0.9375rem; font-weight: 600; cursor: pointer; transition: all 0.2s;
        }
        .btn-primary { background: #1565C0; color: white; }
        .btn-primary:hover { background: #0D3B6E; }

        .alert {
            padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;
            font-size: 0.875rem; font-weight: 500;
        }
        .alert-success { background: #DCFCE7; color: #166534; border-left: 4px solid #16A34A; }
        .alert-error { background: #FEF2F2; color: #991B1B; border-left: 4px solid #DC2626; }

        .logo-section { display: flex; align-items: center; gap: 20px; }
        .current-logo {
            width: 80px; height: 80px; border-radius: 12px; background: #F1F5F9;
            display: flex; align-items: center; justify-content: center;
            font-size: 2rem; color: #0D3B6E; overflow: hidden; border: 2px solid #E2E8F0;
        }
        .current-logo img { width: 100%; height: 100%; object-fit: cover; }
    </style>
</head>
<body>
    <?php $current_dealer_page = 'profile'; include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="dlr-main-content">
        <div class="dlr-page-header">
            <div class="dlr-page-header-left">
                <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
                <h1>&#128100; My Profile</h1>
            </div>
            <div></div>
        </div>

        <div class="container">
        <?php if ($success): ?>
            <div class="alert alert-success"><?= sanitize($success) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error"><?= sanitize($error) ?></div>
        <?php endif; ?>

        <!-- Store Logo -->
        <div class="card">
            <h2>&#128247; Store Logo</h2>
            <form method="POST" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="update_logo">
                <div class="logo-section">
                    <div class="current-logo">
                        <?php if ($dealer['logo_path']): ?>
                            <img src="/solarglobal/<?= sanitize($dealer['logo_path']) ?>" alt="Logo">
                        <?php else: ?>
                            <?= strtoupper(substr($dealer['business_name'], 0, 1)) ?>
                        <?php endif; ?>
                    </div>
                    <div>
                        <input type="file" name="store_logo" accept="image/jpeg,image/png,image/webp" style="margin-bottom:8px">
                        <div style="font-size:0.8125rem;color:#64748B">JPG, PNG, WebP. Max 2MB.</div>
                        <button type="submit" class="btn btn-primary" style="margin-top:8px">Upload Logo</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Profile Info -->
        <div class="card">
            <h2>&#127970; Business Information</h2>
            <form method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="update_profile">

                <div class="form-row">
                    <div class="form-group">
                        <label>Business Name *</label>
                        <input type="text" name="business_name" value="<?= sanitize($dealer['business_name']) ?>" required maxlength="200">
                    </div>
                    <div class="form-group">
                        <label>Owner Name *</label>
                        <input type="text" name="owner_name" value="<?= sanitize($dealer['owner_name']) ?>" required maxlength="150">
                    </div>
                </div>

                <div class="form-group">
                    <label>Phone</label>
                    <input type="tel" name="phone" value="<?= sanitize($dealer['phone'] ?? '') ?>" maxlength="30">
                </div>

                <div class="form-group">
                    <label>Store Address</label>
                    <input type="text" name="address" value="<?= sanitize($dealer['address'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label>Store Description</label>
                    <textarea name="store_description" maxlength="500"><?= sanitize($dealer['store_description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Email (cannot be changed)</label>
                    <input type="email" value="<?= sanitize($dealer['email']) ?>" disabled style="background:#F1F5F9">
                </div>

                <button type="submit" class="btn btn-primary">Save Changes</button>
            </form>
        </div>

        <!-- Change Password -->
        <div class="card">
            <h2>&#128274; Change Password</h2>
            <form method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="change_password">

                <div class="form-group">
                    <label>Current Password</label>
                    <input type="password" name="current_password" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" required minlength="8" placeholder="Min 8 chars, 1 uppercase, 1 number">
                    </div>
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" required minlength="8">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Change Password</button>
            </form>
        </div>
        </div>
    </main>
</body>
</html>
