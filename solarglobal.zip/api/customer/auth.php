<?php
/**
 * Customer Auth API
 * Endpoints: google_login, send_otp, verify_otp, check_session, logout
 */
session_start();
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/csrf.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/customer_auth.php';

header('Content-Type: application/json; charset=utf-8');

// Rate limiting: 10 auth requests per minute (stricter for auth)
if (!rate_limit('api_customer_auth', 10, 60)) {
    respond_rate_limited('Too many authentication attempts. Please wait a minute.');
}

$db = getDB();
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    case 'google_login':
        $id_token = $_POST['google_token'] ?? '';
        $google_user = verify_google_token($id_token);

        if (!$google_user || empty($google_user['email'])) {
            respond_json(['success' => false, 'error' => 'Invalid Google token.'], 400);
        }

        // Find or create
        $stmt = $db->prepare("SELECT * FROM customers WHERE google_id = ? OR email = ? LIMIT 1");
        $stmt->execute([$google_user['google_id'], $google_user['email']]);
        $customer = $stmt->fetch();

        if ($customer && !$customer['is_active']) {
            respond_json(['success' => false, 'error' => 'Account deactivated.'], 403);
        }

        if ($customer) {
            $db->prepare("UPDATE customers SET google_id = ?, avatar_url = ?, email_verified = 1 WHERE id = ?")
               ->execute([$google_user['google_id'], $google_user['avatar_url'], $customer['id']]);
        } else {
            $db->prepare("INSERT INTO customers (name, email, google_id, avatar_url, email_verified, is_active) VALUES (?, ?, ?, ?, 1, 1)")
               ->execute([$google_user['name'], $google_user['email'], $google_user['google_id'], $google_user['avatar_url']]);
            $stmt = $db->prepare("SELECT * FROM customers WHERE id = ?");
            $stmt->execute([$db->lastInsertId()]);
            $customer = $stmt->fetch();
        }

        customer_login($customer);
        respond_json(['success' => true, 'customer' => get_customer_session()]);
        break;

    case 'send_otp':
        $email = strtolower(trim($_POST['email'] ?? ''));
        $name = trim($_POST['name'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            respond_json(['success' => false, 'error' => 'Invalid email.'], 400);
        }

        $stmt = $db->prepare("SELECT id, name, is_active FROM customers WHERE email = ?");
        $stmt->execute([$email]);
        $customer = $stmt->fetch();

        if ($customer && !$customer['is_active']) {
            respond_json(['success' => false, 'error' => 'Account deactivated.'], 403);
        }

        $otp = generate_otp();
        $expires = date('Y-m-d H:i:s', time() + 600);

        if ($customer) {
            $db->prepare("UPDATE customers SET otp_code = ?, otp_expires_at = ? WHERE id = ?")
               ->execute([$otp, $expires, $customer['id']]);
        } else {
            $db->prepare("INSERT INTO customers (name, email, otp_code, otp_expires_at, is_active) VALUES (?, ?, ?, ?, 1)")
               ->execute([$name ?: explode('@', $email)[0], $email, $otp, $expires]);
        }

        $sent = send_otp_email($email, $otp, $name ?: ($customer['name'] ?? ''));
        $_SESSION['otp_email'] = $email;

        $response = ['success' => true, 'message' => 'OTP sent.'];
        // Dev OTP — only when SOLARGLOBAL_DEV env is explicitly set
        if (getenv('SOLARGLOBAL_DEV') === 'true') {
            $response['dev_otp'] = $otp;
        }
        respond_json($response);
        break;

    case 'verify_otp':
        $email = $_SESSION['otp_email'] ?? strtolower(trim($_POST['email'] ?? ''));
        $code = trim($_POST['otp_code'] ?? '');

        if (empty($email) || empty($code)) {
            respond_json(['success' => false, 'error' => 'Email and code required.'], 400);
        }

        $stmt = $db->prepare("SELECT * FROM customers WHERE email = ? AND otp_code = ? AND otp_expires_at > NOW() AND is_active = 1");
        $stmt->execute([$email, $code]);
        $customer = $stmt->fetch();

        if (!$customer) {
            respond_json(['success' => false, 'error' => 'Invalid or expired code.'], 401);
        }

        $db->prepare("UPDATE customers SET otp_code = NULL, otp_expires_at = NULL, email_verified = 1 WHERE id = ?")
           ->execute([$customer['id']]);

        customer_login($customer);
        unset($_SESSION['otp_email']);

        respond_json(['success' => true, 'customer' => get_customer_session()]);
        break;

    case 'check_session':
        if (is_customer_logged_in()) {
            respond_json(['logged_in' => true, 'customer' => get_customer_session()]);
        } else {
            respond_json(['logged_in' => false]);
        }
        break;

    case 'logout':
        customer_logout();
        respond_json(['success' => true]);
        break;

    default:
        respond_json(['error' => 'Invalid action.'], 400);
}
