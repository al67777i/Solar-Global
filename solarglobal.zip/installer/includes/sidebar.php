<?php
if (!function_exists('get_system_setting')) {
    require_once __DIR__ . '/../../includes/helpers.php';
}
/**
 * Installer Sidebar Navigation
 * Include this in all installer panel pages.
 *
 * Required variables before including:
 *   $installer — from get_installer_profile()
 *   $current_installer_page — string like 'dashboard', 'orders', 'portfolio', 'reviews', 'notifications', 'profile', 'subscription'
 */
$current_installer_page = $current_installer_page ?? '';

// Notification count
$inst_notif_count = 0;
if (isset($installer['id'])) {
    require_once __DIR__ . '/../../includes/notification_helpers.php';
    $inst_notif_count = get_unread_notification_count('installer', (int)$installer['id']);
}

// Pending orders count
$inst_pending_orders = 0;
if (isset($installer['id'])) {
    try {
        $__db = getDB();
        $__stmt = $__db->prepare("SELECT COUNT(*) FROM installer_orders WHERE installer_id = ? AND status = 'requested'");
        $__stmt->execute([$installer['id']]);
        $inst_pending_orders = (int)$__stmt->fetchColumn();
    } catch (Exception $e) {}
}

// Portfolio count
$inst_portfolio_count = 0;
if (function_exists('get_installer_portfolio_count')) {
    try { $inst_portfolio_count = get_installer_portfolio_count(); } catch (Exception $e) {}
}
?>

<!-- Installer Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h2>&#9889; <?= get_system_setting('site_name', 'SolarGlobal') ?></h2>
        <p>Installer Portal</p>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section">
            <div class="nav-section-title">Main</div>
            <a href="dashboard.php" class="nav-item <?= $current_installer_page === 'dashboard' ? 'active' : '' ?>">
                <span class="icon">&#127968;</span> Dashboard
            </a>
            <a href="notifications.php" class="nav-item <?= $current_installer_page === 'notifications' ? 'active' : '' ?>">
                <span class="icon">&#128276;</span> Notifications
                <?php if ($inst_notif_count > 0): ?>
                    <span class="badge"><?= $inst_notif_count ?></span>
                <?php endif; ?>
            </a>
            <a href="orders.php" class="nav-item <?= $current_installer_page === 'orders' ? 'active' : '' ?>">
                <span class="icon">&#128203;</span> Orders
                <?php if ($inst_pending_orders > 0): ?>
                    <span class="badge"><?= $inst_pending_orders ?></span>
                <?php endif; ?>
            </a>
            <a href="portfolio.php" class="nav-item <?= $current_installer_page === 'portfolio' ? 'active' : '' ?>">
                <span class="icon">&#128247;</span> Portfolio
                <?php if ($inst_portfolio_count > 0): ?>
                    <span class="badge" style="background:#D97706"><?= $inst_portfolio_count ?></span>
                <?php endif; ?>
            </a>
            <a href="reviews.php" class="nav-item <?= $current_installer_page === 'reviews' ? 'active' : '' ?>">
                <span class="icon">&#11088;</span> Reviews
            </a>
        </div>

        <div class="nav-section">
            <div class="nav-section-title">Account</div>
            <a href="subscription.php" class="nav-item <?= $current_installer_page === 'subscription' ? 'active' : '' ?>">
                <span class="icon">&#128179;</span> Subscription
            </a>
            <a href="profile.php" class="nav-item <?= $current_installer_page === 'profile' ? 'active' : '' ?>">
                <span class="icon">&#128100;</span> My Profile
            </a>
            <a href="/solarglobal/index.php" class="nav-item">
                <span class="icon">&#127760;</span> View Website
            </a>
            <a href="logout.php" class="nav-item">
                <span class="icon">&#128682;</span> Logout
            </a>
        </div>
    </nav>

    <div class="sidebar-footer">
        <div class="installer-info">
            <div class="installer-avatar">
                <?php if (!empty($installer['logo_path'])): ?>
                    <img src="/solarglobal/<?= htmlspecialchars($installer['logo_path']) ?>" alt="Logo">
                <?php else: ?>
                    <?= strtoupper(substr($installer['business_name'] ?? 'I', 0, 1)) ?>
                <?php endif; ?>
            </div>
            <div class="installer-meta">
                <div class="d-name"><?= htmlspecialchars($installer['business_name'] ?? '') ?></div>
                <div class="d-email"><?= htmlspecialchars($installer['email'] ?? '') ?></div>
            </div>
        </div>
    </div>
</aside>

<div class="overlay" id="overlay"></div>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('overlay').classList.toggle('active');
}
document.getElementById('overlay')?.addEventListener('click', toggleSidebar);
</script>
