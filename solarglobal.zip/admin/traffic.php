<?php
/**
 * Traffic Analytics - Advanced Admin Panel
 * Bot detection, advanced charts, real-time monitoring
 */
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/helpers.php';

set_security_headers();
$db = getDB();

// ── Bot Detection Patterns ──
$botPatterns = [
    'bot', 'crawler', 'spider', 'slurp', 'googlebot', 'bingbot', 'yandex',
    'baidu', 'facebook', 'twitter', 'semrush', 'ahrefs', 'mj12bot', 'dotbot',
    'petalbot', 'bytespider', 'gptbot', 'claudebot', 'chatgpt', 'applebot'
];
$botRegex = implode('|', $botPatterns);
$botSqlCondition = "(LOWER(user_agent) REGEXP '" . $botRegex . "' OR device_type = 'bot')";
$humanSqlCondition = "(NOT (LOWER(user_agent) REGEXP '" . $botRegex . "') AND (device_type != 'bot' OR device_type IS NULL))";

// ── Filters ──
$filter = $_GET['filter'] ?? 'all';
if (!in_array($filter, ['all', 'human', 'bot'])) $filter = 'all';

$range = $_GET['range'] ?? '7';
$validRanges = ['1','7','30','90','365'];

// Custom date range
$customFrom = $_GET['from'] ?? '';
$customTo = $_GET['to'] ?? '';
$useCustom = false;

if ($customFrom && $customTo) {
    $useCustom = true;
    $dateFrom = date('Y-m-d', strtotime($customFrom));
    $dateTo = date('Y-m-d', strtotime($customTo));
    $dateCondition = "visit_date BETWEEN '$dateFrom' AND '$dateTo 23:59:59'";
    $prevDays = (strtotime($dateTo) - strtotime($dateFrom)) / 86400 + 1;
    $prevDateFrom = date('Y-m-d', strtotime($dateFrom . " -$prevDays days"));
    $prevDateTo = date('Y-m-d', strtotime($dateFrom . ' -1 day'));
    $prevDateCondition = "visit_date BETWEEN '$prevDateFrom' AND '$prevDateTo 23:59:59'";
    $range = 'custom';
} else {
    if (!in_array($range, $validRanges)) $range = '7';
    $dateCondition = "visit_date >= DATE_SUB(NOW(), INTERVAL $range DAY)";
    $prevDateCondition = "visit_date >= DATE_SUB(NOW(), INTERVAL " . ($range * 2) . " DAY) AND visit_date < DATE_SUB(NOW(), INTERVAL $range DAY)";
}

// Build filter condition
$filterCondition = '';
if ($filter === 'human') {
    $filterCondition = "AND $humanSqlCondition";
} elseif ($filter === 'bot') {
    $filterCondition = "AND $botSqlCondition";
}

// ── Bot Traffic Percentage (always all traffic) ──
$botTotal = $db->query("SELECT COUNT(*) as c FROM visitor_stats WHERE $dateCondition AND $botSqlCondition")->fetch();
$allTotal = $db->query("SELECT COUNT(*) as c FROM visitor_stats WHERE $dateCondition")->fetch();
$botPercent = $allTotal['c'] > 0 ? round(($botTotal['c'] / $allTotal['c']) * 100, 1) : 0;

// ── Overview Stats (current period) ──
$currentStats = $db->query("
    SELECT COUNT(*) as views,
           COUNT(DISTINCT ip_address) as visitors,
           COUNT(DISTINCT session_id) as sessions
    FROM visitor_stats WHERE $dateCondition $filterCondition
")->fetch();

// Unique human visitors
$humanVisitors = $db->query("
    SELECT COUNT(DISTINCT ip_address) as c
    FROM visitor_stats WHERE $dateCondition AND $humanSqlCondition
")->fetch();

// Bot requests
$botRequests = $db->query("
    SELECT COUNT(*) as c
    FROM visitor_stats WHERE $dateCondition AND $botSqlCondition
")->fetch();

// Avg pages per session
$avgPagesPerSession = 0;
if ($currentStats['sessions'] > 0) {
    $avgPagesPerSession = round($currentStats['views'] / $currentStats['sessions'], 1);
}

// ── Previous Period Stats (for trend arrows) ──
$prevStats = $db->query("
    SELECT COUNT(*) as views,
           COUNT(DISTINCT ip_address) as visitors,
           COUNT(DISTINCT session_id) as sessions
    FROM visitor_stats WHERE $prevDateCondition $filterCondition
")->fetch();

$prevHumanVisitors = $db->query("
    SELECT COUNT(DISTINCT ip_address) as c
    FROM visitor_stats WHERE $prevDateCondition AND $humanSqlCondition
")->fetch();

$prevBotRequests = $db->query("
    SELECT COUNT(*) as c
    FROM visitor_stats WHERE $prevDateCondition AND $botSqlCondition
")->fetch();

$prevAvgPages = ($prevStats['sessions'] > 0) ? round($prevStats['views'] / $prevStats['sessions'], 1) : 0;

// Trend calculation helper
function calcTrend($current, $previous) {
    if ($previous == 0) return $current > 0 ? 100 : 0;
    return round((($current - $previous) / $previous) * 100, 1);
}

$trendViews = calcTrend($currentStats['views'], $prevStats['views']);
$trendVisitors = calcTrend($humanVisitors['c'], $prevHumanVisitors['c']);
$trendBots = calcTrend($botRequests['c'], $prevBotRequests['c']);
$trendAvgPages = calcTrend($avgPagesPerSession, $prevAvgPages);

// ── Daily Traffic (for main chart + stacked bar) ──
$dailyTraffic = $db->query("
    SELECT DATE(visit_date) as day,
           COUNT(*) as page_views,
           COUNT(DISTINCT ip_address) as unique_visitors,
           SUM(CASE WHEN $botSqlCondition THEN 1 ELSE 0 END) as bot_views,
           SUM(CASE WHEN $humanSqlCondition THEN 1 ELSE 0 END) as human_views
    FROM visitor_stats
    WHERE $dateCondition
    GROUP BY DATE(visit_date) ORDER BY day
")->fetchAll();

// ── Hourly Distribution ──
$hourlyHuman = $db->query("
    SELECT HOUR(visited_at) as hour, COUNT(*) as visits
    FROM visitor_stats
    WHERE $dateCondition AND $humanSqlCondition
    GROUP BY HOUR(visited_at) ORDER BY hour
")->fetchAll();

$hourlyBot = $db->query("
    SELECT HOUR(visited_at) as hour, COUNT(*) as visits
    FROM visitor_stats
    WHERE $dateCondition AND $botSqlCondition
    GROUP BY HOUR(visited_at) ORDER BY hour
")->fetchAll();

// ── Browser Distribution ──
$browsers = $db->query("
    SELECT browser, COUNT(*) as count
    FROM visitor_stats
    WHERE $dateCondition $filterCondition AND browser IS NOT NULL AND browser != ''
    GROUP BY browser ORDER BY count DESC LIMIT 8
")->fetchAll();

// ── Device Distribution ──
$devices = $db->query("
    SELECT
        CASE
            WHEN $botSqlCondition THEN 'Bot'
            WHEN device_type = 'mobile' THEN 'Mobile'
            WHEN device_type = 'tablet' THEN 'Tablet'
            ELSE 'Desktop'
        END as dtype,
        COUNT(*) as count
    FROM visitor_stats
    WHERE $dateCondition
    GROUP BY dtype ORDER BY count DESC
")->fetchAll();

// ── Top Pages ──
$topPages = $db->query("
    SELECT page_url, COUNT(*) as views, COUNT(DISTINCT ip_address) as visitors
    FROM visitor_stats
    WHERE $dateCondition $filterCondition
    GROUP BY page_url ORDER BY views DESC LIMIT 10
")->fetchAll();

// ── Top Referrers ──
$topReferrers = $db->query("
    SELECT referer, COUNT(*) as visits
    FROM visitor_stats
    WHERE $dateCondition $filterCondition AND referer IS NOT NULL AND referer != ''
    GROUP BY referer ORDER BY visits DESC LIMIT 15
")->fetchAll();

// Direct traffic count
$directTraffic = $db->query("
    SELECT COUNT(*) as c
    FROM visitor_stats
    WHERE $dateCondition $filterCondition AND (referer IS NULL OR referer = '')
")->fetch();

// ── Top IPs ──
$topIPs = $db->query("
    SELECT ip_address,
           COUNT(*) as visits,
           MAX(visited_at) as last_visit,
           SUBSTRING(MAX(user_agent), 1, 80) as ua_snippet,
           MAX(page_url) as top_page,
           MAX(device_type) as device_type,
           SUM(CASE WHEN $botSqlCondition THEN 1 ELSE 0 END) as bot_hits
    FROM visitor_stats
    WHERE $dateCondition
    GROUP BY ip_address ORDER BY visits DESC LIMIT 25
")->fetchAll();

// ── Recent Visitors ──
$recentVisitors = $db->query("
    SELECT ip_address, user_agent, page_url, referer, device_type, browser, os,
           visited_at,
           CASE WHEN $botSqlCondition THEN 1 ELSE 0 END as is_bot
    FROM visitor_stats
    ORDER BY visited_at DESC LIMIT 100
")->fetchAll();

// ── Prepare chart JSON data ──
$chartLabels = array_map(fn($r) => $r['day'], $dailyTraffic);
$chartPageViews = array_map(fn($r) => (int)$r['page_views'], $dailyTraffic);
$chartUniqueVisitors = array_map(fn($r) => (int)$r['unique_visitors'], $dailyTraffic);
$chartBotViews = array_map(fn($r) => (int)$r['bot_views'], $dailyTraffic);
$chartHumanViews = array_map(fn($r) => (int)$r['human_views'], $dailyTraffic);

// Hourly arrays (0-23)
$hourlyHumanArr = array_fill(0, 24, 0);
$hourlyBotArr = array_fill(0, 24, 0);
foreach ($hourlyHuman as $h) $hourlyHumanArr[(int)$h['hour']] = (int)$h['visits'];
foreach ($hourlyBot as $h) $hourlyBotArr[(int)$h['hour']] = (int)$h['visits'];

// Referrer categorization helper
function categorizeReferrer($url) {
    if (empty($url)) return 'Direct';
    $lower = strtolower($url);
    $searchEngines = ['google', 'bing', 'yahoo', 'duckduckgo', 'baidu', 'yandex', 'ecosia'];
    $socialMedia = ['facebook', 'twitter', 'instagram', 'linkedin', 'reddit', 'youtube', 'tiktok', 'pinterest', 't.co'];
    foreach ($searchEngines as $se) { if (strpos($lower, $se) !== false) return 'Search'; }
    foreach ($socialMedia as $sm) { if (strpos($lower, $sm) !== false) return 'Social'; }
    return 'Referral';
}

function getDomain($url) {
    $parsed = parse_url($url);
    return $parsed['host'] ?? $url;
}

// Build URL with current filters
function buildUrl($params = []) {
    $current = $_GET;
    $merged = array_merge($current, $params);
    return '?' . http_build_query($merged);
}

$pageTitle = "Traffic Analytics";
include 'includes/header.php';
?>

<style>
/* ── Traffic Analytics Styles ── */
.traffic-top-bar {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
}
.filter-group {
    display: flex;
    gap: 0;
    border-radius: 8px;
    overflow: hidden;
    border: 1px solid #CBD5E1;
}
.filter-btn {
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 500;
    background: white;
    color: #475569;
    border: none;
    cursor: pointer;
    text-decoration: none;
    transition: all 0.2s;
    font-family: inherit;
}
.filter-btn:hover { background: #F1F5F9; }
.filter-btn.active { background: #1E40AF; color: white; }
.filter-btn.active-human { background: #059669; color: white; }
.filter-btn.active-bot { background: #DC2626; color: white; }

.bot-indicator {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 14px;
}
.bot-indicator.low { background: #D1FAE5; color: #065F46; }
.bot-indicator.medium { background: #FEF3C7; color: #92400E; }
.bot-indicator.high { background: #FEE2E2; color: #991B1B; }

.auto-refresh-toggle {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    color: #64748B;
}
.auto-refresh-toggle label {
    display: flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
}
.toggle-switch {
    width: 36px;
    height: 20px;
    background: #CBD5E1;
    border-radius: 10px;
    position: relative;
    cursor: pointer;
    transition: background 0.3s;
}
.toggle-switch.active { background: #3B82F6; }
.toggle-switch::after {
    content: '';
    width: 16px;
    height: 16px;
    background: white;
    border-radius: 50%;
    position: absolute;
    top: 2px;
    left: 2px;
    transition: transform 0.3s;
    box-shadow: 0 1px 3px rgba(0,0,0,0.2);
}
.toggle-switch.active::after { transform: translateX(16px); }

.last-updated {
    font-size: 12px;
    color: #94A3B8;
}
.last-updated .pulse {
    display: inline-block;
    width: 6px;
    height: 6px;
    background: #10B981;
    border-radius: 50%;
    margin-right: 4px;
    animation: pulse-anim 2s infinite;
}

@keyframes pulse-anim {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.5; transform: scale(1.3); }
}

/* Range selector */
.range-row {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    align-items: center;
    margin-bottom: 20px;
}
.range-tabs {
    display: flex;
    gap: 0;
    border-radius: 8px;
    overflow: hidden;
    border: 1px solid #CBD5E1;
}
.range-tab {
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 500;
    background: white;
    color: #475569;
    border: none;
    cursor: pointer;
    text-decoration: none;
    transition: all 0.2s;
}
.range-tab:hover { background: #F1F5F9; color: #1E293B; }
.range-tab.active { background: #1E40AF; color: white; }

.custom-range {
    display: flex;
    align-items: center;
    gap: 8px;
}
.custom-range input[type="date"] {
    padding: 7px 12px;
    border: 1px solid #CBD5E1;
    border-radius: 6px;
    font-size: 13px;
    font-family: inherit;
    color: #1E293B;
    background: white;
}
.custom-range .btn-sm { padding: 7px 14px; }

/* Stat cards with trend */
.stat-card .trend {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    font-size: 12px;
    font-weight: 600;
    margin-top: 4px;
    padding: 2px 8px;
    border-radius: 12px;
}
.trend-up { background: #D1FAE5; color: #065F46; }
.trend-down { background: #FEE2E2; color: #991B1B; }
.trend-flat { background: #F1F5F9; color: #64748B; }
.stat-card.stat-red { border-left: 4px solid #EF4444; }

.stat-card.today-pulse {
    animation: card-pulse 3s ease-in-out infinite;
}
@keyframes card-pulse {
    0%, 100% { box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
    50% { box-shadow: 0 4px 20px rgba(59,130,246,0.15); }
}

/* Chart containers */
.chart-container {
    position: relative;
    padding: 16px 0;
}
.chart-large { min-height: 300px; }

/* IP table enhancements */
.ip-hot { background: #FEF2F2 !important; }
.ip-hot td { color: #991B1B; }
.badge-bot { background: #FEE2E2; color: #991B1B; font-size: 11px; }
.badge-human { background: #D1FAE5; color: #065F46; font-size: 11px; }
.btn-block-ip {
    padding: 3px 8px;
    font-size: 11px;
    background: #FEF2F2;
    color: #DC2626;
    border: 1px solid #FECACA;
    border-radius: 4px;
    cursor: pointer;
    font-family: inherit;
    transition: all 0.2s;
}
.btn-block-ip:hover { background: #DC2626; color: white; }

/* Referrer rows */
.referrer-row {
    display: flex;
    align-items: center;
    gap: 8px;
}
.referrer-favicon {
    width: 16px;
    height: 16px;
    border-radius: 2px;
}
.source-badge {
    display: inline-block;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.source-search { background: #DBEAFE; color: #1D4ED8; }
.source-social { background: #FCE7F3; color: #BE185D; }
.source-referral { background: #FEF3C7; color: #92400E; }
.source-direct { background: #E0E7FF; color: #4338CA; }

/* Recent visitors */
.visitor-row-human { border-left: 3px solid #10B981; }
.visitor-row-bot { border-left: 3px solid #EF4444; background: #FFF5F5; }
.bot-badge {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
}

/* Scrollable table wrapper */
.table-scroll {
    max-height: 600px;
    overflow-y: auto;
    border-radius: 8px;
    border: 1px solid #E2E8F0;
}
.table-scroll::-webkit-scrollbar { width: 6px; }
.table-scroll::-webkit-scrollbar-track { background: #F8FAFC; }
.table-scroll::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 3px; }

/* Grid layouts */
.grid-3-charts {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 20px;
}

@media (max-width: 1024px) {
    .grid-3-charts { grid-template-columns: 1fr; }
    .traffic-top-bar { flex-direction: column; align-items: flex-start; }
    .range-row { flex-direction: column; align-items: flex-start; }
}
@media (max-width: 768px) {
    .filter-group { width: 100%; }
    .filter-btn { flex: 1; text-align: center; }
}
</style>

<!-- Top Controls Bar -->
<div class="traffic-top-bar">
    <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap;">
        <!-- Bot Filter Toggle -->
        <div class="filter-group">
            <a href="<?= buildUrl(['filter' => 'all']) ?>" class="filter-btn <?= $filter === 'all' ? 'active' : '' ?>">All Traffic</a>
            <a href="<?= buildUrl(['filter' => 'human']) ?>" class="filter-btn <?= $filter === 'human' ? 'active-human' : '' ?>">Human Only</a>
            <a href="<?= buildUrl(['filter' => 'bot']) ?>" class="filter-btn <?= $filter === 'bot' ? 'active-bot' : '' ?>">Bots Only</a>
        </div>

        <!-- Bot Traffic Indicator -->
        <div class="bot-indicator <?= $botPercent > 50 ? 'high' : ($botPercent > 25 ? 'medium' : 'low') ?>">
            Bot Traffic: <?= $botPercent ?>% of total
        </div>
    </div>

    <div style="display:flex; gap:12px; align-items:center;">
        <div class="auto-refresh-toggle">
            <label>
                <div class="toggle-switch" id="autoRefreshToggle" onclick="toggleAutoRefresh()"></div>
                <span>Auto-refresh</span>
            </label>
        </div>
        <div class="last-updated">
            <span class="pulse" id="pulseDot"></span>
            <span id="lastUpdated">Just now</span>
        </div>
    </div>
</div>

<!-- Date Range Selector -->
<div class="range-row">
    <div class="range-tabs">
        <a href="<?= buildUrl(['range' => '1', 'from' => '', 'to' => '']) ?>" class="range-tab <?= $range === '1' ? 'active' : '' ?>">Today</a>
        <a href="<?= buildUrl(['range' => '7', 'from' => '', 'to' => '']) ?>" class="range-tab <?= $range === '7' ? 'active' : '' ?>">7 Days</a>
        <a href="<?= buildUrl(['range' => '30', 'from' => '', 'to' => '']) ?>" class="range-tab <?= $range === '30' ? 'active' : '' ?>">30 Days</a>
        <a href="<?= buildUrl(['range' => '90', 'from' => '', 'to' => '']) ?>" class="range-tab <?= $range === '90' ? 'active' : '' ?>">90 Days</a>
        <a href="<?= buildUrl(['range' => '365', 'from' => '', 'to' => '']) ?>" class="range-tab <?= $range === '365' ? 'active' : '' ?>">1 Year</a>
    </div>
    <form class="custom-range" method="GET" action="">
        <input type="hidden" name="filter" value="<?= $filter ?>">
        <input type="date" name="from" value="<?= htmlspecialchars($customFrom) ?>" title="From date">
        <span style="color:#94A3B8;">to</span>
        <input type="date" name="to" value="<?= htmlspecialchars($customTo) ?>" title="To date">
        <button type="submit" class="btn btn-primary btn-sm">Apply</button>
    </form>
</div>

<!-- Overview Stats Row -->
<div class="dashboard-grid grid-4">
    <div class="stat-card stat-blue <?= $range === '1' ? 'today-pulse' : '' ?>">
        <div class="stat-icon">&#128065;</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($currentStats['views']) ?></div>
            <div class="stat-label">Page Views</div>
            <?php $t = $trendViews; ?>
            <div class="trend <?= $t > 0 ? 'trend-up' : ($t < 0 ? 'trend-down' : 'trend-flat') ?>">
                <?= $t > 0 ? '&#9650;' : ($t < 0 ? '&#9660;' : '&#8722;') ?> <?= abs($t) ?>%
            </div>
        </div>
    </div>
    <div class="stat-card stat-green <?= $range === '1' ? 'today-pulse' : '' ?>">
        <div class="stat-icon">&#128100;</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($humanVisitors['c']) ?></div>
            <div class="stat-label">Unique Visitors (Human)</div>
            <?php $t = $trendVisitors; ?>
            <div class="trend <?= $t > 0 ? 'trend-up' : ($t < 0 ? 'trend-down' : 'trend-flat') ?>">
                <?= $t > 0 ? '&#9650;' : ($t < 0 ? '&#9660;' : '&#8722;') ?> <?= abs($t) ?>%
            </div>
        </div>
    </div>
    <div class="stat-card stat-red <?= $range === '1' ? 'today-pulse' : '' ?>">
        <div class="stat-icon">&#129302;</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($botRequests['c']) ?></div>
            <div class="stat-label">Bot Requests (<?= $botPercent ?>%)</div>
            <?php $t = $trendBots; ?>
            <div class="trend <?= $t > 0 ? 'trend-down' : ($t < 0 ? 'trend-up' : 'trend-flat') ?>">
                <?= $t > 0 ? '&#9650;' : ($t < 0 ? '&#9660;' : '&#8722;') ?> <?= abs($t) ?>%
            </div>
        </div>
    </div>
    <div class="stat-card stat-purple <?= $range === '1' ? 'today-pulse' : '' ?>">
        <div class="stat-icon">&#128196;</div>
        <div class="stat-content">
            <div class="stat-value"><?= $avgPagesPerSession ?></div>
            <div class="stat-label">Avg Pages/Session</div>
            <?php $t = $trendAvgPages; ?>
            <div class="trend <?= $t > 0 ? 'trend-up' : ($t < 0 ? 'trend-down' : 'trend-flat') ?>">
                <?= $t > 0 ? '&#9650;' : ($t < 0 ? '&#9660;' : '&#8722;') ?> <?= abs($t) ?>%
            </div>
        </div>
    </div>
</div>

<!-- Main Traffic Chart (Area with gradient) -->
<div class="card">
    <h2>Traffic Overview</h2>
    <div class="chart-container chart-large">
        <canvas id="mainTrafficChart"></canvas>
    </div>
</div>

<!-- Bot vs Human Stacked + Hourly Heatmap -->
<div class="grid-2">
    <div class="card">
        <h2>Bot vs Human Traffic</h2>
        <div class="chart-container">
            <canvas id="stackedBarChart"></canvas>
        </div>
    </div>
    <div class="card">
        <h2>Traffic by Hour of Day</h2>
        <div class="chart-container">
            <canvas id="hourlyChart"></canvas>
        </div>
    </div>
</div>

<!-- Browser + Device + Top Pages Charts -->
<div class="grid-3-charts">
    <div class="card">
        <h2>Browser Distribution</h2>
        <div class="chart-container">
            <canvas id="browserChart"></canvas>
        </div>
    </div>
    <div class="card">
        <h2>Device Distribution</h2>
        <div class="chart-container">
            <canvas id="deviceChart"></canvas>
        </div>
    </div>
    <div class="card">
        <h2>Top Pages</h2>
        <div class="chart-container">
            <canvas id="topPagesChart"></canvas>
        </div>
    </div>
</div>

<!-- Traffic Sources -->
<div class="grid-2">
    <div class="card">
        <h2>Traffic Sources</h2>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr><th>Source</th><th>Category</th><th>Visits</th></tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="referrer-row">
                                <span>Direct / None</span>
                            </div>
                        </td>
                        <td><span class="source-badge source-direct">Direct</span></td>
                        <td><strong><?= number_format($directTraffic['c']) ?></strong></td>
                    </tr>
                    <?php foreach ($topReferrers as $r):
                        $domain = getDomain($r['referer']);
                        $cat = categorizeReferrer($r['referer']);
                        $catClass = strtolower($cat);
                    ?>
                    <tr>
                        <td>
                            <div class="referrer-row">
                                <img src="https://www.google.com/s2/favicons?domain=<?= urlencode($domain) ?>&sz=16"
                                     alt="" class="referrer-favicon" loading="lazy" onerror="this.style.display='none'">
                                <span title="<?= sanitize($r['referer']) ?>"><?= sanitize(substr($domain, 0, 35)) ?></span>
                            </div>
                        </td>
                        <td><span class="source-badge source-<?= $catClass ?>"><?= $cat ?></span></td>
                        <td><strong><?= number_format($r['visits']) ?></strong></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($topReferrers) && $directTraffic['c'] == 0): ?>
                    <tr><td colspan="3" style="color:#94A3B8; text-align:center; padding:20px;">No referrer data yet</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Top IPs -->
    <div class="card">
        <h2>Top IP Addresses</h2>
        <div class="table-scroll">
            <table class="data-table data-table-sm">
                <thead>
                    <tr>
                        <th>IP Address</th>
                        <th>Visits</th>
                        <th>Type</th>
                        <th>Last Visit</th>
                        <th>Top Page</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($topIPs as $ip):
                        $isBot = $ip['bot_hits'] > ($ip['visits'] / 2);
                        $isHot = $ip['visits'] > 100;
                    ?>
                    <tr class="<?= $isHot ? 'ip-hot' : '' ?>">
                        <td><code><?= sanitize($ip['ip_address']) ?></code></td>
                        <td>
                            <span class="badge <?= $isHot ? 'badge-red' : 'badge-blue' ?>"><?= number_format($ip['visits']) ?></span>
                        </td>
                        <td>
                            <span class="badge <?= $isBot ? 'badge-bot' : 'badge-human' ?>">
                                <?= $isBot ? 'Bot' : 'Human' ?>
                            </span>
                        </td>
                        <td class="text-nowrap"><?= $ip['last_visit'] ? date('M d, H:i', strtotime($ip['last_visit'])) : '-' ?></td>
                        <td class="text-truncate" style="max-width:120px" title="<?= sanitize($ip['top_page'] ?? '') ?>">
                            <?= sanitize(substr(basename($ip['top_page'] ?? '/'), 0, 25)) ?>
                        </td>
                        <td>
                            <button class="btn-block-ip" title="Block IP (placeholder)" onclick="alert('IP blocking is not yet implemented. IP: <?= sanitize($ip['ip_address']) ?>')">
                                Block
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Recent Visitors Log -->
<div class="card">
    <h2>Recent Visitors Log <span style="font-size:13px; font-weight:400; color:#94A3B8;">(Last 100)</span></h2>
    <div class="table-scroll">
        <table class="data-table data-table-sm">
            <thead>
                <tr>
                    <th>Time</th>
                    <th>IP</th>
                    <th>Page</th>
                    <th>Device</th>
                    <th>Browser / OS</th>
                    <th>Bot?</th>
                    <th>Referrer</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentVisitors as $v):
                    $isBot = (int)$v['is_bot'];
                ?>
                <tr class="<?= $isBot ? 'visitor-row-bot' : 'visitor-row-human' ?>">
                    <td class="text-nowrap"><?= $v['visited_at'] ? date('M d H:i:s', strtotime($v['visited_at'])) : '-' ?></td>
                    <td><code style="font-size:12px;"><?= sanitize($v['ip_address']) ?></code></td>
                    <td class="text-truncate" style="max-width:150px" title="<?= sanitize($v['page_url']) ?>">
                        <?= sanitize(substr(basename($v['page_url'] ?? '/'), 0, 30)) ?>
                    </td>
                    <td>
                        <span class="badge badge-<?= $v['device_type'] === 'mobile' ? 'green' : ($v['device_type'] === 'bot' ? 'red' : ($v['device_type'] === 'tablet' ? 'orange' : 'blue')) ?>">
                            <?= ucfirst($v['device_type'] ?? 'desktop') ?>
                        </span>
                    </td>
                    <td style="font-size:12px;"><?= sanitize(($v['browser'] ?? '') . ' / ' . ($v['os'] ?? '')) ?></td>
                    <td>
                        <?php if ($isBot): ?>
                            <span class="bot-badge" style="background:#FEE2E2; color:#991B1B;">Bot</span>
                        <?php else: ?>
                            <span class="bot-badge" style="background:#D1FAE5; color:#065F46;">Human</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-truncate" style="max-width:120px; font-size:12px;">
                        <?= sanitize(substr($v['referer'] ?? '-', 0, 40)) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
// ── Chart Data from PHP ──
const chartLabels = <?= json_encode($chartLabels) ?>;
const chartPageViews = <?= json_encode($chartPageViews) ?>;
const chartUniqueVisitors = <?= json_encode($chartUniqueVisitors) ?>;
const chartBotViews = <?= json_encode($chartBotViews) ?>;
const chartHumanViews = <?= json_encode($chartHumanViews) ?>;
const hourlyHumanData = <?= json_encode(array_values($hourlyHumanArr)) ?>;
const hourlyBotData = <?= json_encode(array_values($hourlyBotArr)) ?>;
const browserLabels = <?= json_encode(array_column($browsers, 'browser')) ?>;
const browserCounts = <?= json_encode(array_map('intval', array_column($browsers, 'count'))) ?>;
const deviceLabels = <?= json_encode(array_column($devices, 'dtype')) ?>;
const deviceCounts = <?= json_encode(array_map('intval', array_column($devices, 'count'))) ?>;
const topPageLabels = <?= json_encode(array_map(fn($p) => substr(basename($p['page_url']), 0, 25) ?: '/', $topPages)) ?>;
const topPageViews = <?= json_encode(array_map('intval', array_column($topPages, 'views'))) ?>;

const fmtDate = d => new Date(d).toLocaleDateString('en', {month:'short', day:'numeric'});

// ── 1. Main Traffic Chart (Area with Gradient) ──
(function() {
    const ctx = document.getElementById('mainTrafficChart').getContext('2d');
    const gradBlue = ctx.createLinearGradient(0, 0, 0, 300);
    gradBlue.addColorStop(0, 'rgba(59,130,246,0.3)');
    gradBlue.addColorStop(1, 'rgba(59,130,246,0.02)');
    const gradGreen = ctx.createLinearGradient(0, 0, 0, 300);
    gradGreen.addColorStop(0, 'rgba(16,185,129,0.25)');
    gradGreen.addColorStop(1, 'rgba(16,185,129,0.02)');

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartLabels.map(fmtDate),
            datasets: [{
                label: 'Page Views',
                data: chartPageViews,
                borderColor: '#3B82F6',
                backgroundColor: gradBlue,
                fill: true,
                tension: 0.4,
                borderWidth: 2,
                pointRadius: chartLabels.length > 30 ? 0 : 3,
                pointHoverRadius: 5
            }, {
                label: 'Unique Visitors',
                data: chartUniqueVisitors,
                borderColor: '#10B981',
                backgroundColor: gradGreen,
                fill: true,
                tension: 0.4,
                borderWidth: 2,
                pointRadius: chartLabels.length > 30 ? 0 : 3,
                pointHoverRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { position: 'top', labels: { usePointStyle: true, padding: 20 } },
                tooltip: {
                    backgroundColor: 'rgba(15,23,42,0.9)',
                    titleFont: { size: 13 },
                    bodyFont: { size: 12 },
                    padding: 12,
                    cornerRadius: 8,
                    callbacks: {
                        label: ctx => `${ctx.dataset.label}: ${ctx.parsed.y.toLocaleString()}`
                    }
                }
            },
            scales: {
                y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' } },
                x: { grid: { display: false } }
            }
        }
    });
})();

// ── 2. Stacked Bot vs Human Bar Chart ──
new Chart(document.getElementById('stackedBarChart'), {
    type: 'bar',
    data: {
        labels: chartLabels.map(fmtDate),
        datasets: [{
            label: 'Human',
            data: chartHumanViews,
            backgroundColor: 'rgba(16,185,129,0.7)',
            borderRadius: 2
        }, {
            label: 'Bot',
            data: chartBotViews,
            backgroundColor: 'rgba(239,68,68,0.7)',
            borderRadius: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'top', labels: { usePointStyle: true } } },
        scales: {
            x: { stacked: true, grid: { display: false } },
            y: { stacked: true, beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' } }
        }
    }
});

// ── 3. Hourly Heatmap-style Bar Chart ──
(function() {
    const totalHourly = hourlyHumanData.map((h, i) => h + hourlyBotData[i]);
    const maxVal = Math.max(...totalHourly, 1);
    const hourColors = totalHourly.map(v => {
        const intensity = v / maxVal;
        const r = Math.round(219 - intensity * 160);
        const g = Math.round(234 - intensity * 130);
        const b = Math.round(254 - intensity * 40);
        return `rgb(${r},${g},${b})`;
    });

    new Chart(document.getElementById('hourlyChart'), {
        type: 'bar',
        data: {
            labels: Array.from({length:24}, (_,i) => i + ':00'),
            datasets: [{
                label: 'Human',
                data: hourlyHumanData,
                backgroundColor: 'rgba(59,130,246,0.6)',
                borderRadius: 3
            }, {
                label: 'Bot',
                data: hourlyBotData,
                backgroundColor: 'rgba(239,68,68,0.4)',
                borderRadius: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'top', labels: { usePointStyle: true, font: { size: 11 } } } },
            scales: {
                x: { stacked: true, grid: { display: false }, ticks: { font: { size: 10 } } },
                y: { stacked: true, beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' } }
            }
        }
    });
})();

// ── 4. Browser Distribution (Horizontal Bar) ──
const browserColors = ['#3B82F6','#10B981','#F59E0B','#EF4444','#8B5CF6','#EC4899','#06B6D4','#84CC16'];
new Chart(document.getElementById('browserChart'), {
    type: 'bar',
    data: {
        labels: browserLabels,
        datasets: [{
            data: browserCounts,
            backgroundColor: browserColors.slice(0, browserLabels.length),
            borderRadius: 4
        }]
    },
    options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' } },
            y: { grid: { display: false }, ticks: { font: { size: 11 } } }
        }
    }
});

// ── 5. Device Distribution (Doughnut) ──
const deviceColors = { Desktop: '#3B82F6', Mobile: '#10B981', Tablet: '#F59E0B', Bot: '#EF4444' };
new Chart(document.getElementById('deviceChart'), {
    type: 'doughnut',
    data: {
        labels: deviceLabels,
        datasets: [{
            data: deviceCounts,
            backgroundColor: deviceLabels.map(l => deviceColors[l] || '#94A3B8'),
            borderWidth: 2,
            borderColor: '#fff',
            hoverOffset: 6
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '55%',
        plugins: {
            legend: { position: 'bottom', labels: { usePointStyle: true, padding: 12, font: { size: 11 } } }
        }
    }
});

// ── 6. Top Pages (Horizontal Bar) ──
new Chart(document.getElementById('topPagesChart'), {
    type: 'bar',
    data: {
        labels: topPageLabels,
        datasets: [{
            data: topPageViews,
            backgroundColor: 'rgba(59,130,246,0.6)',
            borderRadius: 4
        }]
    },
    options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' } },
            y: { grid: { display: false }, ticks: { font: { size: 11 } } }
        }
    }
});

// ── Auto-refresh ──
let autoRefreshTimer = null;
let lastUpdateTime = Date.now();

function toggleAutoRefresh() {
    const toggle = document.getElementById('autoRefreshToggle');
    toggle.classList.toggle('active');
    if (toggle.classList.contains('active')) {
        autoRefreshTimer = setInterval(() => location.reload(), 30000);
    } else {
        clearInterval(autoRefreshTimer);
        autoRefreshTimer = null;
    }
}

// Update "last updated" timer
setInterval(() => {
    const seconds = Math.floor((Date.now() - lastUpdateTime) / 1000);
    const el = document.getElementById('lastUpdated');
    if (seconds < 5) el.textContent = 'Just now';
    else if (seconds < 60) el.textContent = seconds + 's ago';
    else el.textContent = Math.floor(seconds / 60) + 'm ago';
}, 1000);
</script>

<?php include 'includes/footer.php'; ?>
