<?php
/**
 * AJAX endpoint - Image Library Picker
 * Returns images from the image_library table as JSON
 * GET params: folder (optional), search (optional), page (default 1, 20 per page)
 */
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/helpers.php';

header('Content-Type: application/json');

$db = getDB();

$folder = trim($_GET['folder'] ?? '');
$search = trim($_GET['search'] ?? '');
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

// Build query
$where = [];
$params = [];

if ($folder !== '' && $folder !== 'all') {
    $where[] = 'folder = ?';
    $params[] = $folder;
}

if ($search !== '') {
    $where[] = '(original_filename LIKE ? OR alt_text LIKE ? OR tags LIKE ?)';
    $searchTerm = '%' . $search . '%';
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

$whereSQL = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

// Get total count
$countStmt = $db->prepare("SELECT COUNT(*) FROM image_library $whereSQL");
$countStmt->execute($params);
$total = (int) $countStmt->fetchColumn();

// Get images
$sql = "SELECT id, filename, file_path, thumbnail_path, alt_text, folder, original_filename
        FROM image_library
        $whereSQL
        ORDER BY id DESC
        LIMIT $perPage OFFSET $offset";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// Add display_url (full URL) for rendering in the modal.
// Keep file_path as the raw relative path stored in the DB.
// This prevents double-URL-prefixing when paths go through get_image_url().
$images = array_map(function($img) {
    $raw                = ltrim($img['file_path'], '/');
    $thumb_raw          = !empty($img['thumbnail_path']) ? ltrim($img['thumbnail_path'], '/') : $raw;
    $img['display_url'] = BASE_URL . $raw;
    $img['thumb_url']   = BASE_URL . $thumb_raw;
    // file_path stays as the raw DB value — DO NOT prepend BASE_URL here
    return $img;
}, $rows);

echo json_encode([
    'success'     => true,
    'images'      => $images,
    'total'       => $total,
    'page'        => $page,
    'per_page'    => $perPage,
    'total_pages' => ceil($total / $perPage)
]);
