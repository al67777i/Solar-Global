﻿/**
 * Interactive Solar System Configurator
 * Real-time customization with live graphs and performance metrics
 */

// Currency helper — reads from global activeCurrency (set by recommender-v9)
function getCurrencySymbol() {
  return (
    window.appState?.activeCurrency?.symbol ||
    (typeof activeCurrency !== "undefined" ? activeCurrency.symbol : "$")
  );
}
function getCurrencyCode() {
  return (
    window.appState?.activeCurrency?.code ||
    (typeof activeCurrency !== "undefined" ? activeCurrency.code : "USD")
  );
}
function getCurrencyRate() {
  return (
    window.appState?.activeCurrency?.rate ||
    (typeof activeCurrency !== "undefined" ? activeCurrency.rate : 1.0)
  );
}
function cfgFmtPrice(usdAmount) {
  const converted = Math.round((usdAmount || 0) * getCurrencyRate());
  return getCurrencySymbol() + converted.toLocaleString();
}

/**
 * Toast notification system for configurator
 */
function showConfigToast(message, type = "info", duration = 4000) {
  // Remove any existing toast
  const existing = document.querySelector(".cfg-toast");
  if (existing) existing.remove();

  const icons = { info: "ℹ️", warning: "⚠️", error: "❌", success: "✅" };
  const colors = {
    info: "#3B82F6",
    warning: "#F59E0B",
    error: "#EF4444",
    success: "#10B981",
  };

  const toast = document.createElement("div");
  toast.className = "cfg-toast";
  toast.innerHTML = `<span class="cfg-toast-icon">${icons[type] || icons.info}</span><span class="cfg-toast-msg">${message}</span>`;
  Object.assign(toast.style, {
    position: "fixed",
    top: "20px",
    right: "20px",
    zIndex: "10000",
    background: "#1E293B",
    color: "#F1F5F9",
    padding: "14px 20px",
    borderRadius: "10px",
    borderLeft: `4px solid ${colors[type] || colors.info}`,
    boxShadow: "0 10px 40px rgba(0,0,0,0.3)",
    display: "flex",
    alignItems: "center",
    gap: "10px",
    fontSize: "14px",
    fontFamily: "'Inter', sans-serif",
    maxWidth: "420px",
    animation: "cfgToastIn 0.3s ease-out",
    backdropFilter: "blur(10px)",
  });

  // Add animation keyframes if not present
  if (!document.getElementById("cfg-toast-style")) {
    const style = document.createElement("style");
    style.id = "cfg-toast-style";
    style.textContent = `
            @keyframes cfgToastIn { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
            @keyframes cfgToastOut { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(40px); } }
        `;
    document.head.appendChild(style);
  }

  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = "cfgToastOut 0.3s ease-in forwards";
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

/**
 * Normalize field aliases between DB column names and configurator-expected names.
 * Ensures fields like watt_peak, battery_type, max_load_watts etc. always exist.
 */
function normalizeSystemFields(sys) {
  if (!sys) return;

  // Inverter aliases
  const inv = sys.inverter;
  if (inv) {
    if (!inv.max_load_watts && inv.power_rating)
      inv.max_load_watts = inv.power_rating;
    if (!inv.max_pv_input && inv.max_solar_input)
      inv.max_pv_input = parseInt(inv.max_solar_input) || 0;
    if (!inv.max_pv_input && inv.max_load_watts)
      inv.max_pv_input = Math.round(inv.max_load_watts * 1.3);
    if (!inv.voltage_class && inv.vdc_type) inv.voltage_class = inv.vdc_type;
    if (!inv.mppt_count && inv.mppt_channels)
      inv.mppt_count = inv.mppt_channels;
  }

  // Panel aliases
  const pan = sys.panel_config?.panel;
  if (pan) {
    if (!pan.watt_peak && pan.wattage)
      pan.watt_peak = parseInt(pan.wattage) || 0;
    if (!pan.wattage && pan.watt_peak) pan.wattage = pan.watt_peak;
    if (!pan.panel_type && pan.type) pan.panel_type = pan.type;
    if (!pan.efficiency_percent && pan.efficiency)
      pan.efficiency_percent = parseFloat(pan.efficiency);
  }

  // Battery aliases (may be null for on-grid systems)
  const bat = sys.battery_config?.battery;
  if (bat) {
    // Normalize voltage: prefer nominal_voltage, fallback to voltage
    if (!bat.voltage && bat.nominal_voltage)
      bat.voltage = parseFloat(bat.nominal_voltage) || 12;
    if (!bat.nominal_voltage && bat.voltage) bat.nominal_voltage = bat.voltage;
    // PRICE FIX: battery from recommendation API has price_unit_usd, not price_usd
    if (!bat.price_usd && bat.price_unit_usd)
      bat.price_usd = parseFloat(bat.price_unit_usd) || 0;
    if (!bat.price_unit_usd && bat.price_usd)
      bat.price_unit_usd = parseFloat(bat.price_usd) || 0;
    if (!bat.battery_type && bat.type) bat.battery_type = bat.type;
    if (!bat.has_bms && bat.is_bms !== undefined)
      bat.has_bms = parseInt(bat.is_bms) || 0;
    if (!bat.depth_of_discharge && bat.dod_decimal)
      bat.depth_of_discharge = Math.round(parseFloat(bat.dod_decimal) * 100);
    if (!bat.depth_of_discharge && bat.dod) {
      const d = parseFloat(bat.dod);
      bat.depth_of_discharge = d <= 1 ? Math.round(d * 100) : Math.round(d);
    }
    if (!bat.depth_of_discharge) bat.depth_of_discharge = 50;
  }
}

/**
 * Normalize a single component object (for items fetched from get_all_components)
 */
function normalizeComponent(comp, type) {
  if (!comp) return comp;
  if (type === "panel") {
    if (!comp.watt_peak && comp.wattage)
      comp.watt_peak = parseInt(comp.wattage) || 0;
    if (!comp.wattage && comp.watt_peak) comp.wattage = comp.watt_peak;
    if (!comp.panel_type && comp.type) comp.panel_type = comp.type;
    if (!comp.efficiency_percent && comp.efficiency)
      comp.efficiency_percent = parseFloat(comp.efficiency);
  } else if (type === "battery") {
    if (!comp.voltage && comp.nominal_voltage)
      comp.voltage = parseFloat(comp.nominal_voltage) || 12;
    if (!comp.nominal_voltage && comp.voltage)
      comp.nominal_voltage = comp.voltage;
    // PRICE FIX: sync price_usd <-> price_unit_usd for batteries
    if (!comp.price_usd && comp.price_unit_usd)
      comp.price_usd = parseFloat(comp.price_unit_usd) || 0;
    if (!comp.price_unit_usd && comp.price_usd)
      comp.price_unit_usd = parseFloat(comp.price_usd) || 0;
    if (!comp.battery_type && comp.type) comp.battery_type = comp.type;
    if (!comp.has_bms && comp.is_bms !== undefined)
      comp.has_bms = parseInt(comp.is_bms) || 0;
    if (!comp.depth_of_discharge && comp.dod) {
      const d = parseFloat(comp.dod);
      comp.depth_of_discharge = d <= 1 ? Math.round(d * 100) : Math.round(d);
    }
  } else if (type === "inverter") {
    if (!comp.max_load_watts && comp.power_rating)
      comp.max_load_watts = comp.power_rating;
    if (!comp.max_pv_input && comp.max_solar_input)
      comp.max_pv_input = parseInt(comp.max_solar_input) || 0;
    if (!comp.voltage_class && comp.vdc_type)
      comp.voltage_class = comp.vdc_type;
  }
  return comp;
}

// Global state
let configuratorState = {
  recommended: null,
  current: null,
  allInverters: [],
  allBatteries: [],
  allPanels: [],
  loadAnalysis: null,
  chart: null,
};

/**
 * Initialize configurator with recommended system
 */
async function initializeConfigurator(systemOption, loadAnalysis, allOptions) {
  // Check if Chart.js is loaded
  if (typeof Chart === "undefined") {
    console.error("Chart.js not loaded! Waiting...");
    setTimeout(() => {
      initializeConfigurator(systemOption, loadAnalysis, allOptions);
    }, 500);
    return;
  }

  configuratorState.recommended = JSON.parse(JSON.stringify(systemOption));
  configuratorState.current = JSON.parse(JSON.stringify(systemOption));
  configuratorState.loadAnalysis = loadAnalysis;
  configuratorState._dealersSearched = false; // Reset dealer search for new config

  // Normalize field aliases — ensures DB column names map to configurator-expected names
  normalizeSystemFields(configuratorState.recommended);
  normalizeSystemFields(configuratorState.current);

  // CRITICAL: ALWAYS derive system_voltage from the SELECTED option's inverter
  // The load_analysis.system_voltage from API may be for a different voltage class
  const invVoltageClass =
    systemOption.inverter?.voltage_class ||
    systemOption.inverter?.vdc_type ||
    "48V";

  // ─── FIXED voltage parsing: "48-60V" must give 48, NOT 4860 ───────────────
  // The old regex stripped ALL non-digits: "48-60V" → "4860" → parseInt=4860 → WRONG
  // New: extract only the FIRST number from the string
  const _vStr = String(invVoltageClass)
    .replace(/[Vv]|DC|dc/g, "")
    .trim();
  let derivedVoltage = 48;
  const _rangeMatch = _vStr.match(/^(\d+\.?\d*)\s*[-–~]\s*(\d+\.?\d*)$/);
  if (_rangeMatch) {
    // It's a range like "48-60" or "38.4~60" — use first number as the base
    const _minV = parseFloat(_rangeMatch[1]);
    const _maxV = parseFloat(_rangeMatch[2]);
    // If battery voltage is known, compute minimum series needed → gives nominal voltage
    const _knownBattV = parseFloat(
      systemOption.battery_config?.battery?.voltage ||
        systemOption.battery_config?.battery?.nominal_voltage ||
        0,
    );
    if (_knownBattV > 0) {
      const _minSeries = Math.ceil(_minV / _knownBattV);
      derivedVoltage = Math.round(_minSeries * _knownBattV);
    } else {
      // No battery known — midpoint of range
      derivedVoltage = Math.round((_minV + _maxV) / 2);
    }
  } else {
    // Single value like "48V" or "400V" — take first number only
    const _singleMatch = _vStr.match(/\d+\.?\d*/);
    derivedVoltage = _singleMatch
      ? Math.round(parseFloat(_singleMatch[0]))
      : 48;
  }
  // Safety clamp
  if (derivedVoltage <= 0 || derivedVoltage > 1500) derivedVoltage = 48;
  // ─────────────────────────────────────────────────────────────────────────

  loadAnalysis.system_voltage = derivedVoltage;
  loadAnalysis.voltage_class = invVoltageClass;

  // Map API field names to configurator field names for panel_config
  const pCfg = configuratorState.current.panel_config;
  if (pCfg) {
    // Map panels_per_string → series, total_strings → parallel if not already set
    if (!pCfg.series && pCfg.panels_per_string)
      pCfg.series = parseInt(pCfg.panels_per_string) || 1;
    if (!pCfg.parallel && pCfg.total_strings)
      pCfg.parallel = parseInt(pCfg.total_strings) || 1;
    if (!pCfg.series) pCfg.series = 1;
    if (!pCfg.parallel)
      pCfg.parallel = Math.max(
        1,
        Math.ceil((pCfg.quantity || 1) / (pCfg.series || 1)),
      );
  }
  const pCfgRec = configuratorState.recommended.panel_config;
  if (pCfgRec) {
    if (!pCfgRec.series && pCfgRec.panels_per_string)
      pCfgRec.series = parseInt(pCfgRec.panels_per_string) || 1;
    if (!pCfgRec.parallel && pCfgRec.total_strings)
      pCfgRec.parallel = parseInt(pCfgRec.total_strings) || 1;
    if (!pCfgRec.series) pCfgRec.series = 1;
    if (!pCfgRec.parallel)
      pCfgRec.parallel = Math.max(
        1,
        Math.ceil((pCfgRec.quantity || 1) / (pCfgRec.series || 1)),
      );
  }

  // Determine if this is an on-grid system (no battery)
  const isOnGrid =
    systemOption.system_type === "on-grid" || !systemOption.battery_config;

  // For on-grid: ensure battery_config exists but is marked as not needed
  if (isOnGrid) {
    configuratorState.current.battery_config = configuratorState.current
      .battery_config || {
      battery: {
        voltage: 0,
        capacity_ah: 0,
        price_usd: 0,
        battery_type: "none",
        name: "N/A",
      },
      quantity: 0,
      series: 0,
      parallel: 0,
      total_ah: 0,
      total_cost: 0,
      wiring: "Not applicable (On-Grid)",
      backup_hours: 0,
    };
    configuratorState.recommended.battery_config =
      configuratorState.recommended.battery_config ||
      configuratorState.current.battery_config;
    configuratorState.current.needs_battery = false;
  } else {
    configuratorState.current.needs_battery = true;
    // Recalculate battery wiring based on CORRECT system voltage
    const battV =
      parseFloat(configuratorState.current.battery_config.battery.voltage) ||
      12;
    const sysV = derivedVoltage;
    const seriesNeeded =
      sysV >= battV && sysV % battV === 0
        ? Math.round(sysV / battV)
        : Math.max(1, Math.round(sysV / battV));
    const currentBattQty = configuratorState.current.battery_config.quantity;
    const validBattQty = Math.max(
      seriesNeeded,
      Math.round(currentBattQty / seriesNeeded) * seriesNeeded,
    );

    configuratorState.current.battery_config.quantity = validBattQty;
    const parallelCount = Math.max(1, Math.floor(validBattQty / seriesNeeded));
    configuratorState.current.battery_config.series = seriesNeeded;
    configuratorState.current.battery_config.parallel = parallelCount;
    configuratorState.current.battery_config.total_ah =
      parallelCount *
      configuratorState.current.battery_config.battery.capacity_ah;
    configuratorState.current.battery_config.total_cost =
      validBattQty *
      parseFloat(configuratorState.current.battery_config.battery.price_usd);

    const bankVoltage = seriesNeeded * battV;
    if (seriesNeeded > 1 && parallelCount > 1) {
      configuratorState.current.battery_config.wiring = `${seriesNeeded}S${parallelCount}P — ${seriesNeeded}×${battV}V in series = ${bankVoltage}V, ${parallelCount} parallel strings`;
    } else if (seriesNeeded > 1) {
      configuratorState.current.battery_config.wiring = `${seriesNeeded}S — ${seriesNeeded}×${battV}V in series = ${bankVoltage}V`;
    } else if (parallelCount > 1) {
      configuratorState.current.battery_config.wiring = `${parallelCount}P — ${parallelCount}×${configuratorState.current.battery_config.battery.capacity_ah}Ah in parallel = ${configuratorState.current.battery_config.total_ah}Ah`;
    } else {
      configuratorState.current.battery_config.wiring = `Single ${battV}V ${configuratorState.current.battery_config.battery.capacity_ah}Ah battery`;
    }
  }

  // Fetch ALL available components from database
  try {
    const response = await fetch("api/get_all_components.php");
    const data = await response.json();

    if (data.success) {
      configuratorState.allInverters = (data.inverters || []).map((c) =>
        normalizeComponent(c, "inverter"),
      );
      configuratorState.allBatteries = (data.batteries || []).map((c) =>
        normalizeComponent(c, "battery"),
      );
      configuratorState.allPanels = (data.panels || []).map((c) =>
        normalizeComponent(c, "panel"),
      );
    } else {
      console.error("Failed to fetch components:", data.message);
      // Fallback: use components from recommendations
      configuratorState.allInverters = allOptions.map((opt) => opt.inverter);
      configuratorState.allBatteries = [systemOption.battery_config.battery];
      configuratorState.allPanels = [systemOption.panel_config.panel];

      // Remove duplicates
      configuratorState.allInverters = Array.from(
        new Map(
          configuratorState.allInverters.map((inv) => [inv.id, inv]),
        ).values(),
      );
    }
  } catch (error) {
    console.error("Error fetching components:", error);
    // Fallback: use components from recommendations
    configuratorState.allInverters = allOptions.map((opt) => opt.inverter);
    configuratorState.allBatteries = [systemOption.battery_config.battery];
    configuratorState.allPanels = [systemOption.panel_config.panel];

    // Remove duplicates
    configuratorState.allInverters = Array.from(
      new Map(
        configuratorState.allInverters.map((inv) => [inv.id, inv]),
      ).values(),
    );
  }

  // CRITICAL FIX: Recalculate system FIRST to generate hourly_simulation data
  // This ensures the chart has data to display on initial load
  await recalculateSystem();

  // CRITICAL FIX: Validate and cap panel quantity on initialization
  const limits = {
    minPanels: 2,
    maxPanels: Math.floor(
      (configuratorState.current.inverter.max_pv_input ||
        configuratorState.current.inverter.max_load_watts * 1.3) /
        (configuratorState.current.panel_config.panel.watt_peak ||
          configuratorState.current.panel_config.panel.wattage ||
          540),
    ),
  };

  if (configuratorState.current.panel_config.quantity > limits.maxPanels) {
    console.warn(
      `⚠️ Initial panel count (${configuratorState.current.panel_config.quantity}) exceeds max (${limits.maxPanels}). Capping to ${limits.maxPanels}.`,
    );
    configuratorState.current.panel_config.quantity = limits.maxPanels;
    configuratorState.current.panel_config.total_wattage =
      limits.maxPanels * configuratorState.current.panel_config.panel.watt_peak;
    configuratorState.current.panel_config.total_kwp = (
      configuratorState.current.panel_config.total_wattage / 1000
    ).toFixed(2);
    configuratorState.current.panel_config.total_cost =
      limits.maxPanels *
      parseFloat(configuratorState.current.panel_config.panel.price_usd);

    // Recalculate series/parallel for new quantity
    recalculatePanelSeriesParallel();

    // Recalculate system with new panel count
    await recalculateSystem();
  }

  renderConfigurator();
  updateEnergyForecast();
}

/**
 * Render configurator UI
 */
function renderConfigurator() {
  const container = document.getElementById("configurator-container");
  if (!container) return;

  const current = configuratorState.current;
  const recommended = configuratorState.recommended;
  const load = configuratorState.loadAnalysis;

  const storageKwh =
    current.battery_storage_kwh ||
    (current.needs_battery !== false
      ? (
          (current.battery_config.total_ah *
            parseFloat(current.battery_config.battery.voltage || 0) *
            (current.battery_config.series || 1)) /
          1000
        ).toFixed(2)
      : "0.00");

  const html = `
        <div class="cfg-wrap">
            <!-- Header -->
            <div class="cfg-header">
                <div class="cfg-header-content">
                    <h2>Customize Your Solar System</h2>
                    <p>Fine-tune components and watch performance update in real-time</p>
                </div>
                <div class="cfg-header-cost">
                    <span class="cfg-cost-label">Total Investment</span>
                    <span class="cfg-cost-value" id="total-cost">${cfgFmtPrice(current.total_cost)}</span>
                    <span class="cost-change" id="cost-change"></span>
                </div>
            </div>

            <!-- Quick System Summary -->
            <div class="cfg-energy-summary">
                <div class="cfg-gstat"><span class="cfg-gstat-icon">☀️</span><span class="cfg-gstat-val" id="cfg-solar-day">${current.solar_generation_per_day || "0"}</span><span class="cfg-gstat-lbl">kWh Solar/Day</span></div>
                <div class="cfg-gstat"><span class="cfg-gstat-icon">🏠</span><span class="cfg-gstat-val" id="cfg-usage-day">${(parseFloat(load.daily_energy_kwh) || 0).toFixed(1)}</span><span class="cfg-gstat-lbl">kWh Usage/Day</span></div>
                <div class="cfg-gstat"><span class="cfg-gstat-icon">⚡</span><span class="cfg-gstat-val" id="cfg-grid-day">${current.grid_units_per_day || "0"}</span><span class="cfg-gstat-lbl">kWh Grid/Day</span></div>
                <div class="cfg-gstat"><span class="cfg-gstat-icon">🎯</span><span class="cfg-gstat-val" id="cfg-independence">${current.energy_independence || 0}%</span><span class="cfg-gstat-lbl">Independence</span></div>
                <div class="cfg-gstat"><span class="cfg-gstat-icon">🔋</span><span class="cfg-gstat-val" id="cfg-backup">${current.backup_hours || 0}h</span><span class="cfg-gstat-lbl">Backup</span></div>
            </div>

            <!-- Placeholder: energy forecast chart will be inserted here -->
            <div id="forecast-slot"></div>

            <!-- Component Selection Cards -->
            <div class="cfg-components">
                <!-- Inverter Card -->
                <div class="cfg-card cfg-card-inverter">
                    <div class="cfg-card-icon">⚡</div>
                    <div class="cfg-card-title">Inverter</div>
                    <select id="inverter-select" class="cfg-select" onchange="onInverterChange(event)">
                        ${renderInverterOptions()}
                    </select>
                    <div class="cfg-card-specs">
                        <div class="cfg-spec"><span class="cfg-spec-k">Capacity</span><span class="cfg-spec-v">${current.inverter.max_load_watts}W</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Voltage</span><span class="cfg-spec-v">${current.inverter.voltage_class}</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">PV Input</span><span class="cfg-spec-v">${current.inverter.max_pv_input || "N/A"}W</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">VDC Range</span><span class="cfg-spec-v">${current.inverter.input_voltage_min || "?"}-${current.inverter.input_voltage_max || "?"}V</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">MPPT</span><span class="cfg-spec-v">${current.inverter.mppt_count || 1} Channel</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">BMS</span><span class="cfg-spec-v">${current.inverter.has_bms == 1 ? "Yes" : "No"}</span></div>
                    </div>
                    <div class="cfg-card-price">${cfgFmtPrice(current.inverter.price_usd)}</div>
                </div>

                <!-- Battery Card / Grid Export Card -->
                ${
                  current.needs_battery !== false
                    ? `
                <div class="cfg-card cfg-card-battery">
                    <div class="cfg-card-icon">🔋</div>
                    <div class="cfg-card-title">Battery Bank</div>
                    <div class="cfg-qty-slider-wrap">
                        <input type="range" class="cfg-batt-slider" id="battery-slider"
                               min="${(() => {
                                 const battV =
                                   parseFloat(
                                     current.battery_config.battery.voltage,
                                   ) || 12;
                                 const sysV =
                                   parseFloat(
                                     configuratorState.loadAnalysis
                                       .system_voltage,
                                   ) || 48;
                                 return sysV >= battV && sysV % battV === 0
                                   ? Math.round(sysV / battV)
                                   : Math.max(1, Math.round(sysV / battV));
                               })()}"
                               max="${(() => {
                                 const battV =
                                   parseFloat(
                                     current.battery_config.battery.voltage ||
                                       current.battery_config.battery
                                         .nominal_voltage,
                                   ) || 12;
                                 const sysV =
                                   parseFloat(
                                     configuratorState.loadAnalysis
                                       .system_voltage,
                                   ) || 48;
                                 const ser =
                                   sysV >= battV && sysV % battV === 0
                                     ? Math.round(sysV / battV)
                                     : Math.max(1, Math.round(sysV / battV));
                                 const inverterW =
                                   parseFloat(
                                     current.inverter.max_load_watts,
                                   ) || 5000;
                                 const maxP =
                                   inverterW < 5000
                                     ? 8
                                     : inverterW < 10000
                                       ? 12
                                       : 20;
                                 return ser * maxP;
                               })()}"
                               step="${(() => {
                                 const battV =
                                   parseFloat(
                                     current.battery_config.battery.voltage,
                                   ) || 12;
                                 const sysV =
                                   parseFloat(
                                     configuratorState.loadAnalysis
                                       .system_voltage,
                                   ) || 48;
                                 return sysV >= battV && sysV % battV === 0
                                   ? Math.round(sysV / battV)
                                   : Math.max(1, Math.round(sysV / battV));
                               })()}"
                               value="${current.battery_config.quantity}"
                               oninput="window.onBatterySliderChange(this.value)">
                        <div class="cfg-qty-slider-info">
                            <span id="battery-quantity">${current.battery_config.quantity}</span> batteries
                            <span class="cfg-slider-range">(${(() => {
                              const battV =
                                parseFloat(
                                  current.battery_config.battery.voltage,
                                ) || 12;
                              const sysV =
                                parseFloat(
                                  configuratorState.loadAnalysis.system_voltage,
                                ) || 48;
                              return sysV >= battV && sysV % battV === 0
                                ? Math.round(sysV / battV)
                                : Math.max(1, Math.round(sysV / battV));
                            })()} – ${(() => {
                              const inverterW =
                                parseFloat(current.inverter.max_load_watts) ||
                                5000;
                              return Math.max(16, Math.ceil(inverterW / 500));
                            })()})</span>
                        </div>
                    </div>
                    <div class="cfg-qty-row" style="margin-top:4px;">
                        <button class="cfg-qty-btn" onclick="window.changeBatteryQuantity(-1); return false;">-</button>
                        <button class="cfg-qty-btn" onclick="window.changeBatteryQuantity(1); return false;">+</button>
                    </div>
                    <div class="cfg-card-specs">
                        <div class="cfg-spec"><span class="cfg-spec-k">Each</span><span class="cfg-spec-v">${current.battery_config.battery.voltage}V ${current.battery_config.battery.capacity_ah}Ah</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Type</span><span class="cfg-spec-v">${current.battery_config.battery.battery_type || "Lead-Acid"}</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Series</span><span class="cfg-spec-v">${current.battery_config.series || 1} batteries → ${(current.battery_config.series || 1) * parseFloat(current.battery_config.battery.voltage)}V</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Parallel</span><span class="cfg-spec-v">${current.battery_config.parallel || 1} strings → ${current.battery_config.total_ah}Ah</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Storage</span><span class="cfg-spec-v">${storageKwh} kWh (${current.usable_storage_kwh || "?"} usable)</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Connection</span><span class="cfg-spec-v" id="wiring-text">${current.battery_config.wiring || "-"}</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Backup</span><span class="cfg-spec-v">${current.backup_hours || 0}h</span></div>
                    </div>
                    <div class="cfg-card-price">${cfgFmtPrice(current.battery_config.total_cost)}</div>
                </div>
                `
                    : `
                <div class="cfg-card cfg-card-battery" style="border-color:#10B981;">
                    <div class="cfg-card-icon">🔌</div>
                    <div class="cfg-card-title">Grid Connection (On-Grid)</div>
                    <div class="cfg-card-specs">
                        <div class="cfg-spec"><span class="cfg-spec-k">Type</span><span class="cfg-spec-v">Net Metering</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Export</span><span class="cfg-spec-v">${(current.grid_export_kwh || 0).toFixed(1)} kWh/day → Grid</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Import</span><span class="cfg-spec-v">${(current.grid_units_per_day || 0).toFixed(1)} kWh/day ← Grid</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Net Savings</span><span class="cfg-spec-v">${cfgFmtPrice((current.monthly_savings || 0) / 12)}/day</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Battery</span><span class="cfg-spec-v">Not Required</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Backup</span><span class="cfg-spec-v">None (grid-dependent)</span></div>
                    </div>
                    <div class="cfg-card-price" style="color:#10B981;">No Battery Cost</div>
                </div>
                `
                }

                <!-- Solar Panel Card -->
                <div class="cfg-card cfg-card-solar">
                    <div class="cfg-card-icon">☀️</div>
                    <div class="cfg-card-title">Solar Panels</div>
                    ${renderPanelSelector()}
                    <div class="cfg-qty-slider-wrap" style="margin-top:12px;">
                        <input type="range" class="cfg-panel-slider" id="panel-slider"
                               min="${(() => {
                                 const lim = updatePanelLimits();
                                 return lim.minPanels;
                               })()}"
                               max="${(() => {
                                 const lim = updatePanelLimits();
                                 return lim.maxPanels;
                               })()}"
                               value="${current.panel_config.quantity}"
                               oninput="window.onPanelSliderChange(this.value)">
                        <div class="cfg-qty-slider-info">
                            <span id="panel-quantity">${current.panel_config.quantity}</span> panels
                            <span class="cfg-slider-range">(${(() => {
                              const lim = updatePanelLimits();
                              return lim.minPanels;
                            })()} – ${(() => {
                              const lim = updatePanelLimits();
                              return lim.maxPanels;
                            })()})</span>
                        </div>
                    </div>
                    <div class="cfg-qty-row" style="margin-top:4px;">
                        <button class="cfg-qty-btn" onclick="window.changePanelQuantity(-1); return false;">-</button>
                        <button class="cfg-qty-btn" onclick="window.changePanelQuantity(1); return false;">+</button>
                    </div>
                    <div class="cfg-card-specs">
                        <div class="cfg-spec"><span class="cfg-spec-k">Each</span><span class="cfg-spec-v">${current.panel_config.panel.watt_peak}W</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Total</span><span class="cfg-spec-v">${current.panel_config.total_kwp} kWp</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">Wiring</span><span class="cfg-spec-v">${current.panel_config.wiring || current.panel_config.series + "S" + current.panel_config.parallel + "P"}</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">String Voc</span><span class="cfg-spec-v" id="vdc-status">${current.panel_config.vdc_used || "?"}V / ${current.panel_config.vdc_limit || current.inverter.input_voltage_max || "?"}V (${current.panel_config.vdc_utilization || "?"}%) ${current.panel_config.within_vdc !== false ? "✓" : "⚠️"}</span></div>
                        <div class="cfg-spec"><span class="cfg-spec-k">String Vmp</span><span class="cfg-spec-v">${current.panel_config.string_voltage || "?"}V (operating)</span></div>
                    </div>
                    <div class="cfg-panel-limits" id="panel-limits-info">
                        <span id="min-panels">2</span>-<span id="max-panels">20</span> panels allowed
                    </div>
                    <div class="cfg-card-price">${cfgFmtPrice(current.panel_config.total_cost)}</div>
                </div>
            </div>

            <!-- Validation Warnings -->
            <div id="validation-warnings"></div>

            <!-- Find Nearest Dealer Section -->
            <div class="cfg-nearest-dealers" id="cfg-nearest-dealers">
                <div class="cfg-nearest-header">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <h3>Where to Buy These Products</h3>
                </div>
                <div id="cfg-dealer-list" class="cfg-dealer-list">
                    <div class="cfg-dealer-loading">Searching for nearby dealers...</div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="cfg-actions">
                <button onclick="window.goBackToRecommendations(); return false;" class="cfg-btn-back">
                    ← Back to Recommendations
                </button>
                <button onclick="window.resetToRecommended(); return false;" class="cfg-btn-reset">
                    Reset to Recommended
                </button>
                <button onclick="window.proceedWithCustomSystem(); return false;" class="cfg-btn-proceed">
                    Proceed with This System
                </button>
            </div>
        </div>
    `;

  // Detach the forecast section BEFORE innerHTML destroys it
  const forecastSection = document.getElementById("energy-forecast-section");
  let forecastParked = null;
  if (forecastSection) {
    forecastParked = forecastSection;
    forecastSection.remove();
  }

  container.innerHTML = html;

  // Re-attach forecast section into the placeholder slot
  const slot = document.getElementById("forecast-slot");
  if (slot && forecastParked) {
    slot.appendChild(forecastParked);
  }

  updatePanelLimits();

  // Search for nearest dealers with selected products (once, not on every re-render)
  if (!configuratorState._dealersSearched) {
    configuratorState._dealersSearched = true;
    setTimeout(searchNearestDealers, 500);
  }
}

/**
 * Render inverter dropdown options
 */
function renderInverterOptions() {
  const current = configuratorState.current;
  const load = configuratorState.loadAnalysis;

  // Sort inverters by capacity
  const sortedInverters = [...configuratorState.allInverters].sort(
    (a, b) => a.max_load_watts - b.max_load_watts,
  );

  return sortedInverters
    .map((inv) => {
      const isRecommended =
        inv.id === configuratorState.recommended.inverter.id;
      const isCurrent = inv.id === current.inverter.id;
      const canHandle = inv.max_load_watts >= load.peak_load_watts;
      const bmsTag = inv.has_bms == 1 ? " [BMS]" : "";
      const vdcInfo =
        inv.input_voltage_max > 0 ? ` VDC:${inv.input_voltage_max}V` : "";

      let label = `[${inv.voltage_class}] ${inv.company_name || ""} ${inv.name} - ${inv.max_load_watts}W${vdcInfo}${bmsTag} - ${getCurrencySymbol()}${formatNumber(inv.price_usd)}`;
      if (isRecommended) label += " ⭐";
      if (!canHandle) label += " ⚠️ Too Small";

      return `
            <option value="${inv.id}"
                    ${isCurrent ? "selected" : ""}
                    ${!canHandle ? "disabled" : ""}>
                ${label}
            </option>
        `;
    })
    .join("");
}

/**
 * Render panel selector with category tabs and cards (NEW UI)
 */
function renderPanelSelector() {
  const current = configuratorState.current;
  const inverter = current.inverter;

  // Get inverter VDC constraints
  const invVdcMax = parseFloat(inverter.input_voltage_max) || 500;
  const invVdcMin = parseFloat(inverter.input_voltage_min) || 40;

  // Group panels by wattage category
  const panelsByWattage = {};
  configuratorState.allPanels.forEach((panel) => {
    const watt = panel.watt_peak;
    if (!panelsByWattage[watt]) {
      panelsByWattage[watt] = [];
    }
    panelsByWattage[watt].push(panel);
  });

  // Sort categories by wattage
  const categories = Object.keys(panelsByWattage).sort(
    (a, b) => parseInt(a) - parseInt(b),
  );

  // Find current panel's category
  const currentCategory = (
    current.panel_config.panel.watt_peak ||
    current.panel_config.panel.wattage ||
    0
  ).toString();

  return `
        <div class="panel-selector-container">
            <!-- Category Tabs -->
            <div class="panel-category-tabs">
                ${categories
                  .map(
                    (watt) => `
                    <button class="panel-category-tab ${watt === currentCategory ? "active" : ""}"
                            onclick="window.showPanelCategory('${watt}')"
                            data-category="${watt}">
                        ${watt}W
                        <span class="tab-count">${panelsByWattage[watt].length}</span>
                    </button>
                `,
                  )
                  .join("")}
            </div>

            <!-- Panel Cards Container -->
            <div class="panel-cards-container">
                ${categories
                  .map(
                    (watt) => `
                    <div class="panel-category-content ${watt === currentCategory ? "active" : ""}"
                         data-category="${watt}">
                        <div class="panel-cards-scroll">
                            ${panelsByWattage[watt]
                              .map((panel) => {
                                const isRecommended =
                                  panel.id ===
                                  configuratorState.recommended.panel_config
                                    .panel.id;
                                const isCurrent =
                                  panel.id === current.panel_config.panel.id;

                                // Check compatibility
                                const panelVoc = parseFloat(panel.voc) || 48;
                                const panelVmp = parseFloat(panel.vmp) || 40;
                                const maxSeries = Math.floor(
                                  invVdcMax / panelVoc,
                                );
                                const minSeries = Math.max(
                                  1,
                                  Math.ceil(invVdcMin / panelVmp),
                                );
                                const isCompatible =
                                  maxSeries >= minSeries && maxSeries >= 1;

                                const companyName =
                                  panel.company_name || "Unknown";
                                const panelType = panel.panel_type || "Mono";
                                const efficiency =
                                  panel.efficiency_percent || 0;

                                return `
                                    <div class="panel-card ${isCurrent ? "selected" : ""} ${!isCompatible ? "incompatible" : ""}"
                                         onclick="${isCompatible ? `window.selectPanel(${panel.id})` : ""}"
                                         data-panel-id="${panel.id}">
                                        ${isRecommended ? '<div class="panel-card-badge">⭐ Recommended</div>' : ""}
                                        ${!isCompatible ? '<div class="panel-card-badge incompatible-badge">⚠️ Incompatible</div>' : ""}

                                        <!-- Solar Panel SVG Icon -->
                                        <div class="panel-card-icon">
                                            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                                                <defs>
                                                    <linearGradient id="panelGrad${panel.id}" x1="0%" y1="0%" x2="100%" y2="100%">
                                                        <stop offset="0%" style="stop-color:#1E40AF;stop-opacity:1" />
                                                        <stop offset="100%" style="stop-color:#3B82F6;stop-opacity:1" />
                                                    </linearGradient>
                                                </defs>
                                                <!-- Panel Frame -->
                                                <rect x="10" y="15" width="80" height="70" rx="3" fill="url(#panelGrad${panel.id})" stroke="#1E3A8A" stroke-width="2"/>
                                                <!-- Grid Lines -->
                                                <line x1="50" y1="15" x2="50" y2="85" stroke="#1E3A8A" stroke-width="1.5"/>
                                                <line x1="10" y1="50" x2="90" y2="50" stroke="#1E3A8A" stroke-width="1.5"/>
                                                <!-- Cells -->
                                                ${[0, 1, 2, 3]
                                                  .map(
                                                    (i) =>
                                                      `<rect x="${15 + (i % 2) * 35}" y="${20 + Math.floor(i / 2) * 30}" width="30" height="25" fill="none" stroke="#60A5FA" stroke-width="0.5" opacity="0.6"/>`,
                                                  )
                                                  .join("")}
                                                <!-- Sun rays -->
                                                <circle cx="85" cy="20" r="8" fill="#FCD34D" opacity="0.9"/>
                                                <line x1="85" y1="12" x2="85" y2="8" stroke="#FCD34D" stroke-width="2" stroke-linecap="round"/>
                                                <line x1="93" y1="20" x2="97" y2="20" stroke="#FCD34D" stroke-width="2" stroke-linecap="round"/>
                                                <line x1="90" y1="15" x2="93" y2="12" stroke="#FCD34D" stroke-width="2" stroke-linecap="round"/>
                                            </svg>
                                        </div>

                                        <!-- Panel Info -->
                                        <div class="panel-card-info">
                                            <div class="panel-card-company">${companyName}</div>
                                            <div class="panel-card-watt">${panel.watt_peak}W</div>
                                            <div class="panel-card-specs">
                                                <span>${panelType}</span>
                                                ${efficiency > 0 ? `<span>${efficiency}%</span>` : ""}
                                                <span>Voc: ${panelVoc}V</span>
                                            </div>
                                            <div class="panel-card-price">${getCurrencySymbol()}${formatNumber(panel.price_usd)}</div>
                                        </div>

                                        ${isCurrent ? '<div class="panel-card-checkmark">✓</div>' : ""}
                                    </div>
                                `;
                              })
                              .join("")}
                        </div>
                    </div>
                `,
                  )
                  .join("")}
            </div>
        </div>
    `;
}

/**
 * Change inverter (GLOBAL)
 */
window.onInverterChange = async function (e) {
  const inverterId = parseInt(e.target.value);
  const newInverter = configuratorState.allInverters.find(
    (inv) => inv.id === inverterId,
  );

  if (!newInverter) return;

  const oldInverter = configuratorState.current.inverter;
  const current = configuratorState.current;

  // Save battery config snapshot BEFORE any changes (for revert on panel incompatibility)
  const savedBatteryConfig = JSON.parse(JSON.stringify(current.battery_config));

  current.inverter = newInverter;

  // CRITICAL FIX: Always update system voltage when inverter changes
  const load = configuratorState.loadAnalysis;
  const oldSystemVoltage =
    parseInt(String(oldInverter.voltage_class).replace(/[^0-9]/g, "")) || 48;
  const newSystemVoltage =
    parseInt(String(newInverter.voltage_class).replace(/[^0-9]/g, "")) || 48;

  // Always sync system voltage with selected inverter
  load.system_voltage = newSystemVoltage;
  load.voltage_class = newInverter.voltage_class;

  // CRITICAL FIX: Recalculate battery configuration for new voltage
  const battV = parseFloat(current.battery_config.battery.voltage) || 12;
  const oldSeries = Math.max(1, Math.round(oldSystemVoltage / battV));
  const newSeries = Math.max(1, Math.round(newSystemVoltage / battV));

  if (oldSeries !== newSeries) {
    // Voltage changed - need to recalculate battery quantity
    const currentBattQty = current.battery_config.quantity;
    const oldParallel = Math.floor(currentBattQty / oldSeries);

    // Keep same number of parallel strings if possible
    const newBattQty = newSeries * oldParallel;

    console.warn(`⚠️ Battery configuration changed due to voltage change:`);
    console.warn(
      `   Old: ${currentBattQty} batteries (${oldSeries}S${oldParallel}P)`,
    );
    console.warn(
      `   New: ${newBattQty} batteries (${newSeries}S${oldParallel}P)`,
    );

    current.battery_config.quantity = newBattQty;
    current.battery_config.series = newSeries;
    current.battery_config.parallel = oldParallel;
    current.battery_config.total_ah =
      oldParallel * parseFloat(current.battery_config.battery.capacity_ah);
    current.battery_config.total_cost =
      newBattQty * parseFloat(current.battery_config.battery.price_usd);

    // Update wiring description
    const bankV = newSeries * battV;
    if (newSeries > 1 && oldParallel > 1) {
      current.battery_config.wiring = `${newSeries}S${oldParallel}P — ${newSeries} in series (${battV}V×${newSeries}=${bankV}V), ${oldParallel} strings in parallel`;
    } else if (newSeries > 1) {
      current.battery_config.wiring = `${newSeries} in series (${battV}V×${newSeries}=${bankV}V)`;
    } else if (oldParallel > 1) {
      current.battery_config.wiring = `${oldParallel} in parallel (${battV}V, ${oldParallel}×${current.battery_config.battery.capacity_ah}Ah=${current.battery_config.total_ah}Ah)`;
    } else {
      current.battery_config.wiring = `Single battery (${battV}V, ${current.battery_config.battery.capacity_ah}Ah)`;
    }
  }

  // CRITICAL FIX: Calculate OPTIMAL panel count for new inverter
  const panel = current.panel_config.panel;
  const panelWp = parseFloat(panel.watt_peak) || 540;
  const panelVoc = parseFloat(panel.voc) || 48;
  const panelVmp = parseFloat(panel.vmp) || 40;

  const {
    invVdcMax: newVdcMax,
    invVdcMin: newVdcMin,
    maxPvInput: newMaxPvInput,
    inverterWatts: newInvWatts,
    mpptCount,
  } = getInverterVdcSpecs(newInverter);

  // Check panel compatibility
  const maxSeries = Math.floor(newVdcMax / panelVoc);
  const minSeries = Math.max(1, Math.ceil(newVdcMin / panelVmp));

  if (maxSeries < minSeries) {
    console.error("   ❌ Panel Voc too high for this inverter!");
    showConfigToast(
      `Current panel (Voc=${panelVoc}V) is not compatible with this inverter (VDC max=${newVdcMax}V). Please select a different panel.`,
      "warning",
    );
    current.inverter = oldInverter;
    load.system_voltage = oldSystemVoltage;
    load.voltage_class = oldInverter.voltage_class;
    current.battery_config = savedBatteryConfig;
    e.target.value = oldInverter.id;
    return;
  }

  // Smart target: use max_pv_input as primary target (that's what the inverter can handle)
  // For recommendation: target ~90% of max_pv_input for optimal utilization
  const targetPvWatts = Math.min(newMaxPvInput * 0.9, newMaxPvInput);
  const panelsNeededForTarget = Math.ceil(targetPvWatts / panelWp);

  // Use smart series/parallel calculation
  const smartConfig = calculateSmartSeriesParallel(
    panelVoc,
    panelVmp,
    panelWp,
    newVdcMax,
    newVdcMin,
    newMaxPvInput,
    panelsNeededForTarget,
    mpptCount,
  );

  let optimalPanelCount = smartConfig.error
    ? panelsNeededForTarget
    : smartConfig.actualPanels;

  // Apply limits
  const absoluteMax = Math.floor(newMaxPvInput / panelWp);
  const minPanelsFromLoad = Math.max(
    1,
    Math.ceil(load.peak_load_watts / panelWp),
  );
  const absoluteMin = Math.max(1, minPanelsFromLoad, minSeries);

  optimalPanelCount = Math.max(
    absoluteMin,
    Math.min(optimalPanelCount, absoluteMax),
  );

  // Update panel configuration
  current.panel_config.quantity = optimalPanelCount;
  current.panel_config.total_wattage = optimalPanelCount * panelWp;
  current.panel_config.total_kwp = (
    current.panel_config.total_wattage / 1000
  ).toFixed(2);
  current.panel_config.total_cost =
    optimalPanelCount * parseFloat(panel.price_usd);

  // Update inverter price in total cost
  current.total_cost =
    parseFloat(newInverter.price_usd) +
    current.battery_config.total_cost +
    current.panel_config.total_cost;

  // Update panel limits display
  updatePanelLimits();

  // Recalculate panel series/parallel for new inverter's VDC limits
  recalculatePanelSeriesParallel();

  // CRITICAL: Recalculate system with new configuration
  await recalculateSystem();
  renderConfigurator();
  updateEnergyForecast();
};

/**
 * Change panel (GLOBAL)
 */
window.onPanelChange = async function (e) {
  const panelId = parseInt(e.target.value);
  const newPanel = configuratorState.allPanels.find((p) => p.id === panelId);

  if (!newPanel) return;

  const current = configuratorState.current;
  const inverter = current.inverter;
  const load = configuratorState.loadAnalysis;

  // Get panel specifications
  const oldPanelWp = parseFloat(current.panel_config.panel.watt_peak) || 540;
  const newPanelWp = parseFloat(newPanel.watt_peak) || 540;
  const newPanelVoc = parseFloat(newPanel.voc) || 48;
  const newPanelVmp = parseFloat(newPanel.vmp) || 40;

  // Get inverter specifications
  const invVdcMax = parseFloat(inverter.input_voltage_max) || 500;
  const invVdcMin = parseFloat(inverter.input_voltage_min) || 40;
  const invWatts = parseFloat(inverter.max_load_watts) || 1000;
  const maxPvInput = parseFloat(inverter.max_pv_input) || invWatts;

  // Validate panel compatibility
  const maxSeries = Math.floor(invVdcMax / newPanelVoc);
  const minSeries = Math.max(1, Math.ceil(invVdcMin / newPanelVmp));

  if (maxSeries < minSeries || maxSeries < 1) {
    console.error("   ❌ Panel incompatible!");
    showConfigToast(
      `This panel (Voc=${newPanelVoc}V) is not compatible with the current inverter (VDC: ${invVdcMin}-${invVdcMax}V). Please select a different panel or change the inverter first.`,
      "warning",
    );
    // Revert selection
    e.target.value = current.panel_config.panel.id;
    return;
  }

  // CRITICAL: Update panel in configuration FIRST
  current.panel_config.panel = newPanel;

  // Calculate limits with NEW panel
  const minPanelsFromLoad = Math.max(
    1,
    Math.ceil(load.peak_load_watts / newPanelWp),
  );
  const minPanels = Math.max(1, minPanelsFromLoad, minSeries);

  const maxPanelsFromWattage = Math.floor(maxPvInput / newPanelWp);
  let maxPanels = maxPanelsFromWattage;
  maxPanels = Math.max(minPanels, maxPanels);

  // Calculate optimal panel count for new panel wattage
  const oldTotalWattage = current.panel_config.quantity * oldPanelWp;
  const targetPvWatts = Math.min(
    maxPvInput,
    Math.max(oldTotalWattage, invWatts * 1.0),
  );

  // Calculate optimal panel count
  let optimalPanelCount = Math.ceil(targetPvWatts / newPanelWp);

  // CRITICAL: Clamp to valid range
  optimalPanelCount = Math.max(
    minPanels,
    Math.min(optimalPanelCount, maxPanels),
  );

  const newTotalWattage = optimalPanelCount * newPanelWp;

  current.panel_config.quantity = optimalPanelCount;
  current.panel_config.total_wattage = newTotalWattage;
  current.panel_config.total_kwp = (newTotalWattage / 1000).toFixed(2);
  current.panel_config.total_cost =
    optimalPanelCount * parseFloat(newPanel.price_usd);

  // Update total cost
  current.total_cost =
    parseFloat(inverter.price_usd) +
    current.battery_config.total_cost +
    current.panel_config.total_cost;

  // Update panel limits AFTER setting new panel
  updatePanelLimits();

  await recalculateSystem();
  renderConfigurator();
  updateEnergyForecast();
};

/**
 * Show panel category (NEW - for card-based UI)
 */
window.showPanelCategory = function (wattage) {
  // Update tab active state
  document.querySelectorAll(".panel-category-tab").forEach((tab) => {
    if (tab.dataset.category === wattage) {
      tab.classList.add("active");
    } else {
      tab.classList.remove("active");
    }
  });

  // Update content active state
  document.querySelectorAll(".panel-category-content").forEach((content) => {
    if (content.dataset.category === wattage) {
      content.classList.add("active");
    } else {
      content.classList.remove("active");
    }
  });
};

/**
 * Select panel from card (NEW - for card-based UI)
 */
window.selectPanel = async function (panelId) {
  const newPanel = configuratorState.allPanels.find((p) => p.id === panelId);

  if (!newPanel) return;

  const current = configuratorState.current;
  const inverter = current.inverter;
  const load = configuratorState.loadAnalysis;

  // Get panel specifications
  const oldPanelWp = parseFloat(current.panel_config.panel.watt_peak) || 540;
  const newPanelWp = parseFloat(newPanel.watt_peak) || 540;
  const newPanelVoc = parseFloat(newPanel.voc) || 48;
  const newPanelVmp = parseFloat(newPanel.vmp) || 40;

  // Get inverter specifications
  const invVdcMax = parseFloat(inverter.input_voltage_max) || 500;
  const invVdcMin = parseFloat(inverter.input_voltage_min) || 40;
  const invWatts = parseFloat(inverter.max_load_watts) || 1000;
  const maxPvInput = parseFloat(inverter.max_pv_input) || invWatts;

  // Validate panel compatibility
  const maxSeries = Math.floor(invVdcMax / newPanelVoc);
  const minSeries = Math.max(1, Math.ceil(invVdcMin / newPanelVmp));

  if (maxSeries < minSeries || maxSeries < 1) {
    console.error("   ❌ Panel incompatible!");
    showConfigToast(
      `This panel (Voc=${newPanelVoc}V) is not compatible with the current inverter (VDC: ${invVdcMin}-${invVdcMax}V). Please select a different panel or change the inverter first.`,
      "warning",
    );
    return;
  }

  // CRITICAL: Update panel in configuration FIRST (before calculating limits)
  current.panel_config.panel = newPanel;

  // Calculate limits with NEW panel
  const minPanelsFromLoad = Math.max(
    1,
    Math.ceil(load.peak_load_watts / newPanelWp),
  );
  const minPanels = Math.max(1, minPanelsFromLoad, minSeries);

  const maxPanelsFromWattage = Math.floor(maxPvInput / newPanelWp);
  let maxPanels = maxPanelsFromWattage;
  maxPanels = Math.max(minPanels, maxPanels);

  // Calculate optimal panel count (try to maintain similar total wattage)
  const oldTotalWattage = current.panel_config.quantity * oldPanelWp;
  const targetPvWatts = Math.min(
    maxPvInput,
    Math.max(oldTotalWattage, invWatts * 1.0),
  );

  let optimalPanelCount = Math.ceil(targetPvWatts / newPanelWp);

  // CRITICAL: Clamp to valid range
  optimalPanelCount = Math.max(
    minPanels,
    Math.min(optimalPanelCount, maxPanels),
  );

  // Update panel configuration
  current.panel_config.quantity = optimalPanelCount;
  current.panel_config.total_wattage = optimalPanelCount * newPanelWp;
  current.panel_config.total_kwp = (
    current.panel_config.total_wattage / 1000
  ).toFixed(2);
  current.panel_config.total_cost =
    optimalPanelCount * parseFloat(newPanel.price_usd);

  // Update total cost
  current.total_cost =
    parseFloat(inverter.price_usd) +
    current.battery_config.total_cost +
    current.panel_config.total_cost;

  // Update panel limits display
  updatePanelLimits();

  // Recalculate system
  await recalculateSystem();
  renderConfigurator();
  updateEnergyForecast();
};

/**
 * Get inverter VDC specs with smart fallbacks
 */
function getInverterVdcSpecs(inverter) {
  const invVdcMax =
    parseFloat(inverter.input_voltage_max) ||
    parseFloat(inverter.max_dc_voltage) ||
    (inverter.voltage_class === "12V"
      ? 55
      : inverter.voltage_class === "24V"
        ? 150
        : 500);
  const invVdcMin =
    parseFloat(inverter.input_voltage_min) ||
    parseFloat(inverter.min_dc_voltage) ||
    (inverter.voltage_class === "12V"
      ? 10
      : inverter.voltage_class === "24V"
        ? 20
        : 40);
  const maxPvInput =
    parseFloat(inverter.max_pv_input) || parseFloat(inverter.max_load_watts);
  const inverterWatts = parseFloat(inverter.max_load_watts);
  const mpptCount = parseInt(inverter.mppt_count) || 1;
  return { invVdcMax, invVdcMin, maxPvInput, inverterWatts, mpptCount };
}

/**
 * Calculate smart series/parallel configuration
 * Uses 85% VDC target for safety (cold weather increases Voc)
 */
function calculateSmartSeriesParallel(
  panelVoc,
  panelVmp,
  panelWp,
  invVdcMax,
  invVdcMin,
  maxPvInput,
  totalPanels,
  mpptCount,
) {
  // Series constraints
  const maxSeries = Math.floor(invVdcMax / panelVoc); // absolute max (Voc limit)
  const minSeries = Math.max(1, Math.ceil(invVdcMin / panelVmp)); // must reach MPPT start voltage

  // Target 85% of max VDC for safety margin (cold weather Voc rise ~5-15%)
  const safeVdcTarget = invVdcMax * 0.85;
  let optimalSeries = Math.floor(safeVdcTarget / panelVoc);
  optimalSeries = Math.max(minSeries, Math.min(maxSeries, optimalSeries));

  if (maxSeries < minSeries) {
    return { error: true, maxSeries, minSeries, optimalSeries: 0, parallel: 0 };
  }

  // If totalPanels is given, find best series/parallel fit
  if (totalPanels > 0) {
    let bestSeries = optimalSeries;
    let bestParallel = Math.max(1, Math.ceil(totalPanels / optimalSeries));
    let bestScore = Infinity;

    // Try each valid series count, pick the one closest to total with best VDC utilization
    for (let s = maxSeries; s >= minSeries; s--) {
      const p = Math.max(1, Math.ceil(totalPanels / s));
      const actual = s * p;
      const waste = actual - totalPanels;
      const vdcUsed = s * panelVoc;
      const vdcPct = vdcUsed / invVdcMax;

      // Penalize: waste panels, being too close to VDC max (>90%), being too low (<50%)
      let score = waste * 10;
      if (vdcPct > 0.92) score += 500; // dangerous - too close to max
      if (vdcPct > 0.95) score += 2000; // very dangerous
      if (vdcPct < 0.4) score += 200; // inefficient - too far from optimal

      // Prefer 70-85% VDC utilization (sweet spot)
      if (vdcPct >= 0.7 && vdcPct <= 0.85) score -= 100;

      // MPPT: prefer parallel strings divisible by MPPT count
      if (mpptCount > 1 && p % mpptCount === 0) score -= 50;

      if (
        score < bestScore ||
        (score === bestScore &&
          waste < Math.abs(bestSeries * bestParallel - totalPanels))
      ) {
        bestSeries = s;
        bestParallel = p;
        bestScore = score;
      }
    }

    const vdcUsed = bestSeries * panelVoc;
    const vmpUsed = bestSeries * panelVmp;
    const vdcPct = ((vdcUsed / invVdcMax) * 100).toFixed(1);

    return {
      error: false,
      maxSeries,
      minSeries,
      optimalSeries,
      series: bestSeries,
      parallel: bestParallel,
      actualPanels: bestSeries * bestParallel,
      vdcUsed: Math.round(vdcUsed),
      vmpUsed: Math.round(vmpUsed),
      vdcPct,
      withinVdc: vdcUsed <= invVdcMax,
    };
  }

  return {
    error: false,
    maxSeries,
    minSeries,
    optimalSeries,
    series: optimalSeries,
    parallel: 1,
  };
}

/**
 * Update panel limits display
 */
function updatePanelLimits() {
  const current = configuratorState.current;
  const load = configuratorState.loadAnalysis;
  const panel = current.panel_config.panel;
  const inverter = current.inverter;

  const panelVoc = parseFloat(panel.voc) || 48;
  const panelVmp = parseFloat(panel.vmp) || 40;
  const panelWp = parseFloat(panel.watt_peak) || 540;

  const { invVdcMax, invVdcMin, maxPvInput, inverterWatts, mpptCount } =
    getInverterVdcSpecs(inverter);

  // Series constraints
  const maxSeries = Math.floor(invVdcMax / panelVoc);
  const minSeries = Math.max(1, Math.ceil(invVdcMin / panelVmp));

  if (maxSeries < minSeries) {
    console.error(
      `   ❌ Panel incompatible! Voc (${panelVoc}V) too high for inverter VDC max (${invVdcMax}V)`,
    );
  }

  // MINIMUM PANELS — driven by:
  // 1. Must have at least minSeries panels (to reach MPPT start voltage)
  // 2. Must cover peak load (1× load coverage minimum)
  // 3. At least 1 panel
  const minPanelsFromVdc = minSeries; // minimum to reach inverter's MPPT start voltage
  const minPanelsFromLoad = Math.max(
    1,
    Math.ceil(load.peak_load_watts / panelWp),
  );
  const minPanels = Math.max(1, minPanelsFromVdc, minPanelsFromLoad);

  // MAXIMUM PANELS — driven by max_pv_input wattage
  const maxPanelsFromWattage = Math.floor(maxPvInput / panelWp);
  let maxPanels = maxPanelsFromWattage;
  maxPanels = Math.max(minPanels, maxPanels);

  // Update display
  const minPanelsEl = document.getElementById("min-panels");
  const maxPanelsEl = document.getElementById("max-panels");

  if (minPanelsEl) minPanelsEl.textContent = minPanels;
  if (maxPanelsEl) maxPanelsEl.textContent = maxPanels;

  return { minPanels, maxPanels };
}

/**
 * Render financial analysis and savings
 */
function renderFinancialAnalysis() {
  const current = configuratorState.current;
  const load = configuratorState.loadAnalysis;

  // Calculate WITHOUT solar system (current situation)
  const dailyLoadKwh = load.daily_energy_kwh;
  const monthlyUnitsWithoutSolar = dailyLoadKwh * 30;
  // Use electricity rate from grid info or default
  const gridRate =
    window.appState?.recommendations?.grid_info?.electricity_rate_kwh || 0;
  const pricePerUnit = gridRate > 0 ? gridRate : 25; // Fallback to 25 if unknown
  const monthlyBillWithoutSolar = monthlyUnitsWithoutSolar * pricePerUnit;

  // Calculate WITH solar system
  const solarGenerationPerDay = current.panel_config?.daily_generation_kwh || 0;
  const gridUnitsPerDay = parseFloat(current.grid_units_per_day) || 0;
  const monthlyUnitsWithSolar = gridUnitsPerDay * 30;
  const monthlyBillWithSolar = monthlyUnitsWithSolar * pricePerUnit;

  // Savings
  const monthlySavings = monthlyBillWithoutSolar - monthlyBillWithSolar;
  const yearlySavings = monthlySavings * 12;
  const unitsSavedPerMonth = monthlyUnitsWithoutSolar - monthlyUnitsWithSolar;

  // ROI Calculation
  const systemCost = current.total_cost;
  const paybackMonths = systemCost / monthlySavings;
  const paybackYears = (paybackMonths / 12).toFixed(1);

  // 24-Hour Energy Flow Analysis
  const simulation = current.panel_config?.hourly_simulation || [];
  let solarToLoadsTotal = 0;
  let solarToBatteryTotal = 0;
  let batteryToLoadsTotal = 0;
  let gridToLoadsTotal = 0;
  let batteryChargingHours = 0;
  let batteryDischargingHours = 0;
  let gridActiveHours = 0;

  simulation.forEach((hour, h) => {
    solarToLoadsTotal += hour.solar_to_load || hour.solar_to_loads || 0;
    solarToBatteryTotal += hour.solar_to_battery || 0;
    batteryToLoadsTotal += hour.battery_to_load || hour.battery_to_loads || 0;
    gridToLoadsTotal += hour.grid_to_load || 0;

    if ((hour.solar_to_battery || 0) > 0.01) batteryChargingHours++;
    if ((hour.battery_to_load || hour.battery_to_loads || 0) > 0.01)
      batteryDischargingHours++;
    if ((hour.grid_to_load || 0) > 0.01) gridActiveHours++;
  });

  return `
        <!-- Before vs After Comparison -->
        <div class="before-after-comparison">
            <div class="comparison-column before">
                <div class="comparison-header">
                    <div class="comparison-icon">❌</div>
                    <h4>WITHOUT Solar System</h4>
                    <p>Your Current Situation</p>
                </div>
                <div class="comparison-stats">
                    <div class="stat-row">
                        <span class="stat-label">Daily Load:</span>
                        <span class="stat-value">${dailyLoadKwh.toFixed(2)} kWh</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Monthly Units:</span>
                        <span class="stat-value highlight-red">${monthlyUnitsWithoutSolar.toFixed(0)} units</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Monthly Bill:</span>
                        <span class="stat-value highlight-red">${getCurrencySymbol()}${formatNumber(monthlyBillWithoutSolar)}</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Yearly Cost:</span>
                        <span class="stat-value highlight-red">${getCurrencySymbol()}${formatNumber(monthlyBillWithoutSolar * 12)}</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Grid Dependency:</span>
                        <span class="stat-value highlight-red">100%</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Backup Power:</span>
                        <span class="stat-value highlight-red">0 hours</span>
                    </div>
                </div>
            </div>

            <div class="comparison-arrow">
                <div class="arrow-icon">→</div>
                <div class="arrow-label">UPGRADE TO</div>
            </div>

            <div class="comparison-column after">
                <div class="comparison-header">
                    <div class="comparison-icon">✅</div>
                    <h4>WITH Solar System</h4>
                    <p>Your Future Savings</p>
                </div>
                <div class="comparison-stats">
                    <div class="stat-row">
                        <span class="stat-label">Solar Generation:</span>
                        <span class="stat-value highlight-green">${solarGenerationPerDay.toFixed(2)} kWh/day</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Monthly Units from Grid:</span>
                        <span class="stat-value highlight-green">${monthlyUnitsWithSolar.toFixed(0)} units</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Monthly Bill:</span>
                        <span class="stat-value highlight-green">${getCurrencySymbol()}${formatNumber(monthlyBillWithSolar)}</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Yearly Cost:</span>
                        <span class="stat-value highlight-green">${getCurrencySymbol()}${formatNumber(monthlyBillWithSolar * 12)}</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Energy Independence:</span>
                        <span class="stat-value highlight-green">${current.energy_independence}%</span>
                    </div>
                    <div class="stat-row">
                        <span class="stat-label">Backup Power:</span>
                        <span class="stat-value highlight-green">${current.backup_hours} hours</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Savings Highlight -->
        <div class="savings-highlight">
            <div class="savings-card">
                <div class="savings-icon">💰</div>
                <div class="savings-label">Monthly Savings</div>
                <div class="savings-amount">${getCurrencySymbol()}${formatNumber(monthlySavings)}</div>
                <div class="savings-detail">${unitsSavedPerMonth.toFixed(0)} units saved per month</div>
            </div>
            <div class="savings-card">
                <div class="savings-icon">📅</div>
                <div class="savings-label">Yearly Savings</div>
                <div class="savings-amount">${getCurrencySymbol()}${formatNumber(yearlySavings)}</div>
                <div class="savings-detail">${(unitsSavedPerMonth * 12).toFixed(0)} units saved per year</div>
            </div>
            <div class="savings-card">
                <div class="savings-icon">⏱️</div>
                <div class="savings-label">Payback Period</div>
                <div class="savings-amount">${paybackYears} years</div>
                <div class="savings-detail">System pays for itself in ${Math.ceil(paybackMonths)} months</div>
            </div>
            <div class="savings-card">
                <div class="savings-icon">🎯</div>
                <div class="savings-label">ROI (10 Years)</div>
                <div class="savings-amount">${Math.round(((yearlySavings * 10) / systemCost) * 100)}%</div>
                <div class="savings-detail">${getCurrencySymbol()}${formatNumber(yearlySavings * 10 - systemCost)} profit</div>
            </div>
        </div>

        <!-- 24-Hour Energy Flow Analysis -->
        <div class="energy-flow-analysis">
            <h4>⚡ 24-Hour Energy Flow Breakdown</h4>
            <div class="flow-grid">
                <div class="flow-card solar">
                    <div class="flow-icon">☀️</div>
                    <div class="flow-label">Solar → Loads</div>
                    <div class="flow-value">${solarToLoadsTotal.toFixed(2)} kWh</div>
                    <div class="flow-detail">Direct solar power to appliances</div>
                </div>
                <div class="flow-card battery-charge">
                    <div class="flow-icon">🔋⬆️</div>
                    <div class="flow-label">Solar → Battery</div>
                    <div class="flow-value">${solarToBatteryTotal.toFixed(2)} kWh</div>
                    <div class="flow-detail">Charging for ${batteryChargingHours} hours</div>
                </div>
                <div class="flow-card battery-discharge">
                    <div class="flow-icon">🔋⬇️</div>
                    <div class="flow-label">Battery → Loads</div>
                    <div class="flow-value">${batteryToLoadsTotal.toFixed(2)} kWh</div>
                    <div class="flow-detail">Backup for ${batteryDischargingHours} hours</div>
                </div>
                <div class="flow-card grid">
                    <div class="flow-icon">🔌</div>
                    <div class="flow-label">Grid → Loads</div>
                    <div class="flow-value">${gridToLoadsTotal.toFixed(2)} kWh</div>
                    <div class="flow-detail">Grid active for ${gridActiveHours} hours</div>
                </div>
            </div>
        </div>

        <!-- Battery Impact Simulator -->
        <div class="battery-impact-section">
            <h4>🔋 Battery Impact Analysis</h4>
            <p class="section-subtitle">See how adding more batteries affects your system performance</p>
            <div class="battery-impact-grid">
                ${renderBatteryImpactScenarios()}
            </div>
        </div>
    `;
}

/**
 * Render battery impact scenarios
 */
function renderBatteryImpactScenarios() {
  const current = configuratorState.current;
  const load = configuratorState.loadAnalysis;
  const currentBatteries = current.battery_config.quantity;
  const batteryAh =
    parseFloat(current.battery_config.battery.capacity_ah) || 100;
  const batteryVoltage =
    parseFloat(
      current.battery_config.battery.voltage ||
        current.battery_config.battery.nominal_voltage,
    ) || 12;
  const systemVoltage = parseFloat(load.system_voltage) || 48;
  const dod =
    parseFloat(
      current.battery_config.battery.depth_of_discharge ||
        current.battery_config.dod_percent ||
        50,
    ) / 100;

  // Calculate series needed for this battery voltage
  const seriesNeeded =
    systemVoltage >= batteryVoltage && systemVoltage % batteryVoltage === 0
      ? Math.round(systemVoltage / batteryVoltage)
      : Math.max(1, Math.round(systemVoltage / batteryVoltage));

  // Calculate average load for backup estimation
  const avgLoadW = load.total_load_watts || load.peak_load_watts || 500;

  const scenarios = [];
  // Step by seriesNeeded to ensure valid battery counts
  const minQty = seriesNeeded;
  const maxQty = Math.min(32, currentBatteries + seriesNeeded * 2);
  for (
    let qty = Math.max(minQty, currentBatteries - seriesNeeded);
    qty <= maxQty;
    qty += seriesNeeded
  ) {
    if (qty < seriesNeeded) continue;
    const parallelStrings = Math.floor(qty / seriesNeeded);
    const totalAh = parallelStrings * batteryAh; // Parallel adds Ah
    // Storage = parallel_Ah × battery_voltage × series_count / 1000
    const storageKwh = (totalAh * batteryVoltage * seriesNeeded) / 1000;
    const usableKwh = storageKwh * dod;
    const backupHours = ((usableKwh * 1000 * 0.9) / avgLoadW).toFixed(1); // 0.9 = inverter efficiency
    const cost = qty * parseFloat(current.battery_config.battery.price_usd);
    const isCurrent = qty === currentBatteries;

    scenarios.push(`
            <div class="battery-scenario ${isCurrent ? "current" : ""}">
                ${isCurrent ? '<div class="scenario-badge">CURRENT</div>' : ""}
                <div class="scenario-qty">${qty}× Batteries</div>
                <div class="scenario-stats">
                    <div class="scenario-stat">
                        <span class="stat-label">Total:</span>
                        <span class="stat-value">${totalAh}Ah</span>
                    </div>
                    <div class="scenario-stat">
                        <span class="stat-label">Storage:</span>
                        <span class="stat-value">${storageKwh.toFixed(2)} kWh</span>
                    </div>
                    <div class="scenario-stat">
                        <span class="stat-label">Backup:</span>
                        <span class="stat-value highlight">${backupHours}h</span>
                    </div>
                    <div class="scenario-stat">
                        <span class="stat-label">Cost:</span>
                        <span class="stat-value">${getCurrencySymbol()}${formatNumber(cost)}</span>
                    </div>
                </div>
                ${
                  !isCurrent
                    ? `
                    <button class="scenario-apply-btn" onclick="applyBatteryScenario(${qty})">
                        ${qty > currentBatteries ? "Add Batteries" : "Reduce Batteries"}
                    </button>
                `
                    : '<div class="scenario-current-label">✓ Selected</div>'
                }
            </div>
        `);
  }

  return scenarios.join("");
}

/**
 * Apply battery scenario
 */
window.applyBatteryScenario = async function (quantity) {
  const current = configuratorState.current;
  const load = configuratorState.loadAnalysis;
  const battV =
    parseFloat(
      current.battery_config.battery.voltage ||
        current.battery_config.battery.nominal_voltage,
    ) || 12;
  const sysV = parseFloat(load.system_voltage) || 48;
  const seriesNeeded =
    sysV >= battV && sysV % battV === 0
      ? Math.round(sysV / battV)
      : Math.max(1, Math.round(sysV / battV));

  // Validate and snap to valid multiple of seriesNeeded
  const validQty = Math.max(
    seriesNeeded,
    Math.round(quantity / seriesNeeded) * seriesNeeded,
  );

  if (validQty > 32) {
    showConfigToast("Maximum 32 batteries allowed.", "warning");
    return;
  }

  current.battery_config.quantity = validQty;
  const parallelCount = Math.floor(validQty / seriesNeeded);
  current.battery_config.series = seriesNeeded;
  current.battery_config.parallel = parallelCount;
  current.battery_config.total_ah =
    parallelCount * current.battery_config.battery.capacity_ah;
  current.battery_config.total_cost =
    validQty * parseFloat(current.battery_config.battery.price_usd);

  // Update wiring description
  const bankV = seriesNeeded * battV;
  if (seriesNeeded > 1 && parallelCount > 1) {
    current.battery_config.wiring = `${seriesNeeded}S${parallelCount}P — ${seriesNeeded}×${battV}V in series = ${bankV}V, ${parallelCount} parallel strings`;
  } else if (seriesNeeded > 1) {
    current.battery_config.wiring = `${seriesNeeded}S — ${seriesNeeded}×${battV}V in series = ${bankV}V`;
  } else if (parallelCount > 1) {
    current.battery_config.wiring = `${parallelCount}P — ${parallelCount}×${current.battery_config.battery.capacity_ah}Ah in parallel = ${current.battery_config.total_ah}Ah`;
  } else {
    current.battery_config.wiring = `Single ${battV}V ${current.battery_config.battery.capacity_ah}Ah battery`;
  }

  await recalculateSystem();
  renderConfigurator();
  updateEnergyForecast();
};

/**
 * Render performance metrics
 */
function renderMetrics() {
  const current = configuratorState.current;
  const load = configuratorState.loadAnalysis;

  return `
        <div class="metric-card">
            <div class="metric-icon">🌞</div>
            <div class="metric-label">Energy Independence</div>
            <div class="metric-value">${current.energy_independence}%</div>
            <div class="metric-bar">
                <div class="metric-bar-fill" style="width: ${current.energy_independence}%"></div>
            </div>
        </div>

        <div class="metric-card">
            <div class="metric-icon">⚡</div>
            <div class="metric-label">Backup Hours</div>
            <div class="metric-value">${current.backup_hours}h</div>
            <div class="metric-sub">At full load</div>
        </div>

        <div class="metric-card">
            <div class="metric-icon">📉</div>
            <div class="metric-label">Grid Units/Day</div>
            <div class="metric-value">${current.grid_units_per_day}</div>
            <div class="metric-sub">kWh from grid</div>
        </div>

        <div class="metric-card">
            <div class="metric-icon">💰</div>
            <div class="metric-label">Monthly Savings</div>
            <div class="metric-value">${getCurrencySymbol()}${formatNumber(calculateMonthlySavings())}</div>
            <div class="metric-sub">Estimated</div>
        </div>
    `;
}

/**
 * Render system summary for comparison
 */
function renderSystemSummary(system, type) {
  return `
        <div class="system-summary ${type}">
            <div class="summary-row">
                <span>Inverter:</span>
                <strong>${system.inverter.name}</strong>
            </div>
            <div class="summary-row">
                <span>Batteries:</span>
                <strong>${system.battery_config.quantity} × ${system.battery_config.battery.capacity_ah}Ah</strong>
            </div>
            <div class="summary-row">
                <span>Panels:</span>
                <strong>${system.panel_config.quantity} × ${system.panel_config.panel.watt_peak}W</strong>
            </div>
            <div class="summary-row highlight">
                <span>Total Cost:</span>
                <strong>${getCurrencySymbol()}${formatNumber(system.total_cost)}</strong>
            </div>
            <div class="summary-row">
                <span>Independence:</span>
                <strong>${system.energy_independence}%</strong>
            </div>
            <div class="summary-row">
                <span>Backup:</span>
                <strong>${system.backup_hours}h</strong>
            </div>
        </div>
    `;
}

/**
 * Initialize Chart.js graph
 */
function initializeChart() {
  const canvas = document.getElementById("energy-chart");
  if (!canvas) {
    console.error("❌ Canvas element not found");
    return;
  }

  // Check if Chart.js is loaded
  if (typeof Chart === "undefined") {
    console.error("❌ Chart.js not loaded! Retrying in 500ms...");
    setTimeout(initializeChart, 500);
    return;
  }

  const ctx = canvas.getContext("2d");

  // Destroy existing chart
  if (configuratorState.chart) {
    configuratorState.chart.destroy();
    configuratorState.chart = null;
  }

  // Prepare data
  const chartData = prepareChartData();

  // Verify we have data to display
  const hasData = chartData.datasets.some((ds) => ds.data.some((v) => v > 0));
  if (!hasData) {
    console.warn("⚠️ No chart data available yet, retrying in 300ms...");
    setTimeout(initializeChart, 300);
    return;
  }

  try {
    configuratorState.chart = new Chart(ctx, {
      type: "line",
      data: chartData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        aspectRatio: undefined,
        interaction: {
          mode: "index",
          intersect: false,
        },
        plugins: {
          legend: {
            display: false,
          },
          tooltip: {
            backgroundColor: "rgba(0, 0, 0, 0.8)",
            padding: 12,
            titleFont: {
              size: 14,
              weight: "bold",
            },
            bodyFont: {
              size: 13,
            },
            callbacks: {
              title: function (context) {
                const label = context[0].label;
                // Label is already formatted (e.g., "11AM", "12PM", "1PM")
                if (label.includes("AM")) {
                  const hour = label.replace("AM", "");
                  return (hour === "12" ? "12" : hour) + ":00 AM";
                }
                if (label.includes("PM")) {
                  const hour = label.replace("PM", "");
                  return (hour === "12" ? "12" : hour) + ":00 PM";
                }
                return label;
              },
              label: function (context) {
                return (
                  context.dataset.label +
                  ": " +
                  context.parsed.y.toFixed(2) +
                  " kWh"
                );
              },
            },
          },
        },
        scales: {
          x: {
            title: {
              display: true,
              text: "Hour of Day",
              font: {
                size: 15,
                weight: "bold",
              },
              color: "#0D3B6E",
              padding: { top: 10 },
            },
            ticks: {
              maxRotation: 0,
              minRotation: 0,
              autoSkip: false,
              font: {
                size: 12,
                weight: "600",
              },
              color: "#475569",
              padding: 8,
              callback: function (value, index, ticks) {
                // Rotated hours starting at 11 AM: 11,12,13,...,23,0,1,...,10
                const actualHour = (11 + index) % 24;
                if (actualHour === 11) return "11AM";
                if (actualHour === 12) return "12PM";
                if (actualHour === 18) return "6PM";
                if (actualHour === 0) return "12AM";
                if (actualHour === 6) return "6AM";
                if (actualHour === 10) return "10AM";
                return "";
              },
            },
            grid: {
              display: true,
              color: function (context) {
                const actualHour = (11 + context.tick.value) % 24;
                if (
                  actualHour === 11 ||
                  actualHour === 12 ||
                  actualHour === 18 ||
                  actualHour === 0 ||
                  actualHour === 6 ||
                  actualHour === 10
                ) {
                  return "rgba(0, 0, 0, 0.15)";
                }
                return "rgba(0, 0, 0, 0.05)";
              },
              lineWidth: function (context) {
                const actualHour = (11 + context.tick.value) % 24;
                if (
                  actualHour === 11 ||
                  actualHour === 12 ||
                  actualHour === 18 ||
                  actualHour === 0 ||
                  actualHour === 6 ||
                  actualHour === 10
                ) {
                  return 2;
                }
                return 1;
              },
            },
          },
          y: {
            title: {
              display: true,
              text: "Energy (kWh)",
              font: {
                size: 15,
                weight: "bold",
              },
              color: "#0D3B6E",
              padding: { bottom: 10 },
            },
            beginAtZero: true,
            ticks: {
              font: {
                size: 12,
                weight: "500",
              },
              color: "#475569",
              padding: 8,
              callback: function (value) {
                return value.toFixed(1);
              },
            },
            grid: {
              color: "rgba(0, 0, 0, 0.08)",
              lineWidth: 1,
            },
          },
        },
        elements: {
          line: {
            tension: 0.4,
            borderWidth: 3,
          },
          point: {
            radius: 0,
            hitRadius: 10,
            hoverRadius: 6,
            hoverBorderWidth: 2,
          },
        },
      },
    });
  } catch (error) {
    console.error("❌ Error creating chart:", error);
    canvas.parentElement.innerHTML = `
            <div style="padding: 40px; text-align: center; background: #FEF2F2; border-radius: 12px; border: 2px solid #EF4444;">
                <div style="font-size: 3rem; margin-bottom: 16px;">📊</div>
                <h3 style="color: #DC2626; margin-bottom: 8px;">Graph Unavailable</h3>
                <p style="color: #64748B;">Chart.js failed to load. Please refresh the page.</p>
                <button onclick="location.reload()" style="margin-top: 16px; padding: 8px 16px; background: #EF4444; color: white; border: none; border-radius: 6px; cursor: pointer;">
                    Refresh Page
                </button>
            </div>
        `;
  }
}

/**
 * Prepare chart data from simulation
 */
function prepareChartData() {
  const current = configuratorState.current;
  const simulation = current.panel_config?.hourly_simulation || [];

  // Validate simulation data exists
  if (!simulation || simulation.length === 0) {
    console.error("❌ No simulation data available for chart!");
    return {
      labels: Array.from({ length: 24 }, (_, i) => {
        if (i === 0) return "12AM";
        if (i === 12) return "12PM";
        return i < 12 ? i + "AM" : i - 12 + "PM";
      }),
      datasets: [
        {
          label: "Load Demand",
          data: Array(24).fill(0),
          borderColor: "#EF4444",
          backgroundColor: "rgba(239, 68, 68, 0.08)",
          borderWidth: 3,
          fill: false,
          tension: 0.4,
        },
        {
          label: "Solar Generation",
          data: Array(24).fill(0),
          borderColor: "#10B981",
          backgroundColor: "rgba(16, 185, 129, 0.15)",
          borderWidth: 3,
          fill: true,
          tension: 0.4,
        },
        {
          label: "Battery Level",
          data: Array(24).fill(0),
          borderColor: "#F59E0B",
          backgroundColor: "rgba(245, 158, 11, 0.08)",
          borderWidth: 3,
          fill: false,
          tension: 0.4,
        },
        {
          label: "Grid Usage",
          data: Array(24).fill(0),
          borderColor: "#3B82F6",
          backgroundColor: "rgba(59, 130, 246, 0.12)",
          borderWidth: 3,
          fill: true,
          tension: 0.4,
        },
      ],
    };
  }

  // Chart starts from 11 AM (solar peak) and wraps to 10 AM next day
  // This matches simulation order: battery starts empty at 11 AM, charges from sun
  const SIM_START = 11;
  const rotatedHours = [];
  for (let i = 0; i < 24; i++) {
    rotatedHours.push((SIM_START + i) % 24);
  }

  const load = rotatedHours.map((h) => parseFloat(simulation[h]?.load || 0));
  const solar = rotatedHours.map((h) =>
    parseFloat(simulation[h]?.solar_generated || 0),
  );
  const battery = rotatedHours.map((h) =>
    parseFloat(simulation[h]?.battery_level || 0),
  );
  const grid = rotatedHours.map((h) =>
    parseFloat(simulation[h]?.grid_to_load || 0),
  );

  const labels = rotatedHours.map((h) => {
    if (h === 0) return "12AM";
    if (h === 12) return "12PM";
    return h < 12 ? h + "AM" : h - 12 + "PM";
  });

  return {
    labels: labels,
    datasets: [
      {
        label: "Load Demand",
        data: load,
        borderColor: "#EF4444",
        backgroundColor: "rgba(239, 68, 68, 0.08)",
        borderWidth: 3,
        fill: false,
        tension: 0.4,
        pointBackgroundColor: "#EF4444",
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
      },
      {
        label: "Solar Generation",
        data: solar,
        borderColor: "#10B981",
        backgroundColor: "rgba(16, 185, 129, 0.15)",
        borderWidth: 3,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: "#10B981",
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
      },
      {
        label: "Battery Level",
        data: battery,
        borderColor: "#F59E0B",
        backgroundColor: "rgba(245, 158, 11, 0.08)",
        borderWidth: 3,
        fill: false,
        tension: 0.4,
        pointBackgroundColor: "#F59E0B",
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
      },
      {
        label: "Grid Usage",
        data: grid,
        borderColor: "#3B82F6",
        backgroundColor: "rgba(59, 130, 246, 0.12)",
        borderWidth: 3,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: "#3B82F6",
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
      },
    ],
  };
}

/**
 * Change battery quantity (GLOBAL)
 */
window.changeBatteryQuantity = async function (delta) {
  const current = configuratorState.current;
  const load = configuratorState.loadAnalysis;
  const battV =
    parseFloat(
      current.battery_config.battery.voltage ||
        current.battery_config.battery.nominal_voltage,
    ) || 12;
  const sysV = parseFloat(load.system_voltage) || 48;
  // Calculate series: only standard divisible voltages
  const seriesNeeded =
    sysV >= battV && sysV % battV === 0
      ? Math.round(sysV / battV)
      : Math.max(1, Math.round(sysV / battV));

  // Must add/remove in series multiples
  const step = seriesNeeded;
  const currentQty = current.battery_config.quantity;
  const newQty = currentQty + (delta > 0 ? step : -step);

  // Validate limits
  if (newQty < seriesNeeded) {
    showConfigToast(
      `Minimum ${seriesNeeded} batteries needed (${seriesNeeded}× ${battV}V in series = ${sysV}V)`,
      "warning",
    );
    return;
  }

  // Dynamic battery max: based on practical limits for the system
  // Larger inverters can support more batteries (1 battery per ~500W of inverter capacity, minimum 16)
  const inverterW =
    parseFloat(configuratorState.current.inverter.max_load_watts) || 5000;
  const maxBatteries = Math.max(16, Math.ceil(inverterW / 500));
  if (newQty > maxBatteries) {
    showConfigToast(
      `Maximum ${maxBatteries} batteries for this inverter (${(inverterW / 1000).toFixed(0)}kW).`,
      "warning",
    );
    return;
  }

  // Ensure quantity is a multiple of series_needed
  const validQty = Math.round(newQty / seriesNeeded) * seriesNeeded;
  if (validQty !== newQty) {
    console.warn(
      `⚠️ Adjusting quantity from ${newQty} to ${validQty} (must be multiple of ${seriesNeeded})`,
    );
  }

  current.battery_config.quantity = validQty;

  // Recalculate parallel strings
  const parallelCount = Math.floor(validQty / seriesNeeded);
  current.battery_config.series = seriesNeeded;
  current.battery_config.parallel = parallelCount;
  current.battery_config.total_ah =
    parallelCount * current.battery_config.battery.capacity_ah;
  current.battery_config.total_cost =
    validQty * parseFloat(current.battery_config.battery.price_usd);

  // Update wiring description
  const bankV = seriesNeeded * battV;
  if (seriesNeeded > 1 && parallelCount > 1) {
    current.battery_config.wiring = `${seriesNeeded}S${parallelCount}P — ${seriesNeeded}×${battV}V in series = ${bankV}V, ${parallelCount} parallel strings`;
  } else if (seriesNeeded > 1) {
    current.battery_config.wiring = `${seriesNeeded}S — ${seriesNeeded}×${battV}V in series = ${bankV}V`;
  } else if (parallelCount > 1) {
    current.battery_config.wiring = `${parallelCount}P — ${parallelCount}×${current.battery_config.battery.capacity_ah}Ah in parallel = ${current.battery_config.total_ah}Ah`;
  } else {
    current.battery_config.wiring = `Single ${battV}V ${current.battery_config.battery.capacity_ah}Ah battery`;
  }

  await recalculateSystem();
  // Save scroll position before re-render
  var scrollY = window.scrollY;
  renderConfigurator();
  // Restore scroll position after re-render
  window.scrollTo(0, scrollY);
  updateEnergyForecast();
};

/**
 * Recalculate panel series/parallel configuration using smart algorithm
 */
function recalculatePanelSeriesParallel() {
  const current = configuratorState.current;
  const panel = current.panel_config.panel;
  const inverter = current.inverter;
  const totalPanels = current.panel_config.quantity;

  const vmp = parseFloat(panel.vmp) || 40;
  const voc = parseFloat(panel.voc) || 48;
  const panelWp = parseFloat(panel.watt_peak) || 540;

  const { invVdcMax, invVdcMin, maxPvInput, inverterWatts, mpptCount } =
    getInverterVdcSpecs(inverter);

  const result = calculateSmartSeriesParallel(
    voc,
    vmp,
    panelWp,
    invVdcMax,
    invVdcMin,
    maxPvInput,
    totalPanels,
    mpptCount,
  );

  if (result.error) {
    console.error(
      `❌ Panel incompatible! Series range: ${result.minSeries}-${result.maxSeries}`,
    );
    current.panel_config.series = 1;
    current.panel_config.parallel = totalPanels;
    current.panel_config.wiring = `⚠️ Incompatible`;
    current.panel_config.within_vdc = false;
    return;
  }

  const bestSeries = result.series;
  const bestParallel = result.parallel;
  const vdcUsed = result.vdcUsed;
  const vmpUsed = result.vmpUsed;
  const vdcPct = result.vdcPct;

  current.panel_config.series = bestSeries;
  current.panel_config.parallel = bestParallel;

  // Build detailed wiring description
  let wiringDesc = `${bestSeries}S${bestParallel}P`;
  if (mpptCount > 1 && bestParallel >= mpptCount) {
    const stringsPerMppt = Math.floor(bestParallel / mpptCount);
    const remainder = bestParallel % mpptCount;
    wiringDesc += ` (${mpptCount} MPPT × ${stringsPerMppt} strings`;
    if (remainder > 0) wiringDesc += ` +${remainder}`;
    wiringDesc += `)`;
  }

  current.panel_config.wiring = wiringDesc;
  current.panel_config.wiring_description = `${bestSeries} panels in series × ${bestParallel} strings in parallel`;
  current.panel_config.string_voltage = vmpUsed;
  current.panel_config.string_voltage_voc = vdcUsed;
  current.panel_config.vdc_used = vdcUsed;
  current.panel_config.vdc_limit = Math.round(invVdcMax);
  current.panel_config.within_vdc = result.withinVdc;
  current.panel_config.vdc_utilization = vdcPct;
}

/**
 * Change panel quantity (GLOBAL)
 */
window.changePanelQuantity = async function (delta) {
  const current = configuratorState.current;
  const newQty = current.panel_config.quantity + delta;
  const limits = updatePanelLimits();

  if (newQty < limits.minPanels) {
    showConfigToast(`Minimum ${limits.minPanels} panels required!`, "warning");
    return;
  }
  if (newQty > limits.maxPanels) {
    showConfigToast(`Maximum ${limits.maxPanels} panels allowed!`, "warning");
    return;
  }

  current.panel_config.quantity = newQty;
  current.panel_config.total_wattage =
    newQty * current.panel_config.panel.watt_peak;
  current.panel_config.total_kwp = (
    current.panel_config.total_wattage / 1000
  ).toFixed(2);
  current.panel_config.total_cost =
    newQty * parseFloat(current.panel_config.panel.price_usd);

  recalculatePanelSeriesParallel();
  await recalculateSystem();
  // Save scroll position before re-render
  var scrollY = window.scrollY;
  renderConfigurator();
  // Restore scroll position after re-render
  window.scrollTo(0, scrollY);
  updateEnergyForecast();
};

/**
 * Panel slider change handler – lightweight update without full re-render
 */
window.onPanelSliderChange = function (val) {
  var qty = parseInt(val);
  if (isNaN(qty)) return;
  var current = configuratorState.current;
  current.panel_config.quantity = qty;
  current.panel_config.total_wattage =
    qty * current.panel_config.panel.watt_peak;
  current.panel_config.total_kwp = (
    current.panel_config.total_wattage / 1000
  ).toFixed(2);
  current.panel_config.total_cost =
    qty * parseFloat(current.panel_config.panel.price_usd);
  recalculatePanelSeriesParallel();
  recalculateSystem();
  // Update display WITHOUT full re-render to avoid scroll jump
  updateQuantityDisplays();
  updateEnergyForecast();
};

/**
 * Battery slider change handler – lightweight update without full re-render
 */
window.onBatterySliderChange = function (val) {
  var qty = parseInt(val);
  if (isNaN(qty)) return;
  var current = configuratorState.current;
  var battV =
    parseFloat(
      current.battery_config.battery.voltage ||
        current.battery_config.battery.nominal_voltage,
    ) || 12;
  var sysV = parseFloat(configuratorState.loadAnalysis.system_voltage) || 48;
  var seriesNeeded =
    sysV >= battV && sysV % battV === 0
      ? Math.round(sysV / battV)
      : Math.max(1, Math.round(sysV / battV));
  // Snap to series multiple
  var validQty = Math.round(qty / seriesNeeded) * seriesNeeded;
  if (validQty < seriesNeeded) validQty = seriesNeeded;
  current.battery_config.quantity = validQty;
  var parallelCount = Math.floor(validQty / seriesNeeded);
  current.battery_config.series = seriesNeeded;
  current.battery_config.parallel = parallelCount;
  current.battery_config.total_ah =
    parallelCount * current.battery_config.battery.capacity_ah;
  current.battery_config.total_cost =
    validQty * parseFloat(current.battery_config.battery.price_usd);
  // Update wiring description
  var bankV = seriesNeeded * battV;
  if (seriesNeeded > 1 && parallelCount > 1) {
    current.battery_config.wiring =
      seriesNeeded +
      "S" +
      parallelCount +
      "P — " +
      seriesNeeded +
      "×" +
      battV +
      "V in series = " +
      bankV +
      "V, " +
      parallelCount +
      " parallel strings";
  } else if (seriesNeeded > 1) {
    current.battery_config.wiring =
      seriesNeeded +
      "S — " +
      seriesNeeded +
      "×" +
      battV +
      "V in series = " +
      bankV +
      "V";
  } else if (parallelCount > 1) {
    current.battery_config.wiring =
      parallelCount +
      "P — " +
      parallelCount +
      "×" +
      current.battery_config.battery.capacity_ah +
      "Ah in parallel = " +
      current.battery_config.total_ah +
      "Ah";
  } else {
    current.battery_config.wiring =
      "Single " +
      battV +
      "V " +
      current.battery_config.battery.capacity_ah +
      "Ah battery";
  }
  recalculateSystem();
  updateQuantityDisplays();
  updateEnergyForecast();
};

/**
 * Lightweight display update – updates text/values without full re-render
 */
function updateQuantityDisplays() {
  var current = configuratorState.current;
  // Panel quantity
  var panelQtyEl = document.getElementById("panel-quantity");
  if (panelQtyEl) panelQtyEl.textContent = current.panel_config.quantity;
  // Panel slider sync
  var panelSlider = document.getElementById("panel-slider");
  if (panelSlider) panelSlider.value = current.panel_config.quantity;
  // Battery quantity
  var battQtyEl = document.getElementById("battery-quantity");
  if (battQtyEl) battQtyEl.textContent = current.battery_config.quantity;
  // Battery slider sync
  var battSlider = document.getElementById("battery-slider");
  if (battSlider) battSlider.value = current.battery_config.quantity;
  // Update panel specs inline
  var totalKwpEls = document.querySelectorAll(".cfg-card-solar .cfg-spec-v");
  if (totalKwpEls.length >= 2) {
    totalKwpEls[1].textContent = current.panel_config.total_kwp + " kWp";
  }
  if (totalKwpEls.length >= 3) {
    totalKwpEls[2].textContent =
      current.panel_config.wiring ||
      current.panel_config.series + "S" + current.panel_config.parallel + "P";
  }
  // Update VDC status
  var vdcEl = document.getElementById("vdc-status");
  if (vdcEl) {
    vdcEl.textContent =
      (current.panel_config.vdc_used || "?") +
      "V / " +
      (current.panel_config.vdc_limit ||
        current.inverter.input_voltage_max ||
        "?") +
      "V (" +
      (current.panel_config.vdc_utilization || "?") +
      "%) " +
      (current.panel_config.within_vdc !== false ? "✓" : "⚠️");
  }
  // Update wiring text
  var wiringEl = document.getElementById("wiring-text");
  if (wiringEl) wiringEl.textContent = current.battery_config.wiring || "-";
  // Update panel limits info
  var limitsInfo = document.getElementById("panel-limits-info");
  if (limitsInfo) {
    var lim = updatePanelLimits();
    var minEl = document.getElementById("min-panels");
    var maxEl = document.getElementById("max-panels");
    if (minEl) minEl.textContent = lim.minPanels;
    if (maxEl) maxEl.textContent = lim.maxPanels;
  }
}

/**
 * Recalculate entire system – FULL CLIENT‑SIDE SIMULATION
 * CRITICAL FIX: The simulation now runs in chronological order (11 AM → 10 AM next day)
 * so the chart data matches the real battery behaviour.
 */
async function recalculateSystem() {
  const current = configuratorState.current;
  const load = configuratorState.loadAnalysis;

  // ===== CHECK ON-GRID MODE =====
  const isOnGridSystem = current.needs_battery === false;

  // ===== BATTERY CALCULATIONS =====
  let rawBattKwh = 0,
    usableBattKwh = 0;

  if (isOnGridSystem) {
    current.battery_storage_kwh = "0.00";
    current.usable_storage_kwh = "0.00";
    current.battery_config.total_cost = 0;
  } else {
    const battery = current.battery_config.battery;
    const batteryVoltage =
      parseFloat(battery.voltage || battery.nominal_voltage) || 12;
    const battQty = current.battery_config.quantity;
    const battCapAh = parseFloat(battery.capacity_ah) || 100;
    const dod =
      parseFloat(
        battery.depth_of_discharge || current.battery_config.dod_percent || 50,
      ) / 100;
    const systemVoltage = parseFloat(load.system_voltage) || 48;

    const seriesCount =
      systemVoltage >= batteryVoltage && systemVoltage % batteryVoltage === 0
        ? Math.round(systemVoltage / batteryVoltage)
        : Math.max(1, Math.round(systemVoltage / batteryVoltage));
    const parallelCount = Math.max(1, Math.floor(battQty / seriesCount));
    const actualQty = seriesCount * parallelCount;

    current.battery_config.quantity = actualQty > 0 ? actualQty : battQty;
    current.battery_config.series = seriesCount;
    current.battery_config.parallel = parallelCount;
    current.battery_config.total_ah = parallelCount * battCapAh;
    current.battery_config.total_cost =
      current.battery_config.quantity * parseFloat(battery.price_usd);

    rawBattKwh =
      (current.battery_config.total_ah * batteryVoltage * seriesCount) / 1000;
    usableBattKwh = rawBattKwh * dod;

    const seriesVoltage = batteryVoltage * seriesCount;
    if (seriesCount > 1 && parallelCount > 1) {
      current.battery_config.wiring = `${seriesCount}S${parallelCount}P — ${seriesCount}×${batteryVoltage}V in series = ${seriesVoltage}V, ${parallelCount} strings parallel`;
      current.battery_config.connection_type = "series-parallel";
    } else if (seriesCount > 1) {
      current.battery_config.wiring = `${seriesCount} in series (${batteryVoltage}V×${seriesCount}=${seriesVoltage}V)`;
      current.battery_config.connection_type = "series";
    } else if (parallelCount > 1) {
      current.battery_config.wiring = `${parallelCount} in parallel (${batteryVoltage}V, ${parallelCount}×${battCapAh}Ah=${parallelCount * battCapAh}Ah)`;
      current.battery_config.connection_type = "parallel";
    } else {
      current.battery_config.wiring = `Single battery (${batteryVoltage}V, ${battCapAh}Ah)`;
      current.battery_config.connection_type = "single";
    }

    current.battery_storage_kwh = rawBattKwh.toFixed(2);
    current.usable_storage_kwh = usableBattKwh.toFixed(2);
  }

  // ===== PANEL CALCULATIONS =====
  const panel = current.panel_config.panel;
  const panelQty = current.panel_config.quantity;
  const panelWp = parseFloat(panel.watt_peak || panel.wattage) || 540;

  current.panel_config.total_wattage = panelQty * panelWp;
  current.panel_config.total_kwp = (
    current.panel_config.total_wattage / 1000
  ).toFixed(2);
  current.panel_config.total_cost = panelQty * parseFloat(panel.price_usd);

  // ===== TOTAL COST =====
  current.total_cost =
    parseFloat(current.inverter.price_usd) +
    (isOnGridSystem ? 0 : current.battery_config.total_cost) +
    current.panel_config.total_cost;

  // ===== HOURLY LOAD PROFILE =====
  let hourlyLoad = load.hourly_load;
  if (!hourlyLoad || hourlyLoad.length !== 24) {
    // Fallback: create a typical diurnal load curve
    const peakW = load.peak_load_watts || 500;
    hourlyLoad = [];
    for (let h = 0; h < 24; h++) {
      let factor = 0.4;
      if (h >= 6 && h < 9) factor = 0.7;
      if (h >= 9 && h < 17) factor = 0.5;
      if (h >= 17 && h < 22) factor = 1.0;
      hourlyLoad.push(peakW * factor);
    }
  }

  // ===== SIMULATION CONSTANTS =====
  const solarCurve = [
    0, 0, 0, 0, 0, 0.05, 0.15, 0.3, 0.5, 0.7, 0.85, 1.0, 1.0, 1.0, 1.0, 0.9,
    0.7, 0.4, 0, 0, 0, 0, 0, 0,
  ];
  const totalKwp = parseFloat(current.panel_config.total_kwp);
  const effPanel = 0.95,
    effMppt = 0.97,
    effBattC = 0.9,
    effBattD = 0.9,
    effInv = 0.9,
    effCable = 0.97;
  const effS2L = effPanel * effMppt * effInv * effCable;
  const effS2B = effPanel * effMppt * effBattC * effCable;
  const effB2L = effBattD * effInv * effCable;

  // ===== SIMULATE FULL 24‑HOUR CYCLE =====
  // CRITICAL: Start at 11 AM (sun at peak) with EMPTY battery (0 kWh).
  // Battery charges purely from sunlight – no pre-charging.
  // Simulation order: 11,12,13,...,23,0,1,...,10
  // Then data is stored in 0-23 slots for chart display.

  let battLevel = 0; // Battery starts EMPTY – charges only from sun
  let totalGen = 0,
    solarToLoad = 0,
    solarToBatt = 0,
    battToLoad = 0,
    gridNeeded = 0,
    gridExport = 0;
  const simulation = new Array(24);

  // Simulation runs from 11 AM (hour 11) through to 10 AM next day (hour 10)
  const SIM_START_HOUR = 11;
  const hourOrder = [];
  for (let i = 0; i < 24; i++) {
    hourOrder.push((SIM_START_HOUR + i) % 24);
  }

  hourOrder.forEach((h) => {
    const genKwh = totalKwp * solarCurve[h] * effPanel * effMppt;
    totalGen += genKwh;
    const loadKwh = (hourlyLoad[h] || 0) / 1000 + 0.02;

    let hS2L = 0,
      hS2B = 0,
      hB2L = 0,
      hG2L = 0,
      hExport = 0;

    if (genKwh > 0) {
      const solarNeededForLoad = loadKwh / (effInv * effCable);
      if (genKwh >= solarNeededForLoad) {
        hS2L = loadKwh;
        const excessSolar = genKwh - solarNeededForLoad;
        if (isOnGridSystem) {
          // On-grid: export excess to grid
          hExport = excessSolar * effInv * effCable;
          gridExport += hExport;
        } else if (battLevel < usableBattKwh && excessSolar > 0) {
          const chargeAmount = Math.min(
            excessSolar * effBattC * effCable,
            usableBattKwh - battLevel,
          );
          battLevel += chargeAmount;
          hS2B = chargeAmount;
          // Any remaining excess in hybrid goes to grid too
          const remaining = excessSolar - chargeAmount / (effBattC * effCable);
          if (remaining > 0.01) {
            hExport = remaining * effInv * effCable;
            gridExport += hExport;
          }
        }
      } else {
        hS2L = genKwh * effInv * effCable;
        let deficit = loadKwh - hS2L;
        if (!isOnGridSystem && battLevel > 0 && deficit > 0) {
          const batteryNeeded = deficit / effB2L;
          const batteryUsed = Math.min(batteryNeeded, battLevel);
          battLevel -= batteryUsed;
          hB2L = batteryUsed * effB2L;
          deficit -= hB2L;
        }
        if (deficit > 0) hG2L = deficit;
      }
    } else {
      let deficit = loadKwh;
      if (!isOnGridSystem && battLevel > 0) {
        const batteryNeeded = deficit / effB2L;
        const batteryUsed = Math.min(batteryNeeded, battLevel);
        battLevel -= batteryUsed;
        hB2L = batteryUsed * effB2L;
        deficit -= hB2L;
      }
      if (deficit > 0) hG2L = deficit;
    }

    solarToLoad += hS2L;
    solarToBatt += hS2B;
    battToLoad += hB2L;
    gridNeeded += hG2L;

    simulation[h] = {
      hour: h,
      solar_generated: parseFloat(genKwh.toFixed(3)),
      load: parseFloat(loadKwh.toFixed(3)),
      battery_level: parseFloat(battLevel.toFixed(3)),
      solar_to_load: parseFloat(hS2L.toFixed(3)),
      solar_to_battery: parseFloat(hS2B.toFixed(3)),
      battery_to_load: parseFloat(hB2L.toFixed(3)),
      grid_to_load: parseFloat(hG2L.toFixed(3)),
      grid_export: parseFloat(hExport.toFixed(3)),
    };
  });

  // Ensure all 24 slots are filled (should already be)
  for (let h = 0; h < 24; h++) {
    if (!simulation[h]) {
      simulation[h] = {
        hour: h,
        solar_generated: 0,
        load: 0,
        battery_level: 0,
        solar_to_load: 0,
        solar_to_battery: 0,
        battery_to_load: 0,
        grid_to_load: 0,
      };
    }
  }

  // ===== UPDATE SYSTEM METRICS =====
  current.panel_config.hourly_simulation = simulation;
  current.panel_config.daily_generation_kwh = parseFloat(totalGen.toFixed(2));
  current.panel_config.solar_to_loads_kwh = parseFloat(solarToLoad.toFixed(2));
  current.panel_config.solar_to_battery_kwh = parseFloat(
    solarToBatt.toFixed(2),
  );
  current.panel_config.battery_to_loads_kwh = parseFloat(battToLoad.toFixed(2));
  current.panel_config.grid_energy_needed_kwh = parseFloat(
    gridNeeded.toFixed(2),
  );
  current.grid_export_kwh = parseFloat(gridExport.toFixed(2));
  current.panel_config.system_efficiency_percent =
    totalGen > 0
      ? parseFloat(
          (((solarToLoad + solarToBatt + gridExport) / totalGen) * 100).toFixed(
            1,
          ),
        )
      : 0;
  current.panel_config.inverter_solar_ratio = Math.round(
    (current.panel_config.total_wattage / current.inverter.max_load_watts) *
      100,
  );

  // Backup hours — count only hours with active load (not divide by fixed 11)
  let nightLoadW = 0;
  let nightActiveCount = 0;
  for (let h = 0; h < 6; h++) {
    const hw = hourlyLoad[h] || 0;
    if (hw > 0) {
      nightLoadW += hw;
      nightActiveCount++;
    }
  }
  for (let h = 18; h < 24; h++) {
    const hw = hourlyLoad[h] || 0;
    if (hw > 0) {
      nightLoadW += hw;
      nightActiveCount++;
    }
  }
  const avgNightW =
    nightActiveCount > 0
      ? nightLoadW / nightActiveCount
      : load.peak_load_watts * 0.3;
  current.backup_hours = isOnGridSystem
    ? 0
    : avgNightW > 0
      ? parseFloat(((usableBattKwh * 1000 * effB2L) / avgNightW).toFixed(1))
      : 0;

  const dailyKwh = parseFloat(load.daily_energy_kwh) || 1;
  current.energy_independence = Math.max(
    0,
    Math.min(100, Math.round(((dailyKwh - gridNeeded) / dailyKwh) * 100)),
  );
  current.grid_units_per_day = parseFloat(gridNeeded.toFixed(2));
  current.solar_generation_per_day = parseFloat(totalGen.toFixed(2));

  // Recalculate panel wiring (keeping quantity intact)
  recalculatePanelSeriesParallel();

  updateUI();
}

/**
 * Update UI after recalculation
 */
function updateUI() {
  const current = configuratorState.current;
  const recommended = configuratorState.recommended;

  // Update quantities
  const battQtyEl = document.getElementById("battery-quantity");
  const panelQtyEl = document.getElementById("panel-quantity");
  if (battQtyEl) battQtyEl.textContent = current.battery_config.quantity;
  if (panelQtyEl) panelQtyEl.textContent = current.panel_config.quantity;

  // Update total cost
  const costEl = document.getElementById("total-cost");
  if (costEl) costEl.textContent = cfgFmtPrice(current.total_cost);

  // Cost difference
  const costDiff = current.total_cost - recommended.total_cost;
  const costChangeEl = document.getElementById("cost-change");
  if (costChangeEl) {
    const diffConverted = Math.round(Math.abs(costDiff) * getCurrencyRate());
    if (costDiff > 100) {
      costChangeEl.textContent = `+${getCurrencySymbol()}${diffConverted.toLocaleString()} more`;
      costChangeEl.className = "cost-change increase";
    } else if (costDiff < -100) {
      costChangeEl.textContent = `-${getCurrencySymbol()}${diffConverted.toLocaleString()} less`;
      costChangeEl.className = "cost-change decrease";
    } else {
      costChangeEl.textContent = "Same as recommended";
      costChangeEl.className = "cost-change same";
    }
  }

  // Update wiring text
  const wiringEl = document.getElementById("wiring-text");
  if (wiringEl) wiringEl.textContent = current.battery_config.wiring || "";

  updatePanelLimits();

  // Update energy summary stats
  const load = configuratorState.loadAnalysis;
  const setStat = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  };
  setStat("cfg-solar-day", current.solar_generation_per_day || "0");
  setStat("cfg-usage-day", (parseFloat(load.daily_energy_kwh) || 0).toFixed(1));
  setStat("cfg-grid-day", current.grid_units_per_day || "0");
  setStat("cfg-independence", (current.energy_independence || 0) + "%");
  setStat("cfg-backup", (current.backup_hours || 0) + "h");

  validateSystem();
  // NOTE: forecast update is NOT called here — it happens after renderConfigurator()
  // to avoid chart being destroyed by DOM rebuild
}

/**
 * Trigger energy forecast update (call AFTER renderConfigurator so DOM is settled)
 */
function updateEnergyForecast() {
  if (window.energyForecast && window.energyForecast.updateFromConfigurator) {
    const forecastPayload = Object.assign({}, configuratorState, {
      systemType:
        window.appState?.systemType ||
        configuratorState.current?.system_type ||
        "hybrid",
      netMetering:
        typeof netMeteringEnabled !== "undefined" ? netMeteringEnabled : false,
      sellbackRate: typeof sellbackRate !== "undefined" ? sellbackRate : 80,
    });
    window.energyForecast.updateFromConfigurator(forecastPayload);
  }
}

/**
 * Validate system configuration
 */
function validateSystem() {
  const current = configuratorState.current;
  const load = configuratorState.loadAnalysis;
  const warnings = [];

  const panelWatts = current.panel_config.total_wattage;
  const inverterWatts = current.inverter.max_load_watts;
  const maxPvInput = parseFloat(current.inverter.max_pv_input) || inverterWatts;

  // Only warn if panels exceed the inverter's MAX PV INPUT (not inverter load capacity)
  // Many inverters accept 130-200% PV oversizing via their max_pv_input spec
  if (panelWatts > maxPvInput) {
    warnings.push({
      type: "error",
      icon: "⚠️",
      message: `Solar panels (${(panelWatts / 1000).toFixed(1)}kW) exceed inverter max PV input (${(maxPvInput / 1000).toFixed(1)}kW) by ${Math.round((panelWatts / maxPvInput - 1) * 100)}%`,
      suggestion: `Reduce panels to ${Math.floor(maxPvInput / current.panel_config.panel.watt_peak)} or upgrade inverter`,
    });
  } else if (panelWatts > maxPvInput * 0.95) {
    // Info: near max capacity
    warnings.push({
      type: "warning",
      icon: "📊",
      message: `PV array (${(panelWatts / 1000).toFixed(1)}kW) is at ${Math.round((panelWatts / maxPvInput) * 100)}% of inverter PV capacity`,
      suggestion: "Near maximum — good utilization but no room for expansion",
    });
  }

  // VDC safety check
  if (current.panel_config.vdc_used && current.panel_config.vdc_limit) {
    const vdcPct =
      (current.panel_config.vdc_used / current.panel_config.vdc_limit) * 100;
    if (vdcPct > 95) {
      warnings.push({
        type: "error",
        icon: "⚡",
        message: `String voltage (${current.panel_config.vdc_used}V) is ${vdcPct.toFixed(0)}% of max VDC (${current.panel_config.vdc_limit}V) — dangerous in cold weather!`,
        suggestion: "Reduce panels per string to stay below 90% of max VDC",
      });
    } else if (vdcPct > 90) {
      warnings.push({
        type: "warning",
        icon: "⚡",
        message: `String voltage at ${vdcPct.toFixed(0)}% of max VDC — close to limit`,
        suggestion:
          "Cold weather increases Voc — consider reducing series count",
      });
    }
  }
  if (inverterWatts < load.peak_load_watts) {
    warnings.push({
      type: "error",
      icon: "⚠️",
      message: `Inverter (${inverterWatts}W) is smaller than peak load (${load.peak_load_watts}W)`,
      suggestion: "Upgrade to a larger inverter",
    });
  }
  if (current.backup_hours < 2) {
    warnings.push({
      type: "warning",
      icon: "🔋",
      message: `Battery provides only ${current.backup_hours}h backup`,
      suggestion: "Add more batteries for longer backup time",
    });
  }
  if (warnings.length === 0) {
    warnings.push({
      type: "success",
      icon: "✅",
      message: "System is well balanced and optimized",
      suggestion: "This configuration will work efficiently",
    });
  }

  const container = document.getElementById("validation-warnings");
  if (container) {
    container.innerHTML = warnings
      .map(
        (w) => `
            <div class="validation-alert ${w.type}">
                <div class="alert-icon">${w.icon}</div>
                <div class="alert-content">
                    <div class="alert-message">${w.message}</div>
                    <div class="alert-suggestion">${w.suggestion}</div>
                </div>
            </div>
        `,
      )
      .join("");
  }
}

/**
 * Calculate monthly savings
 */
function calculateMonthlySavings() {
  const current = configuratorState.current;
  const load = configuratorState.loadAnalysis;
  const gridUnitsPerMonth = current.grid_units_per_day * 30;
  const totalUnitsPerMonth = load.daily_energy_kwh * 30;
  const savedUnits = totalUnitsPerMonth - gridUnitsPerMonth;
  return Math.round(savedUnits * 25);
}

/**
 * Reset to recommended system
 */
window.resetToRecommended = async function () {
  configuratorState.current = JSON.parse(
    JSON.stringify(configuratorState.recommended),
  );
  await recalculateSystem();
  renderConfigurator();
  updateEnergyForecast();
};

/**
 * Go back to recommendations
 */
window.goBackToRecommendations = function () {
  // Ensure recommendations are visible when going back
  const recsEl = document.getElementById("recommendations-container");
  const overviewEl = document.getElementById("system-overview-container");
  if (recsEl) recsEl.style.display = "block";
  if (overviewEl) overviewEl.style.display = "none";

  if (typeof goToStep === "function") {
    goToStep(3);
  } else if (typeof window.goToStep === "function") {
    window.goToStep(3);
  } else {
    document
      .querySelectorAll(".step-content")
      .forEach((s) => s.classList.remove("active"));
    const step3 = document.getElementById("step-3");
    if (step3) step3.classList.add("active");
    document.querySelectorAll(".step").forEach((s, i) => {
      s.classList.remove("active");
      if (i < 2) s.classList.add("completed");
      if (i === 2) s.classList.add("active");
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
};

/**
 * Proceed with custom system
 */
window.proceedWithCustomSystem = function () {
  // Ensure panel series/parallel is up to date before showing diagram
  recalculatePanelSeriesParallel();
  window.appState.selectedSystem = configuratorState.current;
  document.getElementById("configurator-container").style.display = "none";
  const forecastSection = document.getElementById("energy-forecast-section");
  if (forecastSection) forecastSection.style.display = "none";
  const guideContainer = document.getElementById("installation-guide");
  guideContainer.style.display = "block";
  if (typeof renderInstallationGuide === "function") {
    renderInstallationGuide(configuratorState.current);
  } else {
    showConfigToast(
      "Installation guide not available. Please refresh the page.",
      "error",
    );
  }
  window.scrollTo({ top: 0, behavior: "smooth" });
};

/**
 * Find nearest dealers stocking selected products
 * Called after configurator renders
 */
function searchNearestDealers() {
  const dealerList = document.getElementById("cfg-dealer-list");
  const dealerSection = document.getElementById("cfg-nearest-dealers");
  if (!dealerList || !dealerSection) return;

  const current = configuratorState.current;
  if (!current) return;

  // Get user location
  const loc = window.appState?.location;
  if (!loc?.lat || !loc?.lng) {
    dealerList.innerHTML =
      '<div class="cfg-dealer-empty">Enable location to find nearby dealers with these products.</div>';
    return;
  }

  // Build product search params
  const inverterId = current.inverter?.id;
  const panelId = current.panel_config?.panel?.id;
  const batteryId = current.battery_config?.battery?.id;
  const cc = loc.country_code || "";

  const BASE = window.BASE_URL || "/solarglobal/";

  // Search dealers via stores AJAX endpoint
  const radius = 200; // Wide search for product availability
  const qs = `ajax=1&lat=${loc.lat}&lng=${loc.lng}&radius=${radius}&country=${cc}`;

  fetch(`${BASE}stores.php?${qs}`)
    .then((r) => r.json())
    .then((data) => {
      const stores = data.stores || [];
      if (!stores.length) {
        dealerList.innerHTML =
          '<div class="cfg-dealer-empty">No dealers found in your country. Products may be available for delivery.</div>';
        return;
      }

      // Show up to 5 nearest dealers
      const top = stores.slice(0, 5);
      let html = "";
      top.forEach((s) => {
        const stars =
          "★".repeat(Math.round(s.rating || 0)) +
          "☆".repeat(5 - Math.round(s.rating || 0));
        html += `<div class="cfg-dealer-card">
                    <div class="cfg-dealer-info">
                        <strong>${escapeHtml(s.name)}</strong>
                        <span class="cfg-dealer-meta">${escapeHtml(s.city)} · ${s.distance} km · <span class="cfg-dealer-stars">${stars}</span></span>
                        <span class="cfg-dealer-products">${s.total_products || 0} products available</span>
                    </div>
                    <a href="${BASE}store-detail.php?id=${s.id}" target="_blank" rel="noopener noreferrer" class="cfg-dealer-visit">Visit Store →</a>
                </div>`;
      });
      dealerList.innerHTML = html;
    })
    .catch(() => {
      dealerList.innerHTML =
        '<div class="cfg-dealer-empty">Could not search for dealers. Try again later.</div>';
    });
}

function escapeHtml(s) {
  if (!s) return "";
  var d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

/**
 * Format number with commas
 */
function formatNumber(num) {
  return Math.round(num)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
