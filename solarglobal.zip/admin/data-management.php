<?php
/**
 * Admin Data Management — Secure data purge for maintenance
 * Requires re-authentication for all destructive operations
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

$pdo = getDB();
$success_message = '';
$error_message = '';
$is_verified = false;

// ── Step 1: Re-authenticate admin ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_password'])) {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid security token.';
    } else {
        $password = $_POST['admin_password'] ?? '';
        $stmt = $pdo->prepare("SELECT password_hash FROM admin_users WHERE id = ?");
        $stmt->execute([$_SESSION['admin_id']]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            $_SESSION['data_mgmt_verified'] = true;
            $_SESSION['data_mgmt_verified_at'] = time();
            $is_verified = true;
        } else {
            $error_message = 'Incorrect password. Access denied.';
            error_log("DATA PURGE: Failed password verification by admin ID " . $_SESSION['admin_id'] . " from IP " . $_SERVER['REMOTE_ADDR']);
        }
    }
}

// Check if already verified (within 10 minutes)
if (!empty($_SESSION['data_mgmt_verified']) && !empty($_SESSION['data_mgmt_verified_at'])) {
    if (time() - $_SESSION['data_mgmt_verified_at'] < 600) {
        $is_verified = true;
    } else {
        unset($_SESSION['data_mgmt_verified'], $_SESSION['data_mgmt_verified_at']);
    }
}

// ── Rate limiting for purge actions ──
if (!isset($_SESSION['purge_attempts'])) {
    $_SESSION['purge_attempts'] = 0;
    $_SESSION['purge_attempt_time'] = time();
}
if (time() - ($_SESSION['purge_attempt_time'] ?? 0) > 3600) {
    $_SESSION['purge_attempts'] = 0;
    $_SESSION['purge_attempt_time'] = time();
}
$purge_blocked = $_SESSION['purge_attempts'] >= 3;

// ── Step 2: Handle purge actions (only if verified) ──
if ($is_verified && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['purge_action']) && !$purge_blocked) {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid security token.';
    } else {
        $confirmation = trim($_POST['confirmation_phrase'] ?? '');
        if ($confirmation !== 'DELETE ALL DATA') {
            $error_message = 'Confirmation phrase does not match. Type exactly: DELETE ALL DATA';
        } else {
            $action = $_POST['purge_action'];
            $older_than_days = max(1, (int)($_POST['older_than_days'] ?? 30));
            $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$older_than_days} days"));

            $_SESSION['purge_attempts']++;

            try {
                $pdo->beginTransaction();
                $deleted_counts = [];

                switch ($action) {
                    case 'purge_installer_orders':
                        $stmt = $pdo->prepare("DELETE FROM installer_orders WHERE status IN ('completed','cancelled') AND created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Installer Orders'] = $stmt->rowCount();
                        break;

                    case 'purge_dealer_orders':
                        $stmt = $pdo->prepare("DELETE FROM orders WHERE status IN ('picked_up','cancelled','refunded') AND created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Dealer Orders'] = $stmt->rowCount();
                        break;

                    case 'purge_reviews':
                        $stmt = $pdo->prepare("DELETE FROM dealer_reviews WHERE status = 'rejected' AND created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Dealer Reviews (rejected)'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM installer_reviews WHERE status = 'rejected' AND created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Installer Reviews (rejected)'] = $stmt->rowCount();
                        break;

                    case 'purge_all_old':
                        $stmt = $pdo->prepare("DELETE FROM installer_orders WHERE status IN ('completed','cancelled') AND created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Installer Orders'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM orders WHERE status IN ('picked_up','cancelled','refunded') AND created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Dealer Orders'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM dealer_reviews WHERE status = 'rejected' AND created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Dealer Reviews (rejected)'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM installer_reviews WHERE status = 'rejected' AND created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Installer Reviews (rejected)'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM email_verifications WHERE created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Email Verifications'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM visitors WHERE visited_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Page Visits'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM visitor_stats WHERE visited_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Visitor Analytics'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM customer_sessions WHERE created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Customer Sessions'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM dealer_sessions WHERE created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Dealer Sessions'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM import_logs WHERE created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Import Logs'] = $stmt->rowCount();
                        break;

                    case 'purge_installation_requests':
                        $stmt = $pdo->prepare("DELETE FROM installation_requests WHERE created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Legacy Installation Requests'] = $stmt->rowCount();
                        break;

                    case 'purge_traffic':
                        // Delete visitors older than X days
                        $stmt = $pdo->prepare("DELETE FROM visitors WHERE visited_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Page Visits'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM visitor_stats WHERE visited_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Visitor Analytics'] = $stmt->rowCount();
                        break;

                    case 'purge_sessions':
                        $stmt = $pdo->prepare("DELETE FROM customer_sessions WHERE created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Customer Sessions'] = $stmt->rowCount();

                        $stmt = $pdo->prepare("DELETE FROM dealer_sessions WHERE created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Dealer Sessions'] = $stmt->rowCount();
                        break;

                    case 'purge_import_logs':
                        $stmt = $pdo->prepare("DELETE FROM import_logs WHERE created_at < ?");
                        $stmt->execute([$cutoff_date]);
                        $deleted_counts['Import Logs'] = $stmt->rowCount();
                        break;

                    default:
                        throw new Exception('Unknown purge action.');
                }

                $pdo->commit();

                $parts = [];
                foreach ($deleted_counts as $label => $cnt) {
                    $parts[] = "$label: $cnt records";
                }
                $success_message = 'Purge completed. ' . implode(', ', $parts) . '.';

                error_log("DATA PURGE: Admin ID {$_SESSION['admin_id']} executed '{$action}' (older than {$older_than_days} days, cutoff: {$cutoff_date}). Results: " . implode(', ', $parts));

            } catch (Exception $e) {
                $pdo->rollBack();
                $error_message = 'Purge failed: ' . $e->getMessage();
                error_log("DATA PURGE ERROR: " . $e->getMessage());
            }
        }
    }
}

// ── Get current data counts for display ──
$data_stats = [];
try {
    $data_stats['installer_orders_total'] = (int)$pdo->query("SELECT COUNT(*) FROM installer_orders")->fetchColumn();
    $data_stats['installer_orders_completed'] = (int)$pdo->query("SELECT COUNT(*) FROM installer_orders WHERE status IN ('completed','cancelled')")->fetchColumn();
    $data_stats['dealer_orders_total'] = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
    $data_stats['dealer_orders_completed'] = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('picked_up','cancelled','refunded')")->fetchColumn();
    $data_stats['dealer_reviews'] = (int)$pdo->query("SELECT COUNT(*) FROM dealer_reviews")->fetchColumn();
    $data_stats['dealer_reviews_rejected'] = (int)$pdo->query("SELECT COUNT(*) FROM dealer_reviews WHERE status = 'rejected'")->fetchColumn();
    $data_stats['installer_reviews'] = (int)$pdo->query("SELECT COUNT(*) FROM installer_reviews")->fetchColumn();
    $data_stats['installer_reviews_rejected'] = (int)$pdo->query("SELECT COUNT(*) FROM installer_reviews WHERE status = 'rejected'")->fetchColumn();
    $data_stats['email_verifications'] = (int)$pdo->query("SELECT COUNT(*) FROM email_verifications")->fetchColumn();
    try { $data_stats['installation_requests'] = (int)$pdo->query("SELECT COUNT(*) FROM installation_requests")->fetchColumn(); } catch (Exception $e) { $data_stats['installation_requests'] = 0; }
    $data_stats['visitors'] = (int)$pdo->query("SELECT COUNT(*) FROM visitors")->fetchColumn();
    $data_stats['visitor_stats'] = (int)$pdo->query("SELECT COUNT(*) FROM visitor_stats")->fetchColumn();
    $data_stats['customer_sessions'] = (int)$pdo->query("SELECT COUNT(*) FROM customer_sessions")->fetchColumn();
    $data_stats['dealer_sessions'] = (int)$pdo->query("SELECT COUNT(*) FROM dealer_sessions")->fetchColumn();
    $data_stats['import_logs'] = (int)$pdo->query("SELECT COUNT(*) FROM import_logs")->fetchColumn();
} catch (Exception $e) { /* silent */ }

$pageTitle = 'Data Management';
include __DIR__ . '/includes/header.php';
?>

<style>
/* ── Data Management Styles ── */
.dm-warning-banner {
    background: linear-gradient(135deg, #DC2626, #991B1B);
    color: #fff;
    padding: 1.25rem 1.5rem;
    border-radius: 12px;
    display: flex;
    align-items: flex-start;
    gap: 1rem;
    margin-bottom: 2rem;
    box-shadow: 0 4px 14px rgba(220, 38, 38, 0.3);
}
.dm-warning-banner .warning-icon {
    font-size: 2rem;
    flex-shrink: 0;
    line-height: 1;
}
.dm-warning-banner h3 {
    margin: 0 0 0.25rem;
    font-size: 1.1rem;
    font-weight: 700;
}
.dm-warning-banner p {
    margin: 0;
    font-size: 0.9rem;
    opacity: 0.92;
    line-height: 1.5;
}

/* ── Alert messages ── */
.dm-alert {
    padding: 1rem 1.25rem;
    border-radius: 10px;
    margin-bottom: 1.5rem;
    font-size: 0.95rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 0.75rem;
}
.dm-alert-success {
    background: #065F46;
    color: #A7F3D0;
    border: 1px solid #10B981;
}
.dm-alert-error {
    background: #7F1D1D;
    color: #FECACA;
    border: 1px solid #EF4444;
}
.dm-alert-blocked {
    background: #78350F;
    color: #FDE68A;
    border: 1px solid #F59E0B;
}

/* ── Stats Grid ── */
.dm-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}
.dm-stat-card {
    background: #1E293B;
    border: 1px solid #334155;
    border-radius: 10px;
    padding: 1.25rem;
    text-align: center;
}
.dm-stat-card .stat-value {
    font-size: 1.75rem;
    font-weight: 700;
    color: #F1F5F9;
    margin-bottom: 0.25rem;
}
.dm-stat-card .stat-label {
    font-size: 0.8rem;
    color: #94A3B8;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.dm-stat-card .stat-sub {
    font-size: 0.78rem;
    color: #EF4444;
    margin-top: 0.35rem;
}

/* ── Verification Form ── */
.dm-verify-card {
    max-width: 480px;
    margin: 2rem auto;
    background: #1E293B;
    border: 1px solid #334155;
    border-radius: 14px;
    padding: 2.5rem 2rem;
    text-align: center;
}
.dm-verify-card .lock-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
    display: block;
}
.dm-verify-card h2 {
    color: #F1F5F9;
    font-size: 1.25rem;
    margin: 0 0 0.5rem;
}
.dm-verify-card p {
    color: #94A3B8;
    font-size: 0.9rem;
    margin: 0 0 1.5rem;
    line-height: 1.5;
}
.dm-verify-card input[type="password"] {
    width: 100%;
    padding: 0.85rem 1rem;
    background: #0F172A;
    border: 1px solid #475569;
    border-radius: 8px;
    color: #F1F5F9;
    font-size: 1rem;
    margin-bottom: 1rem;
    box-sizing: border-box;
    transition: border-color 0.2s;
}
.dm-verify-card input[type="password"]:focus {
    outline: none;
    border-color: #3B82F6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.25);
}
.dm-verify-card .btn-verify {
    width: 100%;
    padding: 0.85rem;
    background: #3B82F6;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
}
.dm-verify-card .btn-verify:hover {
    background: #2563EB;
}

/* ── Purge Cards ── */
.dm-section-title {
    color: #F1F5F9;
    font-size: 1.15rem;
    font-weight: 700;
    margin: 2rem 0 1rem;
    padding-bottom: 0.5rem;
    border-bottom: 1px solid #334155;
}
.dm-purge-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
    gap: 1.25rem;
    margin-bottom: 2rem;
}
.dm-purge-card {
    background: #1E293B;
    border: 1px solid #334155;
    border-radius: 12px;
    padding: 1.5rem;
    position: relative;
    overflow: hidden;
}
.dm-purge-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: #DC2626;
}
.dm-purge-card.card-nuclear::before {
    background: linear-gradient(90deg, #DC2626, #F59E0B, #DC2626);
}
.dm-purge-card h3 {
    color: #F1F5F9;
    font-size: 1.05rem;
    margin: 0 0 0.4rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.dm-purge-card .card-desc {
    color: #94A3B8;
    font-size: 0.85rem;
    margin: 0 0 1rem;
    line-height: 1.5;
}
.dm-purge-card .card-count {
    display: inline-block;
    background: rgba(220, 38, 38, 0.15);
    color: #FCA5A5;
    font-size: 0.8rem;
    font-weight: 600;
    padding: 0.3rem 0.75rem;
    border-radius: 20px;
    margin-bottom: 1rem;
}
.dm-purge-card label {
    display: block;
    color: #CBD5E1;
    font-size: 0.82rem;
    font-weight: 500;
    margin-bottom: 0.35rem;
}
.dm-purge-card select,
.dm-purge-card input[type="text"] {
    width: 100%;
    padding: 0.65rem 0.85rem;
    background: #0F172A;
    border: 1px solid #475569;
    border-radius: 8px;
    color: #F1F5F9;
    font-size: 0.9rem;
    margin-bottom: 0.85rem;
    box-sizing: border-box;
    transition: border-color 0.2s;
}
.dm-purge-card select:focus,
.dm-purge-card input[type="text"]:focus {
    outline: none;
    border-color: #DC2626;
    box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.2);
}
.dm-purge-card input[type="text"]::placeholder {
    color: #64748B;
}
.btn-purge {
    width: 100%;
    padding: 0.8rem;
    background: #DC2626;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 0.95rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    transition: background 0.2s, transform 0.1s;
    margin-top: 0.25rem;
}
.btn-purge:hover {
    background: #B91C1C;
}
.btn-purge:active {
    transform: scale(0.98);
}
.btn-purge:disabled {
    background: #475569;
    cursor: not-allowed;
    opacity: 0.6;
}

/* ── Rate limit banner ── */
.dm-rate-limit {
    text-align: center;
    padding: 2rem;
}
.dm-rate-limit .rl-icon {
    font-size: 3rem;
    display: block;
    margin-bottom: 1rem;
}
.dm-rate-limit h3 {
    color: #FBBF24;
    font-size: 1.15rem;
    margin: 0 0 0.5rem;
}
.dm-rate-limit p {
    color: #94A3B8;
    font-size: 0.9rem;
    margin: 0;
}

/* ── Responsive ── */
@media (max-width: 768px) {
    .dm-stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    .dm-purge-grid {
        grid-template-columns: 1fr;
    }
    .dm-verify-card {
        margin: 1rem auto;
        padding: 2rem 1.25rem;
    }
}
@media (max-width: 480px) {
    .dm-stats-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<!-- Warning Banner -->
<div class="dm-warning-banner">
    <span class="warning-icon">&#9888;</span>
    <div>
        <h3>Destructive Operations Ahead</h3>
        <p>This tool permanently deletes records from the database. Purged data <strong>cannot be recovered</strong>.
           Only completed, cancelled, or rejected records older than the specified timeframe will be removed.
           All actions are logged and rate-limited.</p>
    </div>
</div>

<!-- Flash Messages -->
<?php if ($success_message): ?>
    <div class="dm-alert dm-alert-success">&#10003; <?= htmlspecialchars($success_message) ?></div>
<?php endif; ?>
<?php if ($error_message): ?>
    <div class="dm-alert dm-alert-error">&#10007; <?= htmlspecialchars($error_message) ?></div>
<?php endif; ?>

<!-- Current Data Stats -->
<h2 class="dm-section-title">Current Data Statistics</h2>
<div class="dm-stats-grid">
    <div class="dm-stat-card">
        <div class="stat-value"><?= number_format($data_stats['installer_orders_total'] ?? 0) ?></div>
        <div class="stat-label">Installer Orders</div>
        <div class="stat-sub"><?= number_format($data_stats['installer_orders_completed'] ?? 0) ?> completed/cancelled</div>
    </div>
    <div class="dm-stat-card">
        <div class="stat-value"><?= number_format($data_stats['dealer_orders_total'] ?? 0) ?></div>
        <div class="stat-label">Dealer Orders</div>
        <div class="stat-sub"><?= number_format($data_stats['dealer_orders_completed'] ?? 0) ?> picked up/cancelled/refunded</div>
    </div>
    <div class="dm-stat-card">
        <div class="stat-value"><?= number_format($data_stats['dealer_reviews'] ?? 0) ?></div>
        <div class="stat-label">Dealer Reviews</div>
        <div class="stat-sub"><?= number_format($data_stats['dealer_reviews_rejected'] ?? 0) ?> rejected</div>
    </div>
    <div class="dm-stat-card">
        <div class="stat-value"><?= number_format($data_stats['installer_reviews'] ?? 0) ?></div>
        <div class="stat-label">Installer Reviews</div>
        <div class="stat-sub"><?= number_format($data_stats['installer_reviews_rejected'] ?? 0) ?> rejected</div>
    </div>
    <div class="dm-stat-card">
        <div class="stat-value"><?= number_format($data_stats['email_verifications'] ?? 0) ?></div>
        <div class="stat-label">Email Verifications</div>
        <div class="stat-sub">Verification codes</div>
    </div>
    <div class="dm-stat-card">
        <div class="stat-value"><?= number_format($data_stats['installation_requests'] ?? 0) ?></div>
        <div class="stat-label">Legacy Requests</div>
        <div class="stat-sub">installation_requests table</div>
    </div>
    <div class="dm-stat-card">
        <div class="stat-value"><?= number_format($data_stats['visitors'] ?? 0) ?></div>
        <div class="stat-label">Page Visits</div>
        <div class="stat-sub">visitors table</div>
    </div>
    <div class="dm-stat-card">
        <div class="stat-value"><?= number_format($data_stats['visitor_stats'] ?? 0) ?></div>
        <div class="stat-label">Visitor Analytics</div>
        <div class="stat-sub">visitor_stats table</div>
    </div>
    <div class="dm-stat-card">
        <div class="stat-value"><?= number_format(($data_stats['customer_sessions'] ?? 0) + ($data_stats['dealer_sessions'] ?? 0)) ?></div>
        <div class="stat-label">Login Sessions</div>
        <div class="stat-sub">customer + dealer sessions</div>
    </div>
    <div class="dm-stat-card">
        <div class="stat-value"><?= number_format($data_stats['import_logs'] ?? 0) ?></div>
        <div class="stat-label">Import Logs</div>
        <div class="stat-sub">Product import history</div>
    </div>
</div>

<?php if (!$is_verified): ?>
<!-- ── Password Re-verification ── -->
<div class="dm-verify-card">
    <span class="lock-icon">&#128274;</span>
    <h2>Authentication Required</h2>
    <p>Enter your admin password to access data management tools. This verification expires after 10 minutes.</p>
    <form method="POST" autocomplete="off">
        <?= csrf_field() ?>
        <input type="hidden" name="verify_password" value="1">
        <input type="password" name="admin_password" placeholder="Enter your admin password" required autofocus>
        <button type="submit" class="btn-verify">Verify Identity</button>
    </form>
</div>

<?php else: ?>
<!-- ── Verified: Show Purge Tools ── -->

<?php if ($purge_blocked): ?>
    <div class="dm-alert dm-alert-blocked">&#9888; Rate limit reached: You have used all 3 purge attempts this hour. Please wait before trying again.</div>
    <div class="dm-rate-limit">
        <span class="rl-icon">&#9203;</span>
        <h3>Too Many Attempts</h3>
        <p>For safety, purge actions are limited to 3 per hour per session. Please try again later.</p>
    </div>
<?php else: ?>

<h2 class="dm-section-title">Purge Actions (<?= 3 - ($_SESSION['purge_attempts'] ?? 0) ?> attempts remaining this hour)</h2>

<div class="dm-purge-grid">
    <!-- Purge Installer Orders -->
    <div class="dm-purge-card">
        <h3>&#128465; Purge Old Installer Orders</h3>
        <p class="card-desc">Permanently delete completed and cancelled installer orders older than the specified period.</p>
        <span class="card-count"><?= number_format($data_stats['installer_orders_completed'] ?? 0) ?> eligible records</span>
        <form method="POST" onsubmit="return confirmPurge(this);">
            <?= csrf_field() ?>
            <input type="hidden" name="purge_action" value="purge_installer_orders">
            <label>Keep records from the last:</label>
            <select name="older_than_days">
                <option value="7">Keep last 7 days</option>
                <option value="10">Keep last 10 days</option>
                <option value="30" selected>Keep last 30 days</option>
                <option value="60">Keep last 60 days</option>
                <option value="90">Keep last 90 days</option>
                <option value="180">Keep last 6 months</option>
                <option value="365">Keep last 1 year</option>
            </select>
            <label>Type <strong>DELETE ALL DATA</strong> to confirm:</label>
            <input type="text" name="confirmation_phrase" placeholder="DELETE ALL DATA" autocomplete="off" required>
            <button type="submit" class="btn-purge">&#9888; Purge Installer Orders</button>
        </form>
    </div>

    <!-- Purge Dealer Orders -->
    <div class="dm-purge-card">
        <h3>&#128465; Purge Old Dealer Orders</h3>
        <p class="card-desc">Permanently delete picked-up, cancelled, and refunded dealer orders older than the specified period.</p>
        <span class="card-count"><?= number_format($data_stats['dealer_orders_completed'] ?? 0) ?> eligible records</span>
        <form method="POST" onsubmit="return confirmPurge(this);">
            <?= csrf_field() ?>
            <input type="hidden" name="purge_action" value="purge_dealer_orders">
            <label>Keep records from the last:</label>
            <select name="older_than_days">
                <option value="7">Keep last 7 days</option>
                <option value="10">Keep last 10 days</option>
                <option value="30" selected>Keep last 30 days</option>
                <option value="60">Keep last 60 days</option>
                <option value="90">Keep last 90 days</option>
                <option value="180">Keep last 6 months</option>
                <option value="365">Keep last 1 year</option>
            </select>
            <label>Type <strong>DELETE ALL DATA</strong> to confirm:</label>
            <input type="text" name="confirmation_phrase" placeholder="DELETE ALL DATA" autocomplete="off" required>
            <button type="submit" class="btn-purge">&#9888; Purge Dealer Orders</button>
        </form>
    </div>

    <!-- Purge Rejected Reviews -->
    <div class="dm-purge-card">
        <h3>&#128465; Purge Rejected Reviews</h3>
        <p class="card-desc">Permanently delete rejected dealer and installer reviews older than the specified period.</p>
        <span class="card-count"><?= number_format(($data_stats['dealer_reviews_rejected'] ?? 0) + ($data_stats['installer_reviews_rejected'] ?? 0)) ?> eligible records</span>
        <form method="POST" onsubmit="return confirmPurge(this);">
            <?= csrf_field() ?>
            <input type="hidden" name="purge_action" value="purge_reviews">
            <label>Keep records from the last:</label>
            <select name="older_than_days">
                <option value="7">Keep last 7 days</option>
                <option value="10">Keep last 10 days</option>
                <option value="30" selected>Keep last 30 days</option>
                <option value="60">Keep last 60 days</option>
                <option value="90">Keep last 90 days</option>
                <option value="180">Keep last 6 months</option>
                <option value="365">Keep last 1 year</option>
            </select>
            <label>Type <strong>DELETE ALL DATA</strong> to confirm:</label>
            <input type="text" name="confirmation_phrase" placeholder="DELETE ALL DATA" autocomplete="off" required>
            <button type="submit" class="btn-purge">&#9888; Purge Rejected Reviews</button>
        </form>
    </div>

    <!-- Purge ALL Old Data -->
    <div class="dm-purge-card card-nuclear">
        <h3>&#9762; Purge All Old Data</h3>
        <p class="card-desc">Nuclear option: purge all completed/cancelled orders, rejected reviews, and expired email verifications in one operation.</p>
        <span class="card-count">Combined purge across all tables</span>
        <form method="POST" onsubmit="return confirmPurge(this);">
            <?= csrf_field() ?>
            <input type="hidden" name="purge_action" value="purge_all_old">
            <label>Keep records from the last:</label>
            <select name="older_than_days">
                <option value="7">Keep last 7 days</option>
                <option value="10">Keep last 10 days</option>
                <option value="30" selected>Keep last 30 days</option>
                <option value="60">Keep last 60 days</option>
                <option value="90">Keep last 90 days</option>
                <option value="180">Keep last 6 months</option>
                <option value="365">Keep last 1 year</option>
            </select>
            <label>Type <strong>DELETE ALL DATA</strong> to confirm:</label>
            <input type="text" name="confirmation_phrase" placeholder="DELETE ALL DATA" autocomplete="off" required>
            <button type="submit" class="btn-purge">&#9762; Purge All Old Data</button>
        </form>
    </div>

    <!-- Clear Legacy Requests -->
    <div class="dm-purge-card">
        <h3>&#128465; Clear Legacy Requests</h3>
        <p class="card-desc">Remove old records from the legacy installation_requests table (dealer-oriented, may no longer be in active use).</p>
        <span class="card-count"><?= number_format($data_stats['installation_requests'] ?? 0) ?> total records</span>
        <form method="POST" onsubmit="return confirmPurge(this);">
            <?= csrf_field() ?>
            <input type="hidden" name="purge_action" value="purge_installation_requests">
            <label>Keep records from the last:</label>
            <select name="older_than_days">
                <option value="7">Keep last 7 days</option>
                <option value="10">Keep last 10 days</option>
                <option value="30" selected>Keep last 30 days</option>
                <option value="60">Keep last 60 days</option>
                <option value="90">Keep last 90 days</option>
                <option value="180">Keep last 6 months</option>
                <option value="365">Keep last 1 year</option>
            </select>
            <label>Type <strong>DELETE ALL DATA</strong> to confirm:</label>
            <input type="text" name="confirmation_phrase" placeholder="DELETE ALL DATA" autocomplete="off" required>
            <button type="submit" class="btn-purge">&#9888; Clear Legacy Requests</button>
        </form>
    </div>

    <!-- Purge Traffic Analytics -->
    <div class="dm-purge-card">
        <h3>&#128202; Purge Traffic Analytics</h3>
        <p class="card-desc">Delete page visit logs and visitor analytics data. Keep only recent records for your dashboard.</p>
        <span class="card-count"><?= number_format(($data_stats['visitors'] ?? 0) + ($data_stats['visitor_stats'] ?? 0)) ?> total records</span>
        <form method="POST" onsubmit="return confirmPurge(this);">
            <?= csrf_field() ?>
            <input type="hidden" name="purge_action" value="purge_traffic">
            <label>Keep records from the last:</label>
            <select name="older_than_days">
                <option value="7">Keep last 7 days</option>
                <option value="10">Keep last 10 days</option>
                <option value="30" selected>Keep last 30 days</option>
                <option value="60">Keep last 60 days</option>
                <option value="90">Keep last 90 days</option>
                <option value="180">Keep last 6 months</option>
                <option value="365">Keep last 1 year</option>
            </select>
            <label>Type <strong>DELETE ALL DATA</strong> to confirm:</label>
            <input type="text" name="confirmation_phrase" placeholder="DELETE ALL DATA" autocomplete="off" required>
            <button type="submit" class="btn-purge">&#128202; Purge Traffic Data</button>
        </form>
    </div>

    <!-- Purge Login Sessions -->
    <div class="dm-purge-card">
        <h3>&#128274; Purge Login Sessions</h3>
        <p class="card-desc">Delete expired customer and dealer session records. Keeps active sessions intact.</p>
        <span class="card-count"><?= number_format(($data_stats['customer_sessions'] ?? 0) + ($data_stats['dealer_sessions'] ?? 0)) ?> total records</span>
        <form method="POST" onsubmit="return confirmPurge(this);">
            <?= csrf_field() ?>
            <input type="hidden" name="purge_action" value="purge_sessions">
            <label>Keep records from the last:</label>
            <select name="older_than_days">
                <option value="7">Keep last 7 days</option>
                <option value="10">Keep last 10 days</option>
                <option value="30" selected>Keep last 30 days</option>
                <option value="60">Keep last 60 days</option>
                <option value="90">Keep last 90 days</option>
                <option value="180">Keep last 6 months</option>
                <option value="365">Keep last 1 year</option>
            </select>
            <label>Type <strong>DELETE ALL DATA</strong> to confirm:</label>
            <input type="text" name="confirmation_phrase" placeholder="DELETE ALL DATA" autocomplete="off" required>
            <button type="submit" class="btn-purge">&#128274; Purge Sessions</button>
        </form>
    </div>

    <!-- Purge Import Logs -->
    <div class="dm-purge-card">
        <h3>&#128203; Purge Import Logs</h3>
        <p class="card-desc">Delete old product import history records.</p>
        <span class="card-count"><?= number_format($data_stats['import_logs'] ?? 0) ?> total records</span>
        <form method="POST" onsubmit="return confirmPurge(this);">
            <?= csrf_field() ?>
            <input type="hidden" name="purge_action" value="purge_import_logs">
            <label>Keep records from the last:</label>
            <select name="older_than_days">
                <option value="7">Keep last 7 days</option>
                <option value="10">Keep last 10 days</option>
                <option value="30" selected>Keep last 30 days</option>
                <option value="60">Keep last 60 days</option>
                <option value="90">Keep last 90 days</option>
                <option value="180">Keep last 6 months</option>
                <option value="365">Keep last 1 year</option>
            </select>
            <label>Type <strong>DELETE ALL DATA</strong> to confirm:</label>
            <input type="text" name="confirmation_phrase" placeholder="DELETE ALL DATA" autocomplete="off" required>
            <button type="submit" class="btn-purge">&#128203; Purge Import Logs</button>
        </form>
    </div>
</div>

<?php endif; // purge_blocked ?>
<?php endif; // is_verified ?>

<script>
function confirmPurge(form) {
    var phrase = form.querySelector('input[name="confirmation_phrase"]').value.trim();
    if (phrase !== 'DELETE ALL DATA') {
        alert('You must type exactly: DELETE ALL DATA');
        return false;
    }
    return confirm('FINAL WARNING: This action is irreversible. Are you absolutely sure you want to proceed with this data purge?');
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
