<?php
/**
 * Find Dealer — REDIRECT
 * This page has been consolidated into store.php (Solar Shop).
 * Keeping this file as a redirect for bookmarks/SEO.
 */
require_once 'includes/helpers.php';
header('Location: ' . BASE_URL . 'store.php');
header('HTTP/1.1 301 Moved Permanently');
exit;
