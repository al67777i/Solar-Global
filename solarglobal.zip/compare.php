<?php
require_once 'includes/db.php';
require_once 'includes/helpers.php';
set_security_headers();

// Track visitor
trackVisitor($pdo);

$type = $_GET['type'] ?? 'inverter';
$allowed_types = ['inverter', 'battery', 'panel'];

if (!in_array($type, $allowed_types)) {
    $type = 'inverter';
}

// Get IDs from URL
$ids = isset($_GET['ids']) ? explode(',', $_GET['ids']) : [];
$ids = array_filter(array_map('intval', $ids));

// Limit to 4 items
$ids = array_slice($ids, 0, 4);

$items = [];
$table_name = $type === 'inverter' ? 'inverters' : ($type === 'battery' ? 'batteries' : 'panels');

if (!empty($ids)) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $sql = "SELECT i.*, c.name as company_name, c.country
            FROM $table_name i
            JOIN companies c ON i.company_id = c.id
            WHERE i.id IN ($placeholders) AND i.is_active = 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($ids);
    $items = $stmt->fetchAll();
}

$site_name = get_system_setting('site_name', 'SolarGlobal');
$page_title = "Compare " . ucfirst($type) . "s | " . $site_name;
$page_description = "Compare specifications, prices, and features of multiple " . $type . "s side by side. Make informed decisions for your solar system.";
$current_page = $type . 's';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0D3B6E">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="mobile-web-app-capable" content="yes">
    <title><?php echo $page_title; ?></title>

    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo $page_description; ?>">
    <meta name="robots" content="index, follow">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/frontend.css">
    <link rel="stylesheet" href="assets/css/products.css">
    <link rel="stylesheet" href="assets/css/compare.css">
    <link rel="stylesheet" href="assets/css/mobile-app.css">
</head>
<body>
    <?php include 'includes/header-nav.php'; ?>
    <?php include_once 'includes/ad_display.php'; ?>

    <?php renderAds('header'); ?>

    <!-- Hero Section -->
    <div class="page-hero">
        <div class="container">
            <h1>📊 Compare <?php echo ucfirst($type); ?>s</h1>
            <p>Side-by-side comparison to help you choose the best option</p>
        </div>
    </div>

    <!-- Comparison Container -->
    <div class="compare-container">
        <?php if (empty($items)): ?>
            <!-- Empty State -->
            <div class="compare-empty">
                <div class="empty-icon">📊</div>
                <h2>No <?php echo $type; ?>s selected for comparison</h2>
                <p>Select 2-4 <?php echo $type; ?>s from the product list to compare them side by side</p>
                <a href="<?php echo $type; ?>s.php" class="btn btn-primary">
                    Browse <?php echo ucfirst($type); ?>s
                </a>
            </div>
        <?php elseif (count($items) < 2): ?>
            <!-- Need More Items -->
            <div class="compare-empty">
                <div class="empty-icon">⚠️</div>
                <h2>Add more <?php echo $type; ?>s to compare</h2>
                <p>You need at least 2 <?php echo $type; ?>s to make a comparison</p>
                <a href="<?php echo $type; ?>s.php" class="btn btn-primary">
                    Add More <?php echo ucfirst($type); ?>s
                </a>
            </div>
        <?php else: ?>
            <!-- Comparison Table -->
            <div class="comparison-header">
                <h2>Comparing <?php echo count($items); ?> <?php echo ucfirst($type); ?>s</h2>
                <a href="<?php echo $type; ?>s.php" class="btn btn-secondary">
                    Add More
                </a>
            </div>

            <div class="comparison-table-wrapper">
                <table class="comparison-table">
                    <thead>
                        <tr>
                            <th class="sticky-col">Specification</th>
                            <?php foreach ($items as $item): ?>
                                <th>
                                    <div class="compare-product-header">
                                        <div class="compare-product-icon">
                                            <?php echo $type === 'inverter' ? '⚡' : ($type === 'battery' ? '🔋' : '☀️'); ?>
                                        </div>
                                        <div class="compare-product-company"><?php echo htmlspecialchars($item['company_name']); ?></div>
                                        <?php
                                        $display_name = $item['model'] ?? $item['name'] ?? 'Unknown';
                                        $display_price = $item['unit_price_usd'] ?? $item['price_unit_usd'] ?? $item['price_usd'] ?? 0;
                                        ?>
                                        <div class="compare-product-name"><?php echo htmlspecialchars($display_name); ?></div>
                                        <div class="compare-product-price"><?php echo number_format($display_price); ?></div>
                                        <a href="<?php echo $type; ?>-detail.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-primary">View Details</a>
                                    </div>
                                </th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($type === 'inverter'): ?>
                            <!-- Inverter Comparison -->
                            <tr class="section-header">
                                <td colspan="<?php echo count($items) + 1; ?>"><strong>Basic Information</strong></td>
                            </tr>
                            <tr>
                                <td class="sticky-col">Brand</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php echo htmlspecialchars($item['company_name']); ?> (<?php echo $item['country']; ?>)</td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td class="sticky-col">Type</td>
                                <?php foreach ($items as $item): ?>
                                    <td><span class="badge <?php echo strtolower($item['type']); ?>"><?php echo $item['type']; ?></span></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr class="highlight-row">
                                <td class="sticky-col">Price</td>
                                <?php
                                $prices = array_column($items, 'price_usd');
                                $min_price = min($prices);
                                foreach ($items as $item):
                                    $is_best = $item['price_usd'] == $min_price;
                                ?>
                                    <td class="<?php echo $is_best ? 'best-value' : ''; ?>">
                                        <?php echo number_format($item['price_usd']); ?>
                                        <?php if ($is_best): ?><span class="best-badge">💰 Best Price</span><?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>

                            <tr class="section-header">
                                <td colspan="<?php echo count($items) + 1; ?>"><strong>Power & Performance</strong></td>
                            </tr>
                            <tr class="highlight-row">
                                <td class="sticky-col">Max Load Capacity</td>
                                <?php
                                $watts = array_map(fn($i) => intval($i['output_power_w'] ?? $i['power_rating'] ?? 0), $items);
                                $max_watts = max($watts) ?: 1;
                                foreach ($items as $item):
                                    $item_watts = intval($item['output_power_w'] ?? $item['power_rating'] ?? 0);
                                    $is_best = $item_watts == $max_watts;
                                ?>
                                    <td class="<?php echo $is_best ? 'best-value' : ''; ?>">
                                        <?php echo number_format($item_watts); ?>W
                                        <?php if ($is_best): ?><span class="best-badge">⚡ Highest</span><?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td class="sticky-col">Voltage Class</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php echo $item['vdc_type']; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr class="highlight-row">
                                <td class="sticky-col">Efficiency</td>
                                <?php
                                $efficiencies = array_map(fn($i) => floatval(str_replace('%','', $i['max_efficiency'] ?? $i['efficiency'] ?? 0)), $items);
                                $max_eff = max($efficiencies) ?: 1;
                                foreach ($items as $item):
                                    $item_eff = floatval(str_replace('%','', $item['max_efficiency'] ?? $item['efficiency'] ?? 0));
                                    $is_best = $item_eff == $max_eff;
                                ?>
                                    <td class="<?php echo $is_best ? 'best-value' : ''; ?>">
                                        <?php echo $item_eff; ?>%
                                        <?php if ($is_best): ?><span class="best-badge">⭐ Best</span><?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td class="sticky-col">Surge Power</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php $sp = $item['surge_power_w'] ?? $item['surge_power_watts'] ?? 0; echo $sp ? number_format($sp) . 'W' : 'N/A'; ?></td>
                                <?php endforeach; ?>
                            </tr>

                            <tr class="section-header">
                                <td colspan="<?php echo count($items) + 1; ?>"><strong>Solar Input</strong></td>
                            </tr>
                            <tr>
                                <td class="sticky-col">Input Voltage Range</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php $vmin = $item['min_pv_voltage'] ?? $item['input_voltage_min'] ?? 0; $vmax = $item['max_pv_voltage'] ?? $item['input_voltage_max'] ?? 0; echo ($vmin && $vmax) ? $vmin . 'V - ' . $vmax . 'V' : 'N/A'; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr class="highlight-row">
                                <td class="sticky-col">MPPT Trackers</td>
                                <?php
                                $mppts = array_column($items, 'mppt_count');
                                $max_mppt = max($mppts);
                                foreach ($items as $item):
                                    $is_best = $item['mppt_count'] == $max_mppt;
                                ?>
                                    <td class="<?php echo $is_best ? 'best-value' : ''; ?>">
                                        <?php echo $item['mppt_count']; ?>
                                        <?php if ($is_best && $max_mppt > 1): ?><span class="best-badge">✓ More</span><?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>

                            <tr class="section-header">
                                <td colspan="<?php echo count($items) + 1; ?>"><strong>Build & Protection</strong></td>
                            </tr>
                            <tr>
                                <td class="sticky-col">IP Rating</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php echo $item['ip_rating'] ?? 'N/A'; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr class="highlight-row">
                                <td class="sticky-col">Warranty</td>
                                <?php
                                $warranties = array_column($items, 'warranty_years');
                                $max_warranty = max($warranties);
                                foreach ($items as $item):
                                    $is_best = $item['warranty_years'] == $max_warranty;
                                ?>
                                    <td class="<?php echo $is_best ? 'best-value' : ''; ?>">
                                        <?php echo $item['warranty_years']; ?> Years
                                        <?php if ($is_best): ?><span class="best-badge">🛡️ Longest</span><?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td class="sticky-col">Weight</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php echo $item['weight_kg'] ? $item['weight_kg'] . ' kg' : 'N/A'; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td class="sticky-col">Dimensions</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php echo $item['dimensions'] ?? 'N/A'; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td class="sticky-col">Cooling Method</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php echo $item['cooling_method'] ?? 'N/A'; ?></td>
                                <?php endforeach; ?>
                            </tr>

                            <tr class="section-header">
                                <td colspan="<?php echo count($items) + 1; ?>"><strong>Features</strong></td>
                            </tr>
                            <tr>
                                <td class="sticky-col">Display</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php echo $item['display_type'] ?? 'N/A'; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td class="sticky-col">Communication</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php echo $item['communication'] ?? 'N/A'; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td class="sticky-col">Certifications</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php echo $item['certifications'] ?? 'N/A'; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <td class="sticky-col">Country of Origin</td>
                                <?php foreach ($items as $item): ?>
                                    <td><?php echo $item['country'] ?? $item['country_origin'] ?? 'N/A'; ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endif; ?>

                        <!-- Score Row -->
                        <tr class="section-header">
                            <td colspan="<?php echo count($items) + 1; ?>"><strong>Overall Score</strong></td>
                        </tr>
                        <tr class="score-row">
                            <td class="sticky-col">Recommendation</td>
                            <?php
                            // Calculate min/max values based on type for scoring
                            // Get correct price column by type
                            $prices = array_map(function($i) use ($type) {
                                if ($type === 'inverter') return floatval($i['unit_price_usd'] ?? $i['price_usd'] ?? 0);
                                if ($type === 'battery') return floatval($i['price_unit_usd'] ?? $i['price_usd'] ?? 0);
                                return floatval($i['price_usd'] ?? 0);
                            }, $items);
                            $min_price = !empty($prices) ? max(1, min($prices)) : 1;
                            $max_price = !empty($prices) ? max($prices) : 1;

                            // Type-specific metrics with correct column names
                            if ($type === 'inverter') {
                                $watts = array_map(fn($i) => intval($i['output_power_w'] ?? $i['power_rating'] ?? 0), $items);
                                $max_watts = !empty($watts) ? max($watts) ?: 1 : 1;
                                $efficiencies = array_map(fn($i) => floatval(str_replace('%','', $i['max_efficiency'] ?? $i['efficiency'] ?? 0)), $items);
                                $max_eff = !empty($efficiencies) ? max($efficiencies) ?: 1 : 1;
                            } elseif ($type === 'battery') {
                                $capacities = array_column($items, 'capacity_ah');
                                $max_capacity = !empty($capacities) ? max($capacities) ?: 1 : 1;
                                $voltages = array_map(fn($i) => floatval($i['nominal_voltage'] ?? $i['voltage'] ?? 0), $items);
                                $max_voltage = !empty($voltages) ? max($voltages) ?: 1 : 1;
                            } elseif ($type === 'panel') {
                                $wattages = array_column($items, 'wattage');
                                $max_wattage = !empty($wattages) ? max($wattages) ?: 1 : 1;
                                $efficiencies = array_map(fn($i) => floatval($i['efficiency'] ?? 0), $items);
                                $max_eff = !empty($efficiencies) ? max($efficiencies) ?: 1 : 1;
                            }

                            $warranties = array_column($items, 'warranty_years');
                            $max_warranty = !empty($warranties) ? max($warranties) : 1;

                            // Calculate scores
                            $scores = [];
                            foreach ($items as $item) {
                                $score = 0;

                                // Price score (lower is better, max 25 points)
                                $item_price = ($type === 'inverter') ? floatval($item['unit_price_usd'] ?? $item['price_usd'] ?? 0)
                                           : (($type === 'battery') ? floatval($item['price_unit_usd'] ?? $item['price_usd'] ?? 0)
                                           : floatval($item['price_usd'] ?? 0));
                                if ($min_price > 0) {
                                    $price_score = 25 - (($item_price - $min_price) / $min_price) * 10;
                                    $score += max(0, min(25, $price_score));
                                }

                                // Type-specific performance score (max 25 points)
                                if ($type === 'inverter' && $max_watts > 0) {
                                    $power_score = (intval($item['output_power_w'] ?? $item['power_rating'] ?? 0) / $max_watts) * 25;
                                    $score += $power_score;
                                } elseif ($type === 'battery' && $max_capacity > 0) {
                                    $capacity_score = (($item['capacity_ah'] ?? 0) / $max_capacity) * 25;
                                    $score += $capacity_score;
                                } elseif ($type === 'panel' && $max_wattage > 0) {
                                    $watt_score = (($item['wattage'] ?? 0) / $max_wattage) * 25;
                                    $score += $watt_score;
                                }

                                // Efficiency score (max 25 points) - for inverters and panels
                                if (($type === 'inverter' || $type === 'panel') && $max_eff > 0) {
                                    $eff_score = (($item['efficiency'] ?? 0) / $max_eff) * 25;
                                    $score += $eff_score;
                                } elseif ($type === 'battery' && $max_voltage > 0) {
                                    // For batteries, use voltage as a metric
                                    $voltage_score = (floatval($item['nominal_voltage'] ?? $item['voltage'] ?? 0) / $max_voltage) * 25;
                                    $score += $voltage_score;
                                }

                                // Warranty score (max 25 points)
                                if ($max_warranty > 0) {
                                    $warranty_score = (($item['warranty_years'] ?? 0) / $max_warranty) * 25;
                                    $score += $warranty_score;
                                }

                                $scores[$item['id']] = round($score, 1);
                            }

                            $max_score = max($scores);

                            foreach ($items as $item):
                                $score = $scores[$item['id']];
                                $is_best = $score == $max_score;
                            ?>
                                <td class="<?php echo $is_best ? 'best-value' : ''; ?>">
                                    <div class="score-display">
                                        <div class="score-number"><?php echo $score; ?>/100</div>
                                        <div class="score-bar">
                                            <div class="score-fill" style="width: <?php echo $score; ?>%"></div>
                                        </div>
                                        <?php if ($is_best): ?>
                                            <span class="best-badge">🏆 Best Overall</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pros & Cons -->
            <div class="pros-cons-section">
                <h2>Pros & Cons Analysis</h2>
                <div class="pros-cons-grid">
                    <?php foreach ($items as $item): ?>
                        <div class="pros-cons-card">
                            <h3><?php echo htmlspecialchars($item['name']); ?></h3>

                            <div class="pros">
                                <h4>✓ Pros</h4>
                                <ul>
                                    <?php if ($item['price_usd'] == $min_price): ?>
                                        <li>Most affordable option</li>
                                    <?php endif; ?>

                                    <?php if ($type === 'inverter'): ?>
                                        <?php $iw = intval($item['output_power_w'] ?? $item['power_rating'] ?? 0); ?>
                                        <?php if ($iw == $max_watts): ?>
                                            <li>Highest power capacity</li>
                                        <?php endif; ?>
                                        <?php $ie = floatval(str_replace('%','', $item['max_efficiency'] ?? $item['efficiency'] ?? 0)); ?>
                                        <?php if ($ie == $max_eff): ?>
                                            <li>Best efficiency rating</li>
                                        <?php endif; ?>
                                        <?php if (isset($item['mppt_count']) && $item['mppt_count'] == $max_mppt && $max_mppt > 1): ?>
                                            <li>More MPPT trackers for better solar harvesting</li>
                                        <?php endif; ?>
                                    <?php elseif ($type === 'battery'): ?>
                                        <?php if (isset($item['capacity_ah']) && $item['capacity_ah'] == $max_capacity): ?>
                                            <li>Highest capacity (<?php echo $item['capacity_ah']; ?>Ah)</li>
                                        <?php endif; ?>
                                        <?php $bv = floatval($item['nominal_voltage'] ?? $item['voltage'] ?? 0); ?>
                                        <?php if ($bv == $max_voltage): ?>
                                            <li>Higher voltage (<?php echo $bv; ?>V)</li>
                                        <?php endif; ?>
                                    <?php elseif ($type === 'panel'): ?>
                                        <?php if (isset($item['wattage']) && $item['wattage'] == $max_wattage): ?>
                                            <li>Highest wattage (<?php echo $item['wattage']; ?>W)</li>
                                        <?php endif; ?>
                                        <?php if (isset($item['efficiency']) && $item['efficiency'] == $max_eff): ?>
                                            <li>Best efficiency rating</li>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if (isset($item['warranty_years']) && $item['warranty_years'] == $max_warranty): ?>
                                        <li>Longest warranty period</li>
                                    <?php endif; ?>
                                    <?php if (isset($item['ip_rating']) && $item['ip_rating'] && strpos($item['ip_rating'], '65') !== false): ?>
                                        <li>Excellent weather protection (<?php echo $item['ip_rating']; ?>)</li>
                                    <?php endif; ?>
                                    <?php if (isset($item['communication']) && $item['communication'] && strpos($item['communication'], 'WiFi') !== false): ?>
                                        <li>WiFi monitoring capability</li>
                                    <?php endif; ?>
                                </ul>
                            </div>

                            <div class="cons">
                                <h4>✗ Cons</h4>
                                <ul>
                                    <?php if ($item['price_usd'] > $min_price * 1.5): ?>
                                        <li>Higher price point</li>
                                    <?php endif; ?>

                                    <?php if ($type === 'inverter'): ?>
                                        <?php if ($iw < $max_watts * 0.7): ?>
                                            <li>Lower power capacity</li>
                                        <?php endif; ?>
                                        <?php if ($ie < $max_eff - 2): ?>
                                            <li>Lower efficiency compared to others</li>
                                        <?php endif; ?>
                                    <?php elseif ($type === 'battery'): ?>
                                        <?php if (isset($item['capacity_ah']) && $item['capacity_ah'] < $max_capacity * 0.7): ?>
                                            <li>Lower capacity compared to others</li>
                                        <?php endif; ?>
                                    <?php elseif ($type === 'panel'): ?>
                                        <?php if (isset($item['wattage']) && $item['wattage'] < $max_wattage * 0.7): ?>
                                            <li>Lower wattage compared to others</li>
                                        <?php endif; ?>
                                        <?php if (isset($item['efficiency']) && $item['efficiency'] < $max_eff - 2): ?>
                                            <li>Lower efficiency compared to others</li>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if (isset($item['warranty_years']) && $item['warranty_years'] < $max_warranty): ?>
                                        <li>Shorter warranty period</li>
                                    <?php endif; ?>
                                    <?php if (!$item['display_type'] || $item['display_type'] === 'None'): ?>
                                        <li>No display for monitoring</li>
                                    <?php endif; ?>
                                    <?php if ($item['mppt_count'] < $max_mppt): ?>
                                        <li>Fewer MPPT trackers</li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php renderAds('footer'); ?>

    <?php include 'includes/footer.php'; ?>

    <script src="assets/js/products.js"></script>
</body>
</html>
