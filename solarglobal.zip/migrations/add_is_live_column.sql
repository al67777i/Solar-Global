-- Migration: Add is_live column to dealers and installers tables
-- Run this once in your database to enable the live/offline toggle feature.
-- Defaults to 1 (live) so all existing shops remain visible.

ALTER TABLE dealers
    ADD COLUMN IF NOT EXISTS is_live TINYINT(1) NOT NULL DEFAULT 1
    COMMENT 'Admin toggle: 1 = visible to customers, 0 = hidden from public';

ALTER TABLE installers
    ADD COLUMN IF NOT EXISTS is_live TINYINT(1) NOT NULL DEFAULT 1
    COMMENT 'Admin toggle: 1 = visible to customers, 0 = hidden from public';

-- Optional: add indexes for query performance
CREATE INDEX IF NOT EXISTS idx_dealers_is_live ON dealers (is_live);
CREATE INDEX IF NOT EXISTS idx_installers_is_live ON installers (is_live);
