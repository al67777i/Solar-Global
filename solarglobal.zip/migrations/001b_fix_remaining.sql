USE solar_recommender;

-- Energy forecasts table
CREATE TABLE IF NOT EXISTS energy_forecasts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    city_id INT NOT NULL,
    forecast_date DATE NOT NULL,
    panel_watt_peak INT NOT NULL,
    num_panels INT NOT NULL DEFAULT 1,
    expected_generation_kwh DECIMAL(6,2) NOT NULL,
    weather_factor DECIMAL(4,3) DEFAULT 0.800,
    temperature_loss_percent DECIMAL(4,1) DEFAULT 0.0,
    system_losses_percent DECIMAL(4,1) DEFAULT 20.0,
    net_generation_kwh DECIMAL(6,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE CASCADE,
    INDEX idx_city_date (city_id, forecast_date),
    INDEX idx_date (forecast_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contact messages table
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(200) NOT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    subject VARCHAR(255) DEFAULT NULL,
    message TEXT NOT NULL,
    city_id INT DEFAULT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE SET NULL,
    INDEX idx_read (is_read),
    INDEX idx_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Update appliances with seasonal data
UPDATE appliances SET season_tags = 'summer', usage_hours_summer = 16.0, usage_hours_winter = 0.0 WHERE name_en = 'Ceiling Fan';
UPDATE appliances SET season_tags = 'summer', usage_hours_summer = 12.0, usage_hours_winter = 0.0 WHERE name_en = 'Pedestal Fan';
UPDATE appliances SET season_tags = 'summer,winter', usage_hours_summer = 10.0, usage_hours_winter = 6.0 WHERE name_en = '1-Ton AC Inverter';
UPDATE appliances SET season_tags = 'summer,winter', usage_hours_summer = 10.0, usage_hours_winter = 6.0 WHERE name_en = '1.5-Ton AC Inverter';
UPDATE appliances SET season_tags = 'summer,winter', usage_hours_summer = 10.0, usage_hours_winter = 6.0 WHERE name_en = '2-Ton AC Inverter';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 8.0, usage_hours_winter = 6.0, standby_watts = 2 WHERE name_en = 'LED Bulb 12W';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 8.0, usage_hours_winter = 6.0, standby_watts = 3 WHERE name_en = 'LED Tube Light';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 6.0, usage_hours_winter = 6.0, standby_watts = 2 WHERE name_en = 'CFL Bulb';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 5.0, usage_hours_winter = 5.0, standby_watts = 1 WHERE name_en = 'LED Strip Light';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 24.0, usage_hours_winter = 24.0, standby_watts = 5 WHERE name_en = 'Refrigerator (Small)';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 24.0, usage_hours_winter = 24.0, standby_watts = 8 WHERE name_en = 'Refrigerator (Large)';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 24.0, usage_hours_winter = 24.0, standby_watts = 10 WHERE name_en = 'Deep Freezer';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.5, usage_hours_winter = 0.5 WHERE name_en = 'Microwave Oven';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.3, usage_hours_winter = 0.5 WHERE name_en = 'Electric Kettle';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.5, usage_hours_winter = 0.5 WHERE name_en = 'Rice Cooker';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.3, usage_hours_winter = 0.3 WHERE name_en = 'Blender/Juicer';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.2, usage_hours_winter = 0.3 WHERE name_en = 'Toaster';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 1.0, usage_hours_winter = 1.0 WHERE name_en = 'Washing Machine';
UPDATE appliances SET season_tags = 'winter', usage_hours_summer = 0.0, usage_hours_winter = 1.5 WHERE name_en = 'Dryer';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.5, usage_hours_winter = 1.0 WHERE name_en = 'Iron';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 2.0, usage_hours_winter = 2.0 WHERE name_en = 'Submersible Water Pump';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 2.0, usage_hours_winter = 2.0 WHERE name_en = 'Surface Water Pump';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 8.0, usage_hours_winter = 8.0, standby_watts = 5 WHERE name_en = 'Water Dispenser (Hot+Cold)';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 5.0, usage_hours_winter = 4.0, standby_watts = 1 WHERE name_en = 'LED TV 32 inch';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 5.0, usage_hours_winter = 4.0, standby_watts = 2 WHERE name_en = 'LED TV 55 inch';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 6.0, usage_hours_winter = 6.0, standby_watts = 2 WHERE name_en = 'Laptop';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 6.0, usage_hours_winter = 6.0, standby_watts = 5 WHERE name_en = 'Desktop Computer';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 3.0, usage_hours_winter = 3.0, standby_watts = 1 WHERE name_en = 'Phone Charger';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 24.0, usage_hours_winter = 24.0, standby_watts = 10 WHERE name_en = 'WiFi Router';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 24.0, usage_hours_winter = 24.0, standby_watts = 15 WHERE name_en = 'Security Camera System';
UPDATE appliances SET season_tags = 'winter', usage_hours_summer = 0.0, usage_hours_winter = 2.0 WHERE name_en = 'Electric Geyser';
UPDATE appliances SET season_tags = 'summer', usage_hours_summer = 10.0, usage_hours_winter = 2.0 WHERE name_en = 'Exhaust Fan';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.5, usage_hours_winter = 0.5 WHERE name_en = 'Laser Printer';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 3.0, usage_hours_winter = 3.0 WHERE name_en = 'Sewing Machine (Electric)';
UPDATE appliances SET season_tags = 'all_year', usage_hours_summer = 0.5, usage_hours_winter = 0.5 WHERE name_en = 'Flour Mill (Small)';

-- Seasonal Appliance Mapping data
INSERT INTO seasonal_appliance_mapping (appliance_id, season, usage_probability, priority_rank, recommended_hours, notes) VALUES
(1, 'summer', 1.00, 1, 16.0, 'Essential in Pakistani summers'),
(1, 'spring', 0.70, 3, 8.0, 'Used on warm days'),
(1, 'monsoon', 0.90, 2, 12.0, 'Humidity makes fans essential'),
(1, 'winter', 0.05, 10, 0.0, 'Rarely used in winter'),
(2, 'summer', 0.85, 2, 10.0, 'Supplementary cooling'),
(2, 'monsoon', 0.75, 3, 8.0, 'Used with humidity'),
(2, 'winter', 0.02, 10, 0.0, 'Not used'),
(3, 'summer', 0.95, 1, 10.0, 'Essential cooling'),
(3, 'winter', 0.40, 5, 4.0, 'Used for heating in some homes'),
(3, 'spring', 0.30, 6, 3.0, 'Occasional use'),
(4, 'summer', 0.95, 1, 10.0, 'Essential cooling'),
(4, 'winter', 0.35, 5, 4.0, 'Heating mode'),
(4, 'spring', 0.25, 6, 3.0, 'Occasional'),
(5, 'summer', 0.90, 1, 10.0, 'Large room cooling'),
(5, 'winter', 0.30, 5, 4.0, 'Heating mode'),
(6, 'all_year', 1.00, 1, 8.0, 'Always needed'),
(7, 'all_year', 1.00, 1, 8.0, 'Always needed'),
(8, 'all_year', 0.80, 2, 6.0, 'Common backup'),
(9, 'all_year', 0.60, 4, 5.0, 'Decorative/ambient'),
(10, 'all_year', 1.00, 1, 24.0, 'Essential - runs 24/7'),
(11, 'all_year', 1.00, 1, 24.0, 'Essential - runs 24/7'),
(12, 'all_year', 0.70, 3, 24.0, 'Common in larger homes'),
(13, 'all_year', 0.75, 4, 0.5, 'Used briefly'),
(14, 'all_year', 0.85, 3, 0.5, 'Tea/chai essential'),
(15, 'all_year', 0.60, 5, 0.5, 'Depends on family'),
(16, 'all_year', 0.80, 4, 0.3, 'Quick use'),
(17, 'all_year', 0.70, 5, 0.2, 'Breakfast item'),
(18, 'all_year', 0.90, 2, 1.0, 'Regular laundry'),
(19, 'winter', 0.40, 6, 1.5, 'Winter drying'),
(19, 'monsoon', 0.60, 4, 2.0, 'Wet season drying'),
(20, 'all_year', 0.85, 3, 0.5, 'Regular ironing'),
(21, 'all_year', 0.70, 2, 2.0, 'Water supply'),
(22, 'all_year', 0.65, 2, 2.0, 'Water supply'),
(23, 'all_year', 0.50, 5, 8.0, 'Modern homes'),
(24, 'all_year', 0.90, 3, 5.0, 'Entertainment'),
(25, 'all_year', 0.70, 4, 5.0, 'Entertainment'),
(26, 'all_year', 0.80, 3, 6.0, 'Work/study'),
(27, 'all_year', 0.40, 5, 6.0, 'Work'),
(28, 'all_year', 0.95, 2, 3.0, 'Essential'),
(29, 'all_year', 1.00, 1, 24.0, 'Always on'),
(30, 'all_year', 0.50, 3, 24.0, 'Security essential when installed'),
(31, 'winter', 1.00, 1, 2.0, 'Essential for hot water in winter'),
(31, 'spring', 0.30, 7, 0.5, 'Occasional use'),
(31, 'summer', 0.05, 10, 0.0, 'Not needed'),
(32, 'summer', 0.80, 3, 8.0, 'Kitchen ventilation'),
(32, 'all_year', 0.60, 4, 4.0, 'Bathroom use'),
(33, 'all_year', 0.30, 7, 0.5, 'Occasional use'),
(34, 'all_year', 0.35, 6, 3.0, 'Household tailoring'),
(35, 'all_year', 0.40, 5, 0.5, 'Weekly grinding');
