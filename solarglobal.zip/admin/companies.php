<?php
/**
 * Companies Management - View, Edit, Logo Upload, CSV Import
 */
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/csrf.php';
require_once '../includes/helpers.php';

$db = getDB();
$message = '';
$error = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid CSRF token.';
    } else {
        $action = $_POST['action'] ?? '';

        // ── Edit Company ────────────────────────────────────────────────────
        if ($action === 'edit_company') {
            $companyId = intval($_POST['company_id'] ?? 0);
            $name      = trim($_POST['name'] ?? '');
            $country   = trim($_POST['country'] ?? '');
            $website   = trim($_POST['website'] ?? '');
            $desc      = trim($_POST['description'] ?? '');

            if ($companyId <= 0 || empty($name)) {
                $error = 'Company name is required.';
            } else {
                // Check for duplicate name (excluding this id)
                $check = $db->prepare("SELECT id FROM companies WHERE name = ? AND id != ?");
                $check->execute([$name, $companyId]);
                if ($check->fetch()) {
                    $error = 'A company with that name already exists.';
                } else {
                    // Build slug from name
                    $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $name));
                    $slug = trim($slug, '-');
                    $db->prepare("UPDATE companies SET name=?, slug=?, country=?, website=?, description=? WHERE id=?")
                       ->execute([$name, $slug, $country, $website, $desc, $companyId]);
                    $message = 'Company updated successfully.';
                }
            }
        }

        // ── CSV Import ──────────────────────────────────────────────────────
        if ($action === 'import_csv') {
            if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
                $error = 'Please upload a valid CSV file.';
            } else {
                $file = $_FILES['csv_file'];
                $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if ($ext !== 'csv') {
                    $error = 'Only CSV files are allowed.';
                } else {
                    $handle   = fopen($file['tmp_name'], 'r');
                    $headers  = fgetcsv($handle);
                    if ($headers === false) {
                        $error = 'CSV file is empty.';
                    } else {
                        $headers  = array_map(fn($h) => strtolower(trim($h)), $headers);
                        $inserted = $updated = $skipped = 0;

                        while (($row = fgetcsv($handle)) !== false) {
                            $data = [];
                            foreach ($headers as $i => $h) {
                                $data[$h] = isset($row[$i]) ? trim($row[$i]) : '';
                            }
                            $name = $data['name'] ?? '';
                            if (empty($name)) { $skipped++; continue; }

                            $country = $data['country'] ?? '';
                            $desc    = $data['description'] ?? '';
                            $website = $data['website'] ?? '';

                            $stmt = $db->prepare("SELECT id FROM companies WHERE name = ?");
                            $stmt->execute([$name]);
                            $existing = $stmt->fetch();

                            if ($existing) {
                                $updates = []; $params = [];
                                if (!empty($country)) { $updates[] = 'country=?'; $params[] = $country; }
                                if (!empty($desc))    { $updates[] = 'description=?'; $params[] = $desc; }
                                if (!empty($website)) { $updates[] = 'website=?'; $params[] = $website; }
                                if (!empty($updates)) {
                                    $params[] = $existing['id'];
                                    $db->prepare("UPDATE companies SET ".implode(',', $updates)." WHERE id=?")->execute($params);
                                }
                                $updated++;
                            } else {
                                $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $name));
                                $slug = trim($slug, '-');
                                $db->prepare("INSERT INTO companies (name, slug, country, website, description, is_active) VALUES (?,?,?,?,?,1)")
                                   ->execute([$name, $slug, $country, $website, $desc]);
                                $inserted++;
                            }
                        }
                        fclose($handle);
                        $message = "CSV imported: $inserted new, $updated updated, $skipped skipped.";
                    }
                }
            }
        }

        // ── Bulk Logo Upload ────────────────────────────────────────────────
        if ($action === 'bulk_logos') {
            if (!isset($_FILES['logos']) || !is_array($_FILES['logos']['name'])) {
                $error = 'Please select logo files.';
            } else {
                $matched   = 0;
                $unmatched = [];
                $fileCount = count($_FILES['logos']['name']);

                for ($i = 0; $i < $fileCount; $i++) {
                    if ($_FILES['logos']['error'][$i] !== UPLOAD_ERR_OK) continue;
                    $originalName    = $_FILES['logos']['name'][$i];
                    $companyName     = pathinfo($originalName, PATHINFO_FILENAME);
                    $companyNameClean = str_replace(['_', '-'], ' ', $companyName);

                    $stmt = $db->prepare("SELECT id, name FROM companies WHERE name = ? OR name = ?");
                    $stmt->execute([$companyName, $companyNameClean]);
                    $company = $stmt->fetch();

                    if ($company) {
                        $tmpFile = ['name' => $originalName, 'tmp_name' => $_FILES['logos']['tmp_name'][$i],
                                    'size' => $_FILES['logos']['size'][$i], 'error' => $_FILES['logos']['error'][$i],
                                    'type' => $_FILES['logos']['type'][$i]];
                        $result = handle_image_upload($tmpFile, '../uploads/companies/');
                        if ($result['success']) {
                            $db->prepare("UPDATE companies SET logo_path=? WHERE id=?")->execute([$result['path'], $company['id']]);
                            $matched++;
                        }
                    } else {
                        $unmatched[] = $originalName;
                    }
                }
                $message = "$matched logos matched and uploaded.";
                if (!empty($unmatched)) {
                    $error = count($unmatched)." files unmatched: ".implode(', ', array_slice($unmatched, 0, 10));
                    if (count($unmatched) > 10) $error .= '...';
                }
            }
        }

        // ── Single Logo Upload ──────────────────────────────────────────────
        if ($action === 'update_logo') {
            $companyId = intval($_POST['company_id'] ?? 0);
            if ($companyId > 0 && isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                $result = handle_image_upload($_FILES['logo'], '../uploads/companies/');
                if ($result['success']) {
                    $db->prepare("UPDATE companies SET logo_path=? WHERE id=?")->execute([$result['path'], $companyId]);
                    $message = 'Logo updated!';
                } else {
                    $error = 'Upload failed: '.($result['error'] ?? 'Unknown error');
                }
            }
        }
    }
}

// Search/filter
$search = trim($_GET['q'] ?? '');
$sort   = $_GET['sort'] ?? 'name';

// ═══════════════════════════════════════════════════════════════════════════
// PAGINATION - Professional Implementation
// ═══════════════════════════════════════════════════════════════════════════
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 50; // Show 50 companies per page (adjust as needed)
$offset = ($page - 1) * $per_page;

// Count total companies (for pagination)
$countSql = "SELECT COUNT(*) as total FROM companies c";
$countParams = [];
if (!empty($search)) {
    $countSql .= " WHERE c.name LIKE ?";
    $countParams[] = "%$search%";
}
$countStmt = $db->prepare($countSql);
$countStmt->execute($countParams);
$totalCount = $countStmt->fetch()['total'];
$totalPages = max(1, ceil($totalCount / $per_page));

// Ensure page is within bounds
if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $per_page;
}

// Fetch companies with product counts (collation-safe: no LOWER on indexed cols)
// NOW WITH PAGINATION
$sql = "SELECT c.*,
    (SELECT COUNT(*) FROM inverters WHERE company_id=c.id AND is_active=1) AS inverter_count,
    (SELECT COUNT(*) FROM batteries WHERE company_id=c.id AND is_active=1) AS battery_count,
    (SELECT COUNT(*) FROM panels   WHERE company_id=c.id AND is_active=1) AS panel_count
    FROM companies c";

$params = [];
if (!empty($search)) {
    $sql   .= " WHERE c.name LIKE ?";
    $params[] = "%$search%";
}

if ($sort === 'products') {
    $sql .= " ORDER BY (SELECT COUNT(*) FROM inverters WHERE company_id=c.id)+(SELECT COUNT(*) FROM batteries WHERE company_id=c.id)+(SELECT COUNT(*) FROM panels WHERE company_id=c.id) DESC";
} elseif ($sort === 'country') {
    $sql .= " ORDER BY c.country ASC, c.name ASC";
} else {
    $sql .= " ORDER BY c.name ASC";
}

// Add pagination LIMIT
$sql .= " LIMIT ? OFFSET ?";
$params[] = $per_page;
$params[] = $offset;

$stmt      = $db->prepare($sql);
$stmt->execute($params);
$companies = $stmt->fetchAll();

$totalProducts = 0;
foreach ($companies as $c) {
    $totalProducts += $c['inverter_count'] + $c['battery_count'] + $c['panel_count'];
}

$pageTitle = "Companies";
include 'includes/header.php';
?>

<style>
    .companies-header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:20px;}
    .companies-header h2{margin:0;}
    .header-actions{display:flex;gap:8px;flex-wrap:wrap;}
    .btn-sm{padding:8px 14px;border-radius:6px;font-size:13px;font-weight:500;border:none;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:4px;}
    .btn-blue{background:#dbeafe;color:#1d4ed8;} .btn-blue:hover{background:#bfdbfe;}
    .btn-green{background:#d1fae5;color:#047857;} .btn-green:hover{background:#a7f3d0;}
    .btn-amber{background:#fef3c7;color:#b45309;} .btn-amber:hover{background:#fde68a;}
    .btn-purple{background:#ede9fe;color:#6d28d9;} .btn-purple:hover{background:#ddd6fe;}
    .search-bar{display:flex;gap:8px;margin-bottom:16px;}
    .search-bar input{flex:1;padding:10px 14px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;}
    .search-bar select{padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;}
    .company-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;}
    .company-card{background:#fff;border-radius:10px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.08);display:flex;gap:14px;align-items:flex-start;transition:box-shadow .2s;position:relative;}
    .company-card:hover{box-shadow:0 4px 12px rgba(0,0,0,.12);}
    .company-logo{width:56px;height:56px;border-radius:8px;border:1px solid #e5e7eb;display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;background:#f9fafb;position:relative;cursor:pointer;}
    .company-logo img{width:100%;height:100%;object-fit:contain;}
    .company-logo .no-logo{font-size:24px;color:#d1d5db;}
    .company-logo:hover .logo-overlay{opacity:1;}
    .logo-overlay{position:absolute;inset:0;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;color:#fff;font-size:11px;opacity:0;transition:opacity .2s;border-radius:8px;}
    .company-info{flex:1;min-width:0;}
    .company-name{font-weight:600;font-size:14px;color:#1f2937;margin-bottom:2px;}
    .company-meta{font-size:12px;color:#6b7280;margin-bottom:6px;}
    .company-website{font-size:11px;color:#3b82f6;text-decoration:none;}
    .company-website:hover{text-decoration:underline;}
    .product-badges{display:flex;gap:4px;flex-wrap:wrap;margin-top:4px;}
    .p-badge{font-size:11px;padding:2px 6px;border-radius:4px;font-weight:600;}
    .p-badge-inv{background:#dbeafe;color:#1d4ed8;} .p-badge-bat{background:#d1fae5;color:#047857;}
    .p-badge-pan{background:#fef3c7;color:#b45309;} .p-badge-zero{background:#f3f4f6;color:#9ca3af;}
    .card-actions{position:absolute;top:10px;right:10px;display:flex;gap:4px;opacity:0;transition:opacity .2s;}
    .company-card:hover .card-actions{opacity:1;}
    .btn-icon{width:28px;height:28px;border-radius:6px;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:13px;}
    .btn-icon-edit{background:#ede9fe;color:#6d28d9;} .btn-icon-edit:hover{background:#ddd6fe;}
    .modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:1000;align-items:center;justify-content:center;}
    .modal-overlay.active{display:flex;}
    .modal-box{background:#fff;border-radius:12px;padding:24px;max-width:520px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,.2);max-height:90vh;overflow-y:auto;}
    .modal-box h3{margin:0 0 16px;}
    .modal-close{float:right;background:none;border:none;font-size:20px;cursor:pointer;color:#6b7280;}
    .form-row{margin-bottom:12px;}
    .form-row label{display:block;font-size:13px;font-weight:500;color:#374151;margin-bottom:4px;}
    .form-row input,.form-row textarea,.form-row select{width:100%;padding:9px 12px;border:1px solid #d1d5db;border-radius:7px;font-size:13px;font-family:inherit;box-sizing:border-box;}
    .form-row textarea{resize:vertical;min-height:80px;}
    .stats-summary{display:flex;gap:16px;margin-bottom:16px;flex-wrap:wrap;}
    .stats-summary .stat{padding:6px 12px;background:#f3f4f6;border-radius:6px;font-size:12px;color:#6b7280;}
    .stats-summary .stat strong{color:#1f2937;}
    .alert{padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px;}
    .alert-success{background:#d1fae5;color:#065f46;border:1px solid #6ee7b7;}
    .alert-error{background:#fee2e2;color:#991b1b;border:1px solid #fca5a5;}
</style>

<?php if ($message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="card">
    <div class="companies-header">
        <h2>Companies (<?= count($companies) ?>)</h2>
        <div class="header-actions">
            <button class="btn-sm btn-green" onclick="document.getElementById('csvModal').classList.add('active')">&#128196; Import CSV</button>
            <button class="btn-sm btn-amber" onclick="document.getElementById('logoModal').classList.add('active')">&#128247; Bulk Logos</button>
            <a href="export-companies.php?format=csv" class="btn-sm btn-blue">&#128229; Export CSV</a>
        </div>
    </div>

    <div class="stats-summary">
        <span class="stat"><strong><?= $totalCount ?></strong> total companies</span>
        <span class="stat">Showing <strong><?= count($companies) ?></strong> on page <strong><?= $page ?></strong> of <strong><?= $totalPages ?></strong></span>
        <span class="stat"><strong><?= $totalProducts ?></strong> products on this page</span>
        <span class="stat"><strong><?= count(array_filter($companies, fn($c) => !empty($c['logo_path']))) ?></strong> with logos</span>
    </div>

    <form method="GET" class="search-bar">
        <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search companies...">
        <select name="sort" onchange="this.form.submit()">
            <option value="name"     <?= $sort==='name'     ?'selected':'' ?>>Sort: Name</option>
            <option value="products" <?= $sort==='products' ?'selected':'' ?>>Sort: Most Products</option>
            <option value="country"  <?= $sort==='country'  ?'selected':'' ?>>Sort: Country</option>
        </select>
        <button type="submit" class="btn-sm btn-blue">Search</button>
    </form>

    <div class="company-grid">
        <?php foreach ($companies as $company):
            $total = $company['inverter_count'] + $company['battery_count'] + $company['panel_count'];
        ?>
        <div class="company-card">
            <div class="card-actions">
                <button class="btn-icon btn-icon-edit" title="Edit company"
                    onclick="openEdit(<?= $company['id'] ?>, <?= htmlspecialchars(json_encode($company['name'])) ?>, <?= htmlspecialchars(json_encode($company['country'] ?? '')) ?>, <?= htmlspecialchars(json_encode($company['website'] ?? '')) ?>, <?= htmlspecialchars(json_encode($company['description'] ?? '')) ?>)">&#9998;</button>
            </div>
            <div class="company-logo" onclick="openLogoUpload(<?= $company['id'] ?>, '<?= htmlspecialchars(addslashes($company['name'])) ?>')">
                <?php if (!empty($company['logo_path'])): ?>
                    <img src="<?= htmlspecialchars($company['logo_path']) ?>" alt="<?= htmlspecialchars($company['name']) ?>">
                <?php else: ?>
                    <span class="no-logo">&#127970;</span>
                <?php endif; ?>
                <div class="logo-overlay">Upload</div>
            </div>
            <div class="company-info">
                <div class="company-name"><?= htmlspecialchars($company['name']) ?></div>
                <div class="company-meta">
                    <?= !empty($company['country']) ? htmlspecialchars($company['country']) : '<em style="color:#d1d5db">No country</em>' ?>
                </div>
                <?php if (!empty($company['website'])): ?>
                    <a href="<?= htmlspecialchars($company['website']) ?>" class="company-website" target="_blank" rel="noopener">
                        <?= htmlspecialchars(parse_url($company['website'], PHP_URL_HOST) ?: $company['website']) ?>
                    </a>
                <?php endif; ?>
                <div class="product-badges">
                    <?php if ($company['inverter_count'] > 0): ?><span class="p-badge p-badge-inv"><?= $company['inverter_count'] ?> inv</span><?php endif; ?>
                    <?php if ($company['battery_count']  > 0): ?><span class="p-badge p-badge-bat"><?= $company['battery_count']  ?> bat</span><?php endif; ?>
                    <?php if ($company['panel_count']    > 0): ?><span class="p-badge p-badge-pan"><?= $company['panel_count']    ?> pan</span><?php endif; ?>
                    <?php if ($total === 0): ?><span class="p-badge p-badge-zero">No products</span><?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ═══════════════════════════════════════════════════════════════════════════ -->
    <!-- PAGINATION CONTROLS -->
    <!-- ═══════════════════════════════════════════════════════════════════════════ -->
    <?php if ($totalPages > 1): ?>
    <div class="pagination-controls" style="margin-top: 24px; display: flex; justify-content: center; align-items: center; gap: 8px; flex-wrap: wrap;">
        <?php
        // Build query string for pagination links
        $queryParams = [];
        if (!empty($search)) $queryParams['q'] = $search;
        if ($sort !== 'name') $queryParams['sort'] = $sort;
        
        function buildPageUrl($page, $params) {
            $params['page'] = $page;
            return '?' . http_build_query($params);
        }
        ?>
        
        <!-- First Page -->
        <?php if ($page > 1): ?>
            <a href="<?= buildPageUrl(1, $queryParams) ?>" class="btn-sm btn-blue" title="First page">
                &#171; First
            </a>
            <a href="<?= buildPageUrl($page - 1, $queryParams) ?>" class="btn-sm btn-blue" title="Previous page">
                &#8249; Prev
            </a>
        <?php else: ?>
            <button class="btn-sm" style="background: #f3f4f6; color: #9ca3af; cursor: not-allowed;" disabled>
                &#171; First
            </button>
            <button class="btn-sm" style="background: #f3f4f6; color: #9ca3af; cursor: not-allowed;" disabled>
                &#8249; Prev
            </button>
        <?php endif; ?>
        
        <!-- Page Numbers -->
        <?php
        $start = max(1, $page - 2);
        $end = min($totalPages, $page + 2);
        
        // Show first page if not in range
        if ($start > 1): ?>
            <a href="<?= buildPageUrl(1, $queryParams) ?>" class="btn-sm btn-blue">1</a>
            <?php if ($start > 2): ?>
                <span style="color: #9ca3af; padding: 0 4px;">...</span>
            <?php endif; ?>
        <?php endif; ?>
        
        <!-- Range of pages -->
        <?php for ($i = $start; $i <= $end; $i++): ?>
            <?php if ($i == $page): ?>
                <button class="btn-sm" style="background: #6366f1; color: white; font-weight: 700; cursor: default;">
                    <?= $i ?>
                </button>
            <?php else: ?>
                <a href="<?= buildPageUrl($i, $queryParams) ?>" class="btn-sm btn-blue">
                    <?= $i ?>
                </a>
            <?php endif; ?>
        <?php endfor; ?>
        
        <!-- Show last page if not in range -->
        <?php if ($end < $totalPages): ?>
            <?php if ($end < $totalPages - 1): ?>
                <span style="color: #9ca3af; padding: 0 4px;">...</span>
            <?php endif; ?>
            <a href="<?= buildPageUrl($totalPages, $queryParams) ?>" class="btn-sm btn-blue"><?= $totalPages ?></a>
        <?php endif; ?>
        
        <!-- Next & Last -->
        <?php if ($page < $totalPages): ?>
            <a href="<?= buildPageUrl($page + 1, $queryParams) ?>" class="btn-sm btn-blue" title="Next page">
                Next &#8250;
            </a>
            <a href="<?= buildPageUrl($totalPages, $queryParams) ?>" class="btn-sm btn-blue" title="Last page">
                Last &#187;
            </a>
        <?php else: ?>
            <button class="btn-sm" style="background: #f3f4f6; color: #9ca3af; cursor: not-allowed;" disabled>
                Next &#8250;
            </button>
            <button class="btn-sm" style="background: #f3f4f6; color: #9ca3af; cursor: not-allowed;" disabled>
                Last &#187;
            </button>
        <?php endif; ?>
        
        <!-- Items per page info -->
        <span style="margin-left: 16px; font-size: 13px; color: #6b7280;">
            Showing <?= $offset + 1 ?>-<?= min($offset + $per_page, $totalCount) ?> of <?= $totalCount ?>
        </span>
    </div>
    <?php endif; ?>
</div>

<!-- Edit Company Modal -->
<div class="modal-overlay" id="editModal">
    <div class="modal-box">
        <button class="modal-close" onclick="this.closest('.modal-overlay').classList.remove('active')">&times;</button>
        <h3>Edit Company: <span id="editCompanyNameLabel"></span></h3>
        <form method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="edit_company">
            <input type="hidden" name="company_id" id="editCompanyId">
            <div class="form-row">
                <label>Company Name <span style="color:#ef4444">*</span></label>
                <input type="text" name="name" id="editName" required>
            </div>
            <div class="form-row">
                <label>Country</label>
                <input type="text" name="country" id="editCountry" placeholder="e.g. China, Germany">
            </div>
            <div class="form-row">
                <label>Website</label>
                <input type="url" name="website" id="editWebsite" placeholder="https://example.com">
            </div>
            <div class="form-row">
                <label>Description</label>
                <textarea name="description" id="editDescription" placeholder="Brief company description..."></textarea>
            </div>
            <div style="display:flex;gap:8px;margin-top:16px;">
                <button type="submit" class="btn-sm btn-green" style="padding:10px 20px;">&#10003; Save Changes</button>
                <button type="button" class="btn-sm btn-blue" style="padding:10px 20px;" onclick="this.closest('.modal-overlay').classList.remove('active')">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- CSV Import Modal -->
<div class="modal-overlay" id="csvModal">
    <div class="modal-box">
        <button class="modal-close" onclick="this.closest('.modal-overlay').classList.remove('active')">&times;</button>
        <h3>Import Companies CSV</h3>
        <p style="font-size:13px;color:#6b7280;margin-bottom:16px;">
            Columns: <code>name</code> (required), <code>country</code>, <code>website</code>, <code>description</code>.<br>
            Existing companies (matched by exact name) will be updated.
        </p>
        <form method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="import_csv">
            <div style="margin-bottom:12px;">
                <input type="file" name="csv_file" accept=".csv" required style="width:100%;padding:8px;border:1px solid #d1d5db;border-radius:6px;">
            </div>
            <button type="submit" class="btn-sm btn-green" style="padding:10px 20px;">Import</button>
        </form>
    </div>
</div>

<!-- Bulk Logo Modal -->
<div class="modal-overlay" id="logoModal">
    <div class="modal-box">
        <button class="modal-close" onclick="this.closest('.modal-overlay').classList.remove('active')">&times;</button>
        <h3>Bulk Logo Upload</h3>
        <p style="font-size:13px;color:#6b7280;margin-bottom:16px;">
            Filenames must match company names. e.g. <code>Deye.png</code>, <code>JA_Solar.jpg</code>.
        </p>
        <form method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="bulk_logos">
            <div style="margin-bottom:12px;">
                <input type="file" name="logos[]" accept="image/jpeg,image/png,image/webp" multiple required style="width:100%;padding:8px;border:1px solid #d1d5db;border-radius:6px;">
            </div>
            <button type="submit" class="btn-sm btn-amber" style="padding:10px 20px;">Upload Logos</button>
        </form>
    </div>
</div>

<!-- Single Logo Modal -->
<div class="modal-overlay" id="singleLogoModal">
    <div class="modal-box">
        <button class="modal-close" onclick="this.closest('.modal-overlay').classList.remove('active')">&times;</button>
        <h3>Upload Logo: <span id="logoCompanyName"></span></h3>
        <form method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_logo">
            <input type="hidden" name="company_id" id="logoCompanyId">
            <div style="margin-bottom:12px;">
                <input type="file" name="logo" accept="image/jpeg,image/png,image/webp" required style="width:100%;padding:8px;border:1px solid #d1d5db;border-radius:6px;">
            </div>
            <button type="submit" class="btn-sm btn-green" style="padding:10px 20px;">Upload</button>
        </form>
    </div>
</div>

<script>
function openEdit(id, name, country, website, description) {
    document.getElementById('editCompanyId').value = id;
    document.getElementById('editCompanyNameLabel').textContent = name;
    document.getElementById('editName').value = name;
    document.getElementById('editCountry').value = country;
    document.getElementById('editWebsite').value = website;
    document.getElementById('editDescription').value = description;
    document.getElementById('editModal').classList.add('active');
}
function openLogoUpload(id, name) {
    document.getElementById('logoCompanyId').value = id;
    document.getElementById('logoCompanyName').textContent = name;
    document.getElementById('singleLogoModal').classList.add('active');
}
// Close modal on backdrop click
document.querySelectorAll('.modal-overlay').forEach(m => {
    m.addEventListener('click', function(e) { if (e.target === this) this.classList.remove('active'); });
});
</script>

<?php include 'includes/footer.php'; ?>
