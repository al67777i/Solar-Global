<?php
/**
 * Solar Shop — Proximity-Based Dealer Product Marketplace
 *
 * Shows products from nearby dealers using Haversine distance.
 * AJAX-powered with infinite scroll, location detection, and currency conversion.
 *
 * Endpoints:
 *   ?ajax=products  — Paginated product listing (JSON)
 *   ?ajax=brands    — Distinct brand names for filter (JSON)
 *   (default)       — Full HTML page
 */

require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/subscription_helpers.php';
require_once 'includes/location_helper.php';

set_security_headers();
$db = getDB();

// ════════════════════════════════════════════════════════════════
// AJAX Endpoints — respond with JSON and exit early
// ════════════════════════════════════════════════════════════════

if (isset($_GET['ajax'])) {

    // Session needed for rate limiting
    if (session_status() === PHP_SESSION_NONE) session_start();

    header('Content-Type: application/json; charset=utf-8');

    // ── Products endpoint ────────────────────────────────────
    if ($_GET['ajax'] === 'products') {

        if (!rate_limit('store_products', 60, 60)) { respond_rate_limited(); }

        // Sanitize parameters
        $lat       = isset($_GET['lat']) ? (float)$_GET['lat'] : null;
        $lng       = isset($_GET['lng']) ? (float)$_GET['lng'] : null;
        $radius    = max(5, min(500, (int)($_GET['radius'] ?? 50)));
        $type      = $_GET['type'] ?? 'all';
        $sort      = $_GET['sort'] ?? 'newest';
        $brand     = trim($_GET['brand'] ?? '');
        $min_price   = $_GET['min_price'] ?? '';
        $max_price   = $_GET['max_price'] ?? '';
        $search_name = trim($_GET['search_name'] ?? '');
        $min_spec    = $_GET['min_spec'] ?? '';
        $max_spec    = $_GET['max_spec'] ?? '';
        $outside_radius = ($_GET['outside_radius'] ?? '0') === '1';
        $offset    = max(0, (int)($_GET['offset'] ?? 0));
        $limit     = max(1, min(60, (int)($_GET['limit'] ?? 20)));

        // Whitelist
        $valid_types = ['all', 'inverter', 'battery', 'panel', 'installation_appliance'];
        if (!in_array($type, $valid_types)) $type = 'all';

        $valid_sorts = ['price_asc', 'price_desc', 'distance', 'newest', 'best_match'];
        if (!in_array($sort, $valid_sorts)) $sort = 'distance';

        $has_location = ($lat !== null && $lng !== null && ($lat != 0 || $lng != 0));

        // Dealer subscription filter (e.g. "d.status IN ('active','approved') AND ...")
        $dealer_filter = get_dealer_subscription_filter('d');

        // Country code for currency conversion
        $country_code = 'US';
        if (!empty($_COOKIE['sg_location'])) {
            $loc_cookie = json_decode($_COOKIE['sg_location'], true);
            if (!empty($loc_cookie['country_code'])) {
                $country_code = strtoupper(substr($loc_cookie['country_code'], 0, 3));
            }
        }
        $currency_info = get_country_currency_info($country_code);

        // ── Build UNION ALL query across product types ───────

        // Table config: alias, table, spec expression, brand column
        $type_configs = [
            'inverter' => [
                'table' => 'inverters',
                'alias' => 'p',
                'name'  => 'p.name',
                'brand' => 'p.brand',
                'spec'  => "CONCAT(p.power_rating, 'W')",
                'spec_col' => 'p.power_rating',  // kW (stored as watts)
                'image' => 'p.image_path',
                'price' => 'p.price_usd',
                'type_label' => "'inverter'",
            ],
            'battery' => [
                'table' => 'batteries',
                'alias' => 'p',
                'name'  => 'p.name',
                'brand' => 'p.brand',
                'spec'  => "CONCAT(p.capacity_ah, 'Ah/', p.voltage, 'V')",
                'spec_col' => 'p.capacity_ah',  // Ah
                'image' => 'p.image_path',
                'price' => 'p.price_usd',
                'type_label' => "'battery'",
            ],
            'panel' => [
                'table' => 'panels',
                'alias' => 'p',
                'name'  => 'p.name',
                'brand' => 'p.brand',
                'spec'  => "CONCAT(p.wattage, 'W')",
                'spec_col' => 'p.wattage',  // Watts
                'image' => 'p.image_path',
                'price' => 'p.price_usd',
                'type_label' => "'panel'",
            ],
            'installation_appliance' => [
                'table' => 'installation_appliances',
                'alias' => 'p',
                'name'  => 'p.name',
                'brand' => 'p.brand',
                'spec'  => 'p.category',
                'spec_col' => null,
                'image' => 'p.image_path',
                'price' => 'p.price_usd',
                'type_label' => "'installation_appliance'",
            ],
        ];

        // Which types to query
        $types_to_query = ($type === 'all') ? array_keys($type_configs) : [$type];

        $union_parts = [];
        $params = [];
        $count_parts = [];
        $count_params = [];

        foreach ($types_to_query as $ptype) {
            $cfg = $type_configs[$ptype];

            // Distance select
            $distance_select = $has_location
                ? haversine_sql('d.latitude', 'd.longitude') . ' AS distance_km'
                : '9999999 AS distance_km';

            $select = "SELECT
                dp.id AS dp_id,
                dp.product_id,
                {$cfg['type_label']} AS product_type,
                {$cfg['name']} AS name,
                {$cfg['brand']} AS brand,
                {$cfg['spec']} AS spec,
                {$cfg['image']} AS image_path,
                dp.dealer_price,
                dp.stock_quantity,
                d.id AS dealer_id,
                d.business_name AS dealer_name,
                d.city AS dealer_city,
                d.country_code AS dealer_country_code,
                dp.created_at,
                {$distance_select}";

            $from = " FROM dealer_products dp
                JOIN {$cfg['table']} {$cfg['alias']} ON {$cfg['alias']}.id = dp.product_id
                JOIN dealers d ON d.id = dp.dealer_id";

            $where_clauses = [
                "dp.is_active = 1",
                "dp.product_type = ?",
                $dealer_filter,
            ];

            // Params order: SELECT haversine(3) first, then WHERE params
            // SELECT haversine ? placeholders come before WHERE ? in SQL
            $part_params = [];

            // SELECT haversine params (come first in SQL)
            if ($has_location) {
                $part_params[] = $lat;
                $part_params[] = $lng;
                $part_params[] = $lat;
            }

            // WHERE product_type param
            $part_params[] = $ptype;

            // WHERE radius filter (haversine + <= ?)
            if ($has_location && !$outside_radius) {
                $where_clauses[] = haversine_sql('d.latitude', 'd.longitude') . ' <= ?';
                $part_params[] = $lat;
                $part_params[] = $lng;
                $part_params[] = $lat;
                $part_params[] = $radius;
            } elseif ($has_location && $outside_radius) {
                // Outside radius: find products BEYOND the radius
                $where_clauses[] = haversine_sql('d.latitude', 'd.longitude') . ' > ?';
                $part_params[] = $lat;
                $part_params[] = $lng;
                $part_params[] = $lat;
                $part_params[] = $radius;
            }

            // Search name filter (autocomplete or manual search)
            if ($search_name !== '') {
                $where_clauses[] = "({$cfg['name']} LIKE ? OR {$cfg['brand']} LIKE ?)";
                $part_params[] = '%' . $search_name . '%';
                $part_params[] = '%' . $search_name . '%';
            }

            // Brand filter
            if ($brand !== '') {
                $where_clauses[] = "{$cfg['brand']} = ?";
                $part_params[] = $brand;
            }

            // Price filters — values come from frontend in LOCAL currency, convert to USD
            $rate = max(0.001, (float)($currency_info['exchange_rate'] ?? 1.0));
            if ($min_price !== '' && is_numeric($min_price)) {
                $where_clauses[] = "dp.dealer_price >= ?";
                $part_params[] = (float)$min_price / $rate;
            }
            if ($max_price !== '' && is_numeric($max_price)) {
                $where_clauses[] = "dp.dealer_price <= ?";
                $part_params[] = (float)$max_price / $rate;
            }

            // Spec filter (type-specific: kW for inverters, Ah for batteries, W for panels)
            if (!empty($cfg['spec_col'])) {
                if ($min_spec !== '' && is_numeric($min_spec)) {
                    $where_clauses[] = "{$cfg['spec_col']} >= ?";
                    $part_params[] = (float)$min_spec;
                }
                if ($max_spec !== '' && is_numeric($max_spec)) {
                    $where_clauses[] = "{$cfg['spec_col']} <= ?";
                    $part_params[] = (float)$max_spec;
                }
            }

            $where_sql = implode(' AND ', $where_clauses);

            $union_parts[] = "({$select}{$from} WHERE {$where_sql})";
            $params = array_merge($params, $part_params);

            // Count query (same WHERE, no distance in SELECT)
            $count_select = "SELECT COUNT(*) AS cnt";
            // For count, we still need haversine in WHERE for radius filtering
            $count_from = $from;
            $count_where_clauses = [
                "dp.is_active = 1",
                "dp.product_type = ?",
                $dealer_filter,
            ];
            $count_part_params = [$ptype];

            if ($has_location && !$outside_radius) {
                $count_where_clauses[] = haversine_sql('d.latitude', 'd.longitude') . ' <= ?';
                $count_part_params[] = $lat;
                $count_part_params[] = $lng;
                $count_part_params[] = $lat;
                $count_part_params[] = $radius;
            } elseif ($has_location && $outside_radius) {
                // Outside radius: find products BEYOND the radius
                $count_where_clauses[] = haversine_sql('d.latitude', 'd.longitude') . ' > ?';
                $count_part_params[] = $lat;
                $count_part_params[] = $lng;
                $count_part_params[] = $lat;
                $count_part_params[] = $radius;
            }
            if ($search_name !== '') {
                $count_where_clauses[] = "({$cfg['name']} LIKE ? OR {$cfg['brand']} LIKE ?)";
                $count_part_params[] = '%' . $search_name . '%';
                $count_part_params[] = '%' . $search_name . '%';
            }
            if ($brand !== '') {
                $count_where_clauses[] = "{$cfg['brand']} = ?";
                $count_part_params[] = $brand;
            }
            if ($min_price !== '' && is_numeric($min_price)) {
                $count_where_clauses[] = "dp.dealer_price >= ?";
                $count_part_params[] = (float)$min_price / $rate;
            }
            if ($max_price !== '' && is_numeric($max_price)) {
                $count_where_clauses[] = "dp.dealer_price <= ?";
                $count_part_params[] = (float)$max_price / $rate;
            }
            // Spec filter for count
            if (!empty($cfg['spec_col'])) {
                if ($min_spec !== '' && is_numeric($min_spec)) {
                    $count_where_clauses[] = "{$cfg['spec_col']} >= ?";
                    $count_part_params[] = (float)$min_spec;
                }
                if ($max_spec !== '' && is_numeric($max_spec)) {
                    $count_where_clauses[] = "{$cfg['spec_col']} <= ?";
                    $count_part_params[] = (float)$max_spec;
                }
            }

            $count_where_sql = implode(' AND ', $count_where_clauses);
            $count_parts[] = "({$count_select}{$count_from} WHERE {$count_where_sql})";
            $count_params = array_merge($count_params, $count_part_params);
        }

        if (empty($union_parts)) {
            echo json_encode(['products' => [], 'total' => 0, 'currency' => $currency_info]);
            exit;
        }

        // Sort clause
        $order_by = match($sort) {
            'price_asc'   => 'dealer_price ASC',
            'price_desc'  => 'dealer_price DESC',
            'distance'    => 'distance_km ASC',
            'best_match'  => 'distance_km ASC, dealer_price ASC',
            default       => 'distance_km ASC',
        };

        // Main data query
        $sql = implode(' UNION ALL ', $union_parts) . " ORDER BY {$order_by} LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;

        // Count query
        $count_sql = "SELECT SUM(cnt) AS total FROM (" . implode(' UNION ALL ', $count_parts) . ") AS counts";

        try {
            // Fetch total count
            $count_stmt = $db->prepare($count_sql);
            $count_stmt->execute($count_params);
            $total = (int)($count_stmt->fetchColumn() ?: 0);

            // Fetch products
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Format output
            $products = [];
            foreach ($rows as $row) {
                $local_price = convert_usd_to_local((float)$row['dealer_price'], $country_code);
                $products[] = [
                    'dp_id'               => (int)$row['dp_id'],
                    'product_id'          => (int)$row['product_id'],
                    'product_type'        => $row['product_type'],
                    'name'                => $row['name'] ?? '',
                    'brand'               => $row['brand'] ?? '',
                    'spec'                => $row['spec'] ?? '',
                    'image'               => !empty($row['image_path']) ? get_image_url($row['image_path']) : '',
                    'dealer_price'        => (float)$row['dealer_price'],
                    'local_price'         => round($local_price, 2),
                    'formatted_price'     => $currency_info['currency_symbol'] . ' ' . number_format($local_price, 0, '.', ','),
                    'dealer_id'           => (int)$row['dealer_id'],
                    'dealer_name'         => $row['dealer_name'] ?? '',
                    'dealer_city'         => $row['dealer_city'] ?? '',
                    'dealer_country_code' => $row['dealer_country_code'] ?? '',
                    'distance_km'         => $has_location ? round((float)$row['distance_km'], 1) : null,
                    'stock_qty'           => (int)$row['stock_quantity'],
                    'stock_status'        => ((int)$row['stock_quantity'] > 0) ? 'in_stock' : 'out_of_stock',
                ];
            }

            echo json_encode([
                'products' => $products,
                'total'    => $total,
                'currency' => $currency_info,
            ]);
        } catch (Exception $e) {
            error_log('Store AJAX products error: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'Failed to load products.']);
        }
        exit;
    }

    // ── Brands endpoint ──────────────────────────────────────
    if ($_GET['ajax'] === 'brands') {

        if (!rate_limit('store_brands', 30, 60)) { respond_rate_limited(); }

        $dealer_filter = get_dealer_subscription_filter('d');

        // Get distinct brands across all product types that have dealer inventory
        $brand_queries = [
            "SELECT DISTINCT p.brand FROM dealer_products dp JOIN inverters p ON p.id = dp.product_id JOIN dealers d ON d.id = dp.dealer_id WHERE dp.is_active = 1 AND dp.product_type = 'inverter' AND {$dealer_filter} AND p.brand IS NOT NULL AND p.brand != ''",
            "SELECT DISTINCT p.brand FROM dealer_products dp JOIN batteries p ON p.id = dp.product_id JOIN dealers d ON d.id = dp.dealer_id WHERE dp.is_active = 1 AND dp.product_type = 'battery' AND {$dealer_filter} AND p.brand IS NOT NULL AND p.brand != ''",
            "SELECT DISTINCT p.brand FROM dealer_products dp JOIN panels p ON p.id = dp.product_id JOIN dealers d ON d.id = dp.dealer_id WHERE dp.is_active = 1 AND dp.product_type = 'panel' AND {$dealer_filter} AND p.brand IS NOT NULL AND p.brand != ''",
            "SELECT DISTINCT p.brand FROM dealer_products dp JOIN installation_appliances p ON p.id = dp.product_id JOIN dealers d ON d.id = dp.dealer_id WHERE dp.is_active = 1 AND dp.product_type = 'installation_appliance' AND {$dealer_filter} AND p.brand IS NOT NULL AND p.brand != ''",
        ];

        $sql = "SELECT DISTINCT brand FROM (" . implode(' UNION ALL ', $brand_queries) . ") AS all_brands ORDER BY brand ASC";

        try {
            $stmt = $db->query($sql);
            $brands = $stmt->fetchAll(PDO::FETCH_COLUMN);
            echo json_encode(['brands' => $brands]);
        } catch (Exception $e) {
            error_log('Store AJAX brands error: ' . $e->getMessage());
            echo json_encode(['brands' => []]);
        }
        exit;
    }

    // ── Autocomplete endpoint ──────────────────────────────
    if ($_GET['ajax'] === 'autocomplete') {

        if (!rate_limit('store_autocomplete', 120, 60)) { respond_rate_limited(); }

        $q = trim($_GET['q'] ?? '');
        if (strlen($q) < 2) {
            echo json_encode(['suggestions' => []]);
            exit;
        }

        $dealer_filter = get_dealer_subscription_filter('d');
        $like = '%' . $q . '%';

        // Search across all product types for matching names
        $sql = "SELECT DISTINCT name, product_type, brand FROM (
            SELECT p.name, 'inverter' AS product_type, p.brand
            FROM dealer_products dp
            JOIN inverters p ON p.id = dp.product_id
            JOIN dealers d ON d.id = dp.dealer_id
            WHERE dp.is_active = 1 AND dp.product_type = 'inverter' AND {$dealer_filter}
              AND (p.name LIKE ? OR p.brand LIKE ?)

            UNION ALL

            SELECT p.name, 'battery' AS product_type, p.brand
            FROM dealer_products dp
            JOIN batteries p ON p.id = dp.product_id
            JOIN dealers d ON d.id = dp.dealer_id
            WHERE dp.is_active = 1 AND dp.product_type = 'battery' AND {$dealer_filter}
              AND (p.name LIKE ? OR p.brand LIKE ?)

            UNION ALL

            SELECT p.name, 'panel' AS product_type, p.brand
            FROM dealer_products dp
            JOIN panels p ON p.id = dp.product_id
            JOIN dealers d ON d.id = dp.dealer_id
            WHERE dp.is_active = 1 AND dp.product_type = 'panel' AND {$dealer_filter}
              AND (p.name LIKE ? OR p.brand LIKE ?)

            UNION ALL

            SELECT p.name, 'installation_appliance' AS product_type, p.brand
            FROM dealer_products dp
            JOIN installation_appliances p ON p.id = dp.product_id
            JOIN dealers d ON d.id = dp.dealer_id
            WHERE dp.is_active = 1 AND dp.product_type = 'installation_appliance' AND {$dealer_filter}
              AND (p.name LIKE ? OR p.brand LIKE ?)
        ) AS combined
        ORDER BY
            CASE WHEN name LIKE ? THEN 0 ELSE 1 END,
            name ASC
        LIMIT 10";

        try {
            $stmt = $db->prepare($sql);
            // 4 UNIONs × 2 LIKE params = 8, plus 1 for priority ORDER
            $startsWith = $q . '%';
            $stmt->execute([$like, $like, $like, $like, $like, $like, $like, $like, $startsWith]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $suggestions = [];
            foreach ($rows as $row) {
                $suggestions[] = [
                    'name'         => $row['name'],
                    'product_type' => $row['product_type'],
                    'brand'        => $row['brand'] ?? '',
                ];
            }
            echo json_encode(['suggestions' => $suggestions]);
        } catch (Exception $e) {
            error_log('Store autocomplete error: ' . $e->getMessage());
            echo json_encode(['suggestions' => []]);
        }
        exit;
    }

    // Unknown AJAX action
    http_response_code(400);
    echo json_encode(['error' => 'Invalid AJAX action.']);
    exit;
}

// ════════════════════════════════════════════════════════════════
// HTML Page — Full store layout
// ════════════════════════════════════════════════════════════════

trackVisitor($db);

// Page meta
$page_title = "Solar Shop - Find Solar Products From Nearby Dealers";
$page_description = "Browse solar inverters, batteries, panels and installation products from verified dealers near you. Compare prices and buy from trusted local suppliers.";
$page_keywords = "solar shop, buy solar panels, solar inverter price, solar battery, solar dealers near me";
$current_page = 'store';

// Detect saved location (from cookie)
$user_location = detect_user_location();
$user_radius   = get_user_radius(50);

// Currency info for frontend display (based on detected country)
$page_country_code = 'US';
if (!empty($_COOKIE['sg_location'])) {
    $loc_data = json_decode($_COOKIE['sg_location'], true);
    if (!empty($loc_data['country_code'])) {
        $page_country_code = strtoupper(substr($loc_data['country_code'], 0, 3));
    }
} elseif (!empty($user_location['country_code'])) {
    $page_country_code = strtoupper($user_location['country_code']);
}
$page_currency = get_country_currency_info($page_country_code);

// Google Maps API key — try system_settings first, then hardcoded fallback
$maps_key = get_system_setting('google_maps_api_key', '');
// No hardcoded fallback — key must be set in Admin → Settings

require_once 'includes/header.php';
?>

<!-- Anime.js for particle animation -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.2/anime.min.js"></script>
<style>
/* ═══════════════════════════════════════════════════
   Solar Shop — Professional Animated Design
   ═══════════════════════════════════════════════════ */

/* Hero with animated background */
/* ═══ SOLAR SHOP — Premium Dark Theme ═══ */
.shop-hero {
    position: relative;
    background: linear-gradient(160deg, #0a0a0a 0%, #1a1a1a 40%, #0d0d0d 100%);
    padding: 32px 24px 24px;
    color: #fff;
    font-family: 'Inter', sans-serif;
    overflow: hidden;
    border-bottom: 2px solid rgba(245,158,11,0.15);
}
.shop-hero::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 600px;
    height: 600px;
    background: radial-gradient(circle, rgba(245,158,11,0.06) 0%, transparent 70%);
    pointer-events: none;
}
.shop-hero-canvas {
    position: absolute;
    inset: 0;
    pointer-events: none;
    z-index: 0;
}
.shop-hero-canvas .particle {
    position: absolute;
    border-radius: 50%;
    opacity: 0;
}
.shop-hero-inner {
    position: relative;
    z-index: 1;
    max-width: 1280px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 420px;
    gap: 28px;
    align-items: stretch;
}
.shop-hero-left {
    display: flex;
    flex-direction: column;
    justify-content: center;
}
.shop-hero-title {
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.03em;
    margin: 0 0 6px;
    line-height: 1.15;
    color: #ffffff;
}
.shop-hero-title span {
    background: linear-gradient(135deg, #F59E0B, #FBBF24);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
.shop-hero-sub {
    font-size: 0.9rem;
    color: #71717a;
    margin: 0 0 20px;
    line-height: 1.5;
}

/* ═══ Animated Search Bar in Hero ═══ */
.shop-hero-search {
    position: relative;
    margin-bottom: 20px;
}
.shop-hero-search-box {
    display: flex;
    align-items: center;
    background: rgba(255,255,255,0.06);
    border: 2px solid rgba(245,158,11,0.2);
    border-radius: 14px;
    padding: 4px 6px;
    transition: all 0.3s cubic-bezier(.4,0,.2,1);
    backdrop-filter: blur(8px);
}
.shop-hero-search-box:focus-within {
    border-color: #F59E0B;
    background: rgba(255,255,255,0.1);
    box-shadow: 0 0 0 4px rgba(245,158,11,0.12), 0 8px 32px rgba(245,158,11,0.08);
    transform: scale(1.01);
}
.shop-hero-search-box .search-icon-wrap {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 42px;
    height: 42px;
    border-radius: 10px;
    background: linear-gradient(135deg, #F59E0B, #D97706);
    flex-shrink: 0;
}
.shop-hero-search-input {
    flex: 1;
    border: none;
    background: transparent;
    color: #f1f5f9;
    font-size: 1rem;
    font-weight: 500;
    padding: 12px 14px;
    outline: none;
    font-family: inherit;
}
.shop-hero-search-input::placeholder {
    color: #52525b;
    font-weight: 400;
}
.shop-hero-search-clear {
    background: rgba(255,255,255,0.1);
    border: none;
    color: #94a3b8;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1.1rem;
    display: none;
    align-items: center;
    justify-content: center;
    transition: all .15s;
}
.shop-hero-search-clear:hover { background: rgba(255,255,255,.2); color: #fff; }
.shop-autocomplete {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: #1a1a1a;
    border: 1px solid rgba(245,158,11,0.2);
    border-radius: 12px;
    margin-top: 6px;
    box-shadow: 0 12px 40px rgba(0,0,0,0.5);
    z-index: 100;
    max-height: 280px;
    overflow-y: auto;
}
.shop-ac-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    cursor: pointer;
    transition: background .12s;
    border-bottom: 1px solid rgba(255,255,255,0.04);
}
.shop-ac-item:hover, .shop-ac-item.active { background: rgba(245,158,11,0.08); }
.shop-ac-item .ac-name { color: #f1f5f9; font-weight: 500; font-size: 0.88rem; }
.shop-ac-item .ac-type {
    font-size: 0.65rem;
    font-weight: 600;
    text-transform: uppercase;
    padding: 2px 6px;
    border-radius: 4px;
    background: rgba(245,158,11,0.12);
    color: #F59E0B;
}

/* Location row */
.shop-loc-row {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 16px;
    flex-wrap: wrap;
}
.shop-loc-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(245,158,11,0.08);
    border: 1px solid rgba(245,158,11,0.2);
    border-radius: 10px;
    padding: 8px 14px;
    font-size: 0.82rem;
    color: #F59E0B;
    font-weight: 600;
}
.shop-loc-badge svg { flex-shrink: 0; }
.shop-loc-change {
    padding: 8px 16px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 8px;
    color: #a1a1aa;
    font-size: 0.8rem;
    font-weight: 500;
    cursor: pointer;
    font-family: inherit;
    transition: all 0.2s;
}
.shop-loc-change:hover { background: rgba(255,255,255,0.1); color: #f1f5f9; }

/* ═══ Sliders — Large, Prominent ═══ */
.shop-sliders-row {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}
.shop-slider-group {
    flex: 1;
    min-width: 140px;
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.06);
    border-radius: 12px;
    padding: 10px 14px;
    display: flex;
    flex-direction: column;
    gap: 6px;
    transition: opacity 0.3s, transform 0.3s;
}
.shop-spec-slider {
    animation: slideIn 0.3s ease-out;
}
@keyframes slideIn {
    from { opacity: 0; transform: translateY(-8px); }
    to { opacity: 1; transform: translateY(0); }
}
.shop-slider-group .slider-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.shop-slider-group label {
    font-size: 0.72rem;
    color: #71717a;
    white-space: nowrap;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.06em;
}
.shop-slider-group input[type="range"] {
    width: 100%;
    height: 6px;
    border-radius: 3px;
    -webkit-appearance: none;
    appearance: none;
    outline: none;
    cursor: pointer;
    background: rgba(255,255,255,0.08);
}
.shop-slider-group input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 3px solid #F59E0B;
    background: #1a1a1a;
    cursor: pointer;
    box-shadow: 0 0 8px rgba(245,158,11,0.3);
    transition: box-shadow .15s;
}
.shop-slider-group input[type="range"]::-webkit-slider-thumb:hover {
    box-shadow: 0 0 14px rgba(245,158,11,0.5);
}
.shop-slider-group input[type="range"]::-moz-range-thumb {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 3px solid #F59E0B;
    background: #1a1a1a;
    cursor: pointer;
}
/* Spec slider — cyan accent */
.shop-spec-slider input[type="range"]::-webkit-slider-thumb {
    border-color: #22D3EE;
    box-shadow: 0 0 8px rgba(34,211,238,0.3);
}
.shop-spec-slider input[type="range"]::-webkit-slider-thumb:hover {
    box-shadow: 0 0 14px rgba(34,211,238,0.5);
}
.shop-spec-slider input[type="range"]::-moz-range-thumb {
    border-color: #22D3EE;
}
.shop-slider-group .slider-val {
    font-size: 0.9rem;
    font-weight: 700;
    min-width: 44px;
    text-align: right;
}
.slider-val.amber { color: #F59E0B; }
.slider-val.green { color: #34D399; }
.slider-val.cyan  { color: #22D3EE; }
.quality-hint {
    font-size: 0.65rem;
    color: #52525b;
    margin-left: 4px;
}

/* ═══ Large Interactive Map ═══ */
.shop-hero-map {
    border-radius: 16px;
    overflow: hidden;
    border: 2px solid rgba(245,158,11,0.12);
    min-height: 320px;
    background: #111;
    position: relative;
    box-shadow: 0 4px 30px rgba(0,0,0,0.4);
}
#shopMiniMap {
    width: 100%;
    height: 100%;
    min-height: 320px;
}
.shop-hero-map .map-label {
    position: absolute;
    bottom: 10px;
    left: 10px;
    background: rgba(10,10,10,0.85);
    color: #F59E0B;
    font-size: 0.75rem;
    font-weight: 600;
    padding: 5px 10px;
    border-radius: 6px;
    z-index: 500;
    pointer-events: none;
    backdrop-filter: blur(4px);
    border: 1px solid rgba(245,158,11,0.2);
}

/* Filters bar */
.shop-filters {
    background: #fafafa;
    border-bottom: 1px solid #e5e5e5;
    padding: 10px 24px;
    position: sticky;
    top: 68px;
    z-index: 50;
    font-family: 'Inter', sans-serif;
}
.shop-filters-inner {
    max-width: 1280px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}
.shop-pills {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
}
.shop-pill {
    padding: 7px 16px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
    border: 1px solid #e5e5e5;
    background: #fff;
    color: #525252;
    cursor: pointer;
    transition: all 0.2s;
    font-family: inherit;
}
.shop-pill:hover { border-color: #F59E0B; color: #D97706; }
.shop-pill.active { background: #0a0a0a; color: #F59E0B; border-color: #0a0a0a; }
.shop-filter-sep { width: 1px; height: 24px; background: #e5e5e5; margin: 0 4px; }
.shop-filter-select {
    padding: 7px 12px;
    border: 1px solid #e5e5e5;
    border-radius: 8px;
    font-size: 0.8rem;
    font-family: inherit;
    color: #3f3f46;
    background: #fff;
    cursor: pointer;
    min-width: 110px;
}
.shop-price-inputs {
    display: flex;
    align-items: center;
    gap: 4px;
}
.shop-price-inputs input {
    width: 70px;
    padding: 7px 8px;
    border: 1px solid #E2E8F0;
    border-radius: 6px;
    font-size: 0.8rem;
    font-family: inherit;
}
.shop-price-inputs span { color: #94A3B8; font-size: 0.8rem; }

/* Product grid */
.shop-grid-container {
    max-width: 1280px;
    margin: 0 auto;
    padding: 16px 24px 24px;
}
.shop-grid {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 16px;
}
@media (max-width: 1200px) { .shop-grid { grid-template-columns: repeat(4, 1fr); } }
@media (max-width: 1024px) { .shop-grid { grid-template-columns: repeat(3, 1fr); } }
@media (max-width: 1024px) {
    .shop-hero-inner { grid-template-columns: 1fr; }
    .shop-hero-map { min-height: 240px; }
    #shopMiniMap { min-height: 240px; }
}
@media (max-width: 768px) {
    .shop-grid { grid-template-columns: repeat(2, 1fr); }
    .shop-hero { padding: 20px 16px; }
    .shop-hero-title { font-size: 1.5rem; }
    .shop-hero-map { min-height: 200px; }
    #shopMiniMap { min-height: 200px; }
    .shop-filters-inner { gap: 6px; }
    .shop-price-inputs input { width: 56px; }
}
@media (max-width: 480px) {
    .shop-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
    .shop-sliders-row { flex-direction: column; gap: 10px; }
    .shop-hero-map { min-height: 180px; }
}

/* Product card */
.shop-product-card {
    background: #fff;
    border-radius: 10px;
    border: 1px solid #E2E8F0;
    overflow: hidden;
    transition: box-shadow 0.25s, transform 0.2s;
    display: flex;
    flex-direction: column;
}
.shop-product-card:hover {
    box-shadow: 0 8px 24px rgba(0,0,0,0.1);
    transform: translateY(-3px);
}
.shop-product-card .card-img {
    width: 100%;
    aspect-ratio: 4/3;
    object-fit: contain;
    background: #F1F5F9;
    display: block;
}
.shop-product-card .card-img-placeholder {
    width: 100%;
    aspect-ratio: 4/3;
    background: linear-gradient(135deg, #F1F5F9 0%, #E2E8F0 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #CBD5E1;
}
.shop-card-body {
    padding: 10px 12px 12px;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 4px;
}
.shop-card-body .product-name {
    font-size: 0.82rem;
    font-weight: 600;
    color: #1E293B;
    line-height: 1.3;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.shop-card-body .product-brand-spec { font-size: 0.72rem; color: #64748B; }
.shop-type-badge {
    display: inline-block;
    font-size: 0.62rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    padding: 2px 6px;
    border-radius: 3px;
    width: fit-content;
}
.shop-type-badge.inverter  { background: #DBEAFE; color: #1E40AF; }
.shop-type-badge.battery   { background: #D1FAE5; color: #065F46; }
.shop-type-badge.panel     { background: #FEF3C7; color: #92400E; }
.shop-type-badge.installation_appliance { background: #E0E7FF; color: #3730A3; }

.shop-card-price { font-size: 1rem; font-weight: 700; color: #0D3B6E; margin-top: 2px; }
.shop-card-dealer {
    font-size: 0.7rem; color: #94A3B8;
    display: flex; align-items: center; gap: 3px;
    overflow: hidden; white-space: nowrap; text-overflow: ellipsis;
}
.shop-card-dealer svg { flex-shrink: 0; }
.shop-card-meta { display: flex; align-items: center; justify-content: space-between; gap: 4px; }
.shop-distance-badge {
    font-size: 0.65rem; font-weight: 700; color: #0D3B6E; background: #DBEAFE;
    padding: 2px 6px; border-radius: 4px; white-space: nowrap; flex-shrink: 0;
}
.shop-stock-badge {
    font-size: 0.65rem; font-weight: 600; padding: 1px 6px; border-radius: 3px; width: fit-content;
}
.shop-stock-badge.in-stock    { background: #D1FAE5; color: #065F46; }
.shop-stock-badge.low-stock   { background: #FEF3C7; color: #92400E; }
.shop-stock-badge.out-of-stock { background: #FEE2E2; color: #991B1B; }

.shop-card-actions { display: flex; gap: 6px; margin-top: auto; padding-top: 6px; }
.shop-add-cart {
    flex: 1; padding: 8px 6px; background: #F59E0B; color: #fff; font-weight: 600;
    font-size: 0.75rem; border: none; border-radius: 6px; cursor: pointer;
    transition: background 0.2s; font-family: inherit; text-align: center;
}
.shop-add-cart:hover { background: #D97706; }
.shop-add-cart:disabled { background: #CBD5E1; cursor: not-allowed; }
.shop-visit-btn {
    padding: 8px 10px; background: #F1F5F9; color: #475569; font-weight: 500;
    font-size: 0.75rem; border: 1px solid #E2E8F0; border-radius: 6px;
    cursor: pointer; font-family: inherit; text-decoration: none; text-align: center;
    transition: all 0.2s;
}
.shop-visit-btn:hover { background: #E2E8F0; color: #0D3B6E; }

/* States */
.shop-empty-state { text-align: center; padding: 48px 24px; color: #64748B; font-family: 'Inter', sans-serif; }
.shop-empty-state svg { margin-bottom: 12px; }
.shop-empty-state h3 { font-size: 1.1rem; color: #334155; margin: 0 0 6px; }
.shop-empty-state p { font-size: 0.9rem; margin: 0 0 16px; color: #94A3B8; }
.shop-empty-state .btn-locate {
    display: inline-flex; align-items: center; gap: 6px; padding: 10px 20px;
    background: #0D3B6E; color: #fff; border: none; border-radius: 8px;
    font-size: 0.85rem; font-weight: 600; cursor: pointer; font-family: inherit;
}
.shop-empty-state .btn-locate:hover { background: #0B2E56; }

/* Loading */
.shop-load-more { text-align: center; padding: 20px; color: #94A3B8; font-size: 0.85rem; font-family: 'Inter', sans-serif; }
.shop-load-more .spinner {
    display: inline-block; width: 22px; height: 22px; border: 3px solid #E2E8F0;
    border-top-color: #0D3B6E; border-radius: 50%; animation: shop-spin 0.7s linear infinite; margin-bottom: 6px;
}
@keyframes shop-spin { to { transform: rotate(360deg); } }

/* Toast */
.shop-toast {
    position: fixed; bottom: 24px; right: 24px; background: #065F46; color: #fff;
    padding: 10px 18px; border-radius: 8px; font-size: 0.85rem; font-family: 'Inter', sans-serif;
    font-weight: 500; box-shadow: 0 4px 16px rgba(0,0,0,0.15); z-index: 9999;
    transform: translateY(100px); opacity: 0; transition: all 0.3s ease;
}
.shop-toast.show { transform: translateY(0); opacity: 1; }
.shop-toast.error { background: #991B1B; }

/* Results */
.shop-results-info { font-size: 0.8rem; color: #64748B; padding: 0 0 10px; font-family: 'Inter', sans-serif; }

/* Cart preview */
.shop-cart-preview {
    display: none; position: absolute; top: 100%; right: 0; background: #fff;
    border: 1px solid #E2E8F0; border-radius: 10px; box-shadow: 0 8px 24px rgba(0,0,0,0.12);
    min-width: 200px; padding: 10px 0; z-index: 1000; font-family: 'Inter', sans-serif;
}
.sg-cart-btn:hover .shop-cart-preview { display: block; }
.shop-cart-preview-title {
    font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em;
    color: #94A3B8; padding: 0 12px 6px; border-bottom: 1px solid #F1F5F9;
}
.shop-cart-preview-item { font-size: 0.8rem; color: #334155; padding: 5px 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 220px; }
.shop-cart-preview-link { display: block; font-size: 0.78rem; font-weight: 600; color: #0D3B6E; padding: 6px 12px 0; border-top: 1px solid #F1F5F9; margin-top: 4px; text-decoration: none; }
.shop-cart-preview-link:hover { color: #F59E0B; }

/* Map modal overlay */
.shop-map-overlay {
    display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6);
    z-index: 9000; align-items: center; justify-content: center; padding: 20px;
}
.shop-map-overlay.active { display: flex; }
.shop-map-modal {
    background: #fff; border-radius: 16px; width: 100%; max-width: 640px;
    overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,0.3); animation: mapSlideUp 0.25s ease;
}
@keyframes mapSlideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
.shop-map-header { padding: 14px 20px; border-bottom: 1px solid #E2E8F0; display: flex; align-items: center; justify-content: space-between; }
.shop-map-header h3 { font-size: 1rem; font-weight: 700; color: #1E293B; margin: 0; }
.shop-map-close {
    width: 32px; height: 32px; border-radius: 8px; border: none; background: #F1F5F9;
    color: #64748B; font-size: 1.25rem; cursor: pointer; display: flex; align-items: center; justify-content: center;
}
.shop-map-close:hover { background: #E2E8F0; }
.shop-map-body { padding: 14px 20px; }
.shop-map-search { display: flex; gap: 8px; margin-bottom: 10px; }
.shop-map-search input {
    flex: 1; padding: 9px 12px; border: 1.5px solid #E2E8F0; border-radius: 8px;
    font-size: 0.85rem; font-family: inherit; outline: none;
}
.shop-map-search input:focus { border-color: #F59E0B; }
.shop-map-search button {
    padding: 9px 16px; background: #F59E0B; color: #fff; border: none; border-radius: 8px;
    font-size: 0.82rem; font-weight: 600; cursor: pointer; font-family: inherit;
}
.shop-map-search button:hover { background: #D97706; }
#shopModalMap { width: 100%; height: 320px; border-radius: 10px; overflow: hidden; border: 1px solid #E2E8F0; }
.shop-map-footer {
    padding: 10px 20px 14px; display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-wrap: wrap;
}
.shop-map-coords { font-size: 0.78rem; color: #64748B; }
.shop-map-confirm {
    padding: 9px 22px; background: #0D3B6E; color: #fff; border: none; border-radius: 8px;
    font-size: 0.85rem; font-weight: 600; cursor: pointer; font-family: inherit;
}
.shop-map-confirm:hover { background: #0B2E56; }
.shop-map-geolocate {
    padding: 9px 14px; background: #F1F5F9; color: #475569; border: 1px solid #E2E8F0;
    border-radius: 8px; font-size: 0.8rem; font-weight: 500; cursor: pointer; font-family: inherit;
}
.shop-map-geolocate:hover { background: #E2E8F0; }

/* (old search bar styles removed — search is now in hero section) */

/* Autocomplete dropdown */
.shop-autocomplete {
    position: absolute; top: 100%; left: 0; right: 0; background: #1a1a1a;
    border: 1px solid rgba(245,158,11,0.2); border-top: none; border-radius: 0 0 14px 14px;
    box-shadow: 0 12px 36px rgba(0,0,0,0.5); z-index: 500; max-height: 320px; overflow-y: auto;
    backdrop-filter: blur(20px);
}
.shop-ac-item {
    display: flex; align-items: center; gap: 10px; padding: 11px 16px;
    cursor: pointer; transition: background 0.15s; text-decoration: none; color: inherit;
    border-bottom: 1px solid rgba(255,255,255,0.05);
}
.shop-ac-item:last-child { border-bottom: none; }
.shop-ac-item:hover, .shop-ac-item.active { background: rgba(245,158,11,0.12); }
.shop-ac-item .ac-name { font-size: 0.85rem; font-weight: 500; color: #f1f5f9; flex: 1; }
.shop-ac-item .ac-brand { font-size: 0.72rem; color: #94A3B8; }
.shop-ac-item .ac-type {
    font-size: 0.62rem; font-weight: 600; text-transform: uppercase; padding: 2px 6px;
    border-radius: 3px; letter-spacing: 0.03em; flex-shrink: 0;
}
.shop-ac-item .ac-type.inverter  { background: rgba(59,130,246,0.2); color: #93C5FD; }
.shop-ac-item .ac-type.battery   { background: rgba(16,185,129,0.2); color: #6EE7B7; }
.shop-ac-item .ac-type.panel     { background: rgba(245,158,11,0.2); color: #FCD34D; }
.shop-ac-item .ac-type.installation_appliance { background: rgba(139,92,246,0.2); color: #C4B5FD; }

.shop-ac-empty { padding: 14px; text-align: center; color: #94A3B8; font-size: 0.82rem; }

/* Load More button */
.shop-load-more-btn {
    display: block; margin: 20px auto; padding: 12px 32px;
    background: linear-gradient(135deg, #F59E0B, #D97706); color: #fff;
    border: none; border-radius: 10px; font-size: 0.9rem; font-weight: 600; cursor: pointer;
    font-family: 'Inter', sans-serif; transition: all 0.25s; box-shadow: 0 4px 12px rgba(245,158,11,0.3);
}
.shop-load-more-btn:hover { background: linear-gradient(135deg, #D97706, #B45309); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(245,158,11,0.4); }

/* Outside radius section */
.shop-outside-radius {
    max-width: 1280px; margin: 0 auto; padding: 0 24px 40px;
    font-family: 'Inter', sans-serif;
}
.shop-outside-header {
    display: flex; align-items: center; gap: 8px; font-size: 0.9rem; font-weight: 600;
    color: #64748B; padding: 16px 0 12px; border-top: 1px dashed #E2E8F0; margin-top: 16px;
}
.shop-grid-outside { grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)) !important; }
</style>

<!-- ═══════════════ Hero Section — Solar Black Theme ═══════════════ -->
<div class="shop-hero">
    <div class="shop-hero-canvas" id="shopParticleCanvas"></div>
    <div class="shop-hero-inner">
        <div class="shop-hero-left">
            <h1 class="shop-hero-title">Solar <span>Shop</span></h1>
            <p class="shop-hero-sub">Find the best solar products from verified dealers near you. Search, compare, and visit stores.</p>

            <!-- Animated Search Bar — in Hero -->
            <div class="shop-hero-search">
                <div class="shop-hero-search-box">
                    <div class="search-icon-wrap">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    </div>
                    <input type="text" id="shopSearchInput" class="shop-hero-search-input" placeholder="Search inverters, batteries, panels..." autocomplete="off">
                    <button type="button" id="shopSearchClear" class="shop-hero-search-clear" style="display:none;">&times;</button>
                </div>
                <div class="shop-autocomplete" id="shopAutocomplete" style="display:none;"></div>
            </div>

            <div class="shop-loc-row">
                <div class="shop-loc-badge">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <span id="shopLocationLabel">
                        <?php if ($user_location['detected']): ?>
                            <?= sanitize($user_location['city'] ?: 'Your Location') ?>
                        <?php else: ?>
                            Set location
                        <?php endif; ?>
                    </span>
                </div>
                <button class="shop-loc-change" id="shopChangeLocation" type="button">📍 Change Location</button>
            </div>

            <!-- Sliders: Radius / Quality / Price / Spec -->
            <div class="shop-sliders-row">
                <div class="shop-slider-group">
                    <div class="slider-header">
                        <label>📍 Radius</label>
                        <span class="slider-val amber" id="shopRadiusValue"><?= (int)$user_radius ?> km</span>
                    </div>
                    <input type="range" id="shopRadius" min="10" max="200" step="5" value="<?= (int)$user_radius ?>">
                </div>
                <div class="shop-slider-group">
                    <div class="slider-header">
                        <label>⭐ Quality</label>
                        <span class="slider-val green" id="shopQualityValue">100</span>
                        <span class="quality-hint" id="shopQualityHint">Balanced</span>
                    </div>
                    <input type="range" id="shopQuality" min="0" max="200" step="1" value="100">
                </div>
                <div class="shop-slider-group">
                    <div class="slider-header">
                        <label>💰 Max Price</label>
                        <span class="slider-val amber" id="shopPriceSliderValue">Any</span>
                    </div>
                    <input type="range" id="shopPriceSlider" min="0" max="<?= (int)($page_currency['exchange_rate'] * 10000) ?>" step="<?= (int)max(100, $page_currency['exchange_rate'] * 100) ?>" value="<?= (int)($page_currency['exchange_rate'] * 10000) ?>">
                </div>
                <!-- Dynamic spec slider — changes by product type -->
                <div class="shop-slider-group shop-spec-slider" id="shopSpecSliderWrap" style="display:none;">
                    <div class="slider-header">
                        <label id="shopSpecLabel">⚡ Power</label>
                        <span class="slider-val cyan" id="shopSpecValue">Any</span>
                    </div>
                    <input type="range" id="shopSpecSlider" min="0" max="10000" step="100" value="10000">
                </div>
            </div>
        </div>

        <!-- Bigger Map -->
        <div class="shop-hero-map">
            <div id="shopMiniMap"></div>
            <div class="map-label" id="shopMapLabel">Your area — click map to set location</div>
        </div>
    </div>
</div>

<!-- Map Modal (for Change Location) -->
<div class="shop-map-overlay" id="shopMapOverlay">
    <div class="shop-map-modal">
        <div class="shop-map-header">
            <h3>Choose Your Location</h3>
            <button class="shop-map-close" id="shopMapClose" type="button">&times;</button>
        </div>
        <div class="shop-map-body">
            <div class="shop-map-search">
                <input type="text" id="shopMapSearchInput" placeholder="Search city or address...">
                <button type="button" id="shopMapSearchBtn">Search</button>
            </div>
            <div id="shopModalMap"></div>
        </div>
        <div class="shop-map-footer">
            <button class="shop-map-geolocate" id="shopMapGeolocate" type="button">&#128205; Use My Location</button>
            <span class="shop-map-coords" id="shopMapCoords"></span>
            <button class="shop-map-confirm" id="shopMapConfirm" type="button">Confirm Location</button>
        </div>
    </div>
</div>

<!-- Filters Bar -->
<div class="shop-filters">
    <div class="shop-filters-inner">
        <div class="shop-pills">
            <button class="shop-pill active" data-type="all">All</button>
            <button class="shop-pill" data-type="inverter">Inverters</button>
            <button class="shop-pill" data-type="battery">Batteries</button>
            <button class="shop-pill" data-type="panel">Panels</button>
            <button class="shop-pill" data-type="installation_appliance">Installation</button>
        </div>
        <div class="shop-filter-sep"></div>
        <select class="shop-filter-select" id="shopSort">
            <option value="distance" selected>Nearest First</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="best_match">Best Match</option>
        </select>
        <select class="shop-filter-select" id="shopBrand">
            <option value="">All Brands</option>
        </select>
        <!-- Price now controlled by hero slider -->
        <input type="hidden" id="shopMinPrice" value="">
        <input type="hidden" id="shopMaxPrice" value="">
    </div>
</div>

<!-- Product Grid -->
<div class="shop-grid-container">
    <div class="shop-results-info" id="shopResultsInfo"></div>
    <div class="shop-grid" id="shopGrid"></div>
    <div class="shop-load-more" id="shopLoadMore" style="display:none;">
        <div class="spinner"></div>
        <div>Loading products...</div>
    </div>
    <button type="button" id="shopLoadMoreBtn" class="shop-load-more-btn" style="display:none;">Load More Products</button>
    <div id="shopEndMessage" style="display:none;" class="shop-load-more">No more products</div>
</div>

<!-- Outside Radius Results -->
<div class="shop-outside-radius" id="shopOutsideRadius" style="display:none;">
    <div class="shop-outside-header">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
        Also available outside your area:
    </div>
    <div class="shop-grid shop-grid-outside" id="shopOutsideGrid"></div>
</div>

<!-- Toast -->
<div class="shop-toast" id="shopToast"></div>

<!-- Google Maps (try first) or Leaflet fallback loaded via PHP -->
<?php if ($maps_key): ?>
<script>
var useGoogleMaps = false;
function shopGmapsReady() { useGoogleMaps = true; if (window.shopInitMaps) window.shopInitMaps(); }
function gm_authFailure() { useGoogleMaps = false; /* Load Leaflet fallback */ var lk=document.createElement('link'); lk.rel='stylesheet'; lk.href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(lk); var sc=document.createElement('script'); sc.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; sc.onload=function(){ if(window.shopInitMaps) window.shopInitMaps(); }; document.head.appendChild(sc); }
</script>
<script async src="https://maps.googleapis.com/maps/api/js?key=<?= sanitize($maps_key) ?>&libraries=places&callback=shopGmapsReady"></script>
<?php else: ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
<script>var useGoogleMaps = false;</script>
<?php endif; ?>

<script>
(function() {
    'use strict';

    // ══════════════════════════════════════════════
    // Anime.js Particle Background
    // ══════════════════════════════════════════════
    (function initParticles() {
        var canvas = document.getElementById('shopParticleCanvas');
        if (!canvas || typeof anime === 'undefined') return;

        var colors = ['#F59E0B', '#3B82F6', '#10B981', '#8B5CF6', '#F97316'];
        var particles = [];

        for (var i = 0; i < 30; i++) {
            var dot = document.createElement('div');
            dot.className = 'particle';
            var size = Math.random() * 6 + 2;
            dot.style.width = size + 'px';
            dot.style.height = size + 'px';
            dot.style.background = colors[Math.floor(Math.random() * colors.length)];
            dot.style.left = Math.random() * 100 + '%';
            dot.style.top = Math.random() * 100 + '%';
            canvas.appendChild(dot);
            particles.push(dot);
        }

        anime({
            targets: particles,
            translateX: function() { return anime.random(-80, 80); },
            translateY: function() { return anime.random(-60, 60); },
            opacity: [
                { value: 0.4, duration: 1200, easing: 'easeInOutQuad' },
                { value: 0.08, duration: 2400, easing: 'easeInOutQuad' }
            ],
            scale: function() { return [0.5, anime.random(1, 2.5)]; },
            duration: function() { return anime.random(3000, 6000); },
            delay: function() { return anime.random(0, 2000); },
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine',
        });

        // Floating glow lines
        for (var j = 0; j < 4; j++) {
            var line = document.createElement('div');
            line.style.cssText = 'position:absolute;width:' + (Math.random()*200+100) + 'px;height:1px;background:linear-gradient(90deg,transparent,rgba(245,158,11,0.15),transparent);top:' + (Math.random()*100) + '%;left:-10%;opacity:0;';
            canvas.appendChild(line);
            anime({
                targets: line,
                translateX: ['0%', '120%'],
                opacity: [0, 0.6, 0],
                duration: anime.random(4000, 8000),
                delay: anime.random(0, 3000),
                loop: true,
                easing: 'linear',
            });
        }
    })();

    // ══════════════════════════════════════════════
    // State
    // ══════════════════════════════════════════════
    var COOKIE_PATH = '/solarglobal/';
    var COOKIE_DAYS = 30;

    // Currency config from server
    var currencySymbol = <?= json_encode($page_currency['currency_symbol']) ?>;
    var currencyCode   = <?= json_encode($page_currency['currency_code']) ?>;
    var exchangeRate   = <?= json_encode((float)$page_currency['exchange_rate']) ?>;
    var countryFlag    = <?= json_encode($page_currency['flag_emoji'] ?? '') ?>;
    var priceSliderMax = <?= (int)($page_currency['exchange_rate'] * 10000) ?>;

    var state = {
        lat: <?= json_encode($user_location['lat']) ?>,
        lng: <?= json_encode($user_location['lng']) ?>,
        city: <?= json_encode($user_location['city'] ?: '') ?>,
        country_code: <?= json_encode($user_location['country_code'] ?: '') ?>,
        detected: <?= $user_location['detected'] ? 'true' : 'false' ?>,
        radius: <?= (int)$user_radius ?>,
        quality: 100,
        type: 'all',
        sort: 'distance',
        brand: '',
        min_price: '',
        max_price: '',
        min_spec: '',
        max_spec: '',
        search_name: '',
        offset: 0,
        limit: 20,
        total: 0,
        loading: false,
        allLoaded: false,
    };

    // DOM refs
    var $grid          = document.getElementById('shopGrid');
    var $loadMore      = document.getElementById('shopLoadMore');
    var $endMessage    = document.getElementById('shopEndMessage');
    var $locationLabel = document.getElementById('shopLocationLabel');
    var $radiusSlider  = document.getElementById('shopRadius');
    var $radiusValue   = document.getElementById('shopRadiusValue');
    var $qualitySlider = document.getElementById('shopQuality');
    var $qualityValue  = document.getElementById('shopQualityValue');
    var $qualityHint   = document.getElementById('shopQualityHint');
    var $sort          = document.getElementById('shopSort');
    var $brand         = document.getElementById('shopBrand');
    var $minPrice      = document.getElementById('shopMinPrice');
    var $maxPrice      = document.getElementById('shopMaxPrice');
    var $resultsInfo   = document.getElementById('shopResultsInfo');
    var $toast         = document.getElementById('shopToast');
    var $mapLabel      = document.getElementById('shopMapLabel');
    var $searchInput   = document.getElementById('shopSearchInput');
    var $searchClear   = document.getElementById('shopSearchClear');
    var $autocomplete  = document.getElementById('shopAutocomplete');
    var $loadMoreBtn   = document.getElementById('shopLoadMoreBtn');
    var $outsideRadius = document.getElementById('shopOutsideRadius');
    var $outsideGrid   = document.getElementById('shopOutsideGrid');
    var $priceSlider   = document.getElementById('shopPriceSlider');
    var $priceSliderVal= document.getElementById('shopPriceSliderValue');

    // Map modal
    var $mapOverlay   = document.getElementById('shopMapOverlay');
    var $mapClose     = document.getElementById('shopMapClose');
    var $mapSearch    = document.getElementById('shopMapSearchInput');
    var $mapSearchBtn = document.getElementById('shopMapSearchBtn');
    var $mapGeolocate = document.getElementById('shopMapGeolocate');
    var $mapConfirm   = document.getElementById('shopMapConfirm');
    var $mapCoords    = document.getElementById('shopMapCoords');

    // Map instances
    var miniMap = null, miniMarker = null, miniCircle = null;
    var modalMap = null, modalMarker = null, modalCircle = null;
    var gMiniMap = null, gMiniMarker = null, gMiniCircle = null;
    var gModalMap = null, gModalMarker = null, gModalCircle = null;
    var tempLat = null, tempLng = null, tempCity = '', tempCountry = '';

    // ══════════════════════════════════════════════
    // Cookie helpers
    // ══════════════════════════════════════════════
    function setCookie(n, v, d) { var dt=new Date(); dt.setTime(dt.getTime()+d*86400000); document.cookie=n+'='+encodeURIComponent(v)+';expires='+dt.toUTCString()+';path='+COOKIE_PATH; }
    function getCookie(n) { var m=document.cookie.match(new RegExp('(^| )'+n+'=([^;]+)')); return m?decodeURIComponent(m[2]):null; }
    function saveLocation() { setCookie('sg_location',JSON.stringify({lat:state.lat,lng:state.lng,city:state.city,country_code:state.country_code}),COOKIE_DAYS); }
    function saveRadius() { setCookie('sg_radius',state.radius,COOKIE_DAYS); }

    // ══════════════════════════════════════════════
    // Location
    // ══════════════════════════════════════════════
    function updateLocationUI() {
        if (state.detected && (state.city || (state.lat && state.lng))) {
            $locationLabel.textContent = state.city || 'Your Location';
            $mapLabel.textContent = state.city || 'Your area';
        } else {
            $locationLabel.textContent = 'Set location';
            $mapLabel.textContent = 'Set location';
        }
        updateMiniMap();
    }

    function reverseGeocode(lat, lng, cb) {
        if (typeof google !== 'undefined' && google.maps && google.maps.Geocoder) {
            var gc = new google.maps.Geocoder();
            gc.geocode({ location: { lat: lat, lng: lng } }, function(results, status) {
                if (status === 'OK' && results[0]) {
                    var city = '', cc = '';
                    results[0].address_components.forEach(function(c) {
                        if (c.types.includes('locality')) city = c.long_name;
                        if (c.types.includes('administrative_area_level_1') && !city) city = c.long_name;
                        if (c.types.includes('country')) cc = c.short_name;
                    });
                    cb(city, cc);
                } else {
                    nominatimReverse(lat, lng, cb);
                }
            });
        } else {
            nominatimReverse(lat, lng, cb);
        }
    }

    function nominatimReverse(lat, lng, cb) {
        fetch('https://nominatim.openstreetmap.org/reverse?format=json&lat='+lat+'&lon='+lng+'&zoom=10&addressdetails=1',{headers:{'Accept-Language':'en'}})
        .then(function(r){return r.json();})
        .then(function(d){var a=d.address||{};cb(a.city||a.town||a.village||a.county||'',(a.country_code||'').toUpperCase());})
        .catch(function(){cb('','');});
    }

    function detectViaIP() {
        fetch('https://ip-api.com/json/?fields=lat,lon,city,countryCode')
        .then(function(r){return r.json();})
        .then(function(d){
            if(d.lat&&d.lon){state.lat=d.lat;state.lng=d.lon;state.city=d.city||'';state.country_code=d.countryCode||'';state.detected=true;saveLocation();updateLocationUI();resetAndLoad();}
        }).catch(function(){});
    }

    function detectViaBrowser(cb) {
        if(!navigator.geolocation){if(cb)cb(false);return;}
        navigator.geolocation.getCurrentPosition(function(pos){
            var lat=pos.coords.latitude,lng=pos.coords.longitude;
            reverseGeocode(lat,lng,function(city,cc){
                state.lat=lat;state.lng=lng;state.city=city;state.country_code=cc;state.detected=true;
                saveLocation();updateLocationUI();resetAndLoad();if(cb)cb(true,lat,lng,city,cc);
            });
        },function(){if(!state.detected)detectViaIP();if(cb)cb(false);},{enableHighAccuracy:false,timeout:8000});
    }

    // ══════════════════════════════════════════════
    // Mini Map (in hero)
    // ══════════════════════════════════════════════
    function initMiniMapGoogle() {
        var center = { lat: state.lat||30, lng: state.lng||69 };
        gMiniMap = new google.maps.Map(document.getElementById('shopMiniMap'), {
            center: center, zoom: state.detected ? 10 : 4,
            disableDefaultUI: true, zoomControl: false, gestureHandling: 'none',
            styles: [{ featureType: 'all', elementType: 'labels', stylers: [{ visibility: 'simplified' }] }],
        });
        gMiniMarker = new google.maps.Marker({ position: center, map: gMiniMap, icon: { path: google.maps.SymbolPath.CIRCLE, scale: 8, fillColor: '#F59E0B', fillOpacity: 1, strokeColor: '#fff', strokeWeight: 2 }});
        gMiniCircle = new google.maps.Circle({ map: gMiniMap, center: center, radius: state.radius * 1000, fillColor: '#F59E0B', fillOpacity: 0.08, strokeColor: '#F59E0B', strokeWeight: 1.5 });
    }

    function initMiniMapLeaflet() {
        var lat = state.lat || 30, lng = state.lng || 69;
        miniMap = L.map('shopMiniMap', { center: [lat, lng], zoom: state.detected ? 10 : 4, zoomControl: false, dragging: false, scrollWheelZoom: false, doubleClickZoom: false, touchZoom: false, attributionControl: false });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18 }).addTo(miniMap);
        miniMarker = L.circleMarker([lat, lng], { radius: 7, fillColor: '#F59E0B', fillOpacity: 1, color: '#fff', weight: 2 }).addTo(miniMap);
        miniCircle = L.circle([lat, lng], { radius: state.radius * 1000, color: '#F59E0B', fillColor: '#F59E0B', fillOpacity: 0.08, weight: 1.5 }).addTo(miniMap);
    }

    function updateMiniMap() {
        var lat = state.lat || 30, lng = state.lng || 69;
        if (useGoogleMaps && gMiniMap) {
            gMiniMap.setCenter({ lat: lat, lng: lng });
            if (state.detected) gMiniMap.setZoom(10);
            gMiniMarker.setPosition({ lat: lat, lng: lng });
            gMiniCircle.setCenter({ lat: lat, lng: lng });
            gMiniCircle.setRadius(state.radius * 1000);
        } else if (miniMap) {
            miniMap.setView([lat, lng], state.detected ? 10 : 4);
            miniMarker.setLatLng([lat, lng]);
            miniCircle.setLatLng([lat, lng]);
            miniCircle.setRadius(state.radius * 1000);
        }
    }

    // ══════════════════════════════════════════════
    // Modal Map (for Change Location)
    // ══════════════════════════════════════════════
    function openMapModal() {
        $mapOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
        tempLat = state.lat || 30; tempLng = state.lng || 69;
        tempCity = state.city; tempCountry = state.country_code;

        setTimeout(function() {
            if (useGoogleMaps) {
                initModalMapGoogle();
            } else {
                initModalMapLeaflet();
            }
            updateMapCoords();
        }, 120);
    }

    function initModalMapGoogle() {
        var center = { lat: tempLat, lng: tempLng };
        if (!gModalMap) {
            gModalMap = new google.maps.Map(document.getElementById('shopModalMap'), {
                center: center, zoom: state.detected ? 11 : 4, zoomControl: true, mapTypeControl: false, streetViewControl: false, fullscreenControl: false
            });
            gModalMarker = new google.maps.Marker({ position: center, map: gModalMap, draggable: true });
            gModalCircle = new google.maps.Circle({ map: gModalMap, center: center, radius: state.radius * 1000, fillColor: '#F59E0B', fillOpacity: 0.08, strokeColor: '#F59E0B', strokeWeight: 2 });

            gModalMarker.addListener('dragend', function() {
                var p = gModalMarker.getPosition();
                tempLat = p.lat(); tempLng = p.lng();
                gModalCircle.setCenter(p);
                updateMapCoords();
                reverseGeocode(tempLat, tempLng, function(c, cc) { tempCity = c; tempCountry = cc; updateMapCoords(); });
            });
            gModalMap.addListener('click', function(e) {
                tempLat = e.latLng.lat(); tempLng = e.latLng.lng();
                gModalMarker.setPosition(e.latLng);
                gModalCircle.setCenter(e.latLng);
                updateMapCoords();
                reverseGeocode(tempLat, tempLng, function(c, cc) { tempCity = c; tempCountry = cc; updateMapCoords(); });
            });
        } else {
            gModalMap.setCenter(center);
            gModalMap.setZoom(state.detected ? 11 : 4);
            gModalMarker.setPosition(center);
            gModalCircle.setCenter(center);
            gModalCircle.setRadius(state.radius * 1000);
        }
    }

    function initModalMapLeaflet() {
        if (!modalMap) {
            modalMap = L.map('shopModalMap', { center: [tempLat, tempLng], zoom: state.detected ? 11 : 4, zoomControl: true });
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OSM', maxZoom: 18 }).addTo(modalMap);
            modalMarker = L.marker([tempLat, tempLng], { draggable: true }).addTo(modalMap);
            modalCircle = L.circle([tempLat, tempLng], { radius: state.radius * 1000, color: '#F59E0B', fillColor: '#F59E0B', fillOpacity: 0.08, weight: 2 }).addTo(modalMap);

            modalMarker.on('dragend', function() {
                var p = modalMarker.getLatLng(); tempLat = p.lat; tempLng = p.lng;
                modalCircle.setLatLng(p); updateMapCoords();
                reverseGeocode(tempLat, tempLng, function(c, cc) { tempCity = c; tempCountry = cc; updateMapCoords(); });
            });
            modalMap.on('click', function(e) {
                tempLat = e.latlng.lat; tempLng = e.latlng.lng;
                modalMarker.setLatLng(e.latlng); modalCircle.setLatLng(e.latlng); updateMapCoords();
                reverseGeocode(tempLat, tempLng, function(c, cc) { tempCity = c; tempCountry = cc; updateMapCoords(); });
            });
        } else {
            modalMap.setView([tempLat, tempLng], state.detected ? 11 : 4);
            modalMarker.setLatLng([tempLat, tempLng]);
            modalCircle.setLatLng([tempLat, tempLng]);
            modalCircle.setRadius(state.radius * 1000);
        }
        modalMap.invalidateSize();
    }

    function closeMapModal() { $mapOverlay.classList.remove('active'); document.body.style.overflow = ''; }

    function updateMapCoords() {
        var t = tempLat.toFixed(4) + ', ' + tempLng.toFixed(4);
        if (tempCity) t = tempCity + ' (' + t + ')';
        $mapCoords.textContent = t;
    }

    function searchOnMap(q) {
        if (!q.trim()) return;
        if (useGoogleMaps && google.maps.places) {
            var svc = new google.maps.places.PlacesService(gModalMap);
            svc.findPlaceFromQuery({ query: q, fields: ['geometry', 'name'] }, function(results, status) {
                if (status === google.maps.places.PlacesServiceStatus.OK && results[0]) {
                    var loc = results[0].geometry.location;
                    tempLat = loc.lat(); tempLng = loc.lng();
                    gModalMarker.setPosition(loc); gModalCircle.setCenter(loc);
                    gModalMap.setCenter(loc); gModalMap.setZoom(12);
                    reverseGeocode(tempLat, tempLng, function(c, cc) { tempCity = c; tempCountry = cc; updateMapCoords(); });
                } else { nominatimSearch(q); }
            });
        } else { nominatimSearch(q); }
    }

    function nominatimSearch(q) {
        fetch('https://nominatim.openstreetmap.org/search?format=json&q='+encodeURIComponent(q)+'&limit=1&addressdetails=1',{headers:{'Accept-Language':'en'}})
        .then(function(r){return r.json();})
        .then(function(res){
            if(res.length>0){
                var r=res[0]; tempLat=parseFloat(r.lat); tempLng=parseFloat(r.lon);
                var a=r.address||{}; tempCity=a.city||a.town||a.village||a.county||r.display_name.split(',')[0]||'';
                tempCountry=(a.country_code||'').toUpperCase();
                if(modalMap){modalMarker.setLatLng([tempLat,tempLng]);modalCircle.setLatLng([tempLat,tempLng]);modalMap.setView([tempLat,tempLng],12);}
                if(gModalMap){var ll=new google.maps.LatLng(tempLat,tempLng);gModalMarker.setPosition(ll);gModalCircle.setCenter(ll);gModalMap.setCenter(ll);gModalMap.setZoom(12);}
                updateMapCoords();
            } else { showToast('Location not found',true); }
        }).catch(function(){showToast('Search failed',true);});
    }

    // Map modal events
    $mapClose.addEventListener('click', closeMapModal);
    $mapOverlay.addEventListener('click', function(e) { if (e.target === $mapOverlay) closeMapModal(); });
    $mapSearchBtn.addEventListener('click', function() { searchOnMap($mapSearch.value); });
    $mapSearch.addEventListener('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); searchOnMap($mapSearch.value); }});

    $mapGeolocate.addEventListener('click', function() {
        if (!navigator.geolocation) { showToast('Geolocation not available', true); return; }
        $mapGeolocate.textContent = 'Locating...';
        navigator.geolocation.getCurrentPosition(function(pos) {
            tempLat = pos.coords.latitude; tempLng = pos.coords.longitude;
            if (modalMap) { modalMarker.setLatLng([tempLat, tempLng]); modalCircle.setLatLng([tempLat, tempLng]); modalMap.setView([tempLat, tempLng], 12); }
            if (gModalMap) { var ll = new google.maps.LatLng(tempLat, tempLng); gModalMarker.setPosition(ll); gModalCircle.setCenter(ll); gModalMap.setCenter(ll); gModalMap.setZoom(12); }
            reverseGeocode(tempLat, tempLng, function(c, cc) { tempCity = c; tempCountry = cc; updateMapCoords(); });
            $mapGeolocate.innerHTML = '&#128205; Use My Location';
        }, function() { showToast('Could not get location', true); $mapGeolocate.innerHTML = '&#128205; Use My Location'; }, { enableHighAccuracy: true, timeout: 10000 });
    });

    $mapConfirm.addEventListener('click', function() {
        state.lat = tempLat; state.lng = tempLng; state.city = tempCity; state.country_code = tempCountry;
        state.detected = true; saveLocation(); updateLocationUI(); closeMapModal(); resetAndLoad();
    });

    document.getElementById('shopChangeLocation').addEventListener('click', openMapModal);

    // ══════════════════════════════════════════════
    // Quality slider
    // ══════════════════════════════════════════════
    function applyQualityFilter() {
        var q = state.quality;
        if (q <= 40) { state.sort = 'price_asc'; $sort.value = 'price_asc'; $qualityHint.textContent = 'Budget'; }
        else if (q <= 80) { $qualityHint.textContent = 'Economy'; }
        else if (q <= 120) { $qualityHint.textContent = 'Balanced'; }
        else if (q <= 160) { $qualityHint.textContent = 'Premium'; }
        else { state.sort = 'price_desc'; $sort.value = 'price_desc'; $qualityHint.textContent = 'Luxury'; }
        resetAndLoad();
    }
    $qualitySlider.addEventListener('input', function() { state.quality = parseInt(this.value); $qualityValue.textContent = state.quality; });
    var qualityDB = debounce(function() { applyQualityFilter(); }, 400);
    $qualitySlider.addEventListener('input', qualityDB);

    // ══════════════════════════════════════════════
    // Price slider (local currency)
    // ══════════════════════════════════════════════
    function formatPriceLabel(v) {
        if (v >= priceSliderMax) return 'Any';
        if (v >= 1000000) return currencySymbol + (v/1000000).toFixed(1) + 'M';
        if (v >= 1000) return currencySymbol + (v/1000).toFixed(v%1000?1:0) + 'k';
        return currencySymbol + v.toLocaleString();
    }
    $priceSlider.addEventListener('input', function() {
        var val = parseInt(this.value);
        $priceSliderVal.textContent = formatPriceLabel(val);
        // Send local currency value — backend will convert to USD
        state.max_price = val >= priceSliderMax ? '' : val;
    });
    var priceSliderDB = debounce(function() { resetAndLoad(); }, 400);
    $priceSlider.addEventListener('input', priceSliderDB);

    // ══════════��═══════════════════════════════════
    // Spec slider (dynamic per product type)
    // ══════════════════════════════════════════════
    var $specSliderWrap = document.getElementById('shopSpecSliderWrap');
    var $specSlider     = document.getElementById('shopSpecSlider');
    var $specValue      = document.getElementById('shopSpecValue');
    var $specLabel      = document.getElementById('shopSpecLabel');

    var specConfigs = {
        inverter: { label: '⚡ Power (kW)', min: 0, max: 20000, step: 500, unit: 'W', format: function(v, mx) { return v >= mx ? 'Any' : (v >= 1000 ? (v/1000)+'kW' : v+'W'); }},
        battery:  { label: '🔋 Capacity (Ah)', min: 0, max: 500, step: 10, unit: 'Ah', format: function(v, mx) { return v >= mx ? 'Any' : v+'Ah'; }},
        panel:    { label: '☀️ Wattage (W)', min: 0, max: 700, step: 10, unit: 'W', format: function(v, mx) { return v >= mx ? 'Any' : v+'W'; }},
    };

    function updateSpecSlider(type) {
        var cfg = specConfigs[type];
        if (!cfg) {
            $specSliderWrap.style.display = 'none';
            state.min_spec = ''; state.max_spec = '';
            return;
        }
        $specSliderWrap.style.display = 'block';
        $specLabel.textContent = cfg.label;
        $specSlider.min = cfg.min;
        $specSlider.max = cfg.max;
        $specSlider.step = cfg.step;
        $specSlider.value = cfg.max;
        $specValue.textContent = 'Any';
        state.min_spec = ''; state.max_spec = '';
    }

    $specSlider.addEventListener('input', function() {
        var cfg = specConfigs[state.type];
        if (!cfg) return;
        var val = parseInt(this.value);
        $specValue.textContent = cfg.format(val, parseInt(this.max));
        state.max_spec = val >= parseInt(this.max) ? '' : val;
    });
    var specDB = debounce(function() { resetAndLoad(); }, 400);
    $specSlider.addEventListener('input', specDB);

    // ══════════════════════════════════════════════
    // Products
    // ══════════════════════════════════════════════
    function buildUrl(overrides) {
        overrides = overrides || {};
        var p = new URLSearchParams({
            ajax: 'products',
            type: overrides.type || state.type,
            sort: overrides.sort || state.sort,
            offset: overrides.offset !== undefined ? overrides.offset : state.offset,
            limit: overrides.limit || state.limit
        });
        if (state.detected && state.lat && state.lng) { p.set('lat', state.lat); p.set('lng', state.lng); p.set('radius', state.radius); }
        if (state.brand) p.set('brand', state.brand);
        if (state.min_price) p.set('min_price', state.min_price);
        if (state.max_price) p.set('max_price', state.max_price);
        if (state.min_spec) p.set('min_spec', state.min_spec);
        if (state.max_spec) p.set('max_spec', state.max_spec);
        if (state.search_name) p.set('search_name', state.search_name);
        if (overrides.outside_radius) p.set('outside_radius', '1');
        return 'store.php?' + p.toString();
    }

    function loadProducts(append) {
        if (state.loading) return;
        state.loading = true;
        if (append) $loadMore.style.display = 'block';
        $loadMoreBtn.style.display = 'none';

        fetch(buildUrl()).then(function(r){return r.json();}).then(function(data) {
            state.loading = false; $loadMore.style.display = 'none';
            if (!data.products) { if (!append) showEmptyState('no-products'); return; }
            state.total = data.total || 0;
            if (!append) $grid.innerHTML = '';
            if (data.products.length === 0 && !append) {
                showEmptyState('no-products');
                $resultsInfo.textContent = '';
                // Try outside radius when no results found
                if (state.search_name) loadOutsideRadius();
                return;
            }
            data.products.forEach(function(p) { $grid.appendChild(createCard(p)); });
            state.offset += data.products.length;
            state.allLoaded = (state.offset >= state.total) || (data.products.length < state.limit);
            $endMessage.style.display = state.allLoaded ? 'block' : 'none';
            $loadMoreBtn.style.display = state.allLoaded ? 'none' : 'block';
            $loadMoreBtn.textContent = 'Load More (' + $grid.children.length + ' of ' + state.total + ')';
            $resultsInfo.textContent = 'Showing ' + $grid.children.length + ' of ' + state.total + ' products';

            // If few results, also check outside radius
            if (!append && state.total < 5 && state.search_name) loadOutsideRadius();
        }).catch(function() { state.loading = false; $loadMore.style.display = 'none'; showToast('Failed to load products.', true); });
    }

    function loadOutsideRadius() {
        if (!state.detected || !state.search_name) { $outsideRadius.style.display = 'none'; return; }
        fetch(buildUrl({ outside_radius: true, offset: 0, limit: 5, sort: 'distance' }))
        .then(function(r){return r.json();}).then(function(data) {
            if (!data.products || data.products.length === 0) { $outsideRadius.style.display = 'none'; return; }
            $outsideGrid.innerHTML = '';
            data.products.forEach(function(p) { $outsideGrid.appendChild(createCard(p)); });
            $outsideRadius.style.display = 'block';
        }).catch(function() { $outsideRadius.style.display = 'none'; });
    }

    function resetAndLoad() {
        state.offset = 0; state.allLoaded = false;
        $endMessage.style.display = 'none';
        $loadMoreBtn.style.display = 'none';
        $outsideRadius.style.display = 'none';
        loadProducts(false);
    }

    // Card creation
    var placeholderSVG = '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#CBD5E1" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>';

    function createCard(p) {
        var card = document.createElement('div');
        card.className = 'shop-product-card';
        var sc = 'in-stock', sl = 'In Stock';
        if (p.stock_qty <= 0 || p.stock_status === 'out_of_stock') { sc = 'out-of-stock'; sl = 'Out of Stock'; }
        else if (p.stock_qty <= 5) { sc = 'low-stock'; sl = 'Low Stock'; }
        var dl = escapeHtml(p.dealer_name || 'Dealer');
        if (p.dealer_city) dl += ' &middot; ' + escapeHtml(p.dealer_city);
        var distBadge = '';
        if (p.distance_km !== null && p.distance_km < 9999999) {
            distBadge = '<span class="shop-distance-badge">' + p.distance_km + ' km</span>';
        }
        var tl = { inverter: 'Inverter', battery: 'Battery', panel: 'Panel', installation_appliance: 'Installation' };
        var oos = (p.stock_qty <= 0 || p.stock_status === 'out_of_stock');
      card.innerHTML =
    (p.image ? '<img class="card-img" src="'+escapeHtml(p.image)+'" alt="'+escapeHtml(p.name)+'" loading="lazy" onerror="this.outerHTML=\'<div class=card-img-placeholder>\'+placeholderSVGHtmlSafe+\'</div>\'">'
             : '<div class="card-img-placeholder">'+placeholderSVG+'</div>')+
            '<div class="shop-card-body">' +
                '<span class="shop-type-badge '+escapeHtml(p.product_type)+'">'+(tl[p.product_type]||p.product_type)+'</span>' +
                '<a class="product-name" href="<?= BASE_URL ?>'+escapeHtml(p.product_type)+'-detail.php?id='+p.product_id+'" title="'+escapeHtml(p.name)+'" style="text-decoration:none;color:inherit;" onclick="event.stopPropagation()">'+escapeHtml(p.name)+'</a>' +
                '<div class="product-brand-spec">'+escapeHtml(p.brand||'')+(p.spec?' &middot; '+escapeHtml(p.spec):'')+'</div>' +
                '<div class="shop-card-price">'+p.formatted_price+'</div>' +
                '<div class="shop-card-meta">' +
                    '<div class="shop-card-dealer"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/></svg> '+dl+'</div>' +
                    distBadge +
                '</div>' +
                '<span class="shop-stock-badge '+sc+'">'+sl+'</span>' +
                '<div class="shop-card-actions">' +
                    '<button class="shop-add-cart"'+(oos?' disabled':'')+' data-type="'+escapeHtml(p.product_type)+'" data-pid="'+p.product_id+'" data-did="'+p.dealer_id+'">'+(oos?'Out of Stock':'&#128722; Add to Cart')+'</button>' +
                    '<a class="shop-visit-btn" href="<?= BASE_URL ?>store-detail.php?id='+p.dealer_id+'">Store</a>' +
                '</div>' +
            '</div>';

        if (!oos) { var btn = card.querySelector('.shop-add-cart'); btn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); addToCart(p.product_type, p.product_id, p.dealer_id, btn); }); }
        card.addEventListener('click', function(e) { if (e.target.closest('.shop-add-cart') || e.target.closest('.shop-visit-btn')) return; window.location.href = '<?= BASE_URL ?>store-detail.php?id=' + p.dealer_id; });
        card.style.cursor = 'pointer';
        return card;
    }

    // Empty states
    function showEmptyState(reason) {
        var h = '';
        if (reason === 'no-location') {
            h = '<div class="shop-empty-state"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg><h3>Enable Location</h3><p>Allow location access to discover solar products nearby.</p><button class="btn-locate" id="btnEnableLocation">Enable Location</button></div>';
        } else {
            h = '<div class="shop-empty-state"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><h3>No Products Found</h3><p>No products within '+state.radius+' km. Try increasing radius or changing filters.</p></div>';
        }
        $grid.innerHTML = h;
        var btn = document.getElementById('btnEnableLocation');
        if (btn) btn.addEventListener('click', function() { detectViaBrowser(); });
    }

    // Cart
    var recentCartItems = [];
    function addToCart(pt, pid, did, btn) {
        var orig = btn.innerHTML;
        var pn = btn.closest('.shop-card-body') ? btn.closest('.shop-card-body').querySelector('.product-name')?.textContent || 'Product' : 'Product';
        btn.textContent = 'Adding...'; btn.disabled = true;
        fetch('api/cart.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'add', product_type: pt, product_id: pid, dealer_id: did, quantity: 1 }) })
        .then(function(r){return r.json();}).then(function(d) {
            btn.disabled = false;
            if (d.success) {
                btn.innerHTML = '&#10003; Added!'; showToast('Added to cart');
                var cb = document.querySelector('.sg-cart-badge'), cBtn = document.querySelector('.sg-cart-btn');
                if (d.cart_count !== undefined) { if (!cb && cBtn) { cb = document.createElement('span'); cb.className = 'sg-cart-badge'; cBtn.appendChild(cb); } if (cb) cb.textContent = d.cart_count; }
                recentCartItems.unshift(pn); if (recentCartItems.length > 5) recentCartItems.pop(); updateCartPreview();
                setTimeout(function() { btn.innerHTML = orig; }, 1500);
            } else { btn.innerHTML = orig; showToast(d.error || 'Could not add to cart.', true); }
        }).catch(function() { btn.disabled = false; btn.innerHTML = orig; showToast('Network error.', true); });
    }

    function updateCartPreview() {
        var cBtn = document.querySelector('.sg-cart-btn');
        if (!cBtn || recentCartItems.length === 0) return;
        var pv = cBtn.querySelector('.shop-cart-preview');
        if (!pv) { pv = document.createElement('div'); pv.className = 'shop-cart-preview'; cBtn.style.position = 'relative'; cBtn.appendChild(pv); }
        var h = '<div class="shop-cart-preview-title">Recently Added</div>';
        recentCartItems.forEach(function(n) { h += '<div class="shop-cart-preview-item">' + escapeHtml(n) + '</div>'; });
        h += '<a href="<?= BASE_URL ?>customer/cart.php?view=cart" class="shop-cart-preview-link">View Cart &rarr;</a>';
        pv.innerHTML = h;
    }

    // Toast
    var toastTimer = null;
    function showToast(msg, err) { $toast.textContent = msg; $toast.className = 'shop-toast' + (err ? ' error' : '') + ' show'; clearTimeout(toastTimer); toastTimer = setTimeout(function() { $toast.className = 'shop-toast'; }, 3000); }

    // Utility
    function escapeHtml(s) { if (!s) return ''; var d = document.createElement('div'); d.appendChild(document.createTextNode(s)); return d.innerHTML; }
    function debounce(fn, ms) { var t; return function() { clearTimeout(t); t = setTimeout(fn, ms); }; }

    // Event bindings
    document.querySelectorAll('.shop-pill').forEach(function(pill) {
        pill.addEventListener('click', function() { document.querySelectorAll('.shop-pill').forEach(function(p){p.classList.remove('active');}); pill.classList.add('active'); state.type = pill.dataset.type; updateSpecSlider(state.type); resetAndLoad(); });
    });
    $sort.addEventListener('change', function() { state.sort = this.value; resetAndLoad(); });
    $brand.addEventListener('change', function() { state.brand = this.value; resetAndLoad(); });
    var priceDB = debounce(function() { state.min_price = $minPrice.value || ''; state.max_price = $maxPrice.value || ''; resetAndLoad(); }, 500);
    $minPrice.addEventListener('input', priceDB); $maxPrice.addEventListener('input', priceDB);
    $radiusSlider.addEventListener('input', function() { state.radius = parseInt(this.value); $radiusValue.textContent = state.radius + ' km'; });
    var radiusDB = debounce(function() { saveRadius(); updateMiniMap(); resetAndLoad(); }, 300);
    $radiusSlider.addEventListener('input', radiusDB);

    // Load More button (replaces infinite scroll)
    $loadMoreBtn.addEventListener('click', function() { loadProducts(true); });

    // Load brands
    fetch('store.php?ajax=brands').then(function(r){return r.json();}).then(function(d){ if(d.brands&&d.brands.length){d.brands.forEach(function(b){var o=document.createElement('option');o.value=b;o.textContent=b;$brand.appendChild(o);});}}).catch(function(){});

    // ══════════════════════════════════════════════
    // Autocomplete Search
    // ══════════════════════════════════════════════
    var acTimer = null, acIndex = -1;
    var typeLabels = { inverter: 'Inverter', battery: 'Battery', panel: 'Panel', installation_appliance: 'Accessory' };

    $searchInput.addEventListener('input', function() {
        var q = this.value.trim();
        $searchClear.style.display = q ? 'flex' : 'none';
        clearTimeout(acTimer);
        if (q.length < 2) { $autocomplete.style.display = 'none'; acIndex = -1; return; }
        acTimer = setTimeout(function() { fetchAutocomplete(q); }, 300);
    });

    $searchInput.addEventListener('keydown', function(e) {
        var items = $autocomplete.querySelectorAll('.shop-ac-item');
        if (!items.length) {
            if (e.key === 'Enter') { e.preventDefault(); state.search_name = this.value.trim(); $autocomplete.style.display = 'none'; resetAndLoad(); }
            return;
        }
        if (e.key === 'ArrowDown') { e.preventDefault(); acIndex = Math.min(acIndex + 1, items.length - 1); highlightAC(items); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); acIndex = Math.max(acIndex - 1, 0); highlightAC(items); }
        else if (e.key === 'Enter') { e.preventDefault(); if (acIndex >= 0) items[acIndex].click(); else { state.search_name = this.value.trim(); $autocomplete.style.display = 'none'; resetAndLoad(); } }
        else if (e.key === 'Escape') { $autocomplete.style.display = 'none'; acIndex = -1; }
    });

    function highlightAC(items) {
        items.forEach(function(el, i) { el.classList.toggle('active', i === acIndex); });
        if (acIndex >= 0 && items[acIndex]) items[acIndex].scrollIntoView({ block: 'nearest' });
    }

    function fetchAutocomplete(q) {
        fetch('store.php?ajax=autocomplete&q=' + encodeURIComponent(q))
        .then(function(r){return r.json();}).then(function(d) {
            if (!d.suggestions || d.suggestions.length === 0) {
                $autocomplete.innerHTML = '<div class="shop-ac-empty">No matches for "' + escapeHtml(q) + '"</div>';
                $autocomplete.style.display = 'block';
                return;
            }
            var h = '';
            d.suggestions.forEach(function(s) {
                h += '<div class="shop-ac-item" data-name="'+escapeHtml(s.name)+'" data-type="'+escapeHtml(s.product_type)+'">'
                   + '<span class="ac-type '+escapeHtml(s.product_type)+'">'+(typeLabels[s.product_type]||s.product_type)+'</span>'
                   + '<span class="ac-name">'+escapeHtml(s.name)+'</span>'
                   + '<span class="ac-brand">'+escapeHtml(s.brand)+'</span>'
                   + '</div>';
            });
            $autocomplete.innerHTML = h;
            $autocomplete.style.display = 'block';
            acIndex = -1;

            // Click handlers
            $autocomplete.querySelectorAll('.shop-ac-item').forEach(function(item) {
                item.addEventListener('click', function() {
                    var name = this.dataset.name;
                    $searchInput.value = name;
                    $searchClear.style.display = 'flex';
                    state.search_name = name;
                    $autocomplete.style.display = 'none';
                    resetAndLoad();
                });
            });
        }).catch(function() { $autocomplete.style.display = 'none'; });
    }

    $searchClear.addEventListener('click', function() {
        $searchInput.value = '';
        $searchClear.style.display = 'none';
        state.search_name = '';
        $autocomplete.style.display = 'none';
        resetAndLoad();
    });

    // Close autocomplete on click outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.shop-hero-search')) { $autocomplete.style.display = 'none'; acIndex = -1; }
    });

    // ══════════════════════════════════════════════
    // Init maps + products
    // ══════════════════════════════════════════════
    window.shopInitMaps = function() {
        if (useGoogleMaps) { initMiniMapGoogle(); }
        else if (typeof L !== 'undefined') { initMiniMapLeaflet(); }
    };

    // If Google Maps already loaded (async callback fired before this ran)
    if (typeof useGoogleMaps !== 'undefined' && useGoogleMaps && typeof google !== 'undefined') {
        initMiniMapGoogle();
    }
    // If Leaflet already loaded (no Google Maps key)
    else if (typeof L !== 'undefined' && !useGoogleMaps) {
        setTimeout(initMiniMapLeaflet, 50);
    }

    // Init product loading
    if (!state.detected) { detectViaIP(); resetAndLoad(); } else { resetAndLoad(); }

})();
</script>

<?php require_once 'includes/footer.php'; ?>
