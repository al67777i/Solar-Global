<?php
/**
 * Solar Engine API
 * Advanced solar calculations: position, generation, optimization, financial analysis
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

require_once __DIR__ . '/../includes/SolarEngine.php';
require_once __DIR__ . '/../includes/helpers.php';

if (!rate_limit('api_solar', 30, 60)) { respond_rate_limited(); }

$action = $_GET['action'] ?? 'position';
$cityId = (int)($_GET['city_id'] ?? 0);

if (!$cityId && $action !== 'compare') {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'city_id parameter required']);
    exit;
}

try {
    $engine = new SolarEngine();

    switch ($action) {

        case 'position':
            $dateTime = $_GET['datetime'] ?? null;
            echo json_encode($engine->getSolarPosition($cityId, $dateTime));
            break;

        case 'sun_path':
            $date = $_GET['date'] ?? null;
            echo json_encode($engine->getSunPathData($cityId, $date));
            break;

        case 'optimal_tilt':
            $city = getCityById($cityId);
            if (!$city) {
                echo json_encode(['success' => false, 'error' => 'City not found']);
                break;
            }
            $month = isset($_GET['month']) ? (int)$_GET['month'] : null;
            $result = $engine->getOptimalTilt((float)$city['latitude'], $month);
            $result['success'] = true;
            $result['city'] = $city['name_en'];
            echo json_encode($result);
            break;

        case 'generation':
            $panelWatts = (int)($_GET['panel_watts'] ?? 550);
            $numPanels = (int)($_GET['num_panels'] ?? 4);
            $month = isset($_GET['month']) ? (int)$_GET['month'] : null;
            $tilt = isset($_GET['tilt']) ? (float)$_GET['tilt'] : null;
            $age = (float)($_GET['age_years'] ?? 0);

            echo json_encode($engine->calculateDetailedGeneration(
                $cityId, $panelWatts, $numPanels, $month, $tilt, $age
            ));
            break;

        case 'annual_yield':
            $panelWatts = (int)($_GET['panel_watts'] ?? 550);
            $numPanels = (int)($_GET['num_panels'] ?? 4);
            $tilt = isset($_GET['tilt']) ? (float)$_GET['tilt'] : null;
            $age = (float)($_GET['age_years'] ?? 0);

            echo json_encode($engine->getAnnualYield(
                $cityId, $panelWatts, $numPanels, $tilt, $age
            ));
            break;

        case 'forecast':
            $panelWatts = (int)($_GET['panel_watts'] ?? 550);
            $numPanels = (int)($_GET['num_panels'] ?? 4);

            echo json_encode($engine->generateForecast($cityId, $panelWatts, $numPanels));
            break;

        case 'optimize':
            $dailyKwh = (float)($_GET['daily_kwh'] ?? 0);
            $panelWatts = (int)($_GET['panel_watts'] ?? 550);

            if ($dailyKwh <= 0) {
                echo json_encode(['success' => false, 'error' => 'daily_kwh parameter required (> 0)']);
                break;
            }

            echo json_encode($engine->optimizeSystemSize($cityId, $dailyKwh, $panelWatts));
            break;

        case 'financial':
            $panelWatts = (int)($_GET['panel_watts'] ?? 550);
            $numPanels = (int)($_GET['num_panels'] ?? 4);
            $cost = (float)($_GET['system_cost'] ?? 0);
            $rate = (float)($_GET['electricity_rate'] ?? 0);
            $netRate = (float)($_GET['net_metering_rate'] ?? 0);
            $selfConsumption = (float)($_GET['self_consumption'] ?? 0.7);

            if ($cost <= 0) {
                echo json_encode(['success' => false, 'error' => 'system_cost parameter required (PKR)']);
                break;
            }

            echo json_encode($engine->getFinancialAnalysis(
                $cityId, $panelWatts, $numPanels, $cost, $rate, $netRate, $selfConsumption
            ));
            break;

        case 'compare':
            $cityIds = array_filter(array_map('intval', explode(',', $_GET['city_ids'] ?? '')));
            $panelWatts = (int)($_GET['panel_watts'] ?? 550);
            $numPanels = (int)($_GET['num_panels'] ?? 4);

            if (count($cityIds) < 2) {
                echo json_encode(['success' => false, 'error' => 'Provide at least 2 city_ids (comma-separated)']);
                break;
            }

            echo json_encode($engine->compareCities($cityIds, $panelWatts, $numPanels));
            break;

        default:
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => 'Invalid action',
                'available_actions' => [
                    'position' => 'Solar position (elevation, azimuth) for city at date/time',
                    'sun_path' => 'Full sun path data for visualization',
                    'optimal_tilt' => 'Optimal panel tilt angle for city',
                    'generation' => 'Detailed daily generation with all loss factors',
                    'annual_yield' => 'Complete 12-month generation forecast',
                    'forecast' => '30-day generation forecast (stored)',
                    'optimize' => 'Find optimal system size for daily consumption',
                    'financial' => 'ROI, payback, 25-year financial analysis',
                    'compare' => 'Compare generation across multiple cities'
                ]
            ]);
    }
} catch (Exception $e) {
    error_log("Solar API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error: ' . $e->getMessage()]);
}
