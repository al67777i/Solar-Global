<?php
require_once 'includes/db.php';
require_once 'includes/helpers.php';
set_security_headers();
trackVisitor($pdo);

$page_title = "About Us - SolarGlobal Solar System Recommender";
$page_description = "Learn about SolarGlobal, leading solar system recommendation platform. Founded by Bilal Ansar, Software Engineer from COMSATS University.";
$page_keywords = "SolarGlobal, solar system, Bilal Ansar, solar recommendation, solar energy";

$contact_email = get_system_setting('contact_email', 'info@solarglobal.com');
$contact_phone = get_system_setting('contact_phone', '+923054957063');
$whatsapp_number = get_system_setting('whatsapp_number', '923054957063');
$phone_clean = preg_replace('/[^+0-9]/', '', $contact_phone);
$whatsapp_clean = preg_replace('/[^0-9]/', '', $whatsapp_number);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo $page_description; ?>">
    <meta name="keywords" content="<?php echo $page_keywords; ?>">
    <meta name="author" content="Bilal Ansar - SolarGlobal">
    <meta name="robots" content="index, follow">
    <meta name="language" content="English">
    <meta name="revisit-after" content="7 days">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo getCurrentUrl(); ?>">
    <meta property="og:title" content="<?php echo $page_title; ?>">
    <meta property="og:description" content="<?php echo $page_description; ?>">
    <meta property="og:image" content="<?php echo getBaseUrl(); ?>/assets/images/og-image.jpg">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo getCurrentUrl(); ?>">
    <meta property="twitter:title" content="<?php echo $page_title; ?>">
    <meta property="twitter:description" content="<?php echo $page_description; ?>">

    <!-- Canonical URL -->
    <link rel="canonical" href="<?php echo getCurrentUrl(); ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- PWA Meta -->
    <meta name="theme-color" content="#0D3B6E">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="mobile-web-app-capable" content="yes">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/frontend.css">
    <link rel="stylesheet" href="assets/css/mobile-app.css">

    <!-- Anime.js -->
    <script src="assets/js/anime.min.js"></script>

    <style>
        /* ===== CSS Custom Properties ===== */
        :root {
            --abt-primary: #0D3B6E;
            --abt-accent: #10B981;
            --abt-accent-dark: #059669;
            --abt-dark-1: #0a0f1a;
            --abt-dark-2: #0f172a;
            --abt-dark-3: #1e293b;
            --abt-text-light: #f8fafc;
            --abt-text-dark: #334155;
            --abt-text-muted: #64748b;
            --abt-border: #e2e8f0;
            --abt-bg-light: #f8fafc;
            --abt-glow: rgba(16, 185, 129, 0.4);
        }

        html { scroll-behavior: smooth; }

        /* ===== HERO SECTION ===== */
        .abt-hero {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(160deg, #0a0f1a 0%, #0D3B6E 50%, #1a1a2e 100%);
            overflow: hidden;
            text-align: center;
            padding: 120px 20px 80px;
        }

        .abt-hero-bg {
            position: absolute;
            inset: 0;
            overflow: hidden;
            z-index: 0;
        }

        /* Animated SVG grid pattern */
        .abt-hero-bg svg {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0.07;
        }

        /* Floating solar particles (animated via anime.js) */
        .abt-particle {
            position: absolute;
            border-radius: 50%;
            background: rgba(16, 185, 129, 0.3);
            pointer-events: none;
        }

        /* Glowing orbs (animated via anime.js) */
        .abt-orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
        }
        .abt-orb--1 { width: 400px; height: 400px; background: #10B981; top: 10%; left: -5%; }
        .abt-orb--2 { width: 300px; height: 300px; background: #0D3B6E; bottom: 10%; right: -5%; animation-delay: -3s; }
        .abt-orb--3 { width: 200px; height: 200px; background: #10B981; top: 50%; left: 60%; animation-delay: -1.5s; }

        .abt-hero-content {
            position: relative;
            z-index: 2;
            max-width: 900px;
        }

        .abt-hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 20px;
            border-radius: 50px;
            border: 1px solid rgba(16, 185, 129, 0.3);
            background: rgba(16, 185, 129, 0.08);
            color: var(--abt-accent);
            font-size: 0.85rem;
            font-weight: 600;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            margin-bottom: 28px;
            opacity: 0;
            transform: translateY(30px);
        }

        .abt-hero h1 {
            font-size: 3.5rem;
            font-weight: 900;
            color: var(--abt-text-light);
            line-height: 1.1;
            letter-spacing: -0.03em;
            margin-bottom: 24px;
            opacity: 0;
            transform: translateY(30px);
        }

        .abt-hero h1 span {
            background: linear-gradient(135deg, #10B981, #34d399);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .abt-hero-sub {
            font-size: 1.2rem;
            color: rgba(248, 250, 252, 0.8);
            line-height: 1.7;
            max-width: 650px;
            margin: 0 auto 40px;
            opacity: 0;
            transform: translateY(30px);
        }

        /* Typewriter cursor for subtitle */
        .abt-typewriter {
            display: inline;
            border-right: 2px solid var(--abt-accent);
            animation: abt-blink 0.8s step-end infinite;
        }

        .abt-hero-buttons {
            display: flex;
            gap: 16px;
            justify-content: center;
            flex-wrap: wrap;
            opacity: 0;
            transform: translateY(30px);
        }

        .abt-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 16px 36px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 1rem;
            text-decoration: none;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: none;
            cursor: pointer;
            font-family: 'Inter', sans-serif;
        }

        .abt-btn--primary {
            background: linear-gradient(135deg, #10B981, #059669);
            color: white;
            box-shadow: 0 4px 20px rgba(16, 185, 129, 0.3);
        }
        .abt-btn--primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(16, 185, 129, 0.45);
        }

        .abt-btn--outline {
            background: transparent;
            color: white;
            border: 2px solid rgba(255,255,255,0.25);
        }
        .abt-btn--outline:hover {
            border-color: rgba(255,255,255,0.6);
            background: rgba(255,255,255,0.05);
            transform: translateY(-2px);
        }

        /* Scroll indicator */
        .abt-scroll-indicator {
            position: absolute;
            bottom: 40px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 2;
            animation: abt-bounce 2s ease infinite;
        }
        .abt-scroll-indicator span {
            display: block;
            width: 24px;
            height: 24px;
            border-right: 2px solid rgba(255,255,255,0.4);
            border-bottom: 2px solid rgba(255,255,255,0.4);
            transform: rotate(45deg);
        }

        /* ===== STATS SECTION ===== */
        .abt-stats {
            background: #fff;
            padding: 80px 20px;
            position: relative;
        }
        .abt-stats::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--abt-border), transparent);
        }

        .abt-stats-grid {
            max-width: 1100px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 40px;
        }

        .abt-stat-item {
            text-align: center;
            position: relative;
        }
        .abt-stat-item:not(:last-child)::after {
            content: '';
            position: absolute;
            right: -20px;
            top: 50%;
            transform: translateY(-50%);
            width: 1px;
            height: 60px;
            background: var(--abt-border);
        }

        .abt-stat-number {
            font-size: 3rem;
            font-weight: 900;
            color: var(--abt-dark-1);
            letter-spacing: -0.03em;
            line-height: 1;
            margin-bottom: 8px;
        }
        .abt-stat-number .abt-stat-suffix {
            color: var(--abt-accent);
        }

        .abt-stat-label {
            font-size: 0.95rem;
            color: var(--abt-text-muted);
            font-weight: 500;
        }

        /* ===== MISSION SECTION ===== */
        .abt-mission {
            padding: 100px 20px;
            background: var(--abt-bg-light);
        }

        .abt-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .abt-mission-grid {
            display: grid;
            grid-template-columns: 1fr 1.2fr;
            gap: 80px;
            align-items: center;
        }

        .abt-mission-visual {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .abt-mission-icon-wrap {
            width: 280px;
            height: 280px;
            border-radius: 32px;
            background: linear-gradient(135deg, rgba(13, 59, 110, 0.08), rgba(16, 185, 129, 0.08));
            border: 1px solid var(--abt-border);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 7rem;
            position: relative;
        }
        .abt-mission-icon-wrap::before {
            content: '';
            position: absolute;
            inset: -1px;
            border-radius: 32px;
            background: linear-gradient(135deg, var(--abt-accent), var(--abt-primary));
            opacity: 0;
            transition: opacity 0.5s ease;
            z-index: -1;
        }
        .abt-mission-icon-wrap:hover::before { opacity: 0.1; }

        .abt-section-label {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 14px;
            border-radius: 6px;
            background: rgba(16, 185, 129, 0.08);
            color: var(--abt-accent-dark);
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            margin-bottom: 16px;
        }

        .abt-section-title {
            font-size: 2.25rem;
            font-weight: 800;
            color: var(--abt-dark-1);
            letter-spacing: -0.02em;
            margin-bottom: 20px;
            line-height: 1.2;
        }

        .abt-section-text {
            font-size: 1.05rem;
            line-height: 1.8;
            color: var(--abt-text-dark);
            margin-bottom: 16px;
        }

        /* ===== FEATURES / WHAT WE OFFER ===== */
        .abt-features {
            padding: 100px 20px;
            background: #fff;
        }

        .abt-features-header {
            text-align: center;
            max-width: 600px;
            margin: 0 auto 60px;
        }

        .abt-features-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 28px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .abt-feature-card {
            background: #fff;
            border: 1px solid var(--abt-border);
            border-radius: 16px;
            padding: 36px 28px;
            text-align: center;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            opacity: 0;
            transform: translateY(30px);
        }
        .abt-feature-card.abt-visible {
            opacity: 1;
            transform: translateY(0);
        }

        .abt-feature-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 20px 50px rgba(13, 59, 110, 0.1);
            border-color: rgba(16, 185, 129, 0.3);
        }

        .abt-feature-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--abt-primary), var(--abt-accent));
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .abt-feature-card:hover::before { opacity: 1; }

        .abt-feature-icon {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.75rem;
            margin-bottom: 20px;
            background: linear-gradient(135deg, rgba(13, 59, 110, 0.06), rgba(16, 185, 129, 0.06));
        }

        .abt-feature-card h3 {
            font-size: 1.15rem;
            font-weight: 700;
            color: var(--abt-dark-1);
            margin-bottom: 10px;
        }

        .abt-feature-card p {
            font-size: 0.95rem;
            line-height: 1.7;
            color: var(--abt-text-muted);
        }

        /* ===== HOW IT WORKS ===== */
        .abt-how {
            padding: 100px 20px;
            background: var(--abt-bg-light);
        }

        .abt-how-header {
            text-align: center;
            max-width: 600px;
            margin: 0 auto 60px;
        }

        .abt-timeline {
            max-width: 700px;
            margin: 0 auto;
            position: relative;
        }

        .abt-timeline::before {
            content: '';
            position: absolute;
            left: 32px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: linear-gradient(180deg, var(--abt-accent), var(--abt-primary));
            border-radius: 2px;
        }

        .abt-timeline-item {
            display: flex;
            gap: 28px;
            margin-bottom: 48px;
            position: relative;
            opacity: 0;
            transform: translateX(-20px);
        }
        .abt-timeline-item.abt-visible {
            opacity: 1;
            transform: translateX(0);
        }
        .abt-timeline-item:last-child { margin-bottom: 0; }

        .abt-timeline-marker {
            flex-shrink: 0;
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--abt-primary), var(--abt-accent));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.25rem;
            font-weight: 800;
            position: relative;
            z-index: 1;
            box-shadow: 0 4px 16px rgba(13, 59, 110, 0.2);
        }

        .abt-timeline-content h3 {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--abt-dark-1);
            margin-bottom: 6px;
            margin-top: 4px;
        }

        .abt-timeline-content p {
            font-size: 0.95rem;
            color: var(--abt-text-muted);
            line-height: 1.7;
        }

        /* ===== FOUNDER SECTION ===== */
        .abt-founder {
            padding: 100px 20px;
            background: #fff;
        }

        .abt-founder-header {
            text-align: center;
            max-width: 600px;
            margin: 0 auto 60px;
        }

        .abt-founder-card {
            max-width: 900px;
            margin: 0 auto;
            background: var(--abt-bg-light);
            border: 1px solid var(--abt-border);
            border-radius: 24px;
            padding: 56px;
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 48px;
            align-items: start;
        }

        .abt-founder-avatar {
            width: 160px;
            height: 160px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--abt-primary), var(--abt-accent));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 3.5rem;
            font-weight: 900;
            letter-spacing: -0.03em;
            flex-shrink: 0;
            box-shadow: 0 8px 30px rgba(13, 59, 110, 0.15);
        }

        .abt-founder-details h3 {
            font-size: 1.75rem;
            font-weight: 800;
            color: var(--abt-dark-1);
            margin-bottom: 4px;
        }

        .abt-founder-title {
            font-size: 1.05rem;
            color: var(--abt-accent-dark);
            font-weight: 600;
            margin-bottom: 20px;
        }

        .abt-founder-meta {
            list-style: none;
            padding: 0;
            margin: 0 0 24px;
        }

        .abt-founder-meta li {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 8px 0;
            font-size: 0.95rem;
            color: var(--abt-text-dark);
            line-height: 1.6;
        }

        .abt-founder-meta li .abt-meta-icon {
            flex-shrink: 0;
            width: 36px;
            height: 36px;
            border-radius: 8px;
            background: rgba(13, 59, 110, 0.06);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
        }

        .abt-founder-quote {
            padding: 20px 24px;
            border-left: 3px solid var(--abt-accent);
            background: rgba(16, 185, 129, 0.04);
            border-radius: 0 12px 12px 0;
            font-style: italic;
            color: var(--abt-text-dark);
            font-size: 1rem;
            line-height: 1.8;
            margin-bottom: 24px;
        }

        .abt-founder-links {
            display: flex;
            gap: 12px;
        }

        .abt-founder-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 10px;
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .abt-founder-link--wa {
            background: rgba(37, 211, 102, 0.1);
            color: #128C7E;
        }
        .abt-founder-link--wa:hover {
            background: rgba(37, 211, 102, 0.18);
            transform: translateY(-2px);
        }

        .abt-founder-link--email {
            background: rgba(13, 59, 110, 0.06);
            color: var(--abt-primary);
        }
        .abt-founder-link--email:hover {
            background: rgba(13, 59, 110, 0.12);
            transform: translateY(-2px);
        }

        /* ===== WHY CHOOSE US ===== */
        .abt-why {
            padding: 100px 20px;
            background: var(--abt-bg-light);
        }

        .abt-why-header {
            text-align: center;
            max-width: 600px;
            margin: 0 auto 70px;
        }

        .abt-why-row {
            max-width: 1100px;
            margin: 0 auto 64px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
            opacity: 0;
            transform: translateY(30px);
        }
        .abt-why-row.abt-visible {
            opacity: 1;
            transform: translateY(0);
        }
        .abt-why-row:last-child { margin-bottom: 0; }
        .abt-why-row:nth-child(even) .abt-why-visual { order: 2; }
        .abt-why-row:nth-child(even) .abt-why-text { order: 1; }

        .abt-why-visual {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .abt-why-icon-wrap {
            width: 180px;
            height: 180px;
            border-radius: 28px;
            background: #fff;
            border: 1px solid var(--abt-border);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 5rem;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
        }
        .abt-why-icon-wrap:hover {
            transform: scale(1.05) rotate(2deg);
            box-shadow: 0 16px 40px rgba(13, 59, 110, 0.08);
        }

        .abt-why-text h3 {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--abt-dark-1);
            margin-bottom: 12px;
        }

        .abt-why-text p {
            font-size: 1.05rem;
            color: var(--abt-text-dark);
            line-height: 1.8;
        }

        /* ===== CTA SECTION ===== */
        .abt-cta {
            padding: 100px 20px;
            background: var(--abt-dark-1);
            position: relative;
            overflow: hidden;
        }

        .abt-cta-inner {
            max-width: 800px;
            margin: 0 auto;
            text-align: center;
            position: relative;
            z-index: 2;
            padding: 64px 40px;
            border-radius: 24px;
            border: 1px solid rgba(16, 185, 129, 0.15);
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(10px);
            animation: abt-glowBorder 4s ease-in-out infinite alternate;
        }

        .abt-cta h2 {
            font-size: 2.5rem;
            font-weight: 900;
            color: var(--abt-text-light);
            margin-bottom: 16px;
            letter-spacing: -0.02em;
        }

        .abt-cta p {
            font-size: 1.1rem;
            color: rgba(248, 250, 252, 0.65);
            margin-bottom: 36px;
            line-height: 1.7;
        }

        .abt-cta-buttons {
            display: flex;
            gap: 16px;
            justify-content: center;
            flex-wrap: wrap;
        }

        /* CTA background glow */
        .abt-cta-glow {
            position: absolute;
            width: 500px;
            height: 500px;
            border-radius: 50%;
            filter: blur(120px);
            opacity: 0.08;
            pointer-events: none;
        }
        .abt-cta-glow--1 {
            background: var(--abt-accent);
            top: -20%;
            left: -10%;
        }
        .abt-cta-glow--2 {
            background: var(--abt-primary);
            bottom: -20%;
            right: -10%;
        }

        /* ===== KEYFRAMES ===== */
        @keyframes abt-fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes abt-float {
            0%, 100% { transform: translateY(0) translateX(0); }
            25% { transform: translateY(-30px) translateX(10px); }
            50% { transform: translateY(-15px) translateX(-10px); }
            75% { transform: translateY(-40px) translateX(5px); }
        }

        @keyframes abt-pulse {
            from { opacity: 0.1; transform: scale(1); }
            to { opacity: 0.2; transform: scale(1.15); }
        }

        @keyframes abt-bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateX(-50%) translateY(0); }
            40% { transform: translateX(-50%) translateY(-10px); }
            60% { transform: translateX(-50%) translateY(-5px); }
        }

        @keyframes abt-blink {
            from, to { border-color: var(--abt-accent); }
            50% { border-color: transparent; }
        }

        @keyframes abt-glowBorder {
            from { box-shadow: 0 0 30px rgba(16, 185, 129, 0.05), inset 0 0 30px rgba(16, 185, 129, 0.02); }
            to { box-shadow: 0 0 60px rgba(16, 185, 129, 0.12), inset 0 0 60px rgba(16, 185, 129, 0.04); }
        }

        /* Transition utility for scroll animations */
        .abt-animate {
            transition: opacity 0.7s cubic-bezier(0.4, 0, 0.2, 1), transform 0.7s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 1024px) {
            .abt-features-grid { grid-template-columns: repeat(2, 1fr); }
            .abt-why-row { gap: 40px; }
        }

        @media (max-width: 768px) {
            .abt-hero { padding: 100px 20px 60px; min-height: auto; min-height: 90vh; }
            .abt-hero h1 { font-size: 2.2rem; }
            .abt-hero-sub { font-size: 1rem; }

            .abt-stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 32px;
            }
            .abt-stat-item:not(:last-child)::after { display: none; }
            .abt-stat-number { font-size: 2.25rem; }

            .abt-mission-grid {
                grid-template-columns: 1fr;
                gap: 40px;
                text-align: center;
            }
            .abt-mission-icon-wrap { width: 200px; height: 200px; font-size: 5rem; margin: 0 auto; }

            .abt-features-grid { grid-template-columns: 1fr 1fr; gap: 16px; }
            .abt-feature-card { padding: 24px 16px; }

            .abt-timeline::before { left: 24px; }
            .abt-timeline-marker { width: 48px; height: 48px; font-size: 1rem; }

            .abt-founder-card {
                grid-template-columns: 1fr;
                text-align: center;
                padding: 36px 24px;
                gap: 28px;
            }
            .abt-founder-avatar { margin: 0 auto; width: 120px; height: 120px; font-size: 2.5rem; }
            .abt-founder-meta li { justify-content: center; text-align: left; }
            .abt-founder-quote { text-align: left; }
            .abt-founder-links { justify-content: center; }

            .abt-why-row {
                grid-template-columns: 1fr;
                gap: 28px;
                text-align: center;
            }
            .abt-why-row:nth-child(even) .abt-why-visual { order: unset; }
            .abt-why-row:nth-child(even) .abt-why-text { order: unset; }
            .abt-why-icon-wrap { width: 140px; height: 140px; font-size: 4rem; margin: 0 auto; }

            .abt-cta h2 { font-size: 1.75rem; }
            .abt-cta-inner { padding: 40px 24px; }
        }

        @media (max-width: 480px) {
            .abt-hero h1 { font-size: 1.8rem; }
            .abt-features-grid { grid-template-columns: 1fr; }
            .abt-stats-grid { grid-template-columns: 1fr 1fr; }
            .abt-section-title { font-size: 1.75rem; }
        }
    </style>
</head>
<body>
    <?php include 'includes/header-nav.php'; ?>
    <?php include_once 'includes/ad_display.php'; ?>

    <?php renderAds('header'); ?>

    <!-- ===== HERO SECTION ===== -->
    <section class="abt-hero">
        <div class="abt-hero-bg">
            <!-- SVG circuit/mesh pattern -->
            <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
                <defs>
                    <pattern id="abt-grid" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
                        <path d="M 60 0 L 0 0 0 60" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="0.5"/>
                        <circle cx="0" cy="0" r="1.5" fill="rgba(16,185,129,0.6)"/>
                        <circle cx="60" cy="0" r="1.5" fill="rgba(16,185,129,0.6)"/>
                        <circle cx="0" cy="60" r="1.5" fill="rgba(16,185,129,0.6)"/>
                    </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#abt-grid)"/>
            </svg>

            <!-- Floating particles -->
            <div class="abt-particle" style="width:6px;height:6px;top:15%;left:10%;"></div>
            <div class="abt-particle" style="width:4px;height:4px;top:30%;left:80%;"></div>
            <div class="abt-particle" style="width:8px;height:8px;top:60%;left:25%;"></div>
            <div class="abt-particle" style="width:5px;height:5px;top:75%;left:65%;"></div>
            <div class="abt-particle" style="width:7px;height:7px;top:20%;left:50%;"></div>
            <div class="abt-particle" style="width:4px;height:4px;top:85%;left:40%;"></div>
            <div class="abt-particle" style="width:6px;height:6px;top:45%;left:90%;"></div>
            <div class="abt-particle" style="width:5px;height:5px;top:55%;left:5%;"></div>

            <!-- Glowing orbs -->
            <div class="abt-orb abt-orb--1"></div>
            <div class="abt-orb abt-orb--2"></div>
            <div class="abt-orb abt-orb--3"></div>

            <!-- Animated floating shapes (anime.js targets) -->
            <svg class="abt-float-shape" id="abt-shape-1" style="position:absolute;top:12%;left:8%;opacity:0;" width="48" height="48" viewBox="0 0 48 48" fill="none">
                <rect x="4" y="4" width="40" height="40" rx="8" stroke="rgba(16,185,129,0.25)" stroke-width="1.5" fill="none"/>
                <rect x="12" y="12" width="24" height="24" rx="4" stroke="rgba(16,185,129,0.15)" stroke-width="1" fill="rgba(16,185,129,0.04)"/>
            </svg>
            <svg class="abt-float-shape" id="abt-shape-2" style="position:absolute;top:25%;right:12%;opacity:0;" width="56" height="56" viewBox="0 0 56 56" fill="none">
                <circle cx="28" cy="28" r="24" stroke="rgba(255,255,255,0.1)" stroke-width="1.5" fill="none"/>
                <circle cx="28" cy="28" r="14" stroke="rgba(16,185,129,0.2)" stroke-width="1" fill="rgba(16,185,129,0.03)"/>
                <circle cx="28" cy="28" r="4" fill="rgba(16,185,129,0.3)"/>
            </svg>
            <svg class="abt-float-shape" id="abt-shape-3" style="position:absolute;bottom:20%;left:15%;opacity:0;" width="40" height="40" viewBox="0 0 40 40" fill="none">
                <polygon points="20,2 38,38 2,38" stroke="rgba(255,255,255,0.1)" stroke-width="1.5" fill="none"/>
            </svg>
            <svg class="abt-float-shape" id="abt-shape-4" style="position:absolute;top:60%;right:8%;opacity:0;" width="44" height="44" viewBox="0 0 44 44" fill="none">
                <path d="M22 2L42 22L22 42L2 22Z" stroke="rgba(16,185,129,0.2)" stroke-width="1.5" fill="rgba(16,185,129,0.03)"/>
            </svg>
            <svg class="abt-float-shape" id="abt-shape-5" style="position:absolute;bottom:15%;right:25%;opacity:0;" width="36" height="36" viewBox="0 0 36 36" fill="none">
                <circle cx="18" cy="18" r="8" stroke="rgba(255,255,255,0.12)" stroke-width="1"/>
                <line x1="18" y1="2" x2="18" y2="10" stroke="rgba(255,255,255,0.08)" stroke-width="1"/>
                <line x1="18" y1="26" x2="18" y2="34" stroke="rgba(255,255,255,0.08)" stroke-width="1"/>
                <line x1="2" y1="18" x2="10" y2="18" stroke="rgba(255,255,255,0.08)" stroke-width="1"/>
                <line x1="26" y1="18" x2="34" y2="18" stroke="rgba(255,255,255,0.08)" stroke-width="1"/>
            </svg>
        </div>

        <div class="abt-hero-content" id="abt-hero-content">
            <div class="abt-hero-badge" id="abt-hero-badge">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                About SolarGlobal
            </div>
            <h1 id="abt-hero-title">Powering the Future with <span>Smart Solar Technology</span></h1>
            <p class="abt-hero-sub" id="abt-typewriter-target"></p>
            <div class="abt-hero-buttons" id="abt-hero-buttons">
                <a href="index.php" class="abt-btn abt-btn--primary">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                    Get Started
                </a>
                <a href="contact.php" class="abt-btn abt-btn--outline">Contact Us</a>
            </div>
        </div>

        <div class="abt-scroll-indicator"><span></span></div>
    </section>

    <!-- ===== STATS SECTION ===== -->
    <section class="abt-stats">
        <div class="abt-stats-grid">
            <div class="abt-stat-item">
                <div class="abt-stat-number"><span class="abt-counter" data-target="80">0</span><span class="abt-stat-suffix">+</span></div>
                <div class="abt-stat-label">Inverter Brands</div>
            </div>
            <div class="abt-stat-item">
                <div class="abt-stat-number"><span class="abt-counter" data-target="50">0</span><span class="abt-stat-suffix">+</span></div>
                <div class="abt-stat-label">Battery Brands</div>
            </div>
            <div class="abt-stat-item">
                <div class="abt-stat-number"><span class="abt-counter" data-target="40">0</span><span class="abt-stat-suffix">+</span></div>
                <div class="abt-stat-label">Panel Manufacturers</div>
            </div>
            <div class="abt-stat-item">
                <div class="abt-stat-number"><span class="abt-counter" data-target="190">0</span><span class="abt-stat-suffix">+</span></div>
                <div class="abt-stat-label">Countries Served</div>
            </div>
        </div>
    </section>

    <!-- ===== MISSION SECTION ===== -->
    <section class="abt-mission">
        <div class="abt-container">
            <div class="abt-mission-grid">
                <div class="abt-mission-visual">
                    <div class="abt-mission-icon-wrap">
                        <svg width="120" height="120" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="60" cy="48" r="22" stroke="#0D3B6E" stroke-width="3" fill="none"/>
                            <circle cx="60" cy="48" r="8" fill="#10B981"/>
                            <line x1="60" y1="18" x2="60" y2="8" stroke="#10B981" stroke-width="2.5" stroke-linecap="round"/>
                            <line x1="60" y1="78" x2="60" y2="88" stroke="#10B981" stroke-width="2.5" stroke-linecap="round"/>
                            <line x1="30" y1="48" x2="20" y2="48" stroke="#10B981" stroke-width="2.5" stroke-linecap="round"/>
                            <line x1="100" y1="48" x2="90" y2="48" stroke="#10B981" stroke-width="2.5" stroke-linecap="round"/>
                            <line x1="38.8" y1="26.8" x2="31.7" y2="19.7" stroke="#10B981" stroke-width="2.5" stroke-linecap="round"/>
                            <line x1="81.2" y1="69.2" x2="88.3" y2="76.3" stroke="#10B981" stroke-width="2.5" stroke-linecap="round"/>
                            <line x1="38.8" y1="69.2" x2="31.7" y2="76.3" stroke="#10B981" stroke-width="2.5" stroke-linecap="round"/>
                            <line x1="81.2" y1="26.8" x2="88.3" y2="19.7" stroke="#10B981" stroke-width="2.5" stroke-linecap="round"/>
                            <rect x="36" y="94" width="48" height="20" rx="4" fill="none" stroke="#0D3B6E" stroke-width="2.5"/>
                            <line x1="48" y1="94" x2="48" y2="114" stroke="#0D3B6E" stroke-width="1.5"/>
                            <line x1="60" y1="94" x2="60" y2="114" stroke="#0D3B6E" stroke-width="1.5"/>
                            <line x1="72" y1="94" x2="72" y2="114" stroke="#0D3B6E" stroke-width="1.5"/>
                            <line x1="60" y1="78" x2="60" y2="94" stroke="#0D3B6E" stroke-width="2" stroke-dasharray="4 3"/>
                        </svg>
                    </div>
                </div>
                <div class="abt-mission-text">
                    <div class="abt-section-label">Our Mission</div>
                    <h2 class="abt-section-title">Making Solar Energy Accessible for Everyone</h2>
                    <p class="abt-section-text">
                        At SolarGlobal, we are revolutionizing how people choose solar systems. Our mission is to make solar energy
                        accessible, affordable, and easy to understand for everyone. We believe that every home and business
                        deserves clean, reliable, and cost-effective energy.
                    </p>
                    <p class="abt-section-text">
                        Through our advanced recommendation algorithm, we analyze your specific energy needs and recommend the
                        perfect solar system configuration &mdash; taking the guesswork out of going solar.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== WHAT WE OFFER ===== -->
    <section class="abt-features">
        <div class="abt-container">
            <div class="abt-features-header">
                <div class="abt-section-label">What We Offer</div>
                <h2 class="abt-section-title">Tools Built for Smarter Solar Decisions</h2>
                <p class="abt-section-text">Everything you need to plan, compare, and install your solar system with confidence.</p>
            </div>
            <div class="abt-features-grid">
                <div class="abt-feature-card abt-animate">
                    <div class="abt-feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a4 4 0 0 1 4 4c0 1.95-1.4 3.58-3.25 3.93L12 22l-.75-12.07A4.001 4.001 0 0 1 12 2z"/><path d="M8.5 8.5 4.21 5.5"/><path d="M15.5 8.5l4.29-3"/><path d="M12 10v4"/></svg>
                    </div>
                    <h3>Smart Recommendations</h3>
                    <p>Our AI-powered algorithm analyzes your load and recommends the perfect system configuration.</p>
                </div>
                <div class="abt-feature-card abt-animate" style="transition-delay:0.1s">
                    <div class="abt-feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                    </div>
                    <h3>Cost Comparison</h3>
                    <p>Compare BMS vs Non-BMS systems, see upfront costs, and calculate long-term savings.</p>
                </div>
                <div class="abt-feature-card abt-animate" style="transition-delay:0.2s">
                    <div class="abt-feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                    </div>
                    <h3>Detailed Analysis</h3>
                    <p>24-hour energy flow, battery backup time, ROI calculation, and payback period analysis.</p>
                </div>
                <div class="abt-feature-card abt-animate" style="transition-delay:0.3s">
                    <div class="abt-feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
                    </div>
                    <h3>Installation Guide</h3>
                    <p>Animated wiring diagrams, step-by-step instructions, and safety guidelines.</p>
                </div>
                <div class="abt-feature-card abt-animate" style="transition-delay:0.4s">
                    <div class="abt-feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                    </div>
                    <h3>Global Brands</h3>
                    <p>Access to 80+ inverter brands, 50+ battery brands, and 40+ panel manufacturers worldwide.</p>
                </div>
                <div class="abt-feature-card abt-animate" style="transition-delay:0.5s">
                    <div class="abt-feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>
                    </div>
                    <h3>Mobile Friendly</h3>
                    <p>Works perfectly on all devices &mdash; desktop, tablet, and mobile phones.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== HOW IT WORKS ===== -->
    <section class="abt-how">
        <div class="abt-container">
            <div class="abt-how-header">
                <div class="abt-section-label">How It Works</div>
                <h2 class="abt-section-title">Your Solar Journey in 4 Simple Steps</h2>
            </div>
            <div class="abt-timeline">
                <div class="abt-timeline-item abt-animate">
                    <div class="abt-timeline-marker">1</div>
                    <div class="abt-timeline-content">
                        <h3>Enter Your Load Details</h3>
                        <p>Tell us about your appliances, usage hours, and energy consumption. Our system captures every detail to ensure accuracy.</p>
                    </div>
                </div>
                <div class="abt-timeline-item abt-animate" style="transition-delay:0.15s">
                    <div class="abt-timeline-marker">2</div>
                    <div class="abt-timeline-content">
                        <h3>Get AI Recommendations</h3>
                        <p>Our algorithm analyzes your load, considers voltage compatibility and battery chemistry, then recommends the ideal system.</p>
                    </div>
                </div>
                <div class="abt-timeline-item abt-animate" style="transition-delay:0.3s">
                    <div class="abt-timeline-marker">3</div>
                    <div class="abt-timeline-content">
                        <h3>Customize Your System</h3>
                        <p>Choose from multiple brands, compare BMS vs Non-BMS options, review cost breakdowns, and fine-tune your configuration.</p>
                    </div>
                </div>
                <div class="abt-timeline-item abt-animate" style="transition-delay:0.45s">
                    <div class="abt-timeline-marker">4</div>
                    <div class="abt-timeline-content">
                        <h3>Find Nearby Dealers</h3>
                        <p>Connect with trusted solar installers and dealers in your area. Get quotes and start your solar journey today.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== FOUNDER SECTION ===== -->
    <section class="abt-founder">
        <div class="abt-container">
            <div class="abt-founder-header">
                <div class="abt-section-label">Meet the Founder</div>
                <h2 class="abt-section-title">The Vision Behind SolarGlobal</h2>
            </div>
            <div class="abt-founder-card">
                <div class="abt-founder-avatar">BA</div>
                <div class="abt-founder-details">
                    <h3>Bilal Ansar</h3>
                    <div class="abt-founder-title">Software Engineer &amp; Founder</div>

                    <div class="abt-founder-quote">
                        &ldquo;As a software engineer passionate about renewable energy, I created SolarGlobal to help people
                        make informed decisions about solar systems. With rising electricity costs, solar energy is no longer
                        a luxury &mdash; it&rsquo;s a necessity. SolarGlobal makes it easy to find the right system for your needs.&rdquo;
                    </div>

                    <ul class="abt-founder-meta">
                        <li>
                            <span class="abt-meta-icon">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
                            </span>
                            B.S. Software Engineering, COMSATS University Attock Campus
                        </li>
                        <li>
                            <span class="abt-meta-icon">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            </span>
                            SolarGlobal Headquarters, Kangniwala Main Kangni Wala Bazar, Mohalla Shama Ul Arfeen, Gujranwala, Pakistan
                        </li>
                        <li>
                            <span class="abt-meta-icon">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
                            </span>
                            SolarGlobal
                        </li>
                    </ul>

                    <div class="abt-founder-links">
                        <a href="https://wa.me/<?= sanitize($whatsapp_clean ?: '923054957063') ?>" target="_blank" rel="noopener" class="abt-founder-link abt-founder-link--wa">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="#128C7E"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                            WhatsApp
                        </a>
                        <a href="mailto:<?= sanitize($contact_email) ?>" class="abt-founder-link abt-founder-link--email">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                            Email
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== WHY CHOOSE US ===== -->
    <section class="abt-why">
        <div class="abt-container">
            <div class="abt-why-header">
                <div class="abt-section-label">Why Choose Us</div>
                <h2 class="abt-section-title">Built Different. Built Better.</h2>
            </div>

            <div class="abt-why-row abt-animate">
                <div class="abt-why-visual">
                    <div class="abt-why-icon-wrap">
                        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    </div>
                </div>
                <div class="abt-why-text">
                    <h3>Accurate Recommendations</h3>
                    <p>Our algorithm considers voltage compatibility, battery chemistry, and inverter specifications to ensure perfect system matching. Every recommendation is tailored to your unique energy profile.</p>
                </div>
            </div>

            <div class="abt-why-row abt-animate">
                <div class="abt-why-visual">
                    <div class="abt-why-icon-wrap">
                        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                    </div>
                </div>
                <div class="abt-why-text">
                    <h3>Transparent Pricing</h3>
                    <p>See complete cost breakdowns including panels, batteries, inverters, and installation estimates. No hidden fees, no surprises &mdash; just clear, honest numbers you can trust.</p>
                </div>
            </div>

            <div class="abt-why-row abt-animate">
                <div class="abt-why-visual">
                    <div class="abt-why-icon-wrap">
                        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#0D3B6E" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
                    </div>
                </div>
                <div class="abt-why-text">
                    <h3>Educational Resources</h3>
                    <p>Learn about series/parallel connections, BMS vs Non-BMS, battery types, and solar system basics. We empower you with knowledge to make confident decisions.</p>
                </div>
            </div>

            <div class="abt-why-row abt-animate">
                <div class="abt-why-visual">
                    <div class="abt-why-icon-wrap">
                        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                    </div>
                </div>
                <div class="abt-why-text">
                    <h3>Completely Free to Use</h3>
                    <p>No registration required. No hidden charges. Get instant, personalized solar system recommendations without any cost. Our platform is built to serve everyone.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== CTA SECTION ===== -->
    <section class="abt-cta">
        <div class="abt-cta-glow abt-cta-glow--1"></div>
        <div class="abt-cta-glow abt-cta-glow--2"></div>
        <div class="abt-cta-inner">
            <h2>Ready to Go Solar?</h2>
            <p>Get your personalized solar system recommendation in minutes. Join thousands of users who have already made the switch to clean energy.</p>
            <div class="abt-cta-buttons">
                <a href="index.php" class="abt-btn abt-btn--primary">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                    Get Started
                </a>
                <a href="contact.php" class="abt-btn abt-btn--outline">Contact Us</a>
            </div>
        </div>
    </section>

    <?php renderAds('footer'); ?>

    <?php include 'includes/footer.php'; ?>

    <!-- Schema.org Structured Data -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": "SolarGlobal",
        "url": "<?php echo getBaseUrl(); ?>",
        "logo": "<?php echo getBaseUrl(); ?>/assets/images/logo.png",
        "description": "Leading solar system recommendation and marketplace platform",
        "founder": {
            "@type": "Person",
            "name": "Bilal Ansar",
            "jobTitle": "Software Engineer",
            "email": "<?= sanitize($contact_email) ?>",
            "telephone": "<?= sanitize($phone_clean ?: '+923054957063') ?>",
            "alumniOf": {
                "@type": "CollegeOrUniversity",
                "name": "COMSATS University Attock Campus"
            },
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "Kangniwala Main Kangni Wala Bazar, Mohalla Shama Ul Arfeen",
                "addressLocality": "Gujranwala",
                "addressRegion": "Punjab",
                "addressCountry": "PK"
            }
        },
        "address": {
            "@type": "PostalAddress",
            "name": "SolarGlobal Headquarters",
            "streetAddress": "Kangniwala Main Kangni Wala Bazar, Mohalla Shama Ul Arfeen",
            "addressLocality": "Gujranwala",
            "addressRegion": "Punjab",
            "addressCountry": "PK"
        },
        "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "<?= sanitize($phone_clean ?: '+923054957063') ?>",
            "contactType": "Customer Service",
            "email": "<?= sanitize($contact_email) ?>",
            "availableLanguage": ["English", "Urdu"]
        }
    }
    </script>

    <!-- Page Scripts (anime.js powered) -->
    <script>
    (function() {
        'use strict';

        // ═══════════════════════════════════════════
        // HERO ENTRANCE — anime.js timeline
        // ═══════════════════════════════════════════
        var heroTL = anime.timeline({ easing: 'easeOutExpo' });

        // Badge slides up
        heroTL.add({
            targets: '#abt-hero-badge',
            opacity: [0, 1],
            translateY: [40, 0],
            duration: 900
        })
        // Title with slight scale
        .add({
            targets: '#abt-hero-title',
            opacity: [0, 1],
            translateY: [50, 0],
            scale: [0.96, 1],
            duration: 1000
        }, '-=600')
        // Subtitle
        .add({
            targets: '#abt-typewriter-target',
            opacity: [0, 1],
            translateY: [30, 0],
            duration: 800
        }, '-=500')
        // Buttons
        .add({
            targets: '#abt-hero-buttons',
            opacity: [0, 1],
            translateY: [30, 0],
            duration: 800
        }, '-=400')
        // Scroll indicator
        .add({
            targets: '.abt-scroll-indicator',
            opacity: [0, 0.8],
            translateY: [-20, 0],
            duration: 600
        }, '-=300');

        // ═══════════════════════════════════════════
        // FLOATING GEOMETRIC SHAPES — continuous loops
        // ═══════════════════════════════════════════
        anime({
            targets: '#abt-shape-1',
            opacity: [0, 0.6],
            translateY: ['0px', '-18px'],
            rotate: [0, 15],
            duration: 4000,
            delay: 500,
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });
        anime({
            targets: '#abt-shape-2',
            opacity: [0, 0.5],
            translateY: ['0px', '22px'],
            rotate: [0, -20],
            scale: [1, 1.1],
            duration: 5000,
            delay: 800,
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });
        anime({
            targets: '#abt-shape-3',
            opacity: [0, 0.5],
            translateX: ['0px', '15px'],
            translateY: ['0px', '-12px'],
            rotate: [0, 30],
            duration: 6000,
            delay: 300,
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });
        anime({
            targets: '#abt-shape-4',
            opacity: [0, 0.45],
            translateY: ['0px', '-20px'],
            rotate: [0, 45],
            duration: 7000,
            delay: 1200,
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });
        anime({
            targets: '#abt-shape-5',
            opacity: [0, 0.5],
            translateX: ['0px', '-10px'],
            translateY: ['0px', '15px'],
            rotate: [0, 180],
            duration: 8000,
            delay: 600,
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });

        // ═══════════════════════════════════════════
        // PARTICLES — staggered floating
        // ═══════════════════════════════════════════
        anime({
            targets: '.abt-particle',
            translateY: function() { return anime.random(-30, 30) + 'px'; },
            translateX: function() { return anime.random(-20, 20) + 'px'; },
            opacity: [0.2, 0.8],
            scale: [0.8, 1.4],
            duration: function() { return anime.random(3000, 6000); },
            delay: anime.stagger(200),
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutQuad'
        });

        // ═══════════════════════════════════════════
        // GLOWING ORBS — breathing pulse
        // ═══════════════════════════════════════════
        anime({
            targets: '.abt-orb',
            scale: [0.9, 1.15],
            opacity: [0.08, 0.2],
            duration: 4000,
            delay: anime.stagger(1500),
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });

        // ═══════════════════════════════════════════
        // TYPEWRITER EFFECT
        // ═══════════════════════════════════════════
        var typewriterText = 'AI-powered solar recommendations trusted by users in 190+ countries worldwide.';
        var target = document.getElementById('abt-typewriter-target');
        var charIndex = 0;

        function typeWriter() {
            if (charIndex < typewriterText.length) {
                target.innerHTML = typewriterText.substring(0, charIndex + 1) + '<span class="abt-typewriter"></span>';
                charIndex++;
                setTimeout(typeWriter, 30);
            } else {
                setTimeout(function() { target.innerHTML = typewriterText; }, 2000);
            }
        }
        // Start after hero entrance
        setTimeout(typeWriter, 1200);

        // ═══════════════════════════════════════════
        // SCROLL-TRIGGERED ANIMATIONS (anime.js)
        // ═══════════════════════════════════════════
        var scrollObserver = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('abt-visible');

                    // Animate children with anime.js stagger
                    var cards = entry.target.querySelectorAll('.abt-feature-card, .abt-timeline-item, .abt-why-row');
                    if (cards.length > 0) {
                        anime({
                            targets: cards,
                            opacity: [0, 1],
                            translateY: [40, 0],
                            scale: [0.97, 1],
                            delay: anime.stagger(120),
                            duration: 800,
                            easing: 'easeOutCubic'
                        });
                    }
                    scrollObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -30px 0px' });

        // Observe parent sections
        document.querySelectorAll('.abt-features-grid, .abt-timeline, .abt-why-grid').forEach(function(el) {
            scrollObserver.observe(el);
        });

        // Individual elements
        var elObserver = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    anime({
                        targets: entry.target,
                        opacity: [0, 1],
                        translateY: [30, 0],
                        duration: 700,
                        easing: 'easeOutCubic'
                    });
                    elObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });

        document.querySelectorAll('.abt-section-label, .abt-section-title, .abt-section-text, .abt-mission-icon-wrap, .abt-founder-card, .abt-cta-inner').forEach(function(el) {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            elObserver.observe(el);
        });

        // ═══════════════════════════════════════════
        // COUNTER ANIMATION — anime.js powered
        // ═══════════════════════════════════════════
        var countersAnimated = false;

        var counterObserver = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting && !countersAnimated) {
                    countersAnimated = true;

                    // Stat items entrance
                    anime({
                        targets: '.abt-stat-item',
                        opacity: [0, 1],
                        translateY: [30, 0],
                        delay: anime.stagger(150),
                        duration: 600,
                        easing: 'easeOutCubic'
                    });

                    // Counter number animation
                    document.querySelectorAll('.abt-counter').forEach(function(counter) {
                        var tgt = parseInt(counter.getAttribute('data-target'), 10);
                        var obj = { value: 0 };
                        anime({
                            targets: obj,
                            value: tgt,
                            round: 1,
                            duration: 2200,
                            easing: 'easeOutExpo',
                            update: function() { counter.textContent = obj.value; }
                        });
                    });

                    counterObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.3 });

        var statsSection = document.querySelector('.abt-stats');
        if (statsSection) {
            // Hide stat items initially
            document.querySelectorAll('.abt-stat-item').forEach(function(el) {
                el.style.opacity = '0';
            });
            counterObserver.observe(statsSection);
        }

    })();
    </script>
</body>
</html>
