<?php
/**
 * Dealer Store Settings - Edit public store information and location
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/dealer_auth.php';

set_security_headers();
require_dealer_login();

$dealer = get_dealer_profile();
$db = getDB();
$success = '';
$error = '';

// Check if country is already locked (set once — can't change)
$country_locked = !empty($dealer['country_code']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $store_description = trim($_POST['store_description'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $lat = trim($_POST['latitude'] ?? '');
    $lng = trim($_POST['longitude'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $country_code = trim($_POST['country_code'] ?? '');
    $pin_country = trim($_POST['pin_country'] ?? '');

    // If country is already set, keep the existing one (can't change)
    if ($country_locked) {
        $country_code = $dealer['country_code'];
        // Block save if pin is outside the locked country
        if (!empty($pin_country) && $pin_country !== $dealer['country_code']) {
            $error = 'Your store location must be within your registered country (' . $dealer['country_code'] . '). The pin you placed is in ' . $pin_country . '.';
        }
    }

    if (!$error && empty($address)) {
        $error = 'Store address is required.';
    } elseif (!$error && (empty($lat) || empty($lng))) {
        $error = 'Please pin your store location on the map.';
    } elseif (!$error && empty($country_code)) {
        $error = 'Country is required. Pin your location on the map to auto-detect it.';
    }

    if (!$error) {
        $stmt = $db->prepare("
            UPDATE dealers SET store_description = ?, address = ?, phone = ?,
            latitude = ?, longitude = ?, city = ?, country_code = ?
            WHERE id = ?
        ");
        $stmt->execute([$store_description, $address, $phone, $lat, $lng, $city, $country_code, $dealer['id']]);
        $success = 'Store settings saved!';
        $dealer = get_dealer_profile();
        $country_locked = !empty($dealer['country_code']);
    }
}

// Get currency info for dealer's country
$dealer_currency = get_country_currency_info($dealer['country_code'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store Settings - <?= get_system_setting('site_name', 'SolarGlobal') ?> Dealer</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php
    $maps_key = get_system_setting('google_maps_api_key', '');
    // No hardcoded fallback — key must be set in Admin → Settings
    ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
    <script>
    var useGoogleMaps = false;
    function storeSettingsGmapsReady() { useGoogleMaps = true; if (window.initStoreMap) window.initStoreMap(); }
    function gm_authFailure() { useGoogleMaps = false; if (window.initStoreMap) window.initStoreMap(); }
    </script>
    <script async src="https://maps.googleapis.com/maps/api/js?key=<?= sanitize($maps_key) ?>&libraries=places&callback=storeSettingsGmapsReady"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; min-height: 100vh; }
        .container { max-width: 800px; margin: 0 auto; padding: 0; }
        .card { background: white; border-radius: 14px; padding: 32px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #E2E8F0; margin-bottom: 24px; }
        .card h2 { font-size: 1.125rem; font-weight: 700; color: #0D3B6E; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 2px solid #F1F5F9; }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; font-size: 0.875rem; font-weight: 600; color: #334155; margin-bottom: 6px; }
        .form-group input, .form-group textarea { width: 100%; padding: 11px 14px; border: 2px solid #E2E8F0; border-radius: 8px; font-size: 0.9375rem; font-family: inherit; background: #F8FAFC; }
        .form-group input:focus, .form-group textarea:focus { outline: none; border-color: #1565C0; background: white; }
        .form-group textarea { resize: vertical; min-height: 100px; }
        .form-group .help-text { font-size: 0.8125rem; color: #64748B; margin-top: 4px; }
        .map-container { width: 100%; height: 350px; border-radius: 12px; border: 2px solid #E2E8F0; overflow: hidden; margin-bottom: 8px; }
        .coords { display: flex; gap: 16px; font-size: 0.8125rem; color: #64748B; margin-top: 8px; }
        .coords span { background: #F1F5F9; padding: 4px 10px; border-radius: 6px; }
        .btn { padding: 14px 32px; background: #1565C0; color: white; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; }
        .btn:hover { background: #0D3B6E; }
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; }
        .alert-success { background: #DCFCE7; color: #166534; }
        .alert-error { background: #FEF2F2; color: #991B1B; }
    </style>
</head>
<body>
    <?php $current_dealer_page = 'store-settings'; include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="dlr-main-content">
        <div class="dlr-page-header">
            <div class="dlr-page-header-left">
                <button class="dlr-mobile-menu-btn" onclick="dlrToggleSidebar()">&#9776;</button>
                <h1>&#9881; Store Settings</h1>
            </div>
            <div></div>
        </div>
        <div class="container">
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>

        <form method="POST">
            <?= csrf_field() ?>
            <div class="card">
                <h2>&#127970; Store Information</h2>
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="tel" name="phone" value="<?= sanitize($dealer['phone'] ?? '') ?>" placeholder="+1 555 123 4567">
                </div>
                <div class="form-group">
                    <label>Store Description</label>
                    <textarea name="store_description" maxlength="500" placeholder="Describe your solar business..."><?= sanitize($dealer['store_description'] ?? '') ?></textarea>
                    <div class="help-text">This is visible to customers on your store page. Max 500 characters.</div>
                </div>
            </div>

            <?php if ($country_locked): ?>
            <div class="card" style="background:#EFF6FF;border:2px solid #93C5FD;">
                <h2>&#127758; Store Country &amp; Currency</h2>
                <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                    <div style="font-size:2rem;"><?= get_country_flag($dealer_currency, 32) ?></div>
                    <div>
                        <div style="font-size:1.125rem;font-weight:700;color:#1E293B;"><?= sanitize($dealer_currency['name']) ?></div>
                        <div style="font-size:0.875rem;color:#64748B;">
                            Currency: <strong><?= sanitize($dealer_currency['currency_symbol']) ?> (<?= sanitize($dealer_currency['currency_code']) ?>)</strong>
                            &nbsp;|&nbsp; Rate: 1 USD = <?= number_format($dealer_currency['exchange_rate'], 2) ?> <?= sanitize($dealer_currency['currency_code']) ?>
                        </div>
                    </div>
                    <div style="margin-left:auto;background:#FEF3C7;padding:8px 14px;border-radius:8px;font-size:0.8125rem;color:#92400E;font-weight:600;">
                        &#128274; Country is locked after first setup
                    </div>
                </div>
                <p style="font-size:0.8125rem;color:#64748B;margin-top:12px;">
                    All your product prices are in <strong><?= sanitize($dealer_currency['currency_code']) ?></strong>.
                    Only customers from <strong><?= sanitize($dealer_currency['name']) ?></strong> can order from your store.
                </p>
            </div>
            <?php endif; ?>

            <div class="card">
                <h2>&#128205; Store Location</h2>
                <?php if (!$country_locked): ?>
                <div style="background:#FEF3C7;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:0.875rem;color:#92400E;">
                    <strong>&#9888; Important:</strong> Pin your store location below. Your country will be detected automatically and <strong>cannot be changed later</strong>. Your store currency will be locked to this country.
                </div>
                <?php endif; ?>
                <div class="form-group">
                    <label>Store Address</label>
                    <input type="text" name="address" id="addressInput" value="<?= sanitize($dealer['address'] ?? '') ?>" required placeholder="Search your address...">
                </div>
                <div class="form-group">
                    <label>Pin Your Location</label>
                    <div class="map-container" id="storeMap"></div>
                    <div class="coords">
                        <span id="latDisp">Lat: <?= $dealer['latitude'] ? number_format($dealer['latitude'], 5) : '--' ?></span>
                        <span id="lngDisp">Lng: <?= $dealer['longitude'] ? number_format($dealer['longitude'], 5) : '--' ?></span>
                        <span id="cityDisp">City: <?= sanitize($dealer['city'] ?? '--') ?></span>
                        <span id="countryDisp">Country: <?= sanitize($dealer['country_code'] ?? '--') ?></span>
                    </div>
                    <input type="hidden" name="latitude" id="latInput" value="<?= sanitize($dealer['latitude'] ?? '') ?>">
                    <input type="hidden" name="longitude" id="lngInput" value="<?= sanitize($dealer['longitude'] ?? '') ?>">
                    <input type="hidden" name="city" id="cityInput" value="<?= sanitize($dealer['city'] ?? '') ?>">
                    <input type="hidden" name="country_code" id="countryInput" value="<?= sanitize($dealer['country_code'] ?? '') ?>">
                    <input type="hidden" name="pin_country" id="pinCountryInput" value="<?= sanitize($dealer['country_code'] ?? '') ?>">
                </div>
            </div>

            <button type="submit" class="btn">Save Store Settings</button>
        </form>
    </div>

    <script>
    (function() {
        const mapEl = document.getElementById('storeMap');
        if (!mapEl) return;

        const countryLocked = <?= json_encode($country_locked) ?>;
        const lockedCountryCode = <?= json_encode($dealer['country_code'] ?? '') ?>;

        const lat = parseFloat(document.getElementById('latInput').value) || 25;
        const lng = parseFloat(document.getElementById('lngInput').value) || 67;
        const hasCoords = document.getElementById('latInput').value !== '';

        // Track last valid position for reverting
        var lastValidLat = hasCoords ? lat : null;
        var lastValidLng = hasCoords ? lng : null;
        var pinError = document.createElement('div');
        pinError.id = 'pinCountryError';
        pinError.style.cssText = 'display:none;background:#FEF2F2;color:#991B1B;padding:10px 14px;border-radius:8px;margin-top:10px;font-size:0.875rem;font-weight:600;';
        mapEl.parentNode.insertBefore(pinError, mapEl.nextSibling);
        var submitBtn = document.querySelector('button[type="submit"]');

        function showPinError(msg) {
            pinError.textContent = msg;
            pinError.style.display = 'block';
            if (submitBtn) submitBtn.disabled = true;
        }
        function clearPinError() {
            pinError.style.display = 'none';
            if (submitBtn) submitBtn.disabled = false;
        }

        function updateCoordDisplays(lat, lng, city, country) {
            document.getElementById('latInput').value = lat.toFixed(7);
            document.getElementById('lngInput').value = lng.toFixed(7);
            document.getElementById('latDisp').textContent = 'Lat: ' + lat.toFixed(5);
            document.getElementById('lngDisp').textContent = 'Lng: ' + lng.toFixed(5);
            document.getElementById('cityInput').value = city;
            document.getElementById('cityDisp').textContent = 'City: ' + (city || 'Unknown');

            if (!countryLocked) {
                document.getElementById('countryInput').value = country;
                var cd = document.getElementById('countryDisp');
                if (cd) cd.textContent = 'Country: ' + (country || '--');
            } else {
                document.getElementById('countryInput').value = lockedCountryCode;
            }
        }

        // ─── Google Maps Path ───
        function initWithGoogle() {
            const map = new google.maps.Map(mapEl, {
                center: { lat, lng }, zoom: hasCoords ? 15 : 3,
                mapTypeControl: false, streetViewControl: false, fullscreenControl: false
            });
            const marker = new google.maps.Marker({
                position: { lat, lng }, map, draggable: true, visible: hasCoords
            });
            const geocoder = new google.maps.Geocoder();

            function update(lt, ln) {
                marker.setPosition({ lat: lt, lng: ln }); marker.setVisible(true);
                geocoder.geocode({ location: { lat: lt, lng: ln } }, function(r, s) {
                    if (s === 'OK' && r[0]) {
                        var city = '', country = '';
                        r[0].address_components.forEach(function(c) {
                            if (c.types.includes('locality')) city = c.long_name;
                            if (c.types.includes('country')) country = c.short_name;
                        });

                        document.getElementById('pinCountryInput').value = country;

                        if (countryLocked && country && country !== lockedCountryCode) {
                            showPinError('This location is in ' + country + '. Your store country is locked to ' + lockedCountryCode + '. Please pin a location within ' + lockedCountryCode + '.');
                            if (lastValidLat !== null && lastValidLng !== null) {
                                marker.setPosition({ lat: lastValidLat, lng: lastValidLng });
                                map.panTo({ lat: lastValidLat, lng: lastValidLng });
                            } else {
                                marker.setVisible(false);
                            }
                            return;
                        }

                        clearPinError();
                        lastValidLat = lt;
                        lastValidLng = ln;
                        updateCoordDisplays(lt, ln, city, country);
                    }
                });
            }

            map.addListener('click', function(e) { update(e.latLng.lat(), e.latLng.lng()); });
            marker.addListener('dragend', function(e) { update(e.latLng.lat(), e.latLng.lng()); });

            const ac = new google.maps.places.Autocomplete(document.getElementById('addressInput'), {
                types: ['establishment', 'geocode'],
                componentRestrictions: countryLocked ? { country: lockedCountryCode.toLowerCase() } : undefined
            });
            ac.bindTo('bounds', map);
            ac.addListener('place_changed', function() {
                const p = ac.getPlace();
                if (p.geometry && p.geometry.location) {
                    const lt = p.geometry.location.lat(), ln = p.geometry.location.lng();
                    map.setCenter({ lat: lt, lng: ln }); map.setZoom(16); update(lt, ln);
                    if (p.formatted_address) document.getElementById('addressInput').value = p.formatted_address;
                }
            });
        }

        // ─── Leaflet Fallback Path ───
        function initWithLeaflet() {
            var map = L.map(mapEl, {
                center: [lat, lng],
                zoom: hasCoords ? 15 : 3
            });

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors',
                maxZoom: 19
            }).addTo(map);

            var marker = L.marker([lat, lng], { draggable: true });
            if (hasCoords) marker.addTo(map);

            // Reverse geocode using Nominatim (free, no key needed)
            function reverseGeocode(lt, ln) {
                fetch('https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lt + '&lon=' + ln + '&zoom=10&addressdetails=1')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        var city = '';
                        var country = '';
                        if (data.address) {
                            city = data.address.city || data.address.town || data.address.village || '';
                            country = (data.address.country_code || '').toUpperCase();
                        }

                        document.getElementById('pinCountryInput').value = country;

                        if (countryLocked && country && country !== lockedCountryCode) {
                            showPinError('This location is in ' + country + '. Your store country is locked to ' + lockedCountryCode + '. Please pin a location within ' + lockedCountryCode + '.');
                            if (lastValidLat !== null && lastValidLng !== null) {
                                marker.setLatLng([lastValidLat, lastValidLng]);
                                map.panTo([lastValidLat, lastValidLng]);
                            } else {
                                map.removeLayer(marker);
                            }
                            return;
                        }

                        clearPinError();
                        lastValidLat = lt;
                        lastValidLng = ln;
                        updateCoordDisplays(lt, ln, city, country);
                    })
                    .catch(function() {
                        // If geocoding fails, still update coordinates
                        clearPinError();
                        lastValidLat = lt;
                        lastValidLng = ln;
                        updateCoordDisplays(lt, ln, '', '');
                    });
            }

            function update(lt, ln) {
                marker.setLatLng([lt, ln]);
                if (!map.hasLayer(marker)) marker.addTo(map);
                reverseGeocode(lt, ln);
            }

            map.on('click', function(e) { update(e.latlng.lat, e.latlng.lng); });
            marker.on('dragend', function(e) {
                var pos = e.target.getLatLng();
                update(pos.lat, pos.lng);
            });

            // Address search using Nominatim
            var addressInput = document.getElementById('addressInput');
            var searchTimeout = null;
            addressInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    clearTimeout(searchTimeout);
                    var query = addressInput.value.trim();
                    if (!query) return;
                    var params = 'format=json&q=' + encodeURIComponent(query) + '&limit=1';
                    if (countryLocked) params += '&countrycodes=' + lockedCountryCode.toLowerCase();
                    fetch('https://nominatim.openstreetmap.org/search?' + params)
                        .then(function(r) { return r.json(); })
                        .then(function(results) {
                            if (results.length > 0) {
                                var lt = parseFloat(results[0].lat);
                                var ln = parseFloat(results[0].lon);
                                map.setView([lt, ln], 16);
                                update(lt, ln);
                                if (results[0].display_name) addressInput.value = results[0].display_name;
                            }
                        });
                }
            });

            setTimeout(function() { map.invalidateSize(); }, 200);
        }

        // ─── Bootstrap ───
        window.initStoreMap = function() {
            if (useGoogleMaps && typeof google !== 'undefined') {
                initWithGoogle();
            } else if (typeof L !== 'undefined') {
                initWithLeaflet();
            }
        };

        // If Leaflet is already loaded and Google Maps hasn't loaded yet, set a timeout fallback
        setTimeout(function() {
            if (!useGoogleMaps && typeof L !== 'undefined' && !mapEl._leaflet_id) {
                initWithLeaflet();
            }
        }, 4000);
    })();
    </script>
    </main>
</body>
</html>
