<?php
/**
 * Cart API
 * Handles AJAX cart operations from the store page.
 * No login required — cart stored in session.
 *
 * POST actions:
 *   add    — Add product to cart (catalog or dealer)
 *   remove — Remove item from cart
 *   update — Update quantity
 *   count  — Get cart item count (GET)
 */
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

if (!rate_limit('api_cart', 60, 60)) { respond_rate_limited(); }

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

$method = $_SERVER['REQUEST_METHOD'];

// GET: return cart count + summary
if ($method === 'GET') {
    $count = 0;
    $total = 0;
    foreach ($_SESSION['cart'] as $dealer_cart) {
        foreach ($dealer_cart['items'] as $item) {
            $count += $item['quantity'];
            $total += $item['dealer_price'] * $item['quantity'];
        }
    }
    echo json_encode(['success' => true, 'count' => $count, 'total' => round($total, 2)]);
    exit;
}

if ($method !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$action = $input['action'] ?? '';
$db = getDB();

if ($action === 'add') {
    $product_type = $input['product_type'] ?? '';
    $product_id = (int)($input['product_id'] ?? 0);
    $dealer_id = (int)($input['dealer_id'] ?? 0);
    $qty = max(1, (int)($input['quantity'] ?? 1));

    // Validate product type
    $valid_types = ['inverter', 'battery', 'panel', 'installation_appliance'];
    if (!in_array($product_type, $valid_types) || $product_id <= 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid product.']);
        exit;
    }

    // Get product info from catalog
    $table_map = [
        'inverter' => 'inverters',
        'battery' => 'batteries',
        'panel' => 'panels',
        'installation_appliance' => 'installation_appliances'
    ];
    $table = $table_map[$product_type];

    $stmt = $db->prepare("SELECT id, name, price_usd FROM $table WHERE id = ? AND is_active = 1");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();

    if (!$product) {
        echo json_encode(['success' => false, 'error' => 'Product not found.']);
        exit;
    }

    // If dealer specified, check dealer product exists and get dealer price
    $price = $product['price_usd'];
    $dp_id = 0;
    $stock = 999; // Catalog items have unlimited "stock"
    $dealer_name = 'SolarGlobal Catalog';

    if ($dealer_id > 0) {
        $stmt = $db->prepare("SELECT dp.id, dp.dealer_price, dp.stock_quantity, d.business_name
                              FROM dealer_products dp
                              JOIN dealers d ON dp.dealer_id = d.id
                              WHERE dp.dealer_id = ? AND dp.product_type = ? AND dp.product_id = ?
                                AND dp.is_active = 1 AND d.status = 'active'");
        $stmt->execute([$dealer_id, $product_type, $product_id]);
        $dp = $stmt->fetch();
        if ($dp) {
            $price = $dp['dealer_price'];
            $dp_id = $dp['id'];
            $stock = $dp['stock_quantity'];
            $dealer_name = $dp['business_name'];
        } else {
            $dealer_id = 0; // Fallback to catalog
        }
    }

    $qty = min($qty, $stock);

    $cart_item = [
        'dp_id' => $dp_id,
        'product_type' => $product_type,
        'product_id' => $product_id,
        'product_name' => $product['name'],
        'dealer_price' => (float)$price,
        'quantity' => $qty,
        'max_stock' => $stock,
    ];

    // Check if already in cart
    $found = false;
    if (isset($_SESSION['cart'][$dealer_id])) {
        foreach ($_SESSION['cart'][$dealer_id]['items'] as &$item) {
            if ($item['product_type'] === $product_type && $item['product_id'] === $product_id) {
                $item['quantity'] = min($item['quantity'] + $qty, $stock);
                $found = true;
                break;
            }
        }
        unset($item);
    }

    if (!$found) {
        if (!isset($_SESSION['cart'][$dealer_id])) {
            $_SESSION['cart'][$dealer_id] = [
                'dealer_name' => $dealer_name,
                'items' => []
            ];
        }
        $_SESSION['cart'][$dealer_id]['items'][] = $cart_item;
    }

    // Calculate new count
    $count = 0;
    foreach ($_SESSION['cart'] as $dc) {
        foreach ($dc['items'] as $i) $count += $i['quantity'];
    }

    echo json_encode([
        'success' => true,
        'message' => 'Added to cart!',
        'cart_count' => $count,
        'product_name' => $product['name']
    ]);

} elseif ($action === 'remove') {
    $dealer_id = (int)($input['dealer_id'] ?? 0);
    $product_type = $input['product_type'] ?? '';
    $product_id = (int)($input['product_id'] ?? 0);

    if (isset($_SESSION['cart'][$dealer_id])) {
        $_SESSION['cart'][$dealer_id]['items'] = array_values(array_filter(
            $_SESSION['cart'][$dealer_id]['items'],
            fn($i) => !($i['product_type'] === $product_type && $i['product_id'] === $product_id)
        ));
        if (empty($_SESSION['cart'][$dealer_id]['items'])) {
            unset($_SESSION['cart'][$dealer_id]);
        }
    }

    $count = 0;
    foreach ($_SESSION['cart'] as $dc) {
        foreach ($dc['items'] as $i) $count += $i['quantity'];
    }

    echo json_encode(['success' => true, 'message' => 'Removed from cart.', 'cart_count' => $count]);

} elseif ($action === 'clear') {
    $_SESSION['cart'] = [];
    echo json_encode(['success' => true, 'message' => 'Cart cleared.', 'cart_count' => 0]);

} else {
    echo json_encode(['success' => false, 'error' => 'Unknown action.']);
}
