<?php
if (!function_exists('get_system_setting')) {
    require_once __DIR__ . '/../../includes/helpers.php';
}
/**
 * Dealer Sidebar Navigation
 * Include this in all dealer panel pages.
 *
 * Required variables before including:
 *   $dealer  — from get_dealer_profile()
 *   $current_dealer_page — string like 'dashboard', 'products', 'add-products', 'pos', 'orders', etc.
 *
 * Optional:
 *   $pending_orders_count — int, shown as badge on Orders
 *   $product_count — int, shown as badge on Products
 */
$current_dealer_page = $current_dealer_page ?? '';
$pending_orders_count = $pending_orders_count ?? 0;
$product_count = $product_count ?? 0;

// Notification count
$dealer_notif_count = 0;
if (isset($dealer['id'])) {
    require_once __DIR__ . '/../../includes/notification_helpers.php';
    $dealer_notif_count = get_unread_notification_count('dealer', (int)$dealer['id']);
}

// Try to get counts if not provided
if ($product_count === 0 && function_exists('get_dealer_product_count')) {
    try { $product_count = get_dealer_product_count(); } catch (Exception $e) {}
}
if ($pending_orders_count === 0 && isset($dealer['id'])) {
    try {
        $__db = getDB();
        $__stmt = $__db->prepare("SELECT COUNT(*) FROM orders WHERE dealer_id = ? AND status = 'pending'");
        $__stmt->execute([$dealer['id']]);
        $pending_orders_count = (int)$__stmt->fetchColumn();
    } catch (Exception $e) {}
}
?>
<style>
/* ===== Dealer Sidebar ===== */
.dlr-sidebar {
    position: fixed; left: 0; top: 0; bottom: 0; width: 260px;
    background: #0F172A; color: white; z-index: 100;
    display: flex; flex-direction: column; transition: transform 0.3s;
}
.dlr-sidebar-header {
    padding: 24px 20px; border-bottom: 1px solid #1E293B;
}
.dlr-sidebar-header h2 { font-size: 1.25rem; font-weight: 800; color: #F59E0B; margin: 0; }
.dlr-sidebar-header p { font-size: 0.75rem; color: #94A3B8; margin: 2px 0 0; }
.dlr-sidebar-nav { flex: 1; padding: 16px 12px; overflow-y: auto; }
.dlr-nav-section { margin-bottom: 24px; }
.dlr-nav-section-title {
    font-size: 0.6875rem; text-transform: uppercase; letter-spacing: 1px;
    color: #475569; padding: 0 12px; margin-bottom: 8px; font-weight: 600;
}
.dlr-nav-item {
    display: flex; align-items: center; gap: 12px; padding: 10px 12px;
    border-radius: 8px; color: #CBD5E1; text-decoration: none;
    font-size: 0.875rem; font-weight: 500; transition: all 0.2s; cursor: pointer;
}
.dlr-nav-item:hover { background: #1E293B; color: white; }
.dlr-nav-item.active { background: #1565C0; color: white; }
.dlr-nav-item .dlr-icon { font-size: 1.125rem; width: 24px; text-align: center; }
.dlr-nav-item .dlr-badge {
    margin-left: auto; background: #DC2626; color: white;
    font-size: 0.6875rem; padding: 2px 7px; border-radius: 10px; font-weight: 700;
}
.dlr-nav-item .dlr-badge-blue { background: #1565C0; }
.dlr-sidebar-footer {
    padding: 16px 12px; border-top: 1px solid #1E293B;
}
.dlr-dealer-info {
    display: flex; align-items: center; gap: 10px; padding: 8px;
}
.dlr-dealer-avatar {
    width: 36px; height: 36px; border-radius: 8px; background: #334155;
    display: flex; align-items: center; justify-content: center;
    font-size: 1rem; overflow: hidden; flex-shrink: 0; color: #E2E8F0;
}
.dlr-dealer-avatar img { width: 100%; height: 100%; object-fit: cover; }
.dlr-dealer-meta .dlr-d-name { font-size: 0.8125rem; font-weight: 600; color: #E2E8F0; }
.dlr-dealer-meta .dlr-d-email { font-size: 0.6875rem; color: #64748B; }
.dlr-overlay {
    display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 90;
}
.dlr-overlay.active { display: block; }
.dlr-mobile-menu-btn {
    display: none; background: #0F172A; color: white; border: none;
    width: 40px; height: 40px; border-radius: 8px; font-size: 1.25rem;
    cursor: pointer; flex-shrink: 0;
}
.dlr-main-content {
    margin-left: 260px; padding: 24px 32px; min-height: 100vh;
}
.dlr-page-header {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 24px;
}
.dlr-page-header h1 { font-size: 1.5rem; font-weight: 700; color: #1E293B; margin: 0; }
.dlr-page-header-left { display: flex; align-items: center; gap: 12px; }

@media (max-width: 900px) {
    .dlr-sidebar { transform: translateX(-100%); }
    .dlr-sidebar.open { transform: translateX(0); }
    .dlr-main-content { margin-left: 0; padding: 16px; }
    .dlr-mobile-menu-btn { display: block; }
}
</style>

<!-- Dealer Sidebar -->
<aside class="dlr-sidebar" id="dlrSidebar">
    <div class="dlr-sidebar-header">
        <h2>&#9728;&#65039; <?= get_system_setting('site_name', 'SolarGlobal') ?></h2>
        <p>Dealer Portal</p>
    </div>

    <nav class="dlr-sidebar-nav">
        <div class="dlr-nav-section">
            <div class="dlr-nav-section-title">Main</div>
            <a href="dashboard.php" class="dlr-nav-item <?= $current_dealer_page === 'dashboard' ? 'active' : '' ?>">
                <span class="dlr-icon">&#127968;</span> Dashboard
            </a>
            <a href="notifications.php" class="dlr-nav-item <?= $current_dealer_page === 'notifications' ? 'active' : '' ?>">
                <span class="dlr-icon">&#128276;</span> Notifications
                <?php if ($dealer_notif_count > 0): ?>
                    <span class="dlr-badge"><?= $dealer_notif_count ?></span>
                <?php endif; ?>
            </a>
            <a href="products.php" class="dlr-nav-item <?= $current_dealer_page === 'products' ? 'active' : '' ?>">
                <span class="dlr-icon">&#128230;</span> My Products
                <?php if ($product_count > 0): ?>
                    <span class="dlr-badge dlr-badge-blue"><?= $product_count ?></span>
                <?php endif; ?>
            </a>
            <a href="add-products.php" class="dlr-nav-item <?= $current_dealer_page === 'add-products' ? 'active' : '' ?>">
                <span class="dlr-icon">&#10133;</span> Add Products
            </a>
        </div>

        <div class="dlr-nav-section">
            <div class="dlr-nav-section-title">Sales</div>
            <a href="pos.php" class="dlr-nav-item <?= $current_dealer_page === 'pos' ? 'active' : '' ?>">
                <span class="dlr-icon">&#128179;</span> Point of Sale
            </a>
            <a href="orders.php" class="dlr-nav-item <?= $current_dealer_page === 'orders' ? 'active' : '' ?>">
                <span class="dlr-icon">&#128203;</span> Orders
                <?php if ($pending_orders_count > 0): ?>
                    <span class="dlr-badge"><?= $pending_orders_count ?></span>
                <?php endif; ?>
            </a>
            <a href="invoices.php" class="dlr-nav-item <?= $current_dealer_page === 'invoices' ? 'active' : '' ?>">
                <span class="dlr-icon">&#128196;</span> Invoices
            </a>
            <a href="reports.php" class="dlr-nav-item <?= $current_dealer_page === 'reports' ? 'active' : '' ?>">
                <span class="dlr-icon">&#128202;</span> Reports
            </a>
        </div>

        <div class="dlr-nav-section">
            <div class="dlr-nav-section-title">Store</div>
            <a href="store-settings.php" class="dlr-nav-item <?= $current_dealer_page === 'store-settings' ? 'active' : '' ?>">
                <span class="dlr-icon">&#9881;</span> Store Settings
            </a>
            <a href="subscription.php" class="dlr-nav-item <?= $current_dealer_page === 'subscription' ? 'active' : '' ?>">
                <span class="dlr-icon">&#128179;</span> Subscription
            </a>
            <a href="request-product.php" class="dlr-nav-item <?= $current_dealer_page === 'request-product' ? 'active' : '' ?>">
                <span class="dlr-icon">&#128172;</span> Request Product
            </a>
        </div>

        <div class="dlr-nav-section">
            <div class="dlr-nav-section-title">Account</div>
            <a href="profile.php" class="dlr-nav-item <?= $current_dealer_page === 'profile' ? 'active' : '' ?>">
                <span class="dlr-icon">&#128100;</span> My Profile
            </a>
            <a href="/solarglobal/index.php" class="dlr-nav-item">
                <span class="dlr-icon">&#127760;</span> View Website
            </a>
            <a href="logout.php" class="dlr-nav-item">
                <span class="dlr-icon">&#128682;</span> Logout
            </a>
        </div>
    </nav>

    <div class="dlr-sidebar-footer">
        <div class="dlr-dealer-info">
            <div class="dlr-dealer-avatar">
                <?php if (!empty($dealer['logo_path'])): ?>
                    <img src="/solarglobal/<?= htmlspecialchars($dealer['logo_path']) ?>" alt="Logo">
                <?php else: ?>
                    <?= strtoupper(substr($dealer['business_name'] ?? 'D', 0, 1)) ?>
                <?php endif; ?>
            </div>
            <div class="dlr-dealer-meta">
                <div class="dlr-d-name"><?= htmlspecialchars($dealer['business_name'] ?? '') ?></div>
                <div class="dlr-d-email"><?= htmlspecialchars($dealer['email'] ?? '') ?></div>
            </div>
        </div>
    </div>
</aside>

<div class="dlr-overlay" id="dlrOverlay"></div>

<script>
function dlrToggleSidebar() {
    document.getElementById('dlrSidebar').classList.toggle('open');
    document.getElementById('dlrOverlay').classList.toggle('active');
}
document.getElementById('dlrOverlay')?.addEventListener('click', dlrToggleSidebar);
</script>
