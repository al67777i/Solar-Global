<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/csrf.php';
require_once '../includes/helpers.php';

$db = getDB();
$message = '';
$error = '';

$battery_id = intval($_GET['id'] ?? 0);

// Get battery details
$stmt = $db->prepare("SELECT * FROM batteries WHERE id = ?");
$stmt->execute([$battery_id]);
$battery = $stmt->fetch();

if (!$battery) {
    header('Location: batteries.php');
    exit;
}

// Handle pinpoint save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $pinpoints = $_POST['pinpoints'] ?? '[]';
    
    // Update battery with pinpoints JSON
    $stmt = $db->prepare("UPDATE batteries SET pinpoints = ? WHERE id = ?");
    $stmt->execute([$pinpoints, $battery_id]);
    
    $message = 'Pinpoints saved successfully!';
    
    // Reload battery data
    $stmt = $db->prepare("SELECT * FROM batteries WHERE id = ?");
    $stmt->execute([$battery_id]);
    $battery = $stmt->fetch();
}

$pageTitle = "Battery Pinpoints - " . $battery['name'];
include 'includes/header.php';
?>

<style>
.pinpoint-editor {
    background: white;
    padding: 30px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.image-container {
    position: relative;
    display: inline-block;
    max-width: 100%;
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    overflow: hidden;
    background: #f8f9fa;
}

.image-container img {
    display: block;
    max-width: 100%;
    height: auto;
    cursor: crosshair;
}

.pinpoint {
    position: absolute;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 3px solid white;
    cursor: move;
    transform: translate(-50%, -50%);
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    z-index: 10;
}

.pinpoint-label {
    position: absolute;
    background: rgba(0,0,0,0.8);
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    white-space: nowrap;
    pointer-events: none;
    transform: translate(-50%, -35px);
    z-index: 11;
}

.pinpoint.positive { background: #ef4444; }
.pinpoint.negative { background: #000000; }

.pinpoint-list {
    margin-top: 20px;
}

.pinpoint-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px;
    background: #f8f9fa;
    border-radius: 4px;
    margin-bottom: 8px;
}

.pinpoint-color {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid white;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

.controls {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.control-group {
    display: flex;
    gap: 10px;
    align-items: center;
    margin-bottom: 15px;
}

.instructions {
    background: #e0f2fe;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-left: 4px solid #0284c7;
}
</style>

<?php if ($message): ?>
    <div class="alert alert-success"><?= sanitize($message) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-error"><?= sanitize($error) ?></div>
<?php endif; ?>

<div class="card">
    <h2>🔋 Battery Terminal Mapping: <?= sanitize($battery['name']) ?></h2>
    <p>Mark the positive (+) and negative (-) terminals on the battery image</p>
    <a href="batteries.php" class="btn btn-secondary">← Back to Batteries</a>
</div>

<div class="instructions">
    <h3>📖 Instructions:</h3>
    <ol>
        <li><strong>Select terminal type</strong> (Positive or Negative) from the dropdown</li>
        <li><strong>Click on the image</strong> where that terminal is located</li>
        <li><strong>Drag pinpoints</strong> to adjust their position</li>
        <li><strong>Click "Remove"</strong> to delete a pinpoint</li>
        <li><strong>Click "Save Pinpoints"</strong> when done</li>
    </ol>
    <p><strong>Note:</strong> You should mark exactly 2 terminals (one positive, one negative)</p>
</div>

<div class="controls">
    <h3>Add Terminal Pinpoint:</h3>
    <div class="control-group">
        <label><strong>Terminal Type:</strong></label>
        <select id="pinpoint-type" class="form-control" style="width: 300px;">
            <option value="positive">🔴 Positive Terminal (+)</option>
            <option value="negative">⚫ Negative Terminal (-)</option>
        </select>
        <button id="clear-all" class="btn btn-danger">Clear All</button>
    </div>
</div>

<?php if ($battery['image_path']): ?>
<div class="pinpoint-editor">
    <div class="image-container" id="image-container">
        <img src="<?= sanitize($battery['image_path']) ?>" alt="Battery" id="battery-image">
    </div>
</div>

<div class="pinpoint-list">
    <h3>Current Pinpoints:</h3>
    <div id="pinpoint-list-items"></div>
</div>

<form method="POST" id="save-form">
    <?= csrf_field() ?>
    <input type="hidden" name="pinpoints" id="pinpoints-data">
    <button type="submit" class="btn btn-primary btn-lg">💾 Save Pinpoints</button>
    <a href="batteries.php" class="btn btn-secondary">Cancel</a>
</form>

<script>
const pinpointTypes = {
    'positive': { label: 'Positive (+)', color: '#ef4444' },
    'negative': { label: 'Negative (-)', color: '#000000' }
};

let pinpoints = <?= $battery['pinpoints'] ?? '[]' ?>;
let draggedPinpoint = null;

const container = document.getElementById('image-container');
const image = document.getElementById('battery-image');
const typeSelect = document.getElementById('pinpoint-type');

// Add pinpoint on image click
container.addEventListener('click', function(e) {
    if (e.target !== image) return;
    
    const type = typeSelect.value;
    
    // Check if this type already exists
    const existingType = pinpoints.find(p => p.type === type);
    if (existingType) {
        alert(`${pinpointTypes[type].label} already marked! Remove it first or drag to reposition.`);
        return;
    }
    
    const rect = image.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    const pinpoint = {
        id: Date.now(),
        type: type,
        x: x,
        y: y,
        label: pinpointTypes[type].label
    };
    
    pinpoints.push(pinpoint);
    renderPinpoints();
    updateList();
});

// Render pinpoints on image
function renderPinpoints() {
    // Remove existing pinpoints
    document.querySelectorAll('.pinpoint, .pinpoint-label').forEach(el => el.remove());
    
    pinpoints.forEach(point => {
        // Create pinpoint dot
        const dot = document.createElement('div');
        dot.className = `pinpoint ${point.type}`;
        dot.style.left = point.x + '%';
        dot.style.top = point.y + '%';
        dot.dataset.id = point.id;
        
        // Create label
        const label = document.createElement('div');
        label.className = 'pinpoint-label';
        label.textContent = point.label;
        label.style.left = point.x + '%';
        label.style.top = point.y + '%';
        
        // Make draggable
        dot.addEventListener('mousedown', startDrag);
        
        container.appendChild(dot);
        container.appendChild(label);
    });
}

// Drag functionality
function startDrag(e) {
    e.stopPropagation();
    draggedPinpoint = e.target;
    document.addEventListener('mousemove', drag);
    document.addEventListener('mouseup', stopDrag);
}

function drag(e) {
    if (!draggedPinpoint) return;
    
    const rect = image.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    // Constrain to image bounds
    const constrainedX = Math.max(0, Math.min(100, x));
    const constrainedY = Math.max(0, Math.min(100, y));
    
    draggedPinpoint.style.left = constrainedX + '%';
    draggedPinpoint.style.top = constrainedY + '%';
    
    // Update label position
    const label = draggedPinpoint.nextElementSibling;
    if (label && label.classList.contains('pinpoint-label')) {
        label.style.left = constrainedX + '%';
        label.style.top = constrainedY + '%';
    }
    
    // Update data
    const id = parseInt(draggedPinpoint.dataset.id);
    const point = pinpoints.find(p => p.id === id);
    if (point) {
        point.x = constrainedX;
        point.y = constrainedY;
    }
}

function stopDrag() {
    draggedPinpoint = null;
    document.removeEventListener('mousemove', drag);
    document.removeEventListener('mouseup', stopDrag);
    updateList();
}

// Update pinpoint list
function updateList() {
    const listContainer = document.getElementById('pinpoint-list-items');
    
    if (pinpoints.length === 0) {
        listContainer.innerHTML = '<p style="color: #94A3B8;">No terminals marked yet. Click on the image to add terminals.</p>';
        return;
    }
    
    listContainer.innerHTML = pinpoints.map(point => `
        <div class="pinpoint-item">
            <div class="pinpoint-color" style="background: ${pinpointTypes[point.type].color};"></div>
            <strong>${point.label}</strong>
            <span style="color: #64748b;">Position: ${point.x.toFixed(1)}%, ${point.y.toFixed(1)}%</span>
            <button type="button" class="btn btn-danger btn-sm" onclick="removePinpoint(${point.id})">Remove</button>
        </div>
    `).join('');
}

// Remove pinpoint
function removePinpoint(id) {
    pinpoints = pinpoints.filter(p => p.id !== id);
    renderPinpoints();
    updateList();
}

// Clear all
document.getElementById('clear-all').addEventListener('click', function() {
    if (confirm('Remove all pinpoints?')) {
        pinpoints = [];
        renderPinpoints();
        updateList();
    }
});

// Save form
document.getElementById('save-form').addEventListener('submit', function(e) {
    if (pinpoints.length !== 2) {
        if (!confirm('You should mark exactly 2 terminals (positive and negative). Continue anyway?')) {
            e.preventDefault();
            return;
        }
    }
    document.getElementById('pinpoints-data').value = JSON.stringify(pinpoints);
});

// Initial render
renderPinpoints();
updateList();
</script>

<?php else: ?>
<div class="alert alert-error">
    <strong>No image uploaded!</strong> Please upload an image for this battery first.
    <br><a href="batteries.php" class="btn btn-primary" style="margin-top: 10px;">Go to Batteries</a>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
