<?php
/**
 * API: Recalculate System Configuration
 * Called when user changes inverter, batteries, or panels in configurator
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json; charset=utf-8');
session_start();

try {
    require_once '../includes/db.php';
    require_once '../includes/csrf.php';
    require_once '../includes/helpers.php';

    set_security_headers();

    if (!rate_limit('api_recalculate', 30, 60)) { respond_rate_limited(); }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'initialization_failed',
        'message' => 'Failed to initialize API: ' . $e->getMessage()
    ]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond_json(['success' => false, 'message' => 'Method not allowed'], 405);
}

$input = json_decode(file_get_contents('php://input'), true);

if (!validate_csrf_token($input['csrf_token'] ?? '')) {
    respond_json(['success' => false, 'error' => 'csrf_invalid'], 403);
}

try {
    $db = getDB();

    // Get input parameters
    $inverter_id = intval($input['inverter_id']);
    $battery_id = intval($input['battery_id']);
    $battery_quantity = intval($input['battery_quantity']);
    $panel_id = intval($input['panel_id']);
    $panel_quantity = intval($input['panel_quantity']);
    $load_analysis = $input['load_analysis'];

    // Validate inputs
    if ($battery_quantity < 1 || $battery_quantity > 64) {
        respond_json(['success' => false, 'message' => 'Battery quantity must be between 1 and 64'], 400);
    }

    if ($panel_quantity < 1 || $panel_quantity > 200) {
        respond_json(['success' => false, 'message' => 'Panel quantity must be between 1 and 200'], 400);
    }

    // Fetch components from database (with field aliases matching configurator expectations)
    $stmt = $db->prepare("
        SELECT i.*,
            i.output_power_w                 AS max_load_watts,
            i.output_power_w                 AS power_rating,
            COALESCE(i.max_pv_input_w, 0)    AS max_pv_input,
            COALESCE(i.max_pv_input_w, 0)    AS max_solar_input,
            i.battery_voltage_range          AS voltage_class,
            i.battery_voltage_range          AS vdc_type,
            COALESCE(i.mppt_count, 1)        AS mppt_channels,
            COALESCE(c.name, 'Unknown')      AS company_name,
            COALESCE(c.logo_path, '')        AS company_logo
        FROM inverters i
        LEFT JOIN companies c ON i.company_id = c.id
        WHERE i.id = ? AND i.is_active = 1
    ");
    $stmt->execute([$inverter_id]);
    $inverter = $stmt->fetch();

    if (!$inverter) {
        respond_json(['success' => false, 'message' => 'Inverter not found'], 404);
    }

    $stmt = $db->prepare("
        SELECT b.*,
            b.type                             AS battery_type,
            COALESCE(b.is_bms, 'No')          AS has_bms,
            COALESCE(b.depth_of_discharge, 50) / 100.0 AS dod_decimal,
            COALESCE(b.depth_of_discharge, 50) AS depth_of_discharge,
            COALESCE(c.name, 'Unknown')        AS company_name,
            COALESCE(c.logo_path, '')          AS company_logo
        FROM batteries b
        LEFT JOIN companies c ON b.company_id = c.id
        WHERE b.id = ? AND b.is_active = 1
    ");
    $stmt->execute([$battery_id]);
    $battery = $stmt->fetch();

    if (!$battery) {
        respond_json(['success' => false, 'message' => 'Battery not found'], 404);
    }

    $stmt = $db->prepare("
        SELECT p.*,
            p.wattage                          AS watt_peak,
            COALESCE(p.panel_type, p.type, 'Mono') AS panel_type,
            COALESCE(c.name, 'Unknown')        AS company_name,
            COALESCE(c.logo_path, '')          AS company_logo
        FROM panels p
        LEFT JOIN companies c ON p.company_id = c.id
        WHERE p.id = ? AND p.is_active = 1
    ");
    $stmt->execute([$panel_id]);
    $panel = $stmt->fetch();

    if (!$panel) {
        respond_json(['success' => false, 'message' => 'Panel not found'], 404);
    }

    // Calculate battery configuration with proper series/parallel wiring
    $battery_voltage = floatval($battery['nominal_voltage'] ?? $battery['voltage'] ?? 12);
    if ($battery_voltage <= 0) $battery_voltage = 12;

    // Parse inverter battery voltage range (e.g. "48-60V", "48V", "38.4~60")
    $inv_bvr = $inverter['battery_voltage_range'] ?? $inverter['vdc_type'] ?? '48V';
    $inv_min_v = 0; $inv_max_v = 0;
    $clean_bvr = str_replace(['V','v','DC','dc'], '', $inv_bvr);
    if (preg_match('/^(\d+\.?\d*)\s*[-–~]\s*(\d+\.?\d*)$/', trim($clean_bvr), $m)) {
        $inv_min_v = floatval($m[1]);
        $inv_max_v = floatval($m[2]);
    } elseif (preg_match('/^(\d+\.?\d*)$/', trim($clean_bvr), $m)) {
        $sv = floatval($m[1]);
        $inv_min_v = round($sv * 0.85, 1);
        $inv_max_v = round($sv * 1.15, 1);
    } else {
        // Fallback: extract first number from string
        preg_match('/(\d+)/', $inv_bvr, $nm);
        $sv = isset($nm[1]) ? floatval($nm[1]) : 48;
        $inv_min_v = round($sv * 0.85, 1);
        $inv_max_v = round($sv * 1.15, 1);
    }
    if ($inv_min_v <= 0 || $inv_max_v <= 0) { $inv_min_v = 40.8; $inv_max_v = 55.2; }

    // Find valid series range: bat_v × series must fall within inverter range
    $max_safe_series = 16;
    $min_series = max(1, (int)ceil($inv_min_v / $battery_voltage));
    $max_series = min($max_safe_series, (int)floor($inv_max_v / $battery_voltage));
    if ($min_series > $max_series) {
        // Fallback: use simple division
        $min_series = max(1, (int)round($inv_min_v / $battery_voltage));
        $max_series = $min_series;
    }

    // Pick optimal series: closest to midpoint of inverter voltage range
    $sweet_spot = ($inv_min_v + $inv_max_v) / 2.0;
    $best_series = $min_series;
    $best_dist = PHP_FLOAT_MAX;
    for ($s = $min_series; $s <= $max_series; $s++) {
        $d = abs($battery_voltage * $s - $sweet_spot) + ($s - 1) * 1.5;
        if ($d < $best_dist) { $best_dist = $d; $best_series = $s; }
    }
    $series_count = $best_series;
    $string_voltage_v = round($battery_voltage * $series_count, 1); // used in wiring desc

    // Calculate parallel: snap battery_quantity to valid multiple of series_count
    $parallel_count = max(1, (int)round($battery_quantity / $series_count));
    $battery_quantity = $series_count * $parallel_count;

    // Calculate total capacity (parallel strings add Ah)
    $total_ah = $parallel_count * floatval($battery['capacity_ah']);

    // Generate wiring description
    if ($series_count > 1 && $parallel_count > 1) {
        $wiring = "{$series_count}S{$parallel_count}P — {$series_count} in series ({$battery_voltage}V×{$series_count}={$string_voltage_v}V), {$parallel_count} strings in parallel";
        $connection_type = 'series-parallel';
    } elseif ($series_count > 1) {
        $wiring = "{$series_count} in series ({$battery_voltage}V×{$series_count}={$string_voltage_v}V)";
        $connection_type = 'series';
    } elseif ($parallel_count > 1) {
        $wiring = "{$parallel_count} in parallel ({$battery_voltage}V, {$parallel_count}×{$battery['capacity_ah']}Ah={$total_ah}Ah)";
        $connection_type = 'parallel';
    } else {
        $wiring = "Single battery ({$battery_voltage}V, {$battery['capacity_ah']}Ah)";
        $connection_type = 'single';
    }

    $bat_price = floatval($battery['price_unit_usd'] ?? $battery['price_usd'] ?? 0);
    $battery_config = [
        'battery' => $battery,
        'quantity' => $battery_quantity,
        'series' => $series_count,
        'parallel' => $parallel_count,
        'series_count' => $series_count,
        'parallel_count' => $parallel_count,
        'total_ah' => $total_ah,
        'total_cost' => $battery_quantity * $bat_price,
        'wiring' => $wiring,
        'connection_type' => $connection_type,
        'string_voltage' => round($battery_voltage * $series_count, 1),
        'config_code' => "{$series_count}S{$parallel_count}P",
    ];

    // Calculate panel configuration
    $total_solar_watts = $panel_quantity * $panel['wattage'];
    $total_kwp = $total_solar_watts / 1000;

    $panel_config = [
        'panel' => $panel,
        'quantity' => $panel_quantity,
        'total_wattage' => $total_solar_watts,
        'total_kwp' => round($total_kwp, 2),
        'total_cost' => $panel_quantity * floatval($panel['price_usd'] ?? 0),
        'wiring' => $panel_quantity <= 2
            ? "{$panel_quantity} panel" . ($panel_quantity > 1 ? 's in series' : '')
            : "Configuration varies by voltage"
    ];

    // Run hour-by-hour simulation
    $hourly_load = $load_analysis['hourly_load'];
    $system_voltage = $load_analysis['system_voltage'];
    $peak_load_watts = $load_analysis['peak_load_watts'];

    // Solar curve (same as recommend_v2.php)
    $solar_curve = [
        0 => 0, 1 => 0, 2 => 0, 3 => 0, 4 => 0,
        5 => 0.05, 6 => 0.15, 7 => 0.30, 8 => 0.50, 9 => 0.70,
        10 => 0.85, 11 => 1.00, 12 => 1.00, 13 => 1.00, 14 => 1.00,
        15 => 0.90, 16 => 0.70, 17 => 0.40,
        18 => 0, 19 => 0, 20 => 0, 21 => 0, 22 => 0, 23 => 0
    ];

    // Efficiency factors
    $solar_panel_efficiency = 0.95;
    $mppt_efficiency = 0.97;
    $battery_charge_efficiency = 0.90;
    $battery_discharge_efficiency = 0.90;
    $inverter_efficiency = 0.90;
    $cable_losses = 0.97;

    $solar_to_battery_efficiency = $solar_panel_efficiency * $mppt_efficiency * $battery_charge_efficiency * $cable_losses;
    $battery_to_load_efficiency = $battery_discharge_efficiency * $inverter_efficiency * $cable_losses;
    $solar_to_load_efficiency = $solar_panel_efficiency * $mppt_efficiency * $inverter_efficiency * $cable_losses;

    $inverter_idle_consumption_watts = 20;

    // Simulation
    // Battery bank voltage = battery_voltage × series_count
    $battery_bank_voltage = $battery_voltage * $series_count;
    $dod_decimal = floatval($battery['dod_decimal'] ?? ($battery['depth_of_discharge'] ?? 50) / 100);
    $dod_decimal = max(0.10, min(1.0, $dod_decimal));
    $battery_kwh = ($total_ah * $battery_bank_voltage) / 1000;
    $usable_kwh = $battery_kwh * $dod_decimal;
    $battery_current = 0; // Battery starts empty, charges from solar
    $grid_energy_needed = 0;
    $solar_to_loads_total = 0;
    $solar_to_battery_total = 0;
    $battery_to_loads_total = 0;
    $total_solar_generated = 0;
    $inverter_consumption_total = 0;
    $total_losses_kwh = 0;

    $hourly_simulation = [];

    for ($hour = 0; $hour < 24; $hour++) {
        // Solar generation
        $solar_generation_raw_kw = $total_kwp * $solar_curve[$hour];
        $solar_generation_kw = $solar_generation_raw_kw * $solar_panel_efficiency * $mppt_efficiency;
        $solar_generation_kwh = $solar_generation_kw;
        $total_solar_generated += $solar_generation_kwh;

        // Load
        $load_kw = $hourly_load[$hour] / 1000;
        $load_kwh = $load_kw;

        // Inverter consumption
        $inverter_idle_kwh = $inverter_idle_consumption_watts / 1000;
        $inverter_consumption_total += $inverter_idle_kwh;

        // Total load
        $total_load_kwh = $load_kwh + $inverter_idle_kwh;

        // Energy flow
        $hour_solar_to_load = 0;
        $hour_solar_to_battery = 0;
        $hour_battery_to_load = 0;
        $hour_grid_to_load = 0;

        if ($solar_generation_kwh > 0) {
            $solar_needed_for_load = $total_load_kwh / $solar_to_load_efficiency;

            if ($solar_generation_kwh >= $solar_needed_for_load) {
                $hour_solar_to_load = $total_load_kwh;
                $solar_to_loads_total += $total_load_kwh;
                $losses = $solar_needed_for_load - $total_load_kwh;
                $total_losses_kwh += $losses;

                $excess_solar = $solar_generation_kwh - $solar_needed_for_load;

                if ($battery_current < $battery_kwh && $excess_solar > 0) {
                    $charge_amount_raw = $excess_solar * $solar_to_battery_efficiency;
                    $charge_amount = min($charge_amount_raw, $battery_kwh - $battery_current);
                    $battery_current += $charge_amount;
                    $solar_to_battery_total += $charge_amount;
                    $hour_solar_to_battery = $charge_amount;
                    $charge_losses = $excess_solar - ($charge_amount / $solar_to_battery_efficiency);
                    $total_losses_kwh += $charge_losses;
                }
            } else {
                $hour_solar_to_load = $solar_generation_kwh * $solar_to_load_efficiency;
                $solar_to_loads_total += $hour_solar_to_load;
                $losses = $solar_generation_kwh * (1 - $solar_to_load_efficiency);
                $total_losses_kwh += $losses;
                $deficit = $total_load_kwh - $hour_solar_to_load;

                if ($battery_current > 0 && $deficit > 0) {
                    $battery_needed = $deficit / $battery_to_load_efficiency;
                    $battery_use = min($battery_needed, $battery_current);
                    $battery_current -= $battery_use;
                    $hour_battery_to_load = $battery_use * $battery_to_load_efficiency;
                    $battery_to_loads_total += $hour_battery_to_load;
                    $battery_losses = $battery_use - $hour_battery_to_load;
                    $total_losses_kwh += $battery_losses;
                    $deficit -= $hour_battery_to_load;
                }

                if ($deficit > 0) {
                    $grid_energy_needed += $deficit;
                    $hour_grid_to_load = $deficit;
                }
            }
        } else {
            // Night time
            if ($battery_current > 0) {
                $battery_needed = $total_load_kwh / $battery_to_load_efficiency;
                $battery_use = min($battery_needed, $battery_current);
                $battery_current -= $battery_use;
                $hour_battery_to_load = $battery_use * $battery_to_load_efficiency;
                $battery_to_loads_total += $hour_battery_to_load;
                $battery_losses = $battery_use - $hour_battery_to_load;
                $total_losses_kwh += $battery_losses;
                $deficit = $total_load_kwh - $hour_battery_to_load;
            } else {
                $deficit = $total_load_kwh;
            }

            if ($deficit > 0) {
                $grid_energy_needed += $deficit;
                $hour_grid_to_load = $deficit;
            }
        }

        $hourly_simulation[$hour] = [
            'hour' => $hour,
            'solar_generated' => round($solar_generation_kwh, 3),
            'load' => round($total_load_kwh, 3),
            'battery_level' => round($battery_current, 3),
            'solar_to_load' => round($hour_solar_to_load, 3),
            'solar_to_battery' => round($hour_solar_to_battery, 3),
            'battery_to_load' => round($hour_battery_to_load, 3),
            'grid_to_load' => round($hour_grid_to_load, 3)
        ];
    }

    // Update panel config with simulation results
    $panel_config['daily_generation_kwh'] = round($total_solar_generated, 2);
    $panel_config['solar_to_loads_kwh'] = round($solar_to_loads_total, 2);
    $panel_config['solar_to_battery_kwh'] = round($solar_to_battery_total, 2);
    $panel_config['battery_to_loads_kwh'] = round($battery_to_loads_total, 2);
    $panel_config['grid_energy_needed_kwh'] = round($grid_energy_needed, 2);
    $panel_config['inverter_consumption_kwh'] = round($inverter_consumption_total, 2);
    $panel_config['total_losses_kwh'] = round($total_losses_kwh, 2);
    $panel_config['system_efficiency'] = round((($total_solar_generated - $total_losses_kwh) / $total_solar_generated) * 100, 1);
    $panel_config['hourly_simulation'] = $hourly_simulation;
    $panel_config['inverter_solar_ratio'] = round(($total_solar_watts / $inverter['power_rating']) * 100, 0);

    // Calculate total cost (use correct column names)
    $inv_price = floatval($inverter['unit_price_usd'] ?? $inverter['price_usd'] ?? 0);
    $total_cost = $inv_price + $battery_config['total_cost'] + $panel_config['total_cost'];

    // Calculate backup hours based on usable capacity
    $actual_backup_hours = $peak_load_watts > 0
        ? round(($usable_kwh * 1000 * 0.90) / $peak_load_watts, 1)
        : 0;

    // Calculate energy independence
    $daily_energy_kwh = $load_analysis['daily_energy_kwh'];
    $energy_independence = $daily_energy_kwh > 0
        ? round((($daily_energy_kwh - $grid_energy_needed) / $daily_energy_kwh) * 100, 0)
        : 0;

    // Fix image paths
    $inverter['image_path'] = get_image_url($inverter['image_path']);
    $battery['image_path'] = get_image_url($battery['image_path']);
    $panel['image_path'] = get_image_url($panel['image_path']);

    // Build response
    $system = [
        'inverter' => $inverter,
        'battery_config' => $battery_config,
        'panel_config' => $panel_config,
        'total_cost' => $total_cost,
        'backup_hours' => $actual_backup_hours,
        'battery_storage_kwh' => round($battery_kwh, 2),
        'grid_units_per_day' => round($grid_energy_needed, 2),
        'solar_generation_per_day' => $panel_config['daily_generation_kwh'],
        'energy_independence' => $energy_independence
    ];

    respond_json([
        'success' => true,
        'system' => $system
    ]);

} catch (Exception $e) {
    error_log("Recalculation API error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    respond_json([
        'success' => false,
        'message' => 'An error occurred: ' . $e->getMessage()
    ], 500);
}
?>
