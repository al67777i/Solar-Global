<?php
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/location_helper.php';
require_once 'includes/subscription_helpers.php';
set_security_headers();
trackVisitor($pdo);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) {
    header('Location: batteries.php');
    exit;
}

// ═══ BATTERY DETAILS ══════════════════════════════════════════════
$stmt = $pdo->prepare("
    SELECT b.*, c.name as company_name, c.country, c.description as company_description,
           c.logo_path as company_logo, c.website as company_website, c.slug as company_slug
    FROM batteries b
    JOIN companies c ON b.company_id = c.id
    WHERE b.id = ? AND b.is_active = 1
");
$stmt->execute([$id]);
$battery = $stmt->fetch();

if (!$battery) {
    header('Location: batteries.php');
    exit;
}

// ═══ COUNTRY FLAG ══════════════════════════════════════════════════
$origin     = $battery['country'] ?: $battery['country'];
$flag_emoji = '';
if ($origin) {
    $flagStmt = $pdo->prepare("
        SELECT flag_emoji, flag_icon, code FROM countries
        WHERE LOWER(name COLLATE utf8mb4_general_ci) = LOWER(?)
           OR LOWER(code COLLATE utf8mb4_general_ci) = LOWER(?)
        LIMIT 1
    ");
    $flagStmt->execute([$origin, $origin]);
    $flagRow    = $flagStmt->fetch();
    $flag_emoji = $flagRow ? ($flagRow['flag_emoji'] ?? '') : '';
}

// ═══ USER CURRENCY ══════════════════════════════════════════════════
$user_cc = 'US';
$loc     = json_decode($_COOKIE['sg_location'] ?? '{}', true);
if (!empty($loc['country_code'])) {
    $user_cc = $loc['country_code'];
} else {
    $detected = detect_user_country();
    if ($detected) $user_cc = $detected;
}
$currency_info   = get_country_currency_info($user_cc);
$currency_symbol = $currency_info['currency_symbol'];
$currency_code   = $currency_info['currency_code'];
$exchange_rate   = max(0.001, $currency_info['exchange_rate']);

// Helpers
function toLocal($usd, $rate) { return round($usd * $rate, 0); }
function formatLocal($usd, $rate, $symbol) { return $symbol . number_format(toLocal($usd, $rate)); }

$local_price = toLocal($battery['price_unit_usd'], $exchange_rate);

// ═══ ENERGY IN KWH ════════════════════════════════════════════════
$kwh = ($battery['capacity_ah'] * $battery['nominal_voltage']) / 1000;

// ═══ SIMILAR BATTERIES ════════════════════════════════════════════
$similar_stmt = $pdo->prepare("
    SELECT b.*, c.name as company_name
    FROM batteries b
    JOIN companies c ON b.company_id = c.id
    WHERE b.id != ?
      AND b.type = ?
      AND b.nominal_voltage BETWEEN ? AND ?
      AND b.is_active = 1
    ORDER BY ABS(b.price_unit_usd - ?) ASC
    LIMIT 4
");
$similar_stmt->execute([
    $id,
    $battery['type'],
    $battery['nominal_voltage'] * 0.7,
    $battery['nominal_voltage'] * 1.3,
    $battery['price_unit_usd'],
]);
$similar = $similar_stmt->fetchAll();

// ═══ WHERE TO BUY — NEARBY DEALERS ════════════════════════════════
$user_lat = null;
$user_lng = null;
$dealers  = [];
$user_loc = detect_user_location();
if ($user_loc['detected']) {
    $user_lat = $user_loc['lat'];
    $user_lng = $user_loc['lng'];
}

$sub_filter = get_dealer_subscription_filter('d');

if ($user_lat !== null && $user_lng !== null) {
    $haversine  = haversine_sql('d.latitude', 'd.longitude');
    $dealer_sql = "
        SELECT d.id, d.business_name, d.city, d.country_code,
               dp.dealer_price, dp.stock_quantity,
               {$haversine} AS distance_km
        FROM dealer_products dp
        JOIN dealers d ON dp.dealer_id = d.id
        WHERE dp.product_type = 'battery'
          AND dp.product_id = ?
          AND dp.is_active = 1
          AND d.latitude IS NOT NULL AND d.longitude IS NOT NULL
          AND {$sub_filter}
        ORDER BY distance_km ASC
        LIMIT 10
    ";
    $dStmt = $pdo->prepare($dealer_sql);
    $dStmt->execute([$user_lat, $user_lng, $user_lat, $id]);
    $dealers = $dStmt->fetchAll();
}

// Country-based fallback when no coordinates available
if (empty($dealers)) {
    $fallback_cc = $user_loc['country_code'] ?? detect_user_country();
    if (!empty($fallback_cc)) {
        $dStmt = $pdo->prepare("
            SELECT d.id, d.business_name, d.city, d.country_code,
                   dp.dealer_price, dp.stock_quantity,
                   NULL AS distance_km
            FROM dealer_products dp
            JOIN dealers d ON dp.dealer_id = d.id
            WHERE dp.product_type = 'battery' AND dp.product_id = ? AND dp.is_active = 1
              AND d.country_code = ?
              AND {$sub_filter}
            ORDER BY dp.dealer_price ASC
            LIMIT 10
        ");
        $dStmt->execute([$id, $fallback_cc]);
        $dealers = $dStmt->fetchAll();
    }
}

// ═══ SEO META ══════════════════════════════════════════════════════
$site_name = get_system_setting('site_name', 'SolarGlobal');
$page_title       = htmlspecialchars($battery['model']) . ' - ' . htmlspecialchars($battery['company_name']) . ' | ' . $site_name;
$page_description = $battery['model'] . ' — ' . ($battery['type'] ?? 'Solar') . ' battery, '
    . $battery['nominal_voltage'] . 'V ' . number_format($battery['capacity_ah']) . 'Ah. Price: '
    . $currency_symbol . number_format($local_price)
    . ($battery['warranty_years'] ? '. ' . $battery['warranty_years'] . ' year warranty.' : '.');
$page_keywords    = $battery['model'] . ', ' . $battery['company_name'] . ' battery, '
    . ($battery['type'] ?? 'solar') . ' battery, ' . $battery['nominal_voltage'] . 'V battery, solar battery';
$current_page     = 'batteries';
$page_og_type     = 'product';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0D3B6E">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="mobile-web-app-capable" content="yes">
    <title><?php echo $page_title; ?></title>

    <!-- SEO Meta -->
    <meta name="description" content="<?php echo htmlspecialchars($page_description); ?>">
    <meta name="keywords"    content="<?php echo htmlspecialchars($page_keywords); ?>">
    <meta name="author"      content="<?= htmlspecialchars($site_name) ?>">
    <meta name="robots"      content="index, follow">

    <!-- Open Graph -->
    <meta property="og:title"       content="<?php echo $page_title; ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($page_description); ?>">
    <meta property="og:url"         content="<?php echo htmlspecialchars(getCurrentUrl()); ?>">
    <meta property="og:type"        content="product">
    <?php if (!empty($battery['image_path'])): ?>
    <meta property="og:image" content="<?php echo htmlspecialchars(get_image_url($battery['image_path'])); ?>">
    <?php endif; ?>

    <!-- Canonical -->
    <link rel="canonical" href="<?php echo htmlspecialchars(getCurrentUrl()); ?>">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/frontend.css">
    <link rel="stylesheet" href="assets/css/products.css">
    <link rel="stylesheet" href="assets/css/mobile-app.css">

    <!-- JSON-LD Product Schema -->
    <?php $baseUrl = 'https://' . ($_SERVER['HTTP_HOST'] ?? (get_system_setting('site_domain', 'solarglobal.com') ?: 'solarglobal.com')) . BASE_URL; ?>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": <?php echo json_encode($battery['model']); ?>,
        "url": <?php echo json_encode($baseUrl . 'battery-detail.php?id=' . (int)$battery['id']); ?>,
        "brand": { "@type": "Brand", "name": <?php echo json_encode($battery['company_name']); ?> },
        "description": <?php echo json_encode($page_description); ?>,
        <?php if (!empty($battery['image_path'])): ?>
        "image": <?php echo json_encode('https://' . ($_SERVER['HTTP_HOST'] ?? '') . get_image_url($battery['image_path'])); ?>,
        <?php endif; ?>
        "offers": {
            "@type": "Offer",
            "price": "<?php echo number_format($battery['price_unit_usd'], 2, '.', ''); ?>",
            "priceCurrency": "USD",
            "availability": "https://schema.org/InStock"
        }
        <?php if ($battery['warranty_years']): ?>,
        "warranty": "<?php echo (int)$battery['warranty_years']; ?> year(s)"
        <?php endif; ?>
    }
    </script>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "Home", "item": "<?= $baseUrl ?>"},
            {"@type": "ListItem", "position": 2, "name": "Batteries", "item": "<?= $baseUrl ?>batteries.php"},
            {"@type": "ListItem", "position": 3, "name": "<?= sanitize($battery['model']) ?>"}
        ]
    }
    </script>

    <style>
    /* ── Currency Bar ── */
    .currency-bar { background: #FFFBEB; border-bottom: 1px solid #FDE68A; padding: 8px 0; font-size: 0.82rem; }
    .currency-bar-inner { max-width: 1280px; margin: 0 auto; padding: 0 20px; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .currency-bar-badge { background: #F59E0B; color: #fff; padding: 3px 10px; border-radius: 20px; font-weight: 700; font-size: 0.78rem; }

    /* ── Hero ── */
    .batt-hero { background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%); padding: 40px 0 48px; }
    .batt-hero-inner { max-width: 1280px; margin: 0 auto; padding: 0 24px; }

    /* Breadcrumb inside hero */
    .batt-breadcrumb { display: flex; align-items: center; gap: 6px; margin-bottom: 20px; font-size: 0.84rem; flex-wrap: wrap; }
    .batt-breadcrumb a { color: #94A3B8; text-decoration: none; transition: color 0.2s; }
    .batt-breadcrumb a:hover { color: #F59E0B; }
    .batt-breadcrumb .sep { color: #475569; }
    .batt-breadcrumb .current { color: #64748B; }

    /* Hero grid */
    .batt-hero-grid { display: grid; grid-template-columns: 300px 1fr; gap: 40px; align-items: start; }
    @media (max-width: 900px) { .batt-hero-grid { grid-template-columns: 1fr; gap: 24px; } }

    /* Product image box */
    .batt-image-box {
        background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);
        border-radius: 16px; aspect-ratio: 1; display: flex; align-items: center;
        justify-content: center; overflow: hidden; max-height: 300px;
    }
    .batt-image-box img { width: 100%; height: 100%; object-fit: contain; padding: 16px;
        -webkit-user-drag: none; user-select: none; pointer-events: none; }
    .batt-image-placeholder { font-size: 5rem; }

    /* Product info */
    .batt-hero-info { color: #fff; }
    .batt-hero-brand { display: flex; align-items: center; gap: 8px; font-size: 0.9rem; color: #94A3B8; margin-bottom: 8px; }
    .batt-hero-brand .flag { font-size: 1.2rem; }
    .batt-hero-h1 { font-size: 2rem; font-weight: 800; color: #fff; margin: 0 0 16px; line-height: 1.25; }
    @media (max-width: 600px) { .batt-hero-h1 { font-size: 1.5rem; } }

    .batt-type-badge {
        display: inline-flex; align-items: center;
        background: rgba(245,158,11,0.15); border: 1px solid rgba(245,158,11,0.4);
        color: #F59E0B; padding: 4px 14px; border-radius: 20px; font-size: 0.78rem;
        font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 16px;
    }

    /* Price */
    .batt-price-block { margin: 0 0 20px; }
    .batt-price-local { font-size: 2rem; font-weight: 800; color: #F59E0B; display: block; }
    .batt-price-usd { font-size: 0.85rem; color: #64748B; margin-top: 2px; display: block; }

    /* Spec pills */
    .batt-pills { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 24px; }
    .batt-pill {
        background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.12);
        border-radius: 10px; padding: 8px 14px; display: flex; flex-direction: column;
        min-width: 76px; gap: 2px;
    }
    .batt-pill-label { font-size: 0.68rem; color: #64748B; text-transform: uppercase; letter-spacing: 0.06em; }
    .batt-pill-value { font-size: 0.95rem; font-weight: 700; color: #fff; }
    .batt-pill.bms-pill { background: rgba(16,185,129,0.15); border-color: rgba(16,185,129,0.3); }
    .batt-pill.bms-pill .batt-pill-value { color: #10B981; }

    /* Actions */
    .batt-actions { display: flex; gap: 12px; flex-wrap: wrap; }
    .batt-btn-primary {
        display: inline-flex; align-items: center; gap: 6px;
        background: linear-gradient(135deg, #F59E0B, #D97706); color: #fff;
        padding: 12px 24px; border-radius: 10px; font-weight: 700; font-size: 0.9rem;
        text-decoration: none; border: none; cursor: pointer; transition: opacity 0.2s;
        box-shadow: 0 4px 15px rgba(245,158,11,0.3);
    }
    .batt-btn-primary:hover { opacity: 0.9; }
    .batt-btn-outline {
        display: inline-flex; align-items: center; gap: 6px;
        background: transparent; color: #94A3B8; padding: 12px 24px; border-radius: 10px;
        font-weight: 600; font-size: 0.9rem; text-decoration: none;
        border: 1.5px solid rgba(255,255,255,0.15); cursor: pointer; transition: all 0.2s;
        font-family: inherit;
    }
    .batt-btn-outline:hover { border-color: #F59E0B; color: #F59E0B; }

    /* ── Main Content ── */
    .batt-content { max-width: 1280px; margin: 0 auto; padding: 40px 24px 80px; }

    /* ── Tabs ── */
    .batt-tab-nav {
        display: flex; border-bottom: 2px solid #E2E8F0; overflow-x: auto; scrollbar-width: none;
    }
    .batt-tab-nav::-webkit-scrollbar { display: none; }
    .batt-tab-btn {
        padding: 14px 22px; border: none; background: transparent; font-size: 0.9rem;
        font-weight: 600; color: #64748B; cursor: pointer; border-bottom: 2px solid transparent;
        margin-bottom: -2px; white-space: nowrap; transition: all 0.2s; font-family: inherit;
    }
    .batt-tab-btn:hover { color: #1E293B; }
    .batt-tab-btn.active { color: #F59E0B; border-bottom-color: #F59E0B; }
    .batt-tab-panel { display: none; padding: 32px 0 0; }
    .batt-tab-panel.active { display: block; }

    /* ── Specs Table ── */
    .batt-specs-table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
    .batt-specs-table tr:nth-child(even) td { background: #F8FAFC; }
    .batt-specs-table td { padding: 12px 16px; border-bottom: 1px solid #E2E8F0; vertical-align: top; }
    .batt-specs-table td:first-child { font-weight: 600; color: #475569; width: 35%; white-space: nowrap; }
    .batt-specs-table td:last-child { color: #1E293B; }
    .spec-green { color: #10B981; font-weight: 600; }
    .spec-amber { color: #F59E0B; font-weight: 800; font-size: 1.1rem; }

    /* ── Features ── */
    .batt-features-list { list-style: none; padding: 0; margin: 0; }
    .batt-features-list li {
        padding: 13px 0; border-bottom: 1px solid #E2E8F0; font-size: 1rem;
        color: #475569; display: flex; align-items: flex-start; gap: 10px;
    }
    .batt-features-list li:last-child { border-bottom: none; }
    .batt-features-list li .fcheck { color: #10B981; font-weight: 700; flex-shrink: 0; margin-top: 1px; }

    /* ── Where to Buy ── */
    .batt-dealers-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
    .batt-dealer-card {
        background: #fff; border: 1.5px solid #E2E8F0; border-radius: 14px;
        padding: 20px; transition: all 0.2s;
    }
    .batt-dealer-card:hover { border-color: #F59E0B; box-shadow: 0 6px 20px rgba(245,158,11,0.10); transform: translateY(-2px); }
    .batt-dealer-name { font-size: 1rem; font-weight: 700; color: #1E293B; margin-bottom: 4px; }
    .batt-dealer-city { font-size: 0.82rem; color: #64748B; margin-bottom: 12px; }
    .batt-distance-badge {
        display: inline-block; background: #FFFBEB; color: #92400E; border: 1px solid #FDE68A;
        padding: 3px 10px; border-radius: 20px; font-size: 0.72rem; font-weight: 700; margin-bottom: 12px;
    }
    .batt-dealer-price { font-size: 1.2rem; font-weight: 800; color: #F59E0B; display: block; margin-bottom: 4px; }
    .batt-dealer-price-usd { font-size: 0.78rem; color: #94A3B8; display: block; margin-bottom: 14px; }
    .batt-visit-btn {
        display: block; text-align: center; background: linear-gradient(135deg,#F59E0B,#D97706);
        color: #fff; padding: 10px 20px; border-radius: 8px; font-weight: 700;
        font-size: 0.85rem; text-decoration: none; transition: opacity 0.2s;
    }
    .batt-visit-btn:hover { opacity: 0.9; }
    .batt-no-dealers {
        text-align: center; padding: 40px 20px; background: #F8FAFC;
        border-radius: 14px; border: 1.5px dashed #E2E8F0;
    }
    .batt-no-dealers .icon { font-size: 2.5rem; margin-bottom: 12px; }
    .batt-no-dealers h3 { color: #1E293B; margin: 0 0 8px; font-size: 1.1rem; }
    .batt-no-dealers p { color: #64748B; font-size: 0.9rem; margin: 0; }

    /* ── About Brand ── */
    .batt-brand-card {
        background: #F8FAFC; border: 1.5px solid #E2E8F0; border-radius: 14px;
        padding: 28px; display: flex; gap: 24px; align-items: flex-start;
    }
    @media (max-width: 600px) { .batt-brand-card { flex-direction: column; } }
    .batt-brand-logo-box {
        width: 72px; height: 72px; flex-shrink: 0; background: #fff;
        border: 1px solid #E2E8F0; border-radius: 12px; display: flex;
        align-items: center; justify-content: center; overflow: hidden;
    }
    .batt-brand-logo-box img { width: 100%; height: 100%; object-fit: contain; padding: 6px; }
    .batt-brand-name { font-size: 1.2rem; font-weight: 800; color: #1E293B; margin: 0 0 4px; }
    .batt-brand-meta { font-size: 0.85rem; color: #64748B; margin-bottom: 12px; }
    .batt-brand-desc { font-size: 0.9rem; color: #475569; line-height: 1.7; margin: 0 0 16px; }
    .batt-brand-link { display: inline-flex; align-items: center; gap: 6px; color: #F59E0B; font-weight: 600; font-size: 0.85rem; text-decoration: none; }
    .batt-brand-link:hover { text-decoration: underline; }

    /* ── Similar Batteries ── */
    .similar-section { margin-top: 60px; border-top: 2px solid #F1F5F9; padding-top: 40px; }
    .similar-section h2 { font-size: 1.5rem; font-weight: 800; color: #1E293B; margin: 0 0 24px; }
    .similar-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 16px; }
    .similar-card {
        background: #fff; border: 1.5px solid #E2E8F0; border-radius: 14px;
        padding: 20px; transition: all 0.2s;
    }
    .similar-card:hover { border-color: #F59E0B; box-shadow: 0 6px 20px rgba(245,158,11,0.08); transform: translateY(-2px); }
    .similar-type-badge { display: inline-block; background: #F1F5F9; color: #475569; padding: 3px 10px; border-radius: 20px; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; margin-bottom: 10px; }
    .similar-brand { font-size: 0.78rem; color: #94A3B8; margin-bottom: 4px; }
    .similar-name { font-size: 0.95rem; font-weight: 700; color: #1E293B; margin: 0 0 12px; line-height: 1.4; }
    .similar-specs { display: flex; gap: 8px; margin-bottom: 14px; flex-wrap: wrap; }
    .similar-spec { background: #F8FAFC; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem; color: #64748B; }
    .similar-spec strong { color: #1E293B; }
    .similar-price { font-size: 1.1rem; font-weight: 800; color: #F59E0B; margin-bottom: 14px; }
    .similar-price .usd { font-size: 0.75rem; color: #94A3B8; font-weight: 400; display: block; margin-top: 2px; }
    .similar-btn {
        display: block; text-align: center; border: 1.5px solid #F59E0B; color: #F59E0B;
        padding: 9px; border-radius: 8px; font-weight: 700; font-size: 0.82rem;
        text-decoration: none; transition: all 0.2s;
    }
    .similar-btn:hover { background: #F59E0B; color: #fff; }
    </style>
</head>
<body>
    <?php include 'includes/header-nav.php'; ?>
    <?php include_once 'includes/ad_display.php'; ?>
    <?php renderAds('header'); ?>

    <!-- Currency Bar -->
    <div class="currency-bar">
        <div class="currency-bar-inner">
            <span style="color:#92400E;font-weight:500;">Prices shown in:</span>
            <span class="currency-bar-badge"><?php echo htmlspecialchars($currency_code); ?> (<?php echo htmlspecialchars($currency_symbol); ?>)</span>
        </div>
    </div>

    <!-- ═══ HERO ════════════════════════════════════════════════════════════ -->
    <div class="batt-hero">
        <div class="batt-hero-inner">

            <!-- Breadcrumb -->
            <nav class="batt-breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo BASE_URL; ?>">Home</a>
                <span class="sep">/</span>
                <a href="<?php echo BASE_URL; ?>batteries.php">Batteries</a>
                <span class="sep">/</span>
                <span class="current"><?php echo htmlspecialchars($battery['model']); ?></span>
            </nav>

            <div class="batt-hero-grid">

                <!-- Product Image -->
                <div class="batt-image-box">
                    <?php if (!empty($battery['image_path'])): ?>
                        <img src="<?php echo htmlspecialchars(get_image_url($battery['image_path'])); ?>"
                             alt="<?php echo htmlspecialchars($battery['model']); ?>" loading="eager">
                    <?php else: ?>
                        <span class="batt-image-placeholder">&#128267;</span>
                    <?php endif; ?>
                </div>

                <!-- Product Info -->
                <div class="batt-hero-info">

                    <?php if ($battery['type']): ?>
                    <div class="batt-type-badge"><?php echo htmlspecialchars($battery['type']); ?></div>
                    <?php endif; ?>

                    <div class="batt-hero-brand">
                        <?php if ($flagRow || $flag_emoji): ?>
                            <span class="flag"><?= get_country_flag($flagRow ?? $battery['country'], 20) ?></span>
                        <?php endif; ?>
                        <?php echo htmlspecialchars($battery['company_name']); ?>
                        <?php if ($battery['country']): ?>
                            <span style="color:#475569;">&#8212; <?php echo htmlspecialchars($battery['country']); ?></span>
                        <?php endif; ?>
                    </div>

                    <h1 class="batt-hero-h1"><?php echo htmlspecialchars($battery['model']); ?></h1>

                    <!-- Price -->
                    <div class="batt-price-block">
                        <span class="batt-price-local"><?php echo htmlspecialchars($currency_symbol); ?><?php echo number_format($local_price); ?></span>
                        <?php if ($currency_code !== 'USD'): ?>
                            <span class="batt-price-usd">$<?php echo number_format($battery['price_unit_usd']); ?> USD</span>
                        <?php endif; ?>
                    </div>

                    <!-- Key Spec Pills -->
                    <div class="batt-pills">
                        <div class="batt-pill">
                            <span class="batt-pill-label">Voltage</span>
                            <span class="batt-pill-value"><?php echo htmlspecialchars($battery['nominal_voltage']); ?>V</span>
                        </div>
                        <div class="batt-pill">
                            <span class="batt-pill-label">Capacity</span>
                            <span class="batt-pill-value"><?php echo number_format($battery['capacity_ah']); ?> Ah</span>
                        </div>
                        <div class="batt-pill">
                            <span class="batt-pill-label">Energy</span>
                            <span class="batt-pill-value"><?php echo number_format($kwh, 2); ?> kWh</span>
                        </div>
                        <?php if ($battery['warranty_years']): ?>
                        <div class="batt-pill">
                            <span class="batt-pill-label">Warranty</span>
                            <span class="batt-pill-value"><?php echo (int)$battery['warranty_years']; ?> yr</span>
                        </div>
                        <?php endif; ?>
                        <?php if ($battery['is_bms'] === 'Yes'): ?>
                        <div class="batt-pill bms-pill">
                            <span class="batt-pill-label">BMS</span>
                            <span class="batt-pill-value">&#10003; Built-in</span>
                        </div>
                        <?php endif; ?>
                        <?php if ($battery['depth_of_discharge']): ?>
                        <div class="batt-pill">
                            <span class="batt-pill-label">DoD</span>
                            <span class="batt-pill-value"><?php echo htmlspecialchars($battery['depth_of_discharge']); ?>%</span>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Actions -->
                    <div class="batt-actions">
                        <a href="<?php echo BASE_URL; ?>contact.php" class="batt-btn-primary">
                            &#128222; Contact for Quote
                        </a>
                        <button type="button" class="batt-btn-outline"
                            onclick="addToCompare(<?php echo (int)$battery['id']; ?>, 'battery', '<?php echo htmlspecialchars(addslashes($battery['model']), ENT_QUOTES); ?>'); return false;">
                            &#128202; Add to Compare
                        </button>
                    </div>

                </div><!-- /.batt-hero-info -->
            </div><!-- /.batt-hero-grid -->
        </div>
    </div>
    <!-- ═══ END HERO ══════════════════════════════════════════════════════════ -->

    <!-- ═══ MAIN CONTENT ═══════════════════════════════════════════════════ -->
    <div class="batt-content">

        <!-- Tabs -->
        <div class="batt-tabs">
            <div class="batt-tab-nav" role="tablist">
                <button class="batt-tab-btn active" role="tab" aria-selected="true"
                        onclick="switchBattTab('specs', this)">Specifications</button>
                <button class="batt-tab-btn" role="tab" aria-selected="false"
                        onclick="switchBattTab('features', this)">Features</button>
                <button class="batt-tab-btn" role="tab" aria-selected="false"
                        onclick="switchBattTab('dealers', this)">Where to Buy<?php if (!empty($dealers)): ?> <span style="background:#F59E0B;color:#fff;border-radius:20px;padding:1px 7px;font-size:0.7rem;margin-left:4px;"><?php echo count($dealers); ?></span><?php endif; ?></button>
                <button class="batt-tab-btn" role="tab" aria-selected="false"
                        onclick="switchBattTab('brand', this)">About Brand</button>
            </div>

            <!-- ── Specifications Tab ── -->
            <div id="batt-panel-specs" class="batt-tab-panel active" role="tabpanel">
                <table class="batt-specs-table">
                    <thead>
                        <tr>
                            <td style="font-weight:700;color:#1E293B;font-size:0.78rem;text-transform:uppercase;letter-spacing:0.06em;padding-bottom:8px;border-bottom:2px solid #E2E8F0;">Specification</td>
                            <td style="font-weight:700;color:#1E293B;font-size:0.78rem;text-transform:uppercase;letter-spacing:0.06em;padding-bottom:8px;border-bottom:2px solid #E2E8F0;">Value</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td>Model Name</td><td><?php echo htmlspecialchars($battery['model']); ?></td></tr>
                        <tr><td>Brand</td><td><?php echo htmlspecialchars($battery['company_name']); ?></td></tr>
                        <?php if ($battery['type']): ?>
                        <tr><td>Battery Type</td><td><?php echo htmlspecialchars($battery['type']); ?></td></tr>
                        <?php endif; ?>
                        <tr><td>Voltage</td><td><?php echo htmlspecialchars($battery['nominal_voltage']); ?> V</td></tr>
                        <tr><td>Capacity</td><td><?php echo number_format($battery['capacity_ah']); ?> Ah &mdash; <?php echo number_format($kwh, 2); ?> kWh</td></tr>
                        <?php if (isset($battery['is_bms'])): ?>
                        <tr>
                            <td>Built-in BMS</td>
                            <td><?php echo $battery['is_bms'] === 'Yes'
                                ? '<span class="spec-green">&#10003; Yes</span>'
                                : '<span style="color:#EF4444;">&#10007; No</span>'; ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if ($battery['cycle_life']): ?>
                        <tr><td>Cycle Life</td><td><?php echo number_format($battery['cycle_life']); ?> cycles</td></tr>
                        <?php endif; ?>
                        <?php if ($battery['depth_of_discharge']): ?>
                        <tr><td>Depth of Discharge (DoD)</td><td><?php echo htmlspecialchars($battery['depth_of_discharge']); ?>%</td></tr>
                        <?php endif; ?>
                        <?php if ($battery['charging_current_max']): ?>
                        <tr><td>Max Charging Current</td><td><?php echo htmlspecialchars($battery['charging_current_max']); ?> A</td></tr>
                        <?php endif; ?>
                        <?php if ($battery['warranty_years']): ?>
                        <tr><td>Warranty</td><td><?php echo (int)$battery['warranty_years']; ?> year(s)</td></tr>
                        <?php endif; ?>
                        <?php if ($battery['weight_kg']): ?>
                        <tr><td>Weight</td><td><?php echo htmlspecialchars($battery['weight_kg']); ?> kg</td></tr>
                        <?php endif; ?>
                        <?php if ($battery['dimensions']): ?>
                        <tr><td>Dimensions</td><td><?php echo htmlspecialchars($battery['dimensions']); ?></td></tr>
                        <?php endif; ?>
                        <?php if (isset($battery['maintenance_free'])): ?>
                        <tr>
                            <td>Maintenance Free</td>
                            <td><?php echo $battery['maintenance_free']
                                ? '<span class="spec-green">&#10003; Yes</span>'
                                : 'No'; ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if ($battery['temperature_range']): ?>
                        <tr><td>Operating Temperature</td><td><?php echo htmlspecialchars($battery['temperature_range']); ?></td></tr>
                        <?php endif; ?>
                        <?php if ($battery['communication']): ?>
                        <tr><td>Communication</td><td><?php echo htmlspecialchars($battery['communication']); ?></td></tr>
                        <?php endif; ?>
                        <?php if ($battery['certifications']): ?>
                        <tr><td>Certifications</td><td><?php echo htmlspecialchars($battery['certifications']); ?></td></tr>
                        <?php endif; ?>
                        <?php if ($battery['country_origin']): ?>
                        <tr>
                            <td>Country of Origin</td>
                            <td>
                                <?php if ($flagRow || $flag_emoji): ?><?= get_country_flag($flagRow ?? $battery['country_origin'], 20) ?> <?php endif; ?>
                                <?php echo htmlspecialchars($battery['country_origin']); ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if ($battery['pinpoints']): ?>
                        <tr><td>Notes / Highlights</td><td><?php echo htmlspecialchars($battery['pinpoints']); ?></td></tr>
                        <?php endif; ?>
                        <tr>
                            <td><strong>Price</strong></td>
                            <td>
                                <span class="spec-amber"><?php echo htmlspecialchars($currency_symbol); ?><?php echo number_format($local_price); ?></span>
                                <?php if ($currency_code !== 'USD'): ?>
                                    <span style="font-size:0.82rem;color:#94A3B8;margin-left:8px;">($<?php echo number_format($battery['price_usd']); ?> USD)</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div><!-- /#batt-panel-specs -->

            <!-- ── Features Tab ── -->
            <div id="batt-panel-features" class="batt-tab-panel" role="tabpanel">
                <h3 style="font-size:1.2rem;font-weight:800;color:#1E293B;margin:0 0 20px;">Key Features</h3>
                <ul class="batt-features-list">
                    <?php if ($battery['type']): ?>
                    <li><span class="fcheck">&#10003;</span><?php echo htmlspecialchars($battery['type']); ?> battery technology</li>
                    <?php endif; ?>
                    <li><span class="fcheck">&#10003;</span><?php echo htmlspecialchars($battery['nominal_voltage']); ?>V / <?php echo number_format($battery['capacity_ah']); ?> Ah &mdash; <?php echo number_format($kwh, 2); ?> kWh usable energy</li>
                    <?php if ($battery['is_bms'] === 'Yes'): ?>
                    <li><span class="fcheck">&#10003;</span>Integrated Battery Management System (BMS) for protection and longevity</li>
                    <?php endif; ?>
                    <?php if ($battery['cycle_life']): ?>
                    <li><span class="fcheck">&#10003;</span><?php echo number_format($battery['cycle_life']); ?>+ charge cycles rated lifespan</li>
                    <?php endif; ?>
                    <?php if ($battery['depth_of_discharge']): ?>
                    <li><span class="fcheck">&#10003;</span><?php echo htmlspecialchars($battery['depth_of_discharge']); ?>% depth of discharge &mdash; maximise usable capacity</li>
                    <?php endif; ?>
                    <?php if ($battery['warranty_years']): ?>
                    <li><span class="fcheck">&#10003;</span><?php echo (int)$battery['warranty_years']; ?> year manufacturer warranty</li>
                    <?php endif; ?>
                    <?php if (!empty($battery['maintenance_free'])): ?>
                    <li><span class="fcheck">&#10003;</span>Maintenance-free sealed design</li>
                    <?php endif; ?>
                    <?php if ($battery['temperature_range']): ?>
                    <li><span class="fcheck">&#10003;</span>Operating temperature range: <?php echo htmlspecialchars($battery['temperature_range']); ?></li>
                    <?php endif; ?>
                    <?php if ($battery['communication']): ?>
                    <li><span class="fcheck">&#10003;</span><?php echo htmlspecialchars($battery['communication']); ?> communication interface for remote monitoring</li>
                    <?php endif; ?>
                    <?php if ($battery['certifications']): ?>
                    <li><span class="fcheck">&#10003;</span>Certified: <?php echo htmlspecialchars($battery['certifications']); ?></li>
                    <?php endif; ?>
                    <?php if ($battery['charging_current_max']): ?>
                    <li><span class="fcheck">&#10003;</span>Supports up to <?php echo htmlspecialchars($battery['charging_current_max']); ?>A charging current</li>
                    <?php endif; ?>
                    <?php if ($battery['notes']): ?>
                    <li><span class="fcheck">&#10003;</span><?php echo htmlspecialchars($battery['notes']); ?></li>
                    <?php endif; ?>
                </ul>
            </div><!-- /#batt-panel-features -->

            <!-- ── Where to Buy Tab ── -->
            <div id="batt-panel-dealers" class="batt-tab-panel" role="tabpanel">
                <h3 style="font-size:1.2rem;font-weight:800;color:#1E293B;margin:0 0 6px;">Where to Buy</h3>
                <p style="font-size:0.88rem;color:#64748B;margin:0 0 24px;">Authorised dealers near you stocking this battery.</p>

                <?php if (!empty($dealers)): ?>
                <div class="batt-dealers-grid">
                    <?php foreach ($dealers as $dealer):
                        $dealer_local_price = $dealer['dealer_price'] ? toLocal($dealer['dealer_price'], $exchange_rate) : null;
                        $dist = round($dealer['distance_km'], 1);
                    ?>
                    <div class="batt-dealer-card">
                        <div class="batt-dealer-name"><?php echo htmlspecialchars($dealer['business_name']); ?></div>
                        <div class="batt-dealer-city">
                            <?php echo htmlspecialchars($dealer['city'] . ($dealer['country_code'] ? ', ' . $dealer['country_code'] : '')); ?>
                        </div>
                        <span class="batt-distance-badge">&#128205; <?php echo number_format($dist, 1); ?> km away</span>
                        <?php if ($dealer_local_price): ?>
                            <span class="batt-dealer-price"><?php echo htmlspecialchars($currency_symbol); ?><?php echo number_format($dealer_local_price); ?></span>
                            <?php if ($currency_code !== 'USD' && $dealer['dealer_price']): ?>
                                <span class="batt-dealer-price-usd">$<?php echo number_format($dealer['dealer_price']); ?> USD</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="batt-dealer-price" style="font-size:0.85rem;color:#64748B;font-weight:500;">Price on request</span>
                        <?php endif; ?>
                        <a href="<?php echo BASE_URL; ?>store-detail.php?id=<?php echo (int)$dealer['id']; ?>" class="batt-visit-btn">
                            Visit Store &#8594;
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>

                <?php elseif ($user_lat !== null): ?>
                <div class="batt-no-dealers">
                    <div class="icon">&#128205;</div>
                    <h3>No nearby dealers found</h3>
                    <p>No authorised dealers stocking this battery were found near your location.<br>
                       <a href="<?php echo BASE_URL; ?>find-dealer.php" style="color:#F59E0B;font-weight:600;">Browse all dealers</a>
                       or <a href="<?php echo BASE_URL; ?>contact.php" style="color:#F59E0B;font-weight:600;">contact us</a> to find a supplier.</p>
                </div>

                <?php else: ?>
                <div class="batt-no-dealers">
                    <div class="icon">&#128205;</div>
                    <h3>Enable location to see nearby dealers</h3>
                    <p>Allow location access in your browser so we can show you the closest stocking dealers, or
                       <a href="<?php echo BASE_URL; ?>find-dealer.php" style="color:#F59E0B;font-weight:600;">browse all dealers</a>.</p>
                </div>
                <?php endif; ?>
            </div><!-- /#batt-panel-dealers -->

            <!-- ── About Brand Tab ── -->
            <div id="batt-panel-brand" class="batt-tab-panel" role="tabpanel">
                <div class="batt-brand-card">
                    <div class="batt-brand-logo-box">
                        <?php if (!empty($battery['company_logo'])): ?>
                            <img src="<?php echo htmlspecialchars(get_image_url($battery['company_logo'])); ?>"
                                 alt="<?php echo htmlspecialchars($battery['company_name']); ?> logo" loading="lazy">
                        <?php else: ?>
                            <span style="font-size:2rem;color:#94A3B8;">&#128267;</span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="batt-brand-name"><?php echo htmlspecialchars($battery['company_name']); ?></div>
                        <?php if ($battery['country']): ?>
                        <div class="batt-brand-meta">
                            <?php if ($flagRow || $flag_emoji): ?><?= get_country_flag($flagRow ?? $battery['country_origin'], 20) ?> <?php endif; ?>
                            <?php echo htmlspecialchars($battery['country']); ?>
                        </div>
                        <?php endif; ?>
                        <?php if ($battery['company_description']): ?>
                        <p class="batt-brand-desc"><?php echo htmlspecialchars($battery['company_description']); ?></p>
                        <?php endif; ?>
                        <?php if (!empty($battery['company_website'])): ?>
                        <a href="<?php echo htmlspecialchars($battery['company_website']); ?>"
                           class="batt-brand-link" target="_blank" rel="noopener noreferrer">
                            &#127760; Visit Official Website &#8599;
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div><!-- /#batt-panel-brand -->

        </div><!-- /.batt-tabs -->

        <!-- ═══ SIMILAR BATTERIES ════════════════════════════════════════════ -->
        <?php if (!empty($similar)): ?>
        <div class="similar-section">
            <h2>Similar Batteries</h2>
            <div class="similar-grid">
                <?php foreach ($similar as $item):
                    $item_local = toLocal($item['price_usd'], $exchange_rate);
                    $item_kwh   = ($item['capacity_ah'] * $item['voltage']) / 1000;
                ?>
                <div class="similar-card">
                    <?php if ($item['battery_type']): ?>
                    <span class="similar-type-badge"><?php echo htmlspecialchars($item['battery_type']); ?></span>
                    <?php endif; ?>
                    <div class="similar-brand"><?php echo htmlspecialchars($item['company_name']); ?></div>
                    <div class="similar-name"><?php echo htmlspecialchars($item['name']); ?></div>
                    <div class="similar-specs">
                        <span class="similar-spec"><strong><?php echo htmlspecialchars($item['voltage']); ?>V</strong></span>
                        <span class="similar-spec"><strong><?php echo number_format($item['capacity_ah']); ?></strong> Ah</span>
                        <span class="similar-spec"><strong><?php echo number_format($item_kwh, 1); ?></strong> kWh</span>
                    </div>
                    <div class="similar-price">
                        <?php echo htmlspecialchars($currency_symbol); ?><?php echo number_format($item_local); ?>
                        <?php if ($currency_code !== 'USD'): ?>
                            <span class="usd">$<?php echo number_format($item['price_usd']); ?> USD</span>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo BASE_URL; ?>battery-detail.php?id=<?php echo (int)$item['id']; ?>" class="similar-btn">
                        View Details &#8594;
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </div><!-- /.batt-content -->

    <?php renderAds('footer'); ?>

    <?php include 'includes/footer.php'; ?>

    <script src="assets/js/products.js"></script>
    <script>
    function switchBattTab(panelId, btn) {
        document.querySelectorAll('.batt-tab-panel').forEach(function(p) {
            p.classList.remove('active');
        });
        document.querySelectorAll('.batt-tab-btn').forEach(function(b) {
            b.classList.remove('active');
            b.setAttribute('aria-selected', 'false');
        });
        var panel = document.getElementById('batt-panel-' + panelId);
        if (panel) panel.classList.add('active');
        if (btn)   { btn.classList.add('active'); btn.setAttribute('aria-selected', 'true'); }
    }
    </script>
</body>
</html>
