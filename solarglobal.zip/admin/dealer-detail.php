<?php
/**
 * Admin - Dealer Detail Page
 * View full dealer profile, products, reviews, orders, and statistics
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = getDB();
$dealer_id = (int)($_GET['id'] ?? 0);
$success = '';
$error = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';

    if ($action === 'approve_review') {
        $review_id = (int)($_POST['review_id'] ?? 0);
        if ($review_id) {
            $db->prepare("UPDATE dealer_reviews SET status = 'approved' WHERE id = ? AND dealer_id = ?")
               ->execute([$review_id, $dealer_id]);
            // Update dealer avg rating and total reviews
            $db->prepare("UPDATE dealers SET
                avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM dealer_reviews WHERE dealer_id = ? AND status = 'approved'),
                total_reviews = (SELECT COUNT(*) FROM dealer_reviews WHERE dealer_id = ? AND status = 'approved')
                WHERE id = ?")->execute([$dealer_id, $dealer_id, $dealer_id]);
            $success = 'Review approved.';
        }
    } elseif ($action === 'reject_review') {
        $review_id = (int)($_POST['review_id'] ?? 0);
        if ($review_id) {
            $db->prepare("UPDATE dealer_reviews SET status = 'rejected' WHERE id = ? AND dealer_id = ?")
               ->execute([$review_id, $dealer_id]);
            $db->prepare("UPDATE dealers SET
                avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM dealer_reviews WHERE dealer_id = ? AND status = 'approved'),
                total_reviews = (SELECT COUNT(*) FROM dealer_reviews WHERE dealer_id = ? AND status = 'approved')
                WHERE id = ?")->execute([$dealer_id, $dealer_id, $dealer_id]);
            $success = 'Review rejected.';
        }
    } elseif ($action === 'approve_dealer') {
        $db->prepare("UPDATE dealers SET status = 'approved', approved_by = ?, approved_at = NOW() WHERE id = ?")
           ->execute([$_SESSION['admin_id'], $dealer_id]);
        $success = 'Dealer approved!';
    } elseif ($action === 'suspend_dealer') {
        $db->prepare("UPDATE dealers SET status = 'suspended' WHERE id = ?")->execute([$dealer_id]);
        $success = 'Dealer suspended.';
    } elseif ($action === 'activate_dealer') {
        $db->prepare("UPDATE dealers SET status = 'active' WHERE id = ?")->execute([$dealer_id]);
        $success = 'Dealer activated.';
    }
}

// Fetch dealer
$stmt = $db->prepare("SELECT * FROM dealers WHERE id = ?");
$stmt->execute([$dealer_id]);
$dealer = $stmt->fetch();

if (!$dealer) {
    $pageTitle = 'Dealer Not Found';
    include __DIR__ . '/includes/header.php';
    ?>
    <div class="content-wrapper" style="padding: 24px;">
        <div style="background:white; border-radius:12px; padding:60px 24px; text-align:center; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
            <div style="font-size:3rem; margin-bottom:16px;">&#128683;</div>
            <h2 style="color:#1E293B; margin-bottom:8px;">Dealer Not Found</h2>
            <p style="color:#64748B; margin-bottom:24px;">The dealer you are looking for does not exist or has been removed.</p>
            <a href="dealers.php" style="display:inline-block; padding:10px 24px; background:#1565C0; color:white; text-decoration:none; border-radius:8px; font-weight:600; font-size:0.875rem;">&larr; Back to Dealers</a>
        </div>
    </div>
    <?php
    include __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = "Dealer: " . $dealer['business_name'];

// Fetch products by type
$product_types = [
    'inverter' => ['table' => 'inverters', 'label' => 'Inverters', 'name_expr' => "CONCAT(COALESCE(t.company, t.brand, ''), ' ', t.model)"],
    'battery'  => ['table' => 'batteries', 'label' => 'Batteries', 'name_expr' => "CONCAT(COALESCE(t.brand, ''), ' ', t.model)"],
    'panel'    => ['table' => 'panels', 'label' => 'Panels', 'name_expr' => "CONCAT(COALESCE(t.brand, ''), ' ', t.name)"],
    'installation_appliance' => ['table' => 'installation_appliances', 'label' => 'Installation', 'name_expr' => "CONCAT(COALESCE(t.brand, 'Generic'), ' ', t.name)"],
];

$products_by_type = [];
$product_counts = [];
foreach ($product_types as $type_key => $type_info) {
    $stmt = $db->prepare("
        SELECT dp.id, dp.product_type, dp.product_id, dp.dealer_price, dp.original_price,
               dp.stock_quantity, dp.stock_status, dp.is_active,
               {$type_info['name_expr']} AS product_name
        FROM dealer_products dp
        JOIN {$type_info['table']} t ON t.id = dp.product_id
        WHERE dp.dealer_id = ? AND dp.product_type = ?
        ORDER BY dp.is_active DESC, dp.updated_at DESC
    ");
    $stmt->execute([$dealer_id, $type_key]);
    $products_by_type[$type_key] = $stmt->fetchAll();
    $product_counts[$type_key] = count($products_by_type[$type_key]);
}
$total_products = array_sum($product_counts);

// Fetch reviews
$stmt = $db->prepare("
    SELECT r.*, c.name AS customer_name
    FROM dealer_reviews r
    LEFT JOIN customers c ON c.id = r.customer_id
    WHERE r.dealer_id = ?
    ORDER BY r.created_at DESC
    LIMIT 50
");
$stmt->execute([$dealer_id]);
$reviews = $stmt->fetchAll();

// Fetch orders
$stmt = $db->prepare("
    SELECT o.*, c.name AS customer_name,
        (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) AS items_count
    FROM orders o
    LEFT JOIN customers c ON c.id = o.customer_id
    WHERE o.dealer_id = ?
    ORDER BY o.created_at DESC
    LIMIT 100
");
$stmt->execute([$dealer_id]);
$orders = $stmt->fetchAll();

// Stats
$stmt = $db->prepare("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE dealer_id = ? AND status IN ('confirmed', 'ready', 'picked_up')");
$stmt->execute([$dealer_id]);
$total_revenue = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT status, COUNT(*) AS cnt FROM orders WHERE dealer_id = ? GROUP BY status");
$stmt->execute([$dealer_id]);
$order_status_counts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
$total_orders = array_sum($order_status_counts);

// Status colors
$status_colors = [
    'pending'   => ['bg' => '#FEF3C7', 'color' => '#92400E'],
    'approved'  => ['bg' => '#DBEAFE', 'color' => '#1E40AF'],
    'active'    => ['bg' => '#DCFCE7', 'color' => '#166534'],
    'suspended' => ['bg' => '#FEE2E2', 'color' => '#991B1B'],
    'rejected'  => ['bg' => '#F1F5F9', 'color' => '#475569'],
];
$sc = $status_colors[$dealer['status']] ?? $status_colors['pending'];

include __DIR__ . '/includes/header.php';
?>

<div class="content-wrapper" style="padding: 24px;">

    <!-- Top section: Back link, name, status, actions -->
    <div style="margin-bottom:24px;">
        <a href="dealers.php" style="color:#1565C0; text-decoration:none; font-size:0.875rem; font-weight:500;">&larr; Back to Dealers</a>
    </div>

    <?php if ($success): ?>
        <div style="background:#DCFCE7; color:#166534; padding:12px 16px; border-radius:8px; margin-bottom:16px; font-size:0.875rem;">
            <?= sanitize($success) ?>
        </div>
    <?php endif; ?>

    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:24px;">
        <div style="display:flex; align-items:center; gap:12px;">
            <h2 style="font-size:1.5rem; color:#1E293B; margin:0;"><?= sanitize($dealer['business_name']) ?></h2>
            <span style="display:inline-block; padding:4px 14px; border-radius:6px; font-size:0.75rem; font-weight:600; background:<?= $sc['bg'] ?>; color:<?= $sc['color'] ?>;">
                <?= ucfirst($dealer['status']) ?>
            </span>
        </div>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
            <?php if ($dealer['status'] === 'pending'): ?>
                <form method="POST" style="display:inline;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="approve_dealer">
                    <button type="submit" style="padding:8px 18px; background:#16A34A; color:white; border:none; border-radius:6px; font-size:0.8125rem; font-weight:600; cursor:pointer;">Approve</button>
                </form>
            <?php elseif (in_array($dealer['status'], ['active', 'approved'])): ?>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Suspend this dealer?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="suspend_dealer">
                    <button type="submit" style="padding:8px 18px; background:#F59E0B; color:white; border:none; border-radius:6px; font-size:0.8125rem; font-weight:600; cursor:pointer;">Suspend</button>
                </form>
            <?php elseif ($dealer['status'] === 'suspended'): ?>
                <form method="POST" style="display:inline;">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="activate_dealer">
                    <button type="submit" style="padding:8px 18px; background:#16A34A; color:white; border:none; border-radius:6px; font-size:0.8125rem; font-weight:600; cursor:pointer;">Reactivate</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Stats Cards Row -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:16px; margin-bottom:24px;">
        <div style="background:white; border-radius:12px; padding:20px; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
            <div style="font-size:0.8125rem; color:#64748B; margin-bottom:4px;">Total Products</div>
            <div style="font-size:1.75rem; font-weight:700; color:#1E293B;"><?= $total_products ?></div>
        </div>
        <div style="background:white; border-radius:12px; padding:20px; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
            <div style="font-size:0.8125rem; color:#64748B; margin-bottom:4px;">Total Orders</div>
            <div style="font-size:1.75rem; font-weight:700; color:#1E293B;"><?= $total_orders ?></div>
        </div>
        <div style="background:white; border-radius:12px; padding:20px; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
            <div style="font-size:0.8125rem; color:#64748B; margin-bottom:4px;">Total Revenue</div>
            <div style="font-size:1.75rem; font-weight:700; color:#16A34A;"><?= $dealer['currency'] ?? 'USD' ?> <?= number_format($total_revenue, 2) ?></div>
        </div>
        <div style="background:white; border-radius:12px; padding:20px; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
            <div style="font-size:0.8125rem; color:#64748B; margin-bottom:4px;">Average Rating</div>
            <div style="font-size:1.75rem; font-weight:700; color:#F59E0B;"><?= number_format($dealer['avg_rating'] ?? 0, 1) ?> &#9733;</div>
        </div>
        <div style="background:white; border-radius:12px; padding:20px; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
            <div style="font-size:0.8125rem; color:#64748B; margin-bottom:4px;">Total Reviews</div>
            <div style="font-size:1.75rem; font-weight:700; color:#1E293B;"><?= (int)($dealer['total_reviews'] ?? 0) ?></div>
        </div>
    </div>

    <!-- Dealer Info Card -->
    <div style="background:white; border-radius:12px; padding:24px; box-shadow:0 2px 8px rgba(0,0,0,0.04); margin-bottom:24px;">
        <h3 style="font-size:1.125rem; color:#1E293B; margin-bottom:20px;">Dealer Information</h3>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:32px;">
            <!-- Left: Business details -->
            <div>
                <table style="width:100%; border-collapse:collapse;">
                    <?php
                    $info_rows = [
                        'Business Name' => $dealer['business_name'],
                        'Owner Name'    => $dealer['owner_name'],
                        'Email'         => $dealer['email'],
                        'Phone'         => $dealer['phone'] ?? '-',
                        'Address'       => $dealer['address'] ?? '-',
                        'City'          => $dealer['city'] ?? '-',
                        'Country'       => $dealer['country_code'] ?? '-',
                        'Subscription'  => ucfirst($dealer['subscription_status'] ?? 'none'),
                        'Joined'        => date('M d, Y', strtotime($dealer['created_at'])),
                    ];
                    foreach ($info_rows as $label => $value): ?>
                        <tr>
                            <td style="padding:8px 12px 8px 0; font-size:0.8125rem; color:#64748B; font-weight:500; white-space:nowrap; vertical-align:top;"><?= $label ?></td>
                            <td style="padding:8px 0; font-size:0.875rem; color:#1E293B; word-break:break-word;"><?= sanitize($value) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
            <!-- Right: Logo + Map -->
            <div style="display:flex; flex-direction:column; gap:16px; align-items:center;">
                <?php if (!empty($dealer['logo_path'])): ?>
                    <div>
                        <img src="<?= get_image_url($dealer['logo_path']) ?>" alt="Dealer Logo"
                             style="max-width:160px; max-height:120px; border-radius:8px; border:1px solid #E2E8F0; object-fit:contain;">
                    </div>
                <?php else: ?>
                    <div style="width:160px; height:120px; background:#F1F5F9; border-radius:8px; display:flex; align-items:center; justify-content:center; color:#94A3B8; font-size:0.8125rem;">
                        No Logo
                    </div>
                <?php endif; ?>

                <?php if (!empty($dealer['latitude']) && !empty($dealer['longitude'])): ?>
                    <div style="width:100%; max-width:300px;">
                        <img src="https://maps.googleapis.com/maps/api/staticmap?center=<?= $dealer['latitude'] ?>,<?= $dealer['longitude'] ?>&zoom=13&size=300x180&markers=color:red%7C<?= $dealer['latitude'] ?>,<?= $dealer['longitude'] ?>&key="
                             alt="Map Location" style="width:100%; border-radius:8px; border:1px solid #E2E8F0;">
                        <div style="font-size:0.75rem; color:#64748B; margin-top:4px; text-align:center;">
                            <?= $dealer['latitude'] ?>, <?= $dealer['longitude'] ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div style="width:100%; max-width:300px; height:100px; background:#F1F5F9; border-radius:8px; display:flex; align-items:center; justify-content:center; color:#94A3B8; font-size:0.8125rem;">
                        No location data
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Products Section (Tabbed) -->
    <div style="background:white; border-radius:12px; box-shadow:0 2px 8px rgba(0,0,0,0.04); margin-bottom:24px; overflow:hidden;">
        <div style="padding:20px 24px 0;">
            <h3 style="font-size:1.125rem; color:#1E293B; margin-bottom:16px;">Products</h3>
            <div style="display:flex; gap:4px; border-bottom:2px solid #E2E8F0;" id="product-tabs">
                <?php $first = true; foreach ($product_types as $type_key => $type_info): ?>
                    <button onclick="showProductTab('<?= $type_key ?>')"
                            id="tab-<?= $type_key ?>"
                            style="padding:10px 20px; font-size:0.8125rem; font-weight:600; border:none; background:none; cursor:pointer; border-bottom:2px solid <?= $first ? '#1565C0' : 'transparent' ?>; margin-bottom:-2px; color:<?= $first ? '#1565C0' : '#64748B' ?>;">
                        <?= $type_info['label'] ?> (<?= $product_counts[$type_key] ?>)
                    </button>
                <?php $first = false; endforeach; ?>
            </div>
        </div>
        <div style="padding:0 24px 24px;">
            <?php $first = true; foreach ($product_types as $type_key => $type_info): ?>
                <div id="products-<?= $type_key ?>" style="display:<?= $first ? 'block' : 'none' ?>;">
                    <?php if (empty($products_by_type[$type_key])): ?>
                        <div style="padding:40px 0; text-align:center; color:#94A3B8; font-size:0.875rem;">
                            No <?= strtolower($type_info['label']) ?> listed.
                        </div>
                    <?php else: ?>
                        <table style="width:100%; border-collapse:collapse; margin-top:16px;">
                            <thead>
                                <tr style="background:#F8FAFC;">
                                    <th style="padding:10px 12px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Product Name</th>
                                    <th style="padding:10px 12px; text-align:right; font-size:0.8125rem; color:#64748B; font-weight:600;">Dealer Price</th>
                                    <th style="padding:10px 12px; text-align:right; font-size:0.8125rem; color:#64748B; font-weight:600;">Original Price</th>
                                    <th style="padding:10px 12px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Stock</th>
                                    <th style="padding:10px 12px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($products_by_type[$type_key] as $p):
                                    $stock_colors = [
                                        'in_stock'     => ['bg' => '#DCFCE7', 'color' => '#166534'],
                                        'low_stock'    => ['bg' => '#FEF3C7', 'color' => '#92400E'],
                                        'out_of_stock' => ['bg' => '#FEE2E2', 'color' => '#991B1B'],
                                    ];
                                    $stc = $stock_colors[$p['stock_status']] ?? $stock_colors['in_stock'];
                                ?>
                                    <tr style="border-bottom:1px solid #F1F5F9;">
                                        <td style="padding:12px; font-size:0.875rem; color:#1E293B;">
                                            <?= sanitize($p['product_name'] ?? 'Unknown') ?>
                                            <?php if (!$p['is_active']): ?>
                                                <span style="font-size:0.6875rem; color:#94A3B8; margin-left:6px;">(Inactive)</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="padding:12px; font-size:0.875rem; color:#1E293B; text-align:right; font-weight:600;">
                                            <?= number_format($p['dealer_price'], 2) ?>
                                        </td>
                                        <td style="padding:12px; font-size:0.875rem; color:#64748B; text-align:right;">
                                            <?= $p['original_price'] ? number_format($p['original_price'], 2) : '-' ?>
                                        </td>
                                        <td style="padding:12px; text-align:center; font-size:0.875rem; font-weight:600; color:#1E293B;">
                                            <?= (int)$p['stock_quantity'] ?>
                                        </td>
                                        <td style="padding:12px; text-align:center;">
                                            <span style="display:inline-block; padding:3px 10px; border-radius:6px; font-size:0.6875rem; font-weight:600; background:<?= $stc['bg'] ?>; color:<?= $stc['color'] ?>;">
                                                <?= ucwords(str_replace('_', ' ', $p['stock_status'])) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            <?php $first = false; endforeach; ?>
        </div>
    </div>

    <!-- Reviews Section -->
    <div style="background:white; border-radius:12px; padding:24px; box-shadow:0 2px 8px rgba(0,0,0,0.04); margin-bottom:24px;">
        <h3 style="font-size:1.125rem; color:#1E293B; margin-bottom:16px;">Reviews (<?= count($reviews) ?>)</h3>
        <?php if (empty($reviews)): ?>
            <div style="padding:40px 0; text-align:center; color:#94A3B8; font-size:0.875rem;">No reviews yet.</div>
        <?php else: ?>
            <div style="display:flex; flex-direction:column; gap:12px;">
                <?php foreach ($reviews as $r):
                    $review_status_colors = [
                        'pending'  => ['bg' => '#FEF3C7', 'color' => '#92400E'],
                        'approved' => ['bg' => '#DCFCE7', 'color' => '#166534'],
                        'rejected' => ['bg' => '#FEE2E2', 'color' => '#991B1B'],
                    ];
                    $rsc = $review_status_colors[$r['status']] ?? $review_status_colors['pending'];
                ?>
                    <div style="border:1px solid #E2E8F0; border-radius:8px; padding:16px;">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px; flex-wrap:wrap;">
                            <div>
                                <div style="color:#F59E0B; font-size:1rem; margin-bottom:4px;">
                                    <?= str_repeat('&#9733;', (int)$r['rating']) ?><?= str_repeat('&#9734;', 5 - (int)$r['rating']) ?>
                                </div>
                                <div style="font-size:0.875rem; color:#1E293B; margin-bottom:6px;">
                                    <?= sanitize($r['review_text'] ?? '') ?>
                                </div>
                                <div style="font-size:0.75rem; color:#94A3B8;">
                                    By <?= sanitize($r['customer_name'] ?? 'Unknown') ?> &middot; <?= date('M d, Y', strtotime($r['created_at'])) ?>
                                </div>
                            </div>
                            <div style="display:flex; align-items:center; gap:8px; flex-shrink:0;">
                                <span style="display:inline-block; padding:3px 10px; border-radius:6px; font-size:0.6875rem; font-weight:600; background:<?= $rsc['bg'] ?>; color:<?= $rsc['color'] ?>;">
                                    <?= ucfirst($r['status']) ?>
                                </span>
                                <?php if ($r['status'] === 'pending'): ?>
                                    <form method="POST" style="display:inline;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="approve_review">
                                        <input type="hidden" name="review_id" value="<?= $r['id'] ?>">
                                        <button type="submit" style="padding:4px 10px; background:#16A34A; color:white; border:none; border-radius:4px; font-size:0.6875rem; font-weight:600; cursor:pointer;">Approve</button>
                                    </form>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Reject this review?')">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="reject_review">
                                        <input type="hidden" name="review_id" value="<?= $r['id'] ?>">
                                        <button type="submit" style="padding:4px 10px; background:#DC2626; color:white; border:none; border-radius:4px; font-size:0.6875rem; font-weight:600; cursor:pointer;">Reject</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Orders Section -->
    <div style="background:white; border-radius:12px; box-shadow:0 2px 8px rgba(0,0,0,0.04); margin-bottom:24px; overflow:hidden;">
        <div style="padding:20px 24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                <h3 style="font-size:1.125rem; color:#1E293B;">Orders (<?= $total_orders ?>)</h3>
                <?php if (!empty($order_status_counts)): ?>
                    <div style="display:flex; gap:8px; flex-wrap:wrap;">
                        <?php
                        $order_sc = [
                            'pending'   => '#F59E0B',
                            'confirmed' => '#1565C0',
                            'ready'     => '#7C3AED',
                            'picked_up' => '#16A34A',
                            'cancelled' => '#DC2626',
                        ];
                        foreach ($order_status_counts as $os => $oc): ?>
                            <span style="font-size:0.75rem; color:<?= $order_sc[$os] ?? '#64748B' ?>; font-weight:600;">
                                <?= ucfirst($os) ?>: <?= $oc ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php if (empty($orders)): ?>
            <div style="padding:20px 24px 40px; text-align:center; color:#94A3B8; font-size:0.875rem;">No orders yet.</div>
        <?php else: ?>
            <table style="width:100%; border-collapse:collapse;">
                <thead>
                    <tr style="background:#F8FAFC;">
                        <th style="padding:10px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Order #</th>
                        <th style="padding:10px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Customer</th>
                        <th style="padding:10px 16px; text-align:right; font-size:0.8125rem; color:#64748B; font-weight:600;">Total</th>
                        <th style="padding:10px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Items</th>
                        <th style="padding:10px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Status</th>
                        <th style="padding:10px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $o):
                        $os_colors = [
                            'pending'   => ['bg' => '#FEF3C7', 'color' => '#92400E'],
                            'confirmed' => ['bg' => '#DBEAFE', 'color' => '#1E40AF'],
                            'ready'     => ['bg' => '#EDE9FE', 'color' => '#5B21B6'],
                            'picked_up' => ['bg' => '#DCFCE7', 'color' => '#166534'],
                            'cancelled' => ['bg' => '#FEE2E2', 'color' => '#991B1B'],
                        ];
                        $osc = $os_colors[$o['status']] ?? $os_colors['pending'];
                    ?>
                        <tr style="border-bottom:1px solid #F1F5F9;">
                            <td style="padding:12px 16px; font-size:0.875rem; color:#1E293B; font-weight:600;">
                                <?= sanitize($o['order_number']) ?>
                            </td>
                            <td style="padding:12px 16px; font-size:0.875rem; color:#475569;">
                                <?= sanitize($o['customer_name'] ?? 'Guest') ?>
                            </td>
                            <td style="padding:12px 16px; font-size:0.875rem; color:#1E293B; text-align:right; font-weight:600;">
                                <?= sanitize($o['currency'] ?? 'USD') ?> <?= number_format($o['total_amount'], 2) ?>
                            </td>
                            <td style="padding:12px 16px; text-align:center; font-size:0.875rem; color:#64748B;">
                                <?= (int)$o['items_count'] ?>
                            </td>
                            <td style="padding:12px 16px; text-align:center;">
                                <span style="display:inline-block; padding:3px 10px; border-radius:6px; font-size:0.6875rem; font-weight:600; background:<?= $osc['bg'] ?>; color:<?= $osc['color'] ?>;">
                                    <?= ucfirst(str_replace('_', ' ', $o['status'])) ?>
                                </span>
                            </td>
                            <td style="padding:12px 16px; font-size:0.8125rem; color:#64748B;">
                                <?= date('M d, Y', strtotime($o['created_at'])) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</div>

<script>
function showProductTab(type) {
    const types = ['inverter', 'battery', 'panel', 'installation_appliance'];
    types.forEach(function(t) {
        const panel = document.getElementById('products-' + t);
        const tab = document.getElementById('tab-' + t);
        if (panel) panel.style.display = (t === type) ? 'block' : 'none';
        if (tab) {
            tab.style.borderBottomColor = (t === type) ? '#1565C0' : 'transparent';
            tab.style.color = (t === type) ? '#1565C0' : '#64748B';
        }
    });
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
