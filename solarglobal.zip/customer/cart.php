<?php
/**
 * Customer Cart & Ordering
 * Browse dealer inventory, add to cart, place orders (grouped by dealer)
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/customer_auth.php';

set_security_headers();

// Login NOT required for browsing/adding to cart — only for placing orders
$is_logged_in = is_customer_logged_in();
$customer = $is_logged_in ? get_customer_profile() : null;
$db = getDB();

// Detect country for local currency
$country_code = 'US';
if (!empty($_COOKIE['sg_location'])) {
    $loc = json_decode($_COOKIE['sg_location'], true);
    if (!empty($loc['country_code'])) $country_code = strtoupper(substr($loc['country_code'], 0, 3));
}
$currency_info = get_country_currency_info($country_code);

/**
 * Look up the image for a product by type and ID
 */
function get_product_image($db, string $type, int $product_id): string {
    $table_map = ['inverter'=>'inverters','battery'=>'batteries','panel'=>'panels','installation_appliance'=>'installation_appliances'];
    $table = $table_map[$type] ?? null;
    if (!$table) return '';
    try {
        $stmt = $db->prepare("SELECT image_path FROM {$table} WHERE id = ?");
        $stmt->execute([$product_id]);
        $path = $stmt->fetchColumn();
        return $path ? get_image_url($path) : '';
    } catch (Exception $e) { return ''; }
}

$success = '';
$error = '';

// Cart is stored in session: $_SESSION['cart'] = [ dealer_id => [ items... ] ]
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

$dealer_id = (int)($_GET['dealer'] ?? $_POST['dealer_id'] ?? 0);

// Handle cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_to_cart') {
        $did = (int)($_POST['dealer_id'] ?? 0);
        $dp_id = (int)($_POST['dp_id'] ?? 0);
        $qty = max(1, (int)($_POST['quantity'] ?? 1));

        // Validate dealer product exists and is in stock
        $stmt = $db->prepare("SELECT dp.*, d.business_name,
                              CASE dp.product_type
                                  WHEN 'inverter' THEN (SELECT name FROM inverters WHERE id = dp.product_id)
                                  WHEN 'battery' THEN (SELECT name FROM batteries WHERE id = dp.product_id)
                                  WHEN 'panel' THEN (SELECT name FROM panels WHERE id = dp.product_id)
                                  WHEN 'installation_appliance' THEN (SELECT name FROM installation_appliances WHERE id = dp.product_id)
                              END as product_name
                              FROM dealer_products dp
                              JOIN dealers d ON dp.dealer_id = d.id
                              WHERE dp.id = ? AND dp.dealer_id = ? AND dp.is_active = 1 AND d.status = 'active'");
        $stmt->execute([$dp_id, $did]);
        $product = $stmt->fetch();

        if (!$product) {
            $error = 'Product not found.';
        } elseif ($product['stock_quantity'] < $qty) {
            $error = 'Only ' . $product['stock_quantity'] . ' available in stock.';
        } else {
            // Add to cart
            $cart_item = [
                'dp_id' => $dp_id,
                'product_type' => $product['product_type'],
                'product_id' => $product['product_id'],
                'product_name' => $product['product_name'],
                'dealer_price' => $product['dealer_price'],
                'quantity' => $qty,
                'max_stock' => $product['stock_quantity'],
            ];

            // Check if already in cart, update qty
            $found = false;
            if (isset($_SESSION['cart'][$did])) {
                foreach ($_SESSION['cart'][$did]['items'] as &$item) {
                    if ($item['dp_id'] === $dp_id) {
                        $item['quantity'] = min($item['quantity'] + $qty, $product['stock_quantity']);
                        $found = true;
                        break;
                    }
                }
                unset($item);
            }

            if (!$found) {
                if (!isset($_SESSION['cart'][$did])) {
                    $_SESSION['cart'][$did] = [
                        'dealer_name' => $product['business_name'],
                        'items' => []
                    ];
                }
                $_SESSION['cart'][$did]['items'][] = $cart_item;
            }
            $success = 'Added to cart!';
        }
    } elseif ($action === 'update_cart') {
        $did = (int)($_POST['dealer_id'] ?? 0);
        $dp_id = (int)($_POST['dp_id'] ?? 0);
        $qty = max(0, (int)($_POST['quantity'] ?? 0));

        if (isset($_SESSION['cart'][$did])) {
            if ($qty === 0) {
                // Remove item
                $_SESSION['cart'][$did]['items'] = array_values(array_filter(
                    $_SESSION['cart'][$did]['items'],
                    fn($item) => $item['dp_id'] !== $dp_id
                ));
                if (empty($_SESSION['cart'][$did]['items'])) unset($_SESSION['cart'][$did]);
            } else {
                foreach ($_SESSION['cart'][$did]['items'] as &$item) {
                    if ($item['dp_id'] === $dp_id) {
                        $item['quantity'] = min($qty, $item['max_stock']);
                        break;
                    }
                }
                unset($item);
            }
        }
        $success = 'Cart updated.';
    } elseif ($action === 'clear_cart') {
        $_SESSION['cart'] = [];
        $success = 'Cart cleared.';
    } elseif ($action === 'place_order') {
        if (!$is_logged_in) {
            $_SESSION['customer_redirect_after_login'] = '/solarglobal/customer/cart.php?view=cart';
            header('Location: /solarglobal/customer/login.php');
            exit();
        }
        $did = (int)($_POST['dealer_id'] ?? 0);
        $notes = trim($_POST['notes'] ?? '');

        if (!isset($_SESSION['cart'][$did]) || empty($_SESSION['cart'][$did]['items'])) {
            $error = 'Cart is empty for this dealer.';
        } else {
            try {
                $db->beginTransaction();

                $cart_items = $_SESSION['cart'][$did]['items'];
                $total = 0;
                $item_count = 0;

                // Verify stock availability
                foreach ($cart_items as $ci) {
                    $stmt = $db->prepare("SELECT stock_quantity, dealer_price FROM dealer_products WHERE id = ? AND is_active = 1 FOR UPDATE");
                    $stmt->execute([$ci['dp_id']]);
                    $dp = $stmt->fetch();
                    if (!$dp || $dp['stock_quantity'] < $ci['quantity']) {
                        throw new Exception("Insufficient stock for {$ci['product_name']}.");
                    }
                    $total += $dp['dealer_price'] * $ci['quantity'];
                    $item_count += $ci['quantity'];
                }

                // Generate order number
                $today = date('Ymd');
                $stmt = $db->prepare("SELECT COUNT(*) FROM orders WHERE order_number LIKE ?");
                $stmt->execute(["ORD-$today-%"]);
                $seq = $stmt->fetchColumn() + 1;
                $order_number = "ORD-$today-" . str_pad($seq, 4, '0', STR_PAD_LEFT);

                // Create order
                $pickup_deadline = date('Y-m-d H:i:s', time() + 86400); // 24 hours
                $stmt = $db->prepare("INSERT INTO orders (order_number, customer_id, dealer_id, status, total_amount, currency, item_count, notes, pickup_deadline)
                                      VALUES (?, ?, ?, 'pending', ?, 'USD', ?, ?, ?)");
                $stmt->execute([$order_number, $customer['id'], $did, $total, $item_count, $notes, $pickup_deadline]);
                $order_id = $db->lastInsertId();

                // Create order items and decrement stock
                foreach ($cart_items as $ci) {
                    $line_total = $ci['dealer_price'] * $ci['quantity'];
                    $stmt = $db->prepare("INSERT INTO order_items (order_id, product_type, product_id, product_name, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$order_id, $ci['product_type'], $ci['product_id'], $ci['product_name'], $ci['quantity'], $ci['dealer_price'], $line_total]);

                    // Decrement stock
                    $db->prepare("UPDATE dealer_products SET stock_quantity = GREATEST(0, stock_quantity - ?),
                                  stock_status = CASE WHEN stock_quantity - ? > 5 THEN 'in_stock' WHEN stock_quantity - ? > 0 THEN 'low_stock' ELSE 'out_of_stock' END
                                  WHERE id = ?")
                       ->execute([$ci['quantity'], $ci['quantity'], $ci['quantity'], $ci['dp_id']]);
                }

                $db->commit();

                // Notify dealer about the new order
                require_once __DIR__ . '/../includes/notification_helpers.php';
                create_notification('dealer', $did, 'order_placed',
                    'New Order #' . $order_number,
                    'A customer placed an order for ' . $item_count . ' items totaling $' . number_format($total, 2) . '.',
                    '/solarglobal/dealer/orders.php');

                // Clear cart for this dealer
                unset($_SESSION['cart'][$did]);
                $success = "Order $order_number placed! The dealer will confirm your order shortly.";
            } catch (Exception $e) {
                $db->rollBack();
                $error = 'Order failed: ' . $e->getMessage();
            }
        }
    }
}

// Determine view mode
$view = $_GET['view'] ?? 'browse'; // browse, cart

// If browsing dealer, fetch their inventory
$dealer_info = null;
$inventory = [];
if ($dealer_id > 0 && $view !== 'cart') {
    $stmt = $db->prepare("SELECT * FROM dealers WHERE id = ? AND status = 'active'");
    $stmt->execute([$dealer_id]);
    $dealer_info = $stmt->fetch();

    if ($dealer_info) {
        $type_filter = $_GET['type'] ?? '';
        $search = trim($_GET['q'] ?? '');

        $sql = "SELECT dp.*,
                CASE dp.product_type
                    WHEN 'inverter' THEN (SELECT name FROM inverters WHERE id = dp.product_id)
                    WHEN 'battery' THEN (SELECT name FROM batteries WHERE id = dp.product_id)
                    WHEN 'panel' THEN (SELECT name FROM panels WHERE id = dp.product_id)
                    WHEN 'installation_appliance' THEN (SELECT name FROM installation_appliances WHERE id = dp.product_id)
                END as product_name,
                CASE dp.product_type
                    WHEN 'inverter' THEN (SELECT brand FROM inverters WHERE id = dp.product_id)
                    WHEN 'battery' THEN (SELECT brand FROM batteries WHERE id = dp.product_id)
                    WHEN 'panel' THEN (SELECT brand FROM panels WHERE id = dp.product_id)
                    WHEN 'installation_appliance' THEN (SELECT brand FROM installation_appliances WHERE id = dp.product_id)
                END as brand
                FROM dealer_products dp
                WHERE dp.dealer_id = ? AND dp.is_active = 1";

        $params = [$dealer_id];
        if (in_array($type_filter, ['inverter', 'battery', 'panel', 'installation_appliance'])) {
            $sql .= " AND dp.product_type = ?";
            $params[] = $type_filter;
        }
        $sql .= " ORDER BY dp.product_type, dp.dealer_price ASC";

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $inventory = $stmt->fetchAll();

        // Apply search filter in PHP (product_name is subquery)
        if ($search) {
            $inventory = array_filter($inventory, fn($item) =>
                stripos($item['product_name'] ?? '', $search) !== false ||
                stripos($item['brand'] ?? '', $search) !== false
            );
            $inventory = array_values($inventory);
        }
    }
}

// Cart totals
$cart_total = 0;
$cart_count = 0;
foreach ($_SESSION['cart'] as $did_cart => $dealer_cart) {
    foreach ($dealer_cart['items'] as $item) {
        $cart_total += $item['dealer_price'] * $item['quantity'];
        $cart_count += $item['quantity'];
    }
}

$cs = $currency_info['currency_symbol'] ?? '$';
$is_local = ($country_code !== 'US');

$current_page = 'store';
$page_title = $view === 'cart' ? 'Shopping Cart' : ($dealer_info ? sanitize($dealer_info['business_name']) . ' - Store' : 'Browse Store');
require_once __DIR__ . '/../includes/header.php';
?>
    <style>
        .container { max-width: 1100px; margin: 20px auto; padding: 0 20px; }

        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; }
        .alert-success { background: #DCFCE7; color: #166534; }
        .alert-error { background: #FEF2F2; color: #991B1B; }

        /* Tabs */
        .tabs { display: flex; gap: 4px; margin-bottom: 16px; background: white; border-radius: 10px; padding: 4px; box-shadow: 0 1px 4px rgba(0,0,0,0.05); }
        .tab { flex: 1; padding: 10px; text-align: center; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 0.8125rem; color: #64748B; }
        .tab.active { background: #1565C0; color: white; }
        .tab:hover:not(.active) { background: #F1F5F9; }

        /* Search */
        .search-bar { display: flex; gap: 8px; margin-bottom: 16px; }
        .search-bar input { flex: 1; padding: 10px 14px; border: 2px solid #E2E8F0; border-radius: 8px; font-size: 0.875rem; font-family: inherit; }
        .search-bar input:focus { outline: none; border-color: #1565C0; }
        .search-bar button { padding: 10px 20px; background: #1565C0; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; }

        /* Product grid */
        .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 14px; }

        .product-card {
            background: white; border-radius: 10px; padding: 16px; border: 2px solid #E2E8F0; transition: all 0.2s;
        }
        .product-card:hover { border-color: #F59E0B; }
        .pc-brand { font-size: 0.6875rem; font-weight: 600; color: #1565C0; text-transform: uppercase; }
        .pc-name { font-size: 0.9375rem; font-weight: 700; color: #1E293B; margin: 4px 0; }
        .pc-type { font-size: 0.75rem; color: #64748B; background: #F1F5F9; display: inline-block; padding: 2px 8px; border-radius: 4px; margin-bottom: 8px; }
        .pc-price { font-size: 1.25rem; font-weight: 800; color: #059669; margin-bottom: 10px; }
        .pc-stock { font-size: 0.75rem; margin-bottom: 10px; }
        .pc-stock.in { color: #16A34A; }
        .pc-stock.low { color: #D97706; }
        .pc-stock.out { color: #DC2626; }

        .pc-add-form { display: flex; gap: 6px; align-items: center; }
        .pc-add-form input { width: 60px; padding: 6px 8px; border: 1px solid #E2E8F0; border-radius: 6px; text-align: center; font-size: 0.875rem; }
        .btn-add { padding: 6px 16px; background: #F59E0B; color: #1E293B; border: none; border-radius: 6px; font-weight: 700; font-size: 0.8125rem; cursor: pointer; }
        .btn-add:hover { background: #D97706; }

        /* Cart view */
        .cart-section { background: white; border-radius: 12px; padding: 20px; margin-bottom: 16px; box-shadow: 0 1px 4px rgba(0,0,0,0.05); }
        .cart-section-header { margin-bottom: 14px; padding-bottom: 10px; border-bottom: 1px solid #E2E8F0; }
        .cart-section-header h3 { font-size: 1rem; font-weight: 700; color: #1E293B; margin-bottom: 2px; }
        .cart-dealer-meta { font-size: 0.75rem; color: #64748B; }

        .cart-item { display: flex; align-items: center; padding: 12px 0; border-bottom: 1px solid #F1F5F9; gap: 14px; flex-wrap: wrap; }
        .cart-item:last-child { border-bottom: none; }

        .ci-thumb {
            width: 48px; height: 48px; border-radius: 8px; object-fit: cover; background: #F1F5F9; flex-shrink: 0;
            display: flex; align-items: center; justify-content: center; overflow: hidden;
        }
        .ci-thumb img { width: 100%; height: 100%; object-fit: cover; border-radius: 8px; }
        .ci-thumb-placeholder {
            width: 48px; height: 48px; border-radius: 8px; background: #F1F5F9;
            display: flex; align-items: center; justify-content: center; color: #94A3B8; font-size: 1.25rem; flex-shrink: 0;
        }

        .ci-info { flex: 1; min-width: 150px; }
        .ci-name { font-size: 0.875rem; font-weight: 600; color: #1E293B; }
        .ci-type { font-size: 0.6875rem; color: #64748B; }
        .ci-unit-price { font-size: 0.6875rem; color: #94A3B8; margin-top: 1px; }

        .ci-controls { display: flex; align-items: center; gap: 6px; }

        /* Quantity stepper */
        .qty-stepper { display: inline-flex; align-items: center; border: 1px solid #E2E8F0; border-radius: 8px; overflow: hidden; }
        .qty-stepper .qty-btn {
            width: 32px; height: 32px; background: #F8FAFC; border: none; cursor: pointer;
            font-size: 1rem; font-weight: 700; color: #475569; display: flex; align-items: center; justify-content: center;
            transition: background 0.15s;
        }
        .qty-stepper .qty-btn:hover { background: #E2E8F0; }
        .qty-stepper .qty-input {
            width: 44px; height: 32px; text-align: center; border: none; border-left: 1px solid #E2E8F0;
            border-right: 1px solid #E2E8F0; font-size: 0.8125rem; font-weight: 600; font-family: inherit;
            -moz-appearance: textfield; appearance: textfield;
        }
        .qty-stepper .qty-input::-webkit-inner-spin-button,
        .qty-stepper .qty-input::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }

        .ci-price { font-weight: 700; color: #059669; font-size: 0.9375rem; min-width: 90px; text-align: right; }
        .ci-price-local { font-size: 0.6875rem; color: #94A3B8; font-weight: 500; }
        .btn-remove { background: none; border: none; color: #DC2626; cursor: pointer; font-size: 0.75rem; font-weight: 600; padding: 4px 6px; border-radius: 4px; }
        .btn-remove:hover { background: #FEF2F2; }

        .cart-totals { text-align: right; margin-top: 12px; padding-top: 12px; border-top: 2px solid #E2E8F0; }
        .cart-totals .total-label { font-size: 0.875rem; color: #64748B; }
        .cart-totals .total-amount { font-size: 1.5rem; font-weight: 800; color: #1E293B; }
        .cart-totals .total-local { font-size: 0.8125rem; color: #64748B; font-weight: 500; }

        .order-notes { width: 100%; padding: 10px; border: 1px solid #E2E8F0; border-radius: 8px; font-size: 0.875rem; font-family: inherit; margin: 12px 0; resize: vertical; }

        .btn-order {
            padding: 14px 28px; background: #F59E0B; color: #1E293B; border: none; border-radius: 10px;
            font-weight: 700; font-size: 0.9375rem; cursor: pointer; width: 100%; transition: background 0.2s;
            letter-spacing: 0.01em;
        }
        .btn-order:hover { background: #D97706; }

        /* Grand total bar */
        .grand-total-bar {
            background: #0F172A; color: white; border-radius: 12px; padding: 20px 24px;
            display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;
            margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.12);
        }
        .grand-total-bar .gt-label { font-size: 0.875rem; color: #94A3B8; }
        .grand-total-bar .gt-amount { font-size: 1.75rem; font-weight: 800; }
        .grand-total-bar .gt-local { font-size: 0.875rem; color: #94A3B8; font-weight: 500; }
        .grand-total-bar .gt-meta { font-size: 0.8125rem; color: #64748B; }

        .empty-msg { text-align: center; padding: 40px; color: #64748B; }
        .empty-msg a { color: #1565C0; text-decoration: none; font-weight: 600; }
    </style>

    <div class="container">
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>

        <?php if ($view === 'cart'): ?>
            <!-- ==================== CART VIEW ==================== -->
            <?php if (empty($_SESSION['cart'])): ?>
                <div class="empty-msg">
                    <h3>Your cart is empty</h3>
                    <p><a href="/solarglobal/store.php">Find a dealer</a> and start browsing products.</p>
                </div>
            <?php else: ?>
                <?php
                $dealer_count = count($_SESSION['cart']);
                foreach ($_SESSION['cart'] as $did_cart => $dealer_cart):
                    // Look up dealer info for address/city
                    $dealer_info_stmt = $db->prepare("SELECT city, address, country_code FROM dealers WHERE id = ?");
                    $dealer_info_stmt->execute([$did_cart]);
                    $d_info = $dealer_info_stmt->fetch(PDO::FETCH_ASSOC);
                ?>
                    <div class="cart-section">
                        <div class="cart-section-header">
                            <h3>&#127979; <?= sanitize($dealer_cart['dealer_name']) ?></h3>
                            <?php if ($d_info): ?>
                                <div class="cart-dealer-meta">
                                    <?php
                                    $meta_parts = [];
                                    if (!empty($d_info['address'])) $meta_parts[] = sanitize($d_info['address']);
                                    if (!empty($d_info['city'])) $meta_parts[] = sanitize($d_info['city']);
                                    if (!empty($d_info['country_code'])) $meta_parts[] = strtoupper(sanitize($d_info['country_code']));
                                    echo implode(' &middot; ', $meta_parts);
                                    ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php
                        $dealer_total = 0;
                        foreach ($dealer_cart['items'] as $item):
                            $line = $item['dealer_price'] * $item['quantity'];
                            $dealer_total += $line;
                            $img_url = get_product_image($db, $item['product_type'], (int)$item['product_id']);
                        ?>
                            <div class="cart-item">
                                <?php if ($img_url): ?>
                                    <div class="ci-thumb"><img src="<?= sanitize($img_url) ?>" alt="<?= sanitize($item['product_name']) ?>"></div>
                                <?php else: ?>
                                    <div class="ci-thumb-placeholder">&#128247;</div>
                                <?php endif; ?>

                                <div class="ci-info">
                                    <div class="ci-name"><?= sanitize($item['product_name']) ?></div>
                                    <div class="ci-type"><?= ucfirst(str_replace('_', ' ', $item['product_type'])) ?></div>
                                    <div class="ci-unit-price">
                                        $<?= number_format($item['dealer_price'], 2) ?>/ea
                                        <?php if ($is_local): ?>
                                            &middot; <?= $cs ?><?= number_format(convert_usd_to_local($item['dealer_price'], $country_code), 2) ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="ci-controls">
                                    <form method="POST" style="display:inline-flex;align-items:center;gap:6px;" id="qty-form-<?= $item['dp_id'] ?>">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="update_cart">
                                        <input type="hidden" name="dealer_id" value="<?= $did_cart ?>">
                                        <input type="hidden" name="dp_id" value="<?= $item['dp_id'] ?>">
                                        <div class="qty-stepper">
                                            <button type="button" class="qty-btn" onclick="stepQty(this, -1)">&#8722;</button>
                                            <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['max_stock'] ?>" class="qty-input" onchange="this.form.submit()">
                                            <button type="button" class="qty-btn" onclick="stepQty(this, 1)">+</button>
                                        </div>
                                    </form>
                                    <form method="POST" style="display:inline;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="update_cart">
                                        <input type="hidden" name="dealer_id" value="<?= $did_cart ?>">
                                        <input type="hidden" name="dp_id" value="<?= $item['dp_id'] ?>">
                                        <input type="hidden" name="quantity" value="0">
                                        <button type="submit" class="btn-remove">&#10005; Remove</button>
                                    </form>
                                </div>
                                <div class="ci-price">
                                    $<?= number_format($line, 2) ?>
                                    <?php if ($is_local): ?>
                                        <div class="ci-price-local"><?= $cs ?><?= number_format(convert_usd_to_local($line, $country_code), 2) ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <div class="cart-totals">
                            <div class="total-label">Subtotal</div>
                            <div class="total-amount">$<?= number_format($dealer_total, 2) ?></div>
                            <?php if ($is_local): ?>
                                <div class="total-local"><?= $cs ?><?= number_format(convert_usd_to_local($dealer_total, $country_code), 2) ?></div>
                            <?php endif; ?>
                        </div>

                        <?php if ($is_logged_in): ?>
                            <form method="POST">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="place_order">
                                <input type="hidden" name="dealer_id" value="<?= $did_cart ?>">
                                <textarea name="notes" class="order-notes" placeholder="Any notes for the dealer? (optional)" rows="2"></textarea>
                                <button type="submit" class="btn-order">&#10003; Place Order &mdash; $<?= number_format($dealer_total, 2) ?><?php if ($is_local): ?> (<?= $cs ?><?= number_format(convert_usd_to_local($dealer_total, $country_code), 2) ?>)<?php endif; ?></button>
                            </form>
                        <?php else: ?>
                            <div style="text-align:center;padding:16px 0;">
                                <p style="color:#64748B;font-size:0.875rem;margin-bottom:10px;">Login to place your order</p>
                                <a href="/solarglobal/customer/login.php" class="btn-order" style="display:inline-block;text-decoration:none;padding:14px 28px;border-radius:10px;">&#128274; Login to Place Order</a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <?php if ($dealer_count > 1): ?>
                    <div class="grand-total-bar">
                        <div>
                            <div class="gt-label">Grand Total (<?= $dealer_count ?> dealers)</div>
                            <div class="gt-amount">$<?= number_format($cart_total, 2) ?></div>
                            <?php if ($is_local): ?>
                                <div class="gt-local"><?= $cs ?><?= number_format(convert_usd_to_local($cart_total, $country_code), 2) ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="gt-meta"><?= $cart_count ?> item<?= $cart_count !== 1 ? 's' : '' ?> across <?= $dealer_count ?> dealer<?= $dealer_count !== 1 ? 's' : '' ?></div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

        <?php elseif ($dealer_info): ?>
            <!-- ==================== BROWSE DEALER INVENTORY ==================== -->
            <?php
            $type_filter = $_GET['type'] ?? '';
            $search = trim($_GET['q'] ?? '');
            ?>
            <div class="tabs">
                <a href="?dealer=<?= $dealer_id ?>" class="tab <?= !$type_filter ? 'active' : '' ?>">All</a>
                <a href="?dealer=<?= $dealer_id ?>&type=inverter" class="tab <?= $type_filter === 'inverter' ? 'active' : '' ?>">&#9889; Inverters</a>
                <a href="?dealer=<?= $dealer_id ?>&type=battery" class="tab <?= $type_filter === 'battery' ? 'active' : '' ?>">&#128267; Batteries</a>
                <a href="?dealer=<?= $dealer_id ?>&type=panel" class="tab <?= $type_filter === 'panel' ? 'active' : '' ?>">&#9728; Panels</a>
                <a href="?dealer=<?= $dealer_id ?>&type=installation_appliance" class="tab <?= $type_filter === 'installation_appliance' ? 'active' : '' ?>">&#128268; Install</a>
            </div>

            <form method="GET" class="search-bar">
                <input type="hidden" name="dealer" value="<?= $dealer_id ?>">
                <?php if ($type_filter): ?><input type="hidden" name="type" value="<?= $type_filter ?>"><?php endif; ?>
                <input type="text" name="q" value="<?= sanitize($search) ?>" placeholder="Search products...">
                <button type="submit">Search</button>
            </form>

            <p style="font-size:0.8125rem;color:#64748B;margin-bottom:12px;"><?= count($inventory) ?> products available</p>

            <?php if (empty($inventory)): ?>
                <div class="empty-msg"><p>No products found in this category.</p></div>
            <?php else: ?>
                <div class="product-grid">
                    <?php foreach ($inventory as $item): ?>
                        <div class="product-card">
                            <span class="pc-brand"><?= sanitize($item['brand'] ?? '') ?></span>
                            <div class="pc-name"><?= sanitize($item['product_name'] ?? 'Unknown Product') ?></div>
                            <span class="pc-type"><?= ucfirst(str_replace('_', ' ', $item['product_type'])) ?></span>
                            <div class="pc-price">$<?= number_format($item['dealer_price'], 2) ?></div>
                            <div class="pc-stock <?= $item['stock_status'] === 'in_stock' ? 'in' : ($item['stock_status'] === 'low_stock' ? 'low' : 'out') ?>">
                                <?= $item['stock_status'] === 'in_stock' ? '&#10003; In Stock ('.$item['stock_quantity'].')' : ($item['stock_status'] === 'low_stock' ? '&#9888; Low Stock ('.$item['stock_quantity'].')' : '&#10060; Out of Stock') ?>
                            </div>
                            <?php if ($item['stock_quantity'] > 0): ?>
                                <form method="POST" class="pc-add-form">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="add_to_cart">
                                    <input type="hidden" name="dealer_id" value="<?= $dealer_id ?>">
                                    <input type="hidden" name="dp_id" value="<?= $item['id'] ?>">
                                    <input type="number" name="quantity" value="1" min="1" max="<?= $item['stock_quantity'] ?>">
                                    <button type="submit" class="btn-add">+ Add to Cart</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="empty-msg">
                <h3>Select a dealer to browse products</h3>
                <p><a href="/solarglobal/store.php">Find a dealer near you</a></p>
            </div>
        <?php endif; ?>
    </div>

    <script>
    function stepQty(btn, delta) {
        var stepper = btn.closest('.qty-stepper');
        var input = stepper.querySelector('.qty-input');
        var current = parseInt(input.value) || 1;
        var min = parseInt(input.min) || 1;
        var max = parseInt(input.max) || 999;
        var next = current + delta;
        if (next < min) next = min;
        if (next > max) next = max;
        if (next !== current) {
            input.value = next;
            input.form.submit();
        }
    }
    </script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
