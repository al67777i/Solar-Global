<?php
/**
 * Centralized Email Sender
 *
 * Reads mail driver from system_settings:
 *   - 'php_mail' → uses PHP mail() function
 *   - 'smtp'     → uses direct socket SMTP (no PHPMailer dependency)
 *
 * All outgoing emails go through sg_send_email() which wraps content
 * in a professional branded HTML template with disclaimer.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

/**
 * Send an email using the configured mail driver.
 *
 * @param  string $to        Recipient email address
 * @param  string $subject   Email subject
 * @param  string $bodyHtml  HTML body content (inner content only — will be wrapped in template)
 * @param  array  $options   Optional: 'reply_to', 'cc', 'plain_text', 'skip_template' (bool)
 * @return bool              True on success
 */
function sg_send_email(string $to, string $subject, string $bodyHtml, array $options = []): bool
{
    $driver    = get_system_setting('mail_driver', 'php_mail');
    $fromAddr  = get_system_setting('mail_from_address', '');
    $fromName  = get_system_setting('mail_from_name', '');
    $siteName  = get_system_setting('site_name', 'SolarGlobal');

    if (empty($fromAddr)) {
        $fromAddr = 'noreply@' . ($_SERVER['SERVER_NAME'] ?? 'localhost');
    }
    if (empty($fromName)) {
        $fromName = $siteName;
    }

    // Wrap in branded template unless skip_template is set
    if (empty($options['skip_template'])) {
        $bodyHtml = _sg_email_template($bodyHtml, $siteName);
    }

    // Plain text version
    $plainText = $options['plain_text'] ?? strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $bodyHtml));

    if ($driver === 'smtp') {
        return _sg_send_smtp($to, $subject, $bodyHtml, $plainText, $fromAddr, $fromName, $options);
    }

    return _sg_send_php_mail($to, $subject, $bodyHtml, $fromAddr, $fromName, $options);
}

/**
 * Send using PHP mail()
 */
function _sg_send_php_mail(string $to, string $subject, string $html, string $fromAddr, string $fromName, array $options): bool
{
    $boundary = md5(uniqid(time()));

    $headers  = "From: {$fromName} <{$fromAddr}>\r\n";
    $headers .= "Reply-To: " . ($options['reply_to'] ?? $fromAddr) . "\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/alternative; boundary=\"{$boundary}\"\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";

    $plain = strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $html));

    $body  = "--{$boundary}\r\n";
    $body .= "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
    $body .= $plain . "\r\n\r\n";
    $body .= "--{$boundary}\r\n";
    $body .= "Content-Type: text/html; charset=UTF-8\r\n\r\n";
    $body .= $html . "\r\n\r\n";
    $body .= "--{$boundary}--\r\n";

    return @mail($to, $subject, $body, $headers);
}

/**
 * Send using direct SMTP socket (no PHPMailer needed)
 */
function _sg_send_smtp(string $to, string $subject, string $html, string $plain, string $fromAddr, string $fromName, array $options): bool
{
    $host       = get_system_setting('smtp_host', '');
    $port       = intval(get_system_setting('smtp_port', 587));
    $encryption = get_system_setting('smtp_encryption', 'tls');
    $username   = get_system_setting('smtp_username', '');
    $password   = get_system_setting('smtp_password', '');

    if (empty($host) || empty($username) || empty($password)) {
        error_log("sg_send_smtp: SMTP not fully configured (host={$host})");
        return false;
    }

    try {
        $connectHost = ($encryption === 'ssl') ? "ssl://{$host}" : $host;
        $smtp = @fsockopen($connectHost, $port, $errno, $errstr, 10);
        if (!$smtp) {
            error_log("sg_send_smtp: Connection failed - {$errstr} ({$errno})");
            return false;
        }

        stream_set_timeout($smtp, 15);

        // Helper to send command and read response
        $send = function(string $cmd = '') use ($smtp) {
            if ($cmd !== '') {
                fwrite($smtp, $cmd . "\r\n");
            }
            $resp = '';
            while ($line = fgets($smtp, 1024)) {
                $resp .= $line;
                if (isset($line[3]) && ($line[3] === ' ' || $line[3] === "\r")) break;
            }
            return $resp;
        };

        // Read greeting
        $send();

        // EHLO
        $serverName = $_SERVER['SERVER_NAME'] ?? 'localhost';
        $send("EHLO {$serverName}");

        // STARTTLS for TLS
        if ($encryption === 'tls') {
            $resp = $send("STARTTLS");
            if (strpos($resp, '220') === false) {
                error_log("sg_send_smtp: STARTTLS failed: {$resp}");
                fclose($smtp);
                return false;
            }
            $crypto = stream_socket_enable_crypto($smtp, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT);
            if (!$crypto) {
                error_log("sg_send_smtp: TLS negotiation failed");
                fclose($smtp);
                return false;
            }
            $send("EHLO {$serverName}");
        }

        // AUTH LOGIN
        $send("AUTH LOGIN");
        $send(base64_encode($username));
        $resp = $send(base64_encode($password));
        if (strpos($resp, '235') === false) {
            error_log("sg_send_smtp: Authentication failed: {$resp}");
            fclose($smtp);
            return false;
        }

        // MAIL FROM
        $send("MAIL FROM:<{$fromAddr}>");

        // RCPT TO
        $resp = $send("RCPT TO:<{$to}>");
        if (strpos($resp, '250') === false && strpos($resp, '251') === false) {
            error_log("sg_send_smtp: RCPT TO rejected: {$resp}");
            fclose($smtp);
            return false;
        }

        // DATA
        $send("DATA");

        // Build message
        $boundary = md5(uniqid(time()));
        $msg  = "From: {$fromName} <{$fromAddr}>\r\n";
        $msg .= "To: {$to}\r\n";
        $msg .= "Subject: {$subject}\r\n";
        $msg .= "Reply-To: " . ($options['reply_to'] ?? $fromAddr) . "\r\n";
        $msg .= "MIME-Version: 1.0\r\n";
        $msg .= "Content-Type: multipart/alternative; boundary=\"{$boundary}\"\r\n";
        $msg .= "X-Mailer: SolarGlobal-Mailer\r\n";
        $msg .= "\r\n";
        $msg .= "--{$boundary}\r\n";
        $msg .= "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
        $msg .= $plain . "\r\n\r\n";
        $msg .= "--{$boundary}\r\n";
        $msg .= "Content-Type: text/html; charset=UTF-8\r\n\r\n";
        $msg .= $html . "\r\n\r\n";
        $msg .= "--{$boundary}--\r\n";
        $msg .= "\r\n.\r\n";

        $resp = $send($msg);

        // QUIT
        $send("QUIT");
        fclose($smtp);

        return strpos($resp, '250') !== false;
    } catch (\Throwable $e) {
        error_log("sg_send_smtp exception: " . $e->getMessage());
        return false;
    }
}

/**
 * Professional branded HTML email template
 */
function _sg_email_template(string $innerContent, string $siteName): string
{
    $year = date('Y');
    $siteTagline = get_system_setting('site_tagline', 'Smart Solar Advisor');
    $contactEmail = get_system_setting('contact_email', '');
    $contactLine = $contactEmail ? "<a href=\"mailto:{$contactEmail}\" style=\"color:#0EA5E9;text-decoration:none;\">{$contactEmail}</a>" : '';

    return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$siteName}</title>
</head>
<body style="margin:0;padding:0;background-color:#F1F5F9;font-family:'Segoe UI',Roboto,Arial,sans-serif;-webkit-font-smoothing:antialiased;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#F1F5F9;padding:40px 16px;">
        <tr>
            <td align="center">
                <!-- Main Card -->
                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="background-color:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);max-width:600px;width:100%;">
                    <!-- Header -->
                    <tr>
                        <td style="background:linear-gradient(135deg,#0F172A 0%,#1E293B 100%);padding:32px 40px;text-align:center;">
                            <table role="presentation" cellspacing="0" cellpadding="0" style="margin:0 auto;">
                                <tr>
                                    <td style="width:40px;height:40px;background:linear-gradient(135deg,#F59E0B,#D97706);border-radius:10px;text-align:center;vertical-align:middle;">
                                        <span style="font-size:22px;line-height:40px;">&#9728;</span>
                                    </td>
                                    <td style="padding-left:12px;">
                                        <div style="font-size:22px;font-weight:700;color:#ffffff;line-height:1.2;">{$siteName}</div>
                                        <div style="font-size:12px;color:#94A3B8;line-height:1.2;">{$siteTagline}</div>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <!-- Body -->
                    <tr>
                        <td style="padding:36px 40px 24px;">
                            {$innerContent}
                        </td>
                    </tr>
                    <!-- Disclaimer / Footer -->
                    <tr>
                        <td style="padding:0 40px 32px;">
                            <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td style="border-top:1px solid #E2E8F0;padding-top:20px;">
                                        <p style="font-size:12px;color:#94A3B8;margin:0 0 8px;line-height:1.6;">
                                            This is an automated message from <strong>{$siteName}</strong>. Please do not reply directly to this email.
                                        </p>
                                        <p style="font-size:12px;color:#94A3B8;margin:0 0 8px;line-height:1.6;">
                                            <strong>Disclaimer:</strong> {$siteName} is an informational platform that connects solar energy buyers with dealers and installers. We do not sell products directly and do not guarantee the quality, availability, or pricing of any products or services listed. All transactions are between buyers and sellers directly.
                                        </p>
                                        <p style="font-size:11px;color:#CBD5E1;margin:0;line-height:1.6;">
                                            &copy; {$year} {$siteName}. All rights reserved. {$contactLine}
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
HTML;
}
