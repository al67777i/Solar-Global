<?php
/**
 * Admin - Dealer Management
 * View, approve, reject, suspend dealers
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = getDB();
$success = '';
$error = '';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';
    $dealer_id = (int)($_POST['dealer_id'] ?? 0);

    if ($dealer_id && $action) {
        if ($action === 'approve') {
            $db->prepare("UPDATE dealers SET status = 'approved', approved_by = ?, approved_at = NOW() WHERE id = ?")
               ->execute([$_SESSION['admin_id'], $dealer_id]);
            $success = 'Dealer approved!';
        } elseif ($action === 'reject') {
            $reason = trim($_POST['rejection_reason'] ?? 'Application did not meet our requirements.');
            $db->prepare("UPDATE dealers SET status = 'rejected', rejection_reason = ? WHERE id = ?")
               ->execute([$reason, $dealer_id]);
            $success = 'Dealer rejected.';
        } elseif ($action === 'suspend') {
            $db->prepare("UPDATE dealers SET status = 'suspended' WHERE id = ?")->execute([$dealer_id]);
            $success = 'Dealer suspended.';
        } elseif ($action === 'activate') {
            $db->prepare("UPDATE dealers SET status = 'active' WHERE id = ?")->execute([$dealer_id]);
            $success = 'Dealer activated.';
        } elseif ($action === 'delete') {
            $db->prepare("DELETE FROM dealers WHERE id = ?")->execute([$dealer_id]);
            $success = 'Dealer deleted.';
        } elseif ($action === 'toggle_live') {
            $db->prepare("UPDATE dealers SET is_live = NOT is_live WHERE id = ?")->execute([$dealer_id]);
            $success = 'Store visibility updated.';
        }
    }
}

// Filters
$status_filter = $_GET['status'] ?? 'all';
$sub_filter = $_GET['sub'] ?? 'all';
$where_parts = [];
$params = [];
if ($status_filter !== 'all') {
    $where_parts[] = 'd.status = ?';
    $params[] = $status_filter;
}
if ($sub_filter !== 'all') {
    $where_parts[] = 'd.subscription_status = ?';
    $params[] = $sub_filter;
}
$where = $where_parts ? 'WHERE ' . implode(' AND ', $where_parts) : '';

// Fetch dealers
$dealers = $db->prepare("
    SELECT d.*,
        (SELECT COUNT(*) FROM dealer_products dp
         WHERE dp.dealer_id = d.id
         AND (
             (dp.product_type = 'inverter' AND EXISTS (SELECT 1 FROM inverters WHERE id = dp.product_id)) OR
             (dp.product_type = 'battery' AND EXISTS (SELECT 1 FROM batteries WHERE id = dp.product_id)) OR
             (dp.product_type = 'panel' AND EXISTS (SELECT 1 FROM panels WHERE id = dp.product_id)) OR
             (dp.product_type = 'installation_appliance' AND EXISTS (SELECT 1 FROM installation_appliances WHERE id = dp.product_id))
         )) AS product_count
    FROM dealers d
    $where
    ORDER BY
        CASE d.status
            WHEN 'pending' THEN 1
            WHEN 'approved' THEN 2
            WHEN 'active' THEN 3
            WHEN 'suspended' THEN 4
            WHEN 'rejected' THEN 5
        END,
        d.created_at DESC
");
$dealers->execute($params);
$dealers = $dealers->fetchAll();

// Count by status
$counts = $db->query("
    SELECT status, COUNT(*) as cnt FROM dealers GROUP BY status
")->fetchAll(PDO::FETCH_KEY_PAIR);
$total = array_sum($counts);

// Count by subscription status
$sub_counts = $db->query("
    SELECT subscription_status, COUNT(*) as cnt FROM dealers GROUP BY subscription_status
")->fetchAll(PDO::FETCH_KEY_PAIR);

$pageTitle = 'Dealers';

include __DIR__ . '/includes/header.php';
?>

<div class="content-wrapper" style="padding: 24px;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
        <h2 style="font-size:1.5rem; color:#1E293B;">Dealer Management</h2>
        <span style="font-size:0.875rem; color:#64748B;"><?= $total ?> total dealers</span>
    </div>

    <?php if ($success): ?>
        <div style="background:#DCFCE7; color:#166534; padding:12px 16px; border-radius:8px; margin-bottom:16px; font-size:0.875rem;">
            <?= sanitize($success) ?>
        </div>
    <?php endif; ?>

    <!-- Status Filters -->
    <div style="margin-bottom:8px; font-size:0.75rem; font-weight:600; color:#64748B; text-transform:uppercase; letter-spacing:0.5px;">Account Status</div>
    <div style="display:flex; gap:8px; margin-bottom:16px; flex-wrap:wrap;">
        <a href="?status=all<?= $sub_filter !== 'all' ? '&sub=' . urlencode($sub_filter) : '' ?>" style="padding:8px 18px; border:2px solid <?= $status_filter==='all' ? '#1565C0' : '#E2E8F0' ?>; border-radius:8px; text-decoration:none; font-size:0.875rem; font-weight:500; color:<?= $status_filter==='all' ? '#1565C0' : '#475569' ?>; background:<?= $status_filter==='all' ? '#EFF6FF' : 'white' ?>;">
            All (<?= $total ?>)
        </a>
        <?php foreach (['pending'=>'Pending', 'approved'=>'Approved', 'active'=>'Active', 'suspended'=>'Suspended', 'rejected'=>'Rejected'] as $k => $v): ?>
            <a href="?status=<?= $k ?><?= $sub_filter !== 'all' ? '&sub=' . urlencode($sub_filter) : '' ?>" style="padding:8px 18px; border:2px solid <?= $status_filter===$k ? '#1565C0' : '#E2E8F0' ?>; border-radius:8px; text-decoration:none; font-size:0.875rem; font-weight:500; color:<?= $status_filter===$k ? '#1565C0' : '#475569' ?>; background:<?= $status_filter===$k ? '#EFF6FF' : 'white' ?>;">
                <?= $v ?> (<?= $counts[$k] ?? 0 ?>)
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Subscription Filters -->
    <div style="margin-bottom:8px; font-size:0.75rem; font-weight:600; color:#64748B; text-transform:uppercase; letter-spacing:0.5px;">Subscription Status</div>
    <div style="display:flex; gap:8px; margin-bottom:20px; flex-wrap:wrap;">
        <a href="?sub=all<?= $status_filter !== 'all' ? '&status=' . urlencode($status_filter) : '' ?>" style="padding:6px 14px; border:2px solid <?= $sub_filter==='all' ? '#16A34A' : '#E2E8F0' ?>; border-radius:8px; text-decoration:none; font-size:0.8125rem; font-weight:500; color:<?= $sub_filter==='all' ? '#166534' : '#475569' ?>; background:<?= $sub_filter==='all' ? '#DCFCE7' : 'white' ?>;">
            All
        </a>
        <?php foreach (['active'=>'Subscribed', 'trial'=>'Trial', 'expired'=>'Expired', 'canceled'=>'Canceled', 'none'=>'None'] as $sk => $sv): ?>
            <a href="?sub=<?= $sk ?><?= $status_filter !== 'all' ? '&status=' . urlencode($status_filter) : '' ?>" style="padding:6px 14px; border:2px solid <?= $sub_filter===$sk ? '#16A34A' : '#E2E8F0' ?>; border-radius:8px; text-decoration:none; font-size:0.8125rem; font-weight:500; color:<?= $sub_filter===$sk ? '#166534' : '#475569' ?>; background:<?= $sub_filter===$sk ? '#DCFCE7' : 'white' ?>;">
                <?= $sv ?> (<?= $sub_counts[$sk] ?? 0 ?>)
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Dealers Table -->
    <div style="background:white; border-radius:12px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
        <table style="width:100%; border-collapse:collapse;">
            <thead>
                <tr style="background:#F8FAFC;">
                    <th style="padding:12px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Dealer</th>
                    <th style="padding:12px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Location</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Products</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Status</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Subscription</th>
                    <th style="padding:12px 16px; text-align:left; font-size:0.8125rem; color:#64748B; font-weight:600;">Joined</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Live</th>
                    <th style="padding:12px 16px; text-align:center; font-size:0.8125rem; color:#64748B; font-weight:600;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($dealers)): ?>
                    <tr><td colspan="8" style="padding:40px; text-align:center; color:#94A3B8;">No dealers found.</td></tr>
                <?php endif; ?>
                <?php foreach ($dealers as $d): ?>
                    <?php
                    $status_colors = [
                        'pending' => ['bg'=>'#FEF3C7','color'=>'#92400E'],
                        'approved' => ['bg'=>'#DBEAFE','color'=>'#1E40AF'],
                        'active' => ['bg'=>'#DCFCE7','color'=>'#166534'],
                        'suspended' => ['bg'=>'#FEE2E2','color'=>'#991B1B'],
                        'rejected' => ['bg'=>'#F1F5F9','color'=>'#475569'],
                    ];
                    $sc = $status_colors[$d['status']] ?? $status_colors['pending'];
                    ?>
                    <tr style="border-bottom:1px solid #F1F5F9;">
                        <td style="padding:14px 16px;">
                            <div style="font-weight:600; color:#1E293B;"><?= sanitize($d['business_name']) ?></div>
                            <div style="font-size:0.8125rem; color:#64748B;"><?= sanitize($d['owner_name']) ?> &middot; <?= sanitize($d['email']) ?></div>
                            <?php if ($d['phone']): ?><div style="font-size:0.75rem; color:#94A3B8;"><?= sanitize($d['phone']) ?></div><?php endif; ?>
                        </td>
                        <td style="padding:14px 16px; font-size:0.875rem; color:#475569;">
                            <?= sanitize($d['city'] ?? '') ?><?= $d['city'] && $d['country_code'] ? ', ' : '' ?><?= sanitize($d['country_code'] ?? '') ?>
                        </td>
                        <td style="padding:14px 16px; text-align:center; font-weight:600;"><?= $d['product_count'] ?></td>
                        <td style="padding:14px 16px; text-align:center;">
                            <span style="display:inline-block; padding:3px 12px; border-radius:6px; font-size:0.75rem; font-weight:600; background:<?= $sc['bg'] ?>; color:<?= $sc['color'] ?>;">
                                <?= ucfirst($d['status']) ?>
                            </span>
                        </td>
                        <?php
                        $sub_status_colors = [
                            'active' => ['bg'=>'#DCFCE7','color'=>'#166534'],
                            'trial' => ['bg'=>'#DBEAFE','color'=>'#1E40AF'],
                            'expired' => ['bg'=>'#FEE2E2','color'=>'#991B1B'],
                            'canceled' => ['bg'=>'#FEF3C7','color'=>'#92400E'],
                            'past_due' => ['bg'=>'#FEF3C7','color'=>'#92400E'],
                            'none' => ['bg'=>'#F1F5F9','color'=>'#64748B'],
                        ];
                        $ssc = $sub_status_colors[$d['subscription_status'] ?? 'none'] ?? $sub_status_colors['none'];
                        ?>
                        <td style="padding:14px 16px; text-align:center;">
                            <span style="display:inline-block; padding:3px 10px; border-radius:6px; font-size:0.7rem; font-weight:600; background:<?= $ssc['bg'] ?>; color:<?= $ssc['color'] ?>;">
                                <?= ucfirst($d['subscription_status'] ?: 'None') ?>
                            </span>
                            <?php if (!empty($d['subscription_expires_at'])): ?>
                                <div style="font-size:0.7rem; color:#94A3B8; margin-top:2px;"><?= date('M d, Y', strtotime($d['subscription_expires_at'])) ?></div>
                            <?php endif; ?>
                            <?php if (!empty($d['grace_period_ends_at']) && strtotime($d['grace_period_ends_at']) > time()): ?>
                                <div style="font-size:0.65rem; color:#DC2626; margin-top:1px;">Grace: <?= date('M d', strtotime($d['grace_period_ends_at'])) ?></div>
                            <?php endif; ?>
                        </td>
                        <td style="padding:14px 16px; font-size:0.8125rem; color:#64748B;">
                            <?= date('M d, Y', strtotime($d['created_at'])) ?>
                        </td>
                        <td style="padding:14px 16px; text-align:center;">
                            <form method="POST" style="display:inline">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="toggle_live">
                                <input type="hidden" name="dealer_id" value="<?= $d['id'] ?>">
                                <button type="submit" title="<?= ($d['is_live'] ?? 1) ? 'Click to take offline' : 'Click to go live' ?>"
                                    style="background:none; border:none; cursor:pointer; font-size:1.4rem; line-height:1;"
                                ><?= ($d['is_live'] ?? 1) ? '🟢' : '🔴' ?></button>
                            </form>
                        </td>
                        <td style="padding:14px 16px; text-align:center;">
                            <div style="display:flex; gap:4px; justify-content:center; flex-wrap:wrap;">
                                <a href="dealer-detail.php?id=<?= $d['id'] ?>" style="padding:5px 12px; background:#3B82F6; color:white; border:none; border-radius:4px; font-size:0.75rem; font-weight:600; cursor:pointer; text-decoration:none;">View</a>
                                <?php if ($d['status'] === 'pending'): ?>
                                    <form method="POST" style="display:inline">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="approve">
                                        <input type="hidden" name="dealer_id" value="<?= $d['id'] ?>">
                                        <button type="submit" style="padding:5px 12px; background:#16A34A; color:white; border:none; border-radius:4px; font-size:0.75rem; font-weight:600; cursor:pointer;">Approve</button>
                                    </form>
                                    <form method="POST" style="display:inline" onsubmit="return confirm('Reject this dealer?')">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="reject">
                                        <input type="hidden" name="dealer_id" value="<?= $d['id'] ?>">
                                        <button type="submit" style="padding:5px 12px; background:#DC2626; color:white; border:none; border-radius:4px; font-size:0.75rem; font-weight:600; cursor:pointer;">Reject</button>
                                    </form>
                                <?php elseif ($d['status'] === 'active' || $d['status'] === 'approved'): ?>
                                    <form method="POST" style="display:inline" onsubmit="return confirm('Suspend this dealer?')">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="suspend">
                                        <input type="hidden" name="dealer_id" value="<?= $d['id'] ?>">
                                        <button type="submit" style="padding:5px 12px; background:#F59E0B; color:white; border:none; border-radius:4px; font-size:0.75rem; font-weight:600; cursor:pointer;">Suspend</button>
                                    </form>
                                <?php elseif ($d['status'] === 'suspended'): ?>
                                    <form method="POST" style="display:inline">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="activate">
                                        <input type="hidden" name="dealer_id" value="<?= $d['id'] ?>">
                                        <button type="submit" style="padding:5px 12px; background:#16A34A; color:white; border:none; border-radius:4px; font-size:0.75rem; font-weight:600; cursor:pointer;">Reactivate</button>
                                    </form>
                                <?php endif; ?>
                                <form method="POST" style="display:inline" onsubmit="return confirm('DELETE this dealer permanently?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="dealer_id" value="<?= $d['id'] ?>">
                                    <button type="submit" style="padding:5px 12px; background:#1E293B; color:white; border:none; border-radius:4px; font-size:0.75rem; font-weight:600; cursor:pointer;">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
