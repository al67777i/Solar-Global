<?php
/**
 * Customer Installation Bookings - Track and manage installation orders
 */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/customer_auth.php';

set_security_headers();
require_customer_login();

$customer = get_customer_profile();
$db = getDB();
$success = '';
$error = '';

// ── POST Handlers ──────────────────────────────────────────────────────────

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validate_csrf_token($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';
    $order_id = (int)($_POST['order_id'] ?? 0);

    // ── Confirm Completion ──
    if ($action === 'confirm_completion') {
        $stmt = $db->prepare("SELECT * FROM installer_orders WHERE id = ? AND customer_id = ? AND status = 'completed' AND customer_confirmed = 0");
        $stmt->execute([$order_id, $customer['id']]);
        $order = $stmt->fetch();

        if ($order) {
            $stmt = $db->prepare("UPDATE installer_orders SET customer_confirmed = 1, customer_confirmed_at = NOW() WHERE id = ?");
            $stmt->execute([$order_id]);
            $success = 'Installation confirmed! You can now leave a review.';
        } else {
            $error = 'Invalid order or already confirmed.';
        }
    }

    // ── Submit Review ──
    elseif ($action === 'submit_review') {
        $rating = (int)($_POST['rating'] ?? 0);
        $review_text = trim($_POST['review_text'] ?? '');

        $stmt = $db->prepare("SELECT * FROM installer_orders WHERE id = ? AND customer_id = ? AND status = 'completed' AND customer_confirmed = 1");
        $stmt->execute([$order_id, $customer['id']]);
        $order = $stmt->fetch();

        if (!$order) {
            $error = 'Invalid order or installation not yet confirmed.';
        } elseif ($rating < 1 || $rating > 5) {
            $error = 'Please select a rating (1-5 stars).';
        } elseif (strlen($review_text) < 10) {
            $error = 'Please write at least 10 characters in your review.';
        } else {
            // Check duplicate
            $stmt = $db->prepare("SELECT id FROM installer_reviews WHERE order_id = ? AND customer_id = ?");
            $stmt->execute([$order_id, $customer['id']]);
            if ($stmt->fetch()) {
                $error = 'You have already reviewed this installation.';
            } else {
                $stmt = $db->prepare("INSERT INTO installer_reviews (installer_id, customer_id, order_id, reviewer_name, reviewer_email, reviewer_phone, rating, review_text, project_type, system_size_kw, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'approved', NOW())");
                $stmt->execute([
                    $order['installer_id'],
                    $customer['id'],
                    $order_id,
                    $customer['name'] ?? '',
                    $customer['email'] ?? '',
                    $customer['phone'] ?? '',
                    $rating,
                    $review_text,
                    $order['property_type'],
                    $order['system_size_kw']
                ]);

                // Update installer avg_rating and total_reviews
                $stmt = $db->prepare("UPDATE installers SET
                    avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM installer_reviews WHERE installer_id = ? AND status = 'approved'),
                    total_reviews = (SELECT COUNT(*) FROM installer_reviews WHERE installer_id = ? AND status = 'approved')
                    WHERE id = ?");
                $stmt->execute([$order['installer_id'], $order['installer_id'], $order['installer_id']]);

                $success = 'Thank you for your review!';
            }
        }
    }

    // ── Cancel Request ──
    elseif ($action === 'cancel_request') {
        $stmt = $db->prepare("SELECT * FROM installer_orders WHERE id = ? AND customer_id = ? AND status = 'requested'");
        $stmt->execute([$order_id, $customer['id']]);
        $order = $stmt->fetch();

        if ($order) {
            $stmt = $db->prepare("UPDATE installer_orders SET status = 'cancelled', cancel_reason = 'Cancelled by customer', cancelled_at = NOW() WHERE id = ?");
            $stmt->execute([$order_id]);
            $success = 'Installation request cancelled.';
        } else {
            $error = 'Cannot cancel this request.';
        }
    }
}

// ── Fetch all orders ────────────────────────────────────────────────────────

$stmt = $db->prepare("
    SELECT io.*,
           i.business_name, i.owner_name, i.phone AS installer_phone, i.email AS installer_email,
           i.logo_path, i.avg_rating AS installer_rating, i.city AS installer_city, i.country_code,
           ir.id AS review_id, ir.rating AS review_rating, ir.review_text AS review_text_existing
    FROM installer_orders io
    JOIN installers i ON io.installer_id = i.id
    LEFT JOIN installer_reviews ir ON ir.order_id = io.id AND ir.customer_id = io.customer_id
    WHERE io.customer_id = ?
    ORDER BY io.created_at DESC
");
$stmt->execute([$customer['id']]);
$orders = $stmt->fetchAll();

// Stats
$total = count($orders);
$active = 0;
$completed = 0;
foreach ($orders as $o) {
    if (in_array($o['status'], ['requested', 'accepted', 'in_progress'])) $active++;
    if ($o['status'] === 'completed') $completed++;
}

$page_title = 'My Installations';
$current_page = 'installations';
include __DIR__ . '/../includes/header.php';
?>
    <style>
        .inst-container { max-width: 800px; margin: 24px auto; padding: 0 20px; }

        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; }
        .alert-success { background: #DCFCE7; color: #166534; }
        .alert-error { background: #FEF2F2; color: #991B1B; }

        /* Stats bar */
        .stats-bar { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
        .stat-item {
            flex: 1; min-width: 100px; background: white; border-radius: 10px; padding: 16px;
            text-align: center; box-shadow: 0 1px 4px rgba(0,0,0,0.05);
        }
        .stat-num { font-size: 1.5rem; font-weight: 800; color: #1E293B; }
        .stat-label { font-size: 0.75rem; color: #64748B; margin-top: 2px; }

        /* Cards */
        .inst-card {
            background: white; border-radius: 12px; padding: 24px; margin-bottom: 16px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.05);
        }
        .inst-header { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
        .inst-logo {
            width: 44px; height: 44px; border-radius: 8px; object-fit: cover;
            background: #F1F5F9; flex-shrink: 0;
        }
        .inst-logo-placeholder {
            width: 44px; height: 44px; border-radius: 8px; background: #F1F5F9;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.125rem; font-weight: 700; color: #94A3B8; flex-shrink: 0;
        }
        .inst-title { flex: 1; }
        .inst-name { font-size: 1rem; font-weight: 700; color: #1E293B; }
        .inst-city { font-size: 0.75rem; color: #64748B; }

        /* Status badges */
        .badge {
            display: inline-block; padding: 3px 10px; border-radius: 20px;
            font-size: 0.6875rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px;
        }
        .badge-requested { background: #FEF3C7; color: #92400E; }
        .badge-accepted { background: #DBEAFE; color: #1E40AF; }
        .badge-in_progress { background: #EDE9FE; color: #6D28D9; }
        .badge-completed { background: #DCFCE7; color: #166534; }
        .badge-cancelled { background: #FEE2E2; color: #991B1B; }

        /* Details grid */
        .inst-details { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 16px; margin: 14px 0; }
        .inst-detail { font-size: 0.8125rem; }
        .inst-detail-label { color: #94A3B8; font-size: 0.6875rem; text-transform: uppercase; letter-spacing: 0.3px; }
        .inst-detail-value { color: #374151; font-weight: 500; }

        .inst-desc {
            font-size: 0.8125rem; color: #64748B; margin: 10px 0;
            padding: 10px 12px; background: #F8FAFC; border-radius: 6px;
        }
        .inst-notes { font-size: 0.8125rem; margin: 10px 0; }
        .inst-notes strong { color: #374151; }
        .inst-notes span { color: #64748B; }

        .inst-timestamps { font-size: 0.6875rem; color: #94A3B8; margin-top: 12px; display: flex; flex-wrap: wrap; gap: 6px 16px; }

        .inst-cost {
            display: inline-block; padding: 8px 14px; background: #F0FDF4; border: 1px solid #BBF7D0;
            border-radius: 8px; font-size: 0.9375rem; font-weight: 700; color: #166534; margin: 8px 0;
        }

        .inst-info {
            font-size: 0.8125rem; color: #3B82F6; padding: 8px 12px;
            background: #EFF6FF; border-radius: 6px; margin: 10px 0;
        }

        .inst-cancel-reason {
            font-size: 0.8125rem; color: #991B1B; padding: 8px 12px;
            background: #FEF2F2; border-radius: 6px; margin: 10px 0;
        }

        /* Buttons */
        .btn {
            padding: 10px 20px; border: none; border-radius: 8px;
            font-weight: 700; font-size: 0.8125rem; cursor: pointer; font-family: inherit;
            display: inline-block; text-align: center;
        }
        .btn-green { background: #22C55E; color: white; }
        .btn-green:hover { background: #16A34A; }
        .btn-red { background: #FEE2E2; color: #991B1B; }
        .btn-red:hover { background: #FECACA; }
        .btn-amber { background: #F59E0B; color: #1E293B; }
        .btn-amber:hover { background: #D97706; }

        /* Star rating input */
        .star-rating { display: flex; gap: 4px; margin-bottom: 12px; flex-direction: row-reverse; justify-content: flex-end; }
        .star-rating input { display: none; }
        .star-rating label {
            font-size: 2rem; color: #E2E8F0; cursor: pointer; transition: color 0.15s;
        }
        .star-rating input:checked ~ label,
        .star-rating label:hover,
        .star-rating label:hover ~ label { color: #F59E0B; }

        /* Existing review display */
        .existing-review { background: #F0FDF4; border: 1px solid #BBF7D0; border-radius: 8px; padding: 14px; margin-top: 10px; }
        .er-stars { color: #F59E0B; font-size: 1.25rem; margin-bottom: 4px; }
        .er-text { font-size: 0.8125rem; color: #374151; }

        /* Review form */
        .review-form { margin-top: 12px; padding: 16px; background: #FFFBEB; border: 1px solid #FDE68A; border-radius: 8px; }
        .review-form textarea {
            width: 100%; padding: 10px; border: 2px solid #E2E8F0; border-radius: 8px;
            font-family: inherit; font-size: 0.875rem; resize: vertical; min-height: 80px;
            margin-bottom: 10px; box-sizing: border-box;
        }
        .review-form textarea:focus { outline: none; border-color: #F59E0B; }
        .review-toggle {
            font-size: 0.8125rem; color: #D97706; cursor: pointer; font-weight: 600;
            background: none; border: none; padding: 0; font-family: inherit;
        }
        .review-toggle:hover { text-decoration: underline; }

        /* Empty state */
        .empty-state { text-align: center; padding: 40px 20px; }
        .empty-state p { color: #64748B; font-size: 0.9375rem; margin-bottom: 16px; }
        .empty-state a { color: #F59E0B; font-weight: 600; text-decoration: none; }
        .empty-state a:hover { text-decoration: underline; }

        @media (max-width: 640px) {
            .inst-container { padding: 0 12px; }
            .stats-bar { gap: 8px; }
            .stat-item { padding: 12px 8px; min-width: 70px; }
            .stat-num { font-size: 1.25rem; }
            .inst-card { padding: 16px; }
            .inst-details { grid-template-columns: 1fr; gap: 6px; }
            .inst-header { gap: 8px; }
        }
    </style>

    <div class="inst-container">
        <?php if ($success): ?><div class="alert alert-success"><?= sanitize($success) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>

        <!-- Stats Bar -->
        <div class="stats-bar">
            <div class="stat-item">
                <div class="stat-num"><?= $total ?></div>
                <div class="stat-label">Total Bookings</div>
            </div>
            <div class="stat-item">
                <div class="stat-num"><?= $active ?></div>
                <div class="stat-label">Active</div>
            </div>
            <div class="stat-item">
                <div class="stat-num"><?= $completed ?></div>
                <div class="stat-label">Completed</div>
            </div>
        </div>

        <?php if (empty($orders)): ?>
            <div class="inst-card empty-state">
                <p>No installation bookings yet.</p>
                <a href="/solarglobal/find-installer.php">Find an Installer &rarr;</a>
            </div>
        <?php else: ?>
            <?php foreach ($orders as $o): ?>
                <div class="inst-card">
                    <!-- Header: Installer + Status -->
                    <div class="inst-header">
                        <?php if (!empty($o['logo_path'])): ?>
                            <img src="/solarglobal/<?= sanitize($o['logo_path']) ?>" alt="" class="inst-logo">
                        <?php else: ?>
                            <div class="inst-logo-placeholder"><?= strtoupper(substr($o['business_name'] ?? '?', 0, 1)) ?></div>
                        <?php endif; ?>
                        <div class="inst-title">
                            <div class="inst-name"><?= sanitize($o['business_name']) ?></div>
                            <?php if (!empty($o['installer_city'])): ?>
                                <div class="inst-city"><?= sanitize($o['installer_city']) ?><?= !empty($o['country_code']) ? ', ' . sanitize($o['country_code']) : '' ?></div>
                            <?php endif; ?>
                        </div>
                        <?php
                            $status_label = str_replace('_', ' ', $o['status']);
                            $badge_class = 'badge-' . $o['status'];
                        ?>
                        <span class="badge <?= $badge_class ?>"><?= ucwords($status_label) ?></span>
                    </div>

                    <!-- System Details -->
                    <div class="inst-details">
                        <div class="inst-detail">
                            <div class="inst-detail-label">Property Type</div>
                            <div class="inst-detail-value"><?= ucfirst(sanitize($o['property_type'] ?? '-')) ?></div>
                        </div>
                        <div class="inst-detail">
                            <div class="inst-detail-label">System Type</div>
                            <div class="inst-detail-value"><?= ucfirst(sanitize($o['system_type'] ?? '-')) ?></div>
                        </div>
                        <div class="inst-detail">
                            <div class="inst-detail-label">System Size</div>
                            <div class="inst-detail-value"><?= $o['system_size_kw'] ? sanitize($o['system_size_kw']) . ' kW' : '-' ?></div>
                        </div>
                        <?php if (!empty($o['customer_budget_per_kw'])): ?>
                        <div class="inst-detail">
                            <div class="inst-detail-label">Your Budget</div>
                            <div class="inst-detail-value">$<?= number_format($o['customer_budget_per_kw'], 2) ?>/kW<?php if ($o['customer_budget_total'] > 0): ?> ($<?= number_format($o['customer_budget_total'], 2) ?> total)<?php endif; ?></div>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($o['scheduled_date'])): ?>
                        <div class="inst-detail">
                            <div class="inst-detail-label">Scheduled Date</div>
                            <div class="inst-detail-value"><?= date('M j, Y', strtotime($o['scheduled_date'])) ?><?= !empty($o['preferred_time']) ? ' &middot; ' . ucfirst(sanitize($o['preferred_time'])) : '' ?></div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($o['address'])): ?>
                        <div class="inst-detail" style="margin-bottom:8px;">
                            <div class="inst-detail-label">Address</div>
                            <div class="inst-detail-value" style="font-size:0.8125rem;"><?= sanitize($o['address']) ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($o['description'])): ?>
                        <div class="inst-desc"><?= sanitize(strlen($o['description']) > 150 ? substr($o['description'], 0, 150) . '...' : $o['description']) ?></div>
                    <?php endif; ?>

                    <!-- Cost display -->
                    <?php if (in_array($o['status'], ['accepted', 'in_progress']) && $o['estimated_cost'] > 0): ?>
                        <div class="inst-cost"><?= sanitize($o['currency'] ?? 'USD') ?> <?= number_format($o['estimated_cost'], 2) ?> <span style="font-size:0.6875rem;font-weight:400;color:#64748B;">(estimated)</span></div>
                    <?php endif; ?>
                    <?php if ($o['status'] === 'completed' && $o['total_amount'] > 0): ?>
                        <div class="inst-cost"><?= sanitize($o['currency'] ?? 'USD') ?> <?= number_format($o['total_amount'], 2) ?> <span style="font-size:0.6875rem;font-weight:400;color:#64748B;">(final)</span></div>
                    <?php endif; ?>

                    <!-- Notes -->
                    <?php if (!empty($o['customer_notes'])): ?>
                        <div class="inst-notes"><strong>Your notes:</strong> <span><?= sanitize($o['customer_notes']) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($o['installer_notes'])): ?>
                        <div class="inst-notes"><strong>Installer notes:</strong> <span><?= sanitize($o['installer_notes']) ?></span></div>
                    <?php endif; ?>

                    <!-- Timestamps -->
                    <div class="inst-timestamps">
                        <span>Created: <?= date('M j, Y', strtotime($o['created_at'])) ?></span>
                        <?php if (!empty($o['accepted_at'])): ?><span>Accepted: <?= date('M j, Y', strtotime($o['accepted_at'])) ?></span><?php endif; ?>
                        <?php if (!empty($o['started_at'])): ?><span>Started: <?= date('M j, Y', strtotime($o['started_at'])) ?></span><?php endif; ?>
                        <?php if (!empty($o['completed_at'])): ?><span>Completed: <?= date('M j, Y', strtotime($o['completed_at'])) ?></span><?php endif; ?>
                    </div>

                    <!-- Action area per status -->
                    <?php if ($o['status'] === 'requested'): ?>
                        <div style="margin-top:14px;">
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Cancel this installation request?');">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="cancel_request">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <button type="submit" class="btn btn-red">Cancel Request</button>
                            </form>
                        </div>

                    <?php elseif ($o['status'] === 'accepted'): ?>
                        <div class="inst-info">Installer accepted your request! Awaiting work to begin.</div>

                    <?php elseif ($o['status'] === 'in_progress'): ?>
                        <div class="inst-info">Installation in progress...</div>

                    <?php elseif ($o['status'] === 'completed'): ?>
                        <?php if (!$o['customer_confirmed']): ?>
                            <!-- Confirm completion -->
                            <div style="margin-top:14px;">
                                <form method="POST" style="display:inline;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="confirm_completion">
                                    <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                    <button type="submit" class="btn btn-green">Confirm Work Completed</button>
                                </form>
                            </div>

                        <?php elseif (!$o['review_id']): ?>
                            <!-- Review form (collapsible) -->
                            <div style="margin-top:14px;">
                                <button class="review-toggle" onclick="document.getElementById('review-form-<?= $o['id'] ?>').style.display = document.getElementById('review-form-<?= $o['id'] ?>').style.display === 'none' ? 'block' : 'none';">&#9733; Write a Review</button>
                                <div id="review-form-<?= $o['id'] ?>" class="review-form" style="display:none;">
                                    <form method="POST">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="submit_review">
                                        <input type="hidden" name="order_id" value="<?= $o['id'] ?>">

                                        <div style="margin-bottom:10px;">
                                            <div style="font-size:0.8125rem;font-weight:600;color:#374151;margin-bottom:6px;">Rating</div>
                                            <div class="star-rating">
                                                <?php for ($i = 5; $i >= 1; $i--): ?>
                                                    <input type="radio" name="rating" id="star<?= $i ?>_<?= $o['id'] ?>" value="<?= $i ?>" required>
                                                    <label for="star<?= $i ?>_<?= $o['id'] ?>">&#9733;</label>
                                                <?php endfor; ?>
                                            </div>
                                        </div>

                                        <textarea name="review_text" placeholder="Share your experience with this installer..." required minlength="10"></textarea>
                                        <button type="submit" class="btn btn-amber" style="width:100%;">Submit Review</button>
                                    </form>
                                </div>
                            </div>

                        <?php else: ?>
                            <!-- Show existing review -->
                            <div class="existing-review">
                                <div class="er-stars">
                                    <?php for ($i = 1; $i <= 5; $i++) echo $i <= $o['review_rating'] ? '&#9733;' : '&#9734;'; ?>
                                </div>
                                <div class="er-text"><?= nl2br(sanitize($o['review_text_existing'])) ?></div>
                            </div>
                        <?php endif; ?>

                    <?php elseif ($o['status'] === 'cancelled'): ?>
                        <?php if (!empty($o['cancel_reason'])): ?>
                            <div class="inst-cancel-reason"><?= sanitize($o['cancel_reason']) ?></div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
