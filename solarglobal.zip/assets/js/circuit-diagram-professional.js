﻿/**
 * Professional Circuit Diagram with Real Pinpoint Mapping
 * Uses actual pinpoint data from database
 */

/**
 * Render professional circuit diagram with pinpoints
 */
function renderProfessionalCircuitDiagram(selectedSystem) {

    const canvas = document.getElementById('circuit-diagram-canvas');
    if (!canvas) {
        console.error('Circuit diagram canvas not found!');
        return;
    }
    
    const { inverter, battery_config, panel_config } = selectedSystem;
    const loadAnalysis = window.appState.recommendations.load_analysis;

    // Detect system type — on-grid systems have no battery
    const invType = (inverter.inverter_type || inverter.type || '').toLowerCase().replace(/[\s_]/g, '-');
    const isOnGrid = invType === 'on-grid' || invType === 'grid-tie' || invType === 'ongrid';
    const hasBatteries = !isOnGrid
        && battery_config
        && battery_config.battery
        && (battery_config.quantity || battery_config.battery_count || 0) > 0;

    // Parse pinpoints from JSON with error handling
    let inverterPinpoints = [];
    let batteryPinpoints = [];
    let panelPinpoints = [];
    
    try {
        if (inverter.pinpoints && inverter.pinpoints !== 'null' && inverter.pinpoints !== '') {
            inverterPinpoints = JSON.parse(inverter.pinpoints);
        }
    } catch (e) {
        console.warn('Failed to parse inverter pinpoints:', e);
    }
    
    try {
        if (hasBatteries && battery_config.battery.pinpoints && battery_config.battery.pinpoints !== 'null' && battery_config.battery.pinpoints !== '') {
            batteryPinpoints = JSON.parse(battery_config.battery.pinpoints);
        }
    } catch (e) {
        console.warn('Failed to parse battery pinpoints:', e);
    }
    
    try {
        if (panel_config.panel.pinpoints && panel_config.panel.pinpoints !== 'null' && panel_config.panel.pinpoints !== '') {
            panelPinpoints = JSON.parse(panel_config.panel.pinpoints);
        }
    } catch (e) {
        console.warn('Failed to parse panel pinpoints:', e);
    }


    try {
        canvas.innerHTML = `
            <div class="professional-circuit-diagram">
                <h3 style="text-align: center; color: #0D3B6E; margin-bottom: 24px;">
                    🔌 Professional System Wiring Diagram
                </h3>
                
                <div class="diagram-grid ${isOnGrid || !hasBatteries ? 'no-battery-layout' : ''}">
                    <!-- Solar Panels Section -->
                    <div class="diagram-section panels-section">
                        ${renderPanelSection(panel_config, panelPinpoints)}
                    </div>

                    <!-- Inverter Section (Center) -->
                    <div class="diagram-section inverter-section">
                        ${renderInverterSection(inverter, inverterPinpoints, loadAnalysis)}
                    </div>

                    ${hasBatteries ? `
                    <!-- Battery Section -->
                    <div class="diagram-section battery-section">
                        ${renderBatterySection(battery_config, batteryPinpoints)}
                    </div>
                    ` : ''}

                    <!-- Loads Section -->
                    <div class="diagram-section loads-section">
                        ${renderLoadsSection(loadAnalysis)}
                    </div>
                </div>
                
                <!-- Connection Lines SVG Overlay -->
                <svg class="connection-lines" viewBox="0 0 1000 800" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none;">
                    <defs>
                        <marker id="arrowRed" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                            <polygon points="0 0, 10 3, 0 6" fill="#EF4444"/>
                        </marker>
                        <marker id="arrowBlack" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                            <polygon points="0 0, 10 3, 0 6" fill="#000000"/>
                        </marker>
                        <marker id="arrowOrange" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                            <polygon points="0 0, 10 3, 0 6" fill="#F59E0B"/>
                        </marker>
                        <marker id="arrowGreen" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                            <polygon points="0 0, 10 3, 0 6" fill="#10B981"/>
                        </marker>
                    </defs>
                    
                    <!-- Animated connection lines will be drawn here -->
                    ${renderConnectionLines(panel_config, battery_config, inverter, hasBatteries)}
                </svg>
                
                <!-- Wiring Specifications -->
                <div class="wiring-specs-panel">
                    <h4>📋 Wiring Specifications</h4>
                    <div class="specs-grid">
                        <div class="spec-item">
                            <strong>Solar DC Cable:</strong>
                            <span>6mm² (${Math.ceil(panel_config.total_wattage / panel_config.string_voltage)}A)</span>
                        </div>
                        ${hasBatteries ? `
                        <div class="spec-item">
                            <strong>Battery Cable:</strong>
                            <span>16mm² (${Math.ceil(loadAnalysis.total_load_watts / parseInt(inverter.voltage_class))}A)</span>
                        </div>
                        ` : ''}
                        <div class="spec-item">
                            <strong>AC Load Cable:</strong>
                            <span>4mm² (${Math.ceil(loadAnalysis.total_load_watts / 230)}A)</span>
                        </div>
                        <div class="spec-item">
                            <strong>String Voltage:</strong>
                            <span>${panel_config.string_voltage}V DC</span>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Animate the diagram
        animateDiagram();
        
    } catch (error) {
        console.error('Error rendering circuit diagram:', error);
        // Fallback to basic diagram
        canvas.innerHTML = `
            <div style="padding: 40px; text-align: center; background: #FEF3C7; border-radius: 12px; border: 2px solid #F59E0B;">
                <div style="font-size: 48px; margin-bottom: 16px;">⚠️</div>
                <h3 style="color: #D97706; margin-bottom: 12px;">Circuit Diagram Loading Issue</h3>
                <p style="color: #92400E;">There was an issue loading the professional diagram. Please check the browser console for details.</p>
                <button onclick="location.reload()" class="btn btn-primary" style="margin-top: 20px;">Reload Page</button>
            </div>
        `;
    }
}

/**
 * Render panel section with pinpoints or placeholder
 */
function renderPanelSection(panelConfig, pinpoints) {
    const hasImage = panelConfig.panel.image_path && panelConfig.panel.image_path !== '';
    const hasPositive = pinpoints.find(p => p.type === 'positive');
    const hasNegative = pinpoints.find(p => p.type === 'negative');

    // E1: Multi-MPPT string calculation
    const mpptCount = parseInt(window.appState?.selectedSystem?.inverter?.mppt_channels || window.appState?.selectedSystem?.inverter?.mppt_count || 1);
    const totalPanels = panelConfig.quantity || 0;
    const panelVmp = parseFloat(panelConfig.panel?.vmp || panelConfig.panel?.voc * 0.8 || 30);
    const maxInputV = parseFloat(window.appState?.selectedSystem?.inverter?.max_pv_input_voltage || 450);

    // Calculate optimal string config per MPPT
    const panelsPerString = Math.max(1, Math.floor(maxInputV / panelVmp));
    const totalStrings = Math.max(1, Math.ceil(totalPanels / panelsPerString));
    const stringsPerMppt = Math.ceil(totalStrings / mpptCount);

    let mpptConfigHtml = '';
    if (mpptCount > 1) {
        mpptConfigHtml = `<div class="mppt-config">`;
        let panelsAssigned = 0;
        for (let m = 0; m < mpptCount; m++) {
            const stringsThisMppt = Math.min(stringsPerMppt, Math.ceil((totalPanels - panelsAssigned) / panelsPerString));
            const panelsThisMppt = Math.min(stringsThisMppt * panelsPerString, totalPanels - panelsAssigned);
            if (panelsThisMppt <= 0) break;

            mpptConfigHtml += `
                <div class="mppt-row">
                    <span class="mppt-label">MPPT ${m + 1}:</span>
                    <span class="mppt-detail">${panelsThisMppt} panels (${stringsThisMppt} string${stringsThisMppt > 1 ? 's' : ''} × ${panelsPerString} series)</span>
                </div>`;
            panelsAssigned += panelsThisMppt;
        }
        mpptConfigHtml += `</div>`;
    }

    return `
        <div class="component-card">
            <div class="component-header">
                <span class="component-icon">☀️</span>
                <h4>Solar Panels</h4>
                ${mpptCount > 1 ? `<span class="badge badge-mppt">${mpptCount} MPPT</span>` : ''}
            </div>

            <div class="component-body">
                <div class="product-display">
                    ${hasImage ? `
                        <div class="product-image-container" style="position: relative;">
                            <img src="${panelConfig.panel.image_path}" alt="${panelConfig.panel.name}" class="product-image">
                            ${renderPinpointsOnImage(pinpoints)}
                        </div>
                    ` : `
                        <div class="product-placeholder">
                            <div class="placeholder-box">
                                <div class="placeholder-icon">☀️</div>
                                <div class="placeholder-text">${panelConfig.panel.name}</div>
                                ${renderPlaceholderPinpoints(['positive', 'negative'])}
                            </div>
                        </div>
                    `}
                </div>

                <div class="component-info">
                    <div class="info-row">
                        <strong>${panelConfig.quantity}× ${panelConfig.panel.watt_peak || panelConfig.panel.wattage}W</strong>
                    </div>
                    <div class="info-row">
                        <span class="badge">${panelConfig.wiring || (totalStrings + ' strings × ' + panelsPerString + ' series')}</span>
                    </div>
                    <div class="info-row">
                        <span class="voltage-label">String: ${panelConfig.string_voltage || Math.round(panelVmp * panelsPerString)}V DC</span>
                    </div>
                    ${mpptConfigHtml}
                </div>
            </div>
        </div>
    `;
}

/**
 * Render inverter section with pinpoints or placeholder
 */
function renderInverterSection(inverter, pinpoints, loadAnalysis) {
    const hasImage = inverter.image_path && inverter.image_path !== '';
    const isThreePhase = inverter.three_phase == 1 || window.appState?.selectedPhase === 3;
    const mpptCount = parseInt(inverter.mppt_channels || inverter.mppt_count || 1);

    // E2: 3-phase output display
    let phaseHtml = '';
    if (isThreePhase) {
        phaseHtml = `
            <div class="phase-output">
                <div class="phase-line phase-l1"><span>L1</span></div>
                <div class="phase-line phase-l2"><span>L2</span></div>
                <div class="phase-line phase-l3"><span>L3</span></div>
                <div class="phase-line phase-n"><span>N</span></div>
            </div>`;
    }

    return `
        <div class="component-card inverter-card">
            <div class="component-header">
                <span class="component-icon">⚡</span>
                <h4>Inverter</h4>
                ${isThreePhase ? '<span class="badge badge-phase">3Φ</span>' : '<span class="badge badge-phase">1Φ</span>'}
            </div>

            <div class="component-body">
                <div class="product-display">
                    ${hasImage ? `
                        <div class="product-image-container" style="position: relative;">
                            <img src="${inverter.image_path}" alt="${inverter.name}" class="product-image">
                            ${renderPinpointsOnImage(pinpoints)}
                        </div>
                    ` : `
                        <div class="product-placeholder">
                            <div class="placeholder-box large">
                                <div class="placeholder-icon">⚡</div>
                                <div class="placeholder-text">${inverter.name}</div>
                                ${renderPlaceholderPinpoints([
                                    'solar-input',
                                    'battery-positive',
                                    'battery-negative',
                                    isThreePhase ? 'load-l1' : 'load-l1',
                                    isThreePhase ? 'load-l2' : 'load-n',
                                    isThreePhase ? 'load-l3' : '',
                                    'grid-import'
                                ].filter(Boolean))}
                            </div>
                        </div>
                    `}
                </div>

                <div class="component-info">
                    <div class="info-row">
                        <strong>${inverter.name}</strong>
                    </div>
                    <div class="info-row">
                        <span class="badge">${inverter.voltage_class || inverter.vdc_type || '48V'}</span>
                        <span class="badge">${inverter.max_load_watts || inverter.power_rating}W</span>
                        ${mpptCount > 1 ? `<span class="badge badge-mppt">${mpptCount} MPPT</span>` : ''}
                    </div>
                    <div class="info-row">
                        <span class="badge">${inverter.inverter_type || inverter.type || 'Hybrid'}</span>
                        ${isThreePhase ? '<span class="badge badge-3phase">Three Phase</span>' : ''}
                    </div>
                    ${phaseHtml}
                </div>
            </div>
        </div>
    `;
}

/**
 * Render battery section with pinpoints or placeholder
 */
function renderBatterySection(batteryConfig, pinpoints) {
    const hasImage = batteryConfig.battery.image_path && batteryConfig.battery.image_path !== '';
    const series = parseInt(batteryConfig.series || 1);
    const parallel = parseInt(batteryConfig.parallel || 1);
    const battV = parseFloat(batteryConfig.battery.voltage || 12);

    // E3: Battery series/parallel visual grid
    let batteryGridHtml = '';
    if (batteryConfig.quantity > 1) {
        batteryGridHtml = `<div class="battery-grid-visual">`;

        // Show voltage progression for series connections
        if (series > 1) {
            batteryGridHtml += `<div class="battery-series-label">${series}S — Series (voltage adds up)</div>`;
        }
        if (parallel > 1) {
            batteryGridHtml += `<div class="battery-parallel-label">${parallel}P — Parallel (capacity adds up)</div>`;
        }

        // Draw grid: rows = parallel strings, columns = series batteries
        for (let p = 0; p < parallel; p++) {
            batteryGridHtml += `<div class="battery-grid-row">`;
            let runningV = 0;
            for (let s = 0; s < series; s++) {
                runningV += battV;
                const isLast = (s === series - 1);
                batteryGridHtml += `
                    <div class="battery-grid-cell">
                        <div class="battery-grid-icon">🔋</div>
                        <div class="battery-grid-v">${battV}V</div>
                        ${!isLast ? '<div class="battery-grid-plus">+</div>' : ''}
                    </div>`;
            }
            batteryGridHtml += `
                <div class="battery-grid-total">= ${Math.round(runningV)}V</div>
            </div>`;
        }
        if (parallel > 1) {
            batteryGridHtml += `<div class="battery-grid-summary">
                ${parallel} parallel strings × ${batteryConfig.battery.capacity_ah}Ah = ${batteryConfig.total_ah}Ah total
            </div>`;
        }
        batteryGridHtml += `</div>`;
    }

    return `
        <div class="component-card">
            <div class="component-header">
                <span class="component-icon">🔋</span>
                <h4>Battery Bank</h4>
                ${batteryConfig.battery.has_bms == 1 || batteryConfig.battery.is_bms == 1 ? '<span class="badge badge-bms">BMS</span>' : ''}
            </div>

            <div class="component-body">
                <div class="product-display">
                    ${hasImage ? `
                        <div class="product-image-container" style="position: relative;">
                            <img src="${batteryConfig.battery.image_path}" alt="${batteryConfig.battery.name}" class="product-image">
                            ${renderPinpointsOnImage(pinpoints)}
                        </div>
                    ` : `
                        <div class="product-placeholder">
                            <div class="placeholder-box">
                                <div class="placeholder-icon">🔋</div>
                                <div class="placeholder-text">${batteryConfig.battery.name}</div>
                                ${renderPlaceholderPinpoints(['positive', 'negative'])}
                            </div>
                        </div>
                    `}
                </div>

                <div class="component-info">
                    <div class="info-row">
                        <strong>${batteryConfig.quantity}× ${batteryConfig.battery.capacity_ah}Ah ${batteryConfig.battery.type || ''}</strong>
                    </div>
                    <div class="info-row">
                        <span class="badge">Total: ${batteryConfig.total_ah}Ah</span>
                        <span class="badge">${batteryConfig.usable_kwh || '?'}kWh usable</span>
                    </div>
                    <div class="info-row">
                        <span class="wiring-label">${batteryConfig.wiring}</span>
                    </div>
                    <div class="info-row">
                        <span class="backup-label">⚡ ${batteryConfig.backup_hours}h Backup</span>
                    </div>
                </div>

                ${batteryGridHtml}
            </div>
        </div>
    `;
}

/**
 * Render loads section
 */
function renderLoadsSection(loadAnalysis) {
    return `
        <div class="component-card">
            <div class="component-header">
                <span class="component-icon">🏠</span>
                <h4>Your Loads</h4>
            </div>
            
            <div class="component-body">
                <div class="loads-display">
                    <div class="load-icon-large">🏠</div>
                    <div class="load-details">
                        <div class="load-item">
                            <strong>Total Load:</strong>
                            <span>${loadAnalysis.total_load_watts}W</span>
                        </div>
                        <div class="load-item">
                            <strong>Appliances:</strong>
                            <span>${loadAnalysis.appliance_details.length} items</span>
                        </div>
                        <div class="load-item">
                            <strong>Daily Usage:</strong>
                            <span>${loadAnalysis.daily_energy_kwh} kWh</span>
                        </div>
                    </div>
                </div>
                
                <div class="appliances-list">
                    ${loadAnalysis.appliance_details.slice(0, 5).map(app => `
                        <div class="appliance-mini">
                            ${app.image_path ? 
                                `<img src="${app.image_path}" style="width:20px;height:20px;">` : 
                                `<span style="font-size:16px;">${app.icon}</span>`
                            }
                            <span>${app.name_en}</span>
                        </div>
                    `).join('')}
                    ${loadAnalysis.appliance_details.length > 5 ? 
                        `<div class="appliance-mini">+${loadAnalysis.appliance_details.length - 5} more</div>` : 
                        ''
                    }
                </div>
            </div>
        </div>
    `;
}

/**
 * Render pinpoints on actual product image
 */
function renderPinpointsOnImage(pinpoints) {
    if (!pinpoints || pinpoints.length === 0) return '';
    
    const colors = {
        'positive': '#EF4444',
        'negative': '#000000',
        'battery-positive': '#EF4444',
        'battery-negative': '#000000',
        'solar-input': '#F59E0B',
        'load-l1': '#3B82F6',
        'load-l2': '#8B5CF6',
        'load-l3': '#06B6D4',
        'grid-import': '#10B981'
    };
    
    return pinpoints.map(pin => `
        <div class="pinpoint-marker" 
             style="position: absolute; 
                    left: ${pin.x}%; 
                    top: ${pin.y}%; 
                    transform: translate(-50%, -50%);
                    width: 12px;
                    height: 12px;
                    background: ${colors[pin.type] || '#666'};
                    border: 2px solid white;
                    border-radius: 50%;
                    box-shadow: 0 2px 6px rgba(0,0,0,0.3);
                    z-index: 10;">
        </div>
        <div class="pinpoint-label" 
             style="position: absolute; 
                    left: ${pin.x}%; 
                    top: ${pin.y}%; 
                    transform: translate(-50%, -25px);
                    background: rgba(0,0,0,0.8);
                    color: white;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-size: 9px;
                    white-space: nowrap;
                    z-index: 11;">
            ${pin.label}
        </div>
    `).join('');
}

/**
 * Render placeholder pinpoints when no image
 */
function renderPlaceholderPinpoints(types) {
    const positions = {
        'positive': { x: 80, y: 20, label: '+', color: '#EF4444' },
        'negative': { x: 80, y: 80, label: '-', color: '#000000' },
        'battery-positive': { x: 20, y: 60, label: 'BAT+', color: '#EF4444' },
        'battery-negative': { x: 20, y: 80, label: 'BAT-', color: '#000000' },
        'solar-input': { x: 50, y: 10, label: 'SOLAR', color: '#F59E0B' },
        'load-l1': { x: 80, y: 40, label: 'L1', color: '#3B82F6' },
        'load-l2': { x: 80, y: 60, label: 'L2', color: '#8B5CF6' },
        'grid-import': { x: 50, y: 90, label: 'GRID', color: '#10B981' }
    };
    
    return types.map(type => {
        const pos = positions[type];
        if (!pos) return '';
        
        return `
            <div class="placeholder-pinpoint" 
                 style="position: absolute; 
                        left: ${pos.x}%; 
                        top: ${pos.y}%; 
                        transform: translate(-50%, -50%);
                        background: ${pos.color};
                        color: white;
                        width: 24px;
                        height: 24px;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 10px;
                        font-weight: bold;
                        border: 2px solid white;
                        box-shadow: 0 2px 6px rgba(0,0,0,0.3);">
                ${pos.label}
            </div>
        `;
    }).join('');
}

/**
 * Render connection lines between components
 */
function renderConnectionLines(panelConfig, batteryConfig, inverter, hasBatteries) {
    let lines = `
        <!-- Solar to Inverter -->
        <path d="M 250 200 L 250 350"
              stroke="#F59E0B"
              stroke-width="4"
              fill="none"
              marker-end="url(#arrowOrange)"
              class="connection-line solar-line"/>
        <text x="260" y="275" fill="#F59E0B" font-size="12" font-weight="600">
            ${panelConfig.string_voltage}V DC
        </text>
    `;

    if (hasBatteries) {
        lines += `
        <!-- Battery to Inverter (Positive) -->
        <path d="M 150 600 L 200 450"
              stroke="#EF4444"
              stroke-width="4"
              fill="none"
              marker-end="url(#arrowRed)"
              class="connection-line battery-pos-line"/>

        <!-- Battery to Inverter (Negative) -->
        <path d="M 180 620 L 230 470"
              stroke="#000000"
              stroke-width="4"
              fill="none"
              marker-end="url(#arrowBlack)"
              class="connection-line battery-neg-line"/>
        <text x="160" y="530" fill="#EF4444" font-size="12" font-weight="600">
            ${inverter.voltage_class}
        </text>
        `;
    }

    lines += `
        <!-- Inverter to Loads -->
        <path d="M 550 400 L 750 600"
              stroke="#10B981"
              stroke-width="4"
              fill="none"
              marker-end="url(#arrowGreen)"
              class="connection-line load-line"/>
        <text x="640" y="490" fill="#10B981" font-size="12" font-weight="600">
            230V AC
        </text>
    `;

    return lines;
}

/**
 * Animate diagram entrance
 */
function animateDiagram() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    
    // Animate component cards
    anime({
        targets: '.component-card',
        scale: [0.9, 1],
        opacity: [0, 1],
        duration: 600,
        delay: anime.stagger(150),
        easing: 'easeOutBack'
    });
    
    // Animate connection lines
    anime({
        targets: '.connection-line',
        strokeDashoffset: [anime.setDashoffset, 0],
        duration: 1500,
        delay: 800,
        easing: 'easeInOutQuad'
    });
}
