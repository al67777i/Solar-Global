-- ============================================
-- SolarGlobal Marketplace Tables
-- Run this in MySQL: mysql -u root solarglobal < marketplace_tables.sql
-- ============================================

-- Countries table
CREATE TABLE IF NOT EXISTS countries (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(3) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  currency_code VARCHAR(3) NOT NULL DEFAULT 'USD',
  currency_symbol VARCHAR(5) NOT NULL DEFAULT '$',
  grid_voltage INT DEFAULT 230,
  grid_frequency INT DEFAULT 50,
  electricity_rate_kwh DECIMAL(8,4) NULL,
  net_metering_available TINYINT(1) DEFAULT 0,
  tax_rate_pct DECIMAL(4,2) DEFAULT 0,
  is_supported TINYINT(1) DEFAULT 0,
  flag_emoji VARCHAR(10) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_supported (is_supported),
  INDEX idx_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Import logs
CREATE TABLE IF NOT EXISTS import_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT NOT NULL,
  product_type ENUM('inverter','battery','panel','appliance') NOT NULL,
  country_code VARCHAR(3) DEFAULT 'global',
  filename VARCHAR(255) NOT NULL,
  total_rows INT DEFAULT 0,
  inserted INT DEFAULT 0,
  updated INT DEFAULT 0,
  skipped INT DEFAULT 0,
  errors INT DEFAULT 0,
  error_details JSON NULL,
  status ENUM('processing','completed','failed') DEFAULT 'processing',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_admin (admin_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Image library
CREATE TABLE IF NOT EXISTS image_library (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filename VARCHAR(255) NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  file_path VARCHAR(500) NOT NULL,
  thumbnail_path VARCHAR(500) NULL,
  folder ENUM('inverters','batteries','panels','dealers','appliances','general') DEFAULT 'general',
  mime_type VARCHAR(50) NOT NULL,
  file_size INT NOT NULL DEFAULT 0,
  width INT NULL,
  height INT NULL,
  alt_text VARCHAR(255) NULL,
  tags VARCHAR(500) NULL,
  uploaded_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_folder (folder),
  FULLTEXT idx_search (filename, original_filename, alt_text, tags)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed countries
INSERT IGNORE INTO countries (code, name, currency_code, currency_symbol, grid_voltage, grid_frequency, electricity_rate_kwh, is_supported, flag_emoji) VALUES
('PK', 'Pakistan', 'PKR', 'Rs', 230, 50, 55.0000, 1, '🇵🇰'),
('IN', 'India', 'INR', '₹', 230, 50, 8.0000, 1, '🇮🇳'),
('US', 'United States', 'USD', '$', 120, 60, 0.1600, 1, '🇺🇸'),
('GB', 'United Kingdom', 'GBP', '£', 230, 50, 0.3400, 1, '🇬🇧'),
('AU', 'Australia', 'AUD', 'A$', 230, 50, 0.3000, 1, '🇦🇺'),
('DE', 'Germany', 'EUR', '€', 230, 50, 0.4000, 1, '🇩🇪'),
('AE', 'UAE', 'AED', 'د.إ', 220, 50, 0.0800, 1, '🇦🇪'),
('SA', 'Saudi Arabia', 'SAR', 'ر.س', 220, 60, 0.0500, 1, '🇸🇦'),
('ZA', 'South Africa', 'ZAR', 'R', 230, 50, 2.5000, 1, '🇿🇦'),
('CA', 'Canada', 'CAD', 'C$', 120, 60, 0.1300, 1, '🇨🇦'),
('FR', 'France', 'EUR', '€', 230, 50, 0.2500, 0, '🇫🇷'),
('IT', 'Italy', 'EUR', '€', 230, 50, 0.3500, 0, '🇮🇹'),
('ES', 'Spain', 'EUR', '€', 230, 50, 0.2800, 0, '🇪🇸'),
('BR', 'Brazil', 'BRL', 'R$', 220, 60, 0.7500, 0, '🇧🇷'),
('NG', 'Nigeria', 'NGN', '₦', 230, 50, 65.0000, 0, '🇳🇬'),
('BD', 'Bangladesh', 'BDT', '৳', 220, 50, 6.0000, 0, '🇧🇩'),
('TR', 'Turkey', 'TRY', '₺', 230, 50, 3.5000, 0, '🇹🇷'),
('EG', 'Egypt', 'EGP', 'E£', 220, 50, 1.5000, 0, '🇪🇬');

-- Add country_code to product tables
ALTER TABLE inverters ADD COLUMN IF NOT EXISTS country_code VARCHAR(3) DEFAULT 'global';
ALTER TABLE batteries ADD COLUMN IF NOT EXISTS country_code VARCHAR(3) DEFAULT 'global';
ALTER TABLE panels ADD COLUMN IF NOT EXISTS country_code VARCHAR(3) DEFAULT 'global';
