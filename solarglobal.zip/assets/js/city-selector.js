/**
 * City Selector Module
 * Step 0: Select installation city for weather-based recommendations
 */

(function() {
    'use strict';

    let cities = [];
    let selectedCity = null;
    let currentProvince = 'all';
    let highlightIndex = -1;

    const provinceIcons = {
        'Punjab': '🌾',
        'Sindh': '🏖️',
        'KPK': '⛰️',
        'Balochistan': '🏜️',
        'Islamabad': '🏛️',
        'AJK': '🏔️',
        'Gilgit-Baltistan': '🗻'
    };

    async function init() {
        try {
            const response = await fetch('api/cities.php?action=list');
            const result = await response.json();
            if (result.success) {
                cities = result.data;
                renderCityGrid();
                setupEventListeners();
                restoreSavedCity();
            }
        } catch (error) {
            console.error('Failed to load cities:', error);
        }
    }

    function restoreSavedCity() {
        let savedCityId = null;
        try { savedCityId = localStorage.getItem('selectedCityId'); } catch (e) { return; }
        if (savedCityId) {
            const city = cities.find(c => c.id == savedCityId);
            if (city) {
                selectCity(city, true);
                // Show badge immediately on restore
                const badge = document.getElementById('city-badge');
                const badgeName = document.getElementById('city-badge-name');
                if (badge && badgeName) {
                    badgeName.textContent = city.name_en;
                    badge.style.display = 'inline-flex';
                    badge.onclick = () => goToStep(0);
                }
            }
        }
    }

    function renderCityGrid() {
        const grid = document.getElementById('city-grid');
        if (!grid) return;

        const filtered = currentProvince === 'all'
            ? cities
            : cities.filter(c => c.province === currentProvince);

        if (filtered.length === 0) {
            grid.innerHTML = `
                <div class="city-no-results">
                    <div class="no-results-icon">🔍</div>
                    <p>No cities found</p>
                </div>`;
            return;
        }

        grid.innerHTML = filtered.map(city => `
            <div class="city-card ${selectedCity && selectedCity.id == city.id ? 'selected' : ''}"
                 data-city-id="${city.id}"
                 data-city-name="${city.name_en}">
                <span class="city-card-icon">${provinceIcons[city.province] || '📍'}</span>
                <div class="city-card-info">
                    <div class="city-card-name">${city.name_en}</div>
                    <div class="city-card-meta">${city.province}</div>
                </div>
                <div class="city-card-check">${selectedCity && selectedCity.id == city.id ? '✓' : ''}</div>
            </div>
        `).join('');

        grid.querySelectorAll('.city-card').forEach(card => {
            card.addEventListener('click', () => {
                const cityId = card.dataset.cityId;
                const city = cities.find(c => c.id == cityId);
                if (city) selectCity(city);
            });
        });
    }

    function selectCity(city, silent = false) {
        selectedCity = city;

        try {
            localStorage.setItem('selectedCityId', city.id);
            localStorage.setItem('selectedCityName', city.name_en);
        } catch (e) { /* Ignore localStorage errors (e.g. incognito mode) */ }

        if (window.appState) {
            window.appState.selectedCity = city;
        }

        // Persist to server session
        fetch('api/set_city.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ city_id: city.id })
        }).catch(() => {});

        renderCityGrid();
        showSelectedCity(city);

        // Show loading state on solar potential preview immediately
        const preview = document.querySelector('.solar-potential-preview');
        if (preview) {
            preview.classList.add('active');
            const statsGrid = preview.querySelector('.solar-stats-grid');
            if (statsGrid) {
                statsGrid.innerHTML = `
                    <div class="solar-stats-loading">
                        <div class="loading-sun-mini"></div>
                        <p>Loading solar data for ${city.name_en}...</p>
                    </div>
                `;
            }
        }

        fetchSunData(city.id);

        const continueBtn = document.getElementById('btn-city-continue');
        if (continueBtn) continueBtn.disabled = false;

        if (!silent) {
            try {
                if (typeof anime !== 'undefined') {
                    const display = document.querySelector('.selected-city-display');
                    if (display) {
                        anime({
                            targets: display,
                            scale: [0.95, 1],
                            opacity: [0, 1],
                            duration: 400,
                            easing: 'easeOutBack'
                        });
                    }
                }
            } catch(e) {}
        }
    }

    function showSelectedCity(city) {
        const display = document.querySelector('.selected-city-display');
        if (!display) return;

        display.classList.add('active');
        display.querySelector('.city-big-icon').textContent = provinceIcons[city.province] || '📍';
        display.querySelector('.city-details h3').textContent = city.name_en;
        display.querySelector('.city-details p').textContent = `${city.province} • Elevation: ${city.elevation_m}m • Lat: ${parseFloat(city.latitude).toFixed(2)}°N`;

        // Update header badge
        const badge = document.getElementById('city-badge');
        const badgeName = document.getElementById('city-badge-name');
        if (badge && badgeName) {
            badgeName.textContent = city.name_en;
            badge.style.display = 'inline-flex';
            badge.onclick = () => goToStep(0);
        }
    }

    async function fetchSunData(cityId) {
        try {
            const currentMonth = new Date().getMonth() + 1;
            const [sunResponse, weatherResponse] = await Promise.all([
                fetch(`api/cities.php?action=sun_data&city_id=${cityId}&month=${currentMonth}`),
                fetch(`api/weather.php?action=summary&city_id=${cityId}`)
            ]);

            const sunResult = await sunResponse.json();
            const weatherResult = await weatherResponse.json();

            if (sunResult.success && sunResult.data) {
                displaySunData(sunResult.data, weatherResult.success ? weatherResult.data : null);
            }
        } catch (error) {
            console.error('Failed to fetch sun/weather data:', error);
        }
    }

    function displaySunData(sunData, weatherData) {
        const preview = document.querySelector('.solar-potential-preview');
        if (!preview) return;

        preview.classList.add('active');

        const statsGrid = preview.querySelector('.solar-stats-grid');

        // Use live weather data if available, fallback to historical
        const temp = weatherData ? weatherData.avg_temperature : sunData.avg_temperature_c;
        const irradiance = weatherData ? weatherData.avg_daily_irradiance : sunData.avg_irradiance_kwh_m2;
        const sunHours = weatherData ? weatherData.avg_sunshine_hours : sunData.peak_sun_hours;
        const solarRating = weatherData ? weatherData.solar_rating : Math.round(sunData.panel_efficiency_factor * 5);
        const stars = '★'.repeat(solarRating) + '☆'.repeat(5 - solarRating);

        let weatherBadge = '';
        if (weatherData) {
            weatherBadge = `
                <div class="solar-stat-card" style="grid-column: span 4; background: linear-gradient(135deg, #FEF3C7, #FDE68A); border-color: #F59E0B;">
                    <div style="display:flex; align-items:center; gap:12px; justify-content:center;">
                        <span style="font-size:1.5rem;">${getWeatherIcon(weatherData.outlook)}</span>
                        <span style="font-weight:600; color:#92400E;">${weatherData.outlook} • Live Weather Data</span>
                        <span style="color:#B45309; font-size:0.8rem;">(${weatherData.days}-day avg)</span>
                    </div>
                </div>
            `;
        }

        statsGrid.innerHTML = `
            ${weatherBadge}
            <div class="solar-stat-card">
                <div class="stat-icon">☀️</div>
                <div class="stat-value">${sunHours}h</div>
                <div class="stat-label">Sunshine Hours</div>
            </div>
            <div class="solar-stat-card">
                <div class="stat-icon">🌡️</div>
                <div class="stat-value">${temp}°C</div>
                <div class="stat-label">Temperature</div>
            </div>
            <div class="solar-stat-card">
                <div class="stat-icon">⚡</div>
                <div class="stat-value">${irradiance}</div>
                <div class="stat-label">kWh/m² Daily</div>
            </div>
            <div class="solar-stat-card">
                <div class="stat-icon">⭐</div>
                <div class="stat-value">${stars}</div>
                <div class="stat-label">Solar Rating</div>
            </div>
        `;

        // Update selected city display sun info
        const sunInfo = document.querySelector('.selected-city-display .city-sun-info');
        if (sunInfo) {
            sunInfo.innerHTML = `
                <div class="sun-stat">
                    <div class="stat-value">${sunHours}h</div>
                    <div class="stat-label">Sun Hours</div>
                </div>
                <div class="sun-stat">
                    <div class="stat-value">${temp}°C</div>
                    <div class="stat-label">Temperature</div>
                </div>
                <div class="sun-stat">
                    <div class="stat-value">${stars}</div>
                    <div class="stat-label">Solar Rating</div>
                </div>
            `;
        }

        // Store weather data for use in later steps
        if (weatherData && window.appState) {
            window.appState.weatherData = weatherData;
        }

        // Update weather-based background
        if (weatherData && window.WeatherBackground) {
            const hour = new Date().getHours();
            const isDay = hour >= 6 && hour < 19;
            const code = weatherData.weather_code ?? (
                weatherData.outlook === 'Rainy Week' ? 61 :
                weatherData.outlook === 'Cloudy Week' ? 3 :
                weatherData.outlook === 'Mixed Week' ? 2 : 0
            );
            window.WeatherBackground.update(code, isDay);
        }
    }

    function getWeatherIcon(outlook) {
        const icons = {
            'Sunny Week': '☀️',
            'Mixed Week': '⛅',
            'Cloudy Week': '☁️',
            'Rainy Week': '🌧️'
        };
        return icons[outlook] || '🌤️';
    }

    function setupEventListeners() {
        // Search input
        const searchInput = document.getElementById('city-search-input');
        if (searchInput) {
            searchInput.addEventListener('input', handleSearch);
            searchInput.addEventListener('focus', () => {
                if (searchInput.value.length > 0) handleSearch();
            });
            searchInput.addEventListener('keydown', handleSearchKeydown);
            document.addEventListener('click', (e) => {
                if (!e.target.closest('.city-search-container')) {
                    closeAutocomplete();
                }
            });
        }

        // Province tabs
        document.querySelectorAll('.province-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.province-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                currentProvince = tab.dataset.province;
                renderCityGrid();
            });
        });

        // Continue button
        const continueBtn = document.getElementById('btn-city-continue');
        if (continueBtn) {
            continueBtn.addEventListener('click', () => {
                if (selectedCity) {
                    goToStep(1);
                }
            });
        }

        // Change city button
        const changeBtn = document.querySelector('.btn-change-city');
        if (changeBtn) {
            changeBtn.addEventListener('click', () => {
                document.querySelector('.selected-city-display').classList.remove('active');
                document.querySelector('.solar-potential-preview').classList.remove('active');
                document.getElementById('city-search-input').focus();
            });
        }
    }

    function handleSearch() {
        const input = document.getElementById('city-search-input');
        const query = input.value.trim().toLowerCase();
        const dropdown = document.querySelector('.city-autocomplete');

        if (query.length < 1) {
            closeAutocomplete();
            return;
        }

        const matches = cities.filter(c =>
            c.name_en.toLowerCase().includes(query) ||
            c.province.toLowerCase().includes(query)
        ).slice(0, 8);

        if (matches.length === 0) {
            dropdown.innerHTML = `<div class="city-autocomplete-item"><span class="city-name">No cities found</span></div>`;
            dropdown.classList.add('active');
            return;
        }

        highlightIndex = -1;
        dropdown.innerHTML = matches.map((city, i) => `
            <div class="city-autocomplete-item" data-index="${i}" data-city-id="${city.id}">
                <span class="city-icon">${provinceIcons[city.province] || '📍'}</span>
                <span class="city-name">${highlightMatch(city.name_en, query)}</span>
                <span class="city-province">${city.province}</span>
            </div>
        `).join('');

        dropdown.classList.add('active');

        dropdown.querySelectorAll('.city-autocomplete-item').forEach(item => {
            item.addEventListener('click', () => {
                const cityId = item.dataset.cityId;
                const city = cities.find(c => c.id == cityId);
                if (city) {
                    selectCity(city);
                    input.value = city.name_en;
                    closeAutocomplete();
                }
            });
        });
    }

    function handleSearchKeydown(e) {
        const dropdown = document.querySelector('.city-autocomplete');
        const items = dropdown.querySelectorAll('.city-autocomplete-item[data-city-id]');

        if (!dropdown.classList.contains('active') || items.length === 0) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            highlightIndex = Math.min(highlightIndex + 1, items.length - 1);
            updateHighlight(items);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            highlightIndex = Math.max(highlightIndex - 1, 0);
            updateHighlight(items);
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightIndex >= 0 && items[highlightIndex]) {
                items[highlightIndex].click();
            }
        } else if (e.key === 'Escape') {
            closeAutocomplete();
        }
    }

    function updateHighlight(items) {
        items.forEach((item, i) => {
            item.classList.toggle('highlighted', i === highlightIndex);
        });
        if (highlightIndex >= 0 && items[highlightIndex]) {
            items[highlightIndex].scrollIntoView({ block: 'nearest' });
        }
    }

    function highlightMatch(text, query) {
        const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
        return text.replace(regex, '<strong style="color:#D97706">$1</strong>');
    }

    function closeAutocomplete() {
        const dropdown = document.querySelector('.city-autocomplete');
        if (dropdown) dropdown.classList.remove('active');
        highlightIndex = -1;
    }

    // Expose for external access
    window.citySelector = {
        init,
        getSelectedCity: () => selectedCity,
        getCityId: () => selectedCity ? selectedCity.id : null
    };

    // Auto-initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
