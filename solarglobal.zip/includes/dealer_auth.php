<?php
/**
 * Dealer Authentication Middleware
 * Include this at the top of any dealer-protected page
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('DEALER_SESSION_TIMEOUT', 7200); // 2 hours

/**
 * Check if dealer is logged in
 */
function is_dealer_logged_in(): bool {
    return isset($_SESSION['dealer_logged_in']) && $_SESSION['dealer_logged_in'] === true;
}

/**
 * Get current dealer ID
 */
function get_dealer_id(): ?int {
    return $_SESSION['dealer_id'] ?? null;
}

/**
 * Get current dealer data from session
 */
function get_dealer_session(): array {
    return [
        'id' => $_SESSION['dealer_id'] ?? null,
        'email' => $_SESSION['dealer_email'] ?? '',
        'business_name' => $_SESSION['dealer_business_name'] ?? '',
        'owner_name' => $_SESSION['dealer_owner_name'] ?? '',
        'status' => $_SESSION['dealer_status'] ?? '',
        'logo_path' => $_SESSION['dealer_logo'] ?? '',
    ];
}

/**
 * Require dealer login - redirect if not authenticated
 */
function require_dealer_login() {
    if (!is_dealer_logged_in()) {
        $_SESSION['dealer_redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: /solarglobal/dealer/login.php');
        exit();
    }

    // Check session timeout
    if (isset($_SESSION['dealer_last_activity'])) {
        if (time() - $_SESSION['dealer_last_activity'] > DEALER_SESSION_TIMEOUT) {
            dealer_logout();
            header('Location: /solarglobal/dealer/login.php?timeout=1');
            exit();
        }
    }

    // Update activity
    $_SESSION['dealer_last_activity'] = time();

    // Check if dealer is still active
    if (($_SESSION['dealer_status'] ?? '') === 'suspended') {
        dealer_logout();
        header('Location: /solarglobal/dealer/login.php?suspended=1');
        exit();
    }
}

/**
 * Login dealer - set session variables
 */
function dealer_login(array $dealer): void {
    session_regenerate_id(true);
    $_SESSION['dealer_logged_in'] = true;
    $_SESSION['dealer_id'] = (int)$dealer['id'];
    $_SESSION['dealer_email'] = $dealer['email'];
    $_SESSION['dealer_business_name'] = $dealer['business_name'];
    $_SESSION['dealer_owner_name'] = $dealer['owner_name'];
    $_SESSION['dealer_status'] = $dealer['status'];
    $_SESSION['dealer_logo'] = $dealer['logo_path'] ?? '';
    $_SESSION['dealer_last_activity'] = time();

    // Update last login (non-critical — don't let this break login flow)
    try {
        $db = getDB();
        $stmt = $db->prepare("UPDATE dealers SET last_login_at = NOW() WHERE id = ?");
        $stmt->execute([$dealer['id']]);
    } catch (Exception $e) {
        error_log("dealer_login: could not update last_login_at: " . $e->getMessage());
    }
}

/**
 * Logout dealer - destroy dealer session vars
 */
function dealer_logout(): void {
    unset(
        $_SESSION['dealer_logged_in'],
        $_SESSION['dealer_id'],
        $_SESSION['dealer_email'],
        $_SESSION['dealer_business_name'],
        $_SESSION['dealer_owner_name'],
        $_SESSION['dealer_status'],
        $_SESSION['dealer_logo'],
        $_SESSION['dealer_last_activity'],
        $_SESSION['dealer_redirect_after_login']
    );
}

/**
 * Get full dealer profile from database
 */
function get_dealer_profile(?int $dealer_id = null): ?array {
    $id = $dealer_id ?? get_dealer_id();
    if (!$id) return null;

    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM dealers WHERE id = ?");
    $stmt->execute([$id]);
    $dealer = $stmt->fetch();

    if ($dealer) {
        unset($dealer['password_hash']); // Never expose password hash
    }

    return $dealer ?: null;
}

/**
 * Count dealer's products
 */
function get_dealer_product_count(?int $dealer_id = null): int {
    $id = $dealer_id ?? get_dealer_id();
    if (!$id) return 0;

    $db = getDB();
    $stmt = $db->prepare("SELECT COUNT(*) FROM dealer_products WHERE dealer_id = ? AND is_active = 1");
    $stmt->execute([$id]);
    return (int)$stmt->fetchColumn();
}

/**
 * Check if dealer has an active subscription (paid, free trial, or grace period)
 * Returns: ['active' => bool, 'reason' => string, 'trial' => bool, 'trial_days_left' => int,
 *           'grace' => bool, 'grace_days_left' => int]
 */
function check_dealer_subscription(?int $dealer_id = null): array {
    $id = $dealer_id ?? get_dealer_id();
    $base = ['active' => false, 'reason' => 'not_logged_in', 'trial' => false, 'trial_days_left' => 0, 'grace' => false, 'grace_days_left' => 0];

    if (!$id) return $base;

    $db = getDB();
    $dealer = get_dealer_profile($id);
    if (!$dealer) return array_merge($base, ['reason' => 'not_found']);

    // If suspended/rejected, never active
    if (in_array($dealer['status'], ['suspended', 'rejected'])) {
        return array_merge($base, ['reason' => 'suspended']);
    }

    $subStatus = $dealer['subscription_status'] ?? 'none';
    $now = time();

    // 1. Paid active subscription
    if ($subStatus === 'active') {
        $expires = $dealer['subscription_expires_at'] ?? null;
        if (!$expires || strtotime($expires) > $now) {
            return array_merge($base, ['active' => true, 'reason' => 'paid']);
        }
        // Expired but status not yet updated by cron — treat as expired
    }

    // 2. Grace period: subscription expired but within grace window
    //    Store is still visible during grace but user gets warnings
    $graceEnd = $dealer['grace_period_ends_at'] ?? null;
    if ($graceEnd && strtotime($graceEnd) > $now && in_array($subStatus, ['expired', 'past_due', 'canceled'])) {
        $graceDaysLeft = (int)ceil((strtotime($graceEnd) - $now) / 86400);
        return array_merge($base, [
            'active' => true,  // Still active during grace — store visible, features work
            'reason' => 'grace_period',
            'grace' => true,
            'grace_days_left' => $graceDaysLeft
        ]);
    }

    // 3. Free trial check
    $trialEnabled = get_system_setting('dealer_free_trial_enabled', '0');
    if ($trialEnabled === '1') {
        $trialDays = (int)get_system_setting('dealer_free_trial_days', '30');
        $createdAt = strtotime($dealer['created_at']);
        $trialEnd = $createdAt + ($trialDays * 86400);

        if ($now < $trialEnd && in_array($dealer['status'], ['active', 'approved'])) {
            // Only grant trial access if the account was already activated (paid previously or admin-approved)
            $daysLeft = (int)ceil(($trialEnd - $now) / 86400);
            return array_merge($base, ['active' => true, 'reason' => 'free_trial', 'trial' => true, 'trial_days_left' => $daysLeft]);
        }
    }

    // 4. No active subscription, no trial, no grace
    return array_merge($base, ['reason' => 'no_subscription']);
}

/**
 * Require active subscription for protected dealer pages (POS, orders, add products)
 * Redirects to subscription page if not active.
 * During grace period: allows access but sets a warning message.
 */
function require_dealer_subscription(): void {
    $sub = check_dealer_subscription();
    if (!$sub['active']) {
        $_SESSION['dealer_sub_message'] = 'You need an active subscription to access this feature. Please subscribe or renew your plan.';
        header('Location: /solarglobal/dealer/subscription.php');
        exit();
    }
    // Grace period warning — page loads but dealer sees an alert
    if ($sub['grace']) {
        $_SESSION['dealer_sub_warning'] = 'Your subscription has expired. You have ' . $sub['grace_days_left'] . ' day(s) left to renew before your store is locked.';
    }
}

/**
 * Check if a dealer's store is visible to customers
 * Store is visible if: subscription active (paid, trial, or grace)
 */
function is_dealer_store_visible(?int $dealer_id = null): bool {
    $sub = check_dealer_subscription($dealer_id);
    return $sub['active'];
}

/**
 * Get a system setting value
 */
// get_system_setting() moved to helpers.php
if (!function_exists('get_system_setting')) {
    function get_system_setting(string $key, string $default = ''): string {
        static $cache = [];
        if (isset($cache[$key])) return $cache[$key];
        try {
            $db = getDB();
            $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
            $stmt->execute([$key]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $cache[$key] = $row ? ($row['setting_value'] ?? $default) : $default;
        } catch (Exception $e) { $cache[$key] = $default; }
        return $cache[$key];
    }
}
