<?php
/**
 * Ad Impression Tracking API (called via sendBeacon for rotation)
 */
require_once '../includes/db.php';
require_once '../includes/helpers.php';

if (!rate_limit('api_track_impression', 120, 60)) { respond_rate_limited(); }

$adId = intval($_GET['id'] ?? 0);
if ($adId > 0) {
    trackAdImpression(getDB(), $adId);
}

http_response_code(204); // No Content
exit;
