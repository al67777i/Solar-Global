<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

$db = getDB();

$companies = $db->query("SELECT name FROM companies WHERE is_active = 1 ORDER BY name ASC")->fetchAll(PDO::FETCH_COLUMN);

$schema = [
    'instructions' => 'Generate CSV data using EXACTLY these column headers and value constraints. The "brand" column MUST use one of the company names listed below. All prices are in USD. Do NOT invent new brand names.',
    'companies' => $companies,
    'inverter_schema' => [
        'columns' => [
            'name' => ['required' => true, 'type' => 'string', 'example' => 'SUN2000-5KTL', 'description' => 'Model name of the inverter'],
            'brand' => ['required' => true, 'type' => 'string', 'example' => 'Huawei', 'description' => 'Must match a company from the companies list'],
            'output_watts' => ['required' => true, 'type' => 'integer', 'example' => 5000, 'description' => 'Output power in watts'],
            'power_rating' => ['required' => true, 'type' => 'integer', 'example' => 5000, 'description' => 'Max load power rating in watts (usually same as output_watts)'],
            'type' => ['required' => true, 'type' => 'enum', 'values' => ['hybrid', 'on-grid', 'off-grid'], 'description' => 'Inverter type'],
            'vdc_type' => ['required' => true, 'type' => 'enum', 'values' => ['12V', '24V', '48V'], 'description' => 'DC voltage class'],
            'max_pv_input' => ['required' => true, 'type' => 'integer', 'example' => 7500, 'description' => 'Maximum PV input power in watts'],
            'mppt_count' => ['required' => true, 'type' => 'integer', 'example' => 2, 'description' => 'Number of MPPT channels (1-6)'],
            'efficiency' => ['required' => true, 'type' => 'float', 'example' => 97.5, 'description' => 'Efficiency percentage (90-99.9)'],
            'has_bms' => ['required' => false, 'type' => 'integer', 'values' => [0, 1], 'default' => 0, 'description' => '1 if has built-in BMS, 0 otherwise'],
            'price_usd' => ['required' => true, 'type' => 'float', 'example' => 450.00, 'description' => 'Price in US Dollars'],
            'warranty_years' => ['required' => false, 'type' => 'integer', 'example' => 10, 'default' => 5, 'description' => 'Warranty period in years'],
            'parallel_capable' => ['required' => false, 'type' => 'integer', 'values' => [0, 1], 'default' => 0, 'description' => '1 if can be paralleled, 0 otherwise'],
            'max_parallel_units' => ['required' => false, 'type' => 'integer', 'example' => 6, 'default' => 1, 'description' => 'Maximum units that can be paralleled'],
            'parallel_phase_config' => ['required' => false, 'type' => 'enum', 'values' => ['single-phase', 'split-phase', 'three-phase', 'single-and-three', ''], 'description' => 'Phase configuration when paralleled'],
            'usage_type' => ['required' => true, 'type' => 'enum', 'values' => ['residential', 'commercial', 'industrial'], 'description' => 'Target usage: residential (home, ≤8kW), commercial (business, 8-50kW), industrial (factory, >50kW)'],
            'three_phase' => ['required' => true, 'type' => 'integer', 'values' => [0, 1], 'description' => '1 if three-phase inverter, 0 if single-phase'],
            'features' => ['required' => false, 'type' => 'string', 'example' => 'MPPT tracking, WiFi monitoring', 'description' => 'Comma-separated features or notes']
        ]
    ],
    'battery_schema' => [
        'columns' => [
            'name' => ['required' => true, 'type' => 'string', 'example' => 'US3000C'],
            'brand' => ['required' => true, 'type' => 'string', 'example' => 'Pylontech', 'description' => 'Must match a company from the companies list'],
            'capacity_ah' => ['required' => true, 'type' => 'integer', 'example' => 100, 'description' => 'Capacity in Amp-hours'],
            'voltage' => ['required' => true, 'type' => 'integer', 'values' => [12, 24, 48], 'description' => 'Battery voltage'],
            'battery_type' => ['required' => true, 'type' => 'enum', 'values' => ['Deep Cycle', 'Gel', 'AGM', 'Lithium', 'LFP'], 'description' => 'Battery chemistry type'],
            'has_bms' => ['required' => false, 'type' => 'integer', 'values' => [0, 1], 'default' => 0],
            'cycle_life' => ['required' => false, 'type' => 'integer', 'example' => 6000, 'description' => 'Number of charge cycles at rated DoD'],
            'depth_of_discharge' => ['required' => true, 'type' => 'integer', 'example' => 90, 'description' => 'Recommended depth of discharge percentage (50-95)'],
            'maintenance_free' => ['required' => false, 'type' => 'integer', 'values' => [0, 1], 'default' => 1],
            'weight_kg' => ['required' => false, 'type' => 'float', 'example' => 32.0],
            'price_usd' => ['required' => true, 'type' => 'float', 'example' => 340.00, 'description' => 'Price in US Dollars'],
            'warranty_years' => ['required' => false, 'type' => 'integer', 'default' => 5],
            'features' => ['required' => false, 'type' => 'string']
        ]
    ],
    'panel_schema' => [
        'columns' => [
            'name' => ['required' => true, 'type' => 'string', 'example' => 'Tiger Neo 550W'],
            'brand' => ['required' => true, 'type' => 'string', 'example' => 'JinkoSolar', 'description' => 'Must match a company from the companies list'],
            'wattage' => ['required' => true, 'type' => 'integer', 'example' => 550, 'description' => 'Panel wattage (Wp)'],
            'panel_type' => ['required' => true, 'type' => 'enum', 'values' => ['Monocrystalline', 'Polycrystalline', 'Bifacial', 'Thin-Film', 'HJT', 'TOPCon']],
            'efficiency' => ['required' => true, 'type' => 'float', 'example' => 21.3, 'description' => 'Efficiency percentage (15-25)'],
            'voc' => ['required' => false, 'type' => 'float', 'example' => 49.62, 'description' => 'Open circuit voltage (auto-calculated if 0)'],
            'vmp' => ['required' => false, 'type' => 'float', 'example' => 41.32, 'description' => 'Voltage at max power (auto-calculated if 0)'],
            'isc' => ['required' => false, 'type' => 'float', 'example' => 13.86, 'description' => 'Short circuit current (auto-calculated if 0)'],
            'dimensions' => ['required' => false, 'type' => 'string', 'example' => '2278x1134x30', 'description' => 'LxWxH in mm'],
            'weight_kg' => ['required' => false, 'type' => 'float', 'example' => 28.2],
            'price_usd' => ['required' => true, 'type' => 'float', 'example' => 50.00, 'description' => 'Price in US Dollars'],
            'warranty_years' => ['required' => false, 'type' => 'integer', 'default' => 25],
            'features' => ['required' => false, 'type' => 'string']
        ]
    ]
];

header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="solarglobal_import_schema.json"');
echo json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
exit;
