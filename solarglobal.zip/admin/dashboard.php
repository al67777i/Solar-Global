<?php
/**
 * Admin Dashboard - Enhanced with Traffic & System Overview
 */
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/helpers.php';

set_security_headers();
$db = getDB();

// Product stats
$stats = [
    'companies' => $db->query("SELECT COUNT(*) FROM companies")->fetchColumn(),
    'inverters' => $db->query("SELECT COUNT(*) FROM inverters WHERE is_active = 1")->fetchColumn(),
    'batteries' => $db->query("SELECT COUNT(*) FROM batteries WHERE is_active = 1")->fetchColumn(),
    'panels' => $db->query("SELECT COUNT(*) FROM panels WHERE is_active = 1")->fetchColumn(),
];

// Additional counts (with fallback if tables don't exist yet)
$installationCount = 0;
$dealerCount = 0;
$installerCount = 0;
$activeDealersSub = 0;
$activeInstallersSub = 0;
$pendingOrders = 0;
$totalCustomers = 0;
$trialDealers = 0;
$trialInstallers = 0;
$expiredDealers = 0;
$expiredInstallers = 0;
$pendingDealers = 0;
$pendingInstallers = 0;

try { $installationCount = $db->query("SELECT COUNT(*) FROM installation_appliances WHERE is_active = 1")->fetchColumn(); } catch (Exception $e) {}
try { $dealerCount = $db->query("SELECT COUNT(*) FROM dealers")->fetchColumn(); } catch (Exception $e) {}
try { $installerCount = $db->query("SELECT COUNT(*) FROM installers")->fetchColumn(); } catch (Exception $e) {}

// Subscription-aware counts
try { $activeDealersSub = $db->query("SELECT COUNT(*) FROM dealers WHERE subscription_status = 'active'")->fetchColumn(); } catch (Exception $e) {}
try { $activeInstallersSub = $db->query("SELECT COUNT(*) FROM installers WHERE subscription_status = 'active'")->fetchColumn(); } catch (Exception $e) {}
try { $trialDealers = $db->query("SELECT COUNT(*) FROM dealers WHERE subscription_status = 'trial'")->fetchColumn(); } catch (Exception $e) {}
try { $trialInstallers = $db->query("SELECT COUNT(*) FROM installers WHERE subscription_status = 'trial'")->fetchColumn(); } catch (Exception $e) {}
try { $expiredDealers = $db->query("SELECT COUNT(*) FROM dealers WHERE subscription_status = 'expired'")->fetchColumn(); } catch (Exception $e) {}
try { $expiredInstallers = $db->query("SELECT COUNT(*) FROM installers WHERE subscription_status = 'expired'")->fetchColumn(); } catch (Exception $e) {}
try { $pendingDealers = $db->query("SELECT COUNT(*) FROM dealers WHERE status = 'pending'")->fetchColumn(); } catch (Exception $e) {}
try { $pendingInstallers = $db->query("SELECT COUNT(*) FROM installers WHERE status = 'pending'")->fetchColumn(); } catch (Exception $e) {}
try { $pendingOrders = $db->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn(); } catch (Exception $e) {}
try { $totalCustomers = $db->query("SELECT COUNT(*) FROM customers")->fetchColumn(); } catch (Exception $e) {}

// Traffic stats
$trafficToday = ['views' => 0, 'visitors' => 0];
$trafficWeek = ['views' => 0, 'visitors' => 0];
$trafficMonth = ['views' => 0, 'visitors' => 0];

try {
    $trafficToday = $db->query("SELECT COUNT(*) as views, COUNT(DISTINCT ip_address) as visitors FROM visitor_stats WHERE DATE(visit_date) = CURDATE()")->fetch();
    $trafficWeek = $db->query("SELECT COUNT(*) as views, COUNT(DISTINCT ip_address) as visitors FROM visitor_stats WHERE visit_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch();
    $trafficMonth = $db->query("SELECT COUNT(*) as views, COUNT(DISTINCT ip_address) as visitors FROM visitor_stats WHERE visit_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetch();
} catch (Exception $e) {}

// Active ads
$activeAds = 0;
try { $activeAds = $db->query("SELECT COUNT(*) FROM custom_ads WHERE is_active = 1")->fetchColumn(); } catch (Exception $e) {}

// Last 7 days traffic for mini chart
$weeklyTraffic = [];
try {
    $weeklyTraffic = $db->query("
        SELECT DATE(visit_date) as day, COUNT(*) as views, COUNT(DISTINCT ip_address) as visitors
        FROM visitor_stats WHERE visit_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY DATE(visit_date) ORDER BY day
    ")->fetchAll();
} catch (Exception $e) {}

// Recent activity
$recent = $db->query("
    (SELECT 'inverter' as type, model as name, created_at FROM inverters ORDER BY created_at DESC LIMIT 3)
    UNION ALL
    (SELECT 'battery' as type, model as name, created_at FROM batteries ORDER BY created_at DESC LIMIT 3)
    UNION ALL
    (SELECT 'panel' as type, name, created_at FROM panels ORDER BY created_at DESC LIMIT 3)
    ORDER BY created_at DESC LIMIT 10
")->fetchAll();

// System health
$phpVersion = phpversion();
$dbSize = $db->query("
    SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size_mb
    FROM information_schema.tables WHERE table_schema = DATABASE()
")->fetchColumn();

$pageTitle = "Dashboard";
include 'includes/header.php';
?>

<!-- Product Stats -->
<div class="dashboard-grid grid-4">
    <div class="stat-card">
        <div class="stat-icon">🏢</div>
        <div class="stat-content">
            <div class="stat-value"><?= $stats['companies'] ?></div>
            <div class="stat-label">Companies</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">⚡</div>
        <div class="stat-content">
            <div class="stat-value"><?= $stats['inverters'] ?></div>
            <div class="stat-label">Inverters</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🔋</div>
        <div class="stat-content">
            <div class="stat-value"><?= $stats['batteries'] ?></div>
            <div class="stat-label">Batteries</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">☀️</div>
        <div class="stat-content">
            <div class="stat-value"><?= $stats['panels'] ?></div>
            <div class="stat-label">Solar Panels</div>
        </div>
    </div>
</div>

<!-- Subscription & Business Stats -->
<div class="dashboard-grid grid-4">
    <div class="stat-card stat-green">
        <div class="stat-icon">🏪</div>
        <div class="stat-content">
            <div class="stat-value"><?= $activeDealersSub ?></div>
            <div class="stat-label">Active Dealers</div>
            <small class="stat-sub"><?= $trialDealers ?> trial · <?= $expiredDealers ?> expired · <?= $dealerCount ?> total</small>
        </div>
    </div>
    <div class="stat-card stat-green">
        <div class="stat-icon">🔧</div>
        <div class="stat-content">
            <div class="stat-value"><?= $activeInstallersSub ?></div>
            <div class="stat-label">Active Installers</div>
            <small class="stat-sub"><?= $trialInstallers ?> trial · <?= $expiredInstallers ?> expired · <?= $installerCount ?> total</small>
        </div>
    </div>
    <div class="stat-card stat-orange">
        <div class="stat-icon">📦</div>
        <div class="stat-content">
            <div class="stat-value"><?= $pendingOrders ?></div>
            <div class="stat-label">Pending Orders</div>
            <small class="stat-sub"><?= $pendingDealers ?> dealer · <?= $pendingInstallers ?> installer approvals</small>
        </div>
    </div>
    <div class="stat-card stat-blue">
        <div class="stat-icon">👥</div>
        <div class="stat-content">
            <div class="stat-value"><?= $totalCustomers ?></div>
            <div class="stat-label">Customers</div>
            <small class="stat-sub"><?= $installationCount ?> installation items</small>
        </div>
    </div>
</div>

<!-- Traffic Overview -->
<div class="dashboard-grid grid-3">
    <div class="stat-card stat-blue">
        <div class="stat-icon">👁️</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($trafficToday['views'] ?? 0) ?></div>
            <div class="stat-label">Today's Views</div>
            <small class="stat-sub"><?= number_format($trafficToday['visitors'] ?? 0) ?> unique</small>
        </div>
    </div>
    <div class="stat-card stat-green">
        <div class="stat-icon">📊</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($trafficWeek['views'] ?? 0) ?></div>
            <div class="stat-label">This Week</div>
            <small class="stat-sub"><?= number_format($trafficWeek['visitors'] ?? 0) ?> visitors</small>
        </div>
    </div>
    <div class="stat-card stat-orange">
        <div class="stat-icon">📈</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($trafficMonth['views'] ?? 0) ?></div>
            <div class="stat-label">This Month</div>
            <small class="stat-sub"><?= number_format($trafficMonth['visitors'] ?? 0) ?> visitors</small>
        </div>
    </div>
</div>

<!-- Traffic Chart + Quick Links -->
<div class="grid-2">
    <div class="card">
        <h2>Weekly Traffic</h2>
        <canvas id="weeklyChart" height="120"></canvas>
    </div>
    <div class="card">
        <h2>Quick Actions</h2>
        <div class="quick-actions">
            <a href="traffic" class="action-btn">📊 Full Analytics</a>
            <a href="ads" class="action-btn">📢 Manage Ads</a>
            <a href="inverters" class="action-btn">⚡ Inverters</a>
            <a href="batteries" class="action-btn">🔋 Batteries</a>
            <a href="panels" class="action-btn">☀️ Panels</a>
            <a href="seo" class="action-btn">🔍 SEO Settings</a>
            <a href="settings" class="action-btn">⚙️ Settings</a>
            <a href="../" target="_blank" class="action-btn">🌐 View Site</a>
        </div>
    </div>
</div>

<!-- System Info + Recent Activity -->
<div class="grid-2">
    <div class="card">
        <h2>System Health</h2>
        <table class="data-table data-table-sm">
            <tbody>
                <tr><td>PHP Version</td><td><span class="badge badge-green"><?= $phpVersion ?></span></td></tr>
                <tr><td>Database Size</td><td><?= $dbSize ?> MB</td></tr>
                <tr><td>Active Ads</td><td><?= $activeAds ?></td></tr>
                <tr><td>Server</td><td><?= php_uname('s') . ' ' . php_uname('r') ?></td></tr>
                <tr><td>Memory Usage</td><td><?= round(memory_get_usage() / 1024 / 1024, 1) ?> MB</td></tr>
            </tbody>
        </table>
    </div>
    <div class="card">
        <h2>Recent Activity</h2>
        <table class="data-table data-table-sm">
            <thead><tr><th>Type</th><th>Name</th><th>Added</th></tr></thead>
            <tbody>
                <?php foreach ($recent as $item): ?>
                <tr>
                    <td><span class="badge badge-blue"><?= ucfirst($item['type']) ?></span></td>
                    <td class="text-truncate"><?= sanitize(substr($item['name'], 0, 30)) ?></td>
                    <td><?= date('M d', strtotime($item['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
const labels = <?= json_encode(array_column($weeklyTraffic, 'day')) ?>;
const views = <?= json_encode(array_column($weeklyTraffic, 'views')) ?>;
const visitors = <?= json_encode(array_column($weeklyTraffic, 'visitors')) ?>;

if (document.getElementById('weeklyChart')) {
    new Chart(document.getElementById('weeklyChart'), {
        type: 'line',
        data: {
            labels: labels.map(d => new Date(d).toLocaleDateString('en', {weekday:'short'})),
            datasets: [{
                label: 'Views', data: views.map(Number),
                borderColor: '#1565C0', backgroundColor: 'rgba(21,101,192,0.1)', fill: true, tension: 0.4
            }, {
                label: 'Visitors', data: visitors.map(Number),
                borderColor: '#4CAF50', backgroundColor: 'rgba(76,175,80,0.05)', fill: true, tension: 0.4
            }]
        },
        options: { responsive: true, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: true } } }
    });
}
</script>

<?php include 'includes/footer.php'; ?>
