﻿/**
 * Energy Forecast Module v3.0
 * ═══════════════════════════════════════════════════════════
 * The single source of truth for energy visualization.
 * Accurate hour-by-hour simulation with proper efficiency chains.
 *
 * System types:
 *   On-Grid:  Solar → Load → Grid Export/Import (net metering)
 *   Hybrid:   Solar → Load → Battery → Grid (optional net metering)
 *   Off-Grid: Solar → Load → Battery (no grid connection)
 *
 * Charts:
 *   Daily (24h):  Line chart — generation, load, grid export/import, battery charge/discharge
 *   Monthly (30d): Bar chart — daily totals + financial summary
 *   Summary:       Financial breakdown panel below chart
 */
(function () {
    'use strict';

    // ═══════════════════════════════════════════════════════
    // STATE
    // ═══════════════════════════════════════════════════════

    let forecastChart = null;
    let forecastData = null;
    let currentView = 'daily';
    let systemConfig = null;
    let lastFetchKey = '';

    // System parameters — updated from configurator
    let systemType = 'hybrid';
    let netMeteringEnabled = false;
    let sellbackRatePct = 80;
    let sellRateKwh = 0;       // Actual sell rate per kWh (from country data)
    let buyRateKwh = 0;        // Buy rate per kWh

    // Component specs
    let batteryCapacityKwh = 0;   // Total raw battery capacity
    let batteryDod = 0.9;         // Depth of discharge (0-1)
    let inverterEfficiency = 0.96;
    let batteryChargeEff = 0.95;  // Round-trip split: charge side
    let batteryDischargeEff = 0.95; // Round-trip split: discharge side

    // Colors
    const C = {
        solar:     { line: '#f59e0b', fill: 'rgba(245,158,11,0.15)' },
        load:      { line: '#3b82f6', fill: 'rgba(59,130,246,0.10)' },
        export:    { line: '#10b981', fill: 'rgba(16,185,129,0.15)' },
        import:    { line: '#ef4444', fill: 'rgba(239,68,68,0.10)' },
        battChrg:  { line: '#8b5cf6', fill: 'rgba(139,92,246,0.10)' },
        battDisc:  { line: '#ec4899', fill: 'rgba(236,72,153,0.10)' },
        soc:       { line: '#6366f1', fill: 'rgba(99,102,241,0.08)' },
    };

    // ═══════════════════════════════════════════════════════
    // INITIALIZATION
    // ═══════════════════════════════════════════════════════

    function init() {
        document.querySelectorAll('.forecast-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.forecast-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                currentView = tab.dataset.view;
                if (forecastData) {
                    renderChart();
                    updateFinancialSummary();
                }
            });
        });
    }

    // ═══════════════════════════════════════════════════════
    // DATA ENTRY POINTS
    // ═══════════════════════════════════════════════════════

    /**
     * Primary entry: called from system-configurator.js on every recalculation
     */
    function updateFromConfigurator(state) {
        if (!state || !state.current) return;

        const cur = state.current;
        const load = state.loadAnalysis;

        // Panel config
        const panelWatts = cur.panel_config?.panel?.watt_peak || 550;
        const numPanels = cur.panel_config?.quantity || 4;
        const systemKwp = parseFloat(cur.panel_config?.total_kwp) || ((panelWatts * numPanels) / 1000);
        const dailyConsumption = parseFloat(load?.daily_energy_kwh) || 10;

        // System type + net metering from recommender globals
        systemType = state.systemType || cur.system_type || 'hybrid';
        netMeteringEnabled = state.netMetering || false;
        sellbackRatePct = state.sellbackRate || 80;
        buyRateKwh = state.buyRate || window.appState?.recommendations?.grid_info?.electricity_rate_kwh || 0;
        sellRateKwh = state.sellRate || window.appState?.recommendations?.grid_info?.sell_rate_kwh || 0;

        // On-grid always has net metering
        if (systemType === 'on-grid') netMeteringEnabled = true;

        // Battery — compute total kWh from configurator battery config
        batteryCapacityKwh = 0;
        batteryDod = 0.9;
        if (cur.battery_config && cur.battery_config.battery && cur.needs_battery !== false) {
            const bc = cur.battery_config;
            const batt = bc.battery;
            const voltage = parseFloat(batt.voltage) || 12;
            const ah = parseFloat(batt.capacity_ah) || 100;
            const qty = bc.quantity || 1;
            const series = bc.series || 1;
            const parallel = bc.parallel || Math.floor(qty / series);

            // kWh = bankVoltage × parallelAh / 1000
            const bankVoltage = voltage * series;
            const totalAh = parallel * ah;
            batteryCapacityKwh = (bankVoltage * totalAh) / 1000;

            // DoD — from battery spec or system settings
            const dodRaw = parseFloat(batt.dod || batt.depth_of_discharge || cur.battery_config.dod_percent);
            if (dodRaw > 0 && dodRaw <= 1) batteryDod = dodRaw;
            else if (dodRaw > 1 && dodRaw <= 100) batteryDod = dodRaw / 100;
            else {
                // Default by type
                const bType = (batt.battery_type || batt.type || '').toLowerCase();
                if (bType.includes('lfp') || bType.includes('lithium')) batteryDod = 0.90;
                else if (bType.includes('gel')) batteryDod = 0.50;
                else if (bType.includes('agm')) batteryDod = 0.50;
                else batteryDod = 0.50; // lead-acid default
            }
        }

        // Inverter efficiency
        if (cur.inverter) {
            const rawEff = parseFloat(cur.inverter.efficiency);
            inverterEfficiency = (rawEff > 1 ? rawEff / 100 : rawEff) || 0.96;
        }

        systemConfig = { panelWatts, numPanels, systemKwp, dailyConsumption };

        const section = document.getElementById('energy-forecast-section');
        if (!section) return;

        // Always show the section — even without weather data we can simulate
        section.style.display = 'block';
        section.classList.add('visible');

        // Try to get city for weather-based forecast
        let cityId = null;
        try { cityId = localStorage.getItem('selectedCityId'); } catch (e) { /* */ }
        if (!cityId) cityId = window.appState?.selectedCity?.id || window.citySelector?.getCityId?.() || null;

        if (!cityId) {
            // No city — use estimated PSH and show simulation without weather data

            forecastData = {
                annual: null,
                forecast: { success: true, daily_forecast: generateEstimatedForecast(systemKwp), avg_daily_kwh: systemKwp * 4.5 * 0.82 },
                dailyConsumption: dailyConsumption,
                systemKwp: systemKwp,
                loadAnalysis: load
            };
            lastFetchKey = '';
            updateAll();
            return;
        }

        // Only re-fetch if panel config changed (not just battery/type changes)
        const fetchKey = `${cityId}_${panelWatts}_${numPanels}`;
        if (fetchKey === lastFetchKey && forecastData) {
            // Same panels — just update simulation params and re-render
            forecastData.dailyConsumption = dailyConsumption;
            forecastData.systemKwp = systemKwp;
            forecastData.loadAnalysis = load;
            updateAll();
            return;
        }
        lastFetchKey = fetchKey;
        fetchForecastData(cityId, systemConfig, load);
    }

    /**
     * Secondary entry: called from recommendation display
     */
    function showForecast(recData) {
        const solarCtx = recData.solar_context;
        const loadAnalysis = recData.load_analysis;
        if (!solarCtx && !loadAnalysis) return;

        systemConfig = extractSystemConfig(recData);
        if (!systemConfig) return;

        systemType = recData.system_type || 'hybrid';
        netMeteringEnabled = !!recData.net_metering;
        sellbackRatePct = recData.net_metering?.sellback_rate_pct || 80;
        buyRateKwh = recData.grid_info?.electricity_rate_kwh || 0;
        sellRateKwh = recData.grid_info?.sell_rate_kwh || 0;
        if (systemType === 'on-grid') netMeteringEnabled = true;

        // Battery from first option
        const cats = recData.categories || [];
        for (const cat of cats) {
            if (cat.options?.length > 0) {
                const opt = cat.options[0];
                if (opt.battery_config?.battery) {
                    batteryCapacityKwh = parseFloat(opt.battery_config.total_kwh) || 0;
                    batteryDod = parseFloat(opt.battery_config.battery.dod) || 0.9;
                }
                if (opt.inverter) {
                    inverterEfficiency = (parseFloat(opt.inverter.efficiency) || 97) / 100;
                }
                break;
            }
        }

        let cityId = null;
        try { cityId = localStorage.getItem('selectedCityId'); } catch (e) { /* */ }
        const cid = solarCtx?.enhanced_params?.city_id || cityId;
        if (!cid) return;

        const section = document.getElementById('energy-forecast-section');
        if (!section) return;
        section.style.display = 'block';
        section.classList.add('visible');
        fetchForecastData(cid, systemConfig, loadAnalysis);
    }

    function extractSystemConfig(data) {
        for (const cat of (data.categories || [])) {
            if (cat.options?.length > 0) {
                const pc = cat.options[0].panel_config;
                if (pc) return {
                    panelWatts: pc.panel?.watt_peak || 550,
                    numPanels: pc.quantity || 4,
                    systemKwp: pc.total_kwp || ((pc.panel?.watt_peak || 550) * (pc.quantity || 4) / 1000),
                    dailyConsumption: data.load_analysis?.daily_energy_kwh || 10
                };
            }
        }
        const s = data.solar_context?.optimal_sizing;
        if (s) return { panelWatts: s.panel_watts || 550, numPanels: s.recommended_panels || 4, systemKwp: s.system_kwp || 2.2, dailyConsumption: data.load_analysis?.daily_energy_kwh || 10 };
        return null;
    }

    // ═══════════════════════════════════════════════════════
    // DATA FETCHING
    // ═══════════════════════════════════════════════════════

    async function fetchForecastData(cityId, config, loadAnalysis) {
        showLoading();
        try {
            const [annualRes, forecastRes] = await Promise.all([
                fetch(`api/solar.php?action=annual_yield&city_id=${cityId}&panel_watts=${config.panelWatts}&num_panels=${config.numPanels}`),
                fetch(`api/solar.php?action=forecast&city_id=${cityId}&panel_watts=${config.panelWatts}&num_panels=${config.numPanels}`)
            ]);
            const annual = await annualRes.json();
            const forecast = await forecastRes.json();

            if (!annual.success && !forecast.success) { hideLoading(); return; }

            forecastData = {
                annual: annual.success ? annual : null,
                forecast: forecast.success ? forecast : null,
                dailyConsumption: config.dailyConsumption,
                systemKwp: config.systemKwp,
                loadAnalysis: loadAnalysis
            };

            hideLoading();
            updateAll();
        } catch (e) {
            console.error('Forecast fetch error:', e);
            hideLoading();
        }
    }

    function updateAll() {
        updateStats();
        renderChart();
        updateFinancialSummary();
    }

    // ═══════════════════════════════════════════════════════
    // CORE SIMULATION ENGINE
    // ═══════════════════════════════════════════════════════

    /**
     * Simulate a full 24-hour energy flow cycle.
     *
     * Priority dispatch order:
     *   Surplus: Self-consume → Charge battery → Export to grid
     *   Deficit: Use solar → Discharge battery → Import from grid
     *
     * Efficiency chain:
     *   Solar → Load:    via inverter (inverterEfficiency applied to gen before comparison)
     *   Solar → Battery: stored = input × batteryChargeEff
     *   Battery → Load:  delivered = drawn × batteryDischargeEff
     *   Grid ↔ Load:     direct (no additional loss)
     *
     * @param {number} dailyGenKwh - Total DC generation for the day (before inverter loss)
     * @param {number} dailyUseKwh - Total AC load for the day
     * @param {number[]|null} hourlyLoadWatts - 24-element array (watts per hour), or null for default curve
     * @returns {{ hours: Array, totals: Object }}
     */
    function simulateDailyEnergyFlow(dailyGenKwh, dailyUseKwh, hourlyLoadWatts) {
        // Realistic solar irradiance curve (peaks 11am-1pm)
        // Each value = fraction of peak, normalized so sum distributes dailyGenKwh across 24h
        const solarCurve = [
            0, 0, 0, 0, 0,        // 00-04: night
            0.02, 0.10, 0.25,      // 05-07: sunrise ramp
            0.50, 0.75, 0.90,      // 08-10: morning climb
            0.98, 1.00, 0.98,      // 11-13: peak
            0.90, 0.75, 0.55,      // 14-16: afternoon decline
            0.30, 0.08, 0.01,      // 17-19: sunset
            0, 0, 0, 0             // 20-23: night
        ];
        const curveSum = solarCurve.reduce((a, b) => a + b, 0);

        // Hourly consumption profile
        let hourlyUse = new Array(24).fill(0);
        if (hourlyLoadWatts && hourlyLoadWatts.length === 24) {
            // Actual load profile from appliance selection (watts → kWh per hour)
            const rawTotal = hourlyLoadWatts.reduce((a, b) => a + b, 0) / 1000;
            if (rawTotal > 0.01) {
                // Scale to match declared daily consumption (may differ from raw sum)
                const scale = dailyUseKwh / rawTotal;
                hourlyUse = hourlyLoadWatts.map(w => (w / 1000) * scale);
            } else {
                hourlyUse = hourlyLoadWatts.map(w => w / 1000);
            }
        } else {
            // Default residential curve (evening peak)
            const defCurve = [0.25, 0.20, 0.18, 0.18, 0.18, 0.22, 0.45, 0.65, 0.55, 0.45, 0.40, 0.38, 0.38, 0.35, 0.35, 0.40, 0.50, 0.65, 0.85, 1.00, 0.90, 0.70, 0.45, 0.30];
            const dSum = defCurve.reduce((a, b) => a + b, 0);
            hourlyUse = defCurve.map(v => (v / dSum) * dailyUseKwh);
        }

        // DC solar generation per hour (before inverter conversion)
        const hourlyGenDC = solarCurve.map(v => (v / curveSum) * dailyGenKwh);

        // Battery params
        const usableKwh = batteryCapacityKwh * batteryDod;
        const hasBattery = (systemType === 'hybrid' || systemType === 'off-grid') && usableKwh > 0.1;
        const maxChgRate = usableKwh > 0 ? usableKwh * 0.5 : 0; // C/2 max per hour
        const maxDisRate = usableKwh > 0 ? usableKwh * 0.5 : 0;

        // Start SOC: off-grid 50%, hybrid 20% (assumes some charge from previous day)
        let soc = hasBattery ? usableKwh * (systemType === 'off-grid' ? 0.5 : 0.2) : 0;

        const canExport = systemType === 'on-grid' || (systemType === 'hybrid' && netMeteringEnabled);
        const canImport = systemType !== 'off-grid';

        const result = {
            hours: [],
            totals: { generation: 0, consumption: 0, selfConsumed: 0, gridExport: 0, gridImport: 0, batteryCharged: 0, batteryDischarged: 0 }
        };

        for (let h = 0; h < 24; h++) {
            const genDC = hourlyGenDC[h];
            // AC output from solar (after inverter)
            const genAC = genDC * inverterEfficiency;
            const use = hourlyUse[h];

            let selfCon = 0, gExp = 0, gImp = 0, bChg = 0, bDis = 0;

            const net = genAC - use; // positive = surplus, negative = deficit

            if (net >= 0) {
                // ── SURPLUS: solar > load ──
                selfCon = use;
                let surplus = net;

                // 1) Charge battery with surplus
                if (hasBattery && surplus > 0.001) {
                    const space = usableKwh - soc;
                    // How much AC solar input to store: stored = input × chargeEff
                    const maxIn = Math.min(surplus, maxChgRate, space / batteryChargeEff);
                    if (maxIn > 0.001) {
                        bChg = maxIn;
                        soc += maxIn * batteryChargeEff;
                        surplus -= maxIn;
                    }
                }

                // 2) Export remainder to grid
                if (surplus > 0.001 && canExport) {
                    gExp = surplus;
                }
                // else: clipped (wasted) in off-grid
            } else {
                // ── DEFICIT: load > solar ──
                selfCon = genAC;
                let deficit = Math.abs(net);

                // 1) Discharge battery
                if (hasBattery && deficit > 0.001 && soc > 0.001) {
                    // delivered = drawn × dischargeEff
                    const maxDraw = Math.min(deficit / batteryDischargeEff, maxDisRate, soc);
                    if (maxDraw > 0.001) {
                        const delivered = maxDraw * batteryDischargeEff;
                        bDis = delivered;
                        soc -= maxDraw;
                        deficit -= delivered;
                    }
                }

                // 2) Import from grid
                if (deficit > 0.001 && canImport) {
                    gImp = deficit;
                }
                // else: unmet load in off-grid (blackout)
            }

            result.hours.push({
                hour: h,
                generation: round3(genAC),
                consumption: round3(use),
                selfConsumed: round3(selfCon),
                gridExport: round3(gExp),
                gridImport: round3(gImp),
                batteryCharge: round3(bChg),
                batteryDischarge: round3(bDis),
                batterySoc: round3(soc),
                batteryPct: usableKwh > 0 ? round1((soc / usableKwh) * 100) : 0
            });

            result.totals.generation += genAC;
            result.totals.consumption += use;
            result.totals.selfConsumed += selfCon;
            result.totals.gridExport += gExp;
            result.totals.gridImport += gImp;
            result.totals.batteryCharged += bChg;
            result.totals.batteryDischarged += bDis;
        }

        // Round totals
        for (const k of Object.keys(result.totals)) result.totals[k] = round2(result.totals[k]);
        return result;
    }

    /**
     * Simulate 30-day energy flow using weather forecast data
     */
    function simulateMonthlyEnergyFlow() {
        if (!forecastData?.forecast?.daily_forecast) return null;

        const days = forecastData.forecast.daily_forecast;
        const dailyUse = forecastData.dailyConsumption || 10;
        const hourlyLoad = forecastData.loadAnalysis?.hourly_load || null;

        const monthly = {
            days: [],
            totals: { generation: 0, consumption: 0, selfConsumed: 0, gridExport: 0, gridImport: 0, batteryCharged: 0, batteryDischarged: 0 }
        };

        const numDays = Math.min(days.length, 30);
        for (let i = 0; i < numDays; i++) {
            const dayF = days[i];
            const dailyGen = dayF.net_kwh || 0;
            const flow = simulateDailyEnergyFlow(dailyGen, dailyUse, hourlyLoad);

            monthly.days.push({
                date: dayF.date,
                psh: dayF.psh || 0,
                ...flow.totals
            });

            for (const k of Object.keys(monthly.totals)) {
                monthly.totals[k] += flow.totals[k];
            }
        }

        for (const k of Object.keys(monthly.totals)) monthly.totals[k] = round1(monthly.totals[k]);
        return monthly;
    }

    // ═══════════════════════════════════════════════════════
    // STATS UPDATE
    // ═══════════════════════════════════════════════════════

    function updateStats() {
        if (!forecastData) return;

        const dailyUse = forecastData.dailyConsumption || 0;
        const todayF = forecastData.forecast?.daily_forecast?.[0];
        const todayGen = todayF?.net_kwh || forecastData.forecast?.avg_daily_kwh || 0;
        const hourlyLoad = forecastData.loadAnalysis?.hourly_load || null;

        const todayFlow = simulateDailyEnergyFlow(todayGen, dailyUse, hourlyLoad);
        const monthlyFlow = simulateMonthlyEnergyFlow();

        // Electricity rate
        const gridRate = getElectricityRate();
        const sym = getCurrencySymbol();

        // ── Top row stats ──
        setText('stat-daily-gen', todayFlow.totals.generation.toFixed(1) + ' kWh');
        setText('stat-daily-use', dailyUse.toFixed(1) + ' kWh');

        // Surplus/deficit card
        const netExIm = todayFlow.totals.gridExport - todayFlow.totals.gridImport;
        const surplusEl = document.getElementById('stat-surplus');
        const surplusCard = surplusEl?.closest('.stat-card');
        if (netExIm >= 0) {
            setText('stat-surplus', '+' + netExIm.toFixed(1) + ' kWh');
            surplusCard?.classList.remove('deficit');
        } else {
            setText('stat-surplus', netExIm.toFixed(1) + ' kWh');
            surplusCard?.classList.add('deficit');
        }

        // Monthly savings
        let monthlySavings = 0;
        if (monthlyFlow) {
            const t = monthlyFlow.totals;
            // Value of solar self-consumed (avoided grid purchase)
            monthlySavings += t.selfConsumed * gridRate;
            // Value of battery discharge (avoided grid purchase)
            monthlySavings += t.batteryDischarged * gridRate;
            // Net metering credit for exported energy
            monthlySavings += t.gridExport * getSellRate();
        }
        setText('stat-monthly-savings', sym + Math.round(monthlySavings).toLocaleString());

        // ── Info row ──
        setText('info-system-size', (forecastData.systemKwp || 0).toFixed(2) + ' kWp');
        if (forecastData.annual) {
            setText('info-annual', Math.round(forecastData.annual.annual_kwh || 0).toLocaleString() + ' kWh');
            setText('info-specific', (forecastData.annual.specific_yield_kwh_kwp || 0) + ' kWh/kWp');
        }
        setText('info-psh', (todayF?.psh || '--') + ' hrs');

        // ── Energy flow stats (second row) ──
        const flowEl = document.getElementById('energy-flow-stats');
        if (flowEl && monthlyFlow) {
            flowEl.style.display = 'grid';
            const t = monthlyFlow.totals;

            // Visibility per system type
            showCard('stat-grid-export', systemType !== 'off-grid');
            showCard('stat-grid-import', systemType !== 'off-grid');
            showCard('stat-battery-cycles', systemType !== 'on-grid' && batteryCapacityKwh > 0);

            setText('stat-grid-export', t.gridExport.toFixed(0) + ' kWh');
            setText('stat-grid-import', t.gridImport.toFixed(0) + ' kWh');

            const selfPct = t.generation > 0.1 ? ((t.selfConsumed / t.generation) * 100) : 0;
            setText('stat-self-consumption', selfPct.toFixed(0) + '%');

            const usable = batteryCapacityKwh * batteryDod;
            setText('stat-battery-cycles', usable > 0.1
                ? (t.batteryCharged / usable).toFixed(1)
                : 'N/A');
        } else if (flowEl) {
            flowEl.style.display = 'none';
        }
    }

    // ═══════════════════════════════════════════════════════
    // FINANCIAL SUMMARY (below chart)
    // ═══════════════════════════════════════════════════════

    function updateFinancialSummary() {
        const monthlyFlow = simulateMonthlyEnergyFlow();
        if (!monthlyFlow) return;

        const t = monthlyFlow.totals;
        const rate = getElectricityRate();
        const sym = getCurrencySymbol();
        const days = monthlyFlow.days.length;

        // Financial calculations
        const selfConValue = t.selfConsumed * rate;
        const batteryValue = t.batteryDischarged * rate;
        const exportCredit = t.gridExport * getSellRate();
        const gridBill = t.gridImport * rate;
        const totalSavings = selfConValue + batteryValue + exportCredit;
        const netBenefit = totalSavings - gridBill;
        const selfConsumptionPct = t.generation > 0.1 ? (t.selfConsumed / t.generation) * 100 : 0;
        const solarFractionPct = t.consumption > 0.1 ? ((t.selfConsumed + t.batteryDischarged) / t.consumption) * 100 : 0;

        // Build or update the summary div
        let summaryEl = document.getElementById('forecast-financial-summary');
        if (!summaryEl) {
            summaryEl = document.createElement('div');
            summaryEl.id = 'forecast-financial-summary';
            summaryEl.className = 'forecast-financial-summary';
            const chartContainer = document.querySelector('.forecast-chart-container');
            if (chartContainer) chartContainer.parentNode.insertBefore(summaryEl, chartContainer.nextSibling);
            else return;
        }

        // System type label
        let sysLabel = 'Hybrid System';
        if (systemType === 'on-grid') sysLabel = 'On-Grid + Net Metering';
        else if (systemType === 'hybrid') sysLabel = netMeteringEnabled ? 'Hybrid + Net Metering' : 'Hybrid + Battery Storage';
        else sysLabel = 'Off-Grid (Battery Only)';

        let html = `
            <div class="fin-header">
                <h4>Monthly Energy & Financial Summary</h4>
                <span class="fin-system-badge">${sysLabel}</span>
            </div>
            <div class="fin-grid">
                <div class="fin-block fin-energy">
                    <div class="fin-block-title">Energy Flow (${days} days)</div>
                    <div class="fin-row"><span>Total Generation</span><strong>${t.generation.toFixed(0)} kWh</strong></div>
                    <div class="fin-row"><span>Total Consumption</span><strong>${t.consumption.toFixed(0)} kWh</strong></div>
                    <div class="fin-row"><span>Self-Consumed</span><strong>${t.selfConsumed.toFixed(0)} kWh (${selfConsumptionPct.toFixed(0)}%)</strong></div>`;

        if (systemType !== 'off-grid') {
            html += `
                    <div class="fin-row fin-export"><span>Exported to Grid</span><strong class="green">${t.gridExport.toFixed(0)} kWh</strong></div>
                    <div class="fin-row fin-import"><span>Imported from Grid</span><strong class="red">${t.gridImport.toFixed(0)} kWh</strong></div>`;
        }

        if (batteryCapacityKwh > 0 && systemType !== 'on-grid') {
            html += `
                    <div class="fin-row"><span>Battery Charged</span><strong>${t.batteryCharged.toFixed(0)} kWh</strong></div>
                    <div class="fin-row"><span>Battery Discharged</span><strong>${t.batteryDischarged.toFixed(0)} kWh</strong></div>`;
        }

        html += `
                </div>
                <div class="fin-block fin-money">
                    <div class="fin-block-title">Financial Impact</div>
                    <div class="fin-row"><span>Solar Self-Use Savings</span><strong class="green">${sym}${Math.round(selfConValue).toLocaleString()}</strong></div>`;

        if (batteryCapacityKwh > 0 && systemType !== 'on-grid') {
            html += `
                    <div class="fin-row"><span>Battery Discharge Value</span><strong class="green">${sym}${Math.round(batteryValue).toLocaleString()}</strong></div>`;
        }

        if (systemType !== 'off-grid' && t.gridExport > 0) {
            const sr = getSellRate();
            html += `
                    <div class="fin-row"><span>Export Credit (${sym}${sr.toFixed(2)}/kWh)</span><strong class="green">${sym}${Math.round(exportCredit).toLocaleString()}</strong></div>`;
        }

        if (systemType !== 'off-grid') {
            html += `
                    <div class="fin-row"><span>Grid Electricity Bill</span><strong class="red">-${sym}${Math.round(gridBill).toLocaleString()}</strong></div>`;
        }

        // Before/After bill comparison
        const billBefore = t.consumption * rate;
        const billAfter = Math.max(0, gridBill - exportCredit);

        html += `
                    <div class="fin-row fin-total"><span>Net Monthly Benefit</span><strong class="${netBenefit >= 0 ? 'green' : 'red'}">${sym}${Math.round(netBenefit).toLocaleString()}</strong></div>
                    <div class="fin-row"><span>Solar Fraction</span><strong>${solarFractionPct.toFixed(0)}% of load from solar</strong></div>
                </div>
                <div class="fin-block fin-bill-compare">
                    <div class="fin-block-title">Bill Comparison (${days} days)</div>
                    <div class="fin-row"><span>Bill WITHOUT Solar</span><strong class="red">${sym}${Math.round(billBefore).toLocaleString()}</strong></div>
                    <div class="fin-row"><span>Bill WITH Solar</span><strong class="green">${sym}${Math.round(billAfter).toLocaleString()}</strong></div>
                    <div class="fin-row fin-total"><span>You Save</span><strong class="green">${sym}${Math.round(billBefore - billAfter).toLocaleString()} (${billBefore > 0 ? Math.round((1 - billAfter / billBefore) * 100) : 0}%)</strong></div>
                    <div class="fin-row"><span>Annual Savings (est.)</span><strong class="green">${sym}${Math.round((billBefore - billAfter) * 12).toLocaleString()}</strong></div>
                </div>
            </div>`;

        summaryEl.innerHTML = html;
    }

    // ═══════════════════════════════════════════════════════
    // CHART RENDERING
    // ═══════════════════════════════════════════════════════

    // F1: Night-time background shading plugin for daily chart
    const nightShadePlugin = {
        id: 'nightShade',
        beforeDraw(chart) {
            if (chart.config.type !== 'line') return;
            const labels = chart.data.labels || [];
            // Only apply to 24-hour daily charts (labels like "12 AM", "1 AM", etc.)
            if (labels.length !== 24) return;

            const { ctx, chartArea: { left, right, top, bottom }, scales: { x } } = chart;
            if (!x) return;

            ctx.save();
            ctx.fillStyle = 'rgba(15, 23, 42, 0.06)'; // subtle dark tint for night hours

            // Night hours: 0-5 (12AM-5AM) and 18-23 (6PM-11PM)
            const nightRanges = [[0, 5], [18, 23]];
            nightRanges.forEach(([start, end]) => {
                const x0 = x.getPixelForValue(start) - (x.getPixelForValue(1) - x.getPixelForValue(0)) / 2;
                const x1 = x.getPixelForValue(end) + (x.getPixelForValue(1) - x.getPixelForValue(0)) / 2;
                ctx.fillRect(Math.max(x0, left), top, Math.min(x1, right) - Math.max(x0, left), bottom - top);
            });

            // Moon icon labels at edges of night zones
            ctx.font = '10px sans-serif';
            ctx.fillStyle = 'rgba(100, 116, 139, 0.6)';
            ctx.textAlign = 'center';
            const earlyNightCenter = x.getPixelForValue(2.5);
            const lateNightCenter = x.getPixelForValue(20.5);
            ctx.fillText('🌙', earlyNightCenter, top + 14);
            ctx.fillText('🌙', lateNightCenter, top + 14);

            ctx.restore();
        }
    };

    function renderChart() {
        const canvas = document.getElementById('forecast-chart');
        if (!canvas) return;
        if (forecastChart) { forecastChart.destroy(); forecastChart = null; }

        const ctx = canvas.getContext('2d');
        let config;
        if (currentView === 'annual') config = buildAnnualChart();
        else if (currentView === 'monthly') config = buildMonthlyChart();
        else config = buildDailyChart();
        if (!config) return;

        // Register night shade plugin for daily charts
        if (currentView === 'daily' && config) {
            config.plugins = config.plugins || [];
            config.plugins.push(nightShadePlugin);
        }

        forecastChart = new Chart(ctx, config);
    }

    // ── DAILY CHART ──────────────────────────────────────

    function buildDailyChart() {
        if (!forecastData?.forecast?.daily_forecast?.[0]) return null;

        const todayF = forecastData.forecast.daily_forecast[0];
        const genKwh = todayF.net_kwh || (forecastData.systemKwp * (todayF.psh || 5) * 0.82);
        const useKwh = forecastData.dailyConsumption || 10;
        const flow = simulateDailyEnergyFlow(genKwh, useKwh, forecastData.loadAnalysis?.hourly_load);

        const labels = Array.from({ length: 24 }, (_, i) => {
            if (i === 0) return '12 AM';
            if (i === 12) return '12 PM';
            return i < 12 ? i + ' AM' : (i - 12) + ' PM';
        });

        const datasets = [
            makeDS('Solar Generation', flow.hours.map(h => h.generation), C.solar.line, C.solar.fill, true, 3, 1),
            makeDS('Consumption', flow.hours.map(h => h.consumption), C.load.line, C.load.fill, true, 3, 2),
        ];

        // Grid lines (on-grid or hybrid+NM)
        if (systemType === 'on-grid' || (systemType === 'hybrid' && netMeteringEnabled)) {
            datasets.push(makeDS('Grid Export', flow.hours.map(h => h.gridExport > 0.001 ? h.gridExport : null), C.export.line, C.export.fill, true, 3, 3, [5, 3]));
            datasets.push(makeDS('Grid Import', flow.hours.map(h => h.gridImport > 0.001 ? h.gridImport : null), C.import.line, C.import.fill, true, 3, 4, [5, 3]));
        } else if (systemType === 'hybrid') {
            // Hybrid without NM still imports from grid
            datasets.push(makeDS('Grid Import', flow.hours.map(h => h.gridImport > 0.001 ? h.gridImport : null), C.import.line, C.import.fill, true, 3, 4, [5, 3]));
        }

        // Battery lines (hybrid/off-grid)
        if ((systemType === 'hybrid' || systemType === 'off-grid') && batteryCapacityKwh > 0.1) {
            datasets.push(makeDS('Battery Charge', flow.hours.map(h => h.batteryCharge > 0.001 ? h.batteryCharge : null), C.battChrg.line, C.battChrg.fill, false, 3, 5, [4, 2]));
            datasets.push(makeDS('Battery Discharge', flow.hours.map(h => h.batteryDischarge > 0.001 ? h.batteryDischarge : null), C.battDisc.line, C.battDisc.fill, false, 3, 6, [4, 2]));
            // Battery SOC % on secondary axis
            datasets.push({
                label: 'Battery SOC (%)',
                data: flow.hours.map(h => h.batteryPct),
                borderColor: C.soc.line,
                backgroundColor: C.soc.fill,
                fill: false, tension: 0.4, borderWidth: 3,
                pointRadius: 0, pointHoverRadius: 4,
                yAxisID: 'y1', order: 7
            });
        }

        // Title
        let title = "Today's 24-Hour Energy Flow";
        if (systemType === 'on-grid') title += ' — On-Grid + Net Metering';
        else if (systemType === 'hybrid') title += netMeteringEnabled ? ' — Hybrid + Net Metering' : ' — Hybrid + Battery';
        else title += ' — Off-Grid';

        const hasBattSOC = datasets.some(d => d.yAxisID === 'y1');

        return {
            type: 'line',
            data: { labels, datasets },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                aspectRatio: window.innerWidth < 600 ? 1.3 : 2.0,
                animation: { duration: 600, easing: 'easeOutQuart' },
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: { usePointStyle: true, padding: 10, font: { size: 10.5, weight: '500' }, boxWidth: 8 }
                    },
                    title: {
                        display: true, text: title,
                        font: { size: 12, weight: '600' }, color: '#334155', padding: { bottom: 6 }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(15,23,42,0.95)', padding: 12, cornerRadius: 8,
                        titleFont: { size: 12, weight: '600' }, bodyFont: { size: 11 },
                        callbacks: {
                            label: ctx => {
                                const v = ctx.parsed.y;
                                if (v === null || v === undefined) return '';
                                const unit = ctx.dataset.yAxisID === 'y1' ? '%' : 'kWh';
                                return `${ctx.dataset.label}: ${Math.abs(v).toFixed(2)} ${unit}`;
                            },
                            afterBody: items => {
                                const idx = items[0]?.dataIndex;
                                if (idx === undefined) return '';
                                const h = flow.hours[idx];
                                if (!h) return '';
                                const lines = ['─────────────────'];
                                lines.push(`Self-consumed: ${h.selfConsumed.toFixed(2)} kWh`);
                                if (h.gridExport > 0.001) lines.push(`→ Grid export: ${h.gridExport.toFixed(2)} kWh`);
                                if (h.gridImport > 0.001) lines.push(`← Grid import: ${h.gridImport.toFixed(2)} kWh`);
                                if (h.batteryCharge > 0.001) lines.push(`⚡ Batt charge: ${h.batteryCharge.toFixed(2)} kWh`);
                                if (h.batteryDischarge > 0.001) lines.push(`🔋 Batt discharge: ${h.batteryDischarge.toFixed(2)} kWh`);
                                if (batteryCapacityKwh > 0.1) lines.push(`Battery: ${h.batteryPct.toFixed(0)}%`);
                                return lines;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: {
                            font: { size: 10 }, maxRotation: 45, autoSkip: true, maxTicksLimit: 12,
                            color: (ctx) => {
                                // Night hours (6PM-5AM) use lighter color for contrast against shading
                                const h = ctx.index;
                                return (h >= 18 || h < 6) ? '#94A3B8' : '#374151';
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        title: { display: true, text: 'Energy (kWh)', font: { size: 11 } },
                        grid: { color: 'rgba(0,0,0,0.04)' },
                        ticks: { font: { size: 10 }, callback: v => v.toFixed(1) }
                    },
                    ...(hasBattSOC ? {
                        y1: {
                            position: 'right', min: 0, max: 100,
                            title: { display: true, text: 'Battery %', font: { size: 10 } },
                            grid: { drawOnChartArea: false },
                            ticks: { font: { size: 9 }, callback: v => v + '%' }
                        }
                    } : {})
                }
            }
        };
    }

    // ── MONTHLY CHART ────────────────────────────────────

    function buildMonthlyChart() {
        const mf = simulateMonthlyEnergyFlow();
        if (!mf || mf.days.length === 0) return null;

        const labels = mf.days.map(d => {
            const dt = new Date(d.date);
            return dt.getDate() + ' ' + dt.toLocaleDateString('en-US', { month: 'short' });
        });

        const datasets = [
            {
                label: 'Generation', data: mf.days.map(d => round1(d.generation)),
                backgroundColor: 'rgba(245,158,11,0.7)', borderColor: C.solar.line,
                borderWidth: 1, borderRadius: 3, barPercentage: 0.75, order: 1
            },
            {
                label: 'Consumption', data: mf.days.map(d => round1(d.consumption)),
                backgroundColor: 'rgba(59,130,246,0.5)', borderColor: C.load.line,
                borderWidth: 1, borderRadius: 3, barPercentage: 0.75, order: 2
            }
        ];

        if (systemType === 'on-grid' || (systemType === 'hybrid' && netMeteringEnabled)) {
            datasets.push({
                label: 'Grid Export', data: mf.days.map(d => round1(d.gridExport)),
                backgroundColor: 'rgba(16,185,129,0.6)', borderColor: C.export.line,
                borderWidth: 1, borderRadius: 3, barPercentage: 0.75, order: 3
            });
        }

        if (systemType !== 'off-grid') {
            datasets.push({
                label: 'Grid Import', data: mf.days.map(d => round1(d.gridImport)),
                backgroundColor: 'rgba(239,68,68,0.5)', borderColor: C.import.line,
                borderWidth: 1, borderRadius: 3, barPercentage: 0.75, order: 4
            });
        }

        const t = mf.totals;
        const rate = getElectricityRate();
        const sym = getCurrencySymbol();
        const selfPct = t.generation > 0.1 ? ((t.selfConsumed / t.generation) * 100).toFixed(0) : 0;
        const netSavings = (t.selfConsumed + t.batteryDischarged) * rate + t.gridExport * rate * (sellbackRatePct / 100);
        const gridBill = t.gridImport * rate;

        const now = new Date();
        const monthLabel = now.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

        let titleText = `${monthLabel} — Gen: ${t.generation.toFixed(0)} kWh | Use: ${t.consumption.toFixed(0)} kWh`;
        if (t.gridExport > 0.5) titleText += ` | Export: ${t.gridExport.toFixed(0)} kWh`;
        if (t.gridImport > 0.5) titleText += ` | Import: ${t.gridImport.toFixed(0)} kWh`;

        const subtitleText = `Savings: ${sym}${Math.round(netSavings).toLocaleString()} | Grid Bill: ${sym}${Math.round(gridBill).toLocaleString()} | Self-use: ${selfPct}%`;

        return {
            type: 'bar',
            data: { labels, datasets },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                aspectRatio: window.innerWidth < 600 ? 1.3 : 2.0,
                animation: { duration: 600, easing: 'easeOutQuart' },
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: { usePointStyle: true, padding: 10, font: { size: 10.5, weight: '500' }, boxWidth: 8 }
                    },
                    title: { display: true, text: titleText, font: { size: 11, weight: '600' }, color: '#334155' },
                    subtitle: { display: true, text: subtitleText, font: { size: 11, weight: '500' }, color: '#059669', padding: { bottom: 8 } },
                    tooltip: {
                        backgroundColor: 'rgba(15,23,42,0.95)', padding: 12, cornerRadius: 8,
                        titleFont: { size: 12, weight: '600' }, bodyFont: { size: 11 },
                        callbacks: {
                            afterBody: items => {
                                const idx = items[0]?.dataIndex;
                                if (idx === undefined) return '';
                                const d = mf.days[idx];
                                if (!d) return '';
                                const lines = ['─────────────────'];
                                lines.push(`Self-consumed: ${d.selfConsumed.toFixed(1)} kWh`);
                                if (d.gridExport > 0.1) lines.push(`Grid export: ${d.gridExport.toFixed(1)} kWh`);
                                if (d.gridImport > 0.1) lines.push(`Grid import: ${d.gridImport.toFixed(1)} kWh`);
                                if (d.batteryCharged > 0.1) lines.push(`Batt charged: ${d.batteryCharged.toFixed(1)} kWh`);
                                if (d.batteryDischarged > 0.1) lines.push(`Batt discharged: ${d.batteryDischarged.toFixed(1)} kWh`);
                                lines.push(`PSH: ${d.psh.toFixed(1)} hrs`);
                                const daySaving = (d.selfConsumed + d.batteryDischarged) * rate + d.gridExport * getSellRate();
                                const dayBill = d.gridImport * rate;
                                lines.push(`Day saving: ${sym}${Math.round(daySaving)} | Bill: ${sym}${Math.round(dayBill)}`);
                                return lines;
                            }
                        }
                    }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { size: 9 }, maxRotation: 45, autoSkip: true, maxTicksLimit: 15 } },
                    y: {
                        beginAtZero: true,
                        title: { display: true, text: 'Energy (kWh)', font: { size: 11 } },
                        grid: { color: 'rgba(0,0,0,0.04)' },
                        ticks: { font: { size: 10 }, callback: v => v.toFixed(0) }
                    }
                }
            }
        };
    }

    // ── ANNUAL CHART (12-month savings projection) ─────

    function buildAnnualChart() {
        if (!forecastData) return null;

        const dailyGen = forecastData.forecast?.avg_daily_kwh
            || (forecastData.systemKwp || 2) * 4.5 * 0.82;
        const dailyUse = forecastData.dailyConsumption || 10;
        const rate = getElectricityRate();
        const sRate = getSellRate();
        const sym = getCurrencySymbol();
        const hourlyLoad = forecastData.loadAnalysis?.hourly_load || null;

        // Seasonal solar factors (Northern hemisphere general)
        const seasonal = [0.70, 0.75, 0.90, 1.00, 1.10, 1.15, 1.15, 1.10, 1.00, 0.85, 0.72, 0.65];
        const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

        const billBefore = [];
        const billAfter = [];
        const savingsArr = [];
        let totalAnnualBefore = 0;
        let totalAnnualAfter = 0;

        for (let m = 0; m < 12; m++) {
            const monthGenKwh = dailyGen * seasonal[m];
            const flow = simulateDailyEnergyFlow(monthGenKwh, dailyUse, hourlyLoad);
            const t = flow.totals;

            // Scale to 30 days
            const mBillBefore = dailyUse * rate * 30;
            const mGridCost = t.gridImport * rate * 30;
            const mExportCredit = t.gridExport * sRate * 30;
            const mBillAfter = Math.max(0, mGridCost - mExportCredit);
            const mSavings = mBillBefore - mBillAfter;

            billBefore.push(round1(mBillBefore));
            billAfter.push(round1(mBillAfter));
            savingsArr.push(round1(mSavings));
            totalAnnualBefore += mBillBefore;
            totalAnnualAfter += mBillAfter;
        }

        const totalSavings = totalAnnualBefore - totalAnnualAfter;
        const savingsPct = totalAnnualBefore > 0 ? Math.round((totalSavings / totalAnnualBefore) * 100) : 0;

        return {
            type: 'bar',
            data: {
                labels: months,
                datasets: [
                    {
                        label: 'Bill Without Solar',
                        data: billBefore,
                        backgroundColor: 'rgba(239,68,68,0.5)',
                        borderColor: '#ef4444',
                        borderWidth: 1, borderRadius: 4, barPercentage: 0.7, order: 2
                    },
                    {
                        label: 'Bill With Solar',
                        data: billAfter,
                        backgroundColor: 'rgba(16,185,129,0.6)',
                        borderColor: '#10b981',
                        borderWidth: 1, borderRadius: 4, barPercentage: 0.7, order: 1
                    },
                    {
                        label: 'Monthly Savings',
                        data: savingsArr,
                        type: 'line',
                        borderColor: '#f59e0b',
                        backgroundColor: 'rgba(245,158,11,0.1)',
                        fill: true, tension: 0.4, borderWidth: 3,
                        pointRadius: 4, pointBackgroundColor: '#f59e0b',
                        yAxisID: 'y', order: 0
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                aspectRatio: window.innerWidth < 600 ? 1.3 : 2.0,
                animation: { duration: 600, easing: 'easeOutQuart' },
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: { usePointStyle: true, padding: 10, font: { size: 10.5, weight: '500' }, boxWidth: 8 }
                    },
                    title: {
                        display: true,
                        text: `12-Month Savings Projection — Save ${sym}${Math.round(totalSavings).toLocaleString()}/year (${savingsPct}%)`,
                        font: { size: 12, weight: '600' }, color: '#059669'
                    },
                    subtitle: {
                        display: true,
                        text: `Buy: ${sym}${rate.toFixed(2)}/kWh | Sell: ${sym}${sRate.toFixed(2)}/kWh | ${systemType === 'on-grid' ? 'On-Grid' : systemType === 'hybrid' ? 'Hybrid' : 'Off-Grid'}`,
                        font: { size: 11, weight: '500' }, color: '#64748B', padding: { bottom: 8 }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(15,23,42,0.95)', padding: 12, cornerRadius: 8,
                        callbacks: {
                            label: ctx => {
                                const v = ctx.parsed.y;
                                return `${ctx.dataset.label}: ${sym}${Math.round(v).toLocaleString()}`;
                            }
                        }
                    }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { size: 10 } } },
                    y: {
                        beginAtZero: true,
                        title: { display: true, text: `Amount (${sym})`, font: { size: 11 } },
                        grid: { color: 'rgba(0,0,0,0.04)' },
                        ticks: { font: { size: 10 }, callback: v => sym + v.toLocaleString() }
                    }
                }
            }
        };
    }

    // ═══════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════

    function generateEstimatedForecast(systemKwp) {
        const days = [];
        const now = new Date();
        for (let i = 0; i < 30; i++) {
            const d = new Date(now);
            d.setDate(d.getDate() + i);
            // Estimate: ~4.5 PSH average, ±15% daily variation, 82% system derate
            const variation = 0.85 + Math.random() * 0.3;
            const psh = 4.5 * variation;
            const netKwh = systemKwp * psh * 0.82;
            days.push({
                date: d.toISOString().split('T')[0],
                psh: round1(psh),
                net_kwh: round1(netKwh)
            });
        }
        return days;
    }

    function makeDS(label, data, color, bg, fill, width, order, dash) {
        return {
            label, data, borderColor: color, backgroundColor: bg,
            fill, tension: 0.4, borderWidth: width, order,
            pointRadius: 0, pointHoverRadius: 5,
            ...(dash ? { borderDash: dash } : {})
        };
    }

    function getElectricityRate() {
        if (buyRateKwh > 0) return buyRateKwh;
        const r = window.appState?.recommendations?.grid_info?.electricity_rate_kwh;
        return (r && r > 0) ? r : 0.15;
    }

    function getSellRate() {
        if (sellRateKwh > 0) return sellRateKwh;
        const sr = window.appState?.recommendations?.grid_info?.sell_rate_kwh;
        if (sr && sr > 0) return sr;
        // Fallback: buy rate × sellback percentage
        return getElectricityRate() * (sellbackRatePct / 100);
    }

    function getCurrencySymbol() {
        return (window.appState?.activeCurrency?.symbol) || '$';
    }

    function showCard(statId, visible) {
        const card = document.getElementById(statId)?.closest('.stat-card');
        if (card) card.style.display = visible ? '' : 'none';
    }

    function setText(id, text) {
        const el = document.getElementById(id);
        if (el) el.textContent = text;
    }

    function round1(n) { return parseFloat(n.toFixed(1)); }
    function round2(n) { return parseFloat(n.toFixed(2)); }
    function round3(n) { return parseFloat(n.toFixed(3)); }

    function showLoading() {
        const c = document.querySelector('.forecast-chart-container');
        if (c) { c.classList.add('loading'); c.setAttribute('data-loading', 'Calculating energy forecast...'); }
        ['stat-daily-gen', 'stat-daily-use', 'stat-surplus', 'stat-monthly-savings'].forEach(id => {
            const el = document.getElementById(id);
            if (el) { el.textContent = '...'; el.classList.add('loading-pulse'); }
        });
    }

    function hideLoading() {
        const c = document.querySelector('.forecast-chart-container');
        if (c) c.classList.remove('loading');
        ['stat-daily-gen', 'stat-daily-use', 'stat-surplus', 'stat-monthly-savings'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.classList.remove('loading-pulse');
        });
    }

    // ═══════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════

    window.energyForecast = {
        init,
        showForecast,
        updateFromConfigurator,
        getMonthlyFlow: () => simulateMonthlyEnergyFlow(),
        getDailyFlow: () => {
            if (!forecastData?.forecast?.daily_forecast?.[0]) return null;
            const g = forecastData.forecast.daily_forecast[0].net_kwh || 0;
            const u = forecastData.dailyConsumption || 10;
            return simulateDailyEnergyFlow(g, u, forecastData.loadAnalysis?.hourly_load);
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
